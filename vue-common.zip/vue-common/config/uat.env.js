'use strict'
module.exports = {
  NODE_ENV: '"uat"',
  ENV_CONFIG: '"uat"',
  BASE_API: '"https://uat.zhaohu365.com/api/"',
  UPLOAD_API: '"https://uat.zhaohu365.com/api/"',
  WEBSOCKET_URL:'"wss://uat.zhaohu365.com/api/"'
}
