'use strict'
module.exports = {
  NODE_ENV: '"pre"',
  ENV_CONFIG: '"pre"',
  BASE_API: '"http://test.zhaohu365.com/api/"',
  UPLOAD_API: '"http://test.zhaohu365.com/api/"',
  WEBSOCKET_URL:'"wss://test.zhaohu365.com/api/"'
}