'use strict'
module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  BASE_API: '"https://www.zhaohu365.com/api/"',
  UPLOAD_API: '"https://www.zhaohu365.com/api/"',
  WEBSOCKET_URL: '"wss://www.zhaohu365.com/api/"'
}
