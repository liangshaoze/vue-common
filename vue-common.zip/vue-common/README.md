# FSK-VUE-CUSTOMER

> 福寿康管理平台

[线上地址](https://www.zhaohu365.cn/bsapi/)

## Extra

本项目基于`webpack3`开发，请使用该分支[master](http://47.102.44.176:8081/chiyn/fsk-vue-customer.git)

如果你想使用基于 vue + typescript 的管理后台, 可以看看这个项目: [vue-typescript-admin-template](https://github.com/Armour/vue-typescript-admin-template) (鸣谢: [@Armour](https://github.com/Armour))

## Build Setup

```bash
# Clone project
git clone git@47.102.44.176:chiyn/fsk-vue-customer.git

# Install dependencies
npm install

# 建议不要用cnpm  安装有各种诡异的bug 可以通过如下操作解决npm速度慢的问题
npm install --registry=https://registry.npm.taobao.org

# Serve with hot reload at localhost:9528
npm run dev

# Build for production with minification
npm run build

# Build for production and view the bundle analyzer report
npm run build --report
```

## Browsers support

| [<img src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/firefox/firefox_48x48.png" alt="Firefox" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Firefox | [<img src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/chrome/chrome_48x48.png" alt="Chrome" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Chrome | [<img src="https://raw.githubusercontent.com/alrra/browser-logos/master/src/safari/safari_48x48.png" alt="Safari" width="24px" height="24px" />](http://godban.github.io/browsers-support-badges/)</br>Safari |
| --------- | --------- | --------- | --------- |
| last 2 versions| last 2 versions| last 2 versions

Copyright (c) 2019-present chiyn 福寿康 2018 All Rights Reserved 尊慈（上海）养老服务有限公司 版权所有 [沪ICP备18034279号](http://www.beian.miit.gov.cn)
