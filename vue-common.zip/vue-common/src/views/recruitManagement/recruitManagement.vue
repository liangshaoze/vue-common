<template>
	<div id="recruitManagement">
		<headTag :tagName="tagName" />
		<!-- 搜素筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="keyWords" label-width="85px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="姓名" prop="recruitFullName">
							<el-input
								size="mini"
								v-model.trim="keyWords.recruitFullName"
								clearable
								placeholder="请输入姓名"
								maxlength="20"
							/>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="联系电话" prop="recruitTel">
							<el-input
								size="mini"
								v-model.trim="keyWords.recruitTel"
								clearable
								placeholder="请输入联系电话"
								maxlength="11"
							/>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="应聘岗位" prop="positionName">
							<el-autocomplete
								:trigger-on-focus="true"
								v-model.trim="keyWords.positionName"
								size="mini"
								clearable
								:fetch-suggestions="queryPositionName"
								placeholder="请输入岗位"
								@select="selectPositionName"
								@input="removePositionCode"
								@blur="blurPositionName"
							></el-autocomplete>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="推荐来源" prop="recommendSource">
							<el-select size="mini" v-model.trim="keyWords.recommendSource" clearable placeholder="请选择">
								<el-option
									v-for="item in recommendList"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="推荐人" prop="recommendName">
							<el-input size="mini" v-model.trim="keyWords.recommendName" clearable placeholder="请输入推荐人"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="是否录用" prop="isHire">
							<el-select size="mini" v-model.trim="keyWords.isHire" clearable placeholder="请选择">
								<el-option
									v-for="item in isHireList"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="员工归属" prop="recruitBelong">
							<el-select size="mini" v-model.trim="keyWords.recruitBelong" clearable placeholder="请选择">
								<el-option
									v-for="item in recruitBelongList"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="在职状态" prop="workStatus">
							<el-select size="mini" v-model.trim="keyWords.workStatus" clearable placeholder="请选择">
								<el-option
									v-for="item in workStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="面试时间" prop="interviewDate">
							<el-date-picker
								size="mini"
								v-model.trim="keyWords.interviewDate"
								value-format="yyyy-MM-dd"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-items">
						<el-form-item label="入职时间" prop="recruitDate">
							<el-date-picker
								size="mini"
								v-model.trim="keyWords.recruitDate"
								value-format="yyyy-MM-dd"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item class="search_btn">
							<el-button size="mini" type="primary" icon="el-icon-search" @click="getList(1)">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="addRecruitment()">新增</el-button>
					<el-button size="mini" type="primary" icon="el-icon-upload" @click="exportRecruit()">导出</el-button>
					<el-button
						size="mini"
						type="primary"
						icon="el-icon-chat-dot-round"
						@click="infoRecruitment()"
						:loading="loading"
					>发送短信</el-button>
				</el-col>
			</el-row>
			<el-table
				:data="tableData"
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				element-loading-text="拼命加载中"
				highlight-current-row
				stripe
				size="mini"
				v-loading="listLoading"
			>
				<el-table-column prop="recruitFullName" label="姓名" min-width="70"></el-table-column>
				<el-table-column prop="recruitGender" label="性别" min-width="70"></el-table-column>
				<el-table-column prop="recruitTel" label="联系电话" width="120"></el-table-column>
				<el-table-column prop="positionName" label="应聘岗位" min-width="100"></el-table-column>
				<el-table-column prop="recommendSource" label="推荐来源" min-width="100"></el-table-column>
				<el-table-column prop="recommendName" label="推荐人" min-width="100"></el-table-column>
				<el-table-column prop="orgName" label="招聘组织" min-width="150"></el-table-column>
				<el-table-column prop="isHire" label="是否录用" min-width="70"></el-table-column>
				<el-table-column prop="workDate" label="入职时间" width="130">
					<template slot-scope="scope">
						<span v-if="scope.row.workDate != ''">{{scope.row.workDate}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="recruitBelong" label="员工归属" min-width="100"></el-table-column>
				<el-table-column label="操作" fixed="right" width="80">
					<template slot-scope="scope">
						<el-button type="text" @click="viewRecruitment(scope.row)">查看</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--分页-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="listQuery.page"
					:limit.sync="listQuery.pageSize"
					@pagination="pageChange"
				/>
			</el-row>
			<!-- 发送短信弹窗-->
			<el-dialog title="发送短信" :visible.sync="infoModal" width="600px" center>
				<el-row type="flex" justify="center">
					<el-form
						:rules="infoRules"
						ref="formInfoMessage"
						:model="formInfoMessage"
						label-width="100px"
						resize="none"
					>
						<el-form-item label="模板选择:" prop="type" class="selectForm">
							<el-select
								size="mini"
								v-model="formInfoMessage.type"
								clearable
								placeholder="请选择模板"
								@change="selectChange"
							>
								<el-option
									v-for="item in messageOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="手机号码:" prop="phone">
							<el-input
								size="mini"
								style="width:200px;"
								maxlength="11"
								clearable
								v-model="formInfoMessage.phone"
								placeholder="请输入手机号"
							></el-input>
						</el-form-item>
						<el-form-item label="短信内容:" v-if="isMessage" style="margin-top:15px;">
							<el-col style="margin-left:20px;color: #000">面试通知:</el-col>
							<!-- <el-row> -->
							<el-input
								size="mini"
								style="width:100px;"
								maxlength="20"
								v-model="Interview.name"
								placeholder="请输入姓名"
							></el-input>
							<span class="box">您好,我是福寿康（上海）医疗养老公司人事部,通知您:</span>
							<el-date-picker
								size="mini"
								type="datetime"
								placeholder="请选择时间"
								v-model="Interview.date"
								style="width: 170px;"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								:picker-options="expireTimeOption"
							></el-date-picker>
							<span class="box">到地址:</span>
							<el-input
								size="mini"
								style="min-width:300px;margin:10px 0;"
								v-model="Interview.address"
								placeholder="请输入地址"
								maxlength="50"
							></el-input>
							<span class="box">参加面试,岗位:</span>
							<el-input
								size="mini"
								style="width:140px;"
								maxlength="20"
								v-model="Interview.post"
								placeholder="请输入岗位"
							></el-input>
							<span class="box">请您带好身份证等相关证件。联系人:</span>
							<el-input
								size="mini"
								style="width:100px;"
								maxlength="20"
								v-model="Interview.confimName"
								placeholder="请输入姓名"
							></el-input>
							<span class="box">电话:</span>
							<el-input
								size="mini"
								style="width:130px;"
								maxlength="20"
								v-model="Interview.tel"
								placeholder="请输入电话"
							></el-input>
							<!-- </el-row> -->
						</el-form-item>
						<el-form-item label="短信内容:" v-if="isMessgaeModal" style="margin-top:15px;">
							<el-col style="margin-left:20px;color: #000">录用通知:</el-col>
							<!-- <el-col> -->
							<span class="box">你好,</span>
							<el-input
								style="width:100px;"
								maxlength="20"
								size="mini"
								v-model="employment.name"
								placeholder="请输入姓名"
							></el-input>
							<span class="box">,感谢你参加我公司之前</span>
							<el-input
								size="mini"
								style="width:140px;"
								maxlength="20"
								v-model="employment.post"
								placeholder="请输入岗位"
							></el-input>
							<span class="box">,通知您</span>
							<el-date-picker
								size="mini"
								type="datetime"
								placeholder="请选择时间"
								v-model="employment.date"
								style="width: 170px;"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								:picker-options="expireTimeOption"
							></el-date-picker>
							<span class="box">来报到,地址:</span>
							<el-input
								size="mini"
								style="min-width:300px;margin:10px 0;"
								v-model="employment.address"
								placeholder="请输入地址"
								maxlength="50"
							></el-input>
							<span class="box">。请准时带好:</span>
							<el-input
								size="mini"
								style="width:180px;"
								maxlength="20"
								v-model="employment.idCard"
								placeholder="请输入证件"
							></el-input>
							<span class="box">证件前来报到联系人:人事部</span>
							<el-input
								size="mini"
								style="width:100px;"
								maxlength="20"
								v-model="employment.teacherName"
								placeholder="请输入姓名"
							></el-input>
							<span class="box">老师。联系电话：</span>
							<el-input
								size="mini"
								style="width:130px;"
								maxlength="20"
								v-model="employment.cnontactNumber"
								placeholder="请输入联系电话"
							></el-input>
							<span class="box">收到回复，谢谢！</span>
							<!-- </el-col> -->
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer" style="text-align:center">
					<el-button size="mini" @click="isConfirm('formInfoMessage')" style="margin-left:30px;">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="infoSave('formInfoMessage')"
						:loading="Messageloading"
					>发送</el-button>
				</div>
			</el-dialog>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common/index.js";
import { changeYMD } from "utils";
import { export_json_to_excel } from "@/utils/Export2Excel.js";
import { findEhrPositionList } from "api/customerManagement";
import {
	findRecruitInfoList,
	sendMessage,
	exportRecruit
} from "api/recruitmentManagement/index.js";
import {
	validateTel,
	validateIdCard,
	isNumber,
	isMoney,
	chineseName
} from "@/utils/validate";

export default {
	components: {
		HeadTag,
		Pagination
	},
	props: {},
	data () {
		return {
			isMessage: false,
			isMessgaeModal: false,
			templateType: "",
			tagName: "招聘管理",
			expireTimeOption: {
				disabledDate (datetime) {
					return datetime.getTime() < Date.now() - 8.64e7;
				}
			},
			workStatusOptions: [],
			listLoading: false,
			keyWords: {
				recruitFullName: "",
				recruitTel: "",
				positionCode: "",
				positionName: "",
				recommendSource: "",
				recommendName: "",
				orgName: "",
				isHire: "",
				recruitDate: [],
				interviewDate: [],
				workStatusOptions: "",
				recruitBelong: ""
			},
			pickerStartTime: {
				disabledDate: time => {
					let beginDateVal = this.keyWords.entryEndTime;
					if (beginDateVal) {
						return new Date(beginDateVal).getTime() < time.getTime();
					}
				}
			},
			pickerEndTime: {
				disabledDate: time => {
					let beginDateVal = this.keyWords.entryStartTime;
					if (beginDateVal) {
						return new Date(beginDateVal).getTime() > time.getTime();
					} else {
						return time.getTime() < Date.now();
					}
				}
			},
			//推荐来源
			recommendList: [],
			//是否录用
			isHireList: [],
			//员工归属
			recruitBelongList: [],
			recruitObj: [],
			tableData: [],
			totalCount: 0,
			listQuery: {
				page: 1,
				pageSize: 10
			},
			//发送信息
			infoModal: false,
			loading: false,
			infoRules: {
				phone: [
					{
						type: "string",
						required: true,
						message: "请输入手机号",
						trigger: "blur"
					},
					{
						required: true,
						trigger: "blur",
						validator: validateTel
					}
				],
				type: [
					{
						required: true,
						message: "请选择模板",
						trigger: "blur"
					}
				]
			},
			formInfoMessage: {
				phone: "",
				type: "",
				messageList: []
			},
			//短信模板
			messageOptions: [],
			Interview: {
				name: "",
				date: "",
				address: "",
				post: "",
				confimName: "",
				tel: ""
			},
			employment: {
				name: "",
				post: "",
				date: "",
				address: "",
				idCard: "",
				teacherName: "",
				cnontactNumber: ""
			},
			Messageloading: false,
			messageObj: "",
			messageData: ""
		};
	},
	watch: {},
	computed: {},
	methods: {
		//岗位模糊查询
		selectPositionName (item) {
			if (item.value !== "无") {
				this.keyWords.positionCode = item.code;
				this.keyWords.positionName = item.value;
			} else {
				this.keyWords.positionName = "";
			}
		},
		removePositionCode () {
			this.keyWords.positionCode = "";
		},
		blurPositionName(){
			if(!this.keyWords.positionCode){
				this.keyWords.positionName = "";
			}
		},
		queryPositionName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					positionName: queryString
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					positionName: queryString
				};
			}
			findEhrPositionList(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.position = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.position.push({
								value: data[i].positionName,
								code: data[i].positionCode
							});
						}
						var results = this.position;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		selectChange (val) {
			this.templateType = val;
			if (val === "241129") {
				this.isMessage = true;
				this.isMessgaeModal = false;
			} else if (val === "241714") {
				this.isMessgaeModal = true;
				this.isMessage = false;
			}
		},
		//获取数据字典
		initDataDictionary () {
			//在职状态
			findValueBySetCode({ valueSetCode: "WORK_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.workStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "RECOMMEND_SOURCE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.recommendList = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "IS_HIRE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.isHireList = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "STAFF_BELONG" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.recruitBelongList = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "SMS_TEMPLATE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.messageOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		//导出列表数据
		exportRecruit () {
			const tHeader = [
				"序号",
				"应聘组织",
				"姓名",
				"应聘岗位",
				"专业资格证书名称",
				"身份证号码",
				"面试时间",
				"入职时间",
				"离职时间",
				"手机号码",
				"推荐来源",
				"推荐人",
				"推荐人站点",
				"工作开始时间",
				"工作结束时间",
				"工作单位",
				"最后职位",
				"薪水",
				"离职原因",
				"服务年限",
				"老人能否自理",

				"备注"
			];
			// 上面设置Excel的表格第一行的标题
			const filterVal = [
				"orderNum",
				"orgName",
				"recruitFullName",
				"positionName",
				"professionalQualification",
				"idCard",
				"interviewDate",
				"entryDate",
				"quitDate",
				"recruitTel",
				"recommendSource",
				"recommendName",
				"recommendOrgName",
				"workStartDate",
				"workEndDate",
				"companyName",
				"lastPosition",
				"salary",
				"leaveReason",
				"workYears",
				"isProvideOneself",
				"remark"
			];
			// 上面的index、phone_Num、school_Name是tableData里对象的属性
			const params = {
				recruitFullName: this.keyWords.recruitFullName,
				recruitTel: this.keyWords.recruitTel,
				positionName: this.keyWords.positionName,
				recommendSource: this.keyWords.recommendSource,
				recommendName: this.keyWords.recommendName,
				orgName: this.keyWords.orgName,
				isHire: this.keyWords.isHire,
				isWorkStartDate: (this.keyWords.recruitDate && this.keyWords.recruitDate.length > 0) ? (this.keyWords.recruitDate[0] + " 00:00:00") : null,
				isWorkEndDate: (this.keyWords.recruitDate && this.keyWords.recruitDate.length > 0) ? (this.keyWords.recruitDate[1] + " 23:59:59") : null,
				interviewStartDate: (this.keyWords.interviewDate && this.keyWords.interviewDate.length > 0) ? (this.keyWords.interviewDate[0] + " 00:00:00") : null,
				interviewEndDate: (this.keyWords.interviewDate && this.keyWords.interviewDate.length > 0) ? (this.keyWords.interviewDate[1] + " 23:59:59") : null,
				workStatus: this.keyWords.workStatus,
				recruitBelong: this.keyWords.recruitBelong
			};
			exportRecruit(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode == "200"
					) {
						const list = response.data.responseData;
						list.forEach((item, index) => {
							item.orderNum = index + Number(1);
							// item.interviewDate =
							//   item.interviewDate !== undefined
							//     ? changeYMD(item.interviewDate)
							//     : "";
							// item.entryDate =
							//   item.entryDate !== undefined
							//     ? changeYMD(item.entryDate)
							//     : "";
							// item.quitDate =
							//   item.quitDate !== undefined ? changeYMD(item.quitDate) : "";
							// item.workStartDate =
							//   item.workStartDate !== undefined ? changeYMD(item.workStartDate) : "";

							//    item.workEndDate =
							//   item.workEndDate !== undefined ? changeYMD(item.workEndDate) : "";
							return item;
						});
						if (list.length > 0) {
							const data = this.formatJson(filterVal, list);
							export_json_to_excel(tHeader, data, "招聘信息列表");
						} else {
							this.$message.error("操作失败");
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.searchLoading = false;
				});
		},
		formatJson (filterVal, jsonData) {
			return jsonData.map(v => filterVal.map(j => v[j]));
		},
		// 列表数据
		getList (page) {
			this.listQuery.page = page;
			this.listLoading = true;
			let params = {
				recruitFullName: this.keyWords.recruitFullName,
				recruitTel: this.keyWords.recruitTel,
				recommendSource: this.keyWords.recommendSource,
				recommendName: this.keyWords.recommendName,
				isHire: this.keyWords.isHire,
				recruitGender: this.keyWords.recruitGender,
				recruitBelong: this.keyWords.recruitBelong,
				isWorkStartDate: (this.keyWords.recruitDate && this.keyWords.recruitDate.length > 0)
					? (this.keyWords.recruitDate[0] + " 00:00:00")
					: null,
				isWorkEndDate: (this.keyWords.recruitDate && this.keyWords.recruitDate.length > 0)
					? (this.keyWords.recruitDate[1] + " 23:59:59")
					: null,
				interviewStartDate: (this.keyWords.interviewDate && this.keyWords.interviewDate.length > 0)
					? (this.keyWords.interviewDate[0] + " 00:00:00")
					: null,
				interviewEndDate: (this.keyWords.interviewDate && this.keyWords.interviewDate.length > 0)
					? (this.keyWords.interviewDate[1] + " 23:59:59")
					: null,

				workStatus: this.keyWords.workStatus,
				positionCode: this.keyWords.positionCode,
				positionName: this.keyWords.positionName,
				pageNum: page,
				pageSize: this.listQuery.pageSize
			};
			this.listLoading = true;
			findRecruitInfoList(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode == "200"
					) {
						if (response.data.responseData != undefined) {
							this.recruitObj = response.data.responseData;
							for (let i = 0; i < this.recruitObj.length; i++) {
								if (this.recruitObj[i].workDate) {
									this.recruitObj[i].workDate = changeYMD(
										this.recruitObj[i].workDate
									);
								}
							}
							this.tableData = response.data.responseData;
							this.totalCount = response.data.totalCount;
							this.listLoading = false;
						} else {
							this.listLoading = false;
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.listQuery.page = val.page;
			this.listQuery.pageSize = val.limit;
			this.getList(val.page); //改变页码，重新渲染页面
		},
		changeTime () {
			this.keyWords.entryEndTime = "";
		},
		//查看详情操作
		viewRecruitment (row) {
			this.$router.push({
				path: "/personnelManagement/viewRecruit",
				query: {
					recruitCode: row.recruitCode,
					recruitId: row.id
					// status: "edit"
				}
			});
		},
		addRecruitment () {
			this.$router.push({
				path: "/personnelManagement/addRecruit"
				// recruitCode: row.recruitCode,
				// recruitId: row.id
			});
		},
		infoRecruitment () {
			this.infoModal = true;
		},
		isConfirm (formInfoMessage) {
			this.$refs[formInfoMessage].resetFields();
			this.templateType = "";
			// this.messageOptions = [];
			this.formInfoMessage.message = "";
			this.formInfoMessage.type = "";
			this.formInfoMessage.phone = "";
			this.Interview.name = "";
			this.Interview.date = "";
			this.Interview.address = "";
			this.Interview.post = "";
			this.Interview.confimName = "";
			this.Interview.tel = "";
			this.employment.name = "";
			this.employment.date = "";
			this.employment.address = "";
			this.employment.post = "";
			this.employment.teacherName = "";
			this.employment.tel = "";
			this.employment.idCard = "";
			this.employment.cnontactNumber = "";
			this.isMessage = false;
			this.isMessgaeModal = false;
			this.infoModal = false;
		},
		infoSave (formInfoMessage) {
			this.$refs[formInfoMessage].validate(valid => {
				if (valid) {
					this.formInfoMessage.messageList = [];
					if (this.templateType == "241129") {
						let obj = this.Interview;
						Object.keys(obj).map((key, index) => {
							this.formInfoMessage.messageList.push({
								message: obj[key],
								sort: index
							});
						});
						for (let i = 0; i < this.formInfoMessage.messageList.length; i++) {
							let messages = this.formInfoMessage.messageList[i].message;
							if (messages == "") {
								this.$message.error("短信内容必须填写完整");
								return false;
							}
						}
						let params = {
							type: this.templateType,
							phone: this.formInfoMessage.phone,
							messageList: this.formInfoMessage.messageList
						};
						this.Messageloading = true;
						sendMessage(params)
							.then(response => {
								if (
									response.data.statusCode == 200 ||
									response.data.statusCode == "200"
								) {
									this.$message.success("发送成功");
									this.Messageloading = false;
									this.infoModal = false;
									this.isMessage = false;
									this.isMessgaeModal = false;
									this.Messageloading = false;
									this.formInfoMessage.type = "";
									this.formInfoMessage.phone = "";
									this.formInfoMessage.message = "";
									this.Interview.name = "";
									this.Interview.date = "";
									this.Interview.address = "";
									this.Interview.post = "";
									this.Interview.confimName = "";
									this.Interview.tel = "";
								} else {
									this.$message.error(response.data.statusMsg);
									this.Messageloading = false;
								}
							})
							.catch(error => {
								this.Messageloading = false;
								this.$message.error(response.data.statusMsg);
							});
						// }
					} else if (this.templateType == "241714") {
						// var messageArr = [];
						let obj = this.employment;
						Object.keys(obj).map((key, index) => {
							this.formInfoMessage.messageList.push({
								message: obj[key],
								sort: index
							});
						});
						for (let i = 0; i < this.formInfoMessage.messageList.length; i++) {
							let messageIntive = this.formInfoMessage.messageList[i].message;
							if (messageIntive == "") {
								this.$message.error("短信内容必须填写完整");
								return false;
							}
						}
						let params = {
							type: this.templateType,
							phone: this.formInfoMessage.phone,
							messageList: this.formInfoMessage.messageList
						};
						this.Messageloading = true;
						sendMessage(params)
							.then(response => {
								if (
									response.data.statusCode == 200 ||
									response.data.statusCode == "200"
								) {
									this.$message.success("发送成功");
									this.Messageloading = false;
									this.infoModal = false;
									this.isMessage = false;
									this.isMessgaeModal = false;
									this.Messageloading = false;
									this.formInfoMessage.type = "";
									this.formInfoMessage.phone = "";
									this.formInfoMessage.message = "";
									this.employment.name = "";
									this.employment.date = "";
									this.employment.address = "";
									this.employment.post = "";
									this.employment.teacherName = "";
									this.employment.tel = "";
									this.employment.idCard = "";
									this.employment.cnontactNumber = "";
								} else {
									this.$message.error(response.data.statusMsg);
									this.Messageloading = false;
								}
							})
							.catch(error => {
								this.Messageloading = false;
								this.$message.error(response.data.statusMsg);
							});
					}
				} else {
					this.$message.error("请先输入必填信息");
					this.Messageloading = false;
					return false;
				}
			});
		},
		resetForm () {
			this.$refs.filterForm.resetFields();
			this.getList(1);
		}
	},
	created () {
		this.initDataDictionary();
		// this.getList(1);
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#recruitManagement {
	width: 100%;
	min-width: 1250px;
	.el-form-item {
		margin-bottom: 0px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.el-autocomplete {
	width: 200px;
}
.form-item {
	width: 30%;
	min-width: 295px;
}

.form-items {
	width: 30%;
	min-width: 350px;
}
.search_btn {
	min-width: 250px;
	margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.selectForm {
	padding: 20px 0;
}
.pic_icon {
	width: 20px;
	height: 20px;
}
</style>
<style lang="scss">
#recruitManagement {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
</style>