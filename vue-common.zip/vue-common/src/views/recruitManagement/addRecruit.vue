<template>
  <div id="addRecruit">
    <headTag :tagName="tagName" />

    <div class="main-content">
      <div class="main-left">
        <div class="margin-left-form" id="basicForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">基本信息</span>
              <el-button size="small" type="text" :disabled="importDisabled" @click="openRecruitDialog()">
                <span style="text-aligin:center">
                  <img src="@/assets/img/daoru.png" style="width:15px;height:100%;margin-right:7px;" />导入人脸识别信息
                </span>
              </el-button>
              <el-button size="small " type="primary" @click="returnRecrutiList()" class="rightBtn">返回</el-button>
              <el-button size="small" type="primary" @click="saveBasic('basicForm')" :loading="loadingBtn" class="rightBtn" v-if="isShow">保存
              </el-button>
              <el-button type="primary" size="small" :loading="loadingBtn" @click="editForm()" class="rightBtn" v-if="!isShow">修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="basicForm" :inline="false" :model="basicForm" :rules="basicFormRules" label-width="200px" class="form-content">
              <el-col class="form-item">
                <el-form-item label="姓名" prop="recruitFullName">
                  <span v-if="isEdit == false">{{basicForm.recruitFullName}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.recruitFullName" clearable placeholder="请输入姓名" maxlength="20" />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="性别" prop="recruitGender">
                  <span v-if="isEdit == false">{{basicForm.recruitGenderName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.recruitGender" clearable placeholder="请选择">
                      <el-option v-for="item in sexOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="面试时间" prop="interviewDate">
                  <span v-if="isEdit == false">{{basicForm.interviewDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker size="mini" v-model="basicForm.interviewDate" type="date" clearable value-format="yyyy-MM-dd"
                      placeholder="请选择面试时间"></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="手机号码" prop="recruitTel">
                  <span v-if="isEdit == false">{{basicForm.recruitTel}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.recruitTel" clearable placeholder="请输入手机号码" maxlength="11"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="应聘组织" prop="orgName">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.orgName}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.orgName" placeholder="请选择组织" @focus="dialogVisible=true" @clear="clearOrgCode" clearable>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="应聘岗位" prop="positionName">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.positionName}}</span>
                  <span v-if="isEdit == true">
                    <el-autocomplete :trigger-on-focus="true" v-model="basicForm.positionName" size="mini" clearable
                      :fetch-suggestions="queryPositionName" placeholder="请选择应聘岗位" @select="selectPositionName" @input="removePositionCode" @blur="blurPositionName">
                    </el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="户籍地址">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.houseProvinceName}}{{basicForm.houseCityName}}{{basicForm.houseDistrictName}}</span>
                  <span v-if="isEdit == true">
                    <AdressRecruit ref="houseAddress" :address="{
                        provinceCode:basicForm.houseProvinceCode,
                        provinceName:basicForm.houseProvinceName,
                        cityCode: basicForm.houseCityCode,
                        cityName: basicForm.houseCityName,
                        districtCode:basicForm.houseDistrictCode,
                        districtName:basicForm.houseDistrictName
                        }" @selectedProvinceListener="selectedHouseProvinceListener" @selectedCityListener="selectedHouseCityListener"
                      @selectedDistrictListener="selectedHouseDistrictListener" />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.houseDetailAddress}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.houseDetailAddress" clearable placeholder="请输入户籍详细地址" maxlength="50"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="身份证号码" prop="idCard">
                  <span v-if="isEdit == false">{{basicForm.idCard}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.idCard" clearable placeholder="请输入身份证号码" maxlength="18"></el-input>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-item">
                <el-form-item label="身份证地址">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.idCardAddress}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.idCardAddress" clearable placeholder="请输入身份证地址" maxlength="30"></el-input>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-item">
                <el-form-item label="出生年月日" prop="recruitBirthday">
                  <span v-if="isEdit == false">{{basicForm.recruitBirthday}}</span>
                  <span v-if="isEdit == true">
                    <el-input v-model="basicForm.recruitBirthday" size="mini" clearable placeholder="请输入例如：1950-01-01"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="年龄" prop="recruitAge">
                  <span v-if="isEdit == false">{{basicForm.recruitAge}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model.number="basicForm.recruitAge" clearable placeholder="请输入年龄" maxlength="20" />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="籍贯" prop="nativePlace">
                  <span v-if="isEdit == false">{{basicForm.nativePlace}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.nativePlace" clearable placeholder="请输入籍贯" maxlength="50"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="现居住地址">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.liveProvinceName}}{{basicForm.liveCityName}}{{basicForm.liveDistrictName}}</span>
                  <span v-if="isEdit == true">
                    <AdressRecruit ref="liveAddress" :address="{
                        provinceCode:basicForm.liveProvinceCode,
                        provinceName:basicForm.liveProvinceName,
                        cityCode: basicForm.liveCityCode,
                        cityName: basicForm.liveCityName,
                        districtCode:basicForm.liveDistrictCode,
                        districtName:basicForm.liveDistrictName
                        }" @selectedProvinceListener="selectedLiveProvinceListener" @selectedCityListener="selectedLiveCityListener"
                      @selectedDistrictListener="selectedLiveDistrictListener" />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="现居住详细地址">
                  <span v-if="isEdit == false" class="long-field">{{basicForm.liveDetailAddress}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.liveDetailAddress" clearable placeholder="请输入现居住详细地址" maxlength="50"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <!-- <el-col class="form-item">
                <el-form-item label="婚姻状况" prop="maritalStatus">
                  <span v-if="isEdit == false">{{basicForm.maritalStatusName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.maritalStatus" clearable placeholder="请选择">
                      <el-option v-for="item in MarriageOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col> -->

              <!-- <el-col class="form-item">
                <el-form-item label="城镇户口" prop="isUrbanRegistration">
                  <span v-if="isEdit == false">{{basicForm.isUrbanRegistrationName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isUrbanRegistration" placeholder="请选择">
                      <el-option v-for="item in townOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col> -->

              <!-- <el-col class="form-item">
                <el-form-item label="邮政编码" prop="postalCode">
                  <span v-if="isEdit == false">{{basicForm.postalCode}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.postalCode" clearable placeholder="请输入邮政编码" maxlength="8"></el-input>
                  </span>
                </el-form-item>
              </el-col> -->
              <!-- <el-col class="form-item">
                <el-form-item label="最近体检时间" prop="physicalCheckDate">
                  <span v-if="isEdit == false">{{basicForm.physicalCheckDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker size="mini" v-model="basicForm.physicalCheckDate" type="date" value-format="yyyy-MM-dd" clearable
                      placeholder="请选择体检时间"></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="是否缴纳社保" prop="isSocialSecurity">
                  <span v-if="isEdit == false">{{basicForm.isSocialSecurityName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isSocialSecurity" clearable placeholder="请选择">
                      <el-option v-for="item in securityOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="身体状况" prop="physicalCondition">
                  <span v-if="isEdit == false">{{basicForm.physicalConditionName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" clearable v-model="basicForm.physicalCondition" placeholder="请选择">
                      <el-option v-for="item in bodyOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="有无健康证" prop="isHealthCertificate">
                  <span v-if="isEdit == false">{{basicForm.isHealthCertificateName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isHealthCertificate" clearable placeholder="请选择">
                      <el-option v-for="item in healthyOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="是否缴纳公积金" prop="isHousingFund">
                  <span v-if="isEdit == false">{{basicForm.isHousingFundName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isHousingFund" clearable placeholder="请选择">
                      <el-option v-for="item in accumulationOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="信仰" prop="recruitFaith">
                  <span v-if="isEdit == false">{{basicForm.recruitFaithName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" clearable v-model="basicForm.recruitFaith" placeholder="请选择">
                      <el-option v-for="item in faithOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="现在状况" prop="workCondition">
                  <span v-if="isEdit == false">{{basicForm.workConditionName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.workCondition" clearable placeholder="请选择">
                      <el-option v-for="item in presentOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="证件是否为本人所有" prop="isSelfCertificate">
                  <span v-if="isEdit == false">{{basicForm.isSelfCertificateName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isSelfCertificate" clearable placeholder="请选择">
                      <el-option v-for="item in whetherOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col> -->
              <el-col class="form-item">
                <el-form-item label="毕业院校">
                  <span v-if="isEdit == false">{{basicForm.graduatedSchool}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.graduatedSchool" clearable placeholder="请输入毕业院校" maxlength="20" />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="最高学历" prop="recruitEducation">
                  <span v-if="isEdit == false">{{basicForm.recruitEducationName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.recruitEducation" clearable placeholder="请选择">
                      <el-option v-for="item in highestEductionOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-item">
                <el-form-item label="员工归属" prop="recruitBelong">
                  <span v-if="isEdit == false">{{basicForm.recruitBelongName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.recruitBelong" clearable placeholder="请选择">
                      <el-option v-for="item in staffOwnershipOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="合作商">
                  <span v-if="isEdit == false">
                    <span v-if="basicForm.cooperationCode">{{basicForm.cooperationName}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-autocomplete :trigger-on-focus="true" v-model="basicForm.cooperationName" size="mini" clearable
                      :fetch-suggestions="queryCooperationName" placeholder="请输入合作商名称" @select="selectCooperationName" @input="removeCooperationCode">
                    </el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="在合作商岗位" prop="cooperationPosition">
                  <span v-if="isEdit == false">{{basicForm.cooperationPositionName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.cooperationPosition" clearable placeholder="请选择">
                      <el-option v-for="item in partnerPostOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="电子邮箱" prop="recruitEmail">
                  <span v-if="isEdit == false">{{basicForm.recruitEmail}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.recruitEmail" clearable placeholder="请输入电子邮箱" maxlength="50"></el-input>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-item">
                <el-form-item label="推荐来源" prop="recommendSource">
                  <span v-if="isEdit == false">{{basicForm.recommendSourceName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.recommendSource" @change="selectSupplier" clearable placeholder="请选择">
                      <el-option v-for="item in recommendOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-iteml">
                <el-form-item label="推荐人">
                  <span v-if="isEdit == false">{{basicForm.recommendName}}</span>
                  <span v-if="isEdit == true && isStaff">
                    <!-- 员工模糊查询 -->
                    <el-autocomplete :trigger-on-focus="true" v-model="recommendCodeStaff" popper-class="my-autocomplete" size="mini" clearable
                      :fetch-suggestions="queryStaffName" placeholder="请输入推荐人" @select="selectStaffName" @input="removeStaffCode"
                      :disabled="staffDisabled" v-show="isStaff">
                      <template slot-scope="{ item }">
                        <span class="name">
                          {{ item.value }}
                          <span v-if="item.value != '无'">({{ item.staffTel }})</span>
                        </span>
                      </template>
                    </el-autocomplete>
                  </span>
                  <!-- 供应商查询 -->
                  <span v-if="isEdit == true && !isStaff">
                    <el-autocomplete :trigger-on-focus="true" v-model="recommendCodeSupplier" size="mini" clearable
                      :fetch-suggestions="querySupplierName" placeholder="请输入推荐人" @select="selectSupplierName" @input="removeSupplierCode"
                      v-show="isSupplier"></el-autocomplete>
                  </span>
                  <!-- 内部组织 -->
                  <span v-if="isEdit == true && !isStaff">
                    <el-autocomplete :trigger-on-focus="true" v-model="recommendCodeOrg" size="mini" clearable :fetch-suggestions="queryOrgName"
                      placeholder="请输入推荐人" @select="selectisOrgName" @input="removeOrgCode" v-show="isOrg"></el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item" v-if="IsRecommend || basicForm.recommendSource=='10'">
                <el-form-item label="推荐人站点">
                  <span v-if="isEdit == false">
                    <span v-if="basicForm.recommendOrgCode">{{basicForm.recommendOrgName}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.recommendOrgName" clearable placeholder="请输入推荐人站点"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="身高" prop="recruitHeight">
                  <span v-if="isEdit == false">{{basicForm.recruitHeight}}</span>
                  <span v-if="isEdit == true">
                    <el-input size="mini" v-model="basicForm.recruitHeight" clearable placeholder="请输入身高" maxlength="10"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="如录用，何时报到">
                  <span v-if="isEdit == false">{{basicForm.reportDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker size="mini" v-model="basicForm.reportDate" value-format="yyyy-MM-dd" type="date" clearable placeholder="请选择报到时间">
                    </el-date-picker>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-item">
                <el-form-item label="是否曾有过犯罪记录" prop="isCrime">
                  <span v-if="isEdit == false">{{basicForm.isCrimeName}}</span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" v-model="basicForm.isCrime" clearable placeholder="请选择">
                      <el-option v-for="item in crimeOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="是否会骑车">
                  <span v-if="isEdit == false">{{basicForm.isCycleName}}</span>
                  <span v-if="isEdit == true">
                    <el-radio-group size="mini" v-model="basicForm.isCycle">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-itemd">
                <el-form-item label="专业特长">
                  <span v-if="isEdit == false" class="long-field">
                     <span v-if="basicForm.specialtiesList">
                      <span v-if="basicForm.specialtiesList.length>0">
                        <span  v-for="(item,index) of basicForm.specialtiesList" :key="index">
                          <span>{{item}}</span>
                        </span>
                        <span v-if="basicForm.specialtiesDesc">{{basicForm.specialtiesDesc}}</span>
                      </span>
                      </span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-select size="mini" filterable allow-create default-first-option multiple v-model="basicForm.specialtiesList" placeholder="请选择专业特长" @change="selectMajor" @remove-tag="removeTag">
                      <el-option v-for="item in majorOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                     <el-input slot="append" size="mini" v-model="basicForm.specialtiesDesc" clearable placeholder="请输入" v-if="isMajor"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <!-- <el-col class="form-item">
                <el-form-item label="是否接受居家入户">
                  <span v-if="isEdit == false">{{basicForm.isAcceptHomeName}}</span>
                  <span v-if="isEdit == true">
                    <el-radio-group size="mini" v-model="basicForm.isAcceptHome">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col> -->
              <!-- <el-col class="form-item">
                <el-form-item label="需要公司提供住宿">
                  <span v-if="isEdit == false">{{basicForm.isNeedAccommodationName}}</span>
                  <span v-if="isEdit == true">
                    <el-radio-group size="mini" v-model="basicForm.isNeedAccommodation">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="是否背调" prop="backgroundCheckStatus">
                  <span v-if="isEdit == false">
                    <span v-if="basicForm.backgroundCheckStatus == 0">否</span>
                    <span v-if="basicForm.backgroundCheckStatus == 1">
                      是
                      <el-button size="mini" style="margin-left:10px;" @click="btnDetail()">查看详情</el-button>
                    </span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-radio-group size="mini" v-model="basicForm.backgroundCheckStatus">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                    <span v-if="basicForm.backgroundCheckStatus == 1">
                      <el-button size="mini" style="margin-left:10px;" @click="btnDetail()">查看详情</el-button>
                    </span>
                  </span>
                </el-form-item>
              </el-col> -->
            </el-form>
          </el-row>
        </div>
        <div class="margin-left-form" id="educationForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">教育情况</span>
              <el-button size="mini" type="primary" class="rightBtn" icon="el-icon-plus" @click="addEducationForm('educationForm')">新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="educationForm.rules" :model="educationForm" ref="educationForm">
                <el-table :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" stripe :data="educationForm.tableData"
                  v-loading="educationListLoading" highlight-current-row element-loading-text="拼命加载中" class="tableMain">
                  <el-table-column prop="startDate" label="开始时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.startDate">
                          <span>{{ scope.row.startDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.startDate'" :rules="educationForm.rules.startDate">
                          <el-date-picker size="mini" v-model="scope.row.startDate" value-format="yyyy-MM-dd" type="date" placeholder="选择时间">
                          </el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="endDate" label="结束时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.endDate">
                          <span>{{ scope.row.endDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.endDate'" :rules="educationForm.rules.endDate">
                          <el-date-picker size="mini" v-model="scope.row.endDate" value-format="yyyy-MM-dd" type="date" placeholder="选择时间">
                          </el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="schoolName" label="学校" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.schoolName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.schoolName'">
                          <el-input size="mini" v-model="scope.row.schoolName" placeholder="请输入学校"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="major" label="专业" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.major }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.major'">
                          <el-input size="mini" v-model="scope.row.major" placeholder="请输入专业"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateName" label="证书" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.certificateName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateName'">
                          <el-input size="mini" v-model="scope.row.certificateName" placeholder="请输入证书"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateUrl" label="证书上传" min-width="300px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.urlList&&scope.row.urlList.length>0">
                          <div v-for="(item,index) of scope.row.urlList" :key="index">
                            <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                              {{item.name}}
                              <i class="el-icon-view"></i>
                            </el-link>
                          </div>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateUrl'">
                          <table-upload size="mini" :multiple="false" :limit="10" :action="actionUrl" :indexLine="scope.$index"
                            :file-list="scope.row.urlList" @handleGetUrl="getResumeUrl" @handleRemoveList="removeResumeList"></table-upload>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" min-width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button type="primary" size="mini" v-if="!scope.row.editing" icon="el-icon-edit-outline"
                          @click="handleEditEducationForm(scope.$index, scope.row)">编辑</el-button>
                        <el-button type="primary" size="mini" v-if="scope.row.editing" icon="el-icon-success"
                          @click="handleSaveEducationForm(scope.$index, scope.row, 'educationForm')">保存</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleDeleteEducationForm(scope.$index, scope.row)">删除
                        </el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <div class="margin-left-form" id="workExpForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">工作经历</span>
              <el-button size="mini" class="rightBtn" type="primary" icon="el-icon-plus" @click="addWorkExpForm('workExpForm')">新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="workExpForm.rules" :model="workExpForm" ref="workExpForm">
                <el-table :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" stripe :data="workExpForm.tableData"
                  v-loading="workExpListLoading" highlight-current-row element-loading-text="拼命加载中" class="tableMain">
                  <el-table-column prop="startDate" label="开始时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.startDate">
                          <span>{{ scope.row.startDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.startDate'" :rules="workExpForm.rules.startDate">
                          <el-date-picker size="mini" v-model="scope.row.startDate" value-format="yyyy-MM-dd" type="date" placeholder="选择时间">
                          </el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="endDate" label="结束时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.endDate">
                          <span>{{ scope.row.endDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.endDate'" :rules="workExpForm.rules.endDate">
                          <el-date-picker size="mini" v-model="scope.row.endDate" value-format="yyyy-MM-dd" type="date" placeholder="选择时间">
                          </el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="companyName" label="工作单位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.companyName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.companyName'">
                          <el-input size="mini" v-model="scope.row.companyName" placeholder="请输入工作单位"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="lastPosition" label="最后职位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.lastPosition }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.lastPosition'">
                          <el-input size="mini" v-model="scope.row.lastPosition" placeholder="请输入最后职称"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="salary" label="薪水" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.salary }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.salary'">
                          <el-input size="mini" v-model="scope.row.salary" placeholder="请输入薪水"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="leaveReason" label="离职原因" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.leaveReason }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.leaveReason'">
                          <el-input size="mini" v-model="scope.row.leaveReason" placeholder="请输入离职原因"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="workEmployer" label="工作证明人" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.workEmployer }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.workEmployer'">
                          <el-input size="mini" v-model="scope.row.workEmployer" placeholder="请输入工作证明人"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="relationship" label="与本人关系" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.relationship }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.relationship'">
                          <el-input size="mini" v-model="scope.row.relationship" placeholder="请输入与本人关系"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contactsTel" label="联系方式" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row. contactsTel }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.      contactsTel'">
                          <el-input size="mini" v-model="scope.row.contactsTel" placeholder="请输入联系方式" maxlength="11"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="workYears" label="服务年限" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.workYearsValue }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.workYears'">
                          <el-select size="mini" v-model="scope.row.workYears" placeholder="请选择" clearable
                            @change="changeWorkYears(scope.row.workYears,scope.$index)">
                            <el-option v-for="item in serviceYearsOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isProvideOneself" label="老人能否自理" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.isProvideOneselfValue }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.isProvideOneself'">
                          <el-select size="mini" v-model="scope.row.isProvideOneself" placeholder="请选择" clearable
                            @change="changeIsProvideOneself(scope.row.isProvideOneself,scope.$index)">
                            <el-option v-for="item in isCareOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" min-width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button type="primary" size="mini" v-if="!scope.row.editing" icon="el-icon-edit-outline"
                          @click="handleEditWorkExpForm(scope.$index, scope.row)">编辑</el-button>
                        <el-button type="primary" size="mini" v-if="scope.row.editing" icon="el-icon-success"
                          @click="handleSaveWorkExpForm(scope.$index, scope.row, 'workExpForm')">保存</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleDeleteWorkExpForm(scope.$index, scope.row)">删除
                        </el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <div class="margin-left-form" id="professionalForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">专业资格或资质名称</span>
              <el-button class="rightBtn" size="mini" type="primary" icon="el-icon-plus" @click="addMajorQualForm('professionalForm')">新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="professionalForm.rules" :model="professionalForm  " ref="professionalForm">
                <el-table :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" stripe :data="professionalForm.tableData"
                  v-loading="professionalListLoading" highlight-current-row element-loading-text="拼命加载中" class="tableMain">
                  <el-table-column prop="professionalQualification" label="专业资格或资质名称" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.professionalQualification }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.professionalQualification'"
                          :rules="professionalForm.rules.professionalQualification">
                          <el-input size="mini" v-model="scope.row.professionalQualification" placeholder="请输入专业资格或资质名称"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="issueAuthority" label="颁发机构" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.issueAuthority }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.issueAuthority'">
                          <el-input size="mini" v-model="scope.row.issueAuthority" placeholder="请输入颁发机构"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="issueDate" label="颁发日期" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.issueDate }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.issueDate'">
                          <el-date-picker size="mini" v-model="scope.row.issueDate" value-format="yyyy-MM-dd" type="date"></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateLevel" label="证书等级" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.certificateLevelValue}}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateLevel'">
                          <el-select size="mini" v-model="scope.row.certificateLevel" placeholder="请选择" clearable
                            @change="changeCertificateLevel(scope.row.certificateLevel,scope.$index)">
                            <el-option v-for="item in certificateLevelOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateUrl" label="证书上传" min-width="300px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.certList&&scope.row.certList.length>0">
                          <el-col v-for="(item,index) of scope.row.certList" :key="index">
                            <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                              {{item.name}}
                              <i class="el-icon-view"></i>
                            </el-link>
                          </el-col>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateUrl'">
                          <table-upload size="mini" :multiple="false" :limit="10" :action="actionUrl" :indexLine="scope.$index"
                            :file-list="scope.row.certList" @handleGetUrl="getProfessionalUrl" @handleRemoveList="removeProfessionalList">
                          </table-upload>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="remark" label="备注" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.remark }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.remark'">
                          <el-input v-model="scope.row.remark" size="mini" placeholder="请输入备注" maxlength="100"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" min-width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button type="primary" size="mini" v-if="!scope.row.editing" icon="el-icon-edit-outline"
                          @click="handleEditMajorQualForm(scope.$index, scope.row)">编辑</el-button>
                        <el-button type="primary" size="mini" v-if="scope.row.editing" icon="el-icon-success"
                          @click="handleSaveMajorQualForm(scope.$index, scope.row, 'professionalForm')">保存</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleDeleteMajorQualForm(scope.$index, scope.row)">删除
                        </el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <!-- <div class="margin-left-form" id="familyStatusForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">家庭状况</span>
              <el-button size="mini" class="rightBtn" type="primary" icon="el-icon-plus" @click="addFamilyStatusForm('familyStatusForm')">新增
              </el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="familyStatusForm.rules" :model="familyStatusForm" ref="familyStatusForm">
                <el-table :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" stripe :data="familyStatusForm.tableData"
                  v-loading="familyStatusListLoading" highlight-current-row element-loading-text="拼命加载中" class="tableMain">
                  <el-table-column prop="familyMemberName" label="姓名" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.familyMemberName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.familyMemberName'" :rules="familyStatusForm.rules.familyMemberName">
                          <el-input size="mini" v-model="scope.row.familyMemberName" placeholder="请输入姓名"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="relationship" label="关系" min-width="200px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.relationship }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.relationship'">
                          <el-input size="mini" v-model="scope.row.relationship" placeholder="请输入关系"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="companyName" label="工作单位" min-width="200px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.companyName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.companyName'">
                          <el-input size="mini" v-model="scope.row.companyName" placeholder="请输入工作单位"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="position" label="职务" min-width="200px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.position }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.position'">
                          <el-input size="mini" v-model="scope.row.position" placeholder="请输入职务"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contactsTel" label="联系电话" min-width="200px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.contactsTel }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.contactsTel'">
                          <el-input size="mini" v-model="scope.row.contactsTel" placeholder="请输入联系电话"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" min-width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button type="primary" size="mini" v-if="!scope.row.editing" icon="el-icon-edit-outline"
                          @click="handleEditFamilyStatusForm(scope.$index, scope.row)">编辑</el-button>
                        <el-button type="primary" size="mini" v-if="scope.row.editing" icon="el-icon-success"
                          @click="handleSaveFamilyStatusForm(scope.$index, scope.row, 'familyStatusForm')">保存</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="handleDeleteFamilyStatusForm(scope.$index, scope.row)">删除
                        </el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div> -->
        <div class="margin-left-form" id="reviewForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">审核</span>
              <el-button size="mini" type="primary" @click="examineFormSave()" :loading="loadingBtn" class="rightBtn" v-if="isShowExamine">保存
              </el-button>
              <el-button size="mini" type="primary" :loading="loadingBtn" @click="examineEdit()" class="rightBtn" v-if="!isShowExamine">修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form ref="examineForm" :inline="false" :model="examineForm" label-width="200px" class="form-content">
             <el-col class="form-itemE">
                <el-form-item label="是否包住">
                  <span v-if="isExamine == false">{{examineForm.isAccommodationName }}</span>
                  <span v-if="isExamine == true">
                    <el-radio-group size="mini" v-model="examineForm.isAccommodation">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-items">
                <el-form-item label="是否录用">
                  <span v-if="isExamine == false">{{examineForm.isHireName }}</span>
                  <span v-if="isExamine == true">
                    <el-radio-group size="mini" v-model="examineForm.isHire">
                      <el-radio v-for="item in isHireOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>
              
              <el-col class="form-itemE">
                <el-form-item label="报到情况">
                  <span v-if="isExamine == false">{{examineForm.isReportName }}</span>
                  <span v-if="isExamine == true">
                    <el-radio-group size="mini" v-model="examineForm.isReport">
                      <el-radio v-for="item in backgroundOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>
          
             
              <el-col class="form-items">
                <el-form-item label="上岗时间">
                  <span v-if="isExamine == false">
                    <span v-if="examineForm.isWorkName|| examineForm.workDate">{{examineForm.isWorkName }}{{examineForm.workDate}}</span>
                  </span>
                  <span v-if="isExamine == true">
                    <el-radio-group size="mini" v-model="examineForm.isWork">
                      <el-radio v-for="item in isWorkOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
                      <el-date-picker size="mini" style="width:130px;" v-model="examineForm.workDate" type="date" clearable value-format="yyyy-MM-dd"
                        placeholder="请选择时间"></el-date-picker>
                    </el-radio-group>
                  </span>
                </el-form-item>
              </el-col>

              <el-col class="form-itemE">
                <el-form-item label="试用期时间">
                  <span v-if="isExamine == false">
                    <span
                      v-if="examineForm.probationStartDate">{{examineForm.probationStartDate }}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{examineForm.probationEndDate }}</span>
                  </span>
                  <span v-if="isExamine == true">
                    <el-date-picker style="width:300px;" size="mini" v-model="probationDate" value-format="yyyy-MM-dd" format="yyyy-MM-dd" type="daterange" clearable
                      unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" @input="choiceDatePicker"></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-items">
                <el-form-item label="试用期工资">
                  <span v-if="isExamine == false">{{examineForm.probationSalary}}{{examineForm.probationSalaryUnitName}}</span>

                  <span v-if="isExamine == true">
                    <el-input size="mini" v-model="examineForm.probationSalary" clearable placeholder="请输入工资" maxlength="10">
                      <el-select size="mini" style="width:85px;" v-model="examineForm.probationSalaryUnit" placeholder="请选择" slot="append" clearable>
                        <el-option v-for="item in salaryOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                      </el-select>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-itemE">
                <el-form-item label="转正时间">
                  <span v-if="isExamine == false">
                    <span>{{examineForm.formalDate }}</span>
                  </span>
                  <span v-if="isExamine == true">
                    <el-date-picker size="mini" v-model="examineForm.formalDate" value-format="yyyy-MM-dd" type="date" clearable
                      placeholder="请选择面试时间"></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
             
              <el-col class="form-items">
                <el-form-item label="转正后工资">
                  <span v-if="isExamine == false">{{examineForm.formalSalary}}{{examineForm.formalSalaryUnitName}}</span>
                  <span v-if="isExamine == true">
                    <el-input size="mini" v-model="examineForm.formalSalary" clearable placeholder="请输入工资" maxlength="10">
                      <el-select style="width:85px;" v-model="examineForm.formalSalaryUnit" placeholder="请选择" slot="append" clearable>
                        <el-option v-for="item in salaryOptions" :key="item.value" :label="item.name" :value="item.value"></el-option>
                      </el-select>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-itemE">
                <el-form-item label="所属区域">
                  <span v-if="isExamine == false">{{examineForm.accommodationDistrict }}</span>
                  <span v-if="isExamine == true">
                    <el-input size="mini" v-model="examineForm.accommodationDistrict" placeholder="请输入所属区域"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-items">
                <el-form-item label="备注">
                  <span v-if="isExamine == false">{{examineForm.remark }}</span>
                  <span v-if="isExamine == true">
                    <el-input size="mini" type="textarea" class="remark-style" clearable v-model="examineForm.remark" placeholder="请输入备注"
                      resize="none" rows="4" show-word-limit maxlength="100"></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-itemUpload">
                <el-form-item label="简历上传">
                  <span v-if="isExamine == false">
                    <span v-if="briefFileList.length>0">
                      <el-col v-for="(item,index) of briefFileList" :key="index">
                        <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                          {{item.name}}
                          <i class="el-icon-view"></i>
                        </el-link>
                      </el-col>
                    </span>
                  </span>
                  <span v-if="isExamine == true">
                    <el-upload ref="uploadBrief" :class="{hideBrief:hideBriefUpload}" :action="actionUrl" :on-remove="removeBriefList"
                      :on-success="handleBriefChange" :disabled="uploadDisabled" multiple :limit="limitBrief" :file-list="briefFileList">
                      <el-button size="mini" :disabled="uploadDisabled" type="primary">点击上传</el-button>
                    </el-upload>
                  </span>
                </el-form-item>
              </el-col>
            </el-form>
          </el-row>
        </div>
      </div>
      <div class="main-right">
        <div id="nav-fixed" :class="{nav_fixed : isFixed}">
          <el-button type="text" @click="jump('basicForm')" icon="el-icon-s-opportunity" circle>基本信息</el-button>
          <br />
          <el-button type="text" @click="jump('educationForm')" icon="el-icon-s-opportunity" circle>教育情况</el-button>
          <br />
          <el-button type="text" @click="jump('workExpForm')" icon="el-icon-s-opportunity" circle>工作经历</el-button>
          <br />
          <el-button type="text" @click="jump('professionalForm')" icon="el-icon-s-opportunity" circle>专业资格或资质名称</el-button>
          <br />
          <!-- <el-button type="text" @click="jump('familyStatusForm')" icon="el-icon-s-opportunity" circle>家庭状况</el-button>
          <br /> -->
          <el-button type="text" @click="jump('reviewForm')" icon="el-icon-s-opportunity" circle>审核</el-button>
          <br />
        </div>
      </div>
    </div>
    <!-- 查看详情操作弹窗 -->
    <el-dialog title="人脸识别结果" :visible.sync="faceModal">
      <el-table :header-cell-style="{background:'#FAFAFA',color:'#606266'}" stripe :data="checkInfo" highlight-current-row v-loading="listLoading"
        element-loading-text="拼命加载中" style="width: 700px;">
        <el-table-column prop="checkItem" label="查询项目" width="400"></el-table-column>
        <el-table-column prop="checkResult" label="核查结果" width="150"></el-table-column>
        <el-table-column prop="checkStatus" label="核查状态" width="150">
          <template slot-scope="scope">
            <span v-if="scope.row.checkStatus =='1'">
              <i class="el-icon-success i-success"></i>
            </span>
            <span v-else-if="scope.row.checkStatus =='2'">
              <i class="el-icon-warning i-warning"></i>
            </span>
            <span v-else-if="scope.row.checkStatus =='3'">
              <i class="el-icon-remove i-remove"></i>
            </span>
            <span v-else-if="scope.row.checkStatus =='4'">
              <i class="el-icon-error i-error"></i>
            </span>
          </template>
        </el-table-column>
      </el-table>
      <el-table :header-cell-style="{background:'#FAFAFA',color:'#606266'}" :data="reportInfo" style="width: 100%">
        <el-table-column prop="queryDate" label="查询日期" width="250"></el-table-column>
        <el-table-column prop="pdfUrl" label="查询详情" align="right">
          <template slot-scope="scope">
            <span v-if="scope.row.pdfUrl != ''">
              <el-button size="text" @click="handleSee(scope.row.pdfUrl)">查看详情</el-button>
            </span>
          </template>
        </el-table-column>
      </el-table>
      <el-row style="padding:10px;line-height:35px;color:#9B9C9E">
        <span style="font-weight:bold;">备注:</span>
        <el-col>
          <i class="el-icon-success i-success"></i> 代表调查项目结果“属实”，无风险
        </el-col>
        <el-col>
          <i class="el-icon-warning i-warning"></i> 代表调查项目结果“部分有差异或存在疑似风险”，属于中低等风险，建议适当关注
        </el-col>
        <el-col>
          <i class="el-icon-remove i-remove"></i> 代表调查项目无法评估风险，建议关注报告实际内容
        </el-col>
        <el-col>
          <i class="el-icon-error i-error"></i> 代表调查项目结果“存在较严重问题或虚假”，属于高等风险，建议务必关注
        </el-col>
      </el-row>
      <div style="text-align:center;padding:20px 0;">
        <el-button type="primary" @click="faceModal = false" style="width:150px;">确定</el-button>
      </div>
    </el-dialog>
    <!-- 导入人脸识别信息弹窗 -->
    <el-dialog title="导入人脸识别信息" :visible.sync="faceDialog" @close="resetForm" width="800px">
      <el-form :inline="true" :rules="faceRules" ref="formFace" :model="formFace" label-width="80px">
        <el-col :span="24" style="margin:20px 0;">
          <el-form-item label="身份证号" prop="idCard">
            <el-input size="mini" v-model="formFace.idCard" clearable placeholder="请输入身份证号" maxlength="18"></el-input>
          </el-form-item>
          <el-form-item label="姓名" prop="idCardName">
            <el-input size="mini" v-model="formFace.idCardName" clearable placeholder="请输入姓名"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button size="mini" type="primary" style="margin-left:40px;" icon="el-icon-search" @click="importRecruit(1)">查询</el-button>
          </el-form-item>
        </el-col>
        <el-table :data="faceData" element-loading-text="拼命加载中" highlight-current-row stripe v-loading="listLoading">
          <el-table-column prop="idCardName" label="姓名" min-width="120"></el-table-column>
          <el-table-column prop="idCard" label="身份证号码" min-width="250"></el-table-column>
          <el-table-column label="操作" min-width="150">
            <template slot-scope="scope">
              <el-button type="text" @click="importDataFace(scope.row.idCard)">导入人脸识别信息</el-button>
            </template>
          </el-table-column>
        </el-table>
        <!--分页-->
        <el-row style="margin-top:20px">
          <pagination v-if="formFace.totalCount>0" :total="formFace.totalCount" :page.sync="formFace.pageNum" :limit.sync="formFace.pageSize"
            @pagination="pageChange" />
        </el-row>
      </el-form>
    </el-dialog>
    <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
      <org-select v-on:listenTochildEvent="getCurrentNode" />
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import TableUpload from "components/tableUpload";
import { changeYMD } from "utils";
import AdressRecruit from "components/AdressRecruit";
import { findEhrPositionList } from "api/customerManagement";
import { findValueBySetCode, findAddressDictList } from "api/common/index.js";
import { getPartnerManagementList } from "api/partnerManagement/index.js";
import { querySupplier } from "@/api/supplierManagement/supplierManagement.js";
import {
  insertRecruit,
  editRecruitReview,
  editRecruit,
  findEhrOrg,
  findStaff,
  getSurveyDetailByIdCard,
  findSurveyList,
  getRecruitDetailByCode,
  insertRecruitEducation,
  editRecruitEducation,
  deleteRecruitEducation,
  findRecruitEducationList,
  findRecruitWorkExperienceList,
  insertRecruitWorkExperience,
  editRecruitWorkExperience,
  deleteRecruitWorkExperience,
  deleteProfessionalQualification,
  insertProfessionalQualification,
  editProfessionalQualification,
  findProfessionalQualificationList,
  findRecruitFamilyList,
  editRecruitFamily,
  insertRecruitFamily,
  deleteRecruitFamily
} from "api/recruitmentManagement/index.js";
import {
  validateTel,
  validateIdCard,
  validateAge,
  isMoney,
  chineseName,
  validateBirthDay
} from "@/utils/validate";

export default {
  data() {
    return {
      tagName: "新增招聘信息",
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      // actionUrl: " http://47.103.49.186/api/" + "fsk-system/common/fileUpload",
      //保存按钮加载
      loadingBtn: false,
      importDisabled: false,
      isOrg: false,
      // 是否编辑模式
      isEdit: true,
      isExamine: true,
      isDisabled: false,
      isShow: true,
      hideBriefUpload: false,
      limitBrief: 10,
      isShowExamine: true,
      // editShow: false,
      //人脸识别弹窗
      faceModal: false,
      //导入人脸识别信息弹窗
      faceDialog: false,
      listLoading: false,
      isStaff: true,
      isSupplier: false,
      staffDisabled: true,
      faceData: [],
      totalCount: 0,
      formFace: {
        pageNum: 1,
        pageSize: 10,
        totalCount: 0,
        idCard: "",
        idCardName: ""
      },
      uploadDisabled: true,
      //动态加载户籍省市区
      // houseOptions: [],
      house: [],
      houseName: [],
      //动态加载本市地址省市区
      liveOptions: [],
      live: [],
      liveName: [],
      //详情字段
      detailForm: {},
      faceRules: {},
      checkInfo: [
        {
          checkItem: "身份证实名信息校验",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "户籍信息",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "法院民事诉讼及失信记录查询",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "负面社会安全记录查询",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "信贷逾期",
          checkResult: "",
          checkStatus: ""
        }
      ],
      reportInfo: [
        {
          queryDate: "",
          pdfUrl: ""
        }
      ],
      //加载loading
      listLoading: false,
      currentIndex: 0,
      /*
       *
       * 基本信息Form
       * 验证
       *
       *
       */
      backgroundOptions: [],
      basicFormRules: {
        recruitFullName: [
          {
            type: "string",
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        recruitBirthday: [
          {
            required: false,
            message: "请选择出生年月",
            trigger: "change"
          },
          {
            validator: validateBirthDay
          }
        ],
        recruitGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        recruitAge: [
          {
            required: true,
            message: "请输入年龄",
            trigger: "change"
          },
          { validator: validateAge }
        ],
        recommendSource: [
          {
            required: true,
            message: "请选择推荐来源",
            trigger: "change"
          }
        ],
        interviewDate: [
          {
            required: true,
            message: "请输入面试时间",
            trigger: "blur"
          }
        ],
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        recruitEducation:[
          {
            required: true,
            message: "请选择最高学历",
            trigger: "change"
          }
        ],
         recruitBelong:[
          {
            required: true,
            message: "请选择员工归属",
            trigger: "change"
          }
        ],
        positionName: [
          {
            required: true,
            message: "请输入岗位",
            trigger: "change"
          }
        ],
        graduatedSchool: [
          {
            required: true,
            message: "请输入毕业院校",
            trigger: "blur"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "blur"
          }
        ],
        recommendName: [
          {
            required: true,
            message: "请选择推荐人",
            trigger: "blur"
          }
        ],
        houseDetailAddress: [
          {
            required: true,
            message: "请输入户籍详细地址",
            trigger: "blur"
          }
        ],
        houseProvinceCode: [
          {
            required: true,
            message: "请选择户籍地址",
            trigger: "change"
          }
        ],
        liveProvinceName: [
          {
            required: true,
            message: "请选择现居住地址",
            trigger: "change"
          }
        ],
        idCard: [
          {
            required: true,
            message: "请输入身份证号码",
            trigger: "blur"
          },
          {
            required: true,
            trigger: "blur",
            validator: validateIdCard
          }
        ],
        recruitTel: [
          {
            required: true,
            message: "请输入手机号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        backgroundCheckStatus: [
          {
            required: true,
            message: "请选择",
            trigger: "change"
          }
        ]
      },
      // timeDefaultShow: new Date("1950-01"),
      basicForm: {
        orgCode: "",
        orgName: "",
        recruitBelong:'10',
        specialtiesList:[]
      },
      probationDate: [],
      examineForm: {
        probationSalaryUnit: "30",
        formalSalaryUnit: "30"
      },
      isHireOptions: [],
      isWorkOptions: [],
      detailObj: {},
      /*
       *
       * 教育情况
       * 验证
       *
       *
       */
      //教育证书上传
      resumeList: [],
      resumeId: "",
      educationForm: {
        //验证
        rules: {
          startDate: [
            {
              required: true,
              // message: "请选择开始时间",
              trigger: "blur"
            }
          ],
          endDate: [
            {
              required: true,
              // message: "请选择结束时间",
              trigger: "blur"
            }
          ],
          schoolName: [
            {
              required: true,
              message: "请输入学校",
              trigger: "blur"
            }
          ],
          major: [
            {
              required: true,
              message: "请输入专业",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      //加载loading
      educationListLoading: false,
      /*
       *
       * 工作经历
       * 验证
       *
       *
       */
      workExpForm: {
        //验证
        rules: {
          startDate: [
            {
              required: true,
              // message: "请选择开始时间",
              trigger: "blur"
            }
          ],
          endDate: [
            {
              required: true,
              // message: "请选择结束时间",
              trigger: "blur"
            }
          ],
          companyName: [
            {
              required: true,
              message: "请输入工作单位",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      //加载loading
      workExpListLoading: false,
      /*
       *
       * 专业资格
       * 验证
       *
       *
       */
      //加载loading
      professionalListLoading: false,
      //专业资格上传证书
      professionalList: [],
      professionalForm: {
        //验证
        rules: {
          professionalQualification: [
            {
              required: true,
              message: "请输入专业资格或资质名称",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      /*
       *
       * 家庭状况
       * 验证
       *
       *
       */
      familyStatusForm: {
        //验证
        rules: {
          familyMemberName: [
            {
              required: true,
              message: "请输入姓名",
              trigger: "blur"
            }
          ],
          relationShip: [
            {
              required: true,
              message: "请输入关系",
              trigger: "blur"
            }
          ],
          contactsTel: [
            {
              required: true,
              message: "请输入联系电话",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      //加载loading
      familyStatusListLoading: false,
      //简历上传
      briefFileList: [],
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      sexOptions: [],
      //婚姻
      MarriageOptions: [],
      //最高学历
      highestEductionOptions: [],
      //城镇户口
      townOptions: [],
      //在合作商岗位
      partnerPostOptions: [],
      //是否缴纳社保
      securityOptions: [],
      //身体状况
      bodyOptions: [],
      //健康证
      healthyOptions: [],
      //公积金
      accumulationOptions: [],
      //信仰
      faithOptions: [],
      //薪资单位
      salaryOptions: [],
      //现在状况
      presentOptions: [],
      //是否持证本人所有
      whetherOptions: [],
      //是否犯罪
      crimeOptions: [],
      //员工归属
      staffOwnershipOptions: [],
      //推荐来源
      recommendOptions: [],
      //信仰
      religiousOptions: [],
      //在职状态
      zzStatusOptions: [],
      //员工归属
      staffOwnershipOptions: [],
      //服务年限
      serviceYearsOptions: [],
      //证书等级
      certificateLevelOptions: [],
      //老人能否自理
      isCareOptions: [],
      IsRecommend: false,
      isFixed: false,
      offsetTop: 0,
      /**
       *
       * 页面传参
       *
       */
      RecruitCode: "",
      dialogVisible: false,
      //合作商
      cooperations: [],
      //岗位选择
      position: [],
      //员工选择
      staffPositionList: [],
      //供作商选择
      supplierPositionList: [],
      recommendCodeStaff: "",
      recommendCodeSupplier: "",
      recommendCodeOrg: "",
      orgPositionList: [],
      majorOptions:[
      ],
      isMajor:false
    };
  },
  components: {
    HeadTag,
    Pagination,
    TableUpload,
    AdressRecruit,
    OrgSelect
  },
  methods: {
    /**
     *
     * 模糊查询
     *
     */
    //合作商模糊查询
    selectCooperationName(item) {
      if (item.value !== "无") {
        this.basicForm.cooperationCode = item.code;
        this.basicForm.cooperationName = item.value;
      } else {
        this.basicForm.cooperationName = "";
      }
    },
    removeCooperationCode() {
      this.basicForm.cooperationCode = "";
    },
    queryCooperationName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          cooperationName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          cooperationName: queryString
        };
      }
      getPartnerManagementList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.cooperations = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.cooperations.push({
                value: data[i].cooperationName,
                code: data[i].cooperationCode
              });
            }
            var results = this.cooperations;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //岗位模糊查询
    selectPositionName(item, index) {
      if (item.value !== "无") {
        this.basicForm.positionCode = item.code;
        this.basicForm.positionName = item.value;
      } else {
        this.basicForm.positionName = "";
      }
    },
    removePositionCode(index) {
      this.basicForm.positionCode = "";
    },
    blurPositionName(){
      if(!this.basicForm.positionCode){
        this.basicForm.positionName = "";
      }
    },
    queryPositionName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.position = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.position.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.position;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //供应商列表
    querySupplierName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          supplierName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          supplierName: queryString
        };
      }
      querySupplier(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.supplierPositionList = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.supplierPositionList.push({
                value: data[i].supplierName,
                code: data[i].supplierCode
              });
            }
            var results = this.supplierPositionList;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //专业特长
    selectMajor(val){
     if(val.length == 0){
        this.isMajor=false;
      }
       this.isMajor=false;
        val.forEach((v)=>
          {
            if(v=="其他"){
                this.isMajor=true;
              }
          }
      )
      this.basicForm.specialtiesList=val
    },
    removeTag(val){
      if(val=="其他"){
        this.isMajor = false;
        this.basicForm.specialtiesDesc='' 
      }
    },
    //供应商传Name
    selectSupplierName(item) {
      if (item.value !== "无") {
        this.basicForm.supplierCode = item.code;
        this.basicForm.supplierName = item.value;
      } else {
        this.basicForm.supplierName = "";
        this.recommendCodeSupplier = "";
      }
    },
    removeSupplierCode() {
      this.basicForm.supplierCode = "";
    },
    //内部组织列表
    queryOrgName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          orgName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          orgName: queryString
        };
      }
      findEhrOrg(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.orgPositionList = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.orgPositionList.push({
                value: data[i].orgName,
                code: data[i].orgCode
              });
            }
            var results = this.orgPositionList;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //供应商传Name
    selectisOrgName(item) {
      if (item.value !== "无") {
        this.basicForm.internalOrgCode = item.code;
        this.basicForm.internalOrg = item.value;
      } else {
        this.basicForm.internalOrg = "";
        this.recommendCodeOrg = "";
      }
    },
    removeOrgCode() {
      this.basicForm.internalOrgCode = "";
      this.basicForm.internalOrg = "";
    },

    selectSupplier(val) {
      if (val == "10") {
        this.isStaff = true;
        this.isSupplier = false;
        this.isOrg = false;
        this.staffDisabled = false;
        this.recommendCodeSupplier = "";
        this.recommendCodeOrg = "";
      } else if (val == "20") {
        this.staffDisabled = false;
        this.isStaff = false;
        this.isOrg = false;
        this.isSupplier = true;
        this.recommendCodeOrg = "";
        this.recommendCodeStaff = "";
        this.IsRecommend = false;
        this.basicForm.recommendOrgName = "";
        this.basicForm.recommendOrgCode = "";
      } else if (val == "30") {
        this.staffDisabled = false;
        this.isOrg = true;
        this.isSupplier = false;
        this.isStaff = false;
        this.recommendCodeSupplier = "";
        this.recommendCodeStaff = "";
        this.IsRecommend = false;
        this.basicForm.recommendOrgName = "";
        this.basicForm.recommendOrgCode = "";
      }
    },
    /**
     *
     * 返回员工管理列表
     *
     */
    returnRecrutiList() {
      this.$router.push({
        path: "/personnelManagement/recruitManagement"
      });
    },
    //员工模糊查询
    selectStaffName(item) {
      this.IsRecommend = true;
      if (item.value !== "无") {
        this.basicForm.staffCode = item.code;
        this.basicForm.staffName = item.value;
        this.basicForm.staffTel = item.staffTel;
        this.basicForm.recommendOrgName = item.recommendOrgName;
        this.basicForm.recommendOrgCode = item.recommendOrgCode;
      } else {
        this.basicForm.staffName = "";
        this.recommendCodeStaff = "";
      }
    },
    removeStaffCode() {
      this.basicForm.staffCode = "";
      this.basicForm.staffName = "";
    },
    queryStaffName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          staffFullName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          staffFullName: queryString
        };
      }
      findStaff(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.staffPositionList = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.staffPositionList.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel,
                recommendOrgName: data[i].orgName,
                recommendOrgCode: data[i].orgCode
              });
            }
            var results = this.staffPositionList;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //获取数据字典
    initDataDictionary() {
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.sexOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "RECRUIT_MARITAL_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.MarriageOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "EHR_EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.highestEductionOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.townOptions = response.data.responseData;
            this.securityOptions = response.data.responseData;
            this.accumulationOptions = response.data.responseData;
            this.whetherOptions = response.data.responseData;
            this.crimeOptions = response.data.responseData;
            this.healthyOptions = response.data.responseData;
            this.backgroundOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "COOPERATION_POSTS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.partnerPostOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "PHYSICAL_CONDITION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.bodyOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "WORK_CONDITION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.presentOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "STAFF_BELONG" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffOwnershipOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "RECOMMEND_SOURCE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.recommendOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "SALARY_UNIT" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.salaryOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "IS_HIRE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isHireOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "IS_WORK" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isWorkOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "IS_PROVIDE_ONESELF" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isCareOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "WORK_YEARS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.serviceYearsOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      findValueBySetCode({ valueSetCode: "CERTIFICATE_LEVEL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.certificateLevelOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
         findValueBySetCode({ valueSetCode: "RECRUIT_SPECIALTIES" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.majorOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    //证书等级
    changeCertificateLevel(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.certificateLevelOptions.find(item => {
        return item.value === val;
      });
      this.professionalForm.tableData[this.currentIndex].certificateLevel =
        obj.value;
      this.professionalForm.tableData[this.currentIndex].certificateLevelValue =
        obj.name;
    },
    //根据身份证获取年龄信息
    GetAge(identityCard) {
      var len = (identityCard + "").length;
      if (len == 0) {
        return 0;
      } else {
        if (len != 15 && len != 18) {
          //身份证号码只能为15位或18位其它不合法
          return 0;
        }
      }
      var strBirthday = "";
      if (len == 18) {
        //处理18位的身份证号码从号码中得到生日和性别代码
        strBirthday =
          identityCard.substr(6, 4) +
          "/" +
          identityCard.substr(10, 2) +
          "/" +
          identityCard.substr(12, 2);
      }
      if (len == 15) {
        strBirthday =
          "19" +
          identityCard.substr(6, 2) +
          "/" +
          identityCard.substr(8, 2) +
          "/" +
          identityCard.substr(10, 2);
      }
      //时间字符串里，必须是“/”
      var birthDate = new Date(strBirthday);
      var nowDateTime = new Date();
      var age = nowDateTime.getFullYear() - birthDate.getFullYear();
      //再考虑月、天的因素;.getMonth()获取的是从0开始的，这里进行比较，不需要加1
      if (
        nowDateTime.getMonth() < birthDate.getMonth() ||
        (nowDateTime.getMonth() == birthDate.getMonth() &&
          nowDateTime.getDate() < birthDate.getDate())
      ) {
        age--;
      }
      return age;
    },
    /**
     *
     * 查询条件开窗选择组织
     *
     */
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(val) {
      this.basicForm.orgCode = val.orgCode;
      this.basicForm.orgName = val.orgName;
      this.handleClose();
    },
    //清空组织过滤
    clearOrgCode() {
      this.basicForm.orgName = "";
      this.basicForm.orgCode = "";
    },
    /**
     *
     * 基本信息保存
     *
     */
    saveBasic(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$refs.houseAddress.$refs["addressForm"].validate(valid => {
            if (valid) {
              this.$refs.liveAddress.$refs["addressForm"].validate(valid => {
                if (valid) {
                  if (this.basicForm.positionCode == "") {
                    this.basicForm.positionName = "";
                    this.$message.error("输入的岗位不存在");
                    this.$refs.basicForm.validateField("positionName");
                  }
                  if (this.basicForm.internalOrgCode == "") {
                    this.basicForm.internalOrg = "";
                  }
                  if (this.basicForm.cooperationCode == "") {
                    this.basicForm.cooperationName = "";
                  }
                  if (this.basicForm.staffCode == "") {
                    this.basicForm.staffName = "";
                  }
                  if (this.basicForm.supplierCode == "") {
                    this.basicForm.supplierName = "";
                  }
                  this.basicForm.formalSalaryUnit = "30";
                  this.basicForm.probationSalaryUnit = "30";
                  this.loadingBtn = true;
                  if (this.basicForm.id && this.basicForm.recruitCode) {
                    if (
                      this.recommendCodeStaff !== "" ||
                      this.recommendCodeSupplier !== "" ||
                      this.recommendCodeOrg !== ""
                    ) {
                      editRecruit(this.basicForm)
                        .then(response => {
                          if (response.data.statusCode == 200) {
                            this.$message.success("修改成功");
                            this.getRecruitDetailByCode(
                              this.basicForm.recruitCode
                            );
                            this.loadingBtn = false;
                            this.isEdit = false;
                            this.isShow = false;
                          } else {
                            this.$message.error(response.data.statusMsg);
                            this.loadingBtn = false;
                            return false;
                          }
                        })
                        .catch(error => {
                          console.log("editRecruit:" + error);
                          this.$message.error(response.data.statusMsg);
                          this.loadingBtn = false;
                          return false;
                        });
                    } else {
                      this.$message.error("推荐人不能为空");
                      this.loadingBtn = false;
                      return false;
                    }
                  } else {
                    if (this.basicForm.positionCode == "") {
                      this.basicForm.positionName = "";
                      this.$message.error("输入的岗位不存在");
                      this.$refs.basicForm.validateField("positionName");
                    }
                    if (this.basicForm.internalOrgCode == "") {
                      this.basicForm.internalOrg = "";
                    }
                    if (this.basicForm.cooperationCode == "") {
                      this.basicForm.cooperationName = "";
                    }
                    if (this.basicForm.staffCode == "") {
                      this.basicForm.staffName = "";
                    }
                    if (this.basicForm.supplierCode == "") {
                      this.basicForm.supplierName = "";
                    }
                    this.basicForm.formalSalaryUnit = "30";
                    this.basicForm.probationSalaryUnit = "30";
                    if (
                      this.recommendCodeStaff !== "" ||
                      this.recommendCodeSupplier !== "" ||
                      this.recommendCodeOrg !== ""
                    ) {
                      insertRecruit(this.basicForm)
                        .then(response => {
                          if (response.data.statusCode == "200") {
                            this.$message.success("新增成功");
                            this.getRecruitDetailByCode(
                              response.data.responseData
                            );
                            this.loadingBtn = false;
                            this.isEdit = false;
                            this.isShow = false;
                            this.uploadDisabled = false;
                            this.importDisabled = true;
                          } else {
                            this.$message.error(response.data.statusMsg);
                            this.loadingBtn = false;
                            return false;
                          }
                        })
                        .catch(error => {
                          console.log(error);
                          this.$message.error(response.data.statusMsg);
                          this.loadingBtn = false;
                          return false;
                        });
                    } else {
                      this.$message.error("推荐人不能为空");
                      this.loadingBtn = false;
                      return false;
                    }
                  }
                } else {
                  this.$message.error("请检查是否填写完整");
                  return false;
                }
              });
            } else {
              this.$message.error("请检查是否填写完整");
              return false;
            }
          });
        } else {
          this.$message.error("请检查是否填写完整");
          console.log("error submit!!");
          return false;
        }
      });
    },

    //审核
    examineFormSave() {
      if (this.basicForm.id && this.basicForm.recruitCode) {
        if (this.probationDate == null) {
          this.examineForm.probationStartDate = null;
          this.examineForm.probationEndDate = null;
        }
        this.loadingBtn = true;
        editRecruitReview(this.examineForm)
          .then(response => {
            if (response.data.statusCode == "200") {
              this.$message.success("操作成功");
              this.getRecruitDetailByCode(this.basicForm.recruitCode);
              this.loadingBtn = false;
              this.isExamine = false;
              this.isShowExamine = false;
            } else {
              this.$message.error("操作失败");
              this.loadingBtn = false;
              return false;
            }
          })
          .catch(error => {
            console.log(error);
            this.$message.error(response.data.statusMsg);
            this.loadingBtn = false;
            return false;
          });
      } else {
        this.$message.error("请先保存基本信息");
        return false;
      }
    },
    /**
     *
     * 基本信息修改
     *
     */
    editForm() {
      if (this.basicForm.recommendSource == "10") {
        this.IsRecommend = true;
      }
      if(this.basicForm.specialtiesList){
         this.isMajor=false;
        if(this.basicForm.specialtiesList.length>0){
            this.basicForm.specialtiesList.forEach((item)=>{
                  if(item=="其他"){
                    this.isMajor=true;
                  }
            })
        }
      }
      this.importDisabled = false;
      this.isEdit = true;
      this.isShow = true;
      this.getRecruitDetailByCode(this.basicForm.recruitCode);
    },
    // 审核修改
    examineEdit() {
      this.importDisabled = false;
      this.isExamine = true;
      this.isShowExamine = true;
      this.getRecruitDetailByCode(this.basicForm.recruitCode);
    },
    //查询招聘基本信息详情
    getRecruitDetailByCode(code) {
      this.briefFileList = [];
      var params = {
        recruitCode: code
      };
      getRecruitDetailByCode(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.basicForm = response.data.responseData; //基本信息详情
            this.examineForm = response.data.responseData; // 审核详情
            //基本信息详情
            if (this.basicForm.reportDate) {
              this.basicForm.reportDate = changeYMD(this.basicForm.reportDate);
            }
            if (this.basicForm.physicalCheckDate) {
              this.basicForm.physicalCheckDate = changeYMD(
                this.basicForm.physicalCheckDate
              );
            }
            if (this.basicForm.interviewDate) {
              this.basicForm.interviewDate = changeYMD(
                this.basicForm.interviewDate
              );
            }
            if (this.basicForm.backgroundCheckStatus) {
              this.basicForm.backgroundCheckStatus = this.basicForm.backgroundCheckStatus;
            }
            if (this.basicForm.recommendSource) {
              if (this.basicForm.recommendSource == "10") {
                this.isSupplier = false;
                this.isOrg = false;
                this.isStaff = true;
                this.recommendCodeSupplier = "";
                this.recommendCodeOrg = "";
                this.recommendCodeStaff = this.basicForm.recommendName;
                this.basicForm.staffCode =
                  response.data.responseData.recommendCode;
                this.basicForm.staffName =
                  response.data.responseData.recommendName;
                this.basicForm.recommendOrgCode =
                  response.data.responseData.recommendOrgCode;
                this.basicForm.recommendOrgName =
                  response.data.responseData.recommendOrgName;
              } else if (this.basicForm.recommendSource == "20") {
                this.isSupplier = true;
                this.isStaff = false;
                this.isOrg = false;
                this.recommendCodeStaff = "";
                this.recommendCodeOrg = "";
                this.recommendCodeSupplier = this.basicForm.recommendName;
                this.basicForm.supplierCode =
                  response.data.responseData.recommendCode;
                this.basicForm.supplierName =
                  response.data.responseData.recommendName;
              } else if (this.basicForm.recommendSource == "30") {
                this.isSupplier = false;
                this.isStaff = false;
                this.isOrg = true;
                this.recommendCodeOrg = this.basicForm.recommendName;
                this.basicForm.internalOrgCode =
                  response.data.responseData.recommendCode;
                this.basicForm.internalOrg =
                  response.data.responseData.recommendName;
              }
            }
            //简历详情
            if (this.examineForm.curriculumVitae) {
              let obj = response.data.responseData.curriculumVitae;
              let temp = obj.split(",");
              for (let i = 0; i < temp.length; i++) {
                let url = temp[i];
                this.briefFileList.push({
                  url: url,
                  name: decodeURI(url)
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18)
                });
              }
            }
            // 审核详情
            if (this.examineForm.workDate) {
              this.examineForm.workDate = changeYMD(this.examineForm.workDate);
            }
            if (this.examineForm.formalDate) {
              this.examineForm.formalDate = changeYMD(
                this.examineForm.formalDate
              );
            }
            if (this.examineForm.probationStartDate == undefined) {
              this.examineForm.probationStartDate = "";
            } else {
              this.examineForm.probationStartDate = changeYMD(
                this.examineForm.probationStartDate
              );
            }
            if (this.examineForm.probationEndDate == undefined) {
              this.examineForm.probationEndDate = "";
            } else {
              this.examineForm.probationEndDate = changeYMD(
                this.examineForm.probationEndDate
              );
            }
            this.probationDate = [
              new Date(this.examineForm.probationStartDate),
              new Date(this.examineForm.probationEndDate)
            ];
            if (this.examineForm.formalSalaryUnit == undefined) {
              this.examineForm.formalSalaryUnit = "30";
            } else {
              this.examineForm.formalSalaryUnit = this.examineForm.formalSalaryUnit;
            }
            if (this.examineForm.probationSalaryUnit == undefined) {
              this.examineForm.probationSalaryUnit = "30";
            } else {
              this.examineForm.probationSalaryUnit = this.examineForm.probationSalaryUnit;
            }
          }
        })
        .catch(error => {
          return false;
        });
    },
    //背景查询
    importFace(val) {
      let params = {
        idCard: val
      };
      getSurveyDetailByIdCard(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            if (response.data.responseData) {
              this.faceModal = true;
              this.detailObj = response.data.responseData;
              this.checkInfo[0].checkResult = this.detailObj.realNameResult;
              this.checkInfo[0].checkStatus = this.detailObj.realNameStatus;
              this.checkInfo[1].checkResult = this.detailObj.censusRegisterResult;
              this.checkInfo[1].checkStatus = this.detailObj.censusRegisterStatus;
              this.checkInfo[2].checkResult = this.detailObj.litigationResult;
              this.checkInfo[2].checkStatus = this.detailObj.litigationStatus;
              this.checkInfo[3].checkResult = this.detailObj.negativeRecordResult;
              this.checkInfo[3].checkStatus = this.detailObj.negativeRecordStatus;
              this.checkInfo[4].checkResult = this.detailObj.creditOverdueResult;
              this.checkInfo[4].checkStatus = this.detailObj.creditOverdueStatus;
              this.reportInfo[0].queryDate = this.detailObj.createDate;
              this.reportInfo[0].pdfUrl = this.detailObj.pdfUrl;
            } else {
              this.$message.error("暂无人脸识别信息");
              return false;
            }
          } else {
            this.$message.error("暂无人脸识别信息");
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
    //获取试用期开始结束时间
    choiceDatePicker(item) {
      this.$nextTick(() => {
        this.examineForm.probationStartDate = this.probationDate[0];
        this.examineForm.probationEndDate = this.probationDate[1];
        this.$refs.examineForm.validate(valid => {});
      });
      // }
    },
    //查看详情操作
    btnDetail() {
      this.importFace(this.basicForm.idCard);
    },
    handleSee(url) {
      window.open(url, "_blank");
    },
    //打开导入人脸识别弹窗
    openRecruitDialog() {
      this.faceDialog = true;
      this.importRecruit(1);
    },
    //关闭弹窗事件
    resetForm() {
      this.$refs.formFace.resetFields();
    },
    //导入人脸识别信息列表
    importRecruit(page) {
      this.listLoading = true;
      this.formFace.pageNum = page;
      findSurveyList(this.formFace)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faceData = response.data.responseData;
            this.formFace.totalCount = response.data.totalCount;
          }
          this.listLoading = false;
        })
        .catch(error => {
          console.log(error);
        });
    },
    //父组件触发事件
    pageChange(val) {
      this.formFace.page = val.page;
      this.formFace.pageSize = val.limit;
      this.importRecruit(val.page); //改变页码，重新渲染页面
    },
    importDataFace(val) {
      this.faceDialog = true;
      const loading = this.$loading({
        lock: true,
        text: "导入中...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.5)"
      });
      let params = {
        idCard: val
      };
      getSurveyDetailByIdCard(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            if (response.data.responseData) {
              this.$message.success("导入成功");
              this.detailObj = response.data.responseData;
              const data = response.data.responseData;
              const form = {
                recruitFullName: data.idCardName,
                idCardAddress: data.idCardAddress,
                nativePlace: data.nativePlace,
                idCard: data.idCard,
                recruitAge: this.GetAge(data.idCard),
                recruitBirthday: data.birthday,
                recruitGender: data.gender,
                orgCode: this.basicForm.orgCode,
                orgName: this.basicForm.orgName,
                houseProvinceCode: this.basicForm.houseProvinceCode,
                houseProvinceName: this.basicForm.houseProvinceName,
                houseCityCode: this.basicForm.houseCityCode,
                houseCityName: this.basicForm.houseCityName,
                houseDistrictCode: this.basicForm.houseDistrictCode,
                houseDistrictName: this.basicForm.houseDistrictName,
                houseDetailAddress: this.basicForm.houseDetailAddress,
                liveProvinceCode: this.basicForm.liveProvinceCode,
                liveProvinceName: this.basicForm.liveProvinceName,
                liveCityCode: this.basicForm.liveCityCode,
                liveCityName: this.basicForm.liveCityName,
                liveDistrictCode: this.basicForm.liveDistrictCode,
                liveDistrictName: this.basicForm.liveDistrictName,
                liveDetailAddress: this.basicForm.liveDetailAddress,
                graduatedSchool: this.basicForm.graduatedSchool,
                maritalStatus: this.basicForm.maritalStatus,
                isUrbanRegistration: this.basicForm.isUrbanRegistration,
                recruitEmail: this.basicForm.recruitEmail,
                recruitTel: this.basicForm.recruitTel,
                isSocialSecurity: this.basicForm.isSocialSecurity,
                isSelfCertificate: this.basicForm.isSelfCertificate,
                positionCode: this.basicForm.positionCode,
                positionName: this.basicForm.positionName,
                recruitEducation: this.basicForm.recruitEducation,
                recruitHeight: this.basicForm.recruitHeight,
                liveDistrictName: this.basicForm.liveDistrictName,
                postalCode: this.basicForm.postalCode,
                interviewDate: this.basicForm.interviewDate,
                physicalCheckDate: this.basicForm.physicalCheckDate,
                physicalCondition: this.basicForm.physicalCondition,
                cooperationCode: this.basicForm.cooperationCode,
                cooperationPosition: this.basicForm.cooperationPosition,
                cooperationName: this.basicForm.cooperationName,
                recommendSource: this.basicForm.recommendSource,
                isCycle: this.basicForm.isCycle,
                reportDate: this.basicForm.reportDate,
                isAcceptHome: this.basicForm.isAcceptHome,
                isNeedAccommodation: this.basicForm.isNeedAccommodation,
                recruitFaith: this.basicForm.recruitFaith,
                workCondition: this.basicForm.workCondition,
                isHealthCertificate: this.basicForm.isHealthCertificate,
                isHousingFund: this.basicForm.isHousingFund,
                isSelfCertificate: this.basicForm.isSelfCertificate,
                liveDetailAddress: this.basicForm.liveDetailAddress,
                isCrime: this.basicForm.isCrime,
                recruitBelong: this.basicForm.recruitBelong,
                houseDetailAddress: this.basicForm.houseDetailAddress,
                backgroundCheckStatus: this.basicForm.backgroundCheckStatus,
                recruitCode: this.basicForm.recruitCode
              };
              this.basicForm = form;
              // this.$refs[
              //   "houseList"
              // ].inputValue = this.basicForm.houseDistrictName;
              // this.$refs[
              //   "liveList"
              // ].inputValue = this.basicForm.liveDistrictName;
            }
          }
          loading.close();
          this.faceDialog = false;
        })
        .catch(error => {
          console.log(error);
        });
    },

    /**
     *
     * 教育情况列表操作
     *
     */
    //教育情况列表返回数据
    getDducationList(code) {
      let params = {
        recruitCode: code
      };
      this.educationListLoading = true;
      findRecruitEducationList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationForm.tableData = response.data.responseData;
            if (this.educationForm.tableData.length > 0) {
              this.$set(this.educationForm.tableData[i], "urlList", []);
              var arr = this.educationForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                if (arr[i].startDate) {
                  arr[i].startDate = changeYMD(arr[i].startDate);
                }
                if (arr[i].endDate) {
                  arr[i].endDate = changeYMD(arr[i].endDate);
                }
              }
              if (arr[i].certificateUrl) {
                let obj = arr[i].certificateUrl;
                let temp = obj.split(",");
                for (let j = 0; j < temp.length; j++) {
                  let url = temp[j];
                  this.educationForm.tableData[i].urlList.push({
                    url: url,
                    name: decodeURI(url)
                      .toString()
                      .split("com/")[1]
                      .split("?Expires")[0]
                      .substr(18)
                  });
                }
              }
            }
            this.educationListLoading = false;
          } else {
            this.$message.error("操作失败");
            this.educationListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.educationListLoading = false;
          return false;
        });
    },

    // 编辑
    handleEditEducationForm($index, row) {
      this.$set(this.educationForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveEducationForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.educationForm.tableData[$index].id) {
            let params = {
              id: this.educationForm.tableData[$index].id,
              recruitCode: this.basicForm.recruitCode,
              schoolName: this.educationForm.tableData[$index].schoolName,
              major: this.educationForm.tableData[$index].major,
              certificateName: this.educationForm.tableData[$index]
                .certificateName,
              certificateUrl: this.educationForm.tableData[$index]
                .certificateUrl,
              startDate: this.educationForm.tableData[$index].startDate,
              endDate: this.educationForm.tableData[$index].endDate,
              urlList: this.educationForm.tableData[$index].urlList
            };
            editRecruitEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.educationForm.tableData[$index].id = currentData.id;
                  this.educationForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.educationForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.educationForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.educationForm.tableData[$index].schoolName =
                    currentData.schoolName;
                  this.educationForm.tableData[$index].major =
                    currentData.major;
                  this.educationForm.tableData[$index].certificateName =
                    currentData.certificateName;
                  this.educationForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.$set(
                    this.educationForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
              });
          } else {
            var params = {
              recruitCode: this.basicForm.recruitCode,
              schoolName: this.educationForm.tableData[$index].schoolName,
              major: this.educationForm.tableData[$index].major,
              certificateName: this.educationForm.tableData[$index]
                .certificateName,
              certificateUrl: this.educationForm.tableData[$index]
                .certificateUrl,
              startDate: this.educationForm.tableData[$index].startDate,
              endDate: this.educationForm.tableData[$index].endDate,
              urlList: this.educationForm.tableData[$index].urlList
            };
            insertRecruitEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.educationForm.tableData[$index].id = currentData.id;
                  this.educationForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.educationForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.educationForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.educationForm.tableData[$index].schoolName =
                    currentData.schoolName;
                  this.educationForm.tableData[$index].major =
                    currentData.major;
                  this.educationForm.tableData[$index].certificateName =
                    currentData.certificateName;
                  this.educationForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.$set(
                    this.educationForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
                return false;
              });
          }
        } else {
          console.log("保存失败");
          return false;
        }
      });
    },
    // 删除
    handleDeleteEducationForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.educationForm.tableData[$index].id) {
            var params = {
              recruitCode: this.basicForm.recruitCode,
              id: this.educationForm.tableData[$index].id
            };
            deleteRecruitEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.educationForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteRecruitEducation:" + error);
                return false;
              });
          } else {
            this.educationForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //证件上传回调地址
    getResumeUrl(response, file, fileList, index) {
      if (response) {
        this.educationForm.tableData[index].urlList = [];
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let certificateUrl = "";
        urls.forEach(items => {
          certificateUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (certificateUrl.length > 0) {
          certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
        }
        this.educationForm.tableData[index].certificateUrl = certificateUrl;
        //回显当前行文件
        let temp = certificateUrl.split(",");
        for (let i = 0; i < temp.length; i++) {
          let url = temp[i];
          this.educationForm.tableData[index].urlList.push({
            url: url,
            name: decodeURI(url)
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18)
          });
        }
      }
    },
    //删除文件
    removeResumeList(file, inputFileMainList, indexLine) {
      let urls = [];
      inputFileMainList.forEach(item => {
        if (item) {
          urls.push(item.url);
        }
      });
      let certificateUrl = "";
      urls.forEach(url => {
        certificateUrl += url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (certificateUrl.length > 0) {
        certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
      }
      this.educationForm.tableData[indexLine].certificateUrl = certificateUrl;
      //回显当前行文件
      this.educationForm.tableData[indexLine].urlList = [];
      let temp = certificateUrl.split(",");
      for (let i = 0; i < temp.length; i++) {
        let url = temp[i];
        this.educationForm.tableData[indexLine].urlList.push({
          url: url,
          name: decodeURI(url)
            .toString()
            .split("com/")[1]
            .split("?Expires")[0]
            .substr(18)
        });
      }
    },
    // 新增一条教育情况数据
    addEducationForm(formName) {
      if (this.basicForm.recruitCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.educationForm.tableData = this.educationForm.tableData || [];
            this.educationForm.tableData.push({
              schoolName: null,
              major: null,
              certificateName: null,
              certificateUrl: null,
              startDate: null,
              endDate: null,
              urlList: [],
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存基本信息后再操作");
        return false;
      }
    },
    /**
     *
     * 工作经历列表操作
     *
     */
    //工作列表返回数据
    getWorkExperienceList(code) {
      let params = {
        recruitCode: code
      };
      this.workExpListLoading = true;
      findRecruitWorkExperienceList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.workExpForm.tableData = response.data.responseData;
            if (this.workExpForm.tableData.length > 0) {
              var arr = this.workExpForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                if (arr[i].startDate) {
                  arr[i].startDate = changeYMD(arr[i].startDate);
                }
                if (arr[i].endDate) {
                  arr[i].endDate = changeYMD(arr[i].endDate);
                }
              }
            }

            this.workExpListLoading = false;
          } else {
            this.$message.error("操作失败");
            this.workExpListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          return false;
        });
    },
    // 新增一条工作经历数据
    addWorkExpForm(formName) {
      if (this.basicForm.recruitCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.workExpForm.tableData = this.workExpForm.tableData || [];
            this.workExpForm.tableData.push({
              recruitCode: null,
              companyName: null,
              lastPosition: null,
              salary: null,
              leaveReason: null,
              workEmployer: null,
              relationship: null,
              contactsTel: null,
              workYears: null,
              isProvideOneself: null,
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存基本信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteWorkExpForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.workExpForm.tableData[$index].id) {
            var params = {
              recruitCode: this.basicForm.recruitCode,
              id: this.workExpForm.tableData[$index].id
            };
            deleteRecruitWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.workExpForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteRecruitWorkExperience:" + error);
                return false;
              });
          } else {
            this.workExpForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    // 编辑
    handleEditWorkExpForm($index, row) {
      this.$set(this.workExpForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveWorkExpForm($index, row, formName) {
      this.$refs[formName].validate((valid, model) => {
        if (valid) {
          if (this.workExpForm.tableData[$index].id) {
            let params = {
              id: this.workExpForm.tableData[$index].id,
              recruitCode: this.basicForm.recruitCode,
              companyName: this.workExpForm.tableData[$index].companyName,
              lastPosition: this.workExpForm.tableData[$index].lastPosition,
              salary: this.workExpForm.tableData[$index].salary,
              leaveReason: this.workExpForm.tableData[$index].leaveReason,
              workEmployer: this.workExpForm.tableData[$index].workEmployer,
              relationship: this.workExpForm.tableData[$index].relationship,
              contactsTel: this.workExpForm.tableData[$index].contactsTel,
              workYears: this.workExpForm.tableData[$index].workYears,
              isProvideOneself: this.workExpForm.tableData[$index]
                .isProvideOneself,
              isProvideOneselfValue: this.workExpForm.tableData[$index]
                .isProvideOneselfValue,
              workYearsValue: this.workExpForm.tableData[$index].workYearsValue,
              startDate: this.workExpForm.tableData[$index].startDate,
              endDate: this.workExpForm.tableData[$index].endDate
            };
            editRecruitWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.workExpForm.tableData[$index].id = currentData.id;
                  this.workExpForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.workExpForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.workExpForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.workExpForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.workExpForm.tableData[$index].lastPosition =
                    currentData.lastPosition;
                  this.workExpForm.tableData[$index].salary =
                    currentData.salary;
                  this.workExpForm.tableData[$index].leaveReason =
                    currentData.leaveReason;
                  this.workExpForm.tableData[$index].workEmployer =
                    currentData.workEmployer;
                  this.workExpForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.workExpForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].workYears =
                    currentData.workYears;
                  this.workExpForm.tableData[$index].workYearsValue =
                    currentData.workYearsValue;
                  this.workExpForm.tableData[$index].isProvideOneself =
                    currentData.isProvideOneself;
                  this.workExpForm.tableData[$index].isProvideOneselfValue =
                    currentData.isProvideOneselfValue ;
                  this.$set(
                    this.workExpForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
              });
          } else {
            let params = {
              recruitCode: this.basicForm.recruitCode,
              companyName: this.workExpForm.tableData[$index].companyName,
              lastPosition: this.workExpForm.tableData[$index].lastPosition,
              salary: this.workExpForm.tableData[$index].salary,
              leaveReason: this.workExpForm.tableData[$index].leaveReason,
              workEmployer: this.workExpForm.tableData[$index].workEmployer,
              relationship: this.workExpForm.tableData[$index].relationship,
              contactsTel: this.workExpForm.tableData[$index].contactsTel,
              workYears: this.workExpForm.tableData[$index].workYears,
              isProvideOneself: this.workExpForm.tableData[$index]
                .isProvideOneself,
              startDate: this.workExpForm.tableData[$index].startDate,
              endDate: this.workExpForm.tableData[$index].endDate,
              isProvideOneselfValue: this.workExpForm.tableData[$index]
                .isProvideOneselfValue,
              workYearsValue: this.workExpForm.tableData[$index].workYearsValue
            };
            insertRecruitWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.workExpForm.tableData[$index].id = currentData.id;
                  this.workExpForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.workExpForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.workExpForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.workExpForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.workExpForm.tableData[$index].lastPosition =
                    currentData.lastPosition;
                  this.workExpForm.tableData[$index].salary =
                    currentData.salary;
                  this.workExpForm.tableData[$index].leaveReason =
                    currentData.leaveReason;
                  this.workExpForm.tableData[$index].workEmployer =
                    currentData.workEmployer;
                  this.workExpForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.workExpForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].workYears =
                    currentData.workYears;
                  this.workExpForm.tableData[$index].workYearsValue =
                    currentData.workYearsValue;
                  this.workExpForm.tableData[$index].isProvideOneself =
                    currentData.isProvideOneself;
                  this.workExpForm.tableData[$index].isProvideOneselfValue =
                    currentData.isProvideOneselfValue;
                  this.$set(
                    this.workExpForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);

                  return false;
                }
              })
              .catch(error => {
                console.log(error);
                return false;
              });
          }
        } else {
          console.log("保存失败");
          return false;
        }
      });
    },
    //服务年限
    changeWorkYears(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.serviceYearsOptions.find(item => {
        return item.value === val;
      });
      this.workExpForm.tableData[this.currentIndex].workYears = obj.value;
      this.workExpForm.tableData[this.currentIndex].workYearsValue = obj.name;
    },
    //老人能否自理
    changeIsProvideOneself(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.isCareOptions.find(item => {
        return item.value === val;
      });
      this.workExpForm.tableData[this.currentIndex].isProvideOneself =
        obj.value;
      this.workExpForm.tableData[this.currentIndex].isProvideOneselfValue =
        obj.name;
    },
    /**
     *
     * 专业资格列表操作
     *
     */
    //专业资格列表数据
    getProfessionalList(code) {
      let params = {
        recruitCode: code
      };
      this.professionalListLoading = true;
      findProfessionalQualificationList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.professionalForm.tableData = response.data.responseData;
            if (this.professionalForm.tableData.length > 0) {
              var arr = this.professionalForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                this.$set(this.professionalForm.tableData[i], "certList", []);
                if (arr[i].issueDate) {
                  arr[i].issueDate = changeYMD(arr[i].issueDate);
                }
                if (arr[i].certificateUrl) {
                  let obj = arr[i].certificateUrl;
                  let temp = obj.split(",");
                  for (let j = 0; j < temp.length; j++) {
                    let url = temp[j];
                    this.professionalForm.tableData[i].certList.push({
                      url: url,
                      name: decodeURI(url)
                        .toString()
                        .split("com/")[1]
                        .split("?Expires")[0]
                        .substr(18)
                    });
                  }
                }
              }
            }
            this.professionalListLoading = false;
          } else {
            this.$message.error("操作失败");
            this.professionalListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.educationListLoading = false;
          return false;
        });
    },
    //证件上传回调地址
    getProfessionalUrl(response, file, fileList, index) {
      if (response) {
        this.professionalForm.tableData[index].certList = [];
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let certificateUrl = "";
        urls.forEach(items => {
          certificateUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (certificateUrl.length > 0) {
          certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
        }
        this.professionalForm.tableData[index].certificateUrl = certificateUrl;
        //回显当前行文件
        let temp = certificateUrl.split(",");
        for (let i = 0; i < temp.length; i++) {
          let url = temp[i];
          this.professionalForm.tableData[index].certList.push({
            url: url,
            name: decodeURI(url)
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18)
          });
        }
      }
    },
    //删除文件
    removeProfessionalList(file, inputFileMainList, indexLine) {
      let urls = [];
      inputFileMainList.forEach(item => {
        if (item) {
          urls.push(item.url);
        }
      });
      let certificateUrl = "";
      urls.forEach(url => {
        certificateUrl += url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (certificateUrl.length > 0) {
        certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
      }
      this.professionalForm.tableData[
        indexLine
      ].certificateUrl = certificateUrl;
      //回显当前行文件
      this.professionalForm.tableData[indexLine].certList = [];
      let temp = certificateUrl.split(",");
      for (let i = 0; i < temp.length; i++) {
        let url = temp[i];
        this.professionalForm.tableData[indexLine].certList.push({
          url: url,
          name: decodeURI(url)
            .toString()
            .split("com/")[1]
            .split("?Expires")[0]
            .substr(18)
        });
      }
    },
    // 编辑
    handleEditMajorQualForm($index, row) {
      this.$set(this.professionalForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveMajorQualForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.professionalForm.tableData[$index].id) {
            let params = {
              id: this.professionalForm.tableData[$index].id,
              recruitCode: this.basicForm.recruitCode,
              professionalQualification: this.professionalForm.tableData[$index]
                .professionalQualification,
              issueAuthority: this.professionalForm.tableData[$index]
                .issueAuthority,
              remark: this.professionalForm.tableData[$index].remark,
              issueDate:
                this.professionalForm.tableData[$index].issueDate == null
                  ? ""
                  : changeYMD(
                      this.professionalForm.tableData[$index].issueDate
                    ),
              certificateUrl: this.professionalForm.tableData[$index]
                .certificateUrl,
              certificateLevel: this.professionalForm.tableData[$index]
                .certificateLevel,
              certificateLevelValue: this.professionalForm.tableData[$index]
                .certificateLevelValue
            };

            editProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.professionalForm.tableData[$index].id = currentData.id;
                  this.professionalForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.professionalForm.tableData[
                    $index
                  ].professionalQualification =
                    currentData.professionalQualification;
                  this.professionalForm.tableData[$index].issueAuthority =
                    currentData.issueAuthority;
                  this.professionalForm.tableData[$index].issueDate == null
                    ? ""
                    : changeYMD(currentData.issueDate);
                  this.professionalForm.tableData[$index].certificateLevel =
                    currentData.certificateLevel;
                  this.professionalForm.tableData[
                    $index
                  ].certificateLevelValue = currentData.certificateLevelValue;
                  this.professionalForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.professionalForm.tableData[$index].remark =
                    currentData.remark;
                  this.$set(
                    this.professionalForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
              });
          } else {
            let params = {
              recruitCode: this.basicForm.recruitCode,
              professionalQualification: this.professionalForm.tableData[$index]
                .professionalQualification,
              issueAuthority: this.professionalForm.tableData[$index]
                .issueAuthority,
              issueDate: this.professionalForm.tableData[$index].issueDate,
              certificateUrl: this.professionalForm.tableData[$index]
                .certificateUrl,
              certificateLevel: this.professionalForm.tableData[$index]
                .certificateLevel,
              remark: this.professionalForm.tableData[$index].remark,
              certificateLevelValue: this.professionalForm.tableData[$index]
                .certificateLevelValue
            };
            insertProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.professionalForm.tableData[$index].id = currentData.id;
                  this.professionalForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.professionalForm.tableData[
                    $index
                  ].professionalQualification =
                    currentData.professionalQualification;
                  this.professionalForm.tableData[$index].remark =
                    currentData.remark;
                  this.professionalForm.tableData[$index].issueAuthority =
                    currentData.issueAuthority;
                  this.professionalForm.tableData[$index].issueDate == null
                    ? ""
                    : changeYMD(currentData.issueDate);
                  this.professionalForm.tableData[$index].certificateLevel =
                    currentData.certificateLevel;
                  this.professionalForm.tableData[
                    $index
                  ].certificateLevelValue = currentData.certificateLevelValue;
                  this.professionalForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.$set(
                    this.professionalForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条专业资格数据
    addMajorQualForm(formName) {
      if (this.basicForm.recruitCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            if (this.professionalForm.tableData.length > 0) {
              this.professionalForm.tableData =
                this.professionalForm.tableData || [];
              this.professionalForm.tableData.push({
                professionalQualification: null,
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateLevelValue: null,
                certificateUrl: null,
                remark: null,
                certList: [],
                editing: true
              });
            } else {
              this.professionalForm.tableData.push({
                professionalQualification: "医疗照护证",
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateUrl: null,
                certificateLevelValue: null,
                remark: null,
                certList: [],
                editing: true
              });
              this.professionalForm.tableData.push({
                professionalQualification: "护士资格证",
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateUrl: null,
                certificateLevelValue: null,
                remark: null,
                certList: [],
                editing: true
              });
              this.professionalForm.tableData.push({
                professionalQualification: "护师资格证",
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateUrl: null,
                certificateLevelValue: null,
                remark: null,
                certList: [],
                editing: true
              });
              this.professionalForm.tableData.push({
                professionalQualification: "主管护师资格证",
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateUrl: null,
                certificateLevelValue: null,
                remark: null,
                certList: [],
                editing: true
              });
              this.professionalForm.tableData.push({
                professionalQualification: "养老护理员资格证",
                issueAuthority: null,
                issueDate: null,
                certificateLevel: null,
                certificateUrl: null,
                certificateLevelValue: null,
                remark: null,
                certList: [],
                editing: true
              });
            }
          }
        });
      } else {
        this.$message.error("请先保存信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteMajorQualForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.professionalForm.tableData[$index].id) {
            var params = {
              recruitCode: this.basicForm.recruitCode,
              id: this.professionalForm.tableData[$index].id
            };
            deleteProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.professionalForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteRecruitEducation:" + error);
                return false;
              });
          } else {
            this.professionalForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    /**
     *
     * 家庭状况列表操作
     *
     */
    //家庭情况列表数据
    getFamilyList(code) {
      let params = {
        recruitCode: code
      };
      this.familyStatusListLoading = true;
      findRecruitFamilyList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.familyStatusForm.tableData = response.data.responseData;
            this.familyStatusListLoading = false;
          } else {
            this.$message.error("操作失败");
            this.familyStatusListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.familyStatusListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditFamilyStatusForm($index, row) {
      this.$set(this.familyStatusForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveFamilyStatusForm($index, row, formName) {
      this.$refs[formName].validate((valid, model) => {
        if (valid) {
          if (this.familyStatusForm.tableData[$index].id) {
            let params = {
              id: this.familyStatusForm.tableData[$index].id,
              recruitCode: this.basicForm.recruitCode,
              familyMemberName: this.familyStatusForm.tableData[$index]
                .familyMemberName,
              companyName: this.familyStatusForm.tableData[$index].companyName,
              position: this.familyStatusForm.tableData[$index].position,
              contactsTel: this.familyStatusForm.tableData[$index].contactsTel,
              relationship: this.familyStatusForm.tableData[$index].relationship
            };
            editRecruitFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.familyStatusForm.tableData[$index].id = currentData.id;
                  this.familyStatusForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.familyStatusForm.tableData[$index].familyMemberName =
                    currentData.familyMemberName;
                  this.familyStatusForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.familyStatusForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.familyStatusForm.tableData[$index].position =
                    currentData.position;
                  this.familyStatusForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.$set(
                    this.familyStatusForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
              });
          } else {
            let params = {
              recruitCode: this.basicForm.recruitCode,
              familyMemberName: this.familyStatusForm.tableData[$index]
                .familyMemberName,
              companyName: this.familyStatusForm.tableData[$index].companyName,
              position: this.familyStatusForm.tableData[$index].position,
              contactsTel: this.familyStatusForm.tableData[$index].contactsTel,
              relationship: this.familyStatusForm.tableData[$index].relationship
            };
            insertRecruitFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.familyStatusForm.tableData[$index].id = currentData.id;
                  this.familyStatusForm.tableData[$index].recruitCode =
                    currentData.recruitCode;
                  this.familyStatusForm.tableData[$index].familyMemberName =
                    currentData.familyMemberName;
                  this.familyStatusForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.familyStatusForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.familyStatusForm.tableData[$index].position =
                    currentData.position;
                  this.familyStatusForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.$set(
                    this.familyStatusForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log(error);
                return false;
              });
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 新增家庭情况
    addFamilyStatusForm(formName) {
      if (this.basicForm.recruitCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.familyStatusForm.tableData =
              this.familyStatusForm.tableData || [];
            this.familyStatusForm.tableData.push({
              familyMemberName: null,
              relationship: null,
              companyName: null,
              position: null,
              contactsTel: null,
              recruitCode: null,
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存基本信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteFamilyStatusForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.familyStatusForm.tableData[$index].id) {
            var params = {
              recruitCode: this.basicForm.recruitCode,
              id: this.familyStatusForm.tableData[$index].id
            };
            deleteRecruitFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.familyStatusForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteRecruitFamily:" + error);
                return false;
              });
          } else {
            this.familyStatusForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //简历上传
    handleBriefChange(response, file, fileList) {
      if (response) {
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let curriculumVitae = "";
        urls.forEach(items => {
          curriculumVitae += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (curriculumVitae.length > 0) {
          curriculumVitae = curriculumVitae.substr(
            0,
            curriculumVitae.length - 1
          );
        }
        this.examineForm.curriculumVitae = curriculumVitae;
      }
    },
    removeBriefList(file, inputFileMainList) {
      let fileList = this.briefFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1); //删除选中的元素,this.briefFileList返回剩余的元素;
      let curriculumVitae = "";
      this.briefFileList.forEach(items => {
        curriculumVitae += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (curriculumVitae.length > 0) {
        curriculumVitae = curriculumVitae.substr(0, curriculumVitae.length - 1);
      }
      this.examineForm.curriculumVitae = curriculumVitae;
    },
    /**
     *
     * 锚点跳转
     *
     */
    jump(domId) {
      //获取头部是否固定
      let headerFlag = this.$store.state.settings.fixedHeader;

      // 当前窗口正中心位置到指定dom位置的距离

      //页面滚动了的距离
      let height =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      //指定dom到页面顶端的距离
      let dom = document.getElementById(domId);
      let domHeight;

      if (headerFlag) {
        domHeight = dom.offsetTop - 60;
      } else {
        domHeight = dom.offsetTop + 40;
      }

      //滚动距离计算
      var S = Number(height) - Number(domHeight);

      //判断上滚还是下滚
      if (S < 0) {
        //下滚
        S = Math.abs(S);
        window.scrollBy({ top: S, behavior: "smooth" });
      } else if (S == 0) {
        //不滚
        window.scrollBy({ top: 0, behavior: "smooth" });
      } else {
        //上滚
        S = -S;
        window.scrollBy({ top: S, behavior: "smooth" });
      }
    },
    // 滚动监听  滚动触发的效果写在这里
    handleScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop >= this.offsetTop) {
        this.isFixed = true;
      } else {
        this.isFixed = false;
      }
    },
    //加载户籍省市区
    selectedHouseProvinceListener(obj) {
      this.basicForm.houseProvinceName = obj.provinceName;
      this.basicForm.houseProvinceCode = obj.provinceCode;
      this.basicForm.houseCityName = "";
      this.basicForm.houseCityCode = "";
      this.basicForm.houseDistrictName = "";
      this.basicForm.houseDistrictCode = "";
    },
    selectedHouseCityListener(obj) {
      this.basicForm.houseCityName = obj.cityName;
      this.basicForm.houseCityCode = obj.cityCode;
      this.basicForm.houseDistrictName = "";
      this.basicForm.houseDistrictCode = "";
    },
    selectedHouseDistrictListener(obj) {
      this.basicForm.houseDistrictName = obj.districtName;
      this.basicForm.houseDistrictCode = obj.districtCode;
    },
    //加载本市地址省市区
    selectedLiveProvinceListener(obj) {
      this.basicForm.liveProvinceName = obj.provinceName;
      this.basicForm.liveProvinceCode = obj.provinceCode;
      this.basicForm.liveCityName = "";
      this.basicForm.liveCityCode = "";
      this.basicForm.liveDistrictName = "";
      this.basicForm.liveDistrictCode = "";
    },
    selectedLiveCityListener(obj) {
      this.basicForm.liveCityName = obj.cityName;
      this.basicForm.liveCityCode = obj.cityCode;
      this.basicForm.liveDistrictName = "";
      this.basicForm.liveDistrictCode = "";
    },
    selectedLiveDistrictListener(obj) {
      this.basicForm.liveDistrictName = obj.districtName;
      this.basicForm.liveDistrictCode = obj.districtCode;
    }
    //加载户籍省市区
    // getHouseNodes(val) {
    //   let idArea;
    //   let sizeArea;
    //   if (!val) {
    //     idArea = 0;
    //     sizeArea = 0;
    //   } else if (val.length === 1) {
    //     idArea = val[0];
    //     sizeArea = val.length; //一级
    //   } else if (val.length === 2) {
    //     idArea = val[1];
    //     sizeArea = val.length; //二级
    //   }
    //   let params = {
    //     pid: idArea
    //   };
    //   findAddressDictList(params).then(
    //     response => {
    //       let Items = response.data.responseData;
    //       if (sizeArea === 0) {
    //         this.houseOptions = Items.map((value, i) => {
    //           return {
    //             id: value.id,
    //             name: value.name,
    //             cities: []
    //           };
    //         });
    //       } else if (sizeArea === 1) {
    //         // 点击一级 加载二级 市
    //         this.houseOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             if (!value.cities.length) {
    //               value.cities = Items.map((value, i) => {
    //                 return {
    //                   id: value.id,
    //                   name: value.name,
    //                   cities: []
    //                 };
    //               });
    //             }
    //           }
    //         });
    //       } else if (sizeArea === 2) {
    //         // 点击二级 加载三级 区
    //         this.houseOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             value.cities.map((value, i) => {
    //               if (value.id === val[1]) {
    //                 if (!value.cities.length) {
    //                   Items.pop();
    //                   value.cities = Items.map((value, i) => {
    //                     return {
    //                       id: value.id,
    //                       name: value.name
    //                     };
    //                   });
    //                 }
    //               }
    //             });
    //           }
    //         });
    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }
    //   );
    // },
    //户籍选择下拉框
    // handleExpandChangeHouse(val) {
    //   this.getHouseNodes(val);
    // },
    // //将户籍省市区注入到Form中
    // addHouseToForm(val) {
    //   this.house = val;
    //   this.houseName = this.$refs["houseList"].getCheckedNodes();
    //   this.basicForm.houseProvinceCode = this.house[0];
    //   this.basicForm.houseProvinceName = this.houseName[0].pathLabels[0];
    //   this.basicForm.houseCityCode = this.house[1];
    //   this.basicForm.houseCityName = this.houseName[0].pathLabels[1];
    //   this.basicForm.houseDistrictCode = this.house[2];
    //   this.basicForm.houseDistrictName = this.houseName[0].pathLabels[2];
    // },
    // changeHouse(val) {
    //   this.$refs["houseList"].presentText = "";
    //   if (!val) {
    //     this.$refs["houseList"].inputValue = this.basicForm.houseDistrictName;
    //     this.$refs["houseList"].presentText = this.basicForm.houseDistrictName;
    //   }
    // },
    //加载本市地址省市区
    // getLiveNodes(val) {
    //   let idArea;
    //   let sizeArea;
    //   if (!val) {
    //     idArea = 0;
    //     sizeArea = 0;
    //   } else if (val.length === 1) {
    //     idArea = val[0];
    //     sizeArea = val.length; //一级
    //   } else if (val.length === 2) {
    //     idArea = val[1];
    //     sizeArea = val.length; //二级
    //   }
    //   let params = {
    //     pid: idArea
    //   };
    //   findAddressDictList(params).then(
    //     response => {
    //       let Items = response.data.responseData;
    //       if (sizeArea === 0) {
    //         this.liveOptions = Items.map((value, i) => {
    //           return {
    //             id: value.id,
    //             name: value.name,
    //             cities: []
    //           };
    //         });
    //       } else if (sizeArea === 1) {
    //         // 点击一级 加载二级 市
    //         this.liveOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             if (!value.cities.length) {
    //               value.cities = Items.map((value, i) => {
    //                 return {
    //                   id: value.id,
    //                   name: value.name,
    //                   cities: []
    //                 };
    //               });
    //             }
    //           }
    //         });
    //       } else if (sizeArea === 2) {
    //         // 点击二级 加载三级 区
    //         this.liveOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             value.cities.map((value, i) => {
    //               if (value.id === val[1]) {
    //                 if (!value.cities.length) {
    //                   Items.pop();
    //                   value.cities = Items.map((value, i) => {
    //                     return {
    //                       id: value.id,
    //                       name: value.name
    //                     };
    //                   });
    //                 }
    //               }
    //             });
    //           }
    //         });
    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }
    //   );
    // },
    // //本市地址选择下拉框
    // handleExpandChangeLive(val) {
    //   this.getLiveNodes(val);
    // },
    // //将本市地址省市区注入到Form中
    // addLiveToForm(val) {
    //   this.live = val;
    //   this.liveName = this.$refs["liveList"].getCheckedNodes();
    //   this.basicForm.liveProvinceCode = this.live[0];
    //   this.basicForm.liveProvinceName = this.liveName[0].pathLabels[0];
    //   this.basicForm.liveCityCode = this.live[1];
    //   this.basicForm.liveCityName = this.liveName[0].pathLabels[1];
    //   this.basicForm.liveDistrictCode = this.live[2];
    //   this.basicForm.liveDistrictName = this.liveName[0].pathLabels[2];
    // },
    // changeLive(val) {
    //   this.$refs["liveList"].presentText = "";
    //   if (!val) {
    //     this.$refs["liveList"].inputValue = this.basicForm.liveDistrictName;
    //     this.$refs["liveList"].presentText = this.basicForm.liveDistrictName;
    //   }
    // }
  },
  created() {
    //获得传入参数
    this.educationForm.tableData = [];
    this.workExpForm.tableData = [];
    this.professionalForm.tableData = [];
    this.familyStatusForm.tableData = [];
    this.initDataDictionary();
    //加载户籍省市区
    // this.getHouseNodes();
    //加载本市地址省市区
    // this.getLiveNodes();
  },
  mounted() {
    // 设置bar浮动阈值为 #fixedBar 至页面顶部的距离
    this.offsetTop = document.querySelector("#nav-fixed").offsetTop;
    // 开启滚动监听
    window.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    // 离开页面 关闭监听 不然会报错
    window.removeEventListener("scroll", this.handleScroll);
  }
};
</script>

<style lang="scss" scoped>
#addRecruit {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
  .form-content .el-form-item {
    margin-bottom: 15px;
  }
}

.main-content {
  width: 100%;
  display: flex;
  .tablePadding {
    padding: 0px 20px;
  }
}
.el-input {
  width: 200px;
}
.form-itemd{
   width: 50%;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    margin: 0px 20px;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.formTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.main-left {
  margin: 0px 0px 0px 20px;
  padding-right: 10px;
  width: calc(100% - 200px);
  float: left;
  min-width: 850px;
  .margin-left-form {
    border-radius: 10px;
    margin-bottom: 10px;
    padding-bottom: 20px;
    background: #fff;
  }
}
.form-content {
  margin: 0px auto;
}
.main-right {
  margin: 0px 20px 0px 10px;
  padding: 10px;
  background: #fff;
  min-width: 200px;
  float: right;
  .vertical-steps {
    height: 500px;
  }
}
.nav_fixed {
  position: fixed;
  margin-top: 60px;
  min-width: 200px;
  z-index: 2;
  top: 0;
}
.i-success {
  color: #0c9905;
  font-size: 15px;
}

.i-warning {
  color: #ebcd25;
  font-size: 15px;
}

.i-remove {
  color: #878787;
  font-size: 15px;
}

.i-error {
  color: #f14848;
  font-size: 15px;
}
.remark-style {
  display: block;
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 400px;
   height: 60px;

}
.form-itemE{
  width: 35%;
	min-width: 400px;
  height: 40px;

}
.form-items{
  width: 40%;
	min-width: 650px;
}
.form-itemUpload{
  width: 35%;
	min-width: 400px;
  height: 50px;

}
.hideBrief .el-upload--picture-card {
  display: none;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
</style>
<style lang="scss">
#addRecruit {
  #nav-fixed .el-button:hover {
    color: #f98c3c;
  }
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}

.form-iteml {
  width: 30%;
  min-width: 400px;
  .el-form-item {
    .el-form-item__label::before {
      content: "*";
      color: #ff4949;
      margin-right: 4px;
    }
  }
}
</style>