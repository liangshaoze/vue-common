<template>
  <div>
    <div style="padding-top:60px;padding-left:5px;padding-right:5px;color:red" v-if="!useable">请在线上口罩预约开放时间段登记，开放时间段为早上8点到下午4点半。</div>
    <div v-if="useable">
        <div style="background:#eee;padding:10px;margin-bottom:10px">
            <div style="text-align:center;font-size:18px;color:green;;margin-bottom:10px">口罩预约登记</div>
            <div style="padding-left:5px;padding-right:5px;color:red">线上口罩预约开放时间段为早上8点到下午4点半。</div>
            <div style="padding:5px;color:red">特别提示，通过本系统取得的预约号，将排在居委现场预约号之后，预约成功后请耐心等待居委的确认通知。</div>
            <div style="padding:5px;">一户（同一个居住地址）只能预约一次，一次只能预约购买一包（5只）口罩。</div>
        </div>
      <div class="form-content">
        <el-form
          :inline="false"
          :model="appointmentForm"
          ref="appointmentForm"
          label-width="120px"
          :rules="rules"
          class="formMain"
        >
          <el-form-item label="所在区" prop="liveDistrictCode" class="form-item">
            <el-select size="mini"
                v-model="appointmentForm.liveDistrictCode"
                placeholder="请选择所在区" 
                @change="queryLiveSubdistricts"
                clearable
              >
                  <el-option  v-for="item in districts" :key="item.code" :label="item.value" :value="item.code"/>
              </el-select>
          </el-form-item>
          <el-form-item label="所在街道" prop="liveSubdistrictCode" class="form-item" >
              <el-select size="mini" 
                v-model="appointmentForm.liveSubdistrictCode" 
                placeholder="请选择所在街道" 
                @change="queryliveNeighborNames"
                clearable
              >
                  <el-option  v-for="item in liveSubdistricts" 
                    :key="item.code" 
                    :label="item.value" 
                    :value="item.code"/>
              </el-select>
          </el-form-item>
           <el-form-item label="所在居委" class="form-item" prop="liveNeighborName" >
            <el-autocomplete
              v-model="appointmentForm.liveNeighborName"
              size="mini"
              clearable
              :fetch-suggestions="queryliveNeighborNames"
              placeholder="请输入所在居委"
              @select="selectLiveNeighborName"
            >
              <template slot-scope="{ item }">
                <el-tooltip
                  class="tooltip-item"
                  effect="dark"
                  :content="item.value"
                  placement="right"
                >
                  <span>{{item.value}}</span>
                </el-tooltip>
              </template>
            </el-autocomplete>
          </el-form-item>
           <el-form-item label="居住地址" prop="liveDetailAddress" class="form-item"> 
            <el-input size="mini" v-model="appointmentForm.liveDetailAddress" placeholder="请输入居住地址" clearable></el-input>
          </el-form-item>
           <el-form-item label="姓名" prop="customerName" class="form-item">
            <el-input size="mini" v-model="appointmentForm.customerName" placeholder="请输入姓名" clearable></el-input>
          </el-form-item>
           <el-form-item label="手机号" prop="customerTel" class="form-item">
            <el-input size="mini" v-model="appointmentForm.customerTel" placeholder="请输入手机号" maxlength="11" clearable></el-input>
          </el-form-item>
           <el-form-item label="身份证号" prop="customerIdCard" class="form-item">
            <el-input size="mini" v-model="appointmentForm.customerIdCard" maxlength="18" placeholder="请输入身份证号" clearable></el-input>
          </el-form-item>
          <el-form-item label="性别" prop="customerGender" class="form-item">
             <el-radio-group v-model="appointmentForm.customerGender">
                <el-radio label="男">男</el-radio>
                <el-radio label="女">女</el-radio>
              </el-radio-group>
          </el-form-item>
          <el-form-item label="是否本市户籍" prop="isNativeHouse" class="form-item">
             <el-radio-group v-model="appointmentForm.isNativeHouse">
                <el-radio label="1">是</el-radio>
                <el-radio label="0">否</el-radio>
              </el-radio-group>
          </el-form-item>
         <div style="text-align:center;padding-bottom:40px" >
                <el-button  @click="submitForm" type="primary" :loading="submitLoading" :disabled="submitDisabled || !useable">提交预约</el-button>
            </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import {insertMaskOrder} from "@/api/maskOrder"
import { findAddressDictList } from "@/api/common/index.js";
import {getAgeFromIdentityCard,getBirthdayFromIdentityCard} from "@/utils"
import {
  validateCellPhone,
  validateIdCard,
} from "@/utils/validate";
export default {
  data() {
    return {
      appointmentForm: {
        liveProvinceCode:"310000",//所在省（固定）
        liveProvinceName:"上海市",//所在省（固定）
        liveCityCode : "310100",//所在市（固定）
        liveCityName : "市辖区",//所在市（固定）
        liveSubdistrictCode:"",
        liveNeighborName:""
      },
      districts: [],
      liveSubdistricts:[],
      liveNeighborNames:[],
      submitLoading:false,
      submitDisabled:false,
      useable:true,
      rules: {
        liveDistrictCode: [
          { required: true, message: "所在区不能为空" }
        ],
        liveSubdistrictCode: [
          { required: true, message: "所在街道不能为空" }
        ],
        liveNeighborName:[
          { required: true, message: "所在居委不能为空" }
        ],
        liveDetailAddress:[
            { required: true, message: "居住地址不能为空" }
        ],
        customerName:[
            { required: true, message: "姓名不能为空" }
        ],
        customerIdCard:[
            { required: true, message: "身份证不能为空" },
            {
              required: true,
              trigger: "blur",
              validator: validateIdCard
            }
        ],
        customerGender:[
            { required: true, message: "性别不能为空" }
        ],
        isNativeHouse:[
            { required: true, message: "是否本市户籍不能为空" }
        ],
        customerTel:[
          { required: true, message: "手机号不能为空" },
          { validator: validateCellPhone }
        ]
      }
    };
  },
  components: {
  },
  methods: {
    submitForm() {
       this.$refs['appointmentForm'].validate(valid => {
        if (valid) {
          this.submitLoading = true;
          this.submitDisabled = true;
          //出生
          this.appointmentForm.customerBirthday = getBirthdayFromIdentityCard(this.appointmentForm.customerIdCard);
          this.appointmentForm.customerAge = getAgeFromIdentityCard(this.appointmentForm.customerIdCard);
          this.appointmentForm.liveDistrictName = this.districts.find(item=>{
            return item.code == this.appointmentForm.liveDistrictCode;
          }).value;//所在区
          this.appointmentForm.liveSubdistrictName = this.liveSubdistricts.find(item=>{
            return item.code == this.appointmentForm.liveSubdistrictCode;
          }).value;//所在街道
          insertMaskOrder(this.appointmentForm)
            .then(response => {
              this.submitLoading = false;
              this.submitDisabled = false;
              if (response.data.statusCode == 200) {
                this.$router.push({
                  path: "/maskOrderResult",
                  query: {
                    success:true,
                    statusMsg: response.data.statusMsg
                  }
                });
              } else {
                this.$router.push({
                  path: "/maskOrderResult",
                  query: {
                    success:false,
                    statusMsg: response.data.statusMsg
                  }
                });
                return false;
              }
            })
            .catch(error => {
              this.submitLoading = false;
              this.submitDisabled = false;
              this.$message.error(this.ConstantData.requestErrorMsg);
            });
        } else {
          this.$message.error("请检查输入是否都已完成");
          return false;
        }
       });
    },
    queryDistrictName(queryString, cb) {
      var params = {
        pageNum: 1,
        pageSize: 100,
        pid: this.appointmentForm.liveCityCode,
        name: ""
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.districts = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.districts.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.districts;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          return false;
        });
    },
    queryLiveSubdistricts(queryString) {
      this.appointmentForm.liveSubdistrictCode = "";
      this.appointmentForm.liveNeighborName = "";
      var params = {
        pageNum: 1,
        pageSize: 100,
        pid: queryString,
        name: ""
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.liveSubdistricts = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.liveSubdistricts.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.liveSubdistricts;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          return false;
        });
    },
    queryliveNeighborNames(queryString,cb){
      if(this.appointmentForm.liveSubdistrictCode == ""){
        cb([])
        return;
      }
        var params = {
        pageNum: 1,
        pageSize: 100,
        pid: this.appointmentForm.liveSubdistrictCode,
        name: queryString
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.liveNeighborNames =[];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.liveNeighborNames.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.liveNeighborNames;
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          return false;
        });
    },
    selectLiveNeighborName(item){
      this.appointmentForm.liveNeighborName = item.value;
    }
  },
  computed: {
    
  },
  mounted(){
    this.queryDistrictName();
    this.useable = true;
    //时间类比较
    var currentTime = new Date();
    var startTime = new Date().getFullYear()+"/"+(new Date().getMonth()+1)+"/"+new Date().getDate()+" 8:00:00";
    startTime = new Date(Date.parse(startTime));
    var endTime =new Date().getFullYear()+"/"+(new Date().getMonth()+1)+"/"+new Date().getDate()+" 16:30:00";
    endTime = new Date(Date.parse(endTime));
    //进行比较
    if(currentTime<startTime||currentTime>endTime){
      this.useable = false;
    }
  },
  created(){
    document.title = "口罩预约登记"
  }
};
</script>

<style lang="scss" scoped>
#person {
  width: 100%;
  height:100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}

.form-content {
  padding: 5px 0px;
}

.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-autocomplete{
  width: 200px;
}
.form-item {
  min-width: 200px;
  padding-bottom: 5px;
  max-height: 40px;
}
</style>
