<template>
  <div>
    <div>
        <div style="background:#fff;padding:60px;text-align:center;" >
            <img v-if="success" src="@/assets/img/chenggong.png" style="max-width:40px;max-height:40px;margin-bottom:20px"/>
            <img v-if="!success" src="@/assets/img/shibai.png" style="max-width:40px;max-height:40px;margin-bottom:20px">
            <div style="color:#666">{{appointResult}}</div>
        </div>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      appointResult: "",
      success:false
    };
  },
  components: {
  },
  methods: {
    
  },
  computed: {
  },
  created(){
    document.title = "提示信息"
    this.appointResult = this.$route.query.statusMsg;
    this.success = this.$route.query.success;
    if(!this.appointResult){
      this.appointResult = "提交失败了，请重新试试~"
    }
  }
};
</script>

<style lang="scss" scoped>
#person {
  width: 100%;
  height:100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}

.form-content {
  padding: 5px 0px;
}

.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  min-width: 200px;
  padding-bottom: 5px;
  max-height: 40px;
}
</style>
