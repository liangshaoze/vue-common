<!--考勤统计-->
<template>
  <div>
    <headTag :tagName="tagName" />
  <div class="filter_wrap">
    <CommonSearchWidget
          @queryMethod="queryMethod"
          :propertyList="searchItems"
          :resultItem="searchModel"
          :ref="setSearchRef('CommonSearchWidget')"
        >
         <el-col class="form-item" slot="append">
            <el-form-item></el-form-item>
         </el-col>
          <el-col class="form-item" slot="append">
            <el-form-item>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                style="margin-left:125px"
                @click="queryData()"
              >查询</el-button>
               <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  v-if="workOrderList.length>0"
                  :loading="exportLoading"
                  :disabled="exportBtnDisabled"
                >导出</el-button>
              <!-- <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button> -->
            </el-form-item>
          </el-col>
        </CommonSearchWidget>
  </div>
    <div class="tableToolbar">
      <div class="tablePanel">
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
          <el-tab-pane label="上月" name="lastMonth">
            <div style="display:flex;justify-content:space-between;padding:10px">
              <div style="display:flex;justify-content:center;align-items:center">
                <span style="margin-right:20px" v-if="workOrderList.length>0">总服务人数:{{personNumber}}</span>
                <span v-if="workOrderList.length>0">本月总计服务人次:{{personCount}}</span>
              </div>
              <div style="float:right;">
                <!-- <el-button type="primary" size="mini" @click="goBack">返回</el-button> -->
                <!-- <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  v-if="workOrderList.length>0"
                >导出考勤</el-button> -->
              </div>
            </div>
            <div
              v-if="workOrderList.length==0"
              v-loading="listLoading"
              style="height:100px;display:flex;justify-content:center;align-items:center;color:#999"
            >{{listLoading?"":"暂无数据"}}</div>
            <el-table
              v-else
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
              size="mini"
              stripe
              :data="workOrderList"
              v-loading="listLoading"
              highlight-current-row
              element-loading-text="拼命加载中"
              show-summary
              :summary-method="getSummaries"
              :max-height="tableMaxHeight"
            >
              <el-table-column
                label="序号"
                type="index"
                show-overflow-tooltip
                width="50"
                align="center"
                fixed="left"
              ></el-table-column>
              <el-table-column label="员工姓名" width="80" prop="careGiverName" fixed="left"></el-table-column>
              <el-table-column label="岗位" min-width="80" prop="servicePositionName" fixed="left"></el-table-column>
              <el-table-column label="星级" min-width="50" prop="staffGrade" fixed="left"></el-table-column>
              <el-table-column label="保底工时" min-width="50" prop="workTime" fixed="left">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.workTime}}</div>
                </template>
              </el-table-column>
              <el-table-column label="住宿" min-width="50" prop="assessGrade"></el-table-column>
              <el-table-column label="商业" min-width="50" prop="assessGrade"></el-table-column>
              <el-table-column label="服务人数" min-width="50" prop="number">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.number}}</div>
                </template>
              </el-table-column>
              <el-table-column label="出勤情况">
                <el-table-column
                  v-for="index in 31"
                  :key="index"
                  :label="index+'日'"
                  :prop="index+''"
                  width="50"
                >
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row[index+'']}}</div>
                </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="本月实际出勤" min-width="50" prop="workOrderCount" fixed="right">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.workOrderCount}}</div>
                </template>
              </el-table-column>
              <el-table-column
                label="本月应出勤"
                prop="companyScanningCount"
                fixed="right"
              >
              <template slot-scope="scope">
                  <div class="text-right">{{scope.row.companyScanningCount}}</div>
              </template>
              </el-table-column>
              <el-table-column label="备注" min-width="100" prop="remark" fixed="right"></el-table-column>
            </el-table>
          </el-tab-pane>
          <el-tab-pane label="当月" name="currentMonth">
            <div style="display:flex;justify-content:space-between;padding:10px">
              <div style="display:flex;justify-content:center;align-items:center">
                <span style="margin-right:20px" v-if="workOrderList.length>0">总服务人数:{{personNumber}}</span>
                <span v-if="workOrderList.length>0">本月总计服务人次:{{personCount}}</span>
              </div>
              <div style="float:right;">
                <!-- <el-button type="primary" size="mini" @click="goBack">返回</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  v-if="workOrderList.length>0"
                >导出考勤</el-button> -->
              </div>
            </div>
            <div
              v-if="workOrderList.length==0"
              v-loading="listLoading"
              style="height:100px;display:flex;justify-content:center;align-items:center;color:#999"
            >{{listLoading?"":"暂无数据"}}</div>
            <el-table
              v-else
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
              size="mini"
              stripe
              :data="workOrderList"
              v-loading="listLoading"
              highlight-current-row
              element-loading-text="拼命加载中"
              show-summary
              :summary-method="getSummaries"
              :max-height="tableMaxHeight"
            >
              <el-table-column
                label="序号"
                type="index"
                show-overflow-tooltip
                width="50"
                align="center"
                fixed="left"
              ></el-table-column>
              <el-table-column label="员工姓名" width="80" prop="careGiverName" fixed="left"></el-table-column>
              <el-table-column label="岗位" min-width="80" prop="servicePositionName" fixed="left"></el-table-column>
              <el-table-column label="星级" min-width="50" prop="staffGrade" fixed="left"></el-table-column>
              <el-table-column label="保底工时" min-width="50" prop="workTime" fixed="left">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.workTime}}</div>
                </template>
              </el-table-column>
              <el-table-column label="住宿" min-width="50" prop="assessGrade"></el-table-column>
              <el-table-column label="商业" min-width="50" prop="assessGrade"></el-table-column>
              <el-table-column label="服务人数" min-width="50" prop="number">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.number}}</div>
                </template>
              </el-table-column>
              <el-table-column label="出勤情况">
                <el-table-column
                  v-for="index in 31"
                  :key="index"
                  :label="index+'日'"
                  :prop="index+''"
                  width="50"
                >
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row[index+'']}}</div>
                </template>
                </el-table-column>
              </el-table-column>
              <el-table-column label="本月实际出勤" min-width="50" prop="workOrderCount" fixed="right">
                <template slot-scope="scope">
                  <div class="text-right">{{scope.row.workOrderCount}}</div>
                </template>
              </el-table-column>
              <el-table-column
                label="本月应出勤"
                prop="companyScanningCount"
                fixed="right"
              >
              <template slot-scope="scope">
                  <div class="text-right">{{scope.row.companyScanningCount}}</div>
              </template>
              </el-table-column>
              <el-table-column label="备注" min-width="100" prop="remark" fixed="right"></el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import AttendanceSearchAdapter from './adapter/attendance-search-adpater'
export default {
  mixins:[AttendanceSearchAdapter],
  components: {
    HeadTag,
    CommonSearchWidget,
  },
  data() {
    return {
      tagName: "考勤统计",
      staffInfo: {},
      listLoading: false,
      activeName: "lastMonth",
      workOrderList: [],
      personNumber: 0,
      personCount: 0,
      exportLoading:false,
      exportBtnDisabled:false,
      tableMaxHeight:this.getTableMaxHeight()
    };
  },
  mounted() {},
  created() {
    this.orgCode = this.$route.query.orgCode;
    this.orgName = this.$route.query.orgName;
    // this.staffInfo = JSON.parse(this.$route.query.staffInfo);
    // this.queryData();
    window.addEventListener("resize",()=>{
      this.tableMaxHeight = this.getTableMaxHeight();
    })
  },
  methods: {
    /**
     * 导出
     */
    exportWorkOrders() {
      this.exportLoading = true;
      this.exportBtnDisabled = true;
      setTimeout(()=>{
         require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [];
        tHeader.push("序号")
        tHeader.push("员工姓名");
        tHeader.push("岗位");
        tHeader.push("星级");
        tHeader.push("保底工时");
        tHeader.push("住宿");
        tHeader.push("商业");
        tHeader.push("服务人数");
        for (let i = 1; i <= 31; i++) {
          tHeader.push(i + "日");
        }
        tHeader.push("本月实际出勤");
        tHeader.push("本月应出勤");
        tHeader.push("备注");
        // 上面设置Excel的表格第一行的标题
        const filterVal = [];
        filterVal.push("orderNumber")
        filterVal.push("careGiverName");
        filterVal.push("servicePositionName");
        filterVal.push("staffGrade");
        filterVal.push("workTime");
        filterVal.push("assessGrade");
        filterVal.push("assessGrade");
        filterVal.push("number");
        for (let i = 1; i <= 31; i++) {
          filterVal.push(i + "");
        }
        filterVal.push("workOrderCount");
        filterVal.push("companyScanningCount");
        filterVal.push("remark");
        try {
          let year = new Date().getFullYear();
          let month = new Date().getMonth() + 1;
          if (this.type == "0" ) {
            if(month == 1){
              //上月
              year = year - 1;
              month = 12;
            }else{
              month=month-1;
            }
          }
          var yy = year.toString();
          var mm = month > 9 ? month : "0" + month;
          var sumRow = this.calColumnSum(filterVal, this.workOrderList);
          sumRow["number"] = "";//服务人数不合计
          sumRow["workTime"] = "";//保底工时不合计
          sumRow["staffGrade"] = "";//星级不合计
          //添加合计行
          this.workOrderList.push(sumRow);
          const data = this.formatJson(filterVal, this.workOrderList);
          export_json_to_excel(
            tHeader,
            data,
            this.searchModel.orgName + "考勤表" + yy + mm
          );
          //移除最后加的合计行
          this.workOrderList.splice(this.workOrderList.length - 1, 1);
          this.exportLoading = false;
          this.exportBtnDisabled = false;
          this.$forceUpdate()
        } catch (error) {
          this.exportLoading = false;
          this.exportBtnDisabled = false;
          this.$message.error("导出失败，请检查数据是否异常");
        }
      });
      },100)
     
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    calColumnSum(filterVal, jsonData) {
      //计算每列的合计总数
      var obj = {};
      filterVal.forEach(key => {
          obj[key] = jsonData
            .map(item => item[key])
            .reduce((prev, num) => {
              const value = Number(num);
              if (!isNaN(value)) {
                return prev + parseInt(num);
              } else {
                return "";
              }
            }, 0);
          obj[filterVal[0]] = "合计";
      });
      return obj;
    },
    handleClick(tab, event) {
      if (tab.index == "0") {
        this.searchModel.type = "0";
      } else {
        this.searchModel.type = "1";
      }
      this.workOrderList = [];
      this.tableMaxHeight=this.getTableMaxHeight();
      this.queryData();
    },
    goBack() {
      this.$router.go(-1);
    },
    getSummaries(param) {
        const { columns, data } = param;
        const sums = {};
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          }
          //处理服务人数 星级 保底工时
          if(column.property=="number"||
            column.property=="staffGrade"||
            column.property == "workTime"||
            column.property == "careGiverName"||
            column.property == "servicePositionName"||
            column.property == "remark"
          ){
            return;
          }
          column.align='right'
          const values = data.map(item => Number(item[column.property]));
          if (!values.every(value => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr);
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
            sums[index] += '';
          } else {
            sums[index] = '';
          }
        });
        return sums;
      },
      getTableMaxHeight(){
        return this.Utils.getWindowHeight()-340;
      },
  }
};
</script>

<style lang="scss" scoped>
#scheduling {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}


.form-item-service {
  width: 80px;
  min-width: 80px;
  margin-top: -3px;
  .font-style {
    height: 20px;
    line-height: 20px;
  }
}

.container {
  background-color: #fff;
  border-radius: 10px;
  margin: 0px 20px 20px 20px;
}

.tablePanel {
  padding: 20px;
}

.seettingTop {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
  height: 80px;
  display: flex;
  padding: 30px 0px 0px 20px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}

.avatar {
  width: 60px;
  height: 60px;
  cursor: pointer;
}
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
</style>