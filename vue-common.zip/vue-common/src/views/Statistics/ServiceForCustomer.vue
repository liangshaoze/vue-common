<!--服务产品客户统计-->
<template>
  <div>
    <headTag :tagName="tagName" />
  <div class="filter_wrap">
    <CommonSearchWidget
          @queryMethod="queryMethod"
          :propertyList="searchItems"
          :resultItem="searchModel"
          :ref="setSearchRef('CommonSearchWidget')"
        >
         <el-col class="form-item" slot="append">
            <el-form-item></el-form-item>
         </el-col>
          <el-col class="form-item" slot="append">
            <el-form-item></el-form-item>
         </el-col>
          <el-col class="form-item" slot="append">
            <el-form-item>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                style="margin-left:125px"
                @click="queryData()"
              >查询</el-button>
               <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  :loading="exportLoading"
                  :disabled="exportBtnDisabled"
                  icon="el-icon-upload"
                >导出</el-button>
              <!-- <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button> -->
            </el-form-item>
          </el-col>
        </CommonSearchWidget>
  </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import ServiceForCustomerSearchAdapter from './adapter/serviceforcustomer-search-adpater'
// 引入ag-grid-vue
import { AgGridVue } from 'ag-grid-vue';
export default {
  mixins:[ServiceForCustomerSearchAdapter],
  components: {
    HeadTag,
    CommonSearchWidget,
    AgGridVue,
  },
  data() {
    return {
      tagName: "服务产品客户统计",
      staffInfo: {},
      listLoading: false,
      workOrderList: [],
      exportLoading:false,
      exportBtnDisabled:false,
      tableMaxHeight:this.getTableMaxHeight(),
      columnDefs:this.getColumnDefs(),
      pinnedBottomRowData: null,
    };
  },
  beforeMount(){
  },
  mounted() {},
  created() {
    // this.staffInfo = JSON.parse(this.$route.query.staffInfo);
    if(this.searchModel.orgCode!=""){
      // this.queryData();
    }
    window.addEventListener("resize",()=>{
      this.tableMaxHeight = this.getTableMaxHeight();
    })
  },
  methods: {
    /**
     * 导出
     */
    exportWorkOrders() {
      if(this.searchModel.orgCode==""){
        this.$message.error("请先选择组织~")
        return;
      }
      this.exportLoading = true;
      this.exportBtnDisabled = true;
     
    },
    calColumnSum(filterVal, jsonData) {
      //计算每列的合计总数
      var obj = {};
      filterVal.forEach(key => {
          obj[key] = jsonData
            .map(item => item[key])
            .reduce((prev, num) => {
              const value = Number(num);
              if (!isNaN(value)) {
                return prev + parseInt(num);
              } else {
                return "";
              }
            }, 0);
          obj[filterVal[0]] = "合计";
      });
      return obj;
    },
    goBack() {
      this.$router.back();
    },
      getTableMaxHeight(){
        return this.Utils.getWindowHeight()-360;
      },
      getColumnDefs(){
        var columnDefs = []
        columnDefs.push({ headerName:"",children:[{ headerName:"序号", field: 'orderNumber',width:80,'pinned': 'left',cellStyle:this.cellStyle('orderNumber')}]})
        columnDefs.push({ headerName:"",children:[{ headerName:"员工姓名", field: 'careGiverName',width:80,'pinned': 'left',cellStyle:this.cellStyle('careGiverName')}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"岗位", field: 'servicePositionName',width:100,'pinned': 'left',cellStyle:this.cellStyle('servicePositionName')}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"星级", field: 'staffGrade',width:50,'pinned': 'left',cellStyle:this.cellStyle('staffGrade')}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"保底工时", field: 'workTime',width:80,'pinned': 'left',cellStyle:this.cellStyle()}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"住宿", field: 'assessGrade',width:50,cellStyle:this.cellStyle()}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"商业", field: 'assessGrade',width:50,cellStyle:this.cellStyle()}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"服务人数", field: 'number',width:80,cellStyle:this.cellStyle()}]});
        var childrens = [];
        for (let i = 1; i <= 31; i++) {
          childrens.push({ headerName:i + "日", field: i+"",width:60,cellStyle:this.cellStyle()});
        }
        columnDefs.push({ headerName:"出勤情况",children:childrens,cellStyle:this.cellStyle()})
        columnDefs.push({ headerName:"",children:[{ headerName:"本月实际出勤", field: 'workOrderCount','pinned': 'right',width:110,cellStyle:this.cellStyle()}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"本月应出勤", field: 'companyScanningCount','pinned': 'right',width:100,cellStyle:this.cellStyle()}]});
        columnDefs.push({ headerName:"",children:[{ headerName:"备注", field: 'remark','pinned': 'right',width:50,cellStyle:this.cellStyle('remark')}]});
        return columnDefs
      },
      getColumnNameList(){
        const filterVal = [];
        filterVal.push("orderNumber")
        filterVal.push("careGiverName");
        filterVal.push("servicePositionName");
        filterVal.push("staffGrade");
        filterVal.push("workTime");
        filterVal.push("assessGrade");
        filterVal.push("assessGrade");
        filterVal.push("number");
        for (let i = 1; i <= 31; i++) {
          filterVal.push(i + "");
        }
        filterVal.push("workOrderCount");
        filterVal.push("companyScanningCount");
        filterVal.push("remark");
        return filterVal;
      },
      getBottomSumRow(){
        var sumRow = this.calColumnSum(this.getColumnNameList(), this.workOrderList);
        sumRow["number"] = "";//服务人数不合计
        sumRow["workTime"] = "";//保底工时不合计
        sumRow["staffGrade"] = "";//星级不合计
        return sumRow;
      },
      cellStyle: function(params) {
        if(params == "orderNumber"||
          params == "careGiverName"||
          params == "servicePositionName"||
          params == "staffGrade"||
          params == "remark"
        ){
          return {padding:'5px',borderLeft:'0.5px solid #e0e6eb',borderBottom:'1px solid #e0e6eb',borderRight:'0.5px solid #e0e6eb',textAlign:'center'};
        }
        return {padding:'5px',borderLeft:'0.5px solid #e0e6eb',borderBottom:'1px solid #e0e6eb',borderRight:'0.5px solid #e0e6eb',textAlign:'right'};
      },
      
  }
};
</script>

<style lang="scss" scoped>
#scheduling {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
// .table {
//   width: 100%;
//   height: 600px;
//   overflow: auto;
// }
</style>
<style lang="scss">

.ag-header-cell-label{ 
  justify-content: center; 
  padding: 3px;
  font-size:12px;
  // font-style:bold;
  
}
.ag-header-cell{
  border: 0.5px solid #e0e6eb !important ;
  // border-bottom: 1px solid #e0e6eb !important;
}
.ag-header{
  min-height: 40px;
  height: 40px;
  overflow: auto;
  background-color:rgba(57, 138, 241, 0.1);
  color:#606266;
  border: 1px solid #e0e6eb;
}
.ag-body-viewport-wrapper.ag-layout-normal {
  overflow-x: scroll;
  border-left: 1px solid #e0e6eb;
  border-right: 1px solid #e0e6eb;
  // border-bottom: 1px solid #e0e6eb;
}
.ag-body-viewport{
  border: 1px solid #e0e6eb;
}

</style>