import BaseSearchAdapter from "components/widget/base-search-adapter"
import { findEtProductByDataAuthority } from "api/businessService/orderPaymentReview";
import { attendanceStatistics, selectGiverListForSchedule } from "api/workOrderManagement";
import {
  findEtProductListForWebQuickSearch,
  getProductAuthorityCode, //产品权限
} from "api/orderManagement";
import { findStaffList } from "api/customerManagement";
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '',
        orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '',
        productName: "",
        staffCode: "",
        staffName: "",
        productCodes: [],
        type: "0", //月份类型判定(0:上月,1:当月)
        searchLoading: false,
      },
      searchItems: [
        {
          propertyName: "组织",
          propertyFieldName: "orgName",
          propertyType: "60", //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "产品名称",
          propertyFieldName: "productCodes",
          propertyType: "30",
          queryMethod: "fetchProductList",
          options: [],
        },
        {
          propertyName: "员工姓名",
          propertyFieldName: "staffName",
          propertyCodeFieldName: "staffCode",
          propertyType: "50",
          queryMethod: "queryStaffName",
        },
      ],
      productAuthorityOrgCode:"",
    };
  },
  mounted(){
    this.getProductRight();
    this.$watch("searchModel.orgCode",()=>{
      this.getProductRight();
      //清空产品及员工姓名
      var product = this.searchItems.find(item => item.propertyFieldName == "productCodes")
      product.options = [];
      this.searchModel.productCodes = [];
      this.searchModel.staffCode = "";
      this.searchModel.staffName = "";

    })
  },
  methods: {
    queryPropertyType(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        productType: 10,
        productName: queryString
      };
      findEtProductByDataAuthority(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            var obj = this.searchItems.find(item => item.propertyFieldName == "productCodes")
            obj.options = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              obj.options.push({
                label: data[i].productName,
                value: data[i].productCode,
              });
            }
            var results = obj.options;
            if (results.length === 0) {
              results = [{ label: "无", value: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEtProductByDataAuthority:" + error);
          return false;
        });
    },
    queryData() {
      if (this.searchModel.orgCode == "") {
        this.$message.warning("请先选择组织~")
        return;
      }
      this.listLoading = true;
      this.searchLoading = true;
      this.workOrderList = [];
      attendanceStatistics(this.searchModel)
        .then(response => {
          this.listLoading = false;
          this.searchLoading = false;
          if (response.data.statusCode == "200") {
            if(response.data.responseData&&response.data.responseData.table){
              this.workOrderList = response.data.responseData.table;
              this.personCount = response.data.responseData.personCount || 0;
              this.personNumber = response.data.responseData.personNumber || 0;
              //数据处理
              this.workOrderList.forEach((item, index) => {
                item.orderNumber = index + 1;
                for (let i = 1; i <= 31; i++) {
                  item[i + ""] = parseInt(item[i + ""]) || 0;
                }
                item.workTime = parseInt(item.workTime) || 0;
                item.companyScanningCount = parseInt(item.companyScanningCount) || 0;
              })
              this.calculateCount();
              this.pinnedBottomRowData = [this.getBottomSumRow()];
              this.$forceUpdate();
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.listLoading = false;
          this.searchLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
    calculateCount() {
      this.workOrderList.forEach(item => {
        item.workOrderCount = 0;
        for (let field in item) {
          if (field.length <= 2) {
            item.workOrderCount += parseInt(item[field]);
          }
        }
        //扫码数量包含出勤数量
        item.companyScanningCount = item.companyScanningCount + item.workOrderCount;
      });
    },
    resetForm() {
      this.searchModel.orgCode = this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '',
        this.searchModel.orgName = this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '',
        this.searcher.resetForm();
      this.queryData();
    },
    queryStaffName(queryString, cb) {
      if(this.searchModel.orgCode==""){
        this.$message.warning("请先选择组织~");
        cb([])
        return;
      }
      let params = {};
      params = {
        pageNum: 1,
        pageSize: 10,
        staffFullName: queryString,
        orgCode: this.searchModel.orgCode,
      };
      findStaffList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.staffPositionList = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.staffPositionList.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel,
                positionName: data[i].positionName
              });
            }
            var results = this.staffPositionList;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //获取产品列表前先查询产品权限
    getProductRight() {
      if(this.searchModel.orgCode==""){
        return;
      }
      this.productAuthorityOrgCode = "";
      getProductAuthorityCode({ orgCode: this.searchModel.orgCode })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.productAuthorityOrgCode = response.data.responseData;
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    fetchProductList(queryString) {
      // if(!this.productForm.orgUnitCode){
      //    cb([])
      //   return;
      // }
      if(this.searchModel.orgCode==""){
        this.$message.warning("请先选择组织~");
        var obj = this.searchItems.find(item => item.propertyFieldName == "productCodes")
        obj.options = [];
        return;
      }
      if (!this.productAuthorityOrgCode) {
        return;
      }
      let params = {
        productName: queryString, //不传值表示查所有产品名称
        productAuthorityOrgCode: this.productAuthorityOrgCode
        // orgUnitCode:this.productForm.orgUnitCode
      };
      findEtProductListForWebQuickSearch(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            var obj = this.searchItems.find(item => item.propertyFieldName == "productCodes")
            obj.options = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              obj.options.push({
                label: data[i].productName,
                value: data[i].productCode,
              });
            }
            if (obj.options.length === 0) {
              this.$message.warning("该组织下无对应的产品哦~");
            }
            
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
  }
}