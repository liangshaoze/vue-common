import BaseSearchAdapter from "components/widget/base-search-adapter"
import { attendanceStatistics } from "api/workOrderManagement";
import {
  findEtProductListForWebQuickSearch,
  getProductAuthorityCode, //产品权限
} from "api/orderManagement";
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '',
        orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '',
        productName: "",
        productCodes: [],
        type: "0", //月份类型判定(0:上月,1:当月)
        searchLoading: false,
      },
      searchItems: [
        {
          propertyName: "组织",
          propertyFieldName: "orgName",
          propertyType: "60", //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "产品名称",
          propertyFieldName: "productCodes",
          propertyType: "30",
          queryMethod: "fetchProductList",
          options: [],
          style:{width:'200px'}
        },
      ],
      productAuthorityOrgCode:"",
    };
  },
  mounted(){
    this.getProductRight();
    this.$watch("searchModel.orgCode",()=>{
      this.getProductRight();
      //清空产品及员工姓名
      var product = this.searchItems.find(item => item.propertyFieldName == "productCodes")
      product.options = [];
      this.searchModel.productCodes = [];
    })
  },
  methods: {
    queryData() {
      if (this.searchModel.orgCode == "") {
        this.$message.warning("请先选择组织~")
        return;
      }
      this.listLoading = true;
      this.searchLoading = true;
      this.workOrderList = [];
      attendanceStatistics(this.searchModel)
        .then(response => {
          this.listLoading = false;
          this.searchLoading = false;
          if (response.data.statusCode == "200") {
            if(response.data.responseData&&response.data.responseData.table){
              this.workOrderList = response.data.responseData.table;
              this.pinnedBottomRowData = [this.getBottomSumRow()];
              this.$forceUpdate();
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.listLoading = false;
          this.searchLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
    resetForm() {
      this.searchModel.orgCode = this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '',
        this.searchModel.orgName = this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '',
        this.searcher.resetForm();
      this.queryData();
    },
    //获取产品列表前先查询产品权限
    getProductRight() {
      if(this.searchModel.orgCode==""){
        return;
      }
      this.productAuthorityOrgCode = "";
      getProductAuthorityCode({ orgCode: this.searchModel.orgCode })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.productAuthorityOrgCode = response.data.responseData;
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    fetchProductList(queryString) {
      if(this.searchModel.orgCode==""){
        this.$message.warning("请先选择组织~");
        var obj = this.searchItems.find(item => item.propertyFieldName == "productCodes")
        obj.options = [];
        return;
      }
      if (!this.productAuthorityOrgCode) {
        return;
      }
      let params = {
        productName: queryString, //不传值表示查所有产品名称
        productAuthorityOrgCode: this.productAuthorityOrgCode
        // orgUnitCode:this.productForm.orgUnitCode
      };
      findEtProductListForWebQuickSearch(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            var obj = this.searchItems.find(item => item.propertyFieldName == "productCodes")
            obj.options = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              obj.options.push({
                label: data[i].productName,
                value: data[i].productCode,
              });
            }
            if (obj.options.length === 0) {
              this.$message.warning("该组织下无对应的产品哦~");
            }
            
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
  }
}