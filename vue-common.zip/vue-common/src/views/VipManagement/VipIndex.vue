<template>
  <div>
    <headTag :tagName="tagName" />
    <div @click="dialogPurchaseRecordsList=true">消费记录</div>
    <div @click="toLuckCoinList">福币明细</div>
    <el-row>
      <!--头像-->
      <div v-if="customerInfo.careReceiverIcon">
        <el-avatar
          size="large"
          style="vertical-align: middle;"
          :src="customerInfo.careReceiverIcon"
          class="avatar"
        ></el-avatar>
      </div>
      <div v-else>
        <!-- <el-avatar
                    size="large"
                    style="vertical-align: middle;"
                    src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
        ></el-avatar>-->
        <svg-icon icon-class="equip-avatar-default" class="avatar" />
      </div>
    </el-row>
    <el-dialog
      title="消费记录"
      :visible.sync="dialogPurchaseRecordsList"
      width="1000px"
      :before-close="closeDialog"
    >
      <PurchaseRecordsList :productName="'护士上门'" />
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import PurchaseRecordsList from "./PurchaseRecordsList";
export default {
  components: {
    HeadTag,
    PurchaseRecordsList
  },
  data() {
    return {
      tagName: "会员信息",
      dialogPurchaseRecordsList: false,
      customerInfo:{},
    };
  },
  methods: {
    closeDialog() {
      this.dialogPurchaseRecordsList = false;
    },
    toLuckCoinList(){
        this.$router.push({
            path:"/vipManagement/luckCoinList"
        })
    }
  }
};
</script>

<style>
.avatar {
  width: 45px;
  height: 45px;
  cursor: pointer;
}
.el-dialog {
  padding: 10px;
}
.el-dialog__body {
  padding: 10px;
}

</style>