<template>
  <div>
    <headTag :tagName="tagName" />
    <div class="filter_wrap">
      <CommonSearchWidget
        @queryMethod="queryMethod"
        :propertyList="searchItems"
        :resultItem="searchModel"
        :ref="setSearchRef('CommonSearchWidget')"
      >
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item>
            <el-button
              size="mini"
              type="primary"
              icon="el-icon-search"
              :loading="searchLoading"
              style="margin-left:125px"
              @click="queryData()"
            >查询</el-button>
            <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
          </el-form-item>
        </el-col>
      </CommonSearchWidget>
    </div>
    <div class="tableToolbar" style="padding-top:10px">
      <div class="tableTopBtn">
        <el-button type="primary" size="mini" @click="dialogAdd=true">新增</el-button>
      </div>
      <CommonTableWidget
        @queryMethod="queryMethod"
        :formModel="tableFormModel"
        :tableDataName="'dataList'"
        :propertyList="columns"
        :loading="tableLoading"
        :ref="setTableRef('CommonTableWidget')"
        :optWidth="80"
        :showTableIndex="false"
        :hasOptColumn="true"
        @pageChange="pageChange"
      >
        <template slot-scope="scope">
          <el-button type="text" v-if="scope.row.row.isEdit" @click="saveExchange(scope)">保存</el-button>
          <el-button type="text" v-else @click="editExchange(scope)">编辑</el-button>
        </template>
      </CommonTableWidget>
    </div>
    <el-dialog title="新增兑换记录" :visible.sync="dialogAdd" width="500px" :before-close="closeDialog">
     <ExchangeAdd/>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import ExchangeSearchAdapter from "./adpater/exchange-search-adapter";
import ExchangeTableAdapter from "./adpater/exchange-table-adapter";
import ExchangeAdd from "./ExchangeAdd"
export default {
  mixins: [ExchangeSearchAdapter, ExchangeTableAdapter],
  components: {
    HeadTag,
    CommonSearchWidget,
    CommonTableWidget,
    ExchangeAdd
  },
  data() {
    return {
      tagName: "兑换记录",
      dialogAdd: false
    };
  },
  mounted() {},
  methods: {
    pageChange(val) {
      this.searchModel.pageNum = val.page;
      this.searchModel.pageSize = val.limit;
      this.queryData();
    },
    editExchange(scope) {
      this.$set(scope.row.row,"isEdit",true);
    },
    saveExchange(scope) {
      this.$set(scope.row.row,"isEdit",false);
    },
    closeDialog(){
      this.dialogAdd = false;
    }
  }
};
</script>

<style>
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>