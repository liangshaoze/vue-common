<template>
  <div>
    <CommonEditWidget
      @queryMethod="queryMethod"
      :propertyList="editItems"
      :resultItem="editFormModel"
      :ref="setEditerRef('CommonEditWidget')"
    ></CommonEditWidget>
  </div>
</template>

<script>
import CommonEditWidget from "components/widget/CommonEditWidget";
import LuckCoinEditAdapter from "./adpater/luck-coin-edit-adapter";
export default {
  mixins: [LuckCoinEditAdapter],
  components: {
    CommonEditWidget
  }
};
</script>

<style>
</style>