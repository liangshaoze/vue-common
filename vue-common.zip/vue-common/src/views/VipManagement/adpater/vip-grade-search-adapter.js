import BaseSearchAdapter from 'components/widget/base-search-adapter'
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        createDate:"",
        pageNum: 1,
        pageSize: 10
      },
      searchItems: [
        {
          propertyName: "创建时间",
          propertyFieldName: "createDate",
          propertyType: "71",
        }
      ],
    }
  },
  mounted(){
    this.queryData();
  },
  methods: {
    queryData(){
      this.loading(true)
      //TODO
      // findDeviceOrderDataByNo(this.searchModel).then(response=>{
      //  this.loading(false);
      //   if(response.data.statusCode==200){
      //     this.tableFormModel.dataList = response.data.responseData;
      //     this.tableFormModel.totalCount = response.data.totalCount;
      //   }
      // }).catch(error=>{
      //    this.loading(false);
      //    this.$message(this.ConstantData.requestErrorMsg)
      // })
      this.tableFormModel.dataList.push({
        tradeId:"JY2007160001",
        vipGrade:"三星",
        money:"1988",
        createDate:"2020-07-16 09:16:20",
      })
      this.tableFormModel.totalCount = this.tableFormModel.dataList.length;
      this.loading(false);
    },
    loading(searching){
      this.searchLoading = searching;
      this.tableLoading = searching;
    },
  }
}