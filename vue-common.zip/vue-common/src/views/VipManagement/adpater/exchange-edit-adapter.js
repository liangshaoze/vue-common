import BaseEditAdapter from 'components/widget/base-edit-adapter'
export default {
  mixins: [BaseEditAdapter],
  data() {
    return {
      editItems: [
        {
          propertyName: "兑换产品",
          propertyFieldName: "productName",
          propertyType: "20",
          required: true,
          optionValueFieldName:"name",
          optionKeyFieldName:"value",
          options:[
            {name:"康复指导",value:"10"},
            {name:"护士上门",value:"20"},
          ]
        },
        {
          propertyName: "消费福币",
          propertyFieldName: "luckCoin",
          propertyType: "10",
          required: true,
        },
        {
          propertyName: "兑换申请时间",
          propertyFieldName: "updateDate",
          propertyType: "71",
          required:true,
        },
      ],
      editFormModel: {
        isEdit: true,
        productName: "",
        luckCoin: "",
        updateDate: "",
      }
    }
  },
  mounted() {
    this.$forceUpdate()
  },
  methods: {
    submit(){
      this.editer.getEditForm().validate(valid=>{
        if(valid){
          this.editFormModel.isEdit = false;
          this.$forceUpdate()
        }else{
          this.$message.error("请检查是否填写完整");
          return false;
        }
      })
    },
    toUpdate(){
      this.editFormModel.isEdit = true;
    },
    
  },


}