import BaseTableAdapter from 'components/widget/base-table-adapter'
export default {
    mixins: [BaseTableAdapter],
    data(){
        return {
            columns: [
                {
                  propertyName: "交易号",
                  propertyFieldName: "tradeId",
                  propertyType: "10"
                },
                {
                  propertyName: "会员星级",
                  propertyFieldName: "vipGrade",
                  propertyType: "10",
                  width: "250"
                },
                {
                  propertyName: "金额（元）",
                  propertyFieldName: "money",
                  propertyType: "10",
                  width: "200"
                },
                {
                  propertyName: "创建时间",
                  propertyFieldName: "createDate",
                  propertyType: "10"
                },
              ],
        }
    },
    methods: {

    },
    
    
}