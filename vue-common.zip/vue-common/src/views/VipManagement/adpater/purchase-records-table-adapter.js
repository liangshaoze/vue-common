import BaseTableAdapter from 'components/widget/base-table-adapter'
export default {
  mixins: [BaseTableAdapter],
  data() {
    return {
      columns: [
        {
          propertyName: "产品名称",
          propertyFieldName: "productName",
          propertyType: "10",
          width: "100",
          canEdit: false,
        },
        {
          propertyName: "服务对象",
          propertyFieldName: "fwdx",
          propertyType: "10",
        },
        {
          propertyName: "服务地址",
          propertyFieldName: "fwdz",
          propertyType: "10",
        },
        {
          propertyName: "服务日期",
          propertyFieldName: "fwrq",
          propertyType: "20",
        },
        {
          propertyName: "服务状态",
          propertyFieldName: "fwzt",
          propertyType: "10",
          width: "100",
        },
        {
          propertyName: "备注",
          propertyFieldName: "remark",
          propertyType: "10",
          width: "100",
        },
      ],
    }
  },
  mounted() {
    //TODO 模拟数据
    this.table.formModel.dataList.push({
      productName: "护士上门",
      fwdx: "李奶奶（13278909871）",
      fwdz: "水电路1388号",
      fwrq: "2020-07-16 13:49:22",
      fwzt: "已服务",
      remark: "这是备注",
    })
  },
  methods: {
    //保存行
    saveRow(index, row, table) {
      alert("保存行")
    },
    //删除行
    deleteRow(index, row, table) {
      alert("删除行")
    },
    addRow() {
      this.table.formModel.dataList.push({
        productName: this.productName,
        fwdx: "",
        fwdz: "",
        fwrq: "",
        fwzt: "",
        remark: "",
        isEdit: true,
      });
    }
  },


}