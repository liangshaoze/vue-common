import BaseSearchAdapter from 'components/widget/base-search-adapter'
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        changeReason:"",
        changeType:"",
        updateTime:"",
        pageNum: 1,
        pageSize: 10
      },
      searchItems: [
        {
          propertyName: "福币变化原因",
          propertyFieldName: "changeReason",
          propertyType: "20",
          optionValueFieldName:"name",
          optionKeyFieldName:"value",
          options:[
            {name:"推荐新人",value:"10"},
            {name:"产品支付",value:"20"},
            {name:"产品兑换",value:"30"},
            {name:"交易退款福币退回",value:"40"},
            {name:"福币失效",value:"50"},
          ]
        },
        {
          propertyName: "福币变化类型",
          propertyFieldName: "changeType",
          propertyType: "20",
          optionValueFieldName:"name",
          optionKeyFieldName:"value",
          options:[{name:"获取",value:"10"},{name:"使用",value:"20"}]
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "71",
        }
      ],
    }
  },
  mounted(){
    this.queryData();
  },
  methods: {
    queryData(){
      this.loading(true)
      //TODO
      // findDeviceOrderDataByNo(this.searchModel).then(response=>{
      //  this.loading(false);
      //   if(response.data.statusCode==200){
      //     this.tableFormModel.dataList = response.data.responseData;
      //     this.tableFormModel.totalCount = response.data.totalCount;
      //   }
      // }).catch(error=>{
      //    this.loading(false);
      //    this.$message(this.ConstantData.requestErrorMsg)
      // })
      this.tableFormModel.dataList.push({
        changeReason:"推荐新人",
        luckCoin:"+100",
        updateDate:"2020-07-16 09:16:20",
      })
      this.tableFormModel.totalCount = this.tableFormModel.dataList.length;
      this.loading(false);
    },
    loading(searching){
      this.searchLoading = searching;
      this.tableLoading = searching;
    },
  }
}