import BaseEditAdapter from 'components/widget/base-edit-adapter'
export default {
  mixins: [BaseEditAdapter],
  data() {
    return {
      editItems: [
        {
          propertyName: "福币变化原因",
          propertyFieldName: "changeReason",
          propertyType: "20",
          required: true,
          optionValueFieldName:"name",
          optionKeyFieldName:"value",
          options:[
            {name:"推荐新人",value:"10"},
            {name:"产品支付",value:"20"},
            {name:"产品兑换",value:"30"},
            {name:"交易退款福币退回",value:"40"},
            {name:"福币失效",value:"50"},
          ]
        },
        {
          propertyName: "福币变化",
          propertyFieldName: "luckCoin",
          propertyType: "10",
          required: true,
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateDate",
          propertyType: "71"
        },
      ],
      editFormModel: {
        isEdit: true,
        changeReason: "",
        luckCoin: "",
        updateDate: "",
      }
    }
  },
  mounted() {
    this.$forceUpdate()
  },
  methods: {
    submit(){
      this.editFormModel.isEdit = false;
      this.$forceUpdate()
    },
    toUpdate(){
      this.editFormModel.isEdit = true;
    }
  },


}