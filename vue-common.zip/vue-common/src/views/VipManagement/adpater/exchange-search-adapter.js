import BaseSearchAdapter from 'components/widget/base-search-adapter'
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        productName:"",
        applyTime:"",
        pageNum: 1,
        pageSize: 10
      },
      searchItems: [
        {
          propertyName: "兑换产品",
          propertyFieldName: "productName",
          propertyType: "20",
          optionValueFieldName:"name",
          optionKeyFieldName:"value",
          options:[
            {name:"康复指导",value:"10"},
            {name:"上门打针",value:"20"},
          ],
        },
        {
          propertyName: "兑换申请时间",
          propertyFieldName: "applyTime",
          propertyType: "71",
        }
      ],
    }
  },
  mounted(){
    this.queryData();
  },
  methods: {
    queryData(){
      this.loading(true)
      //TODO
      // findDeviceOrderDataByNo(this.searchModel).then(response=>{
      //  this.loading(false);
      //   if(response.data.statusCode==200){
      //     this.tableFormModel.dataList = response.data.responseData;
      //     this.tableFormModel.totalCount = response.data.totalCount;
      //   }
      // }).catch(error=>{
      //    this.loading(false);
      //    this.$message(this.ConstantData.requestErrorMsg)
      // })
      this.tableFormModel.dataList.push({
        productName:"康复指导",
        luckCoin:"500",
        applyTime:"2020-07-16 09:16:20",
        status:"已申请",
      })
      this.tableFormModel.totalCount = this.tableFormModel.dataList.length;
      this.loading(false);
    },
    loading(searching){
      this.searchLoading = searching;
      this.tableLoading = searching;
    },
  }
}