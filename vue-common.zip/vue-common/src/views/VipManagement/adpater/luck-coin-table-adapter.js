import BaseTableAdapter from 'components/widget/base-table-adapter'
export default {
    mixins: [BaseTableAdapter],
    data(){
        return {
            columns: [
                {
                  propertyName: "福币变化原因",
                  propertyFieldName: "changeReason",
                  propertyType: "10"
                },
                {
                  propertyName: "福币变化",
                  propertyFieldName: "luckCoin",
                  propertyType: "10",
                  width: "250"
                },
                {
                  propertyName: "更新时间",
                  propertyFieldName: "updateDate",
                  propertyType: "10"
                },
              ],
        }
    },
    methods: {

    },
    
    
}