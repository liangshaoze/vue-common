import BaseTableAdapter from 'components/widget/base-table-adapter'
export default {
    mixins: [BaseTableAdapter],
    data(){
        return {
            columns: [
                {
                  propertyName: "兑换产品",
                  propertyFieldName: "productName",
                  propertyType: "10",
                  canEdit:false,
                },
                {
                  propertyName: "消费福币",
                  propertyFieldName: "luckCoin",
                  propertyType: "10",
                  canEdit:false,
                },
                {
                  propertyName: "兑换申请时间",
                  propertyFieldName: "applyTime",
                  propertyType: "10",
                  canEdit:false,
                },
                {
                  propertyName: "状态",
                  propertyFieldName: "status",
                  propertyType: "20",
                  optionValueFieldName:"name",
                  optionKeyFieldName:"value",
                  options:[
                    {name:"已生效",value:"10"},
                    {name:"已申请",value:"20"},
                  ],
                },
              ],
        }
    },
    methods: {

    },
    
    
}