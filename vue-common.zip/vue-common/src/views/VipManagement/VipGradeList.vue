<template>
  <div>
    <headTag :tagName="tagName" />
    <div class="filter_wrap">
      <CommonSearchWidget
        @queryMethod="queryMethod"
        :propertyList="searchItems"
        :resultItem="searchModel"
        :ref="setSearchRef('CommonSearchWidget')"
      >
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item>
            <el-button
              size="mini"
              type="primary"
              icon="el-icon-search"
              :loading="searchLoading"
              style="margin-left:125px"
              @click="queryData()"
            >查询</el-button>
            <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
          </el-form-item>
        </el-col>
      </CommonSearchWidget>
    </div>
    <div class="tableToolbar" style="padding-top:10px">
      <CommonTableWidget
        @queryMethod="queryMethod"
        :formModel="tableFormModel"
        :tableDataName="'dataList'"
        :propertyList="columns"
        :loading="tableLoading"
        :ref="setTableRef('CommonTableWidget')"
        :optWidth="100"
        :showTableIndex="false"
        :hasOptColumn="true"
        @pageChange="pageChange"
      >
      <template slot-scope="scope">
        <el-button type="text" @click="showServiceRecords(scope)" size="mini">服务记录</el-button>
      </template>
      </CommonTableWidget>
    </div>
    <el-dialog 
    title="服务记录" 
    :visible.sync="dialogServiceRecordsList" 
    width="1000px" 
    :before-close="closeDialog">
    <ServiceRecordsList/>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import VipGradeSearchAdapter from "./adpater/vip-grade-search-adapter";
import VipGradeTableAdapter from "./adpater/vip-grade-table-adapter";
import ServiceRecordsList from "./ServiceRecordsList"
export default {
  mixins: [VipGradeSearchAdapter, VipGradeTableAdapter],
  components: {
    HeadTag,
    CommonSearchWidget,
    CommonTableWidget,
    ServiceRecordsList
  },
  data() {
    return {
      tagName: "会员星级",
      dialogServiceRecordsList:false
    };
  },
  mounted() {},
  methods: {
    pageChange(val) {
      this.searchModel.pageNum = val.page;
      this.searchModel.pageSize = val.limit;
      this.queryData();
    },
    showServiceRecords(scope){
      this.dialogServiceRecordsList = true;
    },
    closeDialog(){
      this.dialogServiceRecordsList = false;
    }
  },

};
</script>

<style>
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
</style>