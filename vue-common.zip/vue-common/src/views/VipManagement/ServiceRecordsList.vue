<template>
  <div>
    <div class="tableToolbar" style="padding-top:10px">
      <CommonTableWidget
        @queryMethod="queryMethod"
        :formModel="tableFormModel"
        :tableDataName="'dataList'"
        :propertyList="columns"
        :loading="tableLoading"
        :ref="setTableRef('CommonTableWidget')"
        :optWidth="80"
        :showTableIndex="false"
        :hasOptColumn="false"
        @pageChange="pageChange"
        :showPagination="false"
      >
      </CommonTableWidget>
    </div>
  </div>
</template>

<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import ServiceRecordsTableAdapter from "./adpater/service-records-table-adapter";
export default {
  mixins: [ServiceRecordsTableAdapter],
  components: {
    CommonTableWidget
  },
  data() {
    return {
    };
  },
  mounted() {},
  methods: {
    // pageChange(val) {
    //   this.searchModel.pageNum = val.page;
    //   this.searchModel.pageSize = val.limit;
    //   this.queryData();
    // },
  }
};
</script>

<style>
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>