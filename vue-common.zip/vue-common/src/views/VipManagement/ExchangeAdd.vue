<template>
  <div>
    <CommonEditWidget
      @queryMethod="queryMethod"
      :propertyList="editItems"
      :resultItem="editFormModel"
      :ref="setEditerRef('CommonEditWidget')"
    ></CommonEditWidget>
  </div>
</template>

<script>
import CommonEditWidget from "components/widget/CommonEditWidget";
import ExchangeEditAdapter from "./adpater/exchange-edit-adapter";
export default {
  mixins: [ExchangeEditAdapter],
  components: {
    CommonEditWidget
  }
};
</script>

<style>
</style>