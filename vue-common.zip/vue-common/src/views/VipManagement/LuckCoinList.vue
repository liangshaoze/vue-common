<template>
  <div>
    <headTag :tagName="tagName" />
    <div class="filter_wrap">
      <CommonSearchWidget
        @queryMethod="queryMethod"
        :propertyList="searchItems"
        :resultItem="searchModel"
        :ref="setSearchRef('CommonSearchWidget')"
      >
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item></el-form-item>
        </el-col>
        <el-col class="form-item" slot="append">
          <el-form-item>
            <el-button
              size="mini"
              type="primary"
              icon="el-icon-search"
              :loading="searchLoading"
              style="margin-left:125px"
              @click="queryData()"
            >查询</el-button>
            <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
          </el-form-item>
        </el-col>
      </CommonSearchWidget>
    </div>
    <div class="tableToolbar" style="padding-top:10px">
      <div class="tableTopBtn">
        <el-button type="primary" size="mini" @click="dialogAdd=true">新增</el-button>
      </div>
      <CommonTableWidget
        @queryMethod="queryMethod"
        :formModel="tableFormModel"
        :tableDataName="'dataList'"
        :propertyList="columns"
        :loading="tableLoading"
        :ref="setTableRef('CommonTableWidget')"
        :optWidth="80"
        :showTableIndex="false"
        :hasOptColumn="false"
        @pageChange="pageChange"
      />
    </div>
    <el-dialog 
    title="新增福币记录" 
    :visible.sync="dialogAdd" 
    width="500px" 
    :before-close="closeDialog">
      <LuckCoinAdd/>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import LuckCoinSearchAdapter from "./adpater/luck-coin-search-adapter";
import LuckCoinTableAdapter from "./adpater/luck-coin-table-adapter";
import LuckCoinAdd from "./LuckCoinAdd"
export default {
  mixins: [LuckCoinSearchAdapter, LuckCoinTableAdapter],
  components: {
    HeadTag,
    CommonSearchWidget,
    CommonTableWidget,
    LuckCoinAdd
  },
  data() {
    return {
      tagName: "福币明细",
      dialogAdd: false
    };
  },
  mounted() {},
  methods: {
    pageChange(val) {
      this.searchModel.pageNum = val.page;
      this.searchModel.pageSize = val.limit;
      this.queryData();
    },
    closeDialog(){
      this.dialogAdd = false;
    }
  }
};
</script>

<style>
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>