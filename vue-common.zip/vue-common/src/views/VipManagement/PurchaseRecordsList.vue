<!--消费记录-->
<template>
  <div>
    <div >
      <el-row style="padding:10px">
        <el-button type="primary" size="mini" @click="addRow" style="float:right">新增</el-button>
      </el-row>
      <CommonTableWidget
        @queryMethod="queryMethod"
        :formModel="tableFormModel"
        :tableDataName="'dataList'"
        :propertyList="columns"
        :loading="tableLoading"
        :ref="setTableRef('CommonTableWidget')"
        :optWidth="200"
        :showTableIndex="false"
        :hasOptColumn="true"
        @pageChange="pageChange"
        :showPagination="false"
      >
      </CommonTableWidget>
    </div>
  </div>
</template>

<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import PurchaseRecordsTableAdapter from "./adpater/purchase-records-table-adapter";
export default {
  mixins: [PurchaseRecordsTableAdapter],
  components: {
    CommonTableWidget
  },
  props:{
    productName:String,
  },
  data() {
    return {
    };
  },
  mounted() {
  },
  methods: {
    // pageChange(val) {
    //   this.searchModel.pageNum = val.page;
    //   this.searchModel.pageSize = val.limit;
    //   this.queryData();
    // },
  }
};
</script>

<style>
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>