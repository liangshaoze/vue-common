<template>
  <div id="supplierManage">
    <!-- 地址标签 -->
    <HeadTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="90px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filters.orgName"
                placeholder="请选择组织"
                @focus="orgDialogVisible=true"
                @clear="clearOrgCode"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="供应商名称" prop="supplierName">
              <el-input size="mini" v-model.trim="filters.supplierName" placeholder="请输入供应商名称" clearable></el-input>
            </el-form-item>
          </el-col>
           <el-col class="form-item">
            <el-form-item label="联系人" prop="contactsName">
              <el-input size="mini" v-model.trim="filters.contactsName" placeholder="请输入联系人" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="contactsTel">
              <el-input size="mini" v-model.trim="filters.contactsTel" placeholder="请输入联系电话" maxlength="11" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="科目" prop="subjectType">
              <el-select v-model.trim="filters.subjectType" size="mini" placeholder="请选择科目" clearable>
                <el-option
                  v-for="item in subjectTypes"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议" prop="isSignAgreement">
              <el-select size="mini" v-model.trim="filters.isSignAgreement" placeholder="请选择" clearable>
                <el-option
                  v-for="item in isSignAgreements"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
         
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="queryList(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <!-- 列表数据 -->
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="toEdit()">新增</el-button>
          <el-button size="mini" type="primary" icon="el-icon-upload" @click="exportToExcel">导出</el-button>
        </el-col>
      </el-row>

      <el-table
        size="mini"
        v-loading="listLoading"
        :data="tableData"
        element-loading-text="拼命加载中"
        highlight-current-row
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        style="width；100%;border-radius:6px"
      >
        <el-table-column label="组织" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="供应商编号" width="150" prop="supplierCode"></el-table-column>
        <el-table-column label="供应商名称" min-width="80" prop="supplierName"></el-table-column>
        <el-table-column label="科目" min-width="60" prop="subjectType"></el-table-column>
        <el-table-column label="地区" min-width="120" prop="supplierDetailAddress"></el-table-column>
        <el-table-column label="联系人" min-width="70" prop="contactsName"></el-table-column>
        <el-table-column label="联系电话" min-width="70" prop="contactsTel"></el-table-column>
        <el-table-column label="签署协议" min-width="70" prop="isSignAgreement"></el-table-column>
        <el-table-column label="协议开始时间" width="100" prop="agreementStartDate"></el-table-column>
        <el-table-column label="协议结束时间" width="100" prop="agreementEndDate"></el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="toDetail(scope.row)">查看</el-button>
            <el-button size="mini" type="text" @click="toEdit(scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-row class="pageToolbar">
        <!--分页-->
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.pageNum"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        />
      </el-row>
      <el-dialog
        title="组织架构"
        :visible.sync="orgDialogVisible"
        width="50%"
        :before-close="handleClose"
      >
        <org-select v-on:listenTochildEvent="getCurrentNode"/>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { querySupplier } from "@/api/supplierManagement/supplierManagement.js";
import { export_json_to_excel } from "@/utils/Export2Excel.js";
import { findValueBySetCode } from "api/common";
import { changeYMD, keepDecimalFull } from "utils/index.js";
import OrgSelect from "components/OrgSelect";

export default {
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  props: {},
  data() {
    return {
      tagName: "供应商管理",
      restaurants: [],
      totalCount: 0,
      timeout: null,
      //关键字搜索
      filters: {
        supplierName: "",
        subjectType: "",
        contactsName: "",
        contactsTel: "",
        isSignAgreement: "",
        pageNum: 1,
        pageSize: 10,
        orgName: ""
      },
      listLoading: false,
      //列表数据
      tableData: [],
      //科目
      subjectTypes: [],
      //签署协议
      isSignAgreements: [],
      searchLoading: false,
      orgDialogVisible: false //组织对话框
    };
  },
  watch: {},
  computed: {},
  methods: {
    querySearchAsync(queryString, cb) {
      var restaurants = this.restaurants;
      var results = queryString
        ? restaurants.filter(this.createStateFilter(queryString))
        : restaurants;

      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        cb(results);
      }, 3000 * Math.random());
    },
    createStateFilter(queryString) {
      return state => {
        return (
          state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
        );
      };
    },
    handleSelect(item) {
      console.log(item);
    },
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.queryList(val.page);
    },
    //查看详情
    toDetail(supplierInfo) {
      sessionStorage.setItem("supplierCode", supplierInfo.supplierCode);
      this.$router.push({
        path: "/personnelManagement/supplierManagementDetail"
      });
    },
    //编辑
    toEdit(supplierInfo) {
      var path = "";
      if (supplierInfo !== undefined) {
        sessionStorage.setItem("supplierCode", supplierInfo.supplierCode);
        path = "/personnelManagement/supplierManagementEdit";
      } else {
        sessionStorage.setItem("supplierCode", undefined);
        path = "/personnelManagement/supplierManagementAdd";
      }
      this.$router.push({
        path: path
      });
    },
    queryList(page) {
      this.listLoading = true;
      this.searchLoading = true;
      this.filters.pageNum = page;
      querySupplier(this.filters)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            if (response.data.responseData != undefined) {
              this.listLoading = false;
              this.tableData = response.data.responseData;
              this.tableData.forEach(item => {
                item.agreementStartDate =
                  item.agreementStartDate !== undefined
                    ? item.agreementStartDate.substr(0, 10)
                    : "";
                item.agreementEndDate =
                  item.agreementEndDate !== undefined
                    ? item.agreementEndDate.substr(0, 10)
                    : "";
                item.supplierDetailAddress = this.detailAddress(item);
                return item;
              });
              this.totalCount = response.data.totalCount;
              this.searchLoading = false;
              this.listLoading = false;
            } else {
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("querySupplier:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    exportToExcel() {
      const tHeader = [
        "序号",
        "组织",
        "供应商名称",
        "科目(学校，家政，其它)",
        "企业对接人姓名",
        "企业联系电话",
        "地址区域(杨浦，虹口等)",
        "联系地址",
        "具体洽谈内容",
        "具体洽谈结果",
        "是否与我们签署协议",
        "协议开始时间",
        "协议结束时间",
        "具体洽谈费用",
        "备注"
      ];
      // 上面设置Excel的表格第一行的标题
      const filterVal = [
        "orderNum",
        "orgName",
        "supplierName",
        "subjectType",
        "contactsName",
        "contactsTel",
        "address",
        "supplierDetailAddress",
        "negotiationContent",
        "negotiationResult",
        "isSignAgreement",
        "agreementStartDate",
        "agreementEndDate",
        "negotiationFee",
        "remark"
      ];
      // 上面的index、phone_Num、school_Name是tableData里对象的属性
      const params = {
        pageNum: 1,
        pageSize: 100000,
        supplierName: this.filters.supplierName,
        subjectType: this.filters.subjectType,
        contactsName: this.filters.contactsName,
        contactsTel: this.filters.contactsTel,
        orgCode: this.filters.orgCode,
        isSignAgreement: this.filters.isSignAgreement
      };
      querySupplier(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            const list = response.data.responseData;
            if (list.length > 0) {
              list.forEach((item, index) => {
                item.orderNum = index + Number(1);
                item.negotiationContent =
                  item.negotiationContent !== undefined
                    ? item.negotiationContent
                    : "";
                item.negotiationResult =
                  item.negotiationResult !== undefined
                    ? item.negotiationResult
                    : "";
                item.negotiationFee =
                  item.negotiationFee !== undefined ? item.negotiationFee : "";
                item.remark = item.remark !== undefined ? item.remark : "";
                item.address = this.getDetailAddress(item);
                item.agreementStartDate =
                  item.agreementStartDate !== undefined
                    ? changeYMD(new Date(item.agreementStartDate))
                    : "";
                item.agreementEndDate =
                  item.agreementEndDate !== undefined
                    ? changeYMD(new Date(item.agreementEndDate))
                    : "";
                item.supplierDetailAddress =
                  item.supplierDetailAddress !== undefined
                    ? item.supplierDetailAddress
                    : "";
                return item;
              });
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, "供应商管理明细汇总");
            } else {
              this.$message.error("暂无数据，无法导出Excel");
              return false;
            }
          }
        })
        .catch(error => {
          console.log(error);
          this.searchLoading = false;
        });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    getDetailAddress(item) {
      var result = "";
      if (item.supplierProvinceName !== undefined) {
        result += item.supplierProvinceName;
      }
      if (item.supplierCityName !== undefined) {
        result += item.supplierCityName;
      }
      if (item.supplierDistrictName !== undefined) {
        result += item.supplierDistrictName;
      }
      // if (item.supplierDetailAddress !== undefined) {
      //   result += item.supplierDetailAddress;
      // }
      return result;
    },
    detailAddress(item) {
      var result = "";
      if (item.supplierProvinceName !== undefined) {
        result += item.supplierProvinceName;
      }
      if (item.supplierCityName !== undefined) {
        result += item.supplierCityName;
      }
      if (item.supplierDistrictName !== undefined) {
        result += item.supplierDistrictName;
      }
      if (item.supplierDetailAddress !== undefined) {
        result += item.supplierDetailAddress;
      }
      return result;
    },
    searchSubjectTypes() {
      findValueBySetCode({ valueSetCode: "SUBJECT_TYPE" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.subjectTypes = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    searchisAgreements() {
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.isSignAgreements = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    handleClose() {
      this.orgDialogVisible = false;
    },
    //获取组织返回的name和code
    getCurrentNode(val) {
      this.filters.orgName = val.orgName;
      this.filters.orgCode = val.orgCode;
      this.handleClose();
    },
    //清空组织过滤
    clearOrgCode() {
      this.filters.orgName = "";
      this.filters.orgCode = "";
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.orgCode = "";
      this.queryList(1);
    }
  },
  created() {
    // this.queryList(1);
    this.searchSubjectTypes();
    this.searchisAgreements();
  },
  activated() {
    this.queryList(1);
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
// 筛选框
#supplierManage {
  width: 100%;
  min-width: 1200px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  width: 28%;
  min-width: 280px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 90px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
.table {
  background-color: #ffffff;
  margin-left: 20px;
  margin-right: 20px;
}
.table-column {
  background-color: #398af1;
}
.content {
  background: #ffffff;
  //   margin-top: 20px;
  .search_btn {
    margin-left: 30px;
  }
}
.listClass {
  //   margin: 50px 0;
  background: "#ffffff";
  height: 40px;
  width: 100%;
}
.tableTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.searchBtn {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin-top: 20px;
}
</style>