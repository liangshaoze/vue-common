<template>
  <div id="supplierManage">
    <headTag :tagName="tagName" />

    <div class="formStyle">
      <el-row class="importToolbar">
        <el-col :span="24">
          <el-button size="small" type="primary" class="rightBtn" @click="cancelClick()">返回</el-button>
        </el-col>
      </el-row>
      <el-row>
        <el-form :model="supplierForm" ref="supplierForm" label-width="150px">
          <el-col class="form-item">
            <el-form-item label="组织：" prop="orgName">{{supplierForm.orgName}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="供应商名称：" prop="supplierName">{{supplierForm.supplierName}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="科目：" prop="subjectType">{{supplierForm.subjectTypeName}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系人：" prop="contactsName">{{supplierForm.contactsName}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="协议日期：">
              <span
                v-if="this.supplierForm.agreementStartDate"
              >{{this.supplierForm.agreementStartDate}}--{{this.supplierForm.agreementEndDate}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话：" prop="contactsTel">{{supplierForm.contactsTel}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="洽谈费用：" prop="negotiationFee">
              <span v-if="supplierForm.negotiationFee">{{supplierForm.negotiationFee | numFilter}}元</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item
              label="地区："
            >{{supplierForm.supplierProvinceName}}{{supplierForm.supplierCityName}}{{supplierForm.supplierDistrictName}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item
              label="联系地址："
              prop="supplierDetailAddress"
            >{{supplierForm.supplierDetailAddress}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item
              label="具体洽谈内容："
              prop="negotiationContent"
            >{{supplierForm.negotiationContent}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item
              label="具体洽谈结果："
              prop="negotiationResult"
            >{{supplierForm.negotiationResult}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注：" prop="remark">{{supplierForm.remark}}</el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议：" prop="isSignAgreement">{{supplierForm.isSignAgreementName}}</el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
  </div>
</template>
<script>
import HeadTag from "components/HeadTag";
import { getSupplierDetail } from "@/api/supplierManagement/supplierManagement.js";
import { log } from "util";
import { changeYMD, keepDecimalFull } from "utils/index.js";
export default {
  components: { HeadTag },
  data() {
    return {
      tagName: "查看供应商",
      supplierForm: {},
      showDate: false
    };
  },
  methods: {
    cancelClick: function() {
      this.$router.push({
        path: "/personnelManagement/supplierManagementList"
      });
    },
    queryDetail: function() {
      let params = {
        supplierCode: sessionStorage.getItem("supplierCode")
      };
      getSupplierDetail(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.supplierForm = response.data.responseData;
            var startDate = "";
            var endDate = "";

            if(this.supplierForm.negotiationFee) {
              this.supplierForm.negotiationFee = keepDecimalFull(
                this.supplierForm.negotiationFee,
                2
              );
            }

            if (this.supplierForm.agreementStartDate) {
              this.supplierForm.agreementStartDate = changeYMD(this.supplierForm.agreementStartDate)
              this.supplierForm.agreementEndDate = changeYMD(this.supplierForm.agreementEndDate)
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getSupplierDetail:"+error);
          return false;
        });
    }
  },
  created: function() {
    //获取详情
    this.queryDetail();
  },
  filters: {
    numFilter(value) {
      let realVal = "";
      if (value) {
        // 截取当前数据到小数点后两位
        realVal = parseFloat(value).toFixed(2);
      } else {
        realVal = "--";
      }
      return realVal;
    }
  }
};
</script>
<style lang="scss" scoped>
#supplierManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.formStyle {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #ffffff;
  border-radius: 10px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.remark-style {
  display: block;
  width: 300px;
}
.form-item {
  width: 30%;
  min-width: 470px;
}
</style>
<style lang="scss">
#supplierManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>