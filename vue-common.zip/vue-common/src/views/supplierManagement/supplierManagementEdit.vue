<template>
  <div id="supplierManage">
    <headTag :tagName="tagName" />

    <div class="formStyle">
      <el-row class="importToolbar">
        <el-col :span="24">
          <el-button size="small" type="primary" class="rightBtn" @click="cancelClick()">返回</el-button>
          <el-button
            size="small"
            type="primary"
            class="rightBtn"
            @click="submitForm('supplierForm')"
            :disabled="submitBtnDisabled"
          >保存</el-button>
        </el-col>
      </el-row>
      <el-row>
        <el-form
          :inline="false"
          :model="supplierForm"
          :rules="rules"
          ref="supplierForm"
          label-width="150px"
        >
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model="supplierForm.orgName"
                clearable
                placeholder="请选择组织"
                @focus="dialogVisible=true"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="供应商名称" prop="supplierName">
              <el-input
                size="mini"
                v-model="supplierForm.supplierName"
                clearable
                placeholder="请输入供应商名称"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="科目" prop="subjectType">
              <el-select
                size="mini"
                v-model="supplierForm.subjectType"
                clearable
                placeholder="请选择科目"
              >
                <el-option
                  v-for="item in subjectTypes"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系人" prop="contactsName">
              <el-input
                size="mini"
                v-model="supplierForm.contactsName"
                clearable
                placeholder="请输入联系人"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="协议日期">
              <el-date-picker
                v-model="agreementDate"
                size="mini"
                clearable
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @blur="choiceDatePicker"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="contactsTel">
              <el-input
                size="mini"
                v-model="supplierForm.contactsTel"
                clearable
                placeholder="请输入联系电话"
                maxlength="11"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="洽谈费用" prop="negotiationFee">
              <el-input
                size="mini"
                v-model="supplierForm.negotiationFee"
                clearable
                placeholder="请输入洽谈费用"
              >
                <template slot="append">(元)</template>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="地区" prop="supplierProvinceName">
              <AddressSelector
                :address="{pCode:supplierForm.supplierProvinceCode,cCode:supplierForm.supplierCityCode,dCode:supplierForm.supplierDistrictCode}"
                @selectedProvinceListener="selectedProvinceListener"
                @selectedCityListener="selectedCityListener"
                @selectedDistrictListener="selectedDistrictListener"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系地址" prop="supplierDetailAddress">
              <el-input
                size="mini"
                v-model="supplierForm.supplierDetailAddress"
                clearable
                placeholder="请输入联系地址"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈内容" prop="negotiationContent">
              <el-input
                type="textarea"
                v-model="supplierForm.negotiationContent"
                clearable
                size="mini"
                placeholder="请输入洽谈内容"
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈结果" prop="negotiationResult">
              <el-input
                type="textarea"
                v-model="supplierForm.negotiationResult"
                clearable
                size="mini"
                placeholder="请输入洽谈结果"
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注" prop="remark">
              <el-input
                type="textarea"
                v-model="supplierForm.remark"
                clearable
                size="mini"
                placeholder="请输入备注"
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议" prop="isSignAgreement">
              <el-radio-group v-model="supplierForm.isSignAgreement">
                <el-radio
                  v-for="item in isSignAgreements"
                  :key="item.value"
                  :label="item.value"
                >{{item.name}}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
    <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
      <org-select v-on:listenTochildEvent="getCurrentNode" />
    </el-dialog>
  </div>
</template>
<script>
import HeadTag from "components/HeadTag";
import { validateTel, isMoney } from "@/utils/validate";
import { getSupplierDetail } from "@/api/supplierManagement/supplierManagement.js";
import {
  saveSupplier,
  updateSupplier
} from "@/api/supplierManagement/supplierManagement.js";
import OrgSelect from "components/OrgSelect";
import AddressSelector from "components/AddressPicker/addressSelector";
import { findValueBySetCode } from "api/common";
export default {
  components: { HeadTag, OrgSelect, AddressSelector },
  data() {
    return {
      tagName: "修改供应商",
      rules: {
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        supplierName: [
          { required: true, message: "公司名称不能为空" },
          {
            type: "string",
            max: 50,
            message: "公司长度不能大于50位",
            trigger: "blur"
          }
        ],
        contactsName: [
          {
            type: "string",
            max: 20,
            message: "联系人长度不能大于20位",
            trigger: "blur"
          }
        ],
        contactsTel: [
          {
            type: "string",
            max: 20,
            message: "企业联系电话长度不能大于20位",
            trigger: "blur"
          }
        ],
        isSignAgreement: [{ required: true, message: "请勾选签署协议" }],
        negotiationFee: [{ validator: isMoney}]
      },
      agreementDate: [],
      supplierForm: {
        isSignAgreement: "0",
        agreementStartDate: "",
        agreementEndDate: "",
        orgName: this.$store.getters.userOrgName,
        orgCode: this.$store.getters.userOrgCode
      },
      provinces: [],
      cities: [],
      districts: [],
      //科目
      subjectTypes: [],
      orgInfos: [],
      dialogVisible: false,
      //签署协议
      isSignAgreements: [],
      submitBtnDisabled: false
    };
  },
  methods: {
    submitForm: function(formName) {
      var that = this;
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (that.supplierForm.supplierCode === undefined) {
            this.insertSupplier(that.supplierForm);
          } else {
            this.updateSupplier(that.supplierForm);
          }
        } else {
          return false;
        }
      });
    },
    cancelClick: function() {
      this.$router.push({
        path: "/personnelManagement/supplierManagementList"
      });
    },
    //获取协议日期开始结束时间
    choiceDatePicker() {
      this.$nextTick(() => {
        this.supplierForm.agreementStartDate = this.agreementDate[0];
        this.supplierForm.agreementEndDate = this.agreementDate[1];
      });
    },
    insertSupplier: function(supplierForm) {
      this.submitBtnDisabled = true;
      saveSupplier(supplierForm)
        .then(response => {
          this.submitBtnDisabled = false;
          if (response.data.statusCode == 200) {
            this.$message.success("新增成功");
            this.$router.push({
              path: "/personnelManagement/supplierManagementList"
            });
          } else {
            this.$message.error(response.data.statusMsg);
            this.submitBtnDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log("saveSupplier:" + error);
          this.submitBtnDisabled = false;
          return false;
        });
    },
    updateSupplier: function(supplierForm) {
      this.submitBtnDisabled = true;
      updateSupplier(supplierForm)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("修改成功");
            this.$router.push({
              path: "/personnelManagement/supplierManagementList"
            });
          } else {
            this.$message.error(response.data.statusMsg);
            this.submitBtnDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.submitBtnDisabled = false;
          return false;
        });
    },
    selectOrg(val) {
      var obj = {};
      obj = this.orgInfos.find(item => {
        return item.orgCode === val;
      });
      this.supplierForm.orgName = obj.orgName;
      this.supplierForm.orgCode = obj.orgCode;
    },
    queryDetail() {
      let params = {
        supplierCode: sessionStorage.getItem("supplierCode")
      };
      getSupplierDetail(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.supplierForm = response.data.responseData;
            if (this.supplierForm.negotiationFee) {
              this.supplierForm.negotiationFee = parseFloat(
                this.supplierForm.negotiationFee
              ).toFixed(2);
            }
            if(this.supplierForm.agreementStartDate) {
              this.agreementDate = [
                new Date(this.supplierForm.agreementStartDate),
                new Date(this.supplierForm.agreementEndDate)
              ]
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getSupplierDetail:"+error);
          return false;
        });
    },
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.supplierForm.orgName = data.orgName;
      this.supplierForm.orgCode = data.orgCode;
      this.handleClose();
    },
    selectedProvinceListener(obj) {
      this.supplierForm.supplierProvinceName = obj.name;
      this.supplierForm.supplierProvinceCode = obj.id;
      this.supplierForm.supplierCityName = "";
      this.supplierForm.supplierCityCode = "";
      this.supplierForm.supplierDistrictName = "";
      this.supplierForm.supplierDistrictCode = "";
    },
    selectedCityListener(obj) {
      this.supplierForm.supplierCityName = obj.name;
      this.supplierForm.supplierCityCode = obj.id;
      this.supplierForm.supplierDistrictName = "";
      this.supplierForm.supplierDistrictCode = "";
    },
    selectedDistrictListener(obj) {
      this.supplierForm.supplierDistrictName = obj.name;
      this.supplierForm.supplierDistrictCode = obj.id;
    },
    searchSubjectTypes() {
      findValueBySetCode({ valueSetCode: "SUBJECT_TYPE" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.subjectTypes = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:"+error);
          return false;
        });
    },
    searchisAgreements() {
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.isSignAgreements = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:"+error);
          return false;
        });
    }
  },
  created: function() {
    this.$nextTick(() => {
      var result = sessionStorage.getItem("supplierCode");
      if (result !== "undefined") {
        this.queryDetail();
        this.tagName = "修改供应商";
      } else {
        this.tagName = "新增供应商";
      }
    });
    this.searchSubjectTypes();
    this.searchisAgreements();
  }
};
</script>
<style lang="scss" scoped>
#supplierManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.formStyle {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #ffffff;
  border-radius: 10px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.remark-style {
  display: block;
  width: 300px;
}
.form-item {
  width: 30%;
  min-width: 470px;
}
</style>
<style lang="scss">
#supplierManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>