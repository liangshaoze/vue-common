<template>
	<div id="orderManage">
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form :inline="true" ref="filterForm" :model="filters" label-width="125px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="订单号" prop="orderCode">
							<el-input size="mini" v-model.trim="filters.orderCode" clearable placeholder="请输入订单号"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="审核时间" prop="reviewRangeDate">
							<el-date-picker
								v-model.trim="filters.reviewRangeDate"
								clearable
								size="mini"
								value-format="yyyy-MM-dd"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="客户联系方式" prop="customerTel">
							<el-input
								size="mini"
								v-model.trim="filters.customerTel"
								clearable
								placeholder="请输入联系方式"
								maxlength="11"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="订单状态" prop="orderStatus">
							<el-select size="mini" v-model.trim="filters.orderStatus" clearable placeholder="请选择">
								<el-option
									v-for="item in orderStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="支付方式" prop="payType">
							<el-select size="mini" v-model.trim="filters.payType" clearable placeholder="请选择支付方式">
								<el-option
									v-for="item in payTypeOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="付款状态" prop="payStatus">
							<el-select size="mini" v-model.trim="filters.payStatus" clearable placeholder="请选择状态">
								<el-option
									v-for="item in payStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="产品名称" prop="productName">
							<el-input size="mini" v-model.trim="filters.productName" clearable placeholder="请输入产品名称"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="审核状态" prop="auditStatus">
							<el-select size="mini" v-model.trim="filters.auditStatus" clearable placeholder="请选择支付方式">
								<el-option
									v-for="item in auditStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="订单来源" prop="orderSource">
							<el-select size="mini" v-model.trim="filters.orderSource" clearable placeholder="请选择状态">
								<el-option
									v-for="item in orderSourceOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="费用类型" prop="feeType">
							<el-select size="mini" v-model.trim="filters.feeType" clearable placeholder="请选择状态">
								<el-option
									v-for="item in feeTypeOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								v-if="showList.customer_list_search"
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="getOrders(1)"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-upload" @click="exportOrderPay()">导出</el-button>
				</el-col>
			</el-row>
			<!--列表-->
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				stripe
				size="mini"
				:data="orderList"
				v-loading="listLoading"
				highlight-current-row
				element-loading-text="拼命加载中"
			>
				<el-table-column label="订单号" width="130" prop="orderCode"></el-table-column>
				<el-table-column label="订单状态" min-width="80" prop="orderStatusValue"></el-table-column>
				<el-table-column label="费用类型" min-width="80" prop="feeTypeValue"></el-table-column>
				<el-table-column label="付款状态" min-width="80" prop="payStatusValue"></el-table-column>
				<el-table-column label="审核状态" min-width="70" prop="auditStatusValue"></el-table-column>
				<el-table-column label="客户联系方式" width="120" prop="customerTel"></el-table-column>
				<el-table-column label="被照护人姓名" min-width="120" prop="careReceiverName"></el-table-column>
				<el-table-column label="被照护人身份证号" width="160" prop="careReceiverIdCard"></el-table-column>
				<el-table-column label="产品名称" min-width="70" prop="productName"></el-table-column>
				<el-table-column label="服务起止日期" width="200" prop="serviceDate">
					<template slot-scope="scope">
						<span
							v-if="scope.row.serviceStartDate"
						>{{scope.row.serviceStartDate}}---{{scope.row.serviceEndDate}}</span>
					</template>
				</el-table-column>
				<el-table-column label="销售价(元)" min-width="90" prop="sellPrice"></el-table-column>
				<el-table-column label="退款金额(元)" min-width="90" prop="refundFee"></el-table-column>
				<el-table-column label="差价金额(元)" min-width="90" prop="needAddFee"></el-table-column>
				<el-table-column label="订单来源" min-width="70" prop="orderSourceValue"></el-table-column>
				<el-table-column label="支付方式" min-width="70" prop="payTypeValue"></el-table-column>
				<!-- <el-table-column label="关联订单号" min-width="120" prop="relationOrderCode"></el-table-column> -->
				<el-table-column label="备注" min-width="100" prop="remark"></el-table-column>
				<el-table-column label="创建时间" width="135" prop="createDate"></el-table-column>
				<!-- <el-table-column label="退款申请时间" min-width="120" prop="feeCreateDate"></el-table-column> -->
				<el-table-column label="支付时间" width="135" prop="payDate"></el-table-column>
				<el-table-column label="审核时间" width="135" prop="auditDate"></el-table-column>
				<el-table-column label="审核人" min-width="70" prop="auditUserName"></el-table-column>
				<el-table-column fixed="right" min-width="50" label="操作">
					<template slot-scope="scope">
						<el-button
							size="mini"
							type="text"
							@click="handleOrder(scope.row.orderCode,scope.row.feeCode)"
							v-if="scope.row.orderSource==10&&(scope.row.auditStatus==10||scope.row.auditStatus==20)"
						>审核</el-button>
						<!-- <span v-if="scope.row.auditStatus==10">审核通过</span> -->
						<el-button
							size="mini"
							type="text"
							@click="offlineAudit(scope.row.orderCode,scope.row.feeCode)"
							v-if="scope.row.orderSource==20&&(scope.row.auditStatus==10||scope.row.auditStatus==20)"
						>审核</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filters.page"
					:limit.sync="filters.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
			<el-dialog
				title="是否确定审核该订单？"
				:visible.sync="dialogAuditOrder"
				width="30%"
				:before-close="handleClose"
				center
			>
				<el-form
					:rules="formAuditRules"
					ref="formAuditOrder"
					:model="formAuditOrder"
					label-width="100px"
				>
					<el-form-item label="支付时间:" prop="payDate">
						<el-date-picker
							size="mini"
							type="datetime"
							placeholder="请选择时间"
							v-model="formAuditOrder.payDate"
							format="yyyy-MM-dd HH:mm:ss"
							value-format="yyyy-MM-dd HH:mm:ss"
							:picker-options="expireTimeOption"
						></el-date-picker>
					</el-form-item>
				</el-form>
				<div slot="footer" class="dialog-footer" style="text-align:center">
					<el-button
						size="mini"
						style="margin-top:20px;"
						type="primary"
						@click="okFundOrder('formAuditOrder')"
						:disabled="isDisabled"
					>确 定</el-button>
					<el-button size="mini" @click="cancelFundOrder('formAuditOrder')">取 消</el-button>
				</div>
			</el-dialog>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";

import { findValueBySetCode } from "api/common";
import {
	findProductOrderFeeAuditList,
	updateMsProductOrderFeeForAudit,
	updateEtProductOrderFeeForAudit
} from "api/businessService/orderPaymentReview";
import { changeYMD } from "utils";
import { hasPermission } from "utils/button";
import { export_json_to_excel } from "@/utils/Export2Excel.js";

export default {
	data () {
		return {
			showList: {
				customer_list_search: true,
				customer_list_add: true,
				customer_list_export: true,
				customer_list_see: true
			},
			tagName: "订单支付审核",
			orderList: [],
			dialogAuditOrder: false,
			//控制查询按钮加载
			searchLoading: false,
			isDisabled: false,
			formFundRules: {},
			formFundOrder: {
				orderPrice: ""
			},
			auditOrderCode: "",
			auditFeeCode: "",
			auditOrderSource: "",
			expireTimeOption: {
				disabledDate (datetime) {
					return datetime.getTime() > Date.now();
				}
			},
			formAuditRules: {
				payDate: [
					{
						type: "string",
						required: true,
						message: "请选择日期",
						trigger: "change"
					}
				]
			},
			formAuditOrder: {
				payDate: ""
			},
			listLoading: false,
			//条件查询
			filters: {
				orderCode: "", //订单CODE
				careReceiverName: "", //被照护人姓名
				careReceiverTel: "", //被照护人联系方式
				customerTel: "", //客户联系方式
				reviewRangeDate: [],
				auditDateB: "",
				auditDateE: "",
				orderStatus: "", //订单状态（10.待确认，20.服务中，30.服务完成，40.服务关闭）
				payStatus: "", //支付状态（10.待付款，20.已付款，30.补差价，40.退款中，50.已退款）
				productName: "", //产品名称
				orderSource: "", //订单来源(10.线上，20.线下)
				payType: "", //支付方式（10微信,20支付宝）
				auditStatus: "", //审核状态（10.审核中，20.审核通过,30.审核不通过）
				page: 1,
				pageSize: 10,
				feeType: ""
			},
			totalCount: 0,
			listLoading: false,
			//订单状态
			orderStatusOptions: [],
			//付款状态
			payStatusOptions: [],
			//支付方式
			payTypeOptions: [],
			//订单来源
			orderSourceOptions: [],
			//审核状态
			auditStatusOptions: [],
			//费用类型
			feeTypeOptions: []
		};
	},
	components: {
		HeadTag,
		Pagination
	},

	watch: {
		// "filters.reviewRangeDate": function(val) {
		//   this.filters.auditDateB =
		//     this.filters.reviewRangeDate != null
		//       ? this.filters.reviewRangeDate[0]
		//       : "";
		//   this.filters.auditDateE =
		//     this.filters.reviewRangeDate != null
		//       ? this.filters.reviewRangeDate[1]
		//       : "";
		// }
	},
	methods: {
		resetForm () {
			this.$refs.filterForm.resetFields();
			this.getOrders();
		},
		//导出审核订单
		exportOrderPay () {
			const tHeader = [
				"序号",
				"订单号",
				"订单状态",
				"费用类型",
				"付款状态",
				"审核状态",
				"客户联系方式",
				"被照护人姓名",
				"被照护人身份证号",
				"产品名称",
				"服务起止日期",
				"销售价（元）",
				"退款金额(元)",
				"差价金额(元)",
				"订单来源",
				"支付方式",
				// "关联订单号",
				"备注",
				"创建时间",
				"支付时间",
				"审核时间",
				"审核人"
			];
			// 上面设置Excel的表格第一行的标题
			const filterVal = [
				"orderNum",
				"orderCode",
				"orderStatusValue",
				"feeTypeValue",
				"payStatusValue",
				"auditStatusValue",
				"customerTel",
				"careReceiverName",
				"careReceiverIdCard",
				"productName",
				"serviceDate",
				"sellPrice",
				"refundFee",
				"needAddFee",
				"orderSourceValue",
				"payTypeValue",
				// "relationOrderCode",
				"remark",
				"createDate",
				"payDate",
				"auditDate",
				"auditUserName"
			];
			const params = {
				pageNum: 1,
				pageSize: 100000,
				orderCode: this.filters.orderCode,
				careReceiverName: this.filters.careReceiverName,
				auditDateB: (this.filters.reviewRangeDate && this.filters.reviewRangeDate.length > 0) ? (this.filters.reviewRangeDate[0] + " 00:00:00") : null,
				auditDateE: (this.filters.reviewRangeDate && this.filters.reviewRangeDate.length > 0) ? (this.filters.reviewRangeDate[1] + " 23:59:59") : null,
				customerTel: this.filters.customerTel,
				orderSource: this.filters.orderSource,
				payStatus: this.filters.payStatus,
				productName: this.filters.productName,
				payType: this.filters.payType,
				feeType: this.filters.feeType,
				orderStatus: this.filters.orderStatus
			};
			findProductOrderFeeAuditList(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						const list = response.data.responseData;
						if (list.length > 0) {
							list.forEach((item, index) => {
								item.orderNum = index + Number(1);
								item.remark = item.remark !== undefined ? item.remark : "";
								// item.createDate =
								//   item.createDate !== undefined
								//     ? changeYMD(new Date(item.createDate))
								//     : "";
								// item.feeCreateDate =
								//   item.feeCreateDate !== undefined
								//     ? changeYMD(new Date(item.feeCreateDate))
								//     : "";
								// item.auditDate =
								//   item.auditDate !== undefined
								//     ? changeYMD(new Date(item.auditDate))
								//     : "";
								item.serviceStartDate =
									item.serviceStartDate !== undefined
										? changeYMD(new Date(item.serviceStartDate))
										: "";
								item.serviceEndDate =
									item.serviceEndDate !== undefined
										? changeYMD(new Date(item.serviceEndDate))
										: "";
								item.serviceDate = this.getDate(item);
								return item;
							});
							const data = this.formatJson(filterVal, list);
							export_json_to_excel(tHeader, data, "订单审核管理");
						} else {
							this.$message.error("暂无数据，无法导出Excel");
							return false;
						}
					}
				})
				.catch(error => {
					console.log(error);
					this.searchLoading = false;
				});
		},
		formatJson (filterVal, jsonData) {
			return jsonData.map(v => filterVal.map(j => v[j]));
		},
		getDate (item) {
			var result = "";
			if (item.serviceStartDate !== undefined) {
				result += item.serviceStartDate;
			}
			if (item.serviceEndDate !== undefined) {
				result += "-" + item.serviceEndDate;
			}
			return result;
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getOrders(val.page); //改变页码，重新渲染页面
		},
		//获取订单列表
		getOrders (page) {
			this.filters.page = page;
			var params = {
				pageNum: page,
				pageSize: this.filters.pageSize,
				orderCode: this.filters.orderCode,
				careReceiverName: this.filters.careReceiverName,
				createDate: this.filters.createDate,
				customerTel: this.filters.customerTel,
				careReceiverIdCard: this.filters.careReceiverIdCard,
				orderSource: this.filters.orderSource,
				productName: this.filters.productName,
				payStatus: this.filters.payStatus,
				payType: this.filters.payType,
				feeType: this.filters.feeType,
				auditStatus: this.filters.auditStatus,
				orderStatus: this.filters.orderStatus,
				auditDateB: (this.filters.reviewRangeDate && this.filters.reviewRangeDate.length > 0) ? (this.filters.reviewRangeDate[0] + " 00:00:00") : null,
				auditDateE: (this.filters.reviewRangeDate && this.filters.reviewRangeDate.length > 0) ? (this.filters.reviewRangeDate[1] + " 23:59:59") : null,
			};
			this.listLoading = true;
			this.searchLoading = true;
			findProductOrderFeeAuditList(params)
				.then(response => {
					if (response.data.responseData != undefined) {
						if (response.data.statusCode == 200 || response.data.statusCode == "200") {
							this.orderList = response.data.responseData;
							for (let i = 0; i < this.orderList.length; i++) {
								this.orderList[i].serviceStartDate = changeYMD(
									this.orderList[i].serviceStartDate
								);
								this.orderList[i].serviceEndDate = changeYMD(
									this.orderList[i].serviceEndDate
								);
							}
							this.totalCount = response.data.totalCount;
							this.listLoading = false;
							this.searchLoading = false;
						} else {
							this.$message.error(response.data.statusMsg);
							this.listLoading = false;
							this.searchLoading = false;
							return false;
						}
					} else {
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findStaffList:" + error);
					this.listLoading = false;
					this.searchLoading = false;
					return false;
				});
		},
		//审核
		handleOrder (orderCode, feeCode) {
			var params = {
				orderCode: orderCode,
				feeCode: feeCode
			};
			updateMsProductOrderFeeForAudit(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.$message.success("审核成功~");
						this.getOrders(1);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("updateProductOrderFeeForAudit:" + error);
					// this.$message.error(response.data.statusMsg);
					return false;
				});
		},
		//线下审核
		offlineAudit (orderCode, feeCode) {
			this.auditOrderCode = orderCode;
			this.auditFeeCode = feeCode;
			// this.auditOrderSource = orderSource;
			this.dialogAuditOrder = true;
		},
		handleClose () {
			this.dialogAuditOrder = false;
			this.formAuditOrder.payDate = "";
		},
		getAuditfund () {
			this.isDisabled = true;
			var params = {
				orderCode: this.auditOrderCode,
				feeCode: this.auditFeeCode,
				// orderSource: this.auditOrderSource,
				payDate: this.formAuditOrder.payDate
			};
			updateEtProductOrderFeeForAudit(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.$message.success("操作成功");
						this.dialogAuditOrder = false;
						this.isDisabled = false;
						this.getOrders(1);
					} else {
						this.$message.error(response.data.statusMsg);
						this.isDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.isDisabled = false;
					// this.$message.error(response.data.statusMsg);
					return false;
				});
		},
		okFundOrder (formAuditOrder) {
			this.isDisabled = true;
			this.$refs[formAuditOrder].validate(valid => {
				if (valid) {
					this.getAuditfund();
					this.$refs[formAuditOrder].resetFields();
				} else {
					this.isDisabled = false;
					return false;
				}
			});
		},
		cancelFundOrder (formAuditOrder) {
			this.dialogAuditOrder = false;
			this.$refs[formAuditOrder].resetFields();
		},
		/**
		 *
		 * 数据字典
		 *
		 */
		initDataDictionary () {
			//订单状态
			findValueBySetCode({ valueSetCode: "ORDER_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.orderStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//付款状态
			findValueBySetCode({ valueSetCode: "PAY_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.payStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//订单来源
			findValueBySetCode({ valueSetCode: "ORDER_SOURCE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.orderSourceOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//支付方式
			findValueBySetCode({ valueSetCode: "PAY_TYPE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.payTypeOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//审核状态
			findValueBySetCode({ valueSetCode: "AUDIT_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.auditStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//费用类型
			findValueBySetCode({ valueSetCode: "FEE_TYPE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.feeTypeOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		/**
		 *
		 * 按钮权限
		 *
		 */
		buttonControl () {
			this.showList.customer_list_search = hasPermission(
				"customer_list_search"
			);
			this.showList.customer_list_add = hasPermission("customer_list_add");
			this.showList.customer_list_export = hasPermission(
				"customer_list_export"
			);
			this.showList.customer_list_see = hasPermission("customer_list_see");
		}
	},
	created () {
		//初始化按钮权限
		// this.buttonControl()
		//初始化数据字典
		this.initDataDictionary();
		// this.getOrders(1);
		// this.$watch("filters.reviewRangeDate");
	},
	mounted () {
		//初始化加载订单
		// this.getOrders(1);
		// this.restaurants = this.loadAll();
	},
	activated () {
		this.getOrders(1);
	}
};
</script>

<style lang="scss" scoped>
#orderManage {
	width: 100%;
	min-width: 1200px;
	.el-form-item {
		margin-bottom: 0px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.search_btn {
	min-width: 250px;
	margin-left: 125px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.pic_icon {
	width: 20px;
	height: 20px;
}
.fund-order {
	margin: 20px 0;
}
</style>
<style lang="scss">
#orderManage {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
</style>