<template>
	<div id="staffscheduling">
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->

		<div class="filter_wrap">
			<el-form :inline="true" ref="filterForm" :model="filters" label-width="115px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="filters.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务人员" prop="careGiverName">
							<el-input size="mini" v-model.trim="filters.careGiverName" clearable placeholder="请输入服务人员"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-items">
						<el-form-item label="服务日期" prop="selectDay">
							<el-select
								v-model="filters.serviceFrequencyType"
								@clear="clearDate"
								clearable
								size="mini"
								style="width:85px"
								@change="selectDate"
								placeholder="请选择"
							>
								<el-option label="周" value="10"></el-option>
								<el-option label="月" value="20"></el-option>
							</el-select>
							<el-select
								v-if="isDay"
								v-model="filters.selectDay"
								:disabled="isDateDisabled"
								multiple
								filterable
								allow-create
								default-first-option
								size="mini"
								placeholder="请选择服务日期"
							>
								<el-option
									v-for="item in schedlingStaffOptions"
									:key="item.planDay"
									:label="item.planDayStr"
									:value="item.planDay"
								></el-option>
							</el-select>
							<el-select
								v-if="isDate"
								v-model="filters.selectDay"
								:disabled="isDayDisabled"
								multiple
								filterable
								allow-create
								default-first-option
								size="mini"
								placeholder="请选择服务日期"
							>
								<el-option
									v-for="item in dateStaffOptions"
									:key="item.planDay"
									:label="item.planDayStr"
									:value="item.planDay"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="queryGetList()"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="insertWorkOrders()">新增排程</el-button>
					<el-button size="mini" type="primary" icon="el-icon-date" @click="staffOrders()">员工工单</el-button>
					<el-button
						size="mini"
						type="primary"
						icon="el-icon-s-custom"
						@click="changeCareGiverName()"
					>更换服务人员</el-button>
					<el-button size="mini" type="danger" icon="el-icon-delete" @click="selectDelete()">删除排程</el-button>
				</el-col>
			</el-row>
			<!-- 列表 -->
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				stripe
				ref="multipleTable"
				size="mini"
				:data="workOrderList"
				v-loading="listLoading"
				highlight-current-row
				@selection-change="handleSelectionChange"
				element-loading-text="拼命加载中"
			>
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="服务人员" min-width="100" prop="careGiverName"></el-table-column>
				<el-table-column label="被照护人姓名" min-width="100" prop="careReceiverName"></el-table-column>
				<el-table-column label="被照护人身份证号" min-width="200" prop="careReceiverIdCard"></el-table-column>
				<el-table-column label="服务日期" min-width="120" prop="planDay">
					<template slot-scope="scope">
						<span v-if="scope.row.serviceFrequencyType == 20">{{scope.row.planDay}}日</span>
						<span v-else>{{scope.row.planDay}}</span>
					</template>
				</el-table-column>
				<el-table-column label="服务时间" min-width="160">
					<template slot-scope="scope">
						<span v-if="scope.row.planStartTime">{{scope.row. planStartTime}}---{{scope.row.planEndTime}}</span>
					</template>
				</el-table-column>
				<el-table-column label="订单号" min-width="140" prop="orderCode"></el-table-column>
				<el-table-column label="组织" min-width="140" prop="orgName"></el-table-column>
				<el-table-column fixed="right" label="操作" width="80">
					<template slot-scope="scope">
						<el-button size="mini" type="text" @click="editOrder(scope.row.scheduleCode)">修改</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filters.page"
					:limit.sync="filters.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
			<!-- 新建排程弹窗 -->
			<el-dialog
				title="新增排程"
				width="600px"
				:close-on-click-modal="false"
				:visible.sync="dialogWorkOrder"
				:before-close="handleOrderClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formStaffWorkOrderRules"
						ref="formStaffWorkOrder"
						:model="formStaffWorkOrder"
						label-width="150px"
					>
						<el-form-item class="workOrderClass" prop="productName" label="产品名称">
							<el-autocomplete
								:trigger-on-focus="true"
								v-model="formStaffWorkOrder.productName"
								size="mini"
								clearable
								:fetch-suggestions="queryProductTypeName"
								placeholder="请输入产品名称"
								@select="selectProductTypeName"
								@input="removeProductTypeName"
							></el-autocomplete>
						</el-form-item>
						<el-form-item label="被照护人姓名" prop="careReceiverName" class="workOrderClass">
							<el-autocomplete
								:trigger-on-focus="true"
								popper-class="my-autocomplete"
								v-model="formStaffWorkOrder.careReceiverName"
								size="mini"
								clearable
								:fetch-suggestions="queryCareReceiverName"
								:disabled="receiverNameDisabled"
								placeholder="请输入被照护人姓名"
								@select="selectCareReceiverName"
								@blur="removeCareReceiverName"
								@clear="removeCareReceiverName"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.careReceiverTel }})</span>
									</span>
								</template>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="组织" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formStaffWorkOrder.orgName"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="订单号" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formStaffWorkOrder.orderCode"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="服务人员" class="workOrderClass" prop="careGiverName">
							<el-autocomplete
								:trigger-on-focus="true"
								style="width:340px;margin-top:5px"
								v-model="formStaffWorkOrder.careGiverName"
								popper-class="my-autocomplete"
								size="mini"
								clearable
								:fetch-suggestions="queryStaffName"
								placeholder="请输入员工姓名"
								@select="selectStaffName"
								@blur="removeStaffCode"
								@clear="removeStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span
											v-if="item.value != '无'"
											:title="item.value+item.staffTel+item.positionName"
										>({{ item.staffTel }}){{ item.positionName }}</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:80px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务岗位">
							<el-radio-group v-model="formStaffWorkOrder.servicePositionCode">
								<el-radio label="GW1911270089">护理员</el-radio>
								<el-radio label="GW1911270063">护士</el-radio>
							</el-radio-group>
						</el-form-item>
						<ScheduleTags
							ref="scheduleTags"
							v-if="dialogWorkOrder"
							:careReceiver="careReceiver"
							:formStaffWorkOrder="formStaffWorkOrder"
							:isEdit="false"
							:serviceDuration="serviceDuration"
						/>
					</el-form>
				</el-row>
				<div slot="footer" style="margin-left:100px;" class="dialog-footer">
					<el-button
						size="mini"
						style="margin-right:10px;"
						@click="cancleWorkOrder('formStaffWorkOrder')"
					>取消</el-button>
					<el-button
						size="mini"
						type="primary"
						style="margin-right:10px;"
						:disabled="cancleDisabled"
						@click="workOrderSubmit('formStaffWorkOrder')"
					>确 定</el-button>
					<el-checkbox size="mini" v-model="isScheduling" label="是否继续给该服务人员排程"></el-checkbox>
				</div>
			</el-dialog>
			<!-- 修改工单 -->
			<el-dialog
				title="修改排程"
				width="600px"
				:close-on-click-modal="false"
				:visible.sync="dialogEidtOrder"
				:before-close="handleEditOrderClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formEditStaffOrderRules"
						ref="formEditStaffOrder"
						:model="formEditStaffOrder"
						label-width="150px"
					>
						<el-form-item class="workOrderClass" prop="productName" label="产品名称">
							<el-autocomplete
								:trigger-on-focus="true"
								v-model="formEditStaffOrder.productName"
								size="mini"
								clearable
								:disabled="true"
								:fetch-suggestions="queryProductTypeName"
								placeholder="请输入产品名称"
								@select="selectProductTypeName"
								@input="removeProductTypeName"
							></el-autocomplete>
						</el-form-item>
						<el-form-item label="被照护人姓名" prop="careReceiverName" class="workOrderClass">
							<el-autocomplete
								:trigger-on-focus="true"
								popper-class="my-autocomplete"
								v-model="formEditStaffOrder.careReceiverName"
								size="mini"
								:disabled="true"
								clearable
								:fetch-suggestions="queryCareReceiverName"
								placeholder="请输入被照护人姓名"
								@select="selectCareReceiverName"
								@input="removeCareReceiverName"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.careReceiverTel }})</span>
									</span>
								</template>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="组织" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formEditStaffOrder.orgName"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="订单号" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formEditStaffOrder.orderCode"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="服务人员" class="workOrderClass" prop="careGiverName">
							<el-autocomplete
								:trigger-on-focus="true"
								style="width:340px;margin-top:5px"
								v-model="formEditStaffOrder.careGiverName"
								popper-class="my-autocomplete"
								size="mini"
								clearable
								:fetch-suggestions="queryStaffName"
								placeholder="请输入员工姓名"
								@select="selectStaffName"
								@blur="removeStaffCode"
								@clear="removeStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name" title="item.value">
										{{ item.value }}
										<span
											v-if="item.value != '无'"
											:title="item.value+item.staffTel+item.positionName"
										>({{ item.staffTel }}){{ item.positionName }}</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:80px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="服务岗位" class="workOrderClass">
							<el-radio-group v-model="formEditStaffOrder.servicePositionCode">
								<el-radio label="GW1911270089">护理员</el-radio>
								<el-radio label="GW1911270063">护士</el-radio>
							</el-radio-group>
						</el-form-item>
						<ScheduleTags
							ref="scheduleTagsOfUpdate"
							v-if="dialogEidtOrder"
							:isEdit="true"
							:careReceiver="careReceiver"
							:formStaffWorkOrder="formEditStaffOrder"
							:serviceDuration="serviceDuration"
						/>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="cancleEditOrder('formEditStaffOrder')">取消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						:disabled="cancleDisabled"
						type="primary"
						@click="editOrderSubmit('formEditStaffOrder')"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 批量删除排程 -->
			<el-dialog
				title="删除排程"
				:close-on-click-modal="false"
				:visible.sync="dialogBatchDeleteOrder"
				width="500px"
				:before-close="handleBatchDelteClose"
				center
			>
				<el-row type="flex" justify="center">
					<h4>是否确定删除选中的员工排程？</h4>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="submitBatchOrder()"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 批量更改护理人员 -->
			<el-dialog
				title="是否确定更换选中排程的服务人员?"
				:close-on-click-modal="false"
				:visible.sync="dialogCareGiverName"
				width="500px"
				:before-close="handleCareGiveNmaeClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="true"
						:rules="formCareGiverNameRules"
						ref="formCareGiverName"
						:model="formCareGiverName"
						label-width="120px"
					>
						<el-form-item label="服务人员" prop="careGiverName">
							<el-autocomplete
								size="mini"
								style="width: 270px;margin-top:5px"
								:trigger-on-focus="true"
								v-model="formCareGiverName.careGiverName"
								popper-class="my-autocomplete"
								clearable
								:fetch-suggestions="queryEditStaffName"
								placeholder="请输入员工姓名"
								@select="selectEditStaffName"
								@input="removeEditStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.staffTel }})</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:90px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="careGiverNameCancel('formCareGiverName')">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="submitCareGiverName('formCareGiverName')"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 组织 -->
			<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
				<org-select v-on:listenTochildEvent="getCurrentNode" />
			</el-dialog>
			<StaffSchedule
				ref="staffScheduleDialog"
				v-if="staffScheduleVisible"
				:staffScheduleVisible="staffScheduleVisible"
				:isWeekDay="isWeekDay"
				@onStaffScheduleClose="onStaffScheduleClose"
			/>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import { changeYMD, parseTime } from "utils";
import StaffSchedule from "@/views/businessService/staffSchedule";
import { findValueBySetCode } from "api/common";
import Pagination from "components/Pagination/pagination";
import ScheduleTags from "@/components/ScheduleTags"

import {
	findWorkorderScheduleList,
	batchAddWorkorderSchedule,
	findInServiceOrderList,
	findEtProductByDataAuthority,
	getWorkorderDetail,
	selectGiverListForSchedule,
	findWorkorderScheduleByScheduleCode,
	editWorkorderScheduleDetail,
	getOrderDetail,
	deleteWorkorderScheduleByCheckBox,
	updateCareGiverBySchedule
} from "api/workOrderManagement";
import { validateOrderTime } from "utils/validate";
export default {
	components: {
		HeadTag,
		StaffSchedule,
		Pagination,
		OrgSelect,
		ScheduleTags
	},
	props: {},
	data () {
		return {
			pickerOptions: {
				disabledDate (time) {
					return time.getTime() < Date.now() - 8.64e7;
				}
			},
			tagName: "排程信息",
			searchLoading: false,
			workOrderList: [],
			listLoading: false,
			totalCount: 0,
			orgcodeDisabled: true,
			multipleSelection: [],
			sideType: "10",
			isDate: false,
			isDay: true,
			editDistinguishStatus: "",
			//新建工单
			dialogWorkOrder: false,
			//批量删除工单
			dialogBatchDeleteOrder: false,
			staffSelectCodeList: [],
			//批量更改护理人员
			dialogCareGiverName: false,
			formCareGiverNameRules: {
				careGiverName: [
					{
						required: true,
						message: "请输入护理人员姓名",
						trigger: "change"
					}
				],
			},
			formCareGiverName: {
				careGiverName: '',
				careGiverCode: '',
				scheduleCodes: []
			},
			dialogEidtOrder: false,
			formEditStaffOrderRules: {
				productName: [
					{
						required: true,
						message: "请选择产品名称",
						trigger: "change"
					}
				],
				careReceiverName: [
					{
						required: true,
						message: "请选择被照护人姓名",
						trigger: "change"
					}
				],
				careGiverName: [
					{
						required: true,
						message: "请选择服务人员姓名",
						trigger: "change"
					}
				],
				servicePositionCode: [
					{
						required: true,
						message: "请选择服务岗位",
						trigger: "change"
					}
				],
				planStartTime: [
					{
						required: true,
						message: "请选择开始时间",
						trigger: "input"
					}
				],
				planServiceDuration: [
					{
						required: true,
						message: "请输入服务时长",
						trigger: "blur"
					},
					{
						validator: validateOrderTime
					}
				]
			},
			formStaffWorkOrderRules: {
				productName: [
					{
						required: true,
						message: "请选择产品名称",
						trigger: "change"
					}
				],
				careReceiverName: [
					{
						required: true,
						message: "请选择被照护人姓名",
						trigger: "change"
					}
				],
				careGiverName: [
					{
						required: true,
						message: "请选择服务人员姓名",
						trigger: "change"
					}
				],
				servicePositionCode: [
					{
						required: true,
						message: "请选择服务岗位",
						trigger: "change"
					}
				],
				planStartDate: [
					{
						required: true,
						message: "请选择开始时间",
						trigger: "change"
					}
				],
				planServiceDuration: [
					{
						required: true,
						message: "请输入服务时长",
						trigger: "blur"
					},
					{
						validator: validateOrderTime
					}
				]
			},
			editStartDate: "",
			editEndDate: "",
			startDate: "",
			endDate: "",
			WorkOrderForSettleList: [],
			formStaffWorkOrder: {
				productCode: "",
				careReceiverCode: "",
				productName: "", //产品名称
				careReceiverName: "", //被照护人姓名
				orgCode: "",
				orgName: "",
				orderCode: "",
				planStartTime: "",
				planServiceDuration: "",
				planEndTime: "",
				servicePositionCode: "GW1911270089",
				servicePositionName: "护理员",
				careGiverCode: "",
				careGiverName: "",
				workorderScheduleServiceList: [] //新增
			},
			formEditStaffOrder: {
				productCode: "",
				careReceiverCode: "",
				productName: "", //产品名称
				careReceiverName: "", //被照护人姓名
				orgCode: "",
				orgName: "",
				orderCode: "",
				planStartTime: "",
				planServiceDuration: "",
				planEndTime: "",
				servicePositionCode: "GW1911270089",
				servicePositionName: "护理员",
				careGiverCode: "",
				careGiverName: "",
				workorderScheduleServiceList: []//编辑
			},
			isScheduling: false,
			//组织
			dialogVisible: false,
			//保存按钮是否禁用
			cancleDisabled: false,
			receiverNameDisabled: true,
			isDisabled: false,
			productTypeOptions: [],
			careReceiverNameOptions: [],
			staffPositionList: [],
			filters: {
				orgName: this.$store.getters.userOrgName, //组织
				orgCode: this.$store.getters.userOrgCode,
				careGiverName: "", //照护人
				careReceiverName: "", //被照护人
				serviceFrequencyType: '',
				page: 1,
				pageSize: 10,
				selectDay: []
			},
			//排班周期
			schedlingStaffOptions: [
				{
					planDayStr: "周一",
					planDay: "1"
				},
				{
					planDayStr: "周二",
					planDay: "2"
				},
				{
					planDayStr: "周三",
					planDay: "3"
				},
				{
					planDayStr: "周四",
					planDay: "4"
				},
				{
					planDayStr: "周五",
					planDay: "5"
				},
				{
					planDayStr: "周六",
					planDay: "6"
				},
				{
					planDayStr: "周日",
					planDay: "7"
				}
			],
			//周排班
			dateStaffOptions: [

			],
			isDateDisabled: true,
			isDayDisabled: false,
			staffScheduleVisible: false,
			isWeekDay: true,
			careReceiver: {},
			serviceDuration: "",
		};
	},
	watch: {},
	computed: {},
	methods: {
		clearDate () {
			this.isDateDisabled = true
			this.isDayDisabled = true
			this.filters.selectDay = []
		},
		selectDate (val) {
			// console.log(val)
			if (val == '20') {
				this.isDayDisabled = false
				this.isDateDisabled = true
				this.isDate = true
				this.isDay = false
				this.filters.selectDay = []
			} else {
				this.isDayDisabled = true
				this.isDateDisabled = false
				this.isDate = false
				this.isDay = true
				this.filters.selectDay = []
			}
		},
		resetForm () {
			this.$refs.filterForm.resetFields()
			this.getList();
		},
		//产品名称模糊查询
		selectProductTypeName (item) {
			if (item.value !== "无") {
				this.formStaffWorkOrder.productCode = item.code;
				this.formStaffWorkOrder.productName = item.value;
				this.formEditStaffOrder.productCode = item.code;
				this.formEditStaffOrder.productName = item.value;
				this.receiverNameDisabled = false;
			} else {
				this.formStaffWorkOrder.productName = "";
				this.formEditStaffOrder.productName = "";
			}
		},
		removeProductTypeName () {
			this.receiverNameDisabled = true;
			this.formStaffWorkOrder.productCode = "";
			this.formEditStaffOrder.productCode = "";
			this.formStaffWorkOrder.orgCode = '';
			this.formStaffWorkOrder.orgName = '';
			this.formStaffWorkOrder.orderCode = '';
			this.formStaffWorkOrder.careReceiverCode = "";
			this.formStaffWorkOrder.careReceiverName = "";
			this.$nextTick(() => {
				this.$refs.formStaffWorkOrder.clearValidate("careReceiverName");
			});
		},
		queryProductTypeName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					productType: 10,
					productName: queryString
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					productType: 10,
					productName: queryString
				};
			}
			findEtProductByDataAuthority(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.productTypeOptions = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.productTypeOptions.push({
								value: data[i].productName,
								code: data[i].productCode
							});
						}
						var results = this.productTypeOptions;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//被照护人姓名
		selectCareReceiverName (item) {
			if (item.value !== "无") {
				this.careReceiver = item;
				if (this.formEditStaffOrder.workorderCode) {
					this.formEditStaffOrder.careReceiverCode = item.code;
					this.formEditStaffOrder.careReceiverName = item.value;
				} else {
					this.formStaffWorkOrder.careReceiverCode = item.code;
					this.formStaffWorkOrder.careReceiverName = item.value;
					this.careReceiverNameOptions.forEach((v) => {
						if (this.formStaffWorkOrder.careReceiverCode == v.code) {
							this.formStaffWorkOrder.orgCode = v.orgCode;
							this.formStaffWorkOrder.orgName = v.orgName;
							this.formStaffWorkOrder.orderCode = v.orderCode;
							this.formStaffWorkOrder.serviceFrequencyType = v.serviceFrequencyType
							this.serviceDuration = v.serviceDuration;//默认服务时长
							this.$refs['scheduleTags'].setServiceDuration(this.serviceDuration);
							this.formStaffWorkOrder.planServiceDuration = v.planServiceDuration
						}
					})
				}
			} else {
				this.formStaffWorkOrder.careReceiverName = "";
				this.formEditStaffOrder.careReceiverName = "";
			}
		},
		removeCareReceiverName () {
			this.formStaffWorkOrder.careReceiverCode = "";
			this.formStaffWorkOrder.careReceiverName = "";
			this.formEditStaffOrder.careReceiverName = "";
			this.formStaffWorkOrder.orgCode = '';
			this.formStaffWorkOrder.orgName = '';
			this.formStaffWorkOrder.orderCode = '';
			this.$refs['scheduleTags'].setServiceDuration('');
		},
		queryCareReceiverName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.formStaffWorkOrder.productCode,
					careReceiverName: queryString
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.formStaffWorkOrder.productCode,
					careReceiverName: queryString
				};
			}
			findInServiceOrderList(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.careReceiverNameOptions = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.careReceiverNameOptions.push({
								value: data[i].careReceiverName,
								code: data[i].careReceiverCode,
								careReceiverTel: data[i].careReceiverTel,
								orderCode: data[i].orderCode,
								orgCode: data[i].orgCode,
								orgName: data[i].orgName,
								serviceFrequencyType: data[i].serviceFrequencyType,
								serviceFrequency: data[i].serviceFrequency,
								serviceDuration: data[i].serviceDuration,
							});
						}
						var results = this.careReceiverNameOptions;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//员工模糊查询
		selectStaffName (item) {
			if (item.value !== "无") {
				this.formStaffWorkOrder.staffTel = item.staffTel;
				this.formStaffWorkOrder.careGiverCode = item.code;
				this.formStaffWorkOrder.careGiverName = item.value;
				this.formEditStaffOrder.staffTel = item.staffTel;
				this.formEditStaffOrder.careGiverCode = item.code;
				this.formEditStaffOrder.careGiverName = item.value;
				// this.formCareGiverName.careGiverName=item.value
				// this.formCareGiverName.careGiverCode=item.code

			} else {
				this.formStaffWorkOrder.careGiverName = "";
				this.formEditStaffOrder.careGiverName = "";
				//  this.formCareGiverName.careGiverName='';
			}
		},
		selectEditStaffName (item) {
			if (item.value !== "无") {
				this.formCareGiverName.careGiverName = item.value
				this.formCareGiverName.careGiverCode = item.code
			} else {
				this.formCareGiverName.careGiverName = '';
			}
		},
		removeStaffCode () {
			this.formStaffWorkOrder.careGiverCode = "";
			this.formStaffWorkOrder.careGiverName = "";
			this.formEditStaffOrder.careGiverCode = "";
			this.formEditStaffOrder.careGiverName = "";
			this.formCareGiverName.careGiverCode = '';
			this.formCareGiverName.careGiverName = "";

		},
		removeEditStaffCode () {
			this.formCareGiverName.careGiverCode = '';
		},
		queryStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formStaffWorkOrder.orgCode,
					orgCode: this.formEditStaffOrder.orgCode
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formStaffWorkOrder.orgCode,
					orgCode: this.formEditStaffOrder.orgCode
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffPositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffPositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel,
								positionName: data[i].positionName
							});
						}
						var results = this.staffPositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		queryEditStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formStaffWorkOrder.orgCode,
					orgCode: this.formEditStaffOrder.orgCode
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formStaffWorkOrder.orgCode,
					orgCode: this.formEditStaffOrder.orgCode
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffPositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffPositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel,
								positionName: data[i].positionName
							});
						}
						var results = this.staffPositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		/**
		 *
		 * 查询条件开窗选择组织
		 *
		 */
		close () {
			this.dialogVisible = false;
		},
		getCurrentNode (data) {
			this.filters.orgName = data.orgName;
			this.filters.orgCode = data.orgCode;
			this.close();
		},
		//清空组织过滤
		clearOrgCode () {
			this.filters.orgName = "";
			this.filters.orgCode = "";
		},
		getList () {
			var params = {
				pageNum: this.filters.page,
				pageSize: this.filters.pageSize,
				orgCode: this.filters.orgCode,
				orgName: this.filters.orgName,
				careGiverName: this.filters.careGiverName,
				careReceiverName: this.filters.careReceiverName,
				planDayList: this.filters.selectDay,
				serviceFrequencyType: this.filters.serviceFrequencyType
			};
			this.listLoading = true;
			this.searchLoading = true;
			findWorkorderScheduleList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						if (response.data.responseData != undefined) {
							this.workOrderList = response.data.responseData;
							this.totalCount = response.data.totalCount;
							this.listLoading = false;
							this.searchLoading = false;
						} else {
							this.listLoading = false;
							this.searchLoading = false;
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findWorkorderScheduleByCareGiverCode:" + error);
					this.listLoading = false;
					this.searchLoading = false;
					return false;
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getList(val.page); //改变页码，重新渲染页面
		},
		queryGetList () {
			this.filters.page = 1
			this.getList();
		},
		//新增
		insertWorkOrders () {
			this.dialogWorkOrder = true
			this.getOneproduct()
		},
		//单个产品
		getOneproduct () {
			var params = {
				pageNum: 1,
				pageSize: 10,
				productType: 10
			}
			findEtProductByDataAuthority(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							if (data.length == 1) {
								this.formStaffWorkOrder.productName = data[i].productName
								this.formStaffWorkOrder.productCode = data[i].productCode
							}
						}
						this.receiverNameDisabled = false
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					return false;
				});
		},
		cancleWorkOrder (formStaffWorkOrder) {
			this.isScheduling = false
			this.$refs[formStaffWorkOrder].resetFields();
			this.formStaffWorkOrder.orgName = "";
			this.formStaffWorkOrder.orderCode = "";
			this.formStaffWorkOrder.planEndTime = "";
			this.formStaffWorkOrder.careGiverName = "";
			this.dialogWorkOrder = false;
			this.receiverNameDisabled = true;
		},
		workOrderSubmit (formName) {
			if (this.careReceiverNameOptions.length == 0) {
				this.formStaffWorkOrder.careReceiverName = "";
				this.$message.error("请选择正确的被照护人姓名")
				return false
			} else {
				this.$refs[formName].validate(valid => {
					if (valid) {
						if (this.$refs["scheduleTags"].getAddSchedules().length == 0) {
							this.$message.error("请点击”添加“按钮，添加排程时间");
							return false;
						}
						this.insertStaffscheduling()
					} else {
						this.$message.error("请检查是否填写完整");
						return false;
					}
				});
			}
		},
		//员工排程
		staffOrders () {
			this.staffScheduleVisible = true;
			this.isWeekDay = false; //TODO 根据工单的排程类型是否为周传值
			var timer = setInterval(() => {
				this.$refs["staffScheduleDialog"].setTitle("员工工单")
				clearInterval(timer)
			}, 100)

		},
		//更换护理人员
		changeCareGiverName () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				this.dialogCareGiverName = true;
				let staffId = ""
				for (let i = 0; i < list.length; i++) {
					staffId = list[0].careGiverCode;
					if (staffId != list[i].careGiverCode) {
						this.dialogCareGiverName = false;
						this.$message.error("请选择同一护理人员进行更换哦");
						return false
					}
					this.formCareGiverName.scheduleCodes[i] = list[i].scheduleCode
				}
			}
		},
		submitCareGiverName (formCareGiverName) {
			this.$refs[formCareGiverName].validate(valid => {
				if (valid) {
					this.isDisabled = true
					var params = {
						scheduleCodes: this.formCareGiverName.scheduleCodes,
						careGiverName: this.formCareGiverName.careGiverName,
						careGiverCode: this.formCareGiverName.careGiverCode,
					};
					updateCareGiverBySchedule(params)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.dialogCareGiverName = false;
								this.formCareGiverName.scheduleCodes = []
								this.formCareGiverName.careGiverCode = ''
								this.formCareGiverName.careGiverName = ''
								this.formStaffWorkOrder.careGiverCode = '';
								this.formStaffWorkOrder.careGiverName = '';
								this.isDisabled = false;
								this.getList();
								this.$refs[formCareGiverName].resetFields();
							} else {
								this.$alert('<font color=red>' + response.data.statusMsg + '</font>', {
									dangerouslyUseHTMLString: true
								});
								this.isDisabled = false;
								return false;
							}
						})
						.catch(error => {
							this.formCareGiverName.scheduleCodes = []
							this.isDisabled = false;
							// this.$message.error(this.ConstantData.requestErrorMsg)
						});
				} else {
					this.$message.error("请检查是否填写完整");
					this.isDisabled = false
					return false;
				}
			});
		},
		careGiverNameCancel (formCareGiverName) {
			this.formStaffWorkOrder.careGiverCode = '';
			this.formStaffWorkOrder.careGiverName = '';
			this.$refs[formCareGiverName].resetFields();
			this.formCareGiverName.scheduleCodes = []
			this.dialogCareGiverName = false;
		},
		handleCareGiveNmaeClose () {
			this.formStaffWorkOrder.careGiverCode = '';
			this.formStaffWorkOrder.careGiverName = '';
			this.$refs["formCareGiverName"].resetFields();
			this.formCareGiverName.scheduleCodes = []
			this.dialogCareGiverName = false
		},
		handleOrderClose () {
			this.isScheduling = false
			this.formStaffWorkOrder.planEndTime = "";
			this.formStaffWorkOrder.orgName = "";
			this.formStaffWorkOrder.orderCode = "";
			this.formStaffWorkOrder.careGiverName = "";
			this.$refs["formStaffWorkOrder"].resetFields();
			this.dialogWorkOrder = false;
			this.receiverNameDisabled = true;
			this.$refs["scheduleTags"].resetData();
		},
		handleBatchDelteClose () {
			this.staffSelectCodeList = []
			this.dialogBatchDeleteOrder = false;
		},
		handleEditOrderClose () {
			this.dialogEidtOrder = false;
			this.formEditStaffOrder.workorderCode = "";
			this.$refs["formEditStaffOrder"].resetFields();
			this.$refs["scheduleTagsOfUpdate"].resetData();
		},
		handleSelectionChange (val) {
			this.multipleSelection = val;
		},
		onStaffScheduleClose () {
			this.staffScheduleVisible = false;
		},
		//修改
		editOrder (scheduleCode) {
			var params = {
				scheduleCode: scheduleCode,
			};
			findWorkorderScheduleByScheduleCode(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.formEditStaffOrder.productName =
							response.data.responseData.productName;
						this.formEditStaffOrder.productCode =
							response.data.responseData.productCode;
						this.formEditStaffOrder.workorderCode =
							response.data.responseData.workorderCode;
						this.formEditStaffOrder.careReceiverCode =
							response.data.responseData.careReceiverCode;
						this.formEditStaffOrder.careReceiverName =
							response.data.responseData.careReceiverName;
						this.formEditStaffOrder.orgName = response.data.responseData.orgName;
						this.formEditStaffOrder.orgCode = response.data.responseData.orgCode;
						this.formEditStaffOrder.orderCode = response.data.responseData.orderCode;
						this.formEditStaffOrder.careGiverName =
							response.data.responseData.careGiverName;
						this.formEditStaffOrder.careGiverCode =
							response.data.responseData.careGiverCode;
						this.formEditStaffOrder.servicePositionCode =
							response.data.responseData.servicePositionCode;
						this.formEditStaffOrder.planStartTime =
							response.data.responseData.planStartTime;
						this.formEditStaffOrder.planServiceDuration =
							response.data.responseData.planServiceDuration;
						this.formEditStaffOrder.planEndTime =
							response.data.responseData.planEndTime;
						this.formEditStaffOrder.planDay = response.data.responseData.planDay
						this.formEditStaffOrder.serviceFrequencyType = response.data.responseData.serviceFrequencyType
						this.formEditStaffOrder.scheduleCode = response.data.responseData.scheduleCode
						this.formEditStaffOrder.isSign = response.data.responseData.isSign
						/* 编辑 */
						this.formEditStaffOrder.workorderScheduleServiceList = response.data.responseData.workorderScheduleServiceList
						this.getOrderDetail(this.formEditStaffOrder.orderCode)
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					return false;
				});
		},
		//根据orderCode查产品名称
		getOrderDetail (orderCode) {
			var param = {
				orderCode: orderCode
			}; //TODO
			getOrderDetail(param)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.formEditStaffOrder.productName =
							response.data.responseData.productName;
						this.formEditStaffOrder.productCode =
							response.data.responseData.productCode;
						this.formEditStaffOrder.serviceFrequency = response.data.responseData.serviceFrequency;
						this.careReceiver = this.formEditStaffOrder;
						this.dialogEidtOrder = true;
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("getOrderDetail:" + error);
				});
		},
		//批量删除
		selectDelete () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				this.dialogBatchDeleteOrder = true;
				for (let i = 0; i < list.length; i++) {
					this.staffSelectCodeList[i] = list[i].scheduleCode;
				}
			}
		},
		submitBatchOrder () {
			this.isDisabled = true;
			var params = {
				scheduleCodes: this.staffSelectCodeList,
			};
			deleteWorkorderScheduleByCheckBox(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						this.dialogBatchDeleteOrder = false;
						this.isDisabled = false;
						this.staffSelectCodeList = []
						this.getList(1);
					} else {
						this.$message.error(response.data.statusMsg);
						this.staffSelectCodeList = []
						this.isDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.isDisabled = false;
				});
		},
		deleteBatchCancel () {
			this.staffSelectCodeList = []
			this.dialogBatchDeleteOrder = false;
		},
		cancleEditOrder () {
			this.formEditStaffOrder.workorderCode = "";
			this.dialogEidtOrder = false;
		},
		editOrderSubmit (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					this.editWorkorderScheduleDetail();
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});


		},
		//新增员工排程
		insertStaffscheduling () {
			this.cancleDisabled = true;
			let params = {
				serviceFrequencyType: this.formStaffWorkOrder.serviceFrequencyType,
				careReceiverCode: this.formStaffWorkOrder.careReceiverCode,
				careGiverCode: this.formStaffWorkOrder.careGiverCode,
				workorderScheduleInDtoList: this.$refs["scheduleTags"].getAddSchedules()
			};
			console.log(params,'87799')
			batchAddWorkorderSchedule(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode === "200"
					) {
						if (this.isScheduling == true) {
							this.$message.success('新增排程成功');
							this.cancleDisabled = false
							this.$nextTick(() => {
								this.$refs.formStaffWorkOrder.clearValidate("careReceiverName");
							});
							this.formStaffWorkOrder.orgCode = "";
							this.formStaffWorkOrder.orgName = "";
							this.formStaffWorkOrder.orderCode = "";
							this.formStaffWorkOrder.careReceiverName = "";
							this.formStaffWorkOrder.careReceiverCode = "";
							this.isScheduling = false
							this.$refs['scheduleTags'].addTag.serviceItems = [];
							this.$refs["scheduleTags"].resetData();
						} else {
							this.isScheduling = false
							this.dialogWorkOrder = false;
							this.$refs["formStaffWorkOrder"].resetFields();
							this.$refs["scheduleTags"].resetData();
							this.formStaffWorkOrder.orgCode = "";
							this.formStaffWorkOrder.orgName = "";
							this.formStaffWorkOrder.orderCode = "";
							this.formStaffWorkOrder.planEndTime = "";
							this.formStaffWorkOrder.careGiverName = "";
							this.cancleDisabled = false;
							this.receiverNameDisabled = true
							this.getList();
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.cancleDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log("batchAddWorkorderSchedule:" + error);
					this.cancleDisabled = false;
					return false;
				});
		},
		//修改排程接口
		editWorkorderScheduleDetail () {
			var updatePlanInfo = this.$refs["scheduleTagsOfUpdate"].getUpdatedData();
			this.cancleDisabled = true;
			let params = {
				orgCode: this.formEditStaffOrder.orgCode,
				orgName: this.formEditStaffOrder.orgName,
				orderCode: this.formEditStaffOrder.orderCode,
				serviceFrequencyType: this.formEditStaffOrder.serviceFrequencyType, //该字段不会变
				careReceiverCode: this.formEditStaffOrder.careReceiverCode,
				careReceiverName: this.formEditStaffOrder.careReceiverName,
				servicePositionCode: this.formEditStaffOrder.servicePositionCode,
				servicePositionName:
					this.formEditStaffOrder.servicePositionCode == "GW1911270089"
						? "护理员"
						: "护士",
				careGiverCode: this.formEditStaffOrder.careGiverCode,
				careGiverName: this.formEditStaffOrder.careGiverName,
				planDay: updatePlanInfo.planDay,
				planStartTime: updatePlanInfo.planStartTime,
				planEndTime: updatePlanInfo.planEndTime,
				planServiceDuration: updatePlanInfo.planServiceDuration,
				scheduleCode: this.formEditStaffOrder.scheduleCode,
				/* 编辑 */
				workorderScheduleServiceList: updatePlanInfo.workorderScheduleServiceList,
				isSign: this.formEditStaffOrder.isSign
			};
			editWorkorderScheduleDetail(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode === "200"
					) {
						this.dialogEidtOrder = false;
						this.cancleDisabled = false;
						this.getList();
					} else {
						this.$message.error(response.data.statusMsg);
						// this.dialogEidtOrder = false;
						this.cancleDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log("editWorkorderScheduleDetail:" + error);
					this.cancleDisabled = false;
					return false;
				});

		},
	},
	created () {
		for (let i = 1; i <= 31; i++) {
			this.dateStaffOptions.push({
				planDayStr: i + '日',
				planDay: i
			});
		}
		this.getList();
	},
	mounted () { },
	activated () {
		// this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#staffscheduling {
	width: 100%;
	min-width: 1470px;
	.el-form-item {
		margin-bottom: 0px;
	}

	.el-input {
		width: 200px;
	}
	.el-select {
		width: 200px;
	}
	.el-autocomplete {
		width: 200px;
	}
	.form-item {
		width: 30%;
		min-width: 295px;
	}
	.workOrderClass {
		margin-top: 15px;
		margin-bottom: 0;
	}
	.form-items {
		width: 30%;
		min-width: 350x;
	}
	.search_btn {
		min-width: 250px;
		margin-left: 120px;
	}
	.tableTopBtn {
		background-color: white;
		text-align: right;
		padding: 20px 20px 20px 0px;
	}
	.el-dialog {
		display: flex;
		flex-direction: column;
		margin: 0 !important;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}
	.el-dialog .el-dialog__body {
		flex: 1;
		overflow: auto;
	}
	.remark-style {
		display: block;
		width: 300px;
		margin-top: 5px;
	}
	
	.my-autocomplete {
		// height:40px;
		li {
			line-height: normal;
			padding: 7px;
			.name {
				text-overflow: ellipsis;
				overflow: hidden;
			}
		}
	}
}
</style>
<style lang="scss">
#staffscheduling {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
.el-autocomplete-suggestion__wrap {
	max-height: 380px;
}
.el-time-panel__footer {
	margin-right: 34px !important;
}
</style>
