<template>
	<div id="detailOrder">
		<headTag :tagName="tagName" />
		<el-row class="main-content">
			<el-form
				label-width="150px"
				:model="workOrderdetail"
				ref="workOrderdetail"
				class="form-content"
				:inline="false"
				:rules="workOrderdetailRules"
			>
				<el-col class="panel-card">
					<el-row class="importToolbar">
						<el-col :span="24">
							<span class="form-tag">被照护人信息</span>
							<el-button size="small" type="primary" @click="btnBackList()" class="rightBtn">返回</el-button>
						</el-col>
					</el-row>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名:">
							<span>{{workOrderdetail.careReceiverName}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人年龄:">
							<span>{{workOrderdetail.careReceiverAge}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人身份证号:">
							<span>{{workOrderdetail.careReceiverIdCard}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="被照护人地址:">
							<span
								class="long-field"
							>{{workOrderdetail.liveProvinceName}}{{workOrderdetail.liveCityName}}{{workOrderdetail.liveDistrictName}}{{workOrderdetail.liveSubdistrictName}}{{workOrderdetail.liveDetailAddress}}</span>
							<el-button style="margin-left:20px;" size="mini" type="primary" @click="btnOrder()">查看订单</el-button>
						</el-form-item>
					</el-col>
				</el-col>
				<el-col class="panel-card" style="padding-bottom:40px;">
					<el-row class="importToolbar">
						<el-col :span="24">
							<span class="form-tag">服务详情</span>
						</el-col>
					</el-row>
					<el-col class="form-items">
						<el-form-item label="排班时间:">
							<span>{{workOrderdetail.planStartDate}}---{{workOrderdetail.planEndDate}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items" v-if="planServiceItems">
						<el-form-item label="计划服务项:">
							<span>{{planServiceItems}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="实际服务时长:">
							<span>
								<span v-if="workOrderdetail.actServiceDuration">{{workOrderdetail.actServiceDuration}}h</span>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务人员:">
							<span>{{workOrderdetail.careGiverName}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单类型:">
							<span>{{workOrderdetail.workorderTypeValue}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务时长:">
							<span>
								<span v-if="workOrderdetail.planServiceDuration">{{workOrderdetail.planServiceDuration}}h</span>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签入状态:">
							<span>{{workOrderdetail.workorderStatusValue}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单状态:">
							<span>{{workOrderdetail.distinguishStatusValue}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="结算状态:">
							<span>{{workOrderdetail.settleStatusValue}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="结算时间:">
							<span>{{workOrderdetail.settleDate }}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="审核状态:">
							<span
								v-if="workOrderdetail.auditStatus == '30'"
							>{{workOrderdetail.auditStatusValue}}({{workOrderdetail.personAuditReason}})</span>
							<span v-if="workOrderdetail.auditStatus == '40'">
								{{workOrderdetail.auditStatusValue}}
								<span
									v-if="workOrderdetail.personAuditReason"
								>({{workOrderdetail.personAuditReason}})</span>
							</span>
							<span v-if="workOrderdetail.auditStatus == '20'">
								{{workOrderdetail.auditStatusValue}}
								<span
									v-if="workOrderdetail.personAuditReason"
								>({{workOrderdetail.personAuditReason}})</span>
							</span>
							<span v-if="workOrderdetail.auditStatus == '00'">
								{{workOrderdetail.auditStatusValue}}
								<span
									v-if="workOrderdetail.personAuditReason"
								>({{workOrderdetail.personAuditReason}})</span>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="审核原因:">
							<span class="long-field">{{workOrderdetail.auditReason }}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="删改原因:">
							<span class="long-field">{{workOrderdetail.delReason }}</span>
						</el-form-item>
					</el-col>
					<!-- <el-col class="form-item">
						<el-form-item label="修改原因:">
							<span class="long-field">{{workOrderdetail.delReason }}</span>
						</el-form-item>
					</el-col>-->
					<el-col class="form-item">
						<el-form-item label="签入时间:">
							<span>{{workOrderdetail.checkinDate}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemAdress">
						<el-form-item label="签入地址:">
							<span class="long-field">
								<span v-if="workOrderdetail.checkinAddress">{{workOrderdetail.checkinAddress}}</span>
								<span v-if="workOrderdetail.checkinDistance">({{workOrderdetail.checkinDistance}})</span>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签出时间:">
							<span>{{workOrderdetail.checkoutDate}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemAdress">
						<el-form-item label="签出地址:">
							<!-- <span>{{workOrderdetail.checkoutAddress}}({{workOrderdetail.checkoutDistance}})</span> -->
							<span class="long-field">
								<span v-if="workOrderdetail.checkoutAddress">{{workOrderdetail.checkoutAddress}}</span>
								<span v-if="workOrderdetail.checkoutDistance">({{workOrderdetail.checkoutDistance}})</span>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="服务项:">
							<span class="long-field" v-if="setServiceItems">{{setServiceItems}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="上传照片:">
							<span v-if="checkinPhotosList.length>0">
								<span
									style="width:100px;height:100px;margin-right:10px;"
									v-for="item in checkinPhotosList"
									:key="item.id"
								>
									<el-image
										style="width: 100px; height: 100px;"
										:src="item ? item : ''"
										:preview-src-list="checkinPhotosList"
									></el-image>
								</span>
							</span>
						</el-form-item>
					</el-col>
				</el-col>
				<el-col class="panel-card" v-if="isShow">
					<!-- 护理员 -->
					<el-row class="importToolbar">
						<el-col :span="24">
							<span class="form-tag">健康状态</span>
						</el-col>
					</el-row>
					<el-col class="form-itemd">
						<el-form-item label="收缩压:">
							<span v-if="obj.ssy">{{obj.ssy}}&nbsp;mmHg</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="舒张压:">
							<span v-if="obj.szy">{{obj.szy}}&nbsp;mmHg</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="意识:">
							<span>{{obj.ys}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="面色:">
							<span>{{obj.ms}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="睡眠:">
							<span>{{obj.sm}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="食欲:">
							<span>{{obj.sy}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="大便:">
							<span>{{obj.db}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemd">
						<el-form-item label="饮水量:">
							<span>{{obj.ysl}}</span>
						</el-form-item>
					</el-col>
				</el-col>
				<el-col v-if="!isShow">
					<el-col class="panel-card" style="padding-bottom:40px;">
						<el-col>
							<el-row class="importToolbar">
								<el-col :span="24">
									<span class="form-tag">生命体征</span>
								</el-col>
							</el-row>
							<el-col class="form-item">
								<el-form-item label="脉搏:">
									<span v-if="obj.mb">{{obj.mb}}&nbsp;次/分</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="呼吸:">
									<span v-if="obj.hx">{{obj.hx}}&nbsp;次/分</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="体温:">
									<span v-if="obj.tw">{{obj.tw}}>&nbsp;℃</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="收缩压:">
									<span v-if="obj.ssy">{{obj.ssy}}&nbsp;mmHg</span>
								</el-form-item>
							</el-col>

							<el-col class="form-item">
								<el-form-item label="舒张压:">
									<span v-if="obj.szy">{{obj.szy}}&nbsp;mmHg</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="血糖:">
									<span v-if="obj.xt">{{obj.xt}}&nbsp;mol/L</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="检测时间段:">
									<span v-if="obj.jcsjd">{{obj.jcsjd}}&nbsp;</span>
								</el-form-item>
							</el-col>
						</el-col>
					</el-col>
					<el-col class="panel-card" style="padding-bottom:40px;">
						<el-col>
							<el-row class="importToolbar">
								<el-col :span="24">
									<span class="form-tag">健康状态</span>
								</el-col>
							</el-row>
							<el-col class="form-item">
								<el-form-item label="意识:">
									<span v-if="obj.ys">{{obj.ys}}</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="睡眠质量:">
									<span v-if="obj.smzl">{{obj.smzl}}&nbsp;h/天</span>
								</el-form-item>
							</el-col>

							<el-col class="form-item">
								<el-form-item label="水分摄入量:">
									<span v-if="obj.sfsrl">{{obj.sfsrl}}&nbsp;ml/天</span>
									<!-- <span v-if="1500<obj.sfsrl<2000">充分</span>
									<span v-else-if="800<obj.sfsrl<1400">不充分</span>
									<span v-else-if="obj.sfsrl<800">极少</span>-->
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="水分摄入:">
									<span v-if="obj.sfsr">{{obj.sfsr}}</span>
								</el-form-item>
							</el-col>

							<el-col class="form-item">
								<el-form-item label="营养摄入:">
									<span v-if="obj.yysr">{{obj.yysr}}</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="进食形态:">
									<span v-if="obj.jszt">{{obj.jszt}}</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="皮肤:">
									<span v-if="obj.pf">{{obj.pf}}</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="皮肤情况说明:">
									<span v-if="obj.pfqksm">{{obj.pfqksm}}&nbsp;</span>
								</el-form-item>
							</el-col>
							<el-col class="form-item">
								<el-form-item label="尿量:">
									<span v-if="obj.nl">{{obj.nl}}&nbsp;ml/天</span>
								</el-form-item>
							</el-col>

							<el-col class="form-item">
								<el-form-item label="大便:">
									<span v-if="obj.db">{{obj.db}}&nbsp;</span>
								</el-form-item>
							</el-col>
						</el-col>
					</el-col>
					<el-col class="panel-card" style="padding-bottom:40px;">
						<el-col>
							<el-row class="importToolbar">
								<el-col :span="24">
									<span class="form-tag">用药情况</span>
								</el-col>
							</el-row>
						</el-col>
						<div v-for="(item,i) in this.MedicationList" :key="i">
							<el-col class="form-itemD">
								<el-form-item label="药物名称:">
									<span>{{item[0]}}&nbsp;</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="服用频次:">
									<span>{{item[1]}}&nbsp;</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="药物剂量:">
									<span>{{item[2]}}&nbsp;</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="是否按时服药:">
									<span>{{item[3]}}&nbsp;</span>
								</el-form-item>
							</el-col>
						</div>
					</el-col>
				</el-col>
			</el-form>
		</el-row>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { changeYMD } from "utils";
import { getWorkorderDetail } from "api/workOrderManagement";
export default {
	components: {
		HeadTag
	},
	props: {},
	data () {
		return {
			tagName: "工单信息",
			workorderCode: "",
			auditStatus: "",
			workorderStatus: "",
			distinguishStatus: "",
			workOrderdetail: {},
			workOrderdetailRules: {},
			checkinPhotosList: [],
			MedicationList: [],
			careReceiverSignList: [],
			srcList: [],
			obj: {
				// gy: "",
				// dy: "",
				// ms: "",
				// sm: "",
				// xt: "",
				// tw: "",
				// tz: "",
				// smzl: "",
				// ysl: ""
			},
			isShow: true,
			planServiceItems: "",
			setServiceItems: '',
		};
	},
	watch: {},
	computed: {},
	methods: {
		btnBackList () {
			this.$router.push({
				path: "/workOrderManagement/workOrderManagementList"
			});
		},
		btnOrder () {
			this.$router.push({
				path: "/businessServiceManagement/updateOrderInfo",
				query: {
					orderCode: this.workOrderdetail.orderCode
				}
			});
		},
		getWorkorderDetail (workorderCode, auditStatus, workorderStatus, distinguishStatus) {
			var params = {
				workorderCode: workorderCode,
				auditStatus: auditStatus,
				workorderStatus: workorderStatus,
				distinguishStatus: distinguishStatus
			};
			getWorkorderDetail(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.workOrderdetail = response.data.responseData;
						if (response.data.responseData.checkoutPhotos) {
							let obj = response.data.responseData.checkoutPhotos;
							let temp = obj.split(",");
							this.checkinPhotosList = [...temp];
						}
						if (response.data.responseData.checkinDistance) {
							let checkinDistance = response.data.responseData.checkinDistance
							this.workOrderdetail.checkinDistance = Math.round(checkinDistance) + '米'
						}
						if (response.data.responseData.checkoutDistance) {
							let checkoutDistance = response.data.responseData.checkoutDistance
							this.workOrderdetail.checkoutDistance = Math.round(checkoutDistance) + '米'
						}
						if (
							response.data.responseData.servicePositionCode == "GW1911270089"
						) {
							//护理员
							this.isShow = true;
							this.$forceUpdate()
						} else {
							//护士
							this.isShow = false;
							this.$forceUpdate()
						}
						if (response.data.responseData.careReceiverSignList.length > 0) {
							this.careReceiverSignList =
								response.data.responseData.careReceiverSignList;
							var hasMedication = false;
							this.careReceiverSignList.forEach(item => {
								if (item.signCode == "MEDICATION") {
									hasMedication = true;
								}
							})
							if (!hasMedication) {
								var obj = JSON.parse(JSON.stringify(this.careReceiverSignList[0]));
								obj.signValue = "|||";
								obj.signName = "用药情况";
								this.$set(obj, "signCode", "MEDICATION")
								this.careReceiverSignList.push(obj)
							}
							// this.careReceiverSignList.forEach((item, key) => {
							// 	if(item.signName!=='用药情况'){
							// 		// item.signName=='用药情况'
							// 		this.$set(this.careReceiverSignList[key], "用药情况", key);
							// 	}
							// })
							this.careReceiverSignList.forEach(item => {
								// debugger;
								switch (item.signName) {

									case "收缩压":
										this.obj.ssy = item.signValue;
										break;
									case "舒张压":
										this.obj.szy = item.signValue;
										break;
									case "面色":
										this.obj.ms = item.signValue;
										break;
									case "睡眠":
										this.obj.sm = item.signValue;
										break;
									case "食欲":
										this.obj.sy = item.signValue;
										break;
									case "大便":
										this.obj.db = item.signValue;
										break;
									case "饮水量":
										this.obj.ysl = item.signValue;
										break;
									case "脉搏":
										this.obj.mb = item.signValue;
										break;
									case "呼吸":
										this.obj.hx = item.signValue;
										break;
									case "体温":
										this.obj.tw = item.signValue;
										break;
									case "血糖":
										this.obj.xt = item.signValue;
										break;
									case "检测时间段":
										this.obj.jcsjd = item.signValue;
										break;
									case "意识":
										this.obj.ys = item.signValue;
										break;
									case "睡眠质量":
										this.obj.smzl = item.signValue;
										break;
									case "水分摄入量":
										this.obj.sfsrl = item.signValue;
										break;
									case "水分摄入":
										this.obj.sfsr = item.signValue;
										break;
									case "营养摄入":
										this.obj.yysr = item.signValue;
										break;
									case "进食形态":
										this.obj.jszt = item.signValue;
										break;
									case "皮肤":
										this.obj.pf = item.signValue;
										break;
									case "尿量":
										this.obj.nl = item.signValue;
										break;
									case "皮肤情况说明":
										this.obj.pfqksm = item.signValue;
										break;
									case "用药情况":
										if (item.signValue) {
											this.MedicationList.push(item.signValue.split("|"))
										}
										// let value = item.signValue.split("|")
										// //药物名称
										// this.obj.ywmc = value[0]
										// //服用频次
										// this.obj.fypc = value[1]
										// //药物剂量
										// this.obj.ywjl = value[2];
										// //是否按时服药
										// this.obj.ascy = value[3];
										break;
								}
							});
						} else if (response.data.responseData.careReceiverSignList.length == 0) {
							this.careReceiverSignList =
								response.data.responseData.careReceiverSignList;
							var obj = {}
							obj.signName = "用药情况";
							obj.signValue = "|||";
							obj.signCode = "MEDICATION";
							// this.$set(obj, "signCode", "MEDICATION")
							this.careReceiverSignList.push(obj)
							this.MedicationList.push(obj.signValue.split("|"))
						}

						//计划服务项
						this.planServiceItems = ""
						if (response.data.responseData.reportWorkorderServiceList) {
							var reportWorkorderServiceList = response.data.responseData.reportWorkorderServiceList;
							reportWorkorderServiceList.forEach((item, index) => {
								// this.planServiceItems+=item.serviceCode+item.serviceItem+(index!=reportWorkorderServiceList.length-1?",":"")
								this.planServiceItems += item.serviceCode + item.serviceItem + (index != reportWorkorderServiceList.length - 1 ? "," : "")
							});
							this.$forceUpdate()
						}
						//服务项
						this.setServiceItems = ""
						if (response.data.responseData.actWorkorderServiceList) {
							var actWorkorderServiceList = response.data.responseData.actWorkorderServiceList;
							actWorkorderServiceList.forEach((item, index) => {
								// this.planServiceItems+=item.serviceCode+item.serviceItem+(index!=reportWorkorderServiceList.length-1?",":"")
								this.setServiceItems += item.serviceCode + item.serviceItem + (index != actWorkorderServiceList.length - 1 ? "," : "")
							});
							this.$forceUpdate()
						}
					}
				})
				.catch(error => {
					console.log("getWorkorderDetail:" + error);
					return false;
				});
		}
	},
	created () {
		//获得传入参数
		var param = this.$route.query;
		this.workorderCode = param.workorderCode;
		this.auditStatus = param.auditStatus;
		this.workorderStatus = param.workorderStatus;
		this.distinguishStatus = param.distinguishStatus;

		this.getWorkorderDetail(
			this.workorderCode,
			this.auditStatus,
			this.workorderStatus,
			this.distinguishStatus
		);
	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
#detailOrder {
	width: 100%;
	min-width: 1024px;
	.el-form-item {
		margin-bottom: 15px;
	}
}
.main-content {
	border-radius: 10px;
	background: #fff;
	margin: 0px 20px 20px 20px;
	padding: 20px 30px 20px 10px;
}
.importToolbar {
	padding: 10px;
	border: 0.1px solid #e0e6eb;
	border-bottom-left-radius: 0px;
	border-bottom-right-radius: 0px;
	border-top-left-radius: 8px;
	border-top-right-radius: 8px;
	background-color: #f9f9f9;
	.form-tag {
		font-size: 16px;
		border-left: 5px solid #f98c3c;
		padding-left: 10px;
		font-weight: 550;
	}
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.remark-style {
	display: block;
	width: 300px;
}
.form-item {
	width: 30%;
	min-width: 400px;
	padding-bottom: 5px;
	height: 60px;
}
img:hover {
	transform: scale(1.02, 1.02);
}
.form-itemD {
	width: 25%;
	min-width: 280px;
	// padding-bottom: 5px;
	height: 60px;
}
.form-content {
	font-size: 16px;
	// margin: 0px 42px;
}
.form-items {
	width: 100%;
}
.panel-card {
	border: 1px solid #e0e6eb;
	border-radius: 8px;
	margin: 0px 10px 10px 10px;
}
.form-itemAdress {
	width: 30%;
	min-width: 400px;
	.el-form-item {
		.el-form-item__content {
			line-height: 30px;
		}
	}
}
.form-itemd {
	width: 50%;
}
</style>