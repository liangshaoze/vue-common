<template>
	<div id="workOrderManage">
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filters" label-width="110px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="filters.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单类型" prop="workorderType">
							<el-select size="mini" v-model.trim="filters.workorderType" clearable placeholder="请选择工单类型">
								<el-option
									v-for="item in workorderOptionsType"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="计划时间" prop="planDate">
							<el-date-picker
								v-model.trim="filters.planDate"
								clearable
								size="mini"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								type="datetimerange"
								style="width: 290px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="服务人员" prop="careGiverName">
							<el-input size="mini" v-model.trim="filters.careGiverName" clearable placeholder="请输入服务人员"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人地址" prop="liveDetailAddress">
							<el-input
								size="mini"
								v-model.trim="filters.liveDetailAddress"
								clearable
								:disabled="adreesDisabled"
								placeholder="请输入被照护人地址"
							></el-input>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="审核状态" prop="auditStatus">
							<el-select size="mini" v-model.trim="filters.auditStatus" clearable placeholder="请选择审核状态">
								<el-option
									v-for="item in auditStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签入状态" prop="workorderStatus">
							<el-select
								size="mini"
								v-model.trim="filters.workorderStatus"
								clearable
								placeholder="请选择签入状态 "
							>
								<el-option
									v-for="item in workorderStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="结算状态" prop="settleStatus">
							<el-select size="mini" v-model.trim="filters.settleStatus" clearable placeholder="请选择结算状态">
								<el-option
									v-for="item in settleStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="审核原因" prop="auditReason">
							<el-select size="mini" v-model.trim="filters.auditReason" clearable placeholder="请选择审核原因">
								<el-option
									v-for="item in auditReasonOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="删改原因" prop="delReason">
							<el-select size="mini" v-model.trim="filters.delReason" clearable placeholder="请选择删除原因">
								<el-option
									v-for="item in delReasonOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单状态" prop="distinguishStatus">
							<el-radio-group size="mini" v-model="filters.distinguishStatus" @change="changeRadio">
								<el-radio
									v-for="item in distinguishStatusOptions"
									:key="item.value"
									:label="item.value"
								>{{item.name}}</el-radio>
							</el-radio-group>
						</el-form-item>
					</el-col>
					<!-- <el-col class="form-item">
					<el-form-item></el-form-item>-->
					<!-- <el-form-item label="修改服务时间" prop="planDate">
							<el-date-picker v-model.trim="filters.planDate" clearable size="mini" format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm" type="datetimerange" style="width: 290px;" range-separator="至"
								start-placeholder="开始日期" end-placeholder="结束日期"></el-date-picker>
					</el-form-item>-->
					<!-- </el-col> -->
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="queryGetList()"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="insertWorkOrders()">新增</el-button>
					<el-button size="mini" type="primary" icon="el-icon-date" @click="staffOrders()">员工工单</el-button>
					<el-button
						size="mini"
						type="primary"
						icon="el-icon-s-custom"
						@click="changeCareGiverName()"
					>更换服务人员</el-button>
					<el-button size="mini" type="primary" icon="el-icon-thumb" @click="examineOrders()">审核</el-button>
					<el-button size="mini" type="primary" icon="el-icon-edit-outline" @click="FinshOrders()">结算完成</el-button>
					<el-button size="mini" type="primary" icon="el-icon-delete" @click="selectDelete()">删除工单</el-button>
				</el-col>
			</el-row>

			<!-- 列表 -->
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				stripe
				ref="multipleTable"
				size="mini"
				:data="workOrderList"
				v-loading="listLoading"
				highlight-current-row
				@selection-change="handleSelectionChange"
				element-loading-text="拼命加载中"
			>
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="工单单号" width="140">
					<template slot-scope="scope">
						<span v-if="showList.workOrder_number_onClick">
							<a
								href="#"
								style="color: #606266;font-size:14px;cursor:pointer;"
								@click="changeOrder(scope.row)"
							>{{scope.row.workorderCode}}</a>
						</span>
						<span v-else>{{scope.row.workorderCode}}</span>
					</template>
				</el-table-column>
				<el-table-column label="被照护人姓名" min-width="100" prop="careReceiverName"></el-table-column>
				<el-table-column label="被照护人身份证号" width="150" prop="careReceiverIdCard"></el-table-column>
				<el-table-column label="服务人员" min-width="80" prop="careGiverName"></el-table-column>
				<el-table-column label="计划时间" width="230" prop="planServiceDuration">
					<template slot-scope="scope">
						<span
							v-if="scope.row.planStartDate != ''"
						>{{scope.row.planStartDate}}---{{scope.row.planEndDate}}</span>
					</template>
				</el-table-column>
				<el-table-column label="被照护人地址" min-width="180">
					<template slot-scope="scope">
						<span
							v-if="scope.row.liveProvinceName != ''"
						>{{scope.row.liveProvinceName}}{{scope.row.liveCityName}}{{scope.row.liveDistrictName}}{{scope.row.liveSubdistrictName}}{{scope.row.liveDetailAddress}}</span>
					</template>
				</el-table-column>
				<el-table-column label="工单类型" min-width="80" prop="workorderTypeValue"></el-table-column>
				<el-table-column label="签入状态" min-width="80" prop="workorderStatusValue"></el-table-column>
				<el-table-column label="工单状态" min-width="80" prop="distinguishStatusValue"></el-table-column>
				<el-table-column label="审核状态" min-width="80" prop="auditStatusValue">
					<template slot-scope="scope">
						<span
							v-if="scope.row.auditStatus == '30'"
						>{{scope.row.auditStatusValue}}({{scope.row.personAuditReason}})</span>
						<span v-if="scope.row.auditStatus == '40'">
							{{scope.row.auditStatusValue}}
							<span
								v-if="scope.row.personAuditReason"
							>({{scope.row.personAuditReason}})</span>
						</span>
						<span v-if="scope.row.auditStatus == '20'">
							{{scope.row.auditStatusValue}}
							<span
								v-if="scope.row.personAuditReason"
							>({{scope.row.personAuditReason}})</span>
						</span>
						<span v-if="scope.row.auditStatus == '00'">
							{{scope.row.auditStatusValue}}
							<span
								v-if="scope.row.personAuditReason"
							>({{scope.row.personAuditReason}})</span>
						</span>
					</template>
				</el-table-column>
				<el-table-column label="结算状态" min-width="80" prop="settleStatusValue"></el-table-column>
				<el-table-column label="审核原因" min-width="140" prop="auditReason"></el-table-column>
				<el-table-column label="删改原因" min-width="140" prop="delReason"></el-table-column>
				<!-- <el-table-column label="修改原因" min-width="140" prop="delReason"></el-table-column> -->
				<el-table-column label="组织" min-width="140" prop="orgName"></el-table-column>
				<el-table-column fixed="right" label="操作">
					<template slot-scope="scope">
						<span>
							<el-button size="mini" type="text" @click="detailOrder(scope.row)">查看详情</el-button>
						</span>
						<span v-if="scope.row.workorderStatus=='10'">
							<el-button
								size="mini"
								type="text"
								@click="editOrder(scope.row.auditStatus,scope.row.workorderStatus,scope.row.workorderCode,scope.row.distinguishStatus)"
							>修改</el-button>
						</span>
						<span v-if="scope.row.workorderStatus=='10'">
							<el-button
								size="mini"
								type="text"
								style="color:#F4465A;"
								@click="deleteOrder(scope.row.workorderCode,scope.row.distinguishStatus,scope.row.workorderType)"
							>删除</el-button>
						</span>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filters.page"
					:limit.sync="filters.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
			<!-- 新建工单弹窗 -->
			<el-dialog
				title="新建工单"
				width="600px"
				:close-on-click-modal="false"
				:visible.sync="dialogWorkOrder"
				:before-close="handleOrderClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formWorkOrderRules"
						ref="formWorkOrder"
						:model="formWorkOrder"
						label-width="150px"
					>
						<el-form-item class="workOrderClass" prop="productName" label="产品名称">
							<el-autocomplete
								:trigger-on-focus="true"
								v-model="formWorkOrder.productName"
								size="mini"
								clearable
								:fetch-suggestions="queryProductTypeName"
								placeholder="请输入产品名称"
								@select="selectProductTypeName"
								@input="removeProductTypeName"
							></el-autocomplete>
						</el-form-item>
						<el-form-item label="被照护人姓名" prop="careReceiverName" class="workOrderClass">
							<el-autocomplete
								:trigger-on-focus="true"
								popper-class="my-autocomplete"
								v-model="formWorkOrder.careReceiverName"
								size="mini"
								clearable
								:fetch-suggestions="queryCareReceiverName"
								:disabled="receiverNameDisabled"
								placeholder="请输入被照护人姓名"
								@select="selectCareReceiverName"
								@blur="removeCareReceiverName"
								@clear="removeCareReceiverName"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.careReceiverTel }})</span>
									</span>
								</template>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="组织" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formWorkOrder.orgName"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="订单号" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formWorkOrder.orderCode"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="服务人员" class="workOrderClass" prop="careGiverName">
							<el-autocomplete
								:trigger-on-focus="true"
								style="width: 340px;margin-top:5px"
								v-model="formWorkOrder.careGiverName"
								popper-class="my-autocomplete"
								size="mini"
								clearable
								:fetch-suggestions="queryStaffName"
								placeholder="请输入服务人员"
								@select="selectStaffName"
								@blur="removeStaffCode"
								@clear="removeStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span
											v-if="item.value != '无'"
											:title="item.value+item.staffTel+item.positionName"
										>({{ item.staffTel }})({{ item.positionName }})</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:80px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务岗位">
							<el-radio-group v-model="formWorkOrder.servicePositionCode">
								<el-radio label="GW1911270089">护理员</el-radio>
								<el-radio label="GW1911270063">护士</el-radio>
							</el-radio-group>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务日期" prop="planStartDate">
							<el-date-picker
								size="mini"
								type="datetime"
								placeholder="请选择时间"
								v-model="formWorkOrder.planStartDate"
								style="width: 200px;"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								:picker-options="pickerOptions"
								@input="changeEndTime"
							></el-date-picker>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务时长" prop="planServiceDuration">
							<el-input
								size="mini"
								v-model="formWorkOrder.planServiceDuration"
								@input="computeEndTime"
								placeholder="请输入服务时长"
								clearable
							>
								<template slot="append">小时</template>
							</el-input>
						</el-form-item>
						<el-form-item class="workOrderClass" label="结束时间">
							<el-input
								size="mini"
								v-model="formWorkOrder.planEndDate"
								:disabled="true"
								placeholder="根据开始时间计算"
							></el-input>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务项">
							<el-select
								v-model="serviceItems"
								multiple
								filterable
								remote
								placeholder="请输入服务项关键词"
								:remote-method="remoteAddMethod"
								:loading="loading"
								@focus="selectAddService"
								collapse-tags
								@change="selectAddItems"
								size="mini"
							>
								<el-option
									v-for="item in serviceOptions"
									:key="item.value"
									:label="item.label"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="cancleWorkOrder('formWorkOrder')">取消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						:disabled="cancleDisabled"
						@click="workOrderSubmit('formWorkOrder')"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 修改工单 -->
			<el-dialog
				title="修改工单"
				:close-on-click-modal="false"
				width="600px"
				:visible.sync="dialogEidtOrder"
				:before-close="handleEditOrderClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formEditOrderRules"
						ref="formEditOrder"
						:model="formEditOrder"
						label-width="150px"
					>
						<el-form-item class="workOrderClass" prop="productName" label="产品名称">
							<el-autocomplete
								:trigger-on-focus="true"
								v-model="formEditOrder.productName"
								size="mini"
								clearable
								:disabled="true"
								:fetch-suggestions="queryProductTypeName"
								placeholder="请输入产品名称"
								@select="selectProductTypeName"
								@input="removeProductTypeName"
							></el-autocomplete>
						</el-form-item>
						<el-form-item label="被照护人姓名" prop="careReceiverName" class="workOrderClass">
							<el-autocomplete
								:trigger-on-focus="true"
								popper-class="my-autocomplete"
								v-model="formEditOrder.careReceiverName"
								size="mini"
								:disabled="true"
								clearable
								placeholder="请输入被照护人姓名"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.careReceiverTel }})</span>
									</span>
								</template>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="组织" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formEditOrder.orgName"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="订单号" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formEditOrder.orderCode"
								placeholder="根据被照护人姓名带出"
								:disabled="orgcodeDisabled"
							></el-input>
						</el-form-item>
						<el-form-item label="服务人员" class="workOrderClass" prop="careGiverName">
							<el-autocomplete
								:trigger-on-focus="true"
								style="width: 340px;margin-top:5px;"
								v-model="formEditOrder.careGiverName"
								popper-class="my-autocomplete"
								size="mini"
								clearable
								:fetch-suggestions="queryUpdateStaffName"
								placeholder="请输入服务人员"
								@select="selectUpdateStaffName"
								@blur="removeUpdateStaffCode"
								@clear="removeUpdateStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span
											v-if="item.value != '无'"
											:title="item.value+item.staffTel+item.positionName"
										>({{ item.staffTel }}){{ item.positionName }}</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:80px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
						<el-form-item label="服务岗位" class="workOrderClass">
							<el-radio-group v-model="formEditOrder.servicePositionCode">
								<el-radio label="GW1911270089">护理员</el-radio>
								<el-radio label="GW1911270063">护士</el-radio>
							</el-radio-group>
						</el-form-item>
						<el-form-item label="服务日期" class="workOrderClass" prop="planStartDate">
							<el-date-picker
								size="mini"
								type="datetime"
								placeholder="请选择时间"
								v-model="formEditOrder.planStartDate"
								style="width: 200px;"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								:picker-options="pickerEditOptions"
								@input="changeEditEndTime"
							></el-date-picker>
						</el-form-item>
						<el-form-item label="服务时长" class="workOrderClass" prop="planServiceDuration">
							<el-input
								size="mini"
								v-model="formEditOrder.planServiceDuration"
								@input="editComputeEndTime"
								placeholder="请输入服务时长"
								clearable
							>
								<template slot="append">小时</template>
							</el-input>
						</el-form-item>
						<el-form-item label="结束时间" class="workOrderClass">
							<el-input
								size="mini"
								v-model="formEditOrder.planEndDate"
								:disabled="true"
								placeholder="根据开始时间计算"
							></el-input>
						</el-form-item>
						<el-form-item class="workOrderClass" label="服务项">
							<el-select
								v-model="serviceEditItems"
								multiple
								filterable
								remote
								placeholder="请输入服务项关键词"
								:remote-method="selectEditService"
								:loading="loading"
								collapse-tags
								@focus="selectEditService"
								@change="selectEditItems"
								@
								size="mini"
							>
								<el-option
									v-for="item in serviceOptions"
									:key="item.value"
									:label="item.label"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="cancleEditOrder('formEditOrder')">取消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						:disabled="cancleDisabled"
						type="primary"
						@click="editOrderSubmit('formEditOrder')"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 审核弹窗 -->
			<el-dialog
				title="审核工单"
				:close-on-click-modal="false"
				:visible.sync="dialogAuditOrder"
				width="400px"
				:before-close="handleClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formAuditOrderRules"
						ref="formAuditOrder"
						:model="formAuditOrder"
						label-width="100px"
					>
						<el-form-item label="审核状态" style="margin:20px 0;" prop="auditStatus">
							<el-select
								size="mini"
								v-model="formAuditOrder.auditStatus"
								clearable
								placeholder="请选择审核状态"
								@clear="clearVal"
								@change="selectAudit"
							>
								<el-option
									v-for="item in options"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
						<el-form-item label="原因" v-if="isNoAudit">
							<el-input
								type="textarea"
								style="width:200px;"
								v-model="formAuditOrder.personAuditReason"
								placeholder="请输入工单审核原因"
								resize="none"
								show-word-limit
								rows="4"
								clearable
								maxlength="100"
							></el-input>
						</el-form-item>
						<el-form-item label="原因" prop="personAuditReason" v-if="isAudit">
							<el-input
								type="textarea"
								style="width:200px;"
								v-model="formAuditOrder.personAuditReason"
								placeholder="请输入工单审核原因"
								resize="none"
								show-word-limit
								rows="4"
								clearable
								maxlength="100"
							></el-input>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="cancelAuditOrder('formAuditOrder')">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="auditOrderSubmit('formAuditOrder')"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 删除工单 -->
			<el-dialog
				title="删除工单"
				:close-on-click-modal="false"
				:visible.sync="dialogDeleteOrder"
				width="450px"
				:before-close="handleDelteClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formDeleteOrderRules"
						ref="formDeletOrder"
						:model="formDeletOrder"
					>
						<el-form-item>
							<el-radio-group v-model="formDeletOrder.delReason" @change="onRadioChange">
								<el-row class="deleteOrder">
									<el-radio label="老人临时改时间">老人临时改时间</el-radio>
									<el-radio label="护理员临时改时间">护理员临时改时间</el-radio>
									<el-radio label="老人去世">老人去世</el-radio>
									<el-radio label="路上耽搁临时暂停">路上耽搁临时暂停</el-radio>
									<el-radio label="老人住院">老人住院</el-radio>
									<el-radio label="暂停服务">暂停服务</el-radio>
									<el-radio label="其他">
										其他原因
										<el-input
											style="margin-left:10px;"
											v-model="deleteReason"
											size="mini"
											placeholder="请输入删除原因"
											v-show="isRadioShow"
										></el-input>
									</el-radio>
								</el-row>
							</el-radio-group>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="deleteCancel('formDeletOrder')">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="submitOrder('formDeletOrder')"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 批量删除工单 -->
			<el-dialog
				title="批量删除工单"
				:close-on-click-modal="false"
				:visible.sync="dialogBatchDeleteOrder"
				width="450px"
				:before-close="handleBatchDelteClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="false"
						:rules="formBatchDeleteOrderRules"
						ref="formBatchDeletOrder"
						:model="formBatchDeletOrder"
					>
						<el-form-item>
							<el-radio-group v-model="formBatchDeletOrder.delReason" @change="onRadioSlectChange">
								<el-row class="deleteOrder">
									<el-radio label="老人临时改时间">老人临时改时间</el-radio>
									<el-radio label="护理员临时改时间">护理员临时改时间</el-radio>
									<el-radio label="老人去世">老人去世</el-radio>
									<el-radio label="路上耽搁临时暂停">路上耽搁临时暂停</el-radio>
									<el-radio label="老人住院">老人住院</el-radio>
									<el-radio label="暂停服务">暂停服务</el-radio>
									<el-radio label="其他">
										其他原因
										<el-input
											style="margin-left:10px;"
											v-model="selectDeleteReason"
											size="mini"
											placeholder="请输入删除原因"
											v-show="isSelectRadioShow"
										></el-input>
									</el-radio>
								</el-row>
							</el-radio-group>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="deleteBatchCancel('formBatchDeletOrder')">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="submitBatchOrder('formBatchDeletOrder')"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 批量更改服务人员 -->
			<el-dialog
				title="是否确定更换选中工单的服务人员?"
				:close-on-click-modal="false"
				:visible.sync="dialogCareGiverName"
				width="500px"
				:before-close="handleCareGiveNmaeClose"
				center
			>
				<el-row type="flex" justify="center">
					<el-form
						:inline="true"
						:rules="formCareGiverNameRules"
						ref="formCareGiverName"
						:model="formCareGiverName"
						label-width="120px"
					>
						<el-form-item label="服务人员" prop="careGiverName">
							<el-autocomplete
								size="mini"
								:trigger-on-focus="true"
								style="width: 270px;margin-top:5px"
								v-model="formCareGiverName.careGiverName"
								popper-class="my-autocomplete"
								clearable
								:fetch-suggestions="queryEditStaffName"
								placeholder="请输入员工姓名"
								@select="selectEditStaffName"
								@input="removeEditStaffCode"
							>
								<template slot-scope="{ item }">
									<span class="name">
										{{ item.value }}
										<span v-if="item.value != '无'">({{ item.staffTel }})</span>
									</span>
								</template>
								<el-select v-model="sideType" slot="append" style="width:90px;" placeholder="请选择">
									<el-option label="本组" value="10"></el-option>
									<el-option label="跨组" value="20"></el-option>
								</el-select>
							</el-autocomplete>
						</el-form-item>
					</el-form>
				</el-row>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="careGiverNameCancel('formCareGiverName')">取 消</el-button>
					<el-button
						size="mini"
						style="margin-left:40px;"
						type="primary"
						@click="submitCareGiverName('formCareGiverName')"
						:disabled="isDisabled"
					>确 定</el-button>
				</div>
			</el-dialog>
			<!-- 组织 -->
			<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
				<org-select v-on:listenTochildEvent="getCurrentNode" />
			</el-dialog>
			<StaffSchedule
				v-if="staffScheduleVisible"
				:staffScheduleVisible="staffScheduleVisible"
				:isWeekDay="isWeekDay"
				@onStaffScheduleClose="onStaffScheduleClose"
			/>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import { changeYMD, parseTime } from "utils";
import StaffSchedule from "@/views/businessService/staffSchedule";
import { findValueBySetCode, getNow } from "api/common";
import Pagination from "components/Pagination/pagination";
import { timestampChangeDate } from "utils/index";
import {
	findWorkorderListForWeb,
	checkWorkOrderEffectiveness,
	findInServiceOrderList,
	findEtProductByDataAuthority,
	insertWorkorder,
	getWorkorderDetail,
	selectGiverListForSchedule,
	deleteWorkorderByCode,
	editWorkOrderForAudit,
	editWorkOrderForSettle,
	editWorkorder,
	batchDeleteWorkorderByCode,
	updateCareGiverByWorkorder
} from "api/workOrderManagement";
import { validateOrderTime } from "utils/validate";
import { hasPermission } from "@/utils/button";
import {
	findWorkorderSchedule,
	selectProductOrderServiceList
} from "api/businessService/orderPaymentReview";
export default {
	components: {
		HeadTag,
		StaffSchedule,
		Pagination,
		OrgSelect
	},
	props: {},
	data () {
		return {
			pickerOptions: {
				selectableRange: this.getNowTime(),
				disabledDate (time) {
					return time.getTime() < Date.now() - 1 * 24 * 3600 * 1000
				},
			},
			pickerEditOptions: {
				selectableRange: this.getEditTime(this.editTime),
				// selectableRange: this.editTime(),
				disabledDate (time) {
					return time.getTime() < Date.now() - 1 * 24 * 3600 * 1000
				},
			},
			showList: {
				workOrder_number_onClick: true
			},
			tagName: "工单信息",
			searchLoading: false,
			adreesDisabled: false,
			isAudit: false,
			isNoAudit: false,
			workOrderList: [],
			listLoading: false,
			totalCount: 0,
			orgcodeDisabled: true,
			multipleSelection: [],
			sideType: "10",
			isProduct: false,
			isProducts: true,
			deletrDistinguishStatus: "",
			recommendSource: "",
			editDistinguishStatus: "",
			//新建工单
			dialogWorkOrder: false,
			options: [
				{
					value: "40",
					name: "审核通过"
				},
				{
					value: "30",
					name: "审核不通过"
				}
			],
			//批量删除工单
			dialogBatchDeleteOrder: false,
			formBatchDeleteOrderRules: {
				delReason: [
					{
						required: true,
						// message: "请选择删除原因",
						trigger: "change"
					}
				]
			},
			formBatchDeletOrder: {
				delReason: ''
			},
			workorderSelectCodeList: [],
			//批量更改服务人员
			dialogCareGiverName: false,
			formCareGiverNameRules: {
				careGiverName: [
					{
						required: true,
						message: "请输入服务人员",
						trigger: "change"
					}
				],
			},
			formCareGiverName: {
				careGiverName: '',
				careGiverCode: '',
				workorderCodes: []
			},
			//删除工单
			dialogDeleteOrder: false,
			deletrWorkOrder: "",
			dialogEidtOrder: false,
			formEditOrderRules: {
				productName: [
					{
						required: true,
						message: "请选择产品名称",
						trigger: "change"
					}
				],
				careReceiverName: [
					{
						required: true,
						message: "请选择被照护人姓名",
						trigger: "change"
					}
				],
				careGiverName: [
					{
						required: true,
						message: "请选择服务人员姓名",
						trigger: "change"
					}
				],
				servicePositionCode: [
					{
						required: true,
						message: "请选择服务岗位",
						trigger: "change"
					}
				],
				planStartDate: [
					{
						required: true,
						message: "请选择开始时间",
						trigger: "change"
					}
				],
				planServiceDuration: [
					{
						required: true,
						message: "请输入服务时长",
						trigger: "blur"
					},
					{
						validator: validateOrderTime
					}
				]
			},
			formWorkOrderRules: {
				productName: [
					{
						required: true,
						message: "请选择产品名称",
						trigger: "change"
					}
				],
				careReceiverName: [
					{
						required: true,
						message: "请选择被照护人姓名",
						trigger: "change"
					}
				],
				careGiverName: [
					{
						required: true,
						message: "请选择服务人员姓名",
						trigger: "change"
					}
				],
				servicePositionCode: [
					{
						required: true,
						message: "请选择服务岗位",
						trigger: "change"
					}
				],
				planStartDate: [
					{
						required: true,
						message: "请选择开始时间",
						trigger: "change"
					}
				],
				planServiceDuration: [
					{
						required: true,
						message: "请输入服务时长",
						trigger: "blur"
					},
					{
						validator: validateOrderTime
					}
				]
			},
			editStartDate: "",
			editEndDate: "",
			startDate: "",
			endDate: "",
			editAuditStatus: "",
			editWorkorderCode: "",
			editWorkorderStatus: "",
			workorderCodeList: [],
			WorkOrderForSettleList: [],
			deleteType: '',
			formWorkOrder: {
				productCode: "",
				careReceiverCode: "",
				productName: "", //产品名称
				careReceiverName: "", //被照护人姓名
				orgCode: "",
				orgName: "",
				orderCode: "",
				planStartDate: "",
				planServiceDuration: "",
				planEndDate: "",
				servicePositionCode: "GW1911270089",
				servicePositionName: "护理员",
				careGiverCode: "",
				careGiverName: "",
				reportWorkorderServiceList: []
			},
			formEditOrder: {
				productCode: "",
				careReceiverCode: "",
				productName: "", //产品名称
				careReceiverName: "", //被照护人姓名
				orgCode: "",
				orgName: "",
				orderCode: "",
				planStartDate: "",
				planServiceDuration: "",
				planEndDate: "",
				servicePositionCode: "GW1911270089",
				servicePositionName: "护理员",
				careGiverCode: "",
				careGiverName: "",
				reportWorkorderServiceList: []

			},
			//组织
			dialogVisible: false,
			//保存按钮是否禁用
			cancleDisabled: false,
			receiverNameDisabled: true,
			//审核
			dialogAuditOrder: false,
			isDisabled: false,
			auditOptions: [],
			formDeletOrder: {
				delReason: ""
			},
			formAuditOrder: {
				auditStatus: "",
				personAuditReason: ""
			},
			formDeleteOrderRules: {
				delReason: [
					{
						required: true,
						// message: "请选择删除原因",
						trigger: "change"
					}
				]
			},
			formAuditOrderRules: {
				auditStatus: [
					{
						required: true,
						message: "请选择审核状态",
						trigger: "change"
					}
				],
				personAuditReason: [
					{
						required: true,
						message: "请输入审核原因",
						trigger: "blur"
					}
				]
			},
			isRadioShow: false,
			productTypeOptions: [],
			careReceiverNameOptions: [],
			staffPositionList: [], //新增护理人员
			staffUpdatePositionList: [],//更换护理人员 
			staffsPositionList: [],//批量更换护理人员
			distinguishStatusOptions: [],
			//未完成
			filters: {
				orgCode: "",
				distinguishStatus: "10",
				orgName: this.$store.getters.userOrgName, //组织
				orgCode: this.$store.getters.userOrgCode,
				workorderType: "", //工单类型
				workorderStatus: "", //工单状态
				auditStatus: "", //审核状态
				settleStatus: "", //结算状态
				careGiverName: "", //照护人
				careReceiverName: "", //被照护人
				planStartDate: "",
				delReason: '',//删除原因
				liveDetailAddress: '',//被照护人地址
				planEndDate: "",
				planDate: "",
				page: 1,
				pageSize: 10
			},
			workorderOptionsType: [],
			workorderStatusOptions: [],
			auditStatusOptions: [],
			auditReasonOptions: [],
			settleStatusOptions: [],
			delReasonOptions: [],
			staffScheduleVisible: false,
			isWeekDay: true,
			radio: "",
			deleteReason: "",
			selectDeleteReason: '',
			isSelectRadioShow: false,
			serviceItems: [],//服务项
			serviceEditItems: [],//修改服务项
			editServiceItems: [],
			serviceOptions: [],
			list: [],
			loading: false,
			serviceList: [],
			editTime: ''
			// reportWorkorderServiceList: []
		};
	},
	watch: {


	},
	computed: {},
	methods: {
		getNowTime () {
			var now = new Date();
			var year = now.getFullYear(); //得到年份
			var month = now.getMonth() + 1; //得到月份
			var day = now.getDate();
			var hour = now.getHours();
			var minute = now.getMinutes();
			var second = '00';
			var selectDate = `${hour}:${minute}:${second}-23:59:59`;
			return selectDate;
		},
		isToday (str) {
			var d = new Date(str.replace(/-/g, "/"));
			var todaysDate = new Date();
			if (d.setHours(0, 0, 0, 0) == todaysDate.setHours(0, 0, 0, 0)) {
				return true;
			} else {
				return false;
			}
		},
		getEditTime (editTime) {
			// debugger;
			if (editTime) {
				if (this.isToday(editTime) == false) {
					var selectDate = `00:00:00-23:59:59`;
					return selectDate;
				} else {
					if (this.isToday(editTime) == true) {
						var now = new Date();
						var year = now.getFullYear(); //得到年份
						var month = now.getMonth() + 1; //得到月份
						var day = now.getDate();
						var hour = now.getHours();
						var minute = now.getMinutes();
						var second = '00';
						var selectDate = `${hour}:${minute}:${second}-23:59:59`;
						return selectDate;

					}

				}
			}
		},
		p (s) {
			return s < 10 ? '0' + s : s;
		},

		/* 服务项 */
		selectProductOrderServiceListByOrderCode (orderCode) {
			let params = {
				orderCode: orderCode,
			};
			selectProductOrderServiceList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						if (response.data.responseData) {
							this.serviceInDtoList = response.data.responseData
							let list = response.data.responseData
							if (list.length > 0) {
								this.serviceList = list.map(item => {
									return {
										value: `${item.serviceCode}`,
										label: `${item.serviceCode}${item.serviceItem}`,
									}
								})
							}
							this.serviceEditItems = []
							/* 编辑回显 */
							this.formEditOrder.reportWorkorderServiceList.forEach((serviceItem, index) => {
								var isExit = false;
								this.serviceList.forEach(item => {
									if (item.value == serviceItem.serviceCode) {
										// this.serviceItems.push({ lable: serviceItem.serviceItem, value: serviceItem.serviceCode })
										isExit = true;
									}

								})
								this.serviceEditItems.push(serviceItem.serviceCode)
								//合并去重
								if (!isExit) {
									var unExitItem = this.formEditOrder.reportWorkorderServiceList[index];
									var obj = {
										value: `${unExitItem.serviceCode}`,
										label: `${unExitItem.serviceCode}${unExitItem.serviceItem}`,
									}
									this.serviceList.push(obj);
									this.serviceInDtoList.push(unExitItem);
								}
							})
							this.serviceOptions = [...this.serviceList];
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {

					return false;
				});

		},
		/* 新增服务项 */
		selectAddService () {
			if (this.serviceList.length == 0) {
				this.$message.error('请先选择被照护人')
				return false
			} else {
				this.serviceOptions = this.serviceList
			}
		},
		remoteAddMethod (queryString, cb) {
			if (queryString !== '') {
				this.serviceOptions = this.serviceList.filter(item => {
					return item.label.indexOf(queryString) != -1;
				});
			} else {
				this.serviceOptions = [];
			}
		},
		selectAddItems (val) {
			console.log(val, '新增')
			let list = val
			if (list.length > 0) {
				this.formWorkOrder.reportWorkorderServiceList = []
				for (let i = 0; i < list.length; i++) {
					for (let k = 0; k < this.serviceInDtoList.length; k++) {
						if (list[i] === this.serviceInDtoList[k].serviceCode) {
							this.formWorkOrder.reportWorkorderServiceList.push(this.serviceInDtoList[k]);
							break;
						}
					}
				}
			} else {
				this.formWorkOrder.reportWorkorderServiceList = []
			}
		},
		/* 编辑服务项 */
		selectEditService () {
			if (this.serviceList.length == 0) {
				this.$message.error('请先选择被照护人')
				return false
			} else {
				this.serviceOptions = this.serviceList
			}
		},
		remoteEditMethod (queryString, cb) {
			if (queryString !== '') {
				this.serviceOptions = this.serviceList.filter(item => {
					return item.label.indexOf(queryString) != -1;
				});
			} else {
				this.serviceOptions = [];
			}
		},
		selectEditItems (val) {
			console.log(val, '编辑')
			let list = val
			if (list.length > 0) {
				this.formEditOrder.reportWorkorderServiceList = []
				for (let i = 0; i < list.length; i++) {
					for (let k = 0; k < this.serviceInDtoList.length; k++) {
						if (list[i] === this.serviceInDtoList[k].serviceCode) {
							this.formEditOrder.reportWorkorderServiceList.push(this.serviceInDtoList[k]);
							break;
						}
					}
				}
			} else {
				this.formEditOrder.reportWorkorderServiceList = []
			}
		},
		changeRadio (val) {
			// console.log(val)
			if (val == 30) {
				this.filters.liveDetailAddress = '';
				this.adreesDisabled = true
			} else {
				this.adreesDisabled = false
			}
		},
		selectAudit (val) {
			console.log(val)
			if (val == 40) {
				//审核通过 不出现验证
				this.isAudit = false
				this.isNoAudit = true
				this.$nextTick(() => {
					this.$refs["formAuditOrder"].clearValidate("personAuditReason");
				});
			} else {
				this.isAudit = true
				this.isNoAudit = false
				this.$refs["formAuditOrder"].validateField("personAuditReason");
			}
		},
		resetForm () {
			this.$refs.filterForm.resetFields();
			this.filters.liveDetailAddress = '';
			this.filters.productCode = "";
			this.adreesDisabled = false;
			this.getList();
		},
		queryGetList () {
			this.filters.page = 1
			this.getList();
		},
		onRadioChange (val) {
			// console.log(val)
			if (val == '其他') {
				this.isRadioShow = true;
			} else {
				this.deleteReason = ''
				this.isRadioShow = false
			}
		},
		onRadioSlectChange (val) {
			// console.log(val)
			if (val == '其他') {
				this.isSelectRadioShow = true;
			} else {
				this.selectDeleteReason = ''
				this.isSelectRadioShow = false
			}
		},
		//产品名称模糊查询
		selectProductTypeName (item) {
			console.log(item)
			if (item.value !== "无") {
				this.formWorkOrder.productCode = item.code;
				this.formWorkOrder.productName = item.value;
				this.formEditOrder.productCode = item.code;
				this.formEditOrder.productName = item.value;
				this.receiverNameDisabled = false;
			} else {
				this.formWorkOrder.productName = "";
				this.formEditOrder.productName = "";
			}
		},
		removeProductTypeName () {
			this.receiverNameDisabled = true;
			// this.formWorkOrder.productCode = "";
			this.formEditOrder.productCode = "";
			this.formWorkOrder.orgCode = '';
			this.formWorkOrder.orgName = '';
			this.formWorkOrder.orderCode = '';
			this.formWorkOrder.careReceiverCode = "";
			this.formWorkOrder.careReceiverName = "";
			this.$nextTick(() => {
				this.$refs.formWorkOrder.clearValidate("careReceiverName");
			});
		},
		queryProductTypeName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					productType: 10,
					productName: queryString
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					productType: 10,
					productName: queryString
				};
			}
			findEtProductByDataAuthority(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.productTypeOptions = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.productTypeOptions.push({
								value: data[i].productName,
								code: data[i].productCode
							});
						}
						this.receiverNameDisabled = true
						var results = this.productTypeOptions;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//单个产品
		getOneproduct () {
			var params = {
				pageNum: 1,
				pageSize: 10,
				productType: 10
			}
			findEtProductByDataAuthority(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							if (data.length == 1) {
								this.receiverNameDisabled = false;
								this.formWorkOrder.productName = data[i].productName
								this.formWorkOrder.productCode = data[i].productCode
							}
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					return false;
				});
		},
		//新增被照护人姓名
		selectCareReceiverName (item) {
			if (item.value !== "无") {
				this.formWorkOrder.careReceiverCode = item.code;
				this.formWorkOrder.careReceiverName = item.value;
				console.log(this.careReceiverNameOptions)
				this.careReceiverNameOptions.forEach((v) => {
					if (this.formWorkOrder.careReceiverCode == v.code) {
						this.formWorkOrder.orgCode = v.orgCode;
						this.formWorkOrder.orgName = v.orgName;
						this.formWorkOrder.orderCode = v.orderCode;
						this.formWorkOrder.planServiceDuration = v.serviceDuration;//默认服务时长
					}
				})
				this.selectProductOrderServiceListByOrderCode(this.formWorkOrder.orderCode);
			} else {
				this.formWorkOrder.careReceiverName = "";
				// this.formEditOrder.careReceiverName = "";
			}
		},
		selectEditCareReceiverName (item) {
			if (item.value !== "无") {
				this.formEditOrder.careReceiverCode = item.code;
				this.formEditOrder.careReceiverName = item.value;
			} else {
				this.formEditOrder.careReceiverName = "";
			}
		},
		removeCareReceiverName () {
			this.formWorkOrder.careReceiverCode = "";
			this.formWorkOrder.careReceiverName = "";
			this.formWorkOrder.orgCode = '';
			this.formWorkOrder.orgName = '';
			this.formWorkOrder.orderCode = '';
			this.serviceItems = []
			this.reportWorkorderServiceList = []
			this.$forceUpdate()
		},
		removeEditCareReceiverName () {
			this.formEditOrder.careReceiverName = "";
		},
		queryCareReceiverName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.formWorkOrder.productCode,
					careReceiverName: queryString
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.formWorkOrder.productCode,
					careReceiverName: queryString
				};
			}
			findInServiceOrderList(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.careReceiverNameOptions = [];//新增护理人员
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.careReceiverNameOptions.push({
								value: data[i].careReceiverName,
								code: data[i].careReceiverCode,
								careReceiverTel: data[i].careReceiverTel,
								orderCode: data[i].orderCode,
								orgCode: data[i].orgCode,
								orgName: data[i].orgName,
								serviceDuration: data[i].serviceDuration
							});
						}
						var results = this.careReceiverNameOptions;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		// queryCareEditReceiverName (queryString, cb) {
		// 	let params = {};
		// 	if (queryString) {
		// 		params = {
		// 			pageNum: 1,
		// 			pageSize: 10,
		// 			productCode: this.formEditOrder.productCode,
		// 			careReceiverName: queryString
		// 		};
		// 	} else {
		// 		params = {
		// 			pageNum: 1,
		// 			pageSize: 10,
		// 			productCode: this.formEditOrder.productCode,
		// 			careReceiverName: queryString
		// 		};
		// 	}
		// 	findInServiceOrderList(params)
		// 		.then(response => {
		// 			if (response.data.statusCode === "200") {
		// 				this.careReceiverNameOptions = [];
		// 				var data = response.data.responseData;
		// 				for (let i = 0; i < data.length; i++) {
		// 					this.careReceiverNameOptions.push({
		// 						value: data[i].careReceiverName,
		// 						code: data[i].careReceiverCode,
		// 						careReceiverTel: data[i].careReceiverTel,
		// 						orderCode: data[i].orderCode,
		// 						orgCode: data[i].orgCode,
		// 						orgName: data[i].orgName,
		// 						serviceDuration: data[i].serviceDuration
		// 					});
		// 				}
		// 				var results = this.careReceiverNameOptions;
		// 				if (results.length === 0) {
		// 					results = [{ value: "无", code: "-1" }];
		// 				}
		// 				cb(results);
		// 			} else {
		// 				this.$message.error(response.data.statusMsg);
		// 				return false;
		// 			}
		// 		})
		// 		.catch(error => {
		// 			console.log("findEhrPositionList:" + error);
		// 			return false;
		// 		});
		// },
		//新增护理人员
		selectStaffName (item) {
			if (item.value !== "无") {
				this.formWorkOrder.staffTel = item.staffTel;
				this.formWorkOrder.careGiverCode = item.code;
				this.formWorkOrder.careGiverName = item.value;
			} else {
				this.formWorkOrder.careGiverName = "";
			}
		},
		//修改护理人员
		selectUpdateStaffName (item) {
			if (item.value !== "无") {
				this.formEditOrder.staffTel = item.staffTel;
				this.formEditOrder.careGiverCode = item.code;
				this.formEditOrder.careGiverName = item.value;
			} else {
				this.formEditOrder.careGiverName = "";
			}
		},
		selectEditStaffName (item) {
			if (item.value !== "无") {
				this.formCareGiverName.careGiverName = item.value
				this.formCareGiverName.careGiverCode = item.code
			} else {
				this.formCareGiverName.careGiverName = '';
			}
		},
		removeEditStaffCode () {
			this.formCareGiverName.careGiverCode = '';
			this.formCareGiverName.careGiverName = '';
		},
		removeStaffCode () {
			this.formWorkOrder.careGiverCode = "";
			this.formWorkOrder.careGiverName = "";
		},
		removeUpdateStaffCode () {
			this.formEditOrder.careGiverCode = "";
			this.formEditOrder.careGiverName = "";
		},
		//新增护理人员
		queryStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formWorkOrder.orgCode,
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formWorkOrder.orgCode,
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffPositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffPositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel,
								positionName: data[i].positionName
							});
						}
						var results = this.staffPositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//修改护理人员
		queryUpdateStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formEditOrder.orgCode
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formEditOrder.orgCode
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffUpdatePositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffUpdatePositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel,
								positionName: data[i].positionName
							});
						}
						var results = this.staffUpdatePositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//批量修改护理人员
		queryEditStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formWorkOrder.orgCode,
					orgCode: this.formEditOrder.orgCode
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.formWorkOrder.orgCode,
					orgCode: this.formEditOrder.orgCode
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffsPositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffsPositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel
							});
						}
						var results = this.staffsPositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		//修改开始时间计算结束时间
		changeEndTime () {
			var workTime = this.formWorkOrder.planStartDate.substring(-1, 11)
			this.pickerOptions.selectableRange = this.getEditTime(workTime)
			if (this.formWorkOrder.planServiceDuration != "" && this.formWorkOrder.planStartDate != "") {
				this.computeEndTime();
			} else {
				return false;
			}
		},
		changeEditEndTime () {
			var workTime = this.formEditOrder.planStartDate.substring(-1, 11)
			this.pickerEditOptions.selectableRange = this.getEditTime(workTime)
			if (this.formEditOrder.planServiceDuration != "" && this.formEditOrder.planStartDate != "") {
				this.editComputeEndTime();
			} else {
				return false;
			}
		},
		selectTime (val) {
			console.log(val)
		},
		//计算结束时间
		computeEndTime () {
			if (
				this.formWorkOrder.planServiceDuration != "" &&
				this.formWorkOrder.planServiceDuration > 0
			) {
				var startTime = this.formWorkOrder.planStartDate;
				startTime = startTime.replace(new RegExp("-", "gm"), "/");
				var startTimeM = new Date(startTime).getTime();
				var timeDuration =
					this.formWorkOrder.planServiceDuration * 60 * 60 * 1000;
				var endTime = parseTime(timeDuration + startTimeM);
				var timearr = endTime
					.replace(" ", ":")
					.replace(/\:/g, "-")
					.split("-");
				var timestr =
					"" +
					timearr[0] +
					"-" +
					timearr[1] +
					"-" +
					timearr[2] +
					" " +
					timearr[3] +
					":" +
					timearr[4];
				this.formWorkOrder.planEndDate = timestr;
			} else {
				return false;
			}
		},
		//编辑
		editComputeEndTime () {
			if (
				this.formEditOrder.planServiceDuration != "" &&
				this.formEditOrder.planServiceDuration > 0
			) {
				var startTime = this.formEditOrder.planStartDate;
				startTime = startTime.replace(new RegExp("-", "gm"), "/");
				var startTimeM = new Date(startTime).getTime();
				var timeDuration =
					this.formEditOrder.planServiceDuration * 60 * 60 * 1000;
				var endTime = parseTime(timeDuration + startTimeM);
				var timearr = endTime
					.replace(" ", ":")
					.replace(/\:/g, "-")
					.split("-");
				var timestr =
					"" +
					timearr[0] +
					"-" +
					timearr[1] +
					"-" +
					timearr[2] +
					" " +
					timearr[3] +
					":" +
					timearr[4];
				this.formEditOrder.planEndDate = timestr;
			} else {
				return false;
			}
		},
		/**
		 *
		 * 查询条件开窗选择组织
		 *
		 */
		close () {
			this.dialogVisible = false;
		},
		getCurrentNode (data) {
			this.filters.orgName = data.orgName;
			this.filters.orgCode = data.orgCode;
			this.close();
		},
		//清空组织过滤
		clearOrgCode () {
			this.filters.orgName = "";
			this.filters.orgCode = "";
		},
		getList () {
			// this.filters.page = page;
			var params = {
				pageNum: this.filters.page,
				pageSize: this.filters.pageSize,
				orgCode: this.filters.orgCode,
				orgName: this.filters.orgName,
				workorderType: this.filters.workorderType,
				workorderStatus: this.filters.workorderStatus,
				distinguishStatus: this.filters.distinguishStatus,
				auditStatus: this.filters.auditStatus,
				auditReason: this.filters.auditReason,
				settleStatus: this.filters.settleStatus,
				careGiverName: this.filters.careGiverName,
				careReceiverName: this.filters.careReceiverName,
				liveDetailAddress: this.filters.liveDetailAddress,
				delReason: this.filters.delReason,
				planStartDate:
					this.filters.planDate != null ? this.filters.planDate[0] : null,
				planEndDate:
					this.filters.planDate != null ? this.filters.planDate[1] : null
			};
			this.listLoading = true;
			this.searchLoading = true;
			findWorkorderListForWeb(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						if (response.data.responseData != undefined) {
							this.workOrderList = response.data.responseData;
							for (let i = 0; i < this.workOrderList.length; i++) {
								if (this.workOrderList[i].planStartDate) {
									this.workOrderList[i].planStartDate = this.workOrderList[
										i
									].planStartDate;
								}
								if (this.workOrderList[i].planEndDate) {
									this.workOrderList[i].planEndDate = this.workOrderList[
										i
									].planEndDate;
								}
							}
							this.totalCount = response.data.totalCount;
							this.listLoading = false;
							this.searchLoading = false;
						} else {
							this.listLoading = false;
							this.searchLoading = false;
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findWorkorderListForWeb:" + error);
					this.listLoading = false;
					this.searchLoading = false;
					return false;
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getList(val.page); //改变页码，重新渲染页面
		},

		changeOrder (row) {
			// this.formEditOrder.workorderCode = row.workorderCode
			this.$router.push({
				path: "/workOrderManagement/updateOrder",
				query: {
					workorderCode: row.workorderCode,
					auditStatus: row.auditStatus,
					workorderStatus: row.workorderStatus,
					distinguishStatus: row.distinguishStatus
				}
			});
		},
		//新增
		insertWorkOrders () {
			this.dialogWorkOrder = true
			this.getOneproduct()
		},
		cancleWorkOrder (formWorkOrder) {
			this.$refs[formWorkOrder].resetFields();
			this.formWorkOrder.orgName = "";
			this.formWorkOrder.orderCode = "";
			this.formWorkOrder.planEndDate = "";
			this.formWorkOrder.careGiverName = "";
			this.serviceItems = []
			this.reportWorkorderServiceList = []
			this.dialogWorkOrder = false;
			this.receiverNameDisabled = true;
		},
		workOrderSubmit (formName) {
			if (this.careReceiverNameOptions.length == 0) {
				this.formWorkOrder.careReceiverName = "";
				this.$message.error("请选择正确的被照护人姓名")
			} else {
				this.$refs[formName].validate(valid => {
					if (valid) {
						this.checkWorkOrderEffectiveness();
					} else {
						this.$message.error("请检查是否填写完整");
						return false;
					}
				});
			}
		},
		//员工排程
		staffOrders () {
			this.staffScheduleVisible = true;
			this.isWeekDay = false; //TODO 根据工单的排程类型是否为周传值
		},
		//更换服务人员
		changeCareGiverName () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				this.dialogCareGiverName = true;
				let staffId = ""
				for (let i = 0; i < list.length; i++) {
					staffId = list[0].careGiverCode;
					if (list[i].workorderStatus == "10") {
						if (staffId != list[i].careGiverCode) {
							this.dialogCareGiverName = false;
							this.$message.error("请选择同一服务人员进行更换哦");
							return false
						}
						this.formCareGiverName.workorderCodes[i] = list[i].workorderCode;
					} else {
						this.dialogCareGiverName = false;
						this.$message.error("请选择未签入的工单");
						this.formCareGiverName.workorderCodes = [];
						return false;
					}
				}
			}
		},
		submitCareGiverName (formCareGiverName) {
			this.$refs[formCareGiverName].validate(valid => {
				if (valid) {
					var params = {
						workorderCodes: this.formCareGiverName.workorderCodes,
						careGiverName: this.formCareGiverName.careGiverName,
						careGiverCode: this.formCareGiverName.careGiverCode,
					};
					updateCareGiverByWorkorder(params)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.dialogCareGiverName = false;
								this.formCareGiverName.workorderCodes = []
								this.formCareGiverName.careGiverCode = ''
								this.formCareGiverName.careGiverName = ''
								this.formWorkOrder.careGiverCode = '';
								this.formWorkOrder.careGiverName = '';
								this.getList();
								this.$refs[formCareGiverName].resetFields();
							} else {
								this.$alert('<font color=red>' + response.data.statusMsg + '</font>', {
									dangerouslyUseHTMLString: true
								});
								return false;
							}
						})
						.catch(error => {
							this.$message.error(this.ConstantData.requestErrorMsg)
						});
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});
		},
		careGiverNameCancel (formCareGiverName) {
			this.formWorkOrder.careGiverCode = '';
			this.formWorkOrder.careGiverName = '';
			this.formCareGiverName.scheduleCodes = []
			this.$refs[formCareGiverName].resetFields();
			this.dialogCareGiverName = false;
		},
		handleCareGiveNmaeClose () {
			this.formWorkOrder.careGiverCode = '';
			this.formWorkOrder.careGiverName = '';
			this.formCareGiverName.scheduleCodes = []
			this.$refs["formCareGiverName"].resetFields()
			this.dialogCareGiverName = false
		},
		//查看详情
		detailOrder (row) {
			this.$router.push({
				path: "/workOrderManagement/detailOrder",
				query: {
					workorderCode: row.workorderCode,
					auditStatus: row.auditStatus,
					workorderStatus: row.workorderStatus,
					distinguishStatus: row.distinguishStatus
				}
			});
		},
		//审核
		examineOrders () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				this.dialogAuditOrder = true;
				// debugger;
				for (let i = 0; i < list.length; i++) {
					if (
						list[i].auditStatus == "20"
					) {
						this.workorderCodeList[i] = list[i].workorderCode;
					} else {
						this.dialogAuditOrder = false;
						this.$message.error("审核状态待审核，才能审核");
						this.workorderCodeList = []
						return false;
					}
				}
			}
		},
		//结算完成
		FinshOrders () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				for (let i = 0; i < list.length; i++) {
					if (
						list[i].workorderStatus == "30" &&
						list[i].auditStatus == "40" &&
						list[i].distinguishStatus == "20"
					) {
						this.WorkOrderForSettleList[i] = list[i].workorderCode;
					} else {
						this.$message.error("工单状态已签出审核状态审核通过，才能结算");
						return false;
					}
				}
			}
			var params = {
				workorderCodeList: this.WorkOrderForSettleList
			};
			editWorkOrderForSettle(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						this.getList();
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		handleClose () {
			this.isAudit = false;
			this.isNoAudit = false;
			this.formAuditOrder.auditStatus = ''
			this.workorderCodeList = []
			this.$refs["formAuditOrder"].resetFields();
			this.formWorkOrder.dialogEidtOrder = false;
			this.dialogAuditOrder = false;
		},
		handleOrderClose () {
			this.formWorkOrder.planEndDate = "";
			this.formWorkOrder.orgName = "";
			this.formWorkOrder.orderCode = "";
			this.formWorkOrder.careGiverName = "";
			this.$refs["formWorkOrder"].resetFields();
			this.serviceItems = []
			this.formWorkOrder.reportWorkorderServiceList = []
			this.dialogWorkOrder = false;
			this.receiverNameDisabled = true;

		},
		handleDelteClose () {
			this.isRadioShow = false;
			this.deleteReason = '';
			this.formDeletOrder.delReason = ''
			this.dialogDeleteOrder = false;
		},
		handleBatchDelteClose () {
			this.workorderSelectCodeList = []
			this.isSelectRadioShow = false
			this.formBatchDeletOrder.delReason = ''
			this.selectDeleteReason = ''
			this.dialogBatchDeleteOrder = false;
		},
		handleEditOrderClose () {
			this.dialogEidtOrder = false;
			this.formEditOrder.workorderCode = "";
			this.$refs["formEditOrder"].resetFields();
		},
		clearVal () {
			this.isAudit = false
			this.isNoAudit = false
		},
		auditOrderSubmit (formAuditOrder) {
			console.log(formAuditOrder)
			this.$refs[formAuditOrder].validate(valid => {
				if (valid) {
					console.log(valid)
					var params = {
						workorderCodeList: this.workorderCodeList,
						auditStatus: this.formAuditOrder.auditStatus,
						personAuditReason: this.formAuditOrder.personAuditReason
					};
					editWorkOrderForAudit(params)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.dialogAuditOrder = false;
								this.workorderCodeList = []
								this.isAudit = false;
								this.isNoAudit = false;
								this.formAuditOrder.auditStatus = ''
								this.formAuditOrder.personAuditReason = ''
								this.$refs[formAuditOrder].resetFields();
								this.getList();
							} else {
								this.formAuditOrder.auditStatus = ''
								this.formAuditOrder.personAuditReason = ''
								this.workorderCodeList = []
								this.$message.error(response.data.statusMsg);
								return false;
							}
						})
						.catch(error => {
							console.log(error);
						});
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});
		},
		cancelAuditOrder (formAuditOrder) {
			this.isAudit = false;
			this.isNoAudit = false;
			this.workorderCodeList = []
			this.formAuditOrder.personAuditReason = '';
			this.$refs[formAuditOrder].resetFields();
			this.dialogAuditOrder = false;
		},
		handleSelectionChange (val) {
			this.multipleSelection = val;
		},
		onStaffScheduleClose () {
			this.staffScheduleVisible = false;
		},
		//修改
		editOrder (auditStatus, workorderStatus, workorderCode, distinguishStatus) {
			this.editAuditStatus = auditStatus;
			// this.editWorkorderCode = workorderCode;
			this.editWorkorderStatus = workorderStatus;
			this.editDistinguishStatus = distinguishStatus;
			var params = {
				workorderCode: workorderCode,
				auditStatus: this.editAuditStatus,
				workorderStatus: this.editWorkorderStatus,
				distinguishStatus: this.editDistinguishStatus
			};
			getWorkorderDetail(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.formEditOrder.productName =
							response.data.responseData.productName;
						this.formEditOrder.workorderCode =
							response.data.responseData.workorderCode;
						this.formEditOrder.productCode =
							response.data.responseData.productCode;
						this.formEditOrder.careReceiverCode =
							response.data.responseData.careReceiverCode;
						this.formEditOrder.careReceiverName =
							response.data.responseData.careReceiverName;
						this.formEditOrder.orgName = response.data.responseData.orgName;
						this.formEditOrder.orgCode = response.data.responseData.orgCode;
						this.formEditOrder.orderCode = response.data.responseData.orderCode;
						this.formEditOrder.careGiverName =
							response.data.responseData.careGiverName;
						this.formEditOrder.careGiverCode =
							response.data.responseData.careGiverCode;
						this.formEditOrder.servicePositionCode =
							response.data.responseData.servicePositionCode;
						this.formEditOrder.planStartDate =
							response.data.responseData.planStartDate;
						this.editTime = response.data.responseData.planStartDate.substring(-1, 11);
						console.log(this.editTime, 'this.editTime')
						this.formEditOrder.workorderType = response.data.responseData.workorderType
						this.formEditOrder.planServiceDuration =
							response.data.responseData.planServiceDuration;
						this.formEditOrder.planEndDate =
							response.data.responseData.planEndDate;
						this.formEditOrder.reportWorkorderServiceList = response.data.responseData.reportWorkorderServiceList;
						console.log(this.formEditOrder.reportWorkorderServiceList, '编辑')
						this.dialogEidtOrder = true;
						//服务项回填
						this.selectProductOrderServiceListByOrderCode(this.formEditOrder.orderCode)
						this.getEditTime(this.editTime)
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					return false;
				});
		},
		//批量删除
		selectDelete () {
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else {
				this.dialogBatchDeleteOrder = true;
				for (let i = 0; i < list.length; i++) {
					if (
						list[i].workorderStatus == "10"
					) {
						this.workorderSelectCodeList[i] = list[i].workorderCode;
					} else {
						this.dialogBatchDeleteOrder = false;
						this.workorderSelectCodeList = []
						this.$message.error("签入状态未签入，才能删除");
						return false;
					}
				}
			}
		},
		submitBatchOrder (formBatchDeletOrder) {
			if (this.formBatchDeletOrder.delReason !== '') {
				this.isDisabled = true
				if (this.formBatchDeletOrder.delReason == '其他') {
					this.formBatchDeletOrder.delReason = this.selectDeleteReason
				}
				var params = {
					workorderCodeList: this.workorderSelectCodeList,
					delReason: this.formBatchDeletOrder.delReason
				};
				batchDeleteWorkorderByCode(params)
					.then(response => {
						if (response.data.statusCode == "200") {
							this.$message.success("操作成功");
							this.dialogBatchDeleteOrder = false;
							this.isDisabled = false
							this.workorderSelectCodeList = []
							this.getList();
							this.isSelectRadioShow = false;
							this.formBatchDeletOrder.delReason = ''
							this.selectDeleteReason = ''
						} else {
							this.$message.error(response.data.statusMsg);
							this.isDisabled = false
							return false;
						}
					})
					.catch(error => {
						this.isDisabled = false
						console.log(error);
					});
			} else {
				this.$message.error("请选择删除原因");
				return false;
			}
		},
		deleteBatchCancel (formBatchDeletOrder) {
			this.workorderSelectCodeList = []
			this.isSelectRadioShow = false;
			this.formBatchDeletOrder.delReason = ''
			this.selectDeleteReason = ''
			this.dialogBatchDeleteOrder = false;
		},
		//删除
		deleteOrder (workorderCode, distinguishStatus, workorderType) {
			this.deleteType = workorderType
			this.deletrWorkOrder = workorderCode;
			this.deletrDistinguishStatus = distinguishStatus;
			this.dialogDeleteOrder = true;
		},
		submitOrder (formDeletOrder) {
			if (this.formDeletOrder.delReason !== '') {
				this.isDisabled = true
				if (this.formDeletOrder.delReason == '其他') {
					this.formDeletOrder.delReason = this.deleteReason
				}
				var params = {
					workorderCode: this.deletrWorkOrder,
					distinguishStatus: this.deletrDistinguishStatus,
					delReason: this.formDeletOrder.delReason,
					isDeleteSchedule: 0
				};
				deleteWorkorderByCode(params)
					.then(response => {
						if (response.data.statusCode == 200) {
							this.$message.success("操作成功");
							this.isDisabled = false
							this.dialogDeleteOrder = false;
							this.isRadioShow = false;
							this.deleteReason = '';
							this.formDeletOrder.delReason = ''
							this.getList();
						} else {
							this.$message.error(response.data.statusMsg);
							this.isDisabled = false
							return false;
						}
					})
					.catch(error => {
						console.log(error);
						this.isDisabled = false;
						return false;
					});
			} else {
				this.$message.error("请选择删除原因");
				return false;
			}
		},
		deleteCancel (formDeletOrder) {
			this.isRadioShow = false;
			this.formDeletOrder.delReason = ''
			this.deleteReason = ''
			this.dialogDeleteOrder = false;
		},
		cancleEditOrder () {
			this.formEditOrder.workorderCode = "";

			this.dialogEidtOrder = false;
		},
		editOrderSubmit (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					this.checkWorkOrderEffectiveness();
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});

		},
		//时间核算接口
		checkWorkOrderEffectiveness () {
			let careReceiverCode = "";
			let orderCode = "";
			let workorderCode = "";
			let productCode = "";
			let productName = "";
			if (this.formEditOrder.workorderCode) {
				this.editStartDate = this.formEditOrder.planStartDate;
				this.editEndDate = this.formEditOrder.planEndDate;
				careReceiverCode = this.formEditOrder.careReceiverCode;
				orderCode = this.formEditOrder.orderCode;
				workorderCode = this.formEditOrder.workorderCode;
				productCode = this.formEditOrder.productCode
				productName = this.formEditOrder.productName
			} else {
				this.startDate = this.formWorkOrder.planStartDate;
				this.endDate = this.formWorkOrder.planEndDate;
				careReceiverCode = this.formWorkOrder.careReceiverCode;
				orderCode = this.formWorkOrder.orderCode;
				productCode = this.formWorkOrder.productCode
				productName = this.formWorkOrder.productName
			}
			let params = {
				planStartDate: this.startDate ? this.startDate : this.editStartDate,
				careReceiverCode: careReceiverCode,
				orderCode: orderCode,
				productCode: productCode,
				productName: productName,
				workorderCode: workorderCode ? workorderCode : '',
				planEndDate: this.endDate ? this.endDate : this.editEndDate
			};
			checkWorkOrderEffectiveness(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode === "200"
					) {
						this.getWorkorder();
					} else {
						this.$confirm(response.data.statusMsg, "提示", {
							confirmButtonText: "确定",
							cancelButtonText: "取消",
							type: "warning"
						})
							.then(() => {
								this.getWorkorder();
							})
							.catch(() => {
								this.$message({
									type: "info",
									message: "已取消"
								});
								if (this.formEditOrder.workorderCode != '') {
									this.formEditOrder.workorderCode = ''
									this.dialogEidtOrder = false;
									this.receiverNameDisabled = true;
								}
								this.formWorkOrder.orgCode = "";
								this.formWorkOrder.orgName = "";
								this.formWorkOrder.orderCode = "";
								this.formWorkOrder.planEndDate = "";
								this.formWorkOrder.careGiverName = "";
								this.$refs["formWorkOrder"].resetFields();
								this.dialogWorkOrder = false;
								this.receiverNameDisabled = true;
							});
						return false;
					}
				})
				.catch(error => {
					console.log("checkWorkOrderEffectiveness:" + error);
					return false;
				});
		},
		//新增 修改 工单保存接口
		getWorkorder () {
			if (this.cancleDisabled == false) {
				this.cancleDisabled = true;
				if (this.formEditOrder.workorderCode) {
					let params = {
						orgCode: this.formEditOrder.orgCode,
						orgName: this.formEditOrder.orgName,
						orderCode: this.formEditOrder.orderCode,
						distinguishStatus: this.editDistinguishStatus,
						workorderCode: this.formEditOrder.workorderCode,
						planStartDate: this.editStartDate,
						careReceiverCode: this.formEditOrder.careReceiverCode,
						careReceiverName: this.formEditOrder.careReceiverName,
						servicePositionCode: this.formEditOrder.servicePositionCode,
						servicePositionName:
							this.formEditOrder.servicePositionCode == "GW1911270089"
								? "护理员"
								: "护士",
						workorderType: this.formEditOrder.workorderType,
						careGiverCode: this.formEditOrder.careGiverCode,
						careGiverName: this.formEditOrder.careGiverName,
						planEndDate: this.editEndDate,
						planServiceDuration: this.formEditOrder.planServiceDuration,
						reportWorkorderServiceList: this.formEditOrder.reportWorkorderServiceList
					};
					editWorkorder(params)
						.then(response => {
							if (
								response.data.statusCode == 200 ||
								response.data.statusCode === "200"
							) {
								this.dialogEidtOrder = false;
								this.formEditOrder.workorderCode = "";
								// this.formEditOrder.servicePositionCode = "";
								this.receiverNameDisabled = true
								this.formEditOrder.serviceEditItems = ''
								this.getList();
								setTimeout(() => {
									this.cancleDisabled = false;
								}, 500 * Math.random());
							} else {
								this.$message.error(response.data.statusMsg);
								this.dialogEidtOrder = false;
								this.formEditOrder.workorderCode = "";
								this.cancleDisabled = false;
								this.receiverNameDisabled = true
								return false;
							}
						})
						.catch(error => {
							console.log("editWorkorder:" + error);
							return false;
						});
				} else {
					let params = {
						orgCode: this.formWorkOrder.orgCode,
						orgName: this.formWorkOrder.orgName,
						orderCode: this.formWorkOrder.orderCode,
						planStartDate: this.startDate,
						careReceiverCode: this.formWorkOrder.careReceiverCode,
						careReceiverName: this.formWorkOrder.careReceiverName,
						servicePositionCode: this.formWorkOrder.servicePositionCode,
						servicePositionName:
							this.formWorkOrder.servicePositionCode == "GW1911270089"
								? "护理员"
								: "护士",
						careGiverCode: this.formWorkOrder.careGiverCode,
						careGiverName: this.formWorkOrder.careGiverName,
						planEndDate: this.endDate,
						planServiceDuration: this.formWorkOrder.planServiceDuration,
						workorderType: 20,
						reportWorkorderServiceList: this.formWorkOrder.reportWorkorderServiceList
					};
					insertWorkorder(params)
						.then(response => {
							if (
								response.data.statusCode == 200 ||
								response.data.statusCode === "200"
							) {
								this.dialogWorkOrder = false;
								this.$refs["formWorkOrder"].resetFields();
								this.formWorkOrder.orgCode = "";
								this.formWorkOrder.orgName = "";
								this.formWorkOrder.orderCode = "";
								this.formWorkOrder.planEndDate = "";
								this.formWorkOrder.careGiverName = "";
								this.serviceItems = []
								this.formWorkOrder.reportWorkorderServiceList = []
								this.receiverNameDisabled = true
								this.getList();
								setTimeout(() => {
									this.cancleDisabled = false;
								}, 500 * Math.random());
							} else {
								this.$message.error(response.data.statusMsg);
								this.cancleDisabled = false;
								// this.dialogWorkOrder = false;
								return false;
							}
						})
						.catch(error => {
							console.log("insertWorkorder:" + error);
							return false;
						});
				}
			}
		},
		//删除工单

		/**
		 *
		 * 数据字典
		 *
		 */
		initDataDictionary () {
			//工单状态
			findValueBySetCode({ valueSetCode: "WORKORDER_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.workorderStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//工单审核状态
			findValueBySetCode({ valueSetCode: "WORKORDER_AUDIT_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.auditStatusOptions = response.data.responseData;
						// this.auditOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//工单审核原因
			findValueBySetCode({ valueSetCode: "SELECT_AUDIT_REASON" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.auditReasonOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//删除原因
			findValueBySetCode({ valueSetCode: "SELECT_DELETE_OR_UPDATE_REASON" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.delReasonOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//工单类型
			findValueBySetCode({ valueSetCode: "WORKORDER_TYPE" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.workorderOptionsType = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//现工单状态
			findValueBySetCode({ valueSetCode: "WORKORDER_DISTINGUISH_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.distinguishStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//结算状态
			findValueBySetCode({ valueSetCode: "SETTLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.settleStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		buttonControl () {
			this.showList.workOrder_number_onClick = hasPermission(
				"workOrder_number_onClick"
			);
		}
	},
	created () {
		this.buttonControl();
		this.initDataDictionary();
	},
	mounted () {

	},
	activated () {
		this.getList();
	}
};
</script>
<style lang="scss" scoped>
#workOrderManage {
	width: 100%;
	min-width: 1450px;
	.el-form-item {
		margin-bottom: 0px;
	}

	.el-input {
		width: 200px;
	}
	.el-select {
		width: 200px;
	}
	.el-autocomplete {
		width: 200px;
	}
	.form-item {
		width: 30%;
		min-width: 295px;
	}
	.workOrderClass {
		margin-top: 15px;
		margin-bottom: 0;
	}
	.form-items {
		width: 35%;
		min-width: 350px;
	}
	.search_btn {
		min-width: 250px;
		margin-left: 112px;
	}
	.deleteOrder {
		.el-radio {
			display: block;
			margin: 15px 0;
		}
	}
	.tableTopBtn {
		background-color: white;
		text-align: right;
		padding: 20px 20px 20px 0px;
	}
	.el-dialog {
		display: flex;
		flex-direction: column;
		margin: 0 !important;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}
	.el-dialog .el-dialog__body {
		flex: 1;
		overflow: auto;
	}
	.remark-style {
		display: block;
		width: 300px;
		margin-top: 5px;
	}
	.my-autocomplete {
		// height:40px;
		li {
			line-height: normal;
			padding: 7px;
			.name {
				text-overflow: ellipsis;
				overflow: hidden;
			}
		}
	}
}
</style>
<style lang="scss">
#workOrderManage {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
	.el-picker-panel__footer {
		.el-button--text {
			span {
				display: none !important;
			}
		}
	}
}
.el-picker-panel__footer {
	.el-button--text {
		span {
			display: none !important;
		}
	}
}
.el-autocomplete-suggestion__wrap {
	max-height: 380px;
}
.el-time-panel__footer {
	margin-right: 34px !important;
}
</style>
