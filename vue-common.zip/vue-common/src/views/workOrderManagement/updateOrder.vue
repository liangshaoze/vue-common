<template>
	<div id="updateOrder">
		<headTag :tagName="tagName" />
		<el-row class="main-content">
			<el-form
				ref="orderForm"
				:inline="false"
				:model="orderForm"
				:rules="rules"
				label-width="150px"
				class="form-content"
			>
				<el-col class="panel-card">
					<el-row class="titleToolbar">
						<el-col :span="24">
							<span class="form-tag">被照护人信息</span>
							<el-button
								type="primary"
								size="small"
								class="rightBtn"
								style="margin-left:20px;"
								@click="returnOrderList"
							>返回</el-button>
							<el-button
								size="small"
								type="primary"
								@click="saveWorkOrder('orderForm')"
								:loading="loadingBtn"
								class="rightBtn"
								v-if="btnShow"
							>保存</el-button>
							<el-button
								type="primary"
								size="small"
								class="rightBtn"
								@click="editOrder()"
								:loading="loadingBtn"
								v-if="!btnShow"
							>修改</el-button>
						</el-col>
					</el-row>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名:">
							<span>{{orderForm.careReceiverName}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人年龄:">
							<span>{{orderForm.careReceiverAge}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人身份证号:">
							<span>{{orderForm.careReceiverIdCard}}</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="被照护人地址:">
							<span
								class="long-field"
							>{{orderForm.liveProvinceName}}{{orderForm.liveCityName}}{{orderForm.liveDistrictName}}{{orderForm.liveSubdistrictName}}{{orderForm.liveDetailAddress}}</span>
							<el-button style="margin-left:20px;" size="mini" type="primary" @click="btnOrder()">查看订单</el-button>
						</el-form-item>
					</el-col>
				</el-col>
				<el-col class="panel-card" style="padding-bottom:40px;">
					<el-row class="titleToolbar">
						<el-col :span="24">
							<span class="form-tag">服务详情</span>
						</el-col>
					</el-row>
					<el-col class="form-items">
						<el-form-item label="计划时间:">
							<span v-if="isEdit == false">
								<span
									v-if="orderForm.planStartDate!=''"
								>{{orderForm.planStartDate}}-{{orderForm.planEndDate}}</span>
							</span>
							<span v-if="isEdit == true">
								<el-date-picker
									v-model="planDate"
									size="mini"
									type="datetimerange"
									range-separator="至"
									:disabled="true"
									format="yyyy-MM-dd HH:mm"
									value-format="yyyy-MM-dd HH:mm"
									@blur="choiceDatePicker"
									start-placeholder="开始日期"
									end-placeholder="结束日期"
								></el-date-picker>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="实际服务时长:">
							<span v-if="isEdit == false">
								<span v-if="orderForm.actServiceDuration">{{orderForm.actServiceDuration}}&nbsp;h</span>
							</span>
							<span v-if="isEdit == true">
								<el-input
									v-model="orderForm.actServiceDuration"
									size="mini"
									clearable
									placeholder="请输入时长"
									maxlength="5"
								/>&nbsp;h
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务人员:">
							<span v-if="isEdit == false">{{orderForm.careGiverName}}</span>
							<span v-if="isEdit == true">
								<el-autocomplete
									:trigger-on-focus="true"
									v-model="orderForm.careGiverName"
									popper-class="my-autocomplete"
									size="mini"
									clearable
									:fetch-suggestions="queryStaffName"
									placeholder="请输入员工姓名"
									@select="selectStaffName"
									@input="removeStaffCode"
								>
									<template slot-scope="{ item }">
										<span class="name">
											{{ item.value }}
											<span v-if="item.value != '无'">({{ item.staffTel }})</span>
										</span>
									</template>
									<template slot="append">
										<el-select v-model="sideType" slot="append" style="width:70px;" placeholder="请选择">
											<el-option label="本组" value="10"></el-option>
											<el-option label="跨组" value="20"></el-option>
										</el-select>
									</template>
								</el-autocomplete>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单类型:">
							<span v-if="isEdit == false">{{orderForm.workorderTypeValue}}</span>
							<span v-if="isEdit == true">
								<el-input
									v-model="orderForm.workorderTypeValue"
									:disabled="true"
									size="mini"
									clearable
									maxlength="20"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务时长:">
							<span v-if="isEdit == false">
								<span v-if="orderForm.planServiceDuration">{{orderForm.planServiceDuration}}&nbsp;h</span>
							</span>
							<span v-if="isEdit == true">
								<el-input
									v-model="orderForm.planServiceDuration"
									:disabled="true"
									size="mini"
									clearable
									maxlength="20"
								/>&nbsp;h
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签入状态:">
							<span v-if="isEdit == false">{{orderForm.workorderStatusValue}}</span>
							<span v-if="isEdit == true">
								<el-select size="mini" v-model="orderForm.workorderStatus" clearable placeholder="请选择">
									<el-option
										v-for="item in workorderStatusOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									/>
								</el-select>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="工单状态:">
							<span v-if="isEdit == false">{{orderForm.distinguishStatusValue}}</span>
							<span v-if="isEdit == true">
								<el-input size="mini" v-model="orderForm.distinguishStatusValue" :disabled="true" />
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="结算状态:">
							<span v-if="isEdit == false">{{orderForm.settleStatusValue}}</span>
							<span v-if="isEdit == true">
								<el-select size="mini" v-model="orderForm.settleStatus" clearable placeholder="请选择">
									<el-option
										v-for="item in settleStatusOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									/>
								</el-select>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="结算时间:">
							<span v-if="isEdit == false">{{orderForm.settleDate}}</span>
							<span v-if="isEdit == true">
								<el-date-picker
									size="mini"
									clearable
									v-model="orderForm.settleDate"
									type="datetime"
									format="yyyy-MM-dd HH:mm"
									value-format="yyyy-MM-dd HH:mm"
									placeholder="选择日期时间"
								></el-date-picker>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="审核状态:">
							<span v-if="isEdit == false">
								<span
									v-if="orderForm.auditStatus == '30'"
								>{{orderForm.auditStatusValue}}({{orderForm.personAuditReason}})</span>
								<span v-if="orderForm.auditStatus == '40'">
									{{orderForm.auditStatusValue}}
									<span
										v-if="orderForm.personAuditReason"
									>({{orderForm.personAuditReason}})</span>
								</span>
								<span v-if="orderForm.auditStatus == '20'">
									{{orderForm.auditStatusValue}}
									<span
										v-if="orderForm.personAuditReason"
									>({{orderForm.personAuditReason}})</span>
								</span>
								<span v-if="orderForm.auditStatus == '00'">
									{{orderForm.auditStatusValue}}
									<span
										v-if="orderForm.personAuditReason"
									>({{orderForm.personAuditReason}})</span>
								</span>
							</span>
							<span v-if="isEdit == true">
								<el-select size="mini" v-model="orderForm.auditStatus" clearable placeholder="请选择审核状态">
									<el-option
										v-for="item in auditStatusOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									/>
								</el-select>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="审核原因:">
							<span v-if="isEdit == false" class="long-field">{{orderForm.auditReason}}</span>
							<span v-if="isEdit == true">
								<el-input v-model="orderForm.auditReason" size="mini" clearable maxlength="50" />
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="删改原因:">
							<span v-if="isEdit == false" class="long-field">{{orderForm.delReason}}</span>
							<span v-if="isEdit == true">
								<el-input v-model="orderForm.delReason" size="mini" clearable maxlength="50" />
							</span>
						</el-form-item>
					</el-col>
					<!-- <el-col class="form-item">
						<el-form-item label="修改原因:">
							<span v-if="isEdit == false" class="long-field">{{orderForm.delReason}}</span>
							<span v-if="isEdit == true">
								<el-input v-model="orderForm.delReason" size="mini" clearable maxlength="50" />
							</span>
						</el-form-item>
					</el-col> -->
					<el-col class="form-item">
						<el-form-item label="签入时间:">
							<span v-if="isEdit == false">{{orderForm.checkinDate}}</span>
							<span v-if="isEdit == true">
								<el-date-picker
									size="mini"
									clearable
									v-model="orderForm.checkinDate"
									format="yyyy-MM-dd HH:mm"
									value-format="yyyy-MM-dd HH:mm"
									type="datetime"
									placeholder="选择日期时间"
								></el-date-picker>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签入地址:">
							<span v-if="isEdit == false" class="long-field">
								<span v-if="orderForm.checkinAddress">{{orderForm.checkinAddress}}</span>
								<span v-if="orderForm.checkinDistance">({{this.checkinDistance}})</span>
							</span>
							<span v-if="isEdit == true">
								<el-input v-model="orderForm.checkinAddress" size="mini" clearable maxlength="20" />
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签出时间:">
							<span v-if="isEdit == false">{{orderForm.checkoutDate}}</span>
							<span v-if="isEdit == true">
								<el-date-picker
									size="mini"
									clearable
									format="yyyy-MM-dd HH:mm"
									value-format="yyyy-MM-dd HH:mm"
									v-model="orderForm.checkoutDate"
									type="datetime"
									placeholder="选择日期时间"
								></el-date-picker>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="签出地址:">
							<span v-if="isEdit == false" class="long-field">
								<span v-if="orderForm.checkoutAddress">{{orderForm.checkoutAddress}}</span>
								<span v-if="orderForm.checkoutDistance">({{this.checkoutDistance}})</span>
							</span>
							<span v-if="isEdit == true">
								<el-input v-model="orderForm.checkoutAddress" size="mini" clearable maxlength="20" />
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="服务项:">
							<span v-if="isEdit == false" class="long-field">{{orderForm.serviceItems}}</span>
							<span v-if="isEdit == true">
								<el-input
									class="remark-style"
									v-model="orderForm.serviceItems"
									type="textarea"
									show-word-limit
									resize="none"
									rows="6"
									size="mini"
									clearable
									maxlength="500"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="上传照片:">
							<span v-if="checkinPhotosList.length>0 && isEdit == false ">
								<span style="width:100px;height:100px;" v-for="item in checkinPhotosList" :key="item.id">
									<img :src="item ? item : '' " style="width:100px;height:100px;" alt />
								</span>
							</span>
							<span v-if="isEdit == true">
								<el-upload
									ref="uploadBrief"
									:class="{hideBrief:hideBriefUpload}"
									:action="actionUrl"
									list-type="picture-card"
									:on-remove="removeBriefList"
									:on-success="handleBriefChange"
									accept="image/png, image/gif, image/jpg, image/jpeg"
									multiple
									:limit="limitImg"
									:file-list="briefFileList"
								>
									<i class="el-icon-plus"></i>
									<div slot="tip" style="font-size: 16px;color: #606266;" class="el-upload__tip">只能上传三张图片！</div>
									<el-dialog :visible.sync="dialogVisible">
										<img width="100%" :src="dialogImageUrl" alt />
									</el-dialog>
								</el-upload>
							</span>
						</el-form-item>
					</el-col>
				</el-col>

				<!-- 护理员 -->
				<el-col class="panel-card" style="padding-bottom:40px;" v-if="isShow">
					<el-col class="serviceDetail">
						<el-row class="titleToolbar">
							<el-col :span="24">
								<span class="form-tag">生命体征</span>
							</el-col>
						</el-row>
						<el-col class="form-itemd">
							<el-form-item label="收缩压:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.ssy">{{orderForm.ssy}}&nbsp;mmHg</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.ssy"
										size="mini"
										@input="change($event)"
										clearable
										maxlength="20"
									/>&nbsp;mmHg
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="舒张压:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.szy">{{orderForm.szy}}&nbsp;mmHg</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.szy"
										size="mini"
										@input="change($event)"
										clearable
										maxlength="20"
									/>&nbsp;mmHg
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="意识:">
								<span v-if="isEdit == false">{{orderForm.ys}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.ys" @input="change($event)">
										<el-radio label="清醒">清醒</el-radio>
										<el-radio label="嗜睡">嗜睡</el-radio>
										<el-radio label="昏睡">昏睡</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="面色:">
								<span v-if="isEdit == false">{{orderForm.ms}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.ms" @input="change($event)">
										<el-radio label="正常">正常</el-radio>
										<el-radio label="苍白">苍白</el-radio>
										<el-radio label="发绀">发绀</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="睡眠:">
								<span v-if="isEdit == false">{{orderForm.sm}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.sm" @input="change($event)">
										<el-radio label="4小时以下">4小时以下</el-radio>
										<el-radio label="4-6小时">4-6小时</el-radio>
										<el-radio label="6-8小时">6-8小时</el-radio>
										<el-radio label="8小时以上">8小时以上</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="食欲:">
								<span v-if="isEdit == false">{{orderForm.sy}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.sy" @input="change($event)">
										<el-radio label="正常">正常</el-radio>
										<el-radio label="增加">增加</el-radio>
										<el-radio label="不振">不振</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="大便:">
								<span v-if="isEdit == false">{{orderForm.db}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.db" @input="change($event)">
										<el-radio label="正常">正常</el-radio>
										<el-radio label="便秘">便秘</el-radio>
										<el-radio label="腹泻">腹泻</el-radio>
										<el-radio label="失禁">失禁</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-itemd">
							<el-form-item label="饮水量:">
								<span v-if="isEdit == false">{{orderForm.ysl}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.ysl" @input="change($event)">
										<el-radio label="200ml以下">200ml以下</el-radio>
										<el-radio label="200-500ml">200-500ml</el-radio>
										<el-radio label="501-1000ml">501-1000ml</el-radio>
										<el-radio label="1000ml以上">1000ml以上</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
					</el-col>
				</el-col>
				<!-- //护士 -->
				<el-col class="panel-card" style="padding-bottom:40px;" v-if="!isShow">
					<el-col class="serviceDetail">
						<el-row class="titleToolbar">
							<el-col :span="24">
								<span class="form-tag">生命体征</span>
							</el-col>
						</el-row>
						<el-col class="form-item">
							<el-form-item label="脉搏:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.mb">{{orderForm.mb}}&nbsp;次/分</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.mb"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;次/分
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="呼吸:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.hx">{{orderForm.hx}}&nbsp;次/分</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.hx"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;次/分
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="体温:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.tw">{{orderForm.tw}}&nbsp;℃</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.tw"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;·C
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="收缩压:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.ssy">{{orderForm.ssy}}&nbsp;mmHg</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.ssy"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;mmHg
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="舒张压:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.szy">{{orderForm.szy}}&nbsp;mmHg</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.szy"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;mmHg
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="血糖:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.xt">{{orderForm.xt}}&nbsp;mol/L</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.xt"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;mol/L
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="检测时间段:">
								<span v-if="isEdit == false">{{orderForm.jcsjd}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.jcsjd" @input="change($event)">
										<el-radio label="空腹">空腹</el-radio>
										<el-radio label="餐后2h">餐后2h</el-radio>
										<el-radio label="随机">随机</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
					</el-col>
				</el-col>
				<el-col class="panel-card" style="padding-bottom:40px;" v-if="!isShow">
					<el-col class="serviceDetail">
						<el-row class="titleToolbar">
							<el-col :span="24">
								<span class="form-tag">健康状态</span>
							</el-col>
						</el-row>
						<el-col class="form-item">
							<el-form-item label="意识:">
								<span v-if="isEdit == false">{{orderForm.ys}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.ys" @input="change($event)">
										<el-radio label="清醒">清醒</el-radio>
										<el-radio label="嗜睡">嗜睡</el-radio>
										<el-radio label="昏睡">昏睡</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="睡眠质量:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.smzl">{{orderForm.smzl}}&nbsp;h/天</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.smzl"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;h/天
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="水分摄入量:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.sfsrl">{{orderForm.sfsrl}}&nbsp;ml/天</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.sfsrl"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;ml/天
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="水分摄入:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.sfsr">{{orderForm.sfsr}}&nbsp;</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.sfsr"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;
								</span>
							</el-form-item>
						</el-col>

						<el-col class="form-item">
							<el-form-item label="营养摄入:">
								<span v-if="isEdit == false">{{orderForm.yysr}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.yysr" @input="change($event)">
										<el-radio label="充分">充分</el-radio>
										<el-radio label="不充分">不充分</el-radio>
										<el-radio label="极少">极少</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="进食形态:">
								<span v-if="isEdit == false">{{orderForm.jsxt}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.jsxt" @input="change($event)">
										<el-radio label="固态">固态</el-radio>
										<el-radio label="半流食">半流食</el-radio>
										<el-radio label="流食">流食</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="皮肤:">
								<span v-if="isEdit == false">{{orderForm.pf}}</span>
								<span v-if="isEdit == true">
									<el-radio-group v-model="orderForm.pf" @input="change($event)">
										<el-radio label="完整">完整</el-radio>
										<el-radio label="皮疹">皮疹</el-radio>
										<el-radio label="破损">破损</el-radio>
										<el-radio label="水肿">水肿</el-radio>
										<el-radio label="其他">其他</el-radio>
									</el-radio-group>
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="皮肤情况说明:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.pfqksm">{{orderForm.pfqksm}}&nbsp;</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.pfqksm"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="尿量:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.nl">{{orderForm.nl}}&nbsp;ml/天</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.nl"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;ml/天
								</span>
							</el-form-item>
						</el-col>
						<el-col class="form-item">
							<el-form-item label="大便:">
								<span v-if="isEdit == false">
									<span v-if="orderForm.db">{{orderForm.db}}&nbsp;</span>
								</span>
								<span v-if="isEdit == true">
									<el-input
										v-model="orderForm.db"
										@input="change($event)"
										size="mini"
										clearable
										maxlength="20"
									/>&nbsp;
								</span>
							</el-form-item>
						</el-col>
					</el-col>
				</el-col>
				<el-col class="panel-card" style="padding-bottom:40px;" v-if="!isShow">
					<el-col class="serviceDetail">
						<el-row class="titleToolbar">
							<el-col :span="24">
								<span class="form-tag">用药情况</span>
							</el-col>
						</el-row>
						<div v-for="(item,i) in this.MedicationList" :key="i">
							<el-col class="form-itemD">
								<el-form-item label="药物名称:">
									<span v-if="isEdit == false">
										<span>{{item[0]}}&nbsp;</span>
									</span>
									<span v-if="isEdit == true">
										<el-input v-model="item[0]" size="mini" clearable maxlength="20" />&nbsp;
									</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="服用频次:">
									<span v-if="isEdit == false">
										<span>{{item[1]}}&nbsp;</span>
									</span>
									<span v-if="isEdit == true">
										<el-input v-model="item[1]" size="mini" clearable maxlength="20" />&nbsp;
									</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="药物剂量:">
									<span v-if="isEdit == false">
										<span>{{item[2]}}&nbsp;</span>
									</span>
									<span v-if="isEdit == true">
										<el-input v-model="item[2]" size="mini" clearable maxlength="20" />&nbsp;
									</span>
								</el-form-item>
							</el-col>
							<el-col class="form-itemD">
								<el-form-item label="是否按时服药:">
									<span v-if="isEdit == false">{{item[3]}}</span>
									<span v-if="isEdit == true">
										<el-radio-group v-model="item[3]">
											<el-radio label="是">是</el-radio>
											<el-radio label="否">否</el-radio>
										</el-radio-group>
									</span>
								</el-form-item>
							</el-col>
						</div>
					</el-col>
				</el-col>
			</el-form>
		</el-row>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { findValueBySetCode } from "api/common";
import {
	getWorkorderDetail,
	editWorkorderDetail,
	selectGiverListForSchedule
} from "api/workOrderManagement";
export default {
	components: {
		HeadTag
	},
	props: {},
	data () {
		return {
			tagName: "工单信息",
			//上传阿里云地址
			actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
			// actionUrl: "http://dahua.natapp1.cc/" + "fsk-system/common/fileUpload",
			limitImg: 3,
			distinguishStatus: '',
			hideBriefUpload: false,
			dialogImageUrl: "",
			dialogVisible: false,
			//是否可编辑模式
			isEdit: false,
			btnShow: false,
			sideType: "10",
			isShow: true,
			//按钮加载状态
			loadingBtn: false,
			workorderCode: "",
			auditStatus: "",
			workorderStatus: "",
			planDate: [],
			orderForm: {

			},
			listData: [],
			rules: {
			},
			UpdateServicePositionCode: '',
			settleStatusOptions: [],
			workorderStatusOptions: [],
			distinguishStatusOptions: [],
			auditStatusOptions: [],
			// workOrderdetail: {},
			checkinPhotosList: [],
			careReceiverSignList: [],//回显字段信息
			MedicationList: [],
			staffPositionList: [],
			radio: "3",
			briefFileList: []
		};
	},
	watch: {},
	computed: {},
	methods: {
		//文件上传成功时的钩子
		handleBriefChange (response, file, fileList) {
			if (response) {
				let urls = [];
				fileList.forEach(item => {
					if (item.response) {
						urls.push(item.response.responseData);
					} else {
						urls.push(item.url);
					}
				});
				let checkoutPhotos = "";
				urls.forEach(items => {
					checkoutPhotos += items + ",";
				});
				//去掉最后一个逗号(如果不需要去掉，就不用写)
				if (checkoutPhotos.length > 0) {
					checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
				}
				this.orderForm.checkoutPhotos = checkoutPhotos;
			}
		},
		removeBriefList (file, inputFileMainList) {
			let fileList = this.briefFileList;
			let index = fileList.findIndex(fileItem => {
				return fileItem.uid === file.uid;
			});
			let deletArr = fileList.splice(index, 1); //删除选中的元素,this.briefFileList返回剩余的元素;
			let checkoutPhotos = "";
			this.briefFileList.map(items => {
				checkoutPhotos += items.url + ",";
			});
			//去掉最后一个逗号(如果不需要去掉，就不用写)
			if (checkoutPhotos.length > 0) {
				checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
			}
			this.orderForm.checkoutPhotos = checkoutPhotos;
		},
		//获取排版时间
		choiceDatePicker () {
			this.$nextTick(() => {
				this.orderForm.planStartDate = this.planDate[0];
				this.orderForm.planEndDate = this.planDate[1];
				this.$refs.orderForm.validate(valid => { });
			});
		},
		//服务人员
		selectStaffName (item) {
			if (item.value !== "无") {
				this.orderForm.staffTel = item.staffTel;
				this.orderForm.careGiverCode = item.code;
				this.orderForm.careGiverName = item.value;
			} else {
				this.orderForm.careGiverName = "";
			}
		},
		removeStaffCode () {
			this.orderForm.careGiverCode = "";
		},
		queryStaffName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.orderForm.orgCode
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					staffFullName: queryString,
					sideType: this.sideType,
					orgCode: this.orderForm.orgCode
				};
			}
			selectGiverListForSchedule(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.staffPositionList = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.staffPositionList.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel
							});
						}
						var results = this.staffPositionList;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		getWorkorderDetail (workorderCode, auditStatus, workorderStatus, distinguishStatus) {
			this.briefFileList = [];
			var params = {
				workorderCode: workorderCode,
				auditStatus: auditStatus,
				workorderStatus: workorderStatus,
				distinguishStatus: distinguishStatus
			};
			getWorkorderDetail(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.orderForm = response.data.responseData;
						this.planDate = [
							this.orderForm.planStartDate,
							this.orderForm.planEndDate
						];
						if (response.data.responseData.checkinDistance) {
							let checkinDistance = response.data.responseData.checkinDistance
							this.orderForm.checkinDistance = checkinDistance
							this.checkinDistance = Math.round(checkinDistance) + '米'
						}
						if (response.data.responseData.checkoutDistance) {
							let checkoutDistance = response.data.responseData.checkoutDistance
							this.orderForm.checkoutDistance = checkoutDistance
							this.checkoutDistance = Math.round(checkoutDistance) + '米'
						}
						if (response.data.responseData.checkoutPhotos) {
							let orderForm = response.data.responseData.checkoutPhotos;
							let temp = orderForm.split(",");
							this.checkinPhotosList = [...temp];
							for (let i = 0; i < temp.length; i++) {
								let url = temp[i];
								this.briefFileList.push({
									url: url,
									name: decodeURI(url)
										.toString()
										.split("com/")[1]
										.split("?Expires")[0]
										.substr(18)
								});
							}

						}
						if (
							response.data.responseData.servicePositionCode == "GW1911270089"
						) {
							//护理员
							this.isShow = true
							this.$forceUpdate()
						} else if (response.data.responseData.servicePositionCode == "GW1911270063") {
							//护士
							this.isShow = false
							this.$forceUpdate()
						}
						if (response.data.responseData.careReceiverSignList.length > 0) {
							this.careReceiverSignList = response.data.responseData.careReceiverSignList;
							var hasMedication = false;
							this.careReceiverSignList.forEach(item => {
								if (item.signCode == "MEDICATION") {
									hasMedication = true;
								}
							})
							if (!hasMedication) {
								var obj = JSON.parse(JSON.stringify(this.careReceiverSignList[0]));
								obj.signValue = "|||";
								obj.signName = "用药情况";
								this.$set(obj, "signCode", "MEDICATION")
								this.careReceiverSignList.push(obj)
							}
							// console.log("this.careReceiverSignList==" + JSON.stringify(this.careReceiverSignList))
							this.careReceiverSignList.forEach((item, key) => {
								// if (item.signName !== '用药情况') {
								// 	// item.signName=='用药情况'
								// 	this.$set(this.careReceiverSignList[key], "用药情况", key);
								// }
								// console.log(item, key)
								//回显对应护理员护士签出信息
								switch (item.signName) {
									case "收缩压":
										this.orderForm.ssy = item.signValue;
										break;
									case "舒张压":
										this.orderForm.szy = item.signValue;
										break;
									case "面色":
										this.orderForm.ms = item.signValue;
										break;
									case "睡眠":
										this.orderForm.sm = item.signValue;
										break;
									case "食欲":
										this.orderForm.sy = item.signValue;
										break;
									case "大便":
										this.orderForm.db = item.signValue;
										break;
									case "饮水量":
										this.orderForm.ysl = item.signValue;
										break;
									case "脉搏":
										this.orderForm.mb = item.signValue;
										break;
									case "呼吸":
										this.orderForm.hx = item.signValue;
										break;
									case "体温":
										this.orderForm.tw = item.signValue;
										break;
									case "血糖":
										this.orderForm.xt = item.signValue;
										break;
									case "检测时间段":
										this.orderForm.jcsjd = item.signValue;
										break;
									case "意识":
										this.orderForm.ys = item.signValue;
										break;
									case "睡眠质量":
										this.orderForm.smzl = item.signValue;
										break;
									case "水分摄入量":
										this.orderForm.sfsrl = item.signValue;
										break;
									case "水分摄入":
										this.orderForm.sfsr = item.signValue;
										break;
									case "营养摄入":
										this.orderForm.yysr = item.signValue;
										break;
									case "进食形态":
										this.orderForm.jsxt = item.signValue;
										break;
									case "皮肤":
										this.orderForm.pf = item.signValue;
										break;
									case "尿量":
										this.orderForm.nl = item.signValue;
										break;
									case "皮肤情况说明":
										this.orderForm.pfqksm = item.signValue;
										break;
									case "用药情况":
										if (item.signValue) {
											this.MedicationList.push(item.signValue.split("|"))
										}
										break;
								}
							});
						} else if (response.data.responseData.careReceiverSignList.length == 0) {
							this.careReceiverSignList =
								response.data.responseData.careReceiverSignList;
							var obj = {}
							obj.signName = "用药情况";
							obj.signValue = "";
							obj.signCode = "MEDICATION";
							// this.$set(obj, "signCode", "MEDICATION")
							this.careReceiverSignList.push(obj)
							// console.log(this.careReceiverSignList)
							this.MedicationList.push(obj.signValue.split("|"))
							// console.log(this.MedicationList)

						}

					}
				})
				.catch(error => {
					console.log("getWorkorderDetail:" + error);
					return false;
				});
		},
		getFullname () {
			/* 增加校验用药情况  全必填true 全部必填true 未填完false */
			let fill = false;
			let empt = false;
			let canSubmit = true;
			for (var i = 0; i < this.MedicationList.length; i++) {
				fill = false;
				empt = false;
				for (var j = 0; j < this.MedicationList[i].length; j++) {
					if (this.MedicationList[i][j] == '') {
						empt = true;
					}
					if (this.MedicationList[i][j] != '') {
						fill = true
					}
				}
				if (empt && fill) {
					canSubmit = false;
					break
				}
			}
			if (canSubmit == false) {
				this.$message.error('用药情况均需填写')
				return false
			}
			/* 组装取绑定值 */
			/* app过来数据    后台web端数据==0 回显数据，拼用药情况字段*/
			this.orderForm.careReceiverSignList = [
				{
					signCode: "脉搏",
					signName: "脉搏",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.mb,
					signValueUnit: "次/分"
				},
				{
					signCode: "呼吸",
					signName: "呼吸",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.hx,
					signValueUnit: "次/分"
				},
				{
					signCode: "体温",
					signName: "体温",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.tw,
					signValueUnit: "·C"
				},
				{
					signCode: "收缩压",
					signName: "收缩压",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.ssy,
					signValueUnit: "mmHg"
				},
				{
					signCode: "舒张压",
					signName: "舒张压",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.szy,
					signValueUnit: "mmHg"
				},
				{
					signCode: "血糖",
					signName: "血糖",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.xt,
					signValueUnit: "mol/L"
				},
				{
					signCode: "检测时间段",
					signName: "检测时间段",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.jcsjd,
					signValueUnit: ""
				},
				{
					signCode: "意识",
					signName: "意识",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.ys,
					signValueUnit: "ml/天"
				},
				{
					signCode: "睡眠质量",
					signName: "睡眠质量",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.smzl,
					signValueUnit: "h/天"
				},
				{
					signCode: "水分摄入量",
					signName: "水分摄入量",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.sfsrl,
					signValueUnit: ""
				},
				{
					signCode: "水分摄入",
					signName: "水分摄入",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.sfsr,
					signValueUnit: ""
				},
				{
					signCode: "营养摄入",
					signName: "营养摄入",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.yysr,
					signValueUnit: ""
				},
				{
					signCode: "进食形态",
					signName: "进食形态",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.jsxt,
					signValueUnit: ""
				},
				{
					signCode: "皮肤",
					signName: "皮肤",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.pf,
					signValueUnit: ""
				},
				{
					signCode: "皮肤情况说明",
					signName: "皮肤情况说明",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.pfqksm,
					signValueUnit: ""
				},
				{
					signCode: "尿量",
					signName: "尿量",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.nl,
					signValueUnit: "ml/天"
				},
				{
					signCode: "大便",
					signName: "大便",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.db,
					signValueUnit: ""
				},
				{
					signCode: "面色",
					signName: "面色",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.ms,
					signValueUnit: ""
				},
				{
					signCode: "睡眠",
					signName: "睡眠",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.sm,
					signValueUnit: ""
				},
				{
					signCode: "食欲",
					signName: "食欲",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.sy,
					signValueUnit: ""
				},
				{
					signCode: "饮水量",
					signName: "饮水量",
					signSourceNo: this.orderForm.workorderCode,
					signValue: this.orderForm.ysl,
					signValueUnit: ""
				},
			]
			if (this.orderForm.servicePositionCode == 'GW1911270063') {
				for (var i = 0; i < this.MedicationList.length; i++) {
					var obj = JSON.parse(JSON.stringify(this.orderForm.careReceiverSignList[0]));
					obj.signValue = "";
					obj.signName = "用药情况";
					this.$set(obj, "signCode", "MEDICATION")
					this.orderForm.careReceiverSignList.push(obj)
				}
			}
			/* 字段用药情况，单独处理，增加唯一标识 */
			for (var i = 0; i < this.orderForm.careReceiverSignList.length; i++) {
				if (this.orderForm.careReceiverSignList[i].signCode == 'MEDICATION' && !this.orderForm.careReceiverSignList[i].med) {
					this.$set(this.orderForm.careReceiverSignList[i], "med", i);
				}
			}
			/* 拼接后台格式 */
			if (this.MedicationList.length > 0) {
				this.MedicationList.forEach(v => {
					let rString = ''
					if (v.length > 0) {
						v.forEach((m, i) => {
							rString += m + '|'
						}
						)
					}
					if (rString.length > 0) {
						rString = rString.substr(0, rString.length - 1);
					}
					for (var m = 0; m < this.orderForm.careReceiverSignList.length; m++) {
						if (this.orderForm.careReceiverSignList[m].med == m) {
							if (rString == '|||') {
								rString = ''
							}
							this.orderForm.careReceiverSignList[m].signValue = rString;
							this.$set(this.orderForm.careReceiverSignList[m], "med", "");
							break;
						}
					}
				})
			}

		},
		saveWorkOrder (orderForm) {
			if (this.planDate == null) {
				this.orderForm.planStartDate = null;
				this.orderForm.planEndDate = null;
			}
			this.$refs[orderForm].validate(valid => {
				if (this.getFullname() == false) {
					return
				}
				editWorkorderDetail(this.orderForm)
					.then(response => {
						if (response.data.statusCode == "200") {
							this.$message.success("操作成功");
							this.$router.push({
								path: "/workOrderManagement/workOrderManagementList"
							});
						} else {
							this.$message.error(response.data.statusMsg);
							return false;
						}
					})
					.catch(error => {
						console.log(error);
					});
			});
		},
		handlePictureCardPreview (file) {
			this.dialogImageUrl = file.url;
			this.dialogVisible = true;
		},
		change (e) {
			this.$forceUpdate()
		},
		editOrder () {
			this.isEdit = true;
			this.btnShow = true;
		},
		/**
		 *
		 * 返回列表
		 *
		 */
		returnOrderList () {
			this.$router.push({
				path: "/workOrderManagement/workOrderManagementList"
			});
		},
		btnOrder () {
			this.$router.push({
				path: "/businessServiceManagement/updateOrderInfo",
				query: {
					orderCode: this.orderForm.orderCode
				}
			});
		},
		initDataDictionary () {
			//签入状态
			findValueBySetCode({ valueSetCode: "WORKORDER_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.workorderStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//工单状态
			findValueBySetCode({ valueSetCode: "WORKORDER_DISTINGUISH_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.distinguishStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//工单审核状态
			findValueBySetCode({ valueSetCode: "WORKORDER_AUDIT_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.auditStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//结算状态
			findValueBySetCode({ valueSetCode: "SETTLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.settleStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}
	},
	created () {
		//获得传入参数
		var param = this.$route.query;
		this.workorderCode = param.workorderCode;
		this.auditStatus = param.auditStatus;
		this.workorderStatus = param.workorderStatus;
		this.distinguishStatus = param.distinguishStatus;
		this.getWorkorderDetail(
			this.workorderCode,
			this.auditStatus,
			this.workorderStatus,
			this.distinguishStatus
		);
		this.initDataDictionary();
	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
#updateOrder {
	width: 100%;
	min-width: 1024px;
	.el-form-item {
		margin-bottom: 15px;
	}
}
.main-content {
	border-radius: 10px;
	background: #fff;
	margin: 0px 20px 20px 20px;
	padding: 20px 30px 20px 10px;
}

.panel-card {
	border: 1px solid #e0e6eb;
	border-radius: 8px;
	margin: 0px 10px 10px 10px;
}
.titleToolbar {
	padding: 10px;
	border: 0.1px solid #e0e6eb;
	border-bottom-left-radius: 0px;
	border-bottom-right-radius: 0px;
	border-top-left-radius: 8px;
	border-top-right-radius: 8px;
	background-color: #f9f9f9;
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
	.form-tag {
		font-size: 16px;
		border-left: 5px solid #f98c3c;
		padding-left: 10px;
		font-weight: 550;
	}
}
.form-content {
	font-size: 16px;
	// margin: 0px 42px;
}
.form-items {
	width: 100%;
}
.form-item {
	width: 30%;
	min-width: 400px;
	padding-bottom: 5px;
	height: 60px;
}
.form-itemd {
	width: 50%;
}
.form-itemD {
	width: 25%;
	min-width: 280px;
	// padding-bottom: 5px;
	height: 60px;
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.remark-style {
	display: block;
	width: 300px;
}
.hideBrief .el-upload--picture-card {
	display: none;
}
</style>
<style lang="scss">
#updateOrder {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
</style>