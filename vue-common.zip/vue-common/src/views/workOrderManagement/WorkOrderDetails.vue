<!--工单明细-->
<template>
  <div>
    <headTag :tagName="tagName" />
    <div class="container">
      <el-form>
        <el-row type="flex">
          <el-col style="width:120px">
            <div>
              <div class="avatar">
                <el-avatar
                  size="large"
                  src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
                  style="height:60px;width:60px;"
                ></el-avatar>
              </div>
              <div class="avatar" style="margin-top:10px;text-size:16px">{{staffInfo.staffFullName}}</div>
            </div>
          </el-col>
          <el-col style="justify-content:space-between">
            <div style="color:#333;text-size:16px;margin-top:10px">基本信息</div>
            <div style="margin-top:43px;color:#666">电话:{{staffInfo.staffTel}}</div>
          </el-col>
          <div>
            <el-button type="primary" size="mini" @click="goBack">返回</el-button>
          </div>
        </el-row>
      </el-form>
    </div>
    <div class="tableToolbar">
      <div class="tablePanel">
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
          <el-tab-pane label="上月" name="lastMonth">
            <div style="display:flex;justify-content:space-between;padding:10px">
              <div style="display:flex;justify-content:center;align-items:center">
                <span
                  style="margin-right:20px"
                  v-if="workOrderList.length>0"
                >服务人数:{{numberOfPeopleServed}}</span>
                <span v-if="workOrderList.length>0">服务人次:{{personTimesServed}}</span>
              </div>
              <div style="float:right;">
                <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  v-if="workOrderList.length>0"
                >导出明细</el-button>
              </div>
            </div>
            <div
              v-if="workOrderList.length==0"
              v-loading="listLoading"
              style="height:100px;display:flex;justify-content:center;align-items:center;color:#999"
            >{{listLoading?"":"暂无数据"}}</div>
            <el-table
              v-else
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
              size="mini"
              stripe
              :data="workOrderList"
              v-loading="listLoading"
              highlight-current-row
              element-loading-text="拼命加载中"
              show-summary
              sum-text="每日服务小计"
            >
              <el-table-column label="被照护人姓名" width="110" prop="careReceiverName" fixed="left"></el-table-column>
              <el-table-column label="产品名称" min-width="100" prop="productName" fixed="left"></el-table-column>
              <el-table-column label="评估等级" min-width="80" prop="assessGrade" fixed="left"></el-table-column>
              <el-table-column label="出勤情况">
                <el-table-column
                  v-for="index in 31"
                  :key="index"
                  :label="index+'日'"
                  :prop="index+''"
                  width="50"
                ></el-table-column>
              </el-table-column>
              <el-table-column label="合计" min-width="80" prop="workOrderCount" fixed="right"></el-table-column>
              <el-table-column label="备注" min-width="150" prop="remark" fixed="right"></el-table-column>
            </el-table>
          </el-tab-pane>
          <el-tab-pane label="当月" name="currentMonth">
            <div style="display:flex;justify-content:space-between;padding:10px">
              <div style="display:flex;justify-content:center;align-items:center">
                <span
                  style="margin-right:20px"
                  v-if="workOrderList.length>0"
                >服务人数:{{numberOfPeopleServed}}</span>
                <span v-if="workOrderList.length>0">服务人次:{{personTimesServed}}</span>
              </div>
              <div style="float:right;">
                <el-button
                  type="primary"
                  size="mini"
                  @click="exportWorkOrders"
                  v-if="workOrderList.length>0"
                >导出明细</el-button>
              </div>
            </div>
            <div
              v-if="workOrderList.length==0"
              v-loading="listLoading"
              style="height:100px;display:flex;justify-content:center;align-items:center;color:#999"
            >{{listLoading?"":"暂无数据"}}</div>
            <el-table
              v-else
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
              size="mini"
              stripe
              :data="workOrderList"
              v-loading="listLoading"
              highlight-current-row
              element-loading-text="拼命加载中"
              show-summary
              sum-text="每日服务小计"
            >
              <el-table-column label="被照护人姓名" width="110" prop="careReceiverName" fixed="left"></el-table-column>
              <el-table-column label="产品名称" min-width="100" prop="productName" fixed="left"></el-table-column>
              <el-table-column label="评估等级" min-width="80" prop="assessGrade" fixed="left"></el-table-column>
              <el-table-column label="出勤情况">
                <el-table-column
                  v-for="index in 31"
                  :key="index"
                  :label="index+'日'"
                  :prop="index+''"
                  width="50"
                ></el-table-column>
              </el-table-column>
              <el-table-column label="合计" min-width="80" prop="workOrderCount" fixed="right"></el-table-column>
              <el-table-column label="备注" min-width="150" prop="remark" fixed="right"></el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { queryWorkorderCount } from "api/workOrderManagement";
export default {
  components: {
    HeadTag
  },
  data() {
    return {
      tagName: "工单明细",
      staffInfo: {},
      type: "0", //月份类型判定(0:上月,1:当月)
      listLoading: false,
      activeName: "lastMonth",
      workOrderList: [],
      numberOfPeopleServed: "0",
      personTimesServed: "0",
      myTestInstance: {}
    };
  },
  mounted() {
    this.myTestInstance = this.$refs["myTest"];
  },
  created() {
    this.staffInfo = JSON.parse(this.$route.query.staffInfo);
    this.queryData(this.type);
  },
  methods: {
    queryData(type) {
      this.listLoading = true;
      var parms = {
        careGiverCode: this.staffInfo.staffCode,
        type: type
      };
      queryWorkorderCount(parms)
        .then(response => {
          this.listLoading = false;
          if (response.data.statusCode == "200") {
            if (response.data.responseData) {
              this.workOrderList = response.data.responseData.table;
              this.personTimesServed =
                response.data.responseData.personTimesServed || "0";
              this.numberOfPeopleServed =
                response.data.responseData.numberOfPeopleServed || "0";
                //数据处理
              this.workOrderList.forEach((item,index)=>{
                for (let i = 1; i <= 31; i++) {
                  item[i + ""]=parseInt(item[i + ""])||0;
                }
              })
              this.calculateCount();
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.listLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
    changeMonth(val) {
      this.queryData(val);
    },
    calculateCount() {
      this.workOrderList.forEach(item => {
        item.workOrderCount = 0;
        for (let field in item) {
          if (field.length <= 2) {
            item.workOrderCount += parseInt(item[field]);
          }
        }
      });
      this.$forceUpdate();
    },
    /**
     * 导出
     */
    exportWorkOrders() {
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [];
        tHeader.push("被照护人姓名");
        tHeader.push("产品名称");
        tHeader.push("评估等级");
        for (let i = 1; i <= 31; i++) {
          tHeader.push(i + "日");
        }
        tHeader.push("合计");
        tHeader.push("备注");
        // 上面设置Excel的表格第一行的标题
        const filterVal = [];
        filterVal.push("careReceiverName");
        filterVal.push("productName");
        filterVal.push("assessGrade");
        for (let i = 1; i <= 31; i++) {
          filterVal.push(i + "");
        }
        filterVal.push("workOrderCount");
        filterVal.push("remark");
        try {
          let year = new Date().getFullYear();
          let month = new Date().getMonth() + 1;
           if (this.type == "0" ) {
            if(month == 1){
              //上月
              year = year - 1;
              month = 12;
            }else{
              month=month-1;
            }
          }
          var yy = year.toString();
          var mm = month > 9 ? month : "0" + month;
          //添加合计行
          this.workOrderList.push(
            this.calColumnSum(filterVal, this.workOrderList)
          );
          const data = this.formatJson(filterVal, this.workOrderList);
          export_json_to_excel(
            tHeader,
            data,
            this.staffInfo.staffFullName + "工单明细" + yy + mm
          );
          //移除最后加的合计行
          this.workOrderList.splice(this.workOrderList.length - 1, 1);
        } catch (error) {
          this.$message.error("导出失败，请检查数据是否异常");
        }
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    calColumnSum(filterVal, jsonData) {
      //计算每列的合计总数
      var obj = {};
      filterVal.forEach(key => {
        jsonData.forEach((dataItem, index) => {
          obj[key] = jsonData
            .map(item => item[key])
            .reduce((prev, num) => {
              const value = Number(num);
              if (!isNaN(value)) {
                return prev + parseInt(num);
              } else {
                return "";
              }
            }, 0);
        });
        obj[filterVal[0]] = "每日服务小计";
      });
      return obj;
    },
    handleClick(tab, event) {
      if (tab.index == "0") {
        this.type = "0";
        this.queryData(this.type);
      } else {
        this.type = "1";
        this.queryData(this.type);
      }
    },
    goBack() {
      this.$router.push({
        path: "staffInfoList"
      });
    }
  }
};
</script>

<style lang="scss">
.form-item {
  width: 200px;
}
.container {
  background-color: #fff;
  border-radius: 10px;
  margin: 0px 20px 20px 20px;
  padding: 20px;
  .avatar {
    display: flex;
    justify-content: center;
    justify-items: center;
  }
}
.tablePanel {
  padding: 20px 0px;
}
</style>