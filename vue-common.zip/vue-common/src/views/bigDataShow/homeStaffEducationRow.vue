<!--员工学历统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>员工学历统计</p>
      <div id="second"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>
<script>
import { findEhrStaffEmployeesCardCount } from "@/api/bigData";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      seriesData: {
        visits: [],
        color: [],
        grade: []
      },
      myChart: null
    };
  },
  mounted() {
    this.queryData();
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEhrStaffEmployeesCardCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var data = response.data.responseData;
          var total = 0;
          var visits = [];
          var color = [];
          var grade = [];
          if(data.length > 0) {
            for (let i = 0; i < data.length; i++) {
              total = total + data[i].countNum;
            }
            for (let j = 0; j < data.length; j++) {
              visits.push(data[j].countNum);
              color.push((data[j].countNum/total*100).toFixed(1));
              grade.push(data[j].staffEducation);
            }
            this.seriesData = {
              visits: visits,
              color: color,
              grade: grade
            }
            this.$nextTick(()=>{
              this.initCharts();
            })
          }
        }
      });
    },
    initCharts() {
      this.myChart = this.$echarts.init(
        document.getElementById("second")
      );
      this.createChart(this.seriesData);
    },
    // 漏斗图
    createChart(seriesData) {
      if(seriesData.visits.length > 0) {
        var barcolor = [
          "#1cd389",
          "#668eff",
          "#ffc751",
          "#ff6e73",
          "#8683e6",
          "#9692ff",
          "#FFCC33"
        ];
        var totalCost = [100, 100, 100, 100, 100, 100, 100]; //背景色比例

        var data = {
          grade: seriesData.grade,
          totalCost: totalCost,
          visits: seriesData.visits,
          color: seriesData.color
        };

        var option = {
          grid: {
            top: "10%",
            left: "30%",
            right: "25%",
            bottom: "10%"
          },
          tooltip: {
            show: true
          },
          xAxis: {
            show: false
          },
          yAxis: [
            {
              type: "category",

              axisTick: {
                show: false
              },
              axisLine: {
                show: false
              },
              axisLabel: {
                margin: 10,
                textStyle: {
                  align: "right",
                  fontSize: 10,
                  color: "rgba(245,245,245,0.6)"
                }
              },
              data: data.grade
            },
            {
              type: "category",

              axisLine: {
                show: false
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                textStyle: {
                  fontSize: 12,
                  color: "rgba(245,245,245,0.8)"
                }
              },
              splitArea: {
                show: false
              },
              splitLine: {
                show: false
              },
              data: data.visits
            }
          ],
          series: [
            {
              type: "bar",
              yAxisIndex: 1,
              itemStyle: {
                normal: {
                  show: true,
                  color: "#111233",
                  barBorderRadius: 5,
                  borderWidth: 0,
                  borderColor: "#333"
                }
              },
              barWidth: "35%",
              silent: true,
              data: data.totalCost
            },
            {
              type: "bar",

              itemStyle: {
                normal: {
                  show: true,
                  // color:barcolor,
                  color: function(params) {
                    var num = barcolor.length;
                    return barcolor[params.dataIndex % num];
                  },
                  barBorderRadius: 5,
                  borderWidth: 0,
                  borderColor: "#333"
                }
              },
              label: {
                normal: {
                  show: false
                }
              },
              barWidth: "35%",
              data: data.color
            }
          ]
        };
        this.myChart.setOption(option);
      }
    }  
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #second {
      width: 235px;
      height: 200px;
    }
  }
}
</style>