<!--月服务统计-->
<template>
  <div style="background-color:#070727">
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png">
      </div>
      <el-row type="flex" style="width:100%;">
        <el-col>
          <span style="text-size:16px;height:16px;opacity:0.8;">月服务统计(人次)</span>
        </el-col>
        <el-col>
          <div style="float:right;display:flex;">
            <div
              @click="monthClick"
              :style="{backgroundColor:month?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >月</div>
            <div
              @click="seasonClick"
              :style="{backgroundColor:season?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >季</div>
            <div
              @click="yearClick"
              :style="{backgroundColor:year?'#1A1AD1':'#0A0A77',padding:'5px'}"
            >年</div>
          </div>
        </el-col>
      </el-row>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png">
      </div>
    </div>
    <div id="monthService" style="width:600px;height: 270px;"></div>
    <el-col>
      <span
        style="display: block;text-size:16px;height:16px;opacity:0.8;margin-left:30px;"
      >月服务时长统计(H)</span>
    </el-col>
    <div id="monthServiceTime" style="width:600px;height: 270px;margin-top:20px;"></div>
  </div>
</template>
<script>
import { findEtProductOrderServiceTotal } from "@/api/bigData";
import { stubTrue } from "lodash-es";
export default {
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      month: true,
      season: false,
      year: false,
      myChart: null,
      myChartTime: null,
      data: {},
      allData: {},
      seriesData: {}
    };
  },
  watch: {
    seriesData: {
      handler(newVal, oldVal) {
        this.createMonthTimeChart(newVal);
      }
    }
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEtProductOrderServiceTotal(params).then(response => {
        if (response.data.statusCode == 200) {
          this.allData = response.data.responseData;
          this.initCharts();
        }
      });
    },
    monthClick() {
      this.month = true;
      this.season = false;
      this.year = false;
      var month = [];
      var value = [];
      var xData = [];
      var zData = [];
      this.allData.sixMonthCountList.forEach(item => {
        month.push(item.month);
        value.push(item.servicePeopleNum);
        xData.push(item.month);
        zData.push(item.serviceTimeNum);
      });
      this.data = {
        month: month,
        value: value
      };
      this.seriesData = {
        xData: xData,
        zData: zData
      };
      this.createMonthChart(this.data);
    },
    seasonClick() {
      this.month = false;
      this.season = true;
      this.year = false;
      var month = [];
      var value = [];
      var xData = [];
      var zData = [];
      this.allData.sixQuarterCountList.forEach(item => {
        month.push(item.year + "-" + item.quarter);
        value.push(item.servicePeopleNum);
        xData.push(item.year + "-" + item.quarter);
        zData.push(item.serviceTimeNum);
      });
      this.data = {
        month: month,
        value: value
      };
      this.seriesData = {
        xData: xData,
        zData: zData
      };
      this.createMonthChart(this.data);
    },
    yearClick() {
      this.month = false;
      this.season = false;
      this.year = true;
      var month = [];
      var value = [];
      var xData = [];
      var zData = [];
      this.allData.threeYearCountList.forEach(item => {
        month.push(item.year);
        value.push(item.servicePeopleNum);
        xData.push(item.year);
        zData.push(item.serviceTimeNum);
      });
      this.data = {
        month: month,
        value: value
      };
      this.seriesData = {
        xData: xData,
        zData: zData
      };
      this.createMonthChart(this.data);
    },
    initCharts() {
      this.myChart = this.$echarts.init(
        document.getElementById("monthService")
      );
      this.myChartTime = this.$echarts.init(
        document.getElementById("monthServiceTime")
      );
      var month = [];
      var value = [];
      var xData = [];
      var zData = [];
      this.allData.sixMonthCountList.forEach(item => {
        month.push(item.month);
        value.push(item.servicePeopleNum);
        xData.push(item.month);
        zData.push(item.serviceTimeNum);
      });
      this.data = {
        month: month,
        value: value
      };
      this.seriesData = {
        xData: xData,
        zData: zData
      };
      this.createMonthChart(this.data);
    },
    createMonthChart(data) {
      var option = {
        backgroundColor: "rgba(7, 7, 39, 1)",
        xAxis: {
          data: data.month,
          axisLine: {
            lineStyle: {
              color: "rgba(255,255,255,0.1)"
            }
          },
          axisLabel: {
            color: "#666666",
            fontSize: 10
          }
        },
        grid: {
          top: "10%",
          left: "10%",
          right: "1%",
          bottom: "15%"
        },
        yAxis: {
          axisLine: {
            lineStyle: {
              color: "rgba(255,255,255,0.1)"
            }
          },
          axisLabel: {
            color: "#666666",
            fontSize: 10
          },
          splitLine: {
            show: false
          }
        },
        series: [
          {
            type: "bar",
            barWidth: 30,
            itemStyle: {
              normal: {
                color: new this.$echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "#FF7A21"
                    },
                    {
                      offset: 1,
                      color: "#F1DE75"
                    }
                  ],
                  false
                )
              }
            },
            label: {
              normal: {
                show: true,
                fontSize: 12,
                fontWeight: "bold",
                color: "#ffffff",
                position: "top"
              }
            },
            data: data.value
          }
        ]
      };
      this.myChart.setOption(option);
    },
    createMonthTimeChart(series) {
      this.myChartTime.setOption({
        backgroundColor: "rgba(7, 7, 39, 1)",
        tooltip: {
          trigger: "axis",
          axisPointer: {
            lineStyle: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(255,255,255,0)" // 0% 处的颜色
                  },
                  {
                    offset: 0.5,
                    color: "rgba(255,255,255,1)" // 100% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(255,255,255,0)" // 100% 处的颜色
                  }
                ],
                global: false // 缺省为 false
              }
            }
          }
        },
        grid: {
          top: "10%",
          left: "10%",
          right: "1%",
          bottom: "15%"
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: stubTrue,
            axisLine: {
              //坐标轴轴线相关设置。数学上的x轴
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,0.1)"
              }
            },
            axisLabel: {
              //坐标轴刻度标签的相关设置
              textStyle: {
                color: "#666666",
                fontSize: 10
              }
            },
            data: series.xData
          }
        ],
        yAxis: [
          {
            type: "value",
            splitLine: {
              show: false
            },
            axisLine: {
              lineStyle: {
                color: "rgba(255,255,255,0.1)"
              }
            },
            axisLabel: {
              //坐标轴刻度标签的相关设置
              textStyle: {
                color: "#666666",
                fontSize: 10
              }
            }
          }
        ],
        series: [
          {
            name: "月服务时长(H)",
            type: "line",
            smooth: true,
            showAllSymbol: true,
            symbolSize: 8,
            lineStyle: {
              normal: {
                color: "#53fdfe" // 线条颜色
              },
              borderColor: "#f0f"
            },
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#fff"
              }
            },
            itemStyle: {
              normal: {
                color: "rgba(255,255,255,1)"
              }
            },
            tooltip: {
              show: true
            },
            areaStyle: {
              //区域填充样式
              normal: {
                //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
                color: new this.$echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "rgba(0,150,239,0.3)"
                    },
                    {
                      offset: 1,
                      color: "rgba(0,253,252,0)"
                    }
                  ],
                  false
                ),
                shadowColor: "rgba(53,142,215, 0.9)", //阴影颜色
                shadowBlur: 20 //shadowBlur设图形阴影的模糊大小。配合shadowColor,shadowOffsetX/Y, 设置图形的阴影效果。
              }
            },
            data: series.zData
          }
        ]
      });
    }
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>