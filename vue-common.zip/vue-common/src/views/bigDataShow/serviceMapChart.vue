<template>
	<!-- 实时服务热力图 -->
	<div style="background-color:#070727">
		<div ref="myEchart" style="width:600px; height:380px;" id="box"></div>
	</div>
</template>

<script>
import echarts from "echarts";
import "echarts/map/js/china";
export default {
	components: {},
	props: {},
	data () {
		return {};
	},
	watch: {},
	computed: {},
	methods: {},
	created () { },
	mounted () {
		var geoCoordMap = {
			"运营中心": [121.48248000, 31.30163400],
			"嘉兴福寿康医养健康管理有限公司": [120.76082600, 30.76893200],
			"广州福寿康医疗养老有限公司	": [113.27328000, 23.13726000],
			"苏州福寿康康贤居家护理有限公司": [120.62063600, 31.34851000],
			"常州福寿康健康养老管理服务有限公司": [119.96759000, 31.78165400],
			"厦门福寿康医疗养老服务有限公司": [118.08607500, 24.48396300],
			"温州福寿康医养服务有限公司": [120.69255000, 27.99689900],
			"浙江福寿康医养服务有限公司": [120.15921000, 30.27713600],
			"承德福寿康医养服务有限公司": [117.94249000, 40.98530000],
			"苏州福寿康养老服务有限公司": [120.62047600, 31.34889400],
			"南京福寿康健康养老管理服务有限公司": [118.77971000, 32.10587000],
			"重庆福寿康健康管理有限公司": [106.40228000, 29.81115700],
			"绍兴福寿康健康养老服务有限公司": [120.60585000, 30.01083000],
			"无锡福寿康养老服务有限公司": [120.30897500, 31.58646600],
			"成都福寿康健康管理有限公司": [104.10413000, 30.63193900]
		};
		var convertData = function (data) {
			var res = [];
			for (var i = 0; i < data.length; i++) {
				var geoCoord = geoCoordMap[data[i].name];
				if (geoCoord) {
					res.push(geoCoord.concat(data[i].value));
				}
			}
			return res;
		};
		// 基于准备好的dom，初始化echarts实例
		var myServiceChart = echarts.init(document.getElementById("box"));
		var option = {
			title: {
				text: "实时服务热力图",
				textStyle: {
					//文字颜色
					color: '#FFFFFF',
					//字体系列
					fontFamily: 'PingFang-SC-Medium',
					//字体大小
					fontSize: 16
				},
			

			},
			backgroundColor: "#070727",
			visualMap: {
				show: false,
				min: 0,
				max: 5000,
				splitNumber: 0,
				inRange: {
					color: ["#d94e5d", "#eac736", "#50a3ba"].reverse()
				},
				textStyle: {
					color: "#fff"
				}
			},
			geo: {
				map: "china",
				zoom: 1.2,
				label: {
					emphasis: {
						show: false
					}
				},
				roam: false,
				itemStyle: {
					normal: {
						areaColor: "#070727",
						borderColor: "#10BEFE"
					},
					emphasis: {
						areaColor: "#2a333d"
					}
				}
			},
			series: [
				{
					name: "AQI",
					type: "heatmap",
					coordinateSystem: "geo",
					data: convertData([
						{ name: "运营中心", value: 4629 },
						{ name: "嘉兴福寿康医养健康管理有限公司", value: 35 },
						{ name: "广州福寿康医疗养老有限公司", value: 0 },
						{ name: "苏州福寿康康贤居家护理有限公司", value: 0 },
						{ name: "常州福寿康健康养老管理服务有限公司", value: 0 },
						{ name: "厦门福寿康医疗养老服务有限公司", value: 0 },
						{ name: "温州福寿康医养服务有限公司", value: 0 },
						{ name: "浙江福寿康医养服务有限公司", value: 0 },
						{ name: "承德福寿康医养服务有限公司", value: 0 },
						{ name: "苏州福寿康养老服务有限公司", value: 0 },
						{ name: "南京福寿康健康养老管理服务有限公司", value: 0 },
						{ name: "重庆福寿康健康管理有限公司", value: 0 },
						{ name: "绍兴福寿康健康养老服务有限公司", value: 0 },
						{ name: "无锡福寿康养老服务有限公司", value: 0 },
						{ name: "成都福寿康健康管理有限公司", value: 0 }
					])
				}
			]
		};
		myServiceChart.setOption(option);
	}
};
</script>
<style lang="scss" scoped>

</style>