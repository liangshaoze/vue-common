<!--今日服务量-->
<template>
  <div>
    <div>
      <p style="text-align:center;font-size:14px;margin-top:15px;">今日服务量(人次)</p>
      <p
        style="text-align:center;font-size:50px;margin-top:15px;color:#16CEB2;font-weight:bold;"
      >{{(serviceCount).toLocaleString('en-US')}}</p>
      <div id="mountNode"></div>
    </div>
  </div>
</template>
<script>
import { findWoWorkOrderTodayServiceCount } from "@/api/bigData";
export default {
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      basicColumnChartProp: {
        data: [],
        container: "mountNode",
        size: { width: 600, height: 200 }
      },
      serviceCount: 0
    };
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findWoWorkOrderTodayServiceCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var obj = response.data.responseData;
          if (obj) {
            var count = obj.countNum;
            if (count > 0) {
              this.serviceCount = count;
              this.basicColumnChartProp.data = [
                {
                  type: "服务中",
                  value: parseFloat(
                    ((obj.inServiceCount / count) * 100).toFixed(2)
                  )
                },
                {
                  type: "已完成",
                  value: parseFloat(
                    ((obj.serviceDoneCount / count) * 100).toFixed(2)
                  )
                },
                {
                  type: "未完成",
                  value: parseFloat(
                    ((obj.noServiceCount / count) * 100).toFixed(2)
                  )
                },
                {
                  type: "取消",
                  value: parseFloat(((obj.delCount / count) * 100).toFixed(2))
                }
              ];
              this.basicBarChart();
            }
          }
        }
      });
    },
    basicBarChart: function() {
      let data = this.basicColumnChartProp.data;
      if (data.length > 0) {
        let chart = new G2.Chart({
          container: this.basicColumnChartProp.container,
          width: this.basicColumnChartProp.size.width,
          height: this.basicColumnChartProp.size.height,
          padding: [0, 48, 50, 30]
        });
        chart.source(data);
        chart.legend(false);
        chart.facet("rect", {
          fields: ["type"],
          padding: 20,
          showTitle: false,
          eachView: function eachView(view, facet) {
            var data = facet.data;
            var color = void 0;
            if (data[0].type === "服务中") {
              color = "#FF7A21";
            } else if (data[0].type === "已完成") {
              color = "#0BB54B";
            } else if (data[0].type === "未完成") {
              color = "#747272";
            } else {
              color = "#FF2121";
            }
            data.push({
              type: "其他",
              value: 100 - data[0].value
            });
            view.source(data);
            view.coord("theta", {
              radius: 1,
              innerRadius: 0.8
            });
            view
              .intervalStack()
              .position("value")
              .color("type", [
                color,
                "#181C53",
                "#0BB54B",
                "#D7D4D2",
                "#FF2121"
              ])
              .opacity(1);
            view.guide().html({
              position: ["50%", "50%"],
              html:
                '<div class="g2-guide-html"><p class="value">' +
                (data[0].value + "%") +
                '</p><p class="title">' +
                data[0].type +
                "</p></div>"
            });
          }
        });
        chart.render();
      }
    }
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>
<style lang="scss">
.g2-guide-html {
  height: 30px;
  vertical-align: middle;
  text-align: center;
  .title {
    margin-top: 45px;
    font-size: 14px;
    opacity: 0.6;
  }
  .value {
    font-size: 16px;
    line-height: 30px;
  }
}
</style>