<!--今日服务时间段统计-->
<template>
  <div style="background-color:#070727">
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png">
      </div>
      <div style="width:100%;margin-top:10px;text-size:16px;opacity:0.8;height:16px">今日服务时间段统计</div>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png">
      </div>
    </div>
    <div id="todayServiceTime" style="width:600px;height: 260px;"></div>
  </div>
</template>
<script>
import { findEtProductOrderTodayTimeTjCount } from "@/api/bigData";
export default {
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      myChart: null,
      dataList: []
    };
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEtProductOrderTodayTimeTjCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var data = response.data.responseData;
          if(data) {
            this.dataList = data;
            this.createChart(this.dataList);
          }
        }
      });
    },
    createChart(dataList) {
      this.myChart = this.$echarts.init(
        document.getElementById("todayServiceTime")
      );
      if(dataList.length > 0) {
        var time = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
        this.myChart.setOption({
          backgroundColor: "rgba(7, 7, 39, 1)",
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "line",
              lineStyle: {
                color: "#FF7A21",
                width: 1,
                type: "solid"
              }
            }
          },
          grid: {
            top: "10%",
            left: "10%",
            right: "1%",
            bottom: "15%"
          },
          xAxis: [
            {
              type: "category",
              boundaryGap: false,
              data: time,
              axisLabel: {
                show: true,
                textStyle: {
                  color: "#666666",
                  fontSize: 10
                }
              }
            }
          ],
          yAxis: [
            {
              type: "value",
              axisLabel: {
                formatter: "{value}",
                textStyle: {
                  color: "#A5A5A5",
                  fontSize: 10
                }
              },
              splitLine: {
                show: false
              }
            }
          ],
          series: [
            {
              color: ["#FF7A21"],
              name: "服务人次",
              type: "line",
              smooth: true,
              showAllSymbol: true,
              symbolSize: 4,
              areaStyle: {
                normal: {
                  color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    {
                      offset: 0,
                      color: "rgba(255,122,33,0.8)"
                    },
                    {
                      offset: 0.4,
                      color: "rgba(255,122,33,0.4)"
                    },
                    {
                      offset: 1,
                      color: "rgba(255,122,33,0.1)"
                    }
                  ])
                }
              },
              data: dataList
            }
          ]
        });
      }
    }
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>