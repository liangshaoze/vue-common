<!--员工年龄统计-->
<template>
  <div style="background-color:#070727">
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png" />
      </div>
      <div style="width:100%;margin-top:10px;text-size:16px;height:16px;opacity: 0.8;">员工年龄统计</div>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png" />
      </div>
    </div>
    <div id="staffAge"></div>
  </div>
</template>
<script>
import {findEhrStaffEmployeesAgeCount} from "@/api/bigData"
export default {
  data() {
    return {
      data:[],
      ageData:{}
    };
  },
   props:{
        isHomepage: {
            type: Boolean,
            default: false
        },
	orgCode: {
      type: String,
      default: ""
    }
    },
  methods: {
    queryData(){
    var params = {
        orgCode: this.orgCode
      }
       findEhrStaffEmployeesAgeCount(params).then(response=>{
			  if(response.data.statusCode == 200){
				  this.createChart(response.data.responseData);
			  }
		  });
    },
    createChart(dataList) {
      if(dataList){
        dataList.forEach(item => {
          this.ageData=item;
        });
        this.data=[
              {
            country: "60岁以上",
            type: "男",
            value: this.ageData.man60
          },
          {
            country: "60岁以上",
            type: "女",
            value: this.ageData.woman60
          },
            {
            country: "55-60岁",
            type: "男",
            value: this.ageData.man5560
          },
          {
            country: "55-60岁",
            type: "女",
            value: this.ageData.woman5560
          },
          {
            country: "50-55岁",
            type: "男",
            value: this.ageData.man5055
          },
          {
            country: "50-55岁",
            type: "女",
            value: this.ageData.woman5055
          },
          {
            country: "45-50岁",
            type: "男",
            value: this.ageData.man4550
          },
          {
            country: "45-50岁",
            type: "女",
            value: this.ageData.woman4550
          },
          {
            country: "40-45岁",
            type: "男",
            value: this.ageData.man4045
          },
          {
            country: "40-45岁",
            type: "女",
            value: this.ageData.woman4045
          },
          {
            country: "35-40岁",
            type: "男",
            value: this.ageData.man3540
          },
          {
            country: "35-40岁",
            type: "女",
            value: this.ageData.woman3540
          },
          {
            country: "30-35岁",
            type: "男",
            value: this.ageData.man3035
          },
          {
            country: "30-35岁",
            type: "女",
            value: this.ageData.woman3035
          },
          {
            country: "25-30岁",
            type: "男",
            value: this.ageData.man2530
          },
          {
            country: "25-30岁",
            type: "女",
            value: this.ageData.woman2530
          },
          {
            country: "25岁以下",
            type: "男",
            value: this.ageData.man25
          },
          {
            country: "25岁以下",
            type: "女",
            value: this.ageData.woman25
          }
        ]
        
        var chart = new G2.Chart({
          container: "staffAge",
          forceFit: true,
          height: this.isHomepage==true?200:270,
          padding: "auto"
        });
        chart.source(this.data, {
          value: {
            nice: false,
            alias: "员工数（位）"
          }
        });

        chart.axis("value", false);
        chart.legend({
          position: "top-center"
        });
        chart.coord().transpose();
        chart.facet("mirror", {
          fields: ["type"],
          autoSetAxis: false,
          transpose: true,
          showTitle: false,
          padding: [0, 10, 0, 0],
          eachView: function eachView(view, facet) {
            var facetIndex = facet.colIndex;
            if (facetIndex === 0) {
              view.axis("country", {
                position: "top",
                label: {
                  textStyle: {
                    fill: "#C3D9D7FF",
                    opacity: 0.6,
                    fontSize: 11
                  }
                },
                tickLine: {
                  alignWithLabel: false,
                  length: 0
                },
                line: {
                  lineWidth: 0
                }
              });
            } else {
              view.axis("country", false);
            }
            var color = facetIndex === 0 ? "#8D3AF4" : "#16CEB2";
            view
              .interval()
              .position("country*value")
              .color(color)
              .size(17)
              .opacity(1)
              .label("value", function(val) {
                var offset = -4;
                var shadowBlur = 2;
                var textAlign = facetIndex === 1 ? "end" : "start";
                var fill = "black";
                if (val < 57) {
                  offset = 4;
                  textAlign = facetIndex === 1 ? "start" : "end";
                  fill = "white";
                  shadowBlur = 0;
                }
                return {
                  //position: 'middle',
                  offset: offset,
                  textStyle: {
                    fill: fill,
                    shadowBlur: shadowBlur,
                    shadowColor: "rgba(0, 0, 0, .45)",
                    textAlign: textAlign
                  }
                };
              });
          }
        });

        chart.render();
      }
    }
  },
  mounted() {
    this.queryData();
  }
};
</script>
<style>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>