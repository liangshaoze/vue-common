<template>
  <!-- 员工岗位统计 -->
  <div class="box">
    <div class="screen-img">
      <img :src="imgLeft" />
    </div>
    <div class="content">
      <p>员工岗位统计</p>
      <div id="mountStaffNode"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight" />
    </div>
  </div>
</template>

<script>
import {findEhrStaffPositionTotal} from "@/api/bigData"
export default {
  components: {},
  props: {},
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      basicColumnChartProp: {
        data: [],
        container: "mountStaffNode",
        size: { width: 235, height: 200 }
      }
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData(){
      var params = {
        orgCode: this.orgCode
      }
       findEhrStaffPositionTotal(params).then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          this.basicColumnChartProp.data=[];
          dataList.forEach(item => {
            this.basicColumnChartProp.data.push({
              type: item.positionName,
              value: item.countNum
            })
          });
          this.basicBarChart();
        }
      });
    },
    basicBarChart: function() {
      let data = this.basicColumnChartProp.data;
      if(data.length > 0) {
        let chart = new G2.Chart({
          container: this.basicColumnChartProp.container,
          padding: [20, 0, "auto", 35],
          // forceFit: true,
          width: this.basicColumnChartProp.size.width,
          height: this.basicColumnChartProp.size.height
        });
        chart.source(data);
        chart.scale("value", {
          nice: true,
          min: 0
        });
        chart.legend("type", {
          position: "bottom-center",
          textStyle: {
            fill: "#fff",
            opacity: 0.6,
            fontSize: 11
          }
        });
        chart.tooltip({
          // showMarkers: false,
          showTitle: false,
          itemTpl:
            '<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
        });
        chart.axis("value", {
          label: {
            formatter(value) {
              return value;
            }, //
            textStyle: {
              fill: "#C3D9D7FF",
              opacity: 0.6,
              fontSize: 11
            }
          },
          grid: {
            align: "center",
            type: "line",
            lineStyle: {
              stroke: "#000", // 网格线的颜色
              lineWidth: 0.1, // 网格线的粗细
              lineDash: [1, 2] // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
            },
            hideFirstLine: true, // 是否隐藏第一条网格线，默认为 false
            hideLastLine: true
          }
        });
        chart.axis("type", {
          label: {
            textStyle: {
              fill: "#C3D9D7FF",
              opacity: 0.6,
              fontSize: 11
            }
          }
        });
        chart
          .interval()
          .position("type*value")
          .color("type", ["#FF7A21", "#FC2695", "#0BB54B", "#268AFC"])
          .opacity(1);
        chart.render();
      }
    }
  },
  mounted() {
    this.queryData();
  }
};
</script>
<style lang="scss" scoped>
.box {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #mountNode {
      width: 235px;
      height: 200px;
    }
  }
}
</style>