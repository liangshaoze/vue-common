<template>
  <div id="realTimeInfo">
    <div id="nwwestroll"></div>
    <!--滚屏-->
    <div class="staffType">
      <div class="screen-img">
        <img :src="imgLeft">
      </div>
      <div>
        <el-table
          :data="list"
          :header-cell-style="{background:'rgba(7,7,39,1)',color:'#FFFFFF'}"
          row-class-name="rowStyle"
          class="tableStyle"
        >
          <el-table-column prop="content" :label="columnName"></el-table-column>
          <!-- <span v-for="(item,index) in columnList">
            <el-table-column :prop="item[index].prop" :label="item[index].label"></el-table-column>
          </span>-->
        </el-table>
        <ul class="rankFont">
          <li
            v-for="(item, i) in list"
            ref="rollul"
            :key="i"
            class="rankFont"
            style="list-style: none"
          ></li>
        </ul>
      </div>
      <div class="screen-img">
        <img :src="imgRight">
      </div>
    </div>
  </div>
</template>

<script>
import echarts from "echarts";
export default {
  name: "realTimeInfo",
  props: {
    dataList: {
      type: Array,
      default: []
    },
    columnName: {
      type: String,
      default: "客户实时信息"
    },
    panelHeight: {
      type: String,
      default: "300px"
    }
  },
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      flag: false,
      list: [],
      animate: false,
      timer: null,
      timer1: null
    };
  },
  methods: {
    //滚屏获取数据
    findCurrentWorkorderRoll() {
      this.list = this.dataList;
      this.flag = true;
    },
    //滚屏展示
    showMarquee() {
      if (this.flag) {
        this.nwwestroll = echarts.init(document.getElementById("nwwestroll"));
        this.animate = !this.animate;
        var that = this; // 在异步函数中会出现this的偏移问题，此处一定要先保存好this的指向
        setTimeout(function() {
          that.list.push(that.list[0]);
          that.list.shift();
          that.animate = !that.animate; // 这个地方如果不把animate 取反会出现消息回滚的现象，此时把ul 元素的过渡属性取消掉就可以完美实现无缝滚动的效果了
        }, 0);
      }
    }
  },
  created() {},
  mounted() {
    this.findCurrentWorkorderRoll();
    this.timer = setInterval(this.findCurrentWorkorderRoll, 45000);
    this.timer1 = setInterval(this.showMarquee, 2000);
  },
  beforeDestroy() {
    if (this.timer) {
      //如果定时器还在运行 或者直接关闭，不用判断
      clearInterval(this.timer); //关闭
    }
    if (this.timer1) {
      //如果定时器还在运行 或者直接关闭，不用判断
      clearInterval(this.timer1); //关闭
    }
  }
};
</script>

<style scoped lang="scss">
.divPanel {
  width: 600px;
  height: 300px;
}
.rankFont {
  color: #ccc;
}
.tableStyle {
  width: 540px;
  height: 300px;
}
.staffType {
  display: flex;
  justify-content: space-between;
  height: 300px;
}
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
  img {
    width: 30px;
    height: 30px;
  }
}
</style>
<style lang="scss">
#realTimeInfo {
  .el-table {
    .rowStyle {
      background: rgba(7, 7, 39, 1);
    }
  }
  .el-table th.is-leaf,
  .el-table td {
    border-bottom: 10px;
  }
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background-color: transparent;
  }
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: rgba(18, 18, 100, 0.6);
    color: white;
  }
}
</style>