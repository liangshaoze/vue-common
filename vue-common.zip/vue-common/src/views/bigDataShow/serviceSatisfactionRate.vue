<!--今日已服务满意率-->
<template>
  <div style="background-color:#070727">
   <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png" />
      </div>
      <div style="width:100%;margin-top:10px;text-size:16px;opacity:0.8;height:16px">客户满意率</div>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png" />
      </div>
    </div>
    <el-row type="flex" style="height:260px">
      <el-col>
      <div id="fifth" style="width:300px;height:260px"></div>
      </el-col>
      <el-col >
        <div style="display:flex;justify-content:center;height:100%;align-items:center">
          <div>
          <el-row type="flex">
            <el-col>
              <div style="font-size:40px;color:#16CEB2;font-weight:bold;">{{value1}}</div>
              <div style="font-size:14px;color:#fff;opacity: 0.6;">收到评价</div>
            </el-col>
            <el-col style="margin-left:30px">
              <div style="font-size:40px;color:#16CEB2;font-weight:bold;">{{value2}}</div>
              <div style="font-size:14px;color:#fff;opacity: 0.6;">待评价</div>
            </el-col>
          </el-row>
          <el-row type="flex" style="margin-top:30px">
            <el-col>
              <div style="font-size:30px;color:#16CEB2;">98.6%</div>
              <div style="font-size:14px;color:#fff;opacity: 0.6;">客户满意率</div>
            </el-col>
          </el-row>
          </div>
          </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      emptyData: true,
      myChart: null,
      ratio: 98.6,
      value1: (14874).toLocaleString('en-US'),
      value2: (27211).toLocaleString('en-US'),
    };
  },
  mounted() {
    this.initCharts();
  },
  methods: {
    initCharts() {
      this.myChart = this.$echarts.init(document.getElementById("fifth"));
      this.createChart(this.ratio);
    },
    createChart(ratio) {
      var axisTickLength = 15; //刻度线宽度
      var colorRegionRate = (ratio / 100).toFixed(2);

      var index = ratio >= 80 ? 0 : ratio > 50 ? 1 : 2;
      var startColor = ["#CCFFCC", "#FFCC99", "#FFCCCC"][index];
      var endColor = ["#00CC66", "#FF8C1A", "#FF471A"][index];

      this.myChart.setOption({
        backgroundColor: "#070727",
        series: [
          {
            type: "gauge",
            name: "外层半透明边框圈",
            radius: "80%",
            startAngle: "225",
            endAngle: "-45",
            splitNumber: "100",
            pointer: {
              show: false
            },
            detail: {
              show: false
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  // 有数值的部分
                  [
                    colorRegionRate,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: startColor // 0% 处的颜色
                      },
                      {
                        offset: 0.5,
                        color: endColor // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: endColor // 100% 处的颜色
                      }
                    ])
                  ],
                  // 底色
                  [
                    1,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: "rgba(255,255,255,0.1)" // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: "rgba(255,255,255,0.1)" // 100% 处的颜色
                      }
                    ])
                  ]
                ],
                width: 3,
                opacity: 1
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: false
            },
            axisLabel: {
              show: false
            }
          },
          {
            type: "gauge",
            name: "第二层",
            radius: "76%",
            startAngle: "225",
            endAngle: "-45",
            splitNumber: 4,
            pointer: {
              show: true,
              length: "53%"
            },
            // 仪表盘指针样式。
            itemStyle: {
              color: "#f6fefe"
            },
            data: [
              {
                value: ratio,
                name: "客户满意率"
              }
            ],
            title: {
              show: false
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  // 有数值的部分
                  [
                    colorRegionRate,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: startColor // 0% 处的颜色
                      },
                      {
                        offset: 0.5,
                        color: endColor // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: endColor // 100% 处的颜色
                      }
                    ])
                  ],
                  // 底色
                  [
                    1,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: "rgba(255,255,255,0.1)" // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: "rgba(255,255,255,0.1)" // 100% 处的颜色
                      }
                    ])
                  ]
                ],
                width: 15,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                opacity: 1
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: false
            },
            detail: {
              show: false
            },
            axisLabel: {
              show: false
            },
            animationDuration: 2000
          },
          {
            name: "第三层渐变圈",
            type: "gauge",
            radius: "60%",
            startAngle: "225",
            endAngle: "-45",
            splitNumber: 4,
            pointer: {
              show: false
            },
            data: [
              {
                value: ratio,
                name: "客户满意率"
              }
            ],

            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  // 有数值的部分
                  [
                    colorRegionRate,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: startColor // 0% 处的颜色
                      },
                      {
                        offset: 0.5,
                        color: endColor // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: endColor // 100% 处的颜色
                      }
                    ])
                  ],
                  // 底色
                  [
                    1,
                    new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: "rgba(255,255,255,0.1)" // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: "rgba(255,255,255,0.1)" // 100% 处的颜色
                      }
                    ])
                  ]
                ],
                width: axisTickLength, // 刻度线宽度
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                opacity: 1
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: false
            },
            // 仪表盘指针样式。
            itemStyle: {
              color: "#f6fefe"
            },
            title: {
              show: false
            },
            detail: {
              show: false
            },
            axisLabel: {
              show: false
            },
            animationDuration: 2000
          },
          {
            name: "与div背景色相同模拟axisTick",
            type: "gauge",
            radius: "60%",
            startAngle: "225",
            endAngle: "-45",
            splitNumber: 1,
            pointer: {
              show: false
            },
            title: {
              show: false
            },
            detail: {
              show: true,
              offsetCenter: [0, "80%"],
              formatter: ratio => {
                return [
                  `{a|}{b|}`,
                  `{c|客户满意率：${
                    ratio >= 80 ? "优秀" : ratio > 50 ? "良好" : "一般"
                  }}`
                ].join("\n");
              },
              rich: {
                a: {
                  color: "#DFE3F5",
                  fontWeight: 600,
                  fontSize: 15
                },
                b: {
                  color: "#DFE3F5",
                  fontWeight: 600,
                  fontSize: 15
                },
                c: {
                  color: "#DFE3F5",
                  fontSize: 12
                }
              }
            },
            data: [
              {
                value: ratio,
                name: "客户满意率"
              }
            ],
            axisLine: {
              show: false,
              lineStyle: {
                width: 1,
                opacity: 0
              }
            },
            axisTick: {
              show: true,
              splitNumber: 60,
              length: axisTickLength, // 刻度线宽度
              lineStyle: {
                // 与div背景色相同
                color: "#353c60",
                width: 1
              }
            },
            splitLine: {
              show: false
            },
            axisLabel: {
              show: false
            }
          }
        ]
      });
    }
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>