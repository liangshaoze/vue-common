<template>
  <!-- 员工性别统计 -->
  <div class="box">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>员工性别统计</p>
      <div id="mountNode"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>

<script>
import { findEhrStaffEmployeesGenderCount } from "@/api/bigData";
export default {
  components: {},
  props: {},
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      basicColumnChartProp: {
        data: [],
        container: "mountNode",
        size: { width: 235, height: 200 }
      }
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      }
      findEhrStaffEmployeesGenderCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var result = response.data.responseData;
          var count = 0;
          this.$delete(result,0)
          result.forEach(item => {
            count += item.countNum;
          });
          if (count > 0) {
            this.basicColumnChartProp.data = [];
            result.forEach(item => {
              if (item.staffGender == "woman") {
                this.basicColumnChartProp.data[0] = {
                  item: "女",
                  count: item.countNum,
                  percent: parseFloat((item.countNum / count).toFixed(2))
                };
              }
              if (item.staffGender == "man") {
                this.basicColumnChartProp.data[1] = {
                  item: "男",
                  count: item.countNum,
                  percent: parseFloat((item.countNum / count).toFixed(2))
                };
              }
            });
          }
          this.basicBarChart();
        }
      });
    },
    basicBarChart: function() {
      let data = this.basicColumnChartProp.data;
      if(data.length > 0) {
        let chart = new G2.Chart({
          container: this.basicColumnChartProp.container,
          // forceFit: true,
          padding: ["auto", 30, "auto", -50],
          width: this.basicColumnChartProp.size.width,
          height: this.basicColumnChartProp.size.height
          // animate: false
        });
        chart.source(data, {
          percent: {
            formatter: function formatter(val) {
              val = val * 100 + "%";
              return val;
            }
          }
        });
        chart.coord("theta", {
          radius: 0.75,
          innerRadius: 0.6
        });
        chart.legend("item", {
          position: "right-center",
          offsetX: -10,
          textStyle: {
            fill: "#fff",
            opacity: 0.6,
            fontSize: 11
          }
        });
        chart.tooltip({
          showTitle: false,
          itemTpl:
            '<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
        });
        // 辅助文本
        chart.guide().html({
          position: ["50%"],
          html:
            '<div style="color:#fff;font-size: 14px;text-align: center; opacity: 0.6;"></div>',
          alignX: "100",
          alignY: "100"
        });
        var interval = chart
          .intervalStack()
          .position("percent")
          .color("item", ["#FC2695", "#268AFC"])
          .tooltip("item*percent", function(item, percent) {
            percent = percent * 100 + "%";
            return {
              name: item,
              value: parseFloat(percent)
            };
          })
          .style({
            lineWidth: 1
            // stroke: '#fff'
          });
        chart.render();
      }
    }
  },
  mounted() {
    this.queryData();
  }
};
</script>
<style lang="scss" scoped>
.box {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #mountNode {
      width: 235px;
      height: 200px;
    }
  }
}
</style>