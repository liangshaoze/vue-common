<!--客户关怀统计、员工关怀统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>{{sourceType==="customer"?"客户关怀统计":"员工关怀统计"}}</p>
      <div class="description">
        <p>
          <span class="square"></span>
          男
          <span class="num">
            <span v-if="careData.manCareList">
              {{careData.manCareList.countNum}}
            </span>
            <span v-else>0</span>
          </span>
        </p>
        <p>
          <span class="square red"></span>
          女
          <span class="num">
            <span v-if="careData.womanCareList">
              {{careData.womanCareList.countNum}}
            </span>
            <span v-else>0</span>
          </span>
        </p>
      </div>
      <div v-if="sourceType === 'customer'" id="thrid"></div>
      <div v-else id="sixth"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>
<script>
import { changeYMD } from "utils/index";
import {
  findEhrStaffEmployeesCareCount,
  findEtProductOrderCustomerCareCount
} from "@/api/bigData";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      careData: {}
    };
  },
  props: {
    sourceType: {
      type: String,
      default: ""
    },
    orgCode: {
      type: String,
      default: ""
    }
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      if (this.sourceType === "customer") {
        findEtProductOrderCustomerCareCount(params).then(response => {
          if (response.data.statusCode == 200) {
            this.careData = response.data.responseData;
            this.$nextTick(() => {
              this.createChart();
            });
          }
        });
      } else {
        findEhrStaffEmployeesCareCount(params).then(response => {
          if (response.data.statusCode == 200) {
            this.careData = response.data.responseData;
            this.$nextTick(() => {
              this.createChart();
            });
          }
        });
      }
    },
    createChart() {
      if(this.careData.manCareList) {
        const colorMap = {
          男: "#0F81F5FF",
          女: "#FC2695FF"
        };
        const data1 = [
          { name: "男", month: "1", sum: this.careData.manCareList.January },
          { name: "男", month: "2", sum: this.careData.manCareList.February },
          { name: "男", month: "3", sum: this.careData.manCareList.March },
          { name: "男", month: "4", sum: this.careData.manCareList.April },
          { name: "男", month: "5", sum: this.careData.manCareList.May },
          { name: "男", month: "6", sum: this.careData.manCareList.Jun },
          { name: "男", month: "7", sum: this.careData.manCareList.Jul },
          { name: "男", month: "8", sum: this.careData.manCareList.August },
          { name: "男", month: "9", sum: this.careData.manCareList.September },
          { name: "男", month: "10", sum: this.careData.manCareList.October },
          { name: "男", month: "11", sum: this.careData.manCareList.November },
          { name: "男", month: "12", sum: this.careData.manCareList.December },
          { name: "女", month: "1", sum: this.careData.womanCareList.January },
          { name: "女", month: "2", sum: this.careData.womanCareList.February },
          { name: "女", month: "3", sum: this.careData.womanCareList.March },
          { name: "女", month: "4", sum: this.careData.womanCareList.April },
          { name: "女", month: "5", sum: this.careData.womanCareList.May },
          { name: "女", month: "6", sum: this.careData.womanCareList.Jun },
          { name: "女", month: "7", sum: this.careData.womanCareList.Jul },
          { name: "女", month: "8", sum: this.careData.womanCareList.August },
          { name: "女", month: "9", sum: this.careData.womanCareList.September },
          { name: "女", month: "10", sum: this.careData.womanCareList.October },
          { name: "女", month: "11", sum: this.careData.womanCareList.November },
          { name: "女", month: "12", sum: this.careData.womanCareList.December }
        ];
        const chart = new G2.Chart({
          container: this.sourceType === "customer" ? "thrid" : "sixth",
          padding: [30, 30, 30, 30],
          width: 560,
          height: 400
        });
        chart.source(data1);
        chart.scale("sum", {
          nice: true,
          min: 0
        });
        chart.legend(false);
        chart.axis("month", {
          label: {
            formatter(value) {
              return value + "月";
            },
            textStyle: {
              fill: "#C3D9D7FF",
              fontSize: 11,
              opacity: 0.6
            }
          }
        });
        chart.axis("sum", {
          label: {
            formatter(value) {
              return value;
            },
            textStyle: {
              fill: "#C3D9D7FF",
              fontSize: 11,
              opacity: 0.6
            }
          },
          grid: {
            align: "center",
            type: "line",
            lineStyle: {
              stroke: "#000", // 网格线的颜色
              lineWidth: 0.01, // 网格线的粗细
              lineDash: [1, 2] // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
            },
            hideFirstLine: true, // 是否隐藏第一条网格线，默认为 false
            hideLastLine: true
          }
        });
        chart.tooltip({
          showMarkers: false,
          shared: true
        });
        chart
          .interval()
          .position("month*sum")
          .color("name", val => {
            return colorMap[val];
          })
          .adjust([
            {
              type: "dodge",
              marginRatio: 0
            }
          ]);
        chart.render();
      }
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 600px;
  height: 420px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    > p {
      color: #fff;
      opacity: 0.6;
      margin: 10px 0 0 5px;
    }
    .description {
      position: relative;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      p {
        margin-left: 20px;
        color: #ddd9;
        font-size: 12px;
        .square {
          display: inline-block;
          width: 8px;
          height: 8px;
          background-color: #0f81f5ff;
          margin-right: 3px;
        }
        .square.red {
          background-color: #fc2695ff;
        }
        .num {
          font-size: 18px;
          font-weight: 700;
          color: #fff;
          margin-left: 7px;
        }
      }
    }
    #thrid,
    #sixth {
      width: 540px;
      height: 420px;
      margin-top: -20px;
    }
  }
}
</style>