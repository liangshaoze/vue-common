<template>
  <div id="bdHomePage">
    <div class="screen_left">
      <div class="screen_left_top">
        <div class="screen-text">
          <p>历史员工总人数</p>
          <p class="number">{{staff.historyCount}}</p>
        </div>
        <div class="screen-text">
          <p>{{new Date().getFullYear()-1}}年末在职人数</p>
          <p class="number">{{staff.yearCount}}</p>
        </div>
        <div class="screen-text">
          <p>在职人数</p>
          <p class="number">{{staff.jobCount}}</p>
        </div>
        <div class="screen-text">
          <p>本月新增员工</p>
          <p class="number" style="color:#21FF7F;">+{{staff.monthCount}}</p>
        </div>
      </div>
      <div class="screen_left_middle_split">
        <div class="screen_left_middle_left">
          <home-staff-type />
        </div>
        <div class="screen_left_middle_right">
          <home-staff-education />
        </div>
      </div>
      <div class="screen_left_middle">
        <staffAgeChart :isHomepage="true" />
      </div>
      <div class="screen_left_bottom">
        <monthServiceTimeChart />
      </div>
    </div>
    <div class="screen_middle">
      <div class="screen_middle_main">
        <bigDataStarMap />
      </div>
      <div class="screen_middle_bottom">
        <monthlyServiceChart />
      </div>
    </div>
    <div class="screen_right">
      <div class="screen_right_top">
        <div class="screen--right-text">
          <p>本月新增客户</p>
          <p style="color:#21FF7F;" class="number">+{{customerData.womanCount+customerData.manCount}}</p>
        </div>
        <div class="screen--right-text">
          <p>在服务客户总数</p>
          <p class="number">{{customer.inServiceCount}}</p>
        </div>
        <div class="screen--right-text">
          <p>{{new Date().getFullYear()-1}}年末服务人数</p>
          <p class="number">{{customer.lastYearCount}}</p>
        </div>
        <div class="screen--right-text">
          <p>历史客户总数</p>
          <p class="number">{{customer.historyCount}}</p>
        </div>
        <!-- </div> -->
      </div>
      <div class="screen_right_middle">
        <customer-gender-grade />
      </div>
      <div class="screen_right_bottom">
        <customerAgeChart />
      </div>
    </div>
  </div>
</template>

<script>
import monthlyServiceChart from "./monthlyServiceChart";
import bigDataStarMap from "./bigDataStarMap";
import realTimeInfo from "./realTimeInfo";
import echarts from "echarts";
import homeStaffType from "./homeStaffType"; //在职员工类型统计
import homeStaffEducation from "./homeStaffEducation"; //员工学历统计
import customerGenderGrade from "./customerGenderGrade"; //客户性别/等级统计
import staffAgeChart from "./staffAgeChart"; //员工年龄统计
import monthServiceTimeChart from "./monthServiceTimeChart"; //月服务时长统计
import customerAgeChart from "./customerAgeChart"; //客户年龄统计
import {
	findEhrStaffHomeCount,
findEtProductOrderHistoryServiceCount,
findEtProductOrderMonthAddCount
} from "@/api/bigData"
export default {
  name: "spectaculars",
  data() {
    return {
      staff: {
        // historyCount: 1333,
        // yearCount: 1321,
        // jobCount: 1321,
        // monthCount: 398
      },
      customer: {
        // historyCount: 292,
        // lastYearCount: 0,
        // inServiceCount: 92
      },
      customerData:{}
    };
  },
  components: {
    bigDataStarMap,
    homeStaffType,
    homeStaffEducation,
    customerGenderGrade,
    staffAgeChart,
    monthServiceTimeChart,
    customerAgeChart,
    monthlyServiceChart
  },
  methods: {
	  queryData(){
		  findEhrStaffHomeCount().then(response=>{
			  if(response.data.statusCode == 200){
				  this.staff=response.data.responseData;
			  }
		  });
		  findEtProductOrderHistoryServiceCount().then(response=>{
			  if(response.data.statusCode == 200){
				  this.customer=response.data.responseData;
			  }
      })
       findEtProductOrderMonthAddCount().then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          dataList.forEach(item => {
            if (item.gender == "man") {
              this.customerData.manCount = item.countNum;
            }
            if (item.gender == "woman") {
              this.customerData.womanCount = item.countNum;
            }
          });
        }
      });
	  }
  },
  created() {
	  this.queryData();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped lang="scss">
.screen_left {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_middle {
  width: 600px;
  height: 900px;
  margin: 0px 35px;
  float: left;
}
.screen_right {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_left_top {
  height: 100px;
  display: flex;
  justify-content: space-between;
  .screen-text {
    p {
      font-family: PingFang-SC-Medium;
      font-size: 14px;
      color: #dddddd;
    }
    .number {
      font-family: PingFang-SC-Medium;
      margin: 20px 0;
      font-size: 40px;
      color: #ffff;
    }
  }
}
.screen_left_middle {
  height: 230px;
  margin: 10px 0px;
}
.screen_left_middle_split {
  height: 230px;
  margin: 10px 0px;
}
.screen_left_middle_left {
  width: 295px;
  height: 230px;
  margin-right: 10px;
  float: left;
}
.screen_left_middle_right {
  width: 295px;
  height: 230px;
  float: left;
}
.screen_left_bottom {
  height: 400px;
  margin: 10px 0px;
}
.screen_middle_main {
  height: 550px;
  margin: 30px 0px 10px 0px;
}
.screen_middle_bottom {
  height: 300px;
  margin: 10px 0px;
}
.screen_right_top {
  height: 100px;
  display: flex;
  justify-content: space-between;
  p {
    font-family: PingFang-SC-Medium;
    font-size: 14px;
    color: #dddddd;
  }
  .number {
    font-family: PingFang-SC-Medium;
    margin: 20px 0;
    font-size: 40px;
    color: #ffff;
  }
}
.screen_right_middle {
  height: 470px;
  margin: 10px 0px;
}
.screen_right_bottom {
  height: 300px;
  margin: 10px 0px;
}
</style>
