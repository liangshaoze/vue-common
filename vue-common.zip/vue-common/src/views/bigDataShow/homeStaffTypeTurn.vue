<!--在职员工类型统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>在职员工类型统计</p>
      <div id="first"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>
<script>
//引入jquery
import "@/utils/jquery/js/jquery.min.js";
import { findEhrStaffEmployeesTypeCount } from "@/api/bigData";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      seriesData: [],
      myChart: null
    };
  },
  mounted() {
    this.queryData();
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      }
      findEhrStaffEmployeesTypeCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var data = response.data.responseData;
          if(data.length > 0) {
            for (let i = data.length - 1; i >= 0; i--) {
              this.seriesData.push({
                name:  data[i].positionType,
                value: data[i].countNum
              })
            }
            this.$nextTick(()=>{
              this.initCharts();
            })
          }
        }
      });
    },
    initCharts() {
      this.myChart = this.$echarts.init(
        document.getElementById("first")
      );
      this.createChart(this.seriesData);
    },
    createChart(series) {
      if(series.length > 0) {
        let color = ["#FF8700", "#00e473", "#009DFF"];
        let arrName = [];
        let arrValue = [];
        let sum = 0;
        let pieSeries = [],
          lineYAxis = [];

        // 数据处理
        series.forEach((v, i) => {
          arrName.push(v.name);
          arrValue.push(v.value);
          sum = sum + v.value;
        });

        // 图表option整理
        series.forEach((v, i) => {
          pieSeries.push({
            name: "在职员工类型",
            type: "pie",
            clockWise: false,
            hoverAnimation: false,
            radius: [65 - i * 15 + "%", 55 - i * 15 + "%"],
            center: ["30%", "60%"],
            label: {
              show: false
            },
            data: [
              {
                value: v.value,
                name: v.name
              },
              {
                value: sum - v.value,
                name: "",
                itemStyle: {
                  color: "rgba(0,0,0,0)"
                }
              }
            ]
          });
          pieSeries.push({
            name: "",
            type: "pie",
            silent: true,
            z: 1,
            clockWise: false, //顺时加载
            hoverAnimation: false, //鼠标移入变大
            radius: [65 - i * 15 + "%", 55 - i * 15 + "%"],
            center: ["30%", "60%"],
            label: {
              show: false
            },
            data: [
              {
                value: 7.5,
                itemStyle: {
                  color: "rgba(227,240,255,0.2)"
                }
              },
              {
                value: 2.5,
                name: "",
                itemStyle: {
                  color: "rgba(0,0,0,0)"
                }
              }
            ]
          });
          v.percent = ((v.value / sum) * 100).toFixed(1) + "%";
          lineYAxis.push({
            value: i,
            textStyle: {
              rich: {
                circle: {
                  color: color[i],
                  padding: [0, 5]
                }
              }
            }
          });
        });

        var option = {
          color: color,
          grid: {
            top: "10%",
            bottom: "55%",
            left: "30%",
            containLabel: false
          },
          yAxis: [
            {
              type: "category",
              inverse: true,
              axisLine: {
                show: false
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                formatter: function(params) {
                  let item = series[params];
                  return (
                    "{line|}{circle|●}{name|" +
                    item.name +
                    "}{bd||}{percent|" +
                    item.percent +
                    "}{value|" +
                    item.value +
                    "}{unit|人}"
                  );
                },
                interval: 0,
                inside: true,
                textStyle: {
                  color: "#333",
                  fontSize: 12,
                  rich: {
                    name: {
                      color: "rgba(245,245,245,0.6)",
                      fontSize: 10
                    },
                    bd: {
                      color: "#ccc",
                      padding: [0, 5],
                      fontSize: 10
                    },
                    percent: {
                      color: "#E0E0E0",
                      fontSize: 10
                    },
                    value: {
                      color: "#16CEB2",
                      fontSize: 13,
                      fontWeight: 600,
                      padding: [0, 0, 0, 10]
                    },
                    unit: {
                      color: "#E0E0E0",
                      fontSize: 10
                    }
                  }
                },
                show: true
              },
              data: lineYAxis
            }
          ],
          xAxis: [
            {
              show: false
            }
          ],
          series: pieSeries
        };
        this.myChart.setOption(option);
      }
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
}
</style>
<style lang='scss'>
.content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
      opacity: 0.8;
    }
    #first {
      width: 235px;
      height: 200px;
    }
  }
</style>