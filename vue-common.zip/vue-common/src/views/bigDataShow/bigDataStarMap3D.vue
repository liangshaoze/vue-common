<template>
  <div>
    <div id="allmap" style="width:600px;height: 550px;"></div>
  </div>
</template>

<script>
import "@/utils/echarts-gl/china.js";
export default {
  data() {
    return {};
  },
  created() {},
  mounted() {
    var chinaDatas = [
      { name: "运营中心", value: 4629 },
      { name: "嘉兴福寿康医养健康管理有限公司", value: 35 },
      { name: "广州福寿康医疗养老有限公司", value: 0 },
      { name: "苏州福寿康康贤居家护理有限公司", value: 0 },
      { name: "常州福寿康健康养老管理服务有限公司", value: 0 },
      { name: "厦门福寿康医疗养老服务有限公司", value: 0 },
      { name: "温州福寿康医养服务有限公司", value: 0 },
      { name: "浙江福寿康医养服务有限公司", value: 0 },
      { name: "承德福寿康医养服务有限公司", value: 0 },
      { name: "苏州福寿康养老服务有限公司", value: 0 },
      { name: "南京福寿康健康养老管理服务有限公司", value: 0 },
      { name: "重庆福寿康健康管理有限公司", value: 0 },
      { name: "绍兴福寿康健康养老服务有限公司", value: 0 },
      { name: "无锡福寿康养老服务有限公司", value: 0 },
      { name: "成都福寿康健康管理有限公司", value: 0 }
    ];

    var geoCoordMap = {
      运营中心: [121.48248, 31.301634],
      嘉兴福寿康医养健康管理有限公司: [120.760826, 30.768932],
      广州福寿康医疗养老有限公司: [113.27328, 23.13726],
      苏州福寿康康贤居家护理有限公司: [120.620636, 31.34851],
      常州福寿康健康养老管理服务有限公司: [119.96759, 31.781654],
      厦门福寿康医疗养老服务有限公司: [118.086075, 24.483963],
      温州福寿康医养服务有限公司: [120.69255, 27.996899],
      浙江福寿康医养服务有限公司: [120.15921, 30.277136],
      承德福寿康医养服务有限公司: [117.94249, 40.9853],
      苏州福寿康养老服务有限公司: [120.620476, 31.348894],
      南京福寿康健康养老管理服务有限公司: [118.77971, 32.10587],
      重庆福寿康健康管理有限公司: [106.40228, 29.811157],
      绍兴福寿康健康养老服务有限公司: [120.60585, 30.01083],
      无锡福寿康养老服务有限公司: [120.308975, 31.586466],
      成都福寿康健康管理有限公司: [104.10413, 30.631939]
    };

    var convertData = function(data) {
      var res = [];
      for (var i = 0; i < data.length; i++) {
        var geoCoord = geoCoordMap[data[i].name];
        if (geoCoord) {
          res.push({
            name: data[i].name,
            value: geoCoord.concat(data[i].value)
          });
        }
      }
      return res;
    };

    var myChart = this.$echarts.init(document.getElementById("allmap"));

    var option = {
      visualMap: [
        {
          type: "continuous",
          show: false,
          seriesIndex: 0,
          text: ["bar3D"],
          calculable: true,
          max: 300,
          inRange: {
            color: ["#87aa66", "#eba438", "#d94d4c"]
          }
        }
      ],
      geo3D: {
        map: "china",
        roam: false,  //是否允许缩放
        itemStyle: {
          color: "#1d5e98",
          opacity: 1,
          borderWidth: 0.5,
          borderColor: "rgb(62,215,213)"
        },
        label: {
          show: false
        },
        viewControl: {
          autoRotate :false, //是否开启自动3d 旋转
          autoRotateDirection: 'cw', //控制物体自转的方向
          autoRotateSpeed: 5, //自转速度
          autoRotateAfterStill: 2, //鼠标静止操作后恢复自动旋转的时间间隔,在开启 autoRotate 后有效
          zoomSensitivity: 0,
          rotateSensitivity: [1, 0],
          minBeta: 0,
          maxBeta: 36000000000
        },
        emphasis: {
          //当鼠标放上去  地区区域是否显示名称
          label: {
            show: true,
            textStyle: {
              color: "#fff",
              fontSize: 16,
              backgroundColor: "rgba(0,23,11,0)"
            }
          }
        },
        light: {
          main: {
            color: "#fff", //光照颜色
            intensity: 1.2, //光照强度
            shadowQuality: "high", //阴影亮度
            shadow: false, //是否显示阴影
            alpha: 50,
            beta: 10
          },
          ambient: {
            color: '#fff',
            intensity: 0.3
          }
        }
      },
      series: [
        {
          name: "bar3D",
          type: "bar3D",
          coordinateSystem: "geo3D",
          barSize: 1, //柱子粗细
          shading: "lambert",
          opacity: 1,
          bevelSize: 0.3,
          label: {
            show: false,
            formatter: function(data) {
              var res = data.name + " " + data.value[2];
              return res;
            }
          },
          data: convertData(chinaDatas)
        }
      ]
    };

    myChart.setOption(option);
  }
};
</script>

<style scoped>
</style>
