<!--员工学历统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>员工学历统计</p>
      <div id="second"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>
<script>
import { findEhrStaffEmployeesCardCount } from "@/api/bigData";
import DataSet from "@antv/data-set";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      data: [
        {
          item: "硕士及以上",
          count: 11,
          percent: 0.002
        },
        {
          item: "本科",
          count: 151,
          percent: 0.0364
        },
        {
          item: "大专",
          count: 337,
          percent: 0.081
        },
        {
          item: "中专/高中",
          count: 980,
          percent: 0.236
        },
        {
          item: "初中",
          count: 2544,
          percent: 0.613
        },
        {
          item: "其他",
          count: 126,
          percent: 0.23
        }
      ]
    };
  },
  mounted() {
    // this.createChart();
    this.queryData();
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEhrStaffEmployeesCardCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.createChart(response.data.responseData);
        }
      });
    },
    // 环图
    createChart(dataList) {
      //  小学、初中、中专/高中、大专、本科、硕士、博士、其他
      if (dataList) {
        this.data = [];
        var totalCount = 0;
        dataList.forEach(item => {
          totalCount += item.countNum;
        });
        dataList.forEach(item => {
          var obj = {};
          obj.item = item.staffEducation;
          obj.count = item.countNum;
          obj.percent = parseFloat(item.countNum / totalCount).toFixed(4);
          this.data.push(obj);
        });
      }
      var data = this.data;
      var chart = new G2.Chart({
        container: "second",
        width: "235",
        height: "200",
        padding: ["auto", 10, "auto", 10]
      });
      chart.source(data, {
        percent: {
          formatter: function formatter(val) {
            val = Math.round(val * 10000) / 100 + "%";
            return val;
          },
          textStyle: {
            fill: "#ffffff"
          }
        }
      });
      chart.legend("item", {
        position: "bottom-center",
        textStyle: {
          fill: "#fff"
        }
      }); //图例
      chart.coord("theta", {
        radius: 0.75,
        innerRadius: 0.6
      });
      chart.tooltip({
        showTitle: false,
        itemTpl:
          '<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
      });
      var interval = chart
        .intervalStack()
        .position("percent")
        .color("item")
        .label("percent", {
          formatter: function formatter(val, item) {
            return item.point.item + ": " + val;
          },
          textStyle: {
            fill: "#C3D9D7FF"
          }
        })
        .tooltip("item*percent", function(item, percent) {
          percent = Math.round(percent * 10000) / 100 + "%";
          return {
            name: item,
            value: percent
          };
        })
        .style({
          // lineWidth: 1,
          stroke: "#fff"
        });
      chart.render();
      // interval.setSelected(data[0]);
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #second {
      width: 235px;
      height: 200px;
    }
  }
}
</style>