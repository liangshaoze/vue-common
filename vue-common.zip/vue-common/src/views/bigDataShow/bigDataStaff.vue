<template>
  <div id="bdStaff">
    <div class="screen_left">
      <div class="screen_left_top">
        <div class="screen-text">
          <p>历史员工总人数</p>
          <p class="number">{{staff.historyCount}}</p>
        </div>
        <div class="screen-text">
          <p>{{new Date().getFullYear()-1}}年末在职人数</p>
          <p class="number">{{staff.yearCount}}</p>
        </div>
        <div class="screen-text">
          <p>在职人数</p>
          <p class="number">{{staff.jobCount}}</p>
        </div>
        <div class="screen-text">
          <p>本月新增员工</p>
          <p class="number" style="color:#FF9933;">{{staff.monthCount}}</p>
        </div>
      </div>
      <div class="screen_left_middle_split">
        <div class="screen_left_middle_left">
          <!-- <home-staff-type :orgCode="orgCode" /> -->
          <home-staff-type-turn :orgCode="orgCode" />
        </div>
        <div class="screen_left_middle_right">
          <!-- <home-staff-education :orgCode="orgCode" /> -->
          <home-staff-education-row :orgCode="orgCode" />
        </div>
      </div>
      <div class="screen_left_middle_split">
        <div class="screen_left_middle_left">
          <staffGenderChart :orgCode="orgCode" />
        </div>
        <div class="screen_left_middle_right">
          <staffPositionChart :orgCode="orgCode" />
        </div>
      </div>
      <div class="screen_left_bottom">
        <staffAgeChart :orgCode="orgCode" />
      </div>
    </div>
    <div class="screen_middle">
      <div class="screen_middle_main">
        <staffFromMap />
      </div>
      <div class="screen_middle_bottom">
        <!--省市区占比-->
        <el-table
          :data="tableData"
          height="300"
          :header-cell-style="{background:'#060715',color:'#FFFFFF'}"
          row-class-name="scrollRowStyle"
          class="tableStyleOverFlow"
        >
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="companyType" label="各省市户籍地区"></el-table-column>
          <el-table-column prop="cCount" label="各省市户籍地区所占比例(%)" width="200"></el-table-column>
        </el-table>
      </div>
    </div>
    <div class="screen_right">
      <div class="screen_right_top">
        <div class="screen-img-right">
          <img :src="imgLeft" />
          <img :src="imgRight" />
        </div>
        <div class="screen_staff_content">
          <div class="screen--right-text">
            <p>当月收到简历</p>
            <p class="number">{{resumeData.monthResumeCount}}</p>
          </div>
          <div class="screen--right-text">
            <p>当月面试</p>
            <p class="number">{{resumeData.viewCount}}</p>
          </div>
          <div class="screen--right-text">
            <p>当月入职</p>
            <p class="number">{{resumeData.rzCount}}</p>
          </div>
        </div>
      </div>
      <div class="screen_right_middle">
        <customerCareAndStaffCare :orgCode="orgCode" sourceType="staff" />
      </div>
      <div class="screen_right_bottom">
        <!--滚屏-->
        <realTimeInfo
          v-if="realTimeDataList.length>0"
          :dataList="realTimeDataList"
          :columnName="columnName"
        />
      </div>
    </div>
  </div>
</template>

<script>
import realTimeInfo from "./realTimeInfo";
import echarts from "echarts";
import staffGenderChart from "./staffGenderChart";
import homeStaffType from "./homeStaffType"; //在职员工类型统计
import homeStaffTypeTurn from "./homeStaffTypeTurn"; //在职员工类型统计
import homeStaffEducation from "./homeStaffEducation"; //员工学历统计
import homeStaffEducationRow from "./homeStaffEducationRow"; //员工学历统计
import customerCareAndStaffCare from "./customerCareAndStaffCare"; //员工关怀统计
import staffFromMap from "./staffFromMap";
import staffAgeChart from "./staffAgeChart";
import staffPositionChart  from "./staffPositionChart ";
import {
  findEhrStaffResumeCount,
  findEhrStaffTobeProcessCount,
  findEhrStaffEmployeesHouseProvinceCount,
  findEhrStaffHomeCount
} from "@/api/bigData";

export default {
  name: "",
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      resumeData: {
        monthResumeCount: 1,
        viewCount: 1,
        rzCount: 0
      },
      tableData:[],
      realTimeDataList: [],
      columnName: "本月待处理",
      staff:{}
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      }
       findEhrStaffHomeCount(params).then(response=>{
			  if(response.data.statusCode == 200){
				  this.staff=response.data.responseData;
			  }
		  });
      findEhrStaffResumeCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.resumeData = response.data.responseData;
        }
      });
      findEhrStaffTobeProcessCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var result = response.data.responseData;
          this.realTimeDataList = [
            {
              content: "待转正（试用期结束日期在当月的）人数：" +
                result.tobePositiveCount
            },
            {
              content: "合同到期时间（在当月的）：" + result.contractExpireCount
            },
            {
              content: "当月简历还未关联员工的人数：" + result.unrelatedCount
            }
          ];
        }
      });
      findEhrStaffEmployeesHouseProvinceCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          this.tableData=[];
          dataList.forEach(item => {
            this.tableData.push({
               companyType: item.houseProvinceName,
               cCount: item.scaleNum
            })
          });
        }
      });
    }
  },
  components: {
    realTimeInfo,
    staffGenderChart,
    // homeStaffType,
    homeStaffTypeTurn,
    // homeStaffEducation,
    homeStaffEducationRow,
    staffFromMap,
    staffAgeChart,
    customerCareAndStaffCare,
    staffPositionChart
  }
};
</script>

<style scoped lang="scss">
.screen_left {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_middle {
  width: 600px;
  height: 900px;
  margin: 0px 35px;
  float: left;
}
.screen_right {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_left_top {
  height: 100px;
  background: rgb(7, 7, 39);
  display: flex;
  justify-content: space-between;
  .screen-text {
    padding:10px;
    p {
      font-size: 14px;
      color: #dddddd;
      opacity: 0.8;
    }
    .number {
      margin: 20px 0;
      font-size: 40px;
      font-weight: bold;
      color: #16CEB2;
      opacity: 1;
    }
  }
}
.screen_left_middle {
  height: 230px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_left_middle_split {
  height: 230px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_left_middle_left {
  width: 295px;
  height: 230px;
  background: rgb(7, 7, 39);
  margin-right: 10px;
  float: left;
}
.screen_left_middle_right {
  width: 295px;
  height: 230px;
  background: rgb(7, 7, 39);
  float: left;
}
.screen_left_bottom {
  height: 300px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_middle_main {
  height: 550px;
  background: rgb(7, 7, 39);
  margin: 30px 0px 10px 0px;
}
.screen_middle_bottom {
  height: 300px;
  margin: 10px 0px;
}
.screen_right_top {
  height: 150px;
  background: rgb(7, 7, 39);
  .screen-img-right {
    display: flex;
    justify-content: space-between;
    img {
      width: 30px;
      height: 30px;
    }
  }
  .screen_staff_content {
    display: flex;
    justify-content: space-between;
    padding: 15px 30px;
    background: rgb(7, 7, 39);
    .screen--right-text {
      p {
        font-size: 14px;
        color: #dddddd;
        opacity: 0.8;
      }
      .number {
        margin: 20px 0;
        font-size: 40px;
        font-weight: bold;
        color: #16CEB2;
        opacity: 1;
      }
    }
  }
}
.screen_right_middle {
  height: 420px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_right_bottom {
  height: 300px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
</style>