<template>
  <div id="bdCustomer">
    <div class="screen_left">
      <div class="screen_left_top">
        <!-- <div class="screen-text">
          <p>历史客户总数</p>
          <p class="number">61907</p>
        </div>
        <div class="screen-text">
          <p>2019年末客户总数</p>
          <p class="number">40062</p>
        </div>
        <div class="screen-text">
          <p>在服务客户总数</p>
          <p class="number">40861</p>
        </div>-->
        <div class="screen-text">
          <p>历史客户总数</p>
          <p class="number">{{customerHistory.historyCount}}</p>
        </div>
        <div class="screen-text">
          <p>{{new Date().getFullYear()-1}}年末客户总数</p>
          <p class="number">{{customerHistory.lastYearCount}}</p>
        </div>
        <div class="screen-text">
          <p>在服务客户总数</p>
          <p class="number">{{customerHistory.inServiceCount}}</p>
        </div>
      </div>
      <div class="screen_left_middle">
        <customer-gender-grade :orgCode="orgCode"/>
      </div>
      <div class="screen_left_bottom">
        <customerAgeChart :orgCode="orgCode"/>
      </div>
    </div>
    <div class="screen_middle">
      <div class="screen_middle_main">
        <customerMapChart/>
      </div>
      <div class="screen_middle_bottom">
        <!--公司/站点下客户人数统计-->
        <el-table
          :data="tableData"
          height="282"
          :header-cell-style="{background:'#060715',color:'#FFFFFF'}"
          row-class-name="scrollRowStyle"
          class="tableStyleOverFlow"
        >
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="companyType" label="公司类别"></el-table-column>
          <el-table-column prop="cCount" label="客户人数" width="150"></el-table-column>
        </el-table>
      </div>
    </div>
    <div class="screen_right">
      <div class="screen_right_top">
        <div class="screen-img-right">
          <img :src="imgLeft">
          <p>本月新增客户</p>
          <img :src="imgRight">
        </div>
        <div class="screen_staff_content">
          <div class="screen--right-text">
            <p class="number">
              {{customerData.womanCount+customerData.manCount}}
              <span class="addsex">女</span>
              <span class="addnumber">{{customerData.womanCount}}</span>
              <span class="addsex">男</span>
              <span class="addnumber">{{customerData.manCount}}</span>
            </p>
          </div>
        </div>
      </div>

      <div class="screen_right_middle">
        <customerCareAndStaffCare :orgCode="orgCode" sourceType="customer"/>
      </div>
      <div class="screen_right_bottom">
        <!--滚屏-->
        <realTimeInfo :dataList="realTimeDataList" v-if="realTimeDataList.length > 0"/>
      </div>
    </div>
  </div>
</template>

<script>
import realTimeInfo from "./realTimeInfo";
import echarts from "echarts";
import customerMapChart from "./customerMapChart";
import customerGenderGrade from "./customerGenderGrade"; //客户性别/等级统计
import customerCareAndStaffCare from "./customerCareAndStaffCare"; //客户关怀统计
import customerAgeChart from "./customerAgeChart";
import {
  findEtProductOrderMonthAddCount,
  findEtProductOrderHistoryServiceCount,
  findEtProductOrderCustomerRealInfoCount,
  findEtProductOrderCustomerServicePeopleNum
} from "@/api/bigData";
export default {
  name: "spectaculars",
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      customerData: {
        womanCount: 0,
        manCount: 0
      },
      customerHistory: {},
      tableData: [],
      realTimeDataList: []
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  created() {
    var _this = this;
    this.EventBus.handleEvent("resetLoadData", function(val) {
      if(val.activeName == 'customer') {
        console.log("----------->变更组织加载客户模块,orgCode:"+ val.orgCode);
        _this.orgCode = val.orgCode;
        _this.queryData();
      }
    });
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEtProductOrderMonthAddCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          this.customerData = {
            womanCount: 0,
            manCount: 0
          }
          dataList.forEach(item => {
            if (item.gender == "man") {
              this.customerData.manCount = item.countNum;
            }
            if (item.gender == "woman") {
              this.customerData.womanCount = item.countNum;
            }
          });
        }
      });
      findEtProductOrderHistoryServiceCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.customerHistory = response.data.responseData;
        }
      });
      findEtProductOrderCustomerRealInfoCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var result = response.data.responseData;
          this.realTimeDataList = [
            {
              content: "待服务的客户人数（待确认订单）：" + result.tobeServedCount
            },
            {
              content: "本月到期订单数：" + result.monthExpireCount
            },
            {
              content: "转护理站人数：" + result.toNursingCount
            },
            {
              content: "转养老院人数：" + result.toYlyCount
            }
          ];
        }
      });
      findEtProductOrderCustomerServicePeopleNum(params).then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          this.tableData = [];
          dataList.forEach(item => {
            this.tableData.push({
              companyType: item.orgUnitName,
              cCount: item.countNum
            });
          });
        }
      });
    }
  },
  components: {
    realTimeInfo,
    customerGenderGrade,
    customerCareAndStaffCare,
    customerAgeChart,
    customerMapChart
  }
};
</script>

<style scoped lang="scss">
.screen_left {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_middle {
  width: 600px;
  height: 900px;
  margin: 0px 35px;
  float: left;
}
.screen_right {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_left_top {
  height: 150px;
  background: rgb(7, 7, 39);
  display: flex;
  justify-content: space-between;
  .screen-text {
    height:150px;
    padding:10px;
    text-align: center;
    p {
      font-size: 14px;
      color: #dddddd;
      opacity: 0.8;
    }
    .number {
      margin: 40px 0;
      font-size: 40px;
      font-weight: bold;
      color: #16CEB2;
      opacity: 1;
    }
  }
}
.screen_left_middle {
  height: 420px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_left_bottom {
  height: 300px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_middle_main {
  height: 550px;
  background: rgb(7, 7, 39);
  margin: 30px 0px 10px 0px;
}
.screen_middle_bottom {
  height: 300px;
  margin: 10px 0px;
}
.screen_right_top {
  height: 150px;
  background: rgb(7, 7, 39);
  .screen-img-right {
    display: flex;
    justify-content: space-between;
    img {
      width: 30px;
      height: 30px;
    }
    p {
      position: absolute;
      margin: 8px 0 0 35px;
      opacity: 0.6;
    }
  }
  .screen_staff_content {
    text-align: left;
    height: 120px;
    padding: 15px 30px;
    background: rgb(7, 7, 39);
    .screen--right-text {
      p {
        font-size: 14px;
        color: #dddddd;
      }
      .number {
        margin: 20px 0;
        font-size: 40px;
        font-weight: bold;
        color: #16CEB2;
        .addsex {
          font-size: 14px;
          margin: 0 0 0 100px;
          color: #dddddd;
        }
        .addnumber {
          font-size: 24px;
          color: #16CEB2;
        }
      }
    }
  }
}
.screen_right_middle {
  height: 420px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
.screen_right_bottom {
  height: 300px;
  background: rgb(7, 7, 39);
  margin: 10px 0px;
}
</style>