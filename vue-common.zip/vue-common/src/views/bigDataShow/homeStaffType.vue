<!--在职员工类型统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft">
    </div>
    <div class="content">
      <p>在职员工类型统计</p>
      <div id="first"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight">
    </div>
  </div>
</template>
<script>
import { findEhrStaffEmployeesTypeCount } from "@/api/bigData";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      data: [
        { type: "兼职", sum: 366 },
        { type: "其他(实习、退休返聘)", sum: 342 },
        { type: "全职", sum: 3671 }
      ]
    };
  },
  created() {
    // this.createChart();
    this.queryData();
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      }
      findEhrStaffEmployeesTypeCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.createChart(response.data.responseData);
        }
      });
    },
    createChart(dataList) {
      if (dataList) {
        this.data = [];
        dataList.forEach(item => {
          var obj = {};
          obj.type = item.positionType;
          obj.sum = item.countNum;
          this.data.push(obj);
        });
      }
      const data = this.data;
      const colorMap = {
        全职: "#FF7A21",
        兼职: "#21FFAE",
        "其他(实习、退休返聘)": "#FF2121"
      };
      const chart = new G2.Chart({
        container: "first",
        padding: ["auto", 30, "auto", 30],
        width: 235,
        height: 200
      });
      chart.source(data);
      chart.coord("polar", {
        innerRadius: 0.2
      });
      chart.legend("type", {
        textStyle: {
          fill: "#fff"
        }
      }); //图例
      chart.axis(false); //不展示坐标系
      chart.tooltip({
        showMarkers: false
      });
      chart
        .interval()
        .position("type*sum")
        .color("type", val => colorMap[val])
        .style({
          // lineWidth: 1,
          stroke: "#fff"
        });
      chart.render();
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 295px;
  height: 230px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #first {
      width: 235px;
      height: 200px;
    }
  }
}
</style>