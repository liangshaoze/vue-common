<!--客户年龄统计-->
<template>
  <div style="background-color:#070727">
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png" />
      </div>
      <div style="width:100%;margin-top:10px;text-size:16px;height:16px;opacity: 0.8">客户年龄统计</div>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png" />
      </div>
    </div>
    <div id="custmerAge" style="width:560px;height: 270px;"></div>
  </div>
</template>
<script>
import {findEtProductOrderCustomerAgeCount} from "@/api/bigData"
export default {
  data() {
    return {
      datalist: {}
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  mounted() {
    this.queryData()
  },
  methods: {
    queryData(){
      var params = {
        orgCode: this.orgCode
      }
      findEtProductOrderCustomerAgeCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.datalist = response.data.responseData;
          this.createChart(this.datalist);
        }
      });
    },
    createChart(obj) {
      if(obj) {
        var _G = G2,
          Global = _G.Global;
        const data = [
          { country: "60以下", type:"男", value: obj.man60 },
          { country: "60以下", type:"女",value: obj.woman60 },
          { country: "60-70", type:"男",value: obj.man6070 },
          { country: "60-70", type:"女",value: obj.woman6070 },
          { country: "70-80", type:"男",value: obj.man7080 },
          { country: "70-80", type:"女",value: obj.woman7080 },
          { country: "80-90", type:"男",value: obj.man8090},
          { country: "80-90", type:"女",value: obj.woman8090 },
          { country: "90-100", type:"男",value: obj.man90100 },
          { country: "90-100", type:"女",value: obj.woman90100 },
          { country: "100以上", type:"男",value: obj.man100 },
          { country: "100以上", type:"女",value: obj.woman100 }
        ];
        const chart = new G2.Chart({
          container: "custmerAge",
          forceFit: true,
          height: 270,
          padding: "auto"
        });
        chart.source(data, {
          value: {
            min: 0,
            nice: false,
            alias: "客户数（位）"
          }
        });
        chart.axis("value", false);
        chart.legend({
          position: "top-center"
        });
        chart.coord().transpose();
        chart.facet("mirror", {
          fields: ["type"],
          autoSetAxis: false,
          transpose: true,
          showTitle: false,
          padding: [0, 20, 0, 0],
          eachView: function eachView(view, facet) {
            var facetIndex = facet.colIndex;
            if (facetIndex === 0) {
              view.axis("country", {
                position: "top",
                label: {
                  textStyle: {
                    fill: "#C3D9D7FF",
                    opacity: 0.6,
                    fontSize: 11,
                  }
                },
                tickLine: {
                  alignWithLabel: false,
                  length: 0
                },
                line: {
                  lineWidth: 0
                }
              });
            } else {
              view.axis("country", false);
            }
            var color = facetIndex === 0 ? "#8D3AF4" : "#16CEB2";
            view
              .interval()
              .position("country*value")
              .color(color)
              .size(17)
              .opacity(1)
              .label("value", function(val) {
                var offset = -4;
                var shadowBlur = 2;
                var textAlign = facetIndex === 1 ? "end" : "start";
                var fill = "black";
                if (val < 57) {
                  offset = 4;
                  textAlign = facetIndex === 1 ? "start" : "end";
                  fill = "white";
                  shadowBlur = 0;
                }
                return {
                  //position: 'middle',
                  offset: offset,
                  textStyle: {
                    fill: fill,
                    shadowBlur: shadowBlur,
                    shadowColor: "rgba(0, 0, 0, .45)",
                    textAlign: textAlign
                  }
                };
              });
          }
        });
        chart.render();
      }
    }
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>