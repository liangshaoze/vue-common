<!--客户关怀统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft" />
    </div>
    <div class="content">
      <p>客户关怀统计</p>
      <div class="description">
        <p>
          <span class="square"></span>
          男
          <span class="num">16756</span>
        </p>
        <p>
          <span class="square red"></span>
          女
          <span class="num">25329</span>
        </p>
        <!-- <p>{{time}}</p> -->
      </div>
      <div id="thrid"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight" />
    </div>
  </div>
</template>
<script>
// import moment from "moment";
import { changeYMD } from "utils/index";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      time: ""
    };
  },
  mounted() {
    this.time = changeYMD(new Date()).replace(/-/g, "/");
    this.createChart();
  },
  methods: {
    createChart() {
      //随机数
      function getNumber(min = 10, max = 240) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
      }
      const colorMap = {
        男: "#0F81F5FF",
        女: "#FC2695FF"
      };
      const data = [
        { name: "男", month: "1", sum: 1611 },
        { name: "男", month: "2", sum: 1455 },
        { name: "男", month: "3", sum: 1312 },
        { name: "男", month: "4", sum: 1028 },
        { name: "男", month: "5", sum: 1006 },
        { name: "男", month: "6", sum: 1101 },
        { name: "男", month: "7", sum: 1361 },
        { name: "男", month: "8", sum: 1459 },
        { name: "男", month: "9", sum: 1427 },
        { name: "男", month: "10", sum: 1597 },
        { name: "男", month: "11", sum: 1738 },
        { name: "男", month: "12", sum: 1661 },
        { name: "女", month: "1", sum: 2475 },
        { name: "女", month: "2", sum: 2247 },
        { name: "女", month: "3", sum: 2063 },
        { name: "女", month: "4", sum: 1700 },
        { name: "女", month: "5", sum: 1621 },
        { name: "女", month: "6", sum: 1626 },
        { name: "女", month: "7", sum: 1919 },
        { name: "女", month: "8", sum: 2101 },
        { name: "女", month: "9", sum: 2195 },
        { name: "女", month: "10", sum: 2388 },
        { name: "女", month: "11", sum: 2461 },
        { name: "女", month: "12", sum: 2588 }
      ];
      const chart = new G2.Chart({
        container: "thrid",
        padding: [50, 50, 50, 50],
        width: 540,
        height: 420
      });
      chart.source(data);
      chart.scale("sum", {
        nice: true,
        min: 0
        // max:250
      });
      // chart.legend("name", {
      //   position: "top-right",
      //   offsetY: -10,
      //   textStyle: {
      //     fill: "#fff",
      //     fontSize: "11"
      //   }
      // }); //图例
      chart.legend(false);
      chart.axis("month", {
        label: {
          formatter(value) {
            return value + "月";
          }, // 格式化坐标轴的显示
          textStyle: {
            fill: "#C3D9D7FF", //修改坐标轴label样式 
          }
        }
      });
      chart.axis("sum", {
        label: {
          formatter(value) {
            return value;
          },
          textStyle: {
            fill: "#C3D9D7FF"
          }
        },
        grid: {
          align: "center",
          type: "line",
          lineStyle: {
            stroke: "#999", // 网格线的颜色
            lineWidth: 0.1, // 网格线的粗细
            lineDash: [1, 2] // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
          },
          hideFirstLine: true, // 是否隐藏第一条网格线，默认为 false
          hideLastLine: true
        }
      });
      chart.tooltip({
        showMarkers: false,
        shared: true
      });
      chart
        .interval()
        .position("month*sum")
        .color("name", val => {
          return colorMap[val];
        })
        .adjust([
          {
            type: "dodge",
            marginRatio: 0
          }
        ]);
      chart.render();
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 600px;
  height: 420px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    > p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    .description {
      position: relative;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      p {
        margin-left: 20px;
        color: #ddd9;
        font-size: 12px;
        .square {
          display: inline-block;
          width: 8px;
          height: 8px;
          background-color: #0f81f5ff;
          margin-right: 3px;
        }
        .square.red {
          background-color: #fc2695ff;
        }
        .num {
          font-size: 18px;
          font-weight: 700;
          color: #fff;
          margin-left: 7px;
        }
      }
    }
    #thrid {
      width: 540px;
      height: 420px;
      margin-top: -20px;
    }
  }
}
</style>