<!--全国员工来源-->
<template>
  <div style="background-color:#060715">
    <div style="width:100%;margin-top:10px;text-size:16px;padding:0px;height:16px">全国员工来源</div>
    <div id="main" style="height:550px;"></div>
  </div>
</template>
<script>
import echarts from "echarts";
import 'echarts/map/js/china.js';
export default {
  data() {
    return {};
  },
  methods: {
    createChart() {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById('main'));
      var chinaGeoCoordMap = {
        "江苏": [118.7577797179,32.062894652],
        "安徽": [117.3184097275,31.7302800302],
        "河南": [113.7468087479,34.7663740731],
        "吉林": [125.3194860474,43.8935948874],
        "上海": [121.4648, 31.2891],
        "湖北": [114.3365165193,30.5477075054],
        "浙江": [120.1482817504,30.2679458569],
        "四川": [104.0645185402,30.573884935],
        "湖南": [112.9774371866,28.1159886334],
        "山东": [117.0150329528,36.6684584614],
        "黑龙江": [126.6569889294,45.7402920742],
        "江西": [115.9041651882,28.678716161],
        "辽宁": [123.4228753091,41.8332784856],
        "陕西": [108.9493179689,34.2710555338],
        "山西": [112.5567133283,37.8730033909],
        "广东": [113.2606615241,23.1343756641],
        "河北": [114.524071888,38.036952569],
        "贵州": [106.7042655578,26.60146761],
        "广西": [108.3239924052,22.8181251724],
        "甘肃": [103.8235780073,36.0596398322],
        "云南": [102.7085645915,25.0482571732],
        "重庆": [106.54,29.59],
        "福建": [119.2912109374,26.1032140346],
        "内蒙古": [111.7590830143,40.8159854773],
        "新疆": [87.6241731158,43.7919091236],
        "青海": [101.7780515423,36.6211021499],
        "北京": [116.46,39.92],
        "海南": [110.3445895734,20.0220493652],
        "宁夏": [106.2545993266,38.470732369],
        "香港": [114.15,22.15]
      };
      var chinaDatas = [
        [
          {name: "江苏",value: 0}
        ],
        [
          {
            name: "安徽",
            value: 0
          }
        ],
        [
          {
            name: "河南",
            value: 0
          }
        ],
        [
          {
            name: "吉林",
            value: 0
          }
        ],
        [
          {
            name: "上海",
            value: 0
          }
        ],
        [
          {
            name: "湖北",
            value: 0
          }
        ],
        [
          {
            name: "浙江",
            value: 0
          }
        ],
        [
          {
            name: "四川",
            value: 0
          }
        ],
        [
          {
            name: "湖南",
            value: 0
          }
        ],
        [
          {
            name: "山东",
            value: 0
          }
        ],
        [
          {
            name: "黑龙江",
            value: 0
          }
        ],
        [
          {
            name: "江西",
            value: 0
          }
        ],
        [
          {
            name: "辽宁",
            value: 0
          }
        ],
        [
          {
            name: "陕西",
            value: 0
          }
        ],
        [
          {
            name: "山西",
            value: 0
          }
        ],
        [
          {
            name: "广东",
            value: 0
          }
        ],
        [
          {
            name: "河北",
            value: 0
          }
        ],
        [
          {
            name: "贵州",
            value: 0
          }
        ],
        [
          {
            name: "广西",
            value: 0
          }
        ],
        [
          {
            name: "甘肃",
            value: 0
          }
        ],
        [
          {
            name: "云南",
            value: 0
          }
        ],
        [
          {
            name: "重庆",
            value: 0
          }
        ],
        [
          {
            name: "福建",
            value: 0
          }
        ],
        [
          {
            name: "内蒙古",
            value: 0
          }
        ],
        [
          {
            name: "新疆",
            value: 0
          }
        ],
        [
          {
            name: "青海",
            value: 0
          }
        ],
        [
          {
            name: "北京",
            value: 0
          }
        ],
        [
          {
            name: "海南",
            value: 0
          }
        ],
        [
          {
            name: "宁夏",
            value: 0
          }
        ],
        [
          {
            name: "香港",
            value: 0
          }
        ]
      ];

      var convertData = function(data) {
        var res = [];
        for (var i = 0; i < data.length; i++) {
          var dataItem = data[i];
          var fromCoord = chinaGeoCoordMap[dataItem[0].name];
          var toCoord = [121.4648, 31.2891];
          if (fromCoord && toCoord) {
            res.push([
              {
                coord: fromCoord,
                value: dataItem[0].value
              },
              {
                coord: toCoord
              }
            ]);
          }
        }
        return res;
      };
      var series = [];
      [["上海", chinaDatas]].forEach(function(item, i) {
        console.log(item);
        series.push(
          {
            type: "lines",
            zlevel: 2,
            effect: {
              show: true,
              period: 4, //箭头指向速度，值越小速度越快
              trailLength: 0.02, //特效尾迹长度[0,1]值越大，尾迹越长重
              symbol: "arrow", //箭头图标
              symbolSize: 1 //图标大小
            },
            lineStyle: {
              normal: {
                width: 0.1, //尾迹线条宽度
                opacity: 0.8, //尾迹线条透明度
                curveness: 0.3 //尾迹线条曲直度
              }
            },
            data: convertData(item[1])
          },
          {
            type: "effectScatter",
            coordinateSystem: "geo",
            zlevel: 2,
            rippleEffect: {
              //涟漪特效
              period: 4, //动画时间，值越小速度越快
              brushType: "stroke", //波纹绘制方式 stroke, fill
              scale: 3 //波纹圆环最大限制，值越大波纹越大
            },
            label: {
              normal: {
                show: false,
                position: "right", //显示位置
                offset: [5, 0], //偏移设置
                formatter: function(params) {
                  //圆环显示文字
                  return params.data.name;
                },
                fontSize: 13
              },
              emphasis: {
                show: false
              }
            },
            symbol: "circle",
            silent: true, //是否影响鼠标悬浮操作
            symbolSize: function(val) {
              return 3 + val[2] * 5; //圆环大小
            },
            itemStyle: {
              normal: {
                show: false,
                color: "#f00"
              }
            },
            data: item[1].map(function(dataItem) {
              return {
                name: dataItem[0].name,
                value: chinaGeoCoordMap[dataItem[0].name].concat([
                  dataItem[0].value
                ])
              };
            })
          },
          //被攻击点
          {
            type: "scatter",
            coordinateSystem: "geo",
            zlevel: 2,
            rippleEffect: {
              period: 3,  //动画时间，值越小速度越快
              brushType: "stroke",
              scale: 4  //波纹圆环最大限制，值越大波纹越大
            },
            label: {
              normal: {
                show: true,
                position: "right",
                // offset:[5, 0],
                color: "#33FFFF",
                formatter: "{b}",
                textStyle: {
                  color: "#33FFFF"
                }
              },
              emphasis: {
                show: true,
                color: "#33FFFF"
              }
            },
            symbol: "pin",
            symbolSize: 20,
            silent: true, //是否影响鼠标悬浮操作
            data: [
              {
                name: item[0],
                value: chinaGeoCoordMap[item[0]].concat([10])
              }
            ]
          }
        );
      });

      var option = {
        tooltip: {
          trigger: "item",
          backgroundColor: "rgba(166, 200, 76, 0.82)",
          borderColor: "#FFFFCC",
          showDelay: 0,
          hideDelay: 0,
          enterable: true,
          transitionDuration: 0,
          extraCssText: "z-index:100",
          // formatter: function(params, ticket, callback) {
          //   //根据业务自己拓展要显示的内容
          //   var res = "";
          //   var name = params.name;
          //   var value = params.value[params.seriesIndex + 1];
          //   res =
          //     "<span style='color:#fff;'>" +
          //     name +
          //     "</span><br/>数据：" +
          //     value;
          //   return res;
          // }
        },
        backgroundColor: "#060715",
        visualMap: {
          //图例值控制
          min: 0,
          max: 1,
          calculable: true,
          show: false,
          color: ["#f44336", "#fc9700", "#ffde00", "#ffde00", "#00eaff"],
          textStyle: {
            color: "#fff"
          }
        },
        geo: {
          map: "china",
          zoom: 1.2,
          label: {
            emphasis: {
              show: false
            }
          },
          roam: false, //是否允许缩放
          itemStyle: {
            normal: {
              color: "#060715", //地图背景色
              borderColor: "#516a89", //省市边界线00fcff 516a89
              borderWidth: 1
            },
            emphasis: {
              color: "rgba(37, 43, 61, .5)" //悬浮背景
            }
          }
        },
        series: series
      };
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(option);
    }
  },
  mounted() {
    this.createChart();
  },
  created() {}
};
</script>
<style>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 30px;
}
</style>