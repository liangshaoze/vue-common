<template>
  <div id="bdService">
    <div class="screen_left">
      <div class="screen_left_top">
        <service-satisfaction-rate/>
      </div>
      <div class="screen_left_middle">
        <today-visit-chart/>
      </div>
      <div class="screen_left_bottom">
        <today-service-time-chart :orgCode="orgCode"/>
      </div>
    </div>
    <div class="screen_middle">
      <div class="screen_middle_top">
        <todayServiceVolumeChart :orgCode="orgCode"/>
      </div>
      <div class="screen_middle_main">
        <serviceMapChart/>
      </div>
      <div class="screen_middle_bottom">
        <!--公司/站点下客户人数统计-->
        <el-table
          :data="tableData"
          height="200"
          :header-cell-style="{background:'#060715',color:'#FFFFFF'}"
          row-class-name="scrollRowStyle"
          class="tableStyleOverFlow"
        >
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="companyType" label="公司"></el-table-column>
          <el-table-column prop="cCount" label="正在服务人数" width="150"></el-table-column>
        </el-table>
      </div>
    </div>
    <div class="screen_right">
      <div class="screen_right_top">
        <monthlyServiceChart :orgCode="orgCode"/>
      </div>
      <!-- <div class="screen_right_middle"> -->
        <!-- <month-service-time-chart :orgCode="orgCode"/> -->
      <!-- </div> -->
      <div class="screen_right_bottom">
        <!--滚屏-->
        <realTimeInfo v-if="realTimeDataList.length > 0" :dataList="realTimeDataList"/>
      </div>
    </div>
  </div>
</template>

<script>
import serviceMapChart from "./serviceMapChart";
import monthlyServiceChart from "./monthlyServiceChart";
import realTimeInfo from "./realTimeInfo";
import echarts from "echarts";
import serviceSatisfactionRate from "./serviceSatisfactionRate"; //今日已服务满意率
import todayVisitChart from "./todayVisitChart";
import todayServiceTimeChart from "./todayServiceTimeChart";
// import monthServiceTimeChart from "./monthServiceTimeChart";
import todayServiceVolumeChart from "./todayServiceVolumeChart";
import {
  findEtProductOrderCustomerRealInfoCount,
  findEtProductOrderCustomerServicePeopleNum
} from "@/api/bigData";
export default {
  name: "spectaculars",
  components: {
    serviceMapChart,
    monthlyServiceChart,
    realTimeInfo,
    todayVisitChart,
    todayServiceTimeChart,
    // monthServiceTimeChart,
    serviceSatisfactionRate,
    todayServiceVolumeChart
  },
  props: {
    orgCode: {
      type: String,
      default: ''
    }
  },
  // watch: {
  //   orgCode:function(v){
  //     this.orgCode = v
  //     this.queryData();
  //    },
  // },
  data() {
    return {
      tableData: [],
      realTimeDataList: []
    };
  },
  created() {
  },
  mounted() {
    this.queryData();
  },
  methods: {
    queryData() {
      console.log("service模块 orgCode======》"+this.orgCode);
      var params = {
        orgCode: this.orgCode
      };
      findEtProductOrderCustomerRealInfoCount(params).then(response => {
        if (response.data.statusCode == 200) {
          var result = response.data.responseData;
          this.realTimeDataList = [
            {
              content: "待服务的客户人数（待确认订单）：" + result.tobeServedCount
            },
            {
              content: "本月到期订单数：" + result.monthExpireCount
            },
            {
              content: "转护理站人数：" + result.toNursingCount
            },
            {
              content: "转养老院人数：" + result.toYlyCount
            }
          ];
        }
      });
      findEtProductOrderCustomerServicePeopleNum(params).then(response => {
        if (response.data.statusCode == 200) {
          var dataList = response.data.responseData;
          this.tableData = [];
          dataList.forEach(item => {
            this.tableData.push({
              companyType: item.orgUnitName,
              cCount: item.countNum
            });
          });
        }
      });
    }
  }
};
</script>

<style scoped lang="scss">
.screen_left {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_middle {
  width: 600px;
  height: 900px;
  margin: 0px 35px;
  float: left;
}
.screen_right {
  width: 600px;
  height: 900px;
  float: left;
}
.screen_left_top {
  height: 290px;
  background: rgba(7, 7, 39, 1);
}
.screen_left_middle {
  height: 290px;
  background: rgba(7, 7, 39, 1);
  margin: 10px 0px;
}
.screen_left_bottom {
  height: 290px;
  background: rgba(7, 7, 39, 1);
  margin: 10px 0px;
}
.screen_middle_top {
  height: 260px;
  margin: 30px 0px 10px 0px;
}
.screen_middle_main {
  height: 380px;
  margin: 10px 0px 10px 0px;
}
.screen_middle_bottom {
  height: 200px;
  margin: 10px 0px;
}
.screen_right_top {
  height: 600px;
  background: rgba(7, 7, 39, 1);
}
.screen_right_middle {
  height: 300px;
  background: rgba(7, 7, 39, 1);
  margin: 10px 0px;
}
.screen_right_bottom {
  height: 280px;
  background: rgba(7, 7, 39, 1);
  margin: 10px 0px;
}
</style>