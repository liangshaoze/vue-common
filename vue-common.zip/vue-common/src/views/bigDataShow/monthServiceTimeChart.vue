<!--月服务时长统计-->
<template>
  <div style="background-color:#070727">
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png">
      </div>
      <el-row type="flex" style="width:100%;margin-top:10px;">
        <el-col>
          <span style="text-size:16px;padding:0px;height:16px;opacity:0.8;">月服务时长统计(H)</span>
        </el-col>
        <el-col>
          <div style="float:right;display:flex;">
            <div
              @click="monthClick"
              :style="{backgroundColor:month?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >月</div>
            <div
              @click="seasonClick"
              :style="{backgroundColor:season?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >季</div>
            <div
              @click="yearClick"
              :style="{backgroundColor:year?'#1A1AD1':'#0A0A77',padding:'5px'}"
            >年</div>
          </div>
        </el-col>
      </el-row>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png">
      </div>
    </div>
    <div id="monthServiceTime" style="width:600px;height: 260px;"></div>
  </div>
</template>
<script>
import { findEtProductOrderServiceTotal } from "@/api/bigData";
import { stubTrue } from "lodash-es";
export default {
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      month: true,
      season: false,
      year: false,
      myChart: null,
      allData: {},
      seriesData: {}
    };
  },
  watch: {
    seriesData: {
      handler(newVal, oldVal) {
        this.createMonthChart(newVal);
      }
    }
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      };
      findEtProductOrderServiceTotal(params).then(response => {
        if (response.data.statusCode == 200) {
          this.allData = response.data.responseData;
          this.initCharts();
        }
      });
    },
    monthClick() {
      this.month = true;
      this.season = false;
      this.year = false;
      var xData = [];
      var zData = [];
      this.allData.sixMonthCountList.forEach(item => {
        xData.push(item.month);
        zData.push(item.serviceTimeNum);
      });
      this.seriesData = {
        xData: xData,
        zData: zData
      };
    },
    seasonClick() {
      this.month = false;
      this.season = true;
      this.year = false;
      var xData = [];
      var zData = [];
      this.allData.sixQuarterCountList.forEach(item => {
        xData.push(item.year + '-'+ item.quarter);
        zData.push(item.serviceTimeNum);
      });
      this.seriesData = {
        xData: xData,
        zData: zData
      };
    },
    yearClick() {
      this.month = false;
      this.season = false;
      this.year = true;
      var xData = [];
      var zData = [];
      this.allData.threeYearCountList.forEach(item => {
        xData.push(item.year);
        zData.push(item.serviceTimeNum);
      });
      this.seriesData = {
        xData: xData,
        zData: zData
      };
    },
    initCharts() {
      this.myChart = this.$echarts.init(
        document.getElementById("monthServiceTime")
      );
      var xData = [];
      var zData = [];
      this.allData.sixMonthCountList.forEach(item => {
        xData.push(item.month);
        zData.push(item.serviceTimeNum);
      });
      this.seriesData = {
        xData: xData,
        zData: zData
      };
    },
    createMonthChart(series) {
      this.myChart.setOption({
        backgroundColor: "rgba(7, 7, 39, 1)",
        tooltip: {
          trigger: "axis",
          axisPointer: {
            lineStyle: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(255,255,255,0)" // 0% 处的颜色
                  },
                  {
                    offset: 0.5,
                    color: "rgba(255,255,255,1)" // 100% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(255,255,255,0)" // 100% 处的颜色
                  }
                ],
                global: false // 缺省为 false
              }
            }
          }
        },
        grid: {
          top: "10%",
          left: "10%",
          right: "1%",
          bottom: "15%"
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: stubTrue,
            axisLine: {
              //坐标轴轴线相关设置。数学上的x轴
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,0.1)"
              }
            },
            axisLabel: {
              //坐标轴刻度标签的相关设置
              textStyle: {
                color: "#666666",
                fontSize: 10
              }
           },
            data: series.xData
          }
        ],
        yAxis: [
          {
            type: "value",
            splitLine: {
              show: false
            },
            axisLabel: {
              //坐标轴刻度标签的相关设置
              textStyle: {
                color: "#666666",
                fontSize: 10
              }
            },
          }
        ],
        series: [
          {
            name: "月服务时长(H)",
            type: "line",
            smooth: true,
            showAllSymbol: true,
            symbolSize: 8,
            lineStyle: {
              normal: {
                color: "#53fdfe" // 线条颜色
              },
              borderColor: "#f0f"
            },
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#fff"
              }
            },
            itemStyle: {
              normal: {
                color: "rgba(255,255,255,1)"
              }
            },
            tooltip: {
              show: true
            },
            areaStyle: {
              //区域填充样式
              normal: {
                //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
                color: new this.$echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "rgba(0,150,239,0.3)"
                    },
                    {
                      offset: 1,
                      color: "rgba(0,253,252,0)"
                    }
                  ],
                  false
                ),
                shadowColor: "rgba(53,142,215, 0.9)", //阴影颜色
                shadowBlur: 20 //shadowBlur设图形阴影的模糊大小。配合shadowColor,shadowOffsetX/Y, 设置图形的阴影效果。
              }
            },
            data: series.zData
          }
        ]
      });
    }
  },
  created() {},
  mounted() {
    this.queryData();
  }
};
</script>
<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
  height: 40px;
}
</style>