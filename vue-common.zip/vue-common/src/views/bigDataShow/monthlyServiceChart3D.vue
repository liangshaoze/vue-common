<template>
  <div>
    <div class="chartContainer">
      <div class="screen-img">
        <img src="/fsk/static/img/screen-left.png" />
      </div>
      <el-row type="flex" style="width:100%;">
        <el-col>
          <span style="text-size:16px;line-height:30px">月服务统计(人次)</span>
        </el-col>
        <el-col>
          <div style="float:right;display:flex;">
            <div
              @click="monthClick"
              :style="{backgroundColor:month?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >月</div>
            <div
              @click="seasonClick"
              :style="{backgroundColor:season?'#1A1AD1':'#0A0A77',padding:'5px',marginRight:'3px'}"
            >季</div>
            <div
              @click="yearClick"
              :style="{backgroundColor:year?'#1A1AD1':'#0A0A77',padding:'5px'}"
            >年</div>
          </div>
        </el-col>
      </el-row>
      <div class="screen-img">
        <img src="/fsk/static/img/screen-right.png" />
      </div>
    </div>
    <div id="monthService" style="width:600px;height: 260px;"></div>
  </div>
</template>

<script>
import "@/utils/echarts-gl/china.js";
export default {
  data() {
    return {
      myChart: null,
      month: true,
      season: false,
      year: false,
      seriesData: {}
    };
  },
  watch: {
    seriesData: {
      handler(newVal, oldVal) {
        this.createMonthChart(newVal);
      }
    }
  },
  methods: {
    monthClick() {
      this.month = true;
      this.season = false;
      this.year = false;
      this.seriesData = {
        xData: ["12月", "01月", "02月", "03月", "04月", "05月"],
        zData: [
          [0, 0, 639350],
          [1, 0, 543793],
          [2, 0, 216529],
          [3, 0, 387958],
          [4, 0, 519563],
          [5, 0, 575945]
        ],
        colorList: [
          "#37b70c",
          "#fae521",
          "#f29c00",
          "#dd3f36",
          "#b3013f",
          "#a00398"
        ]
      };
    },
    seasonClick() {
      this.month = false;
      this.season = true;
      this.year = false;
      this.seriesData = {
        xData: [
          "2019一季度",
          "2019二季度",
          "2019三季度",
          "2019四季度",
          "2020一季度",
          "2020二季度"
        ],
        zData: [
          [0, 0, 682109],
          [1, 0, 855797],
          [2, 0, 1318604],
          [3, 0, 1783179],
          [4, 0, 1148280],
          [5, 0, 1095508]
        ],
        colorList: [
          "#37b70c",
          "#fae521",
          "#f29c00",
          "#dd3f36",
          "#b3013f",
          "#a00398"
        ]
      };
    },
    yearClick() {
      this.month = false;
      this.season = false;
      this.year = true;
      this.seriesData = {
        xData: ["2018年", "2019年", "2020年"],
        zData: [[0, 0, 1207143], [1, 0, 4639689], [2, 0, 2243788]],
        colorList: ["#37b70c", "#fae521", "#dd3f36"]
      };
    },
    initCharts() {
      this.myChart = this.$echarts.init(document.getElementById("monthService"));
      this.createMonthChart(this.seriesData);
    },
    createMonthChart(series) {
      this.myChart.setOption({
        backgroundColor: "rgba(7,7,39,1)",
        xAxis3D: {
          type: "category",
          name: "",
          data: series.xData,
          axisLine: {
            lineStyle: {
              color: "#FFF",
              width: 1
            }
          },
          axisLabel: {
            interval: 0,
            textStyle: {
              color: "#FFF",
              fontSize: 13
            }
          }
        },
        yAxis3D: {
          type: "category",
          name: "",
          axisLine: {
            lineStyle: {
              color: "#FFF",
              width: 1
            }
          },
          axisLabel: {
            show: false
          }
        },
        zAxis3D: {
          type: "value",
          name: "",
          axisLine: {
            lineStyle: {
              color: "#FFF",
              width: 1
            }
          },
          axisLabel: {
            interval: 0,
            margin: 55,
            textStyle: {
              color: "#FFF",
              fontSize: 10
            }
          }
        },
        grid3D: {
          boxWidth: 250,
          boxDepth: 30,
          axisPointer: {
            show: false
          },
          light: {
            main: {
              intensity: 1.2
            },
            ambient: {
              intensity: 0.3
            }
          },
          viewControl: {
            alpha: 0,
            beta: 0,
            zoomSensitivity: 0,
            rotateSensitivity: [1, 0]
          }
        },
        series: [
          {
            type: "bar3D",
            name: "1",
            barSize: 15,
            itemStyle: {
              normal: {
                color: function(params) {
                  return series.colorList[params.dataIndex];
                }
              }
            },
            data: series.zData,
            stack: "stack",
            shading: "lambert",
            emphasis: {
              label: {
                show: true
              }
            }
          }
        ]
      });
    }
  },
  created() {},
  mounted() {
    this.initCharts();
    this.seriesData = {
      xData: ["12月", "01月", "02月", "03月", "04月", "05月"],
      zData: [
        [0, 0, 639350],
        [1, 0, 543793],
        [2, 0, 216529],
        [3, 0, 387958],
        [4, 0, 519563],
        [5, 0, 575945]
      ],
      colorList: [
        "#37b70c",
        "#fae521",
        "#f29c00",
        "#dd3f36",
        "#b3013f",
        "#a00398"
      ]
    };
  }
};
</script>

<style scoped>
.screen-img {
  height: 100%;
  background: rgb(7, 7, 39);
}
.screen-img img {
  width: 30px;
  height: 30px;
}
.chartContainer {
  display: flex;
  justify-content: stretch;
}
</style>
