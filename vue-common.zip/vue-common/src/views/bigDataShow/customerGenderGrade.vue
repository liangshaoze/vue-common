<!--客户性别/等级统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft" />
    </div>
    <div class="content">
      <p>客户性别/等级统计</p>
      <div id="fourth"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight" />
    </div>
  </div>
</template>
<script>
import { findEtProductOrderCustomerGenderCount } from "@/api/bigData";
import DataSet from "@antv/data-set";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png"
    };
  },
  props: {
    orgCode: {
      type: String,
      default: ""
    }
  },
  mounted() {
    this.queryData()
  },
  methods: {
    queryData() {
      var params = {
        orgCode: this.orgCode
      }
      findEtProductOrderCustomerGenderCount(params).then(response => {
        if (response.data.statusCode == 200) {
          this.createChart(response.data.responseData);
        }
      });
    },
    createChart(obj) {
      if(obj) {
        const data = [
          { value: obj.man4zCount, type: "男性", name: "中度" },
          { value: obj.man56zCount, type: "男性", name: "重度" },
          { value: obj.man23qCount, type: "男性", name: "轻度" },
          { value: obj.woman4zCount, type: "女性", name: "中度 " },
          { value: obj.woman56zCount, type: "女性", name: "重度 " },
          { value: obj.woman23qCount, type: "女性", name: "轻度 " }
        ];
        // 通过 DataSet 计算百分比
        var _DataSet = DataSet,
          DataView = _DataSet.DataView;
        const dv = new DataView();
        dv.source(data).transform({
          type: "percent",
          field: "value",
          dimension: "type",
          as: "percent"
        });
        const chart = new G2.Chart({
          container: "fourth",
          width: 540,
          height: 420,
          padding: [0, 30, 30, 30]
        });
        chart.source(dv);
        chart.scale({
          percent: {
            formatter: val => {
              val = Math.round(val * 10000) / 100 + "%";
              return val;
            }
          }
        });
        chart.coord("theta", {
          radius: 0.5
        });
        chart.tooltip({
          showTitle: false,
          showMarkers: false
        });
        chart.legend(false);
        chart
          .intervalStack()
          .position("percent")
          .color("name", ["#268AFCFF", "#FC2695FF"])
          .label("type", {
            offset: -10,
            textStyle: {
              fill: "#fff",
              fontSize: "16"
            }
          })
          .tooltip("name*percent", (item, percent) => {
            percent = (percent * 100).toFixed(2) + "%";
            return {
              name: item,
              value: percent
            };
          })
          .select(false)
          .style({
            // lineWidth: 1,
            stroke: "#fff"
          });

        const outterView = chart.view();
        const dv1 = new DataView();
        dv1.source(data).transform({
          type: "percent",
          field: "value",
          dimension: "name",
          as: "percent"
        });
        outterView.source(dv1, {
          percent: {
            formatter: function formatter(val) {
              val = Math.round(val * 10000) / 100 + "%";
              return val;
            }
          }
        });
        outterView.scale({
          percent: {
            formatter: val => {
              val = Math.round(val * 10000) / 100 + "%";
              return val;
            }
          }
        });
        outterView.coord("theta", {
          innerRadius: 0.5 / 0.75,
          radius: 0.75
        });
        outterView
          .intervalStack()
          .position("percent")
          .color("name", [
            "#B1D5FC",
            "#97C7FC",
            "#66ADFF",
            "#FCB1D8",
            "#FC97CC",
            "#FC72B9"
          ])
          .label("name", {
            textStyle: {
              fill: "#C3D9D7FF",
              fontSize: "14"
            }
          })
          .tooltip("name*percent", (item, percent) => {
            percent = (percent * 100).toFixed(2) + "%";
            return {
              name: item,
              value: percent
            };
          })
          .select(false)
          .style({
            // lineWidth: 1,
            stroke: "#fff"
          });
        chart.render();
      }
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 600px;
  height: 420px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    #fourth {
      width: 540px;
      height: 420px;
    }
  }
}
</style>