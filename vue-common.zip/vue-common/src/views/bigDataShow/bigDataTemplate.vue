<template>
  <div id="bdTemplate">
    <el-container>
      <el-header class="headStyle" style="height:80px;">
        <span class="headTitle">福寿康服务分析统计</span>
        <span class="orgSelect">
          <div style="display:flex;justify-content:center;align-items:center">
          <el-button 
          class="selectBtn"
          icon="el-icon-office-building"
          @click="dialogVisible = true"
          style="width:40px"
          />
          <div
            class="selectBtn"
            @click="dialogVisible = true"
            type="text"
          >{{orgName}}</div>
          </div>
        </span>
        <span class="headDate">
          <span class="mR5">{{nowDate}}</span>
          <span class="mR5">{{nowWeek}}</span>
          <span class="times">{{nowTime}}</span>
        </span>
        <span v-if="weather.now" class="headWeather">
          <el-col>
            <span>
              <img white="25" height="25" :src="weatherUrl">
              <span class="wfont">{{weather.now.text}}</span>
            </span>
            <span>{{weather.now.temp}}℃</span>
            <span>{{weather.now.windDir}}{{weather.now.windClass}}</span>
          </el-col>
        </span>
      </el-header>
      <el-main>
        <el-tabs v-model="activeName" tab-position="bottom" @tab-click="handleClick">
          <!-- <el-tab-pane label="首页" name="homePage" class="panelStyle">
            <span slot="label">
              <i class="el-icon-s-home mR5"></i>首页
            </span>
            <bigDataHomePage v-if="activeName==='homePage'"/>
          </el-tab-pane>-->
          <el-tab-pane label="服务" name="service" class="panelStyle">
            <span slot="label">
              <i class="el-icon-menu mR5"></i>服务
            </span>
            <bigDataService :orgCode="orgCode" v-if="activeName==='service' && serviceShow"/>
          </el-tab-pane>
          <el-tab-pane label="客户" name="customer" class="panelStyle">
            <span slot="label">
              <i class="el-icon-s-custom mR5"></i>客户
            </span>
            <bigDataCustomer :orgCode="orgCode" v-if="activeName==='customer' && customerShow"/>
          </el-tab-pane>
          <el-tab-pane label="员工" name="staff" class="panelStyle">
            <span slot="label">
              <i class="el-icon-user-solid mR5"></i>员工
            </span>
            <bigDataStaff :orgCode="orgCode" v-if="activeName==='staff' && staffShow"/>
          </el-tab-pane>
        </el-tabs>
        <div class="bootom-font">
          Copyright &copy;2020 福寿康（上海）医疗养老服务有限公司 版权所有 |
          <a
            href="http://www.beian.miit.gov.cn"
            target="_blank"
          >沪ICP备16050235号</a>
        </div>
      </el-main>
    </el-container>

    <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
      <org-select v-on:listenTochildEvent="getCurrentNode"/>
    </el-dialog>
  </div>
</template>

<script>
// import bigDataHomePage from "./bigDataHomePage";
import bigDataCustomer from "./bigDataCustomer";
import bigDataService from "./bigDataService";
import bigDataStaff from "./bigDataStaff";
import { findEhrOrgList, findCityWeather } from "api/bigData";
import OrgSelect from "components/OrgSelect/bigDataPage";
import { setInterval, setTimeout } from "timers";
export default {
  data() {
    return {
      activeName: "service",
      orgCode: this.UserMgr.getUserInfo().userOrgCode,
      orgName: this.UserMgr.getUserInfo().userOrgName,
      dialogVisible: false,
      cityCode: "",
      //计时器
      timer: null,
      timerWeather: null,
      timeerFindData: null,
      nowWeek: "",
      nowDate: "",
      nowTime: "",
      weather: {},
      weatherUrl: "",
      data: [],
      //模块展示控制
      serviceShow: true,
      customerShow: false,
      staffShow: false
    };
  },
  components: {
    OrgSelect,
    // bigDataHomePage,
    bigDataCustomer,
    bigDataService,
    bigDataStaff
  },
  created() {
    this.loadTree();
  },
  mounted() {
    this.$nextTick(() => {
      this.timer = setInterval(() => {
        this.setNowTimes();
      }, 1000);
      this.timerWeather = setInterval(() => {
        this.findCityWeather();
      }, 1 * 1800 * 1000);
      this.timeerFindData = setInterval(() => {
        this.serviceShow = false;
        this.customerShow = false;
        this.staffShow = false;

        if (this.activeName === "service") {
          this.serviceShow = true;
          this.customerShow = false;
          this.staffShow = false;
        } else if (this.activeName === "customer") {
          this.serviceShow = false;
          this.customerShow = true;
          this.staffShow = false;
        } else if (this.activeName === "staff") {
          this.serviceShow = false;
          this.customerShow = false;
          this.staffShow = true;
        }
      }, 1 * 300 * 1000);
    });
  },
  methods: {
    handleClick(tab, event) {
      if (tab.name === "service") {
        this.serviceShow = true;
        this.customerShow = false;
        this.staffShow = false;
      } else if (tab.name === "customer") {
        this.serviceShow = false;
        this.customerShow = true;
        this.staffShow = false;
      } else if (tab.name === "staff") {
        this.serviceShow = false;
        this.customerShow = false;
        this.staffShow = true;
      }
    },
    //加载树结构数据
    loadTree() {
      var params = {
        orgName: this.orgName
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.data = response.data.responseData;
            this.cityCode = this.data[0].orgDistrictCode;
            this.findCityWeather();
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgList:" + error);
          return false;
        });
    },
    findCityWeather() {
      console.log("----------->查询天气,cityCode:" + this.cityCode);
      var params = {
        cityCode: this.cityCode
      };
      findCityWeather(params).then(response => {
        if (response.data.statusCode == 200) {
          this.weather = response.data.responseData.result;
          if (this.weather) {
            if (this.weather.now.text == "晴") {
              this.weatherUrl = "@/assets/img/q.png";
            } else if (this.weather.now.text == "阴") {
              this.weatherUrl = "@/assets/img/y.png";
            } else if (this.weather.now.text == "小雨") {
              this.weatherUrl = "@/assets/img/xy.png";
            } else if (this.weather.now.text == "中雨") {
              this.weatherUrl = "@/assets/img/zy.png";
            } else if (this.weather.now.text == "大雨") {
              this.weatherUrl = "@/assets/img/dy.png";
            } else if (this.weather.now.text == "晴转多云") {
              this.weatherUrl = "@/assets/img/qzdy.png";
            } else if (this.weather.now.text == "多云转晴") {
              this.weatherUrl = "@/assets/img/dyzy.png";
            } else {
              this.weatherUrl = "@/assets/img/q.png";
            }
          }
        }
      });
    },
    //时间表
    setNowTimes() {
      let myDate = new Date();
      let wk = myDate.getDay();
      let yy = String(myDate.getFullYear());
      let mm = myDate.getMonth() + 1;
      let dd = String(
        myDate.getDate() < 10 ? "0" + myDate.getDate() : myDate.getDate()
      );
      let hou = String(
        myDate.getHours() < 10 ? "0" + myDate.getHours() : myDate.getHours()
      );
      let min = String(
        myDate.getMinutes() < 10
          ? "0" + myDate.getMinutes()
          : myDate.getMinutes()
      );
      let sec = String(
        myDate.getSeconds() < 10
          ? "0" + myDate.getSeconds()
          : myDate.getSeconds()
      );
      let weeks = [
        "星期日",
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六"
      ];
      let week = weeks[wk];
      this.nowDate = yy + "/" + mm + "/" + dd;
      this.nowTime = hou + ":" + min + ":" + sec;
      this.nowWeek = week;
    },
    /**
     *
     * 查询条件开窗选择组织
     *
     */
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.orgName = data.orgName;
      this.orgCode = data.orgCode;
      this.cityCode = data.orgDistrictCode;
      this.handleClose();
      this.findCityWeather();

      this.serviceShow = false;
      this.customerShow = false;
      this.staffShow = false;

      setTimeout(() => {
        if (this.activeName === "service") {
          this.serviceShow = true;
          this.customerShow = false;
          this.staffShow = false;
        } else if (this.activeName === "customer") {
          this.serviceShow = false;
          this.customerShow = true;
          this.staffShow = false;
        } else if (this.activeName === "staff") {
          this.serviceShow = false;
          this.customerShow = false;
          this.staffShow = true;
        }
      }, 100);
    }
  },
  destroyed() {
    this.timer = null;
    this.timerWeather = null;
    this.timeerFindData = null;
  }
};
</script>

<style scoped lang="scss">
#bdTemplate {
  color: white;
  background-color: #060715;
  min-width: 1200px;
}
.mR5 {
  margin-right: 5px;
}
.bootom-font {
  height: 30px;
  width: 100%;
  text-align: center;
  line-height: 30px;
  color: #fff;
  font-size: 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  opacity: 0.6;
}
.headTitle {
  display: block;
  line-height: 70px;
  font-size: 30px;
  font-weight: 560;
  text-align: center;
  background: linear-gradient(
    0deg,
    rgb(22, 80, 187) 0%,
    rgb(120, 252, 238) 100%
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.headWeather {
  float: right;
  margin-top: -55px;
  margin-right: 280px;
  line-height: 25px;
  font-size: 14px;
  font-weight: bold;
  background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
  -webkit-background-clip: text;
  color: transparent;
  img {
    vertical-align: middle;
    margin-top: -5px;
  }
  .wfont {
    font-size: 16px;
    padding-left: 5px;
    background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
    -webkit-background-clip: text;
    color: transparent;
  }
}
.headDate {
  float: right;
  margin: -60px 20px 0 0;
  font-weight: bold;
  background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
  -webkit-background-clip: text;
  color: transparent;
  .times {
    font-size: 25px;
    font-weight: bold;
    background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
    -webkit-background-clip: text;
    color: transparent;
  }
}
.headStyle {
  background-image: url("/fsk/static/img/bigData.png");
  background-repeat: no-repeat;
  background-size: 100% 80px;
  padding: 0px;
}
.panelStyle {
  height: calc(100vh - 159px);
}
</style>
<style lang="scss">
#bdTemplate {
  .orgSelect {
    float: left;
    margin: -60px 0 0 20px;
    .selectBtn {
      text-align: left;
      background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
      -webkit-background-clip: text;
      color: transparent;
      font-size: 15px;
      font-weight: bold;
      border: 0;
      cursor: pointer;
    }
    .el-icon-office-building {
      background: linear-gradient(0deg, #1650bb 0%, #78fcee 100%);
      -webkit-background-clip: text;
      color: transparent;
      font-size: 16px;
    }
  }
  .el-table {
    background-color: rgb(7, 7, 39);
  }
  .el-main {
    padding: 0px 20px;
  }
  .el-tabs__nav-scroll {
    color: white;
    margin-left: 43%;
  }
  .el-tabs__item {
    color: white;
    padding: 0px 20px;
  }
  .el-tabs__item.is-active {
    background: linear-gradient(
      to right,
      rgba(12, 11, 10, 0.5),
      rgba(13, 39, 189, 0.849),
      rgba(38, 101, 236, 0.884)
    );
  }
  .el-tabs__active-bar {
    height: 0px;
  }
  .el-tabs__nav-wrap::after {
    background-color: black;
  }
  .tableStyleOverFlow {
    width: 600px;
    height: 300px;
    overflow-y: auto;
  }
  //实时滚动列表样式
  .el-table .rowStyle {
    background: rgba(7, 7, 39, 1);
    color: #bbbcbf;
  }
  //实时滚动列表样式
  .el-table .scrollRowStyle {
    background-color: #060715;
    color: #bbbcbf;
    overflow-y: auto;
  }
  .el-table th {
    background-color: rgb(7, 7, 39);
  }
  .el-table th.is-leaf,
  .el-table td {
    border-bottom: 0px;
  }
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background-color: transparent;
  }
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: rgba(18, 18, 100, 0.4);
    color: white;
  }
  //滚动条的宽度
  ::-webkit-scrollbar {
    width: 5px;
    height: 5px;
    background-color: #060715;
  }
  //滚动条的滑块
  ::-webkit-scrollbar-thumb {
    background-color: rgba(6, 7, 21, 0.5);
    border-radius: 3px;
  }
  .el-dialog__header {
    background-color: #0b0d28;
    margin: 0;
    border: 0;
    .el-dialog__title {
      color: #fff;
      opacity: 0.8;
    }
  }
  .el-dialog__body {
    background-color: #0b0d28;
    ::-webkit-scrollbar-thumb {
      background-color: rgba(113, 120, 218, 0.5);
      border-radius: 3px;
    }
  }
  .el-tree-node {
    background-color: #0b0d28;
    color: rgba(255, 255, 255, 0.6);
  }
  .el-dialog__headerbtn:focus .el-dialog__close,
  .el-dialog__headerbtn:hover .el-dialog__close {
    color: rgba(255, 255, 255, 0.6);
  }
  .el-tree--highlight-current
    .el-tree-node.is-current
    > .el-tree-node__content {
    background-color: #0b0d28;
  }
  .el-tree-node:focus > .el-tree-node__content {
    background-color: #0b0d28;
  }
  .el-tree-node__content:hover {
    background-color: rgba(47, 56, 182, 1);
    color: #fff;
  }
  #orgSelectBigDataPage .el-input__inner {
    background: rgba(47, 56, 182, 0.2);
    color: rgb(255, 255, 255);
    opacity: 0.8;
    border: 0;
  }
}
</style>