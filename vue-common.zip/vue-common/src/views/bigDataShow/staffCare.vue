<!--员工关怀统计-->
<template>
  <div class="home-staff-type">
    <div class="screen-img">
      <img :src="imgLeft" />
    </div>
    <div class="content">
      <p>员工关怀统计</p>
      <div class="description">
        <p>
          <span class="square"></span>
          男
          <span class="num">404</span>
        </p>
        <p>
          <span class="square red"></span>
          女
          <span class="num">3780</span>
        </p>
        <!-- <p>{{time}}</p> -->
      </div>
      <div id="sixth"></div>
    </div>
    <div class="screen-img">
      <img :src="imgRight" />
    </div>
  </div>
</template>
<script>
// import moment from "moment";
import { changeYMD } from "utils/index";
export default {
  data() {
    return {
      imgLeft: "/fsk/static/img/screen-left.png",
      imgRight: "/fsk/static/img/screen-right.png",
      time: ""
    };
  },
  mounted() {
    this.time = changeYMD(new Date()).replace(/-/g, "/");
    this.createChart();
  },
  methods: {
    createChart() {
      //随机数
      function getNumber(min = 10, max = 240) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
      }
      const colorMap = {
        男: "#0F81F5FF",
        女: "#FC2695FF"
      };
      const data = [
        { name: "男", month: "1", sum: 34 },
        { name: "男", month: "2", sum: 37 },
        { name: "男", month: "3", sum: 31 },
        { name: "男", month: "4", sum: 26 },
        { name: "男", month: "5", sum: 34 },
        { name: "男", month: "6", sum: 22 },
        { name: "男", month: "7", sum: 28 },
        { name: "男", month: "8", sum: 40 },
        { name: "男", month: "9", sum: 37 },
        { name: "男", month: "10", sum: 41 },
        { name: "男", month: "11", sum: 39 },
        { name: "男", month: "12", sum: 35 },
        { name: "女", month: "1", sum: 325 },
        { name: "女", month: "2", sum: 325 },
        { name: "女", month: "3", sum: 330 },
        { name: "女", month: "4", sum: 285 },
        { name: "女", month: "5", sum: 278 },
        { name: "女", month: "6", sum: 276 },
        { name: "女", month: "7", sum: 294 },
        { name: "女", month: "8", sum: 303 },
        { name: "女", month: "9", sum: 305 },
        { name: "女", month: "10", sum: 396 },
        { name: "女", month: "11", sum: 338 },
        { name: "女", month: "12", sum: 337 }
      ];
      const chart = new G2.Chart({
        container: "sixth",
        padding: [50, 50, 50, 50],
        width: 540,
        height: 420
      });
      chart.source(data);
      chart.scale("sum", {
        nice: true,
        min: 0
        // max:250
      });
      // chart.legend("name", {
      //   position: "top-right",
      //   offsetY: -10,
      //   textStyle: {
      //     fill: "#fff",
      //     fontSize: "11"
      //   }
      // }); //图例
      chart.legend(false);
      chart.axis("month", {
        label: {
          formatter(value) {
            return value + "月";
          },
          textStyle: {
            fill: "#C3D9D7FF"
          }
        }
      });
      chart.axis("sum", {
        label: {
          formatter(value) {
            return value;
          },
          textStyle: {
            fill: "#C3D9D7FF"
          }
        },
        grid: {
          align: "center",
          type: "line",
          lineStyle: {
            stroke: "#999", // 网格线的颜色
            lineWidth: 0.1, // 网格线的粗细
            lineDash: [1, 2] // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
          },
          hideFirstLine: true, // 是否隐藏第一条网格线，默认为 false
          hideLastLine: true
        }
      });
      chart.tooltip({
        showMarkers: false,
        shared: true
      });
      chart
        .interval()
        .position("month*sum")
        .color("name", val => {
          return colorMap[val];
        })
        .adjust([
          {
            type: "dodge",
            marginRatio: 0
          }
        ]);
      chart.render();
    }
  }
};
</script>
<style lang='scss' scoped>
.home-staff-type {
  position: relative;
  width: 600px;
  height: 420px;
  background-color: rgb(7, 7, 39);
  color: #fff;
  display: flex;
  justify-content: space-between;
  .screen-img {
    height: 100%;
    background-color: rgb(7, 7, 39);
    img {
      width: 30px;
      height: 30px;
    }
  }
  .content {
    position: relative;
    flex: 1;
    background-color: #070727;
    > p {
      color: #fff;
      margin: 10px 0 0 5px;
    }
    .description {
      position: relative;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      p {
        margin-left: 20px;
        color: #ddd9;
        font-size: 12px;
        .square {
          display: inline-block;
          width: 8px;
          height: 8px;
          background-color: #0f81f5ff;
          margin-right: 3px;
        }
        .square.red {
          background-color: #fc2695ff;
        }
        .num {
          font-size: 18px;
          font-weight: 700;
          color: #fff;
          margin-left: 7px;
        }
      }
    }
    #sixth {
      width: 540px;
      height: 420px;
      margin-top: -20px;
    }
  }
}
</style>