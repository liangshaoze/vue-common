<template>
	<!-- 全国客户分布图 -->
	<div class="box">
		<!-- <div class="screen-img">
			<img :src="imgLeft" />
		</div> -->
		<div class="content-month">
			<div style="width:100%;margin-top:10px;text-size:16px;padding:0px;height:16px">全国客户分布图</div>
			<div ref="myEchart"  id="main"></div>
		</div>
		<!-- <div class="screen-img">
			<img :src="imgRight" />
		</div> -->
		<!-- <div ref="myEchart" style="width:600px; height:550px;" id="main"></div> -->
	</div>
</template>

<script>

import echarts from "echarts";
import 'echarts/map/js/china'
export default {
	components: {},
	props: {},
	data () {
		return {
			imgLeft: "/fsk/static/img/screen-left.png",
			imgRight: "/fsk/static/img/screen-right.png",
		};
	},
	watch: {},
	computed: {},
	methods: {},
	created () { },
	mounted () {

		var data = [
			{
				name: '上海',
				value: 40498
			},
			{
				name: '嘉兴',
				value: 363
			}
		];
		var geoCoordMap = {
			"上海": [121.4648, 31.2891],
			"嘉兴": [120.760826,30.768932]
		};

		var convertData = function (data) {
			var res = [];
			for (var i = 0; i < data.length; i++) {
				var geoCoord = geoCoordMap[data[i].name];
				if (geoCoord) {
					res.push({
						name: data[i].name,
						value: geoCoord.concat(data[i].value)
					});
				}
			}
			return res;
		};
		// 基于准备好的dom，初始化echarts实例
		var myCustomerChart = echarts.init(document.getElementById('main'));
		var option = {
			backgroundColor: '#060715',
			// title: {
			// 	text: '全国客户分布图',
			// 	// left: 'center',
			// 	textStyle: {
			// 		//文字颜色
			// 		color: '#FFFFFF',
			// 		//字体系列
			// 		fontFamily: 'PingFang-SC-Medium',
			// 		//字体大小
			// 		fontSize: 16
			// 	}
			// },
			tooltip: {
				trigger: 'item',
				formatter: function (params) {
					return params.name + '<br/>' +
						params.seriesName + ": " + params.value[2]
				}
			},
			// legend: {
			// 	orient: 'vertical',
			// 	y: 'bottom',
			// 	x: 'right',
			// 	data: ['pm2.5'],
			// 	textStyle: {
			// 		color: '#fff'
			// 	}
			// },
			geo: {
				map: 'china',
				zoom: 1.2,
				label: {
					emphasis: {
						show: false
					}
				},
				roam: false, //是否允许缩放
				itemStyle: {
					normal: {
						areaColor: "#060715",
						borderColor: "#10BEFE"
					},
					emphasis: {
						areaColor: '#2a333d'
					}
				}
			},
			series: [{
				name: '客户数',
				type: 'scatter',
				coordinateSystem: 'geo',
				data: convertData(data),
				symbolSize: function (val) {
					return val[2] / 3000;
				},
				label: {
					normal: {
						formatter: '{b}',
						position: 'right',
						show: false
					},
					emphasis: {
						show: true
					}
				},
				itemStyle: {
					normal: {
						color: '#ddb926'
					}
				}
			},
			{
				name: '客户数',
				type: 'effectScatter',
				coordinateSystem: 'geo',
				data: convertData(data.sort(function (a, b) {
					return b.value - a.value;
				}).slice(0, 2)),
				symbolSize: function (val) {
					return val[2] / 3000;
				},
				showEffectOn: 'render',
				rippleEffect: {
					brushType: 'fill'
				},
				hoverAnimation: true,
				label: {
					normal: {
						formatter: '{b}',
						position: 'right',
						show: true
					}
				},
				itemStyle: {
					normal: {
						color: '#FF7A21',
						shadowBlur: 10,
						shadowColor: '#333'
					}
				},
				zlevel: 1
			}
			]

		}

		myCustomerChart.setOption(option);
	}

};
</script>
<style lang="scss" scoped>
.box {
	position: relative;
	width: 600px;
	// height: 470px;
	background-color: #060715;
	color: #fff;
	display: flex;
	justify-content: space-between;
	.screen-img {
		height: 100%;
		// background-color: rgb(7, 7, 39);
		img {
			width: 30px;
			height: 30px;
		}
	}
	.content-month {
		position: relative;
		flex: 1;
		background-color: #060715;
		p {
			color: #fff;
			margin: 10px 0 0 5px;
		}
		#main {
			width: 600px;
			height: 550px;
		}
	}
}
</style>