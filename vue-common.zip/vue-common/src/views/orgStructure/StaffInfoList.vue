<!--员工信息页面-->
<template>
  <div id="customerManage">
    <headTag :tagName="tagName" />

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="100px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model="filters.orgName"
                @focus="dialogVisible = true"
                @clear="clearStructure"
                placeholder="请选择组织"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="姓名" prop="staffFullName">
              <el-input size="mini" v-model.trim="filters.staffFullName" clearable placeholder="请输入姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="身份证号" prop="idCard">
              <el-input size="mini" v-model.trim="filters.idCard" clearable placeholder="请输入姓身份证号" maxlength="18"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="staffTel">
              <el-input size="mini" v-model.trim="filters.staffTel" clearable placeholder="请输入联系电话" maxlength="11"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="岗位" prop="positionName">
              <el-autocomplete
                :trigger-on-focus="true"
                v-model.trim="filters.positionName"
                size="mini"
                clearable
                :fetch-suggestions="queryPositionName"
                placeholder="请输入岗位"
                @select="selectPositionName"
                @clear="removePositionCode"
              ></el-autocomplete>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="星级" prop="staffGrade">
              <el-select v-model.trim="filters.staffGrade" size="mini" clearable placeholder="请选择星级">
                <el-option
                  v-for="item in staffGradeOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
             <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                type="primary"
                size="mini"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getStaffs(1)"
              >查询</el-button>
              <!-- <el-button size="mini" type="primary" icon="el-icon-menu" @click="handleAttendance">考勤</el-button> -->
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <div class="tablePanel">
        <!--列表-->
        <el-table
          :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
          size="mini"
          stripe
          :data="staffs"
          v-loading="listLoading"
          highlight-current-row
          element-loading-text="拼命加载中"
        >
          <el-table-column label="员工编号" min-width="110" prop="staffCode"></el-table-column>
          <el-table-column label="姓名" min-width="50" prop="staffFullName"></el-table-column>
          <el-table-column label="性别" min-width="40" prop="staffGenderValue"></el-table-column>
          <el-table-column label="身份证号" min-width="100" prop="idCard"></el-table-column>
          <el-table-column label="联系电话" min-width="80" prop="staffTel"></el-table-column>
          <el-table-column label="组织" min-width="150" prop="orgName"></el-table-column>
          <el-table-column label="岗位" min-width="100" prop="positionName"></el-table-column>
          <el-table-column label="在职状态" min-width="70" prop="workStatusValue"></el-table-column>
          <el-table-column label="星级" min-width="50" prop="staffGradeValue"></el-table-column>
          <el-table-column label="是否为管理者" min-width="100" prop="isManager"></el-table-column>
          <el-table-column fixed="right" width="100" label="操作">
            <template slot-scope="scope">
              <span>
              <el-button size="mini" type="text" @click="handleSee(scope.row)">查看</el-button>
              <el-button size="mini" type="text" @click="handleScheduling(scope.row)">排程</el-button>
              </span>
              <span>
              <el-button size="mini" type="text" @click="handleWorkOrderDetails(scope.row)">工单</el-button>
              </span>
            </template>
          </el-table-column>
        </el-table>

        <!--工具条-->
        <el-row class="pageToolbar">
          <el-col>
            <pagination
              v-if="totalCount>0"
              :total="totalCount"
              :page.sync="filters.pageNum"
              :limit.sync="filters.pageSize"
              @pagination="pageChange"
            ></pagination>
          </el-col>
        </el-row>

        <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
          <org-select v-on:listenTochildEvent="getCurrentNode" />
        </el-dialog>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import { findStaffList, findEhrPositionList } from "api/customerManagement";
import { findValueBySetCode } from "api/common";
import { changeYMD } from "utils";
export default {
  data() {
    return {
      tagName: "员工信息",
      //控制弹窗
      dialogVisible: false,
      //条件查询
      filters: {
        orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : "", 
        orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : "",
        staffFullName: "",
        idCard: "",
        quitStartTime: "",
        staffTel: "",
        staffGrade: "",
        selectSource: "2",
        positionCode: "",
        positionName: "",
        pageNum: 1,
        pageSize: 10
      },
      //去除部分在职状态
      zzStatus: ["20","30"],
      staffs: [],
      totalCount: 0,
      listLoading: false,
      searchLoading: false,
      //星级
      staffGradeOptions: [],
      //岗位选择
      position: []
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.getStaffs(val.page); //改变页码，重新渲染页面
    },
    //获取员工列表
    getStaffs(page) {
      this.filters.pageNum = page;
      var params = {
        pageNum:  page,
        pageSize: this.filters.pageSize,
        orgCode: this.filters.orgCode,
        orgName: this.filters.orgName,
        staffFullName: this.filters.staffFullName,
        idCard: this.filters.idCard,
        quitStartTime: this.filters.quitStartTime[0],
        quitEndTime: this.filters.quitStartTime[1],
        staffTel: this.filters.staffTel,
        staffGrade: this.filters.staffGrade,
        selectSource: this.filters.selectSource,
        positionCode: this.filters.positionCode,
        positionName: this.filters.positionName,
      };
      this.listLoading = true;
      this.searchLoading = true;
      // this.filters.pageNum = page
      findStaffList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffs = response.data.responseData;
            for (let i = 0; i < this.staffs.length; i++) {
              this.staffs[i].probationStartDate = changeYMD(
                this.staffs[i].probationStartDate
              );
              this.staffs[i].probationEndDate = changeYMD(
                this.staffs[i].probationEndDate
              );
              if (this.staffs[i].entryDate) {
                this.staffs[i].entryDate = changeYMD(
                  this.staffs[i].entryDate
                );
              }
              if (this.staffs[i].quitDate) {
                this.staffs[i].quitDate = changeYMD(
                  this.staffs[i].quitDate
                );
              }
            }
            this.totalCount = response.data.totalCount;
            this.listLoading = false;
            this.searchLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    //查看员工
    handleSee(row) {
      this.$router.push({
        path: "/orgManagement/editStaffInfo",
        query: {
          staffCode: row.staffCode
        }
      });
    },
    /**
     *
     * 模糊查询
     *
     */
    //岗位模糊查询
    selectPositionName(item) {
      if (item.value !== "无") {
        this.filters.positionName = item.value;
        this.filters.positionCode = item.code;
      } else {
        this.filters.positionName = "";
      }
    },
    removePositionCode() {
      this.filters.positionCode = "";
      this.filters.positionName = "";
    },
    queryPositionName(queryString, cb) {
      let params =  {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.position = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.position.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.position;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 查询条件开窗选择组织
     *
     */
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.filters.orgName = data.orgName;
      this.filters.orgCode = data.orgCode;
      this.handleClose();
    },
    clearStructure() {
      this.filters.orgCode = "";
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.orgName = this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '';
      this.filters.orgCode = this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '';
      this.filters.positionCode = "";
      this.getStaffs();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //员工星级
      findValueBySetCode({ valueSetCode: "STAFF_GRADE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGradeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    handleScheduling(row){
      this.$router.push({
        path: "/orgManagement/staffScheduling",
        query: {
          staffInfo: row,
          staffCode: row.staffCode
        }
      });
    },
    handleAttendance() {
      if(this.filters.orgName=="" || this.filters.orgCode==""){
        this.$message.error("请先选择组织");
        return;
      }
      this.$router.push({
        path: "/orgManagement/staffAttendance",
        query:{
          orgName:this.filters.orgName,
          orgCode:this.filters.orgCode
        }
      });
    },
    handleWorkOrderDetails(row){
       this.$router.push({
        path: "/orgManagement/workOrderDetails",
        query: {
          staffInfo:JSON.stringify(row),
        }
      });
    }
  },
  created() {
  },
  mounted(){
    //初始化数据字典
    this.initDataDictionary();
  },
  activated() {
    //初始化查询列表
    this.getStaffs();
  }
};
</script>

<style lang="scss" scoped>
#customerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item{
    margin-bottom: 0px;
  }
}
.search_btn {
  min-width: 250px;
  margin-left: 100px;
}
.form-item {
  width: 33%;
  min-width: 310px;
}
.tablePanel {
  padding: 20px 0px;
}
.formItem {
  width: 500px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
</style>