<template>
  <div id="orgManage">
    <headTag :tagName="tagName" />

    <div class="main-content">
      <el-row class="importToolbar">
        <el-col :span="24">
          <span class="form-tag">公司信息</span>
          <el-button size="mini" type="primary" @click="returnOrgStructure()" class="rightBtn">返回</el-button>
          <el-button
            type="primary"
            size="mini"
            @click="saveOrgStructure()"
            class="rightBtn"
            :loading="loadingBtn"
            v-if="flag"
          >保存</el-button>
          <el-button
            type="primary"
            size="mini"
            @click="editOrgStructure()"
            class="rightBtn"
            :loading="loadingBtn"
            v-if="!flag"
          >修改</el-button>
        </el-col>
        <el-col :span="24">
          <span class="upOrg">
            上级组织：
            <span v-if="orgForm.orgCode">{{orgForm.porgName}}</span>
            <span v-else>{{parentNode.orgName}}</span>
          </span>
        </el-col>
      </el-row>
      <el-row v-if="!isDepartment">
        <el-row>
          <el-form
            ref="orgForm"
            :inline="false"
            :model="orgForm"
            :rules="orgFormRules"
            label-width="150px"
            class="form-content"
          >
            <el-col class="form-item">
              <el-form-item label="组织类型" prop="orgType">
                <span v-if="isEdit == false"><!--isEdit == false 组织类型不允许修改 04201-->
                  <span v-if="orgForm.orgType != '10'">{{orgForm.orgTypeValue}}</span>
                  <span v-else>总公司</span>
                </span>
                <span v-if="isEdit == true"><!--isEdit == true 组织类型不允许修改-->
                  <span v-if="orgForm.orgType != '10'">
                    <el-select
                      v-model="orgForm.orgType"
                      size="mini"
                      clearable
                      placeholder="请选择组织类型"
                      @change="changeOrgForm"
                      v-if="tagName=='新增下级'"
                    >
                      <el-option
                        v-for="item in orgTypeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                    <span v-if="tagName!=='新增下级'">{{orgForm.orgTypeValue}}</span>
                  </span>
                  <span v-else>总公司</span>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="组织名称" prop="orgName">
                <span v-if="isEdit == false" class="long-field">{{orgForm.orgName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.orgName"
                    size="mini"
                    clearable
                    placeholder="请输入组织名称"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="组织简称">
                <span v-if="isEdit == false">{{orgForm.orgShortName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.orgShortName"
                    size="mini"
                    clearable
                    placeholder="请输入组织简称"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="状态" prop="orgStatus">
                <span v-if="isEdit == false">{{orgForm.orgStatusValue}}</span>
                <span v-if="isEdit == true">
                  <el-select v-model="orgForm.orgStatus" size="mini" clearable placeholder="请选择状态">
                    <el-option
                      v-for="item in orgStatusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="所在地区" prop="orgProvinceName">
                <span v-if="isEdit == false">
                  <span class="long-field"
                    v-if="orgForm.orgProvinceName"
                  >{{orgForm.orgProvinceName}}/{{orgForm.orgCityName}}/{{orgForm.orgDistrictName}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-cascader
                    v-model="orgs"
                    placeholder="请选择所在地区"
                    size="mini"
                    :options="orgsOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeOrg"
                    @change="addOrgToForm"
                    @visible-change="changeOrg"
                    ref="orgList"
                    :props="{
                    value: 'id',
                    label: 'name',
                    children: 'cities'
                  }"
                  ></el-cascader>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="详细地址" prop="orgAddress">
                <span v-if="isEdit == false" class="long-field">{{orgForm.orgAddress}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.orgAddress"
                    size="mini"
                    clearable
                    placeholder="请输入详细地址"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>

            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="证照名称">
                <span v-if="isEdit == false">{{orgForm.certificateName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.certificateName"
                    size="mini"
                    clearable
                    placeholder="请输入证照名称"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>

            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="联系人">
                <span v-if="isEdit == false">{{orgForm.contactsName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.contactsName"
                    size="mini"
                    clearable
                    placeholder="请输入联系人"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="联系电话" prop="contactsTel">
                <span v-if="isEdit == false">{{orgForm.contactsTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.contactsTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系电话"
                    maxlength="11"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="注册地址" prop="registerAddress">
                <span v-if="isEdit == false" class="long-field">{{orgForm.registerAddress}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.registerAddress"
                    size="mini"
                    clearable
                    placeholder="请输入注册地址"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="发证日期">
                <span v-if="isEdit == false">{{orgForm.certificateDate}}</span>
                <span v-if="isEdit == true">
                  <el-date-picker
                    v-model="orgForm.certificateDate"
                    size="mini"
                    clearable
                    value-format="yyyy-MM-dd"
                    type="date"
                    placeholder="请选择发证日期"
                  ></el-date-picker>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="公司类型">
                <span v-if="isEdit == false">{{orgForm.companyType}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.companyType"
                    size="mini"
                    clearable
                    placeholder="请输入公司类型"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="注册资本" prop="registerCapital">
                <span v-if="isEdit == false">
                  <span v-if="orgForm.registerCapital">{{orgForm.registerCapital}}万</span>
                </span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.registerCapital"
                    size="mini"
                    clearable
                    placeholder="请输入注册资本"
                    maxlength="12"
                  >
                    <template slot="append">万</template>
                  </el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="有效日期">
                <span v-if="isEdit == false">
                  <span
                    v-if="orgForm.validStartDate"
                  >{{orgForm.validStartDate}}---{{orgForm.validEndDate}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-date-picker
                    v-model="orgForm.effectiveDate"
                    size="mini"
                    clearable
                    value-format="yyyy-MM-dd"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    @blur="changeValidDuration"
                  ></el-date-picker>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="有效期限">
                <span v-if="isEdit == false">
                  <span v-if="orgForm.validDuration">{{orgForm.validDuration}}年</span>
                </span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.validDuration"
                    size="mini"
                    placeholder="请输入有效期限"
                    :disabled="true"
                  >
                    <template slot="append">年</template>
                  </el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="邮箱" prop="orgEmail">
                <span v-if="isEdit == false" class="long-field">{{orgForm.orgEmail}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.orgEmail"
                    size="mini"
                    clearable
                    placeholder="请输入邮箱"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="统一信用代码">
                <span v-if="isEdit == false" class="long-field">{{orgForm.orgCreditCode}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.orgCreditCode"
                    size="mini"
                    clearable
                    placeholder="请输入统一信用代码"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="发证机关">
                <span v-if="isEdit == false">{{orgForm.certificateOffice}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.certificateOffice"
                    size="mini"
                    clearable
                    placeholder="请输入发证机关"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="法人代表">
                <span v-if="isEdit == false">{{orgForm.legalRepresentative}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orgForm.legalRepresentative"
                    size="mini"
                    clearable
                    placeholder="请输入法人代表"
                    maxlength="50"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="经营范围">
                <span v-if="isEdit == false" class="long-field">{{orgForm.businessScope}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    type="textarea"
                    class="remark-style"
                    v-model="orgForm.businessScope"
                    size="mini"
                    clearable
                    placeholder="请输入经营范围"
                    maxlength="100"
                    show-word-limit
                    resize="none"
                    rows="4"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="备注">
                <span v-if="isEdit == false" class="long-field">{{orgForm.remark}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    type="textarea"
                    class="remark-style"
                    v-model="orgForm.remark"
                    size="mini"
                    clearable
                    placeholder="请输入备注"
                    maxlength="100"
                    show-word-limit
                    resize="none"
                    rows="4"
                  ></el-input>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="附件">
                <span v-if="isEdit == false">
                  <span v-if="AFUFileList.length>0">
                    <el-col v-for="(item,index) of AFUFileList" :key="index">
                      <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                        {{item.name}}
                        <i class="el-icon-view"></i>
                      </el-link>
                    </el-col>
                  </span>
                </span>
                <span v-if="isEdit == true">
                  <file-upload
                    :multiple="false"
                    :limit="10"
                    :action="actionUrl"
                    :file-list="AFUFileList"
                    @handleGetUrl="getAFUUrl"
                    @handleRemoveList="removeAFUList"
                  ></file-upload>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="调档材料上传">
                <span v-if="isEdit == false">
                  <span v-if="IFUFileList.length>0">
                    <el-col v-for="(item,index) of IFUFileList" :key="index">
                      <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                        {{item.name}}
                        <i class="el-icon-view"></i>
                      </el-link>
                    </el-col>
                  </span>
                </span>
                <span v-if="isEdit == true">
                  <file-upload
                    :multiple="false"
                    :limit="10"
                    :action="actionUrl"
                    :file-list="IFUFileList"
                    @handleGetUrl="getIFUUrl"
                    @handleRemoveList="removeIFUList"
                  ></file-upload>
                </span>
              </el-form-item>
              </span>
            </el-col>
            <el-col class="form-item">
              <span v-if="isdefaultShow == true">
              <el-form-item label="授权委托书上传">
                <span v-if="isEdit == false">
                  <span v-if="EFUFileList.length>0">
                    <el-col v-for="(item,index) of EFUFileList" :key="index">
                      <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                        {{item.name}}
                        <i class="el-icon-view"></i>
                      </el-link>
                    </el-col>
                  </span>
                </span>
                <span v-if="isEdit == true">
                  <file-upload
                    :multiple="false"
                    :limit="10"
                    :action="actionUrl"
                    :file-list="EFUFileList"
                    @handleGetUrl="getEFUUrl"
                    @handleRemoveList="removeEFUList"
                  ></file-upload>
                </span>
              </el-form-item>
              </span>
            </el-col>
          </el-form>
        </el-row>
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">信息变更</span>
            <el-button
              size="mini"
              type="primary"
              icon="el-icon-plus"
              class="rightBtn"
              @click="addInfoForm('infoForm')"
            >新增</el-button>
          </el-col>
        </el-row>
        <el-row>
          <el-form :rules="infoForm.rules" :model="infoForm" ref="infoForm">
            <el-table
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
              size="mini"
              stripe
              :data="infoForm.tableData"
              v-loading="infoListLoading"
              highlight-current-row
              element-loading-text="拼命加载中"
              class="tableMain"
            >
              <el-table-column prop="changeDate" label="变更时间" min-width="220px">
                <template slot-scope="scope">
                  <div v-if="!scope.row.editing">
                    <span>{{ scope.row.changeDate }}</span>
                  </div>
                  <div v-else>
                    <el-form-item
                      :prop="'tableData.' + scope.$index + '.changeDate'"
                      :rules="infoForm.rules.changeDate"
                    >
                      <el-form-item :prop="'tableData.' + scope.$index + '.changeDate'">
                        <el-date-picker
                          v-model="scope.row.changeDate"
                          clearable
                          size="mini"
                          value-format="yyyy-MM-dd"
                          type="date"
                          placeholder="选择日期"
                        ></el-date-picker>
                      </el-form-item>
                    </el-form-item>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="changeReason" label="变更事由" min-width="220px">
                <template slot-scope="scope">
                  <div v-if="!scope.row.editing">
                    <span>{{ scope.row.changeReason }}</span>
                  </div>
                  <div v-else>
                    <el-form-item
                      :prop="'tableData.' + scope.$index + '.changeReason'"
                      :rules="infoForm.rules.changeReason"
                    >
                      <el-input
                        v-model="scope.row.changeReason"
                        clearable
                        size="mini"
                        placeholder="请输入变更事由"
                      ></el-input>
                    </el-form-item>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="changeInfo" label="变更信息" min-width="220px">
                <template slot-scope="scope">
                  <div v-if="!scope.row.editing">
                    <span>{{ scope.row.changeInfo }}</span>
                  </div>
                  <div v-else>
                    <el-form-item
                      :prop="'tableData.' + scope.$index + '.changeInfo'"
                      :rules="infoForm.rules.changeInfo"
                    >
                      <el-input
                        v-model="scope.row.changeInfo"
                        clearable
                        size="mini"
                        placeholder="请输入变更信息"
                      ></el-input>
                    </el-form-item>
                  </div>
                </template>
              </el-table-column>
              <el-table-column fixed="right" width="200px" label="操作">
                <template slot-scope="scope">
                  <div class="operate-groups">
                    <el-button
                      type="primary"
                      size="mini"
                      v-if="!scope.row.editing"
                      icon="el-icon-edit-outline"
                      @click="handleEditInfoForm(scope.$index, scope.row)"
                    >编辑</el-button>
                    <el-button
                      type="primary"
                      size="mini"
                      v-if="scope.row.editing"
                      icon="el-icon-success"
                      @click="handleSaveInfoForm(scope.$index, scope.row, 'infoForm')"
                    >保存</el-button>
                    <el-button
                      size="mini"
                      type="danger"
                      icon="el-icon-delete"
                      @click="handleDeleteInfoForm(scope.$index, scope.row)"
                    >删除</el-button>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </el-form>
        </el-row>
      </el-row>
      <el-row v-if="isDepartment">
        <el-form
          ref="deptForm"
          :inline="false"
          :model="deptForm"
          :rules="deptFormRules"
          label-width="150px"
          class="form-content"
        >
          <el-col class="form-item">
            <el-form-item label="组织类型" prop="orgType">
              <span v-if="isEdit == false"><!--isEdit == false 组织类型不允许修改 04201-->
                <span v-if="deptForm.orgType != '10'">{{deptForm.orgTypeValue}}</span>
                <span v-else>总公司</span>
              </span>
              <span v-if="isEdit == true"><!--isEdit == true 组织类型不允许修改 04201-->
                <span v-if="deptForm.orgType != '10'">
                  <el-select
                    v-model="deptForm.orgType"
                    size="mini"
                    clearable
                    placeholder="请选择组织类型"
                    @change="changeDeptForm"
                    v-if="tagName=='新增下级'"
                  >
                    <el-option
                      v-for="item in orgTypeOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                  <span v-if="tagName!=='新增下级'">{{orgForm.orgTypeValue}}</span>
                </span>
                <span v-else>总公司</span>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="组织名称" prop="orgName">
              <span v-if="isEdit == false">{{deptForm.orgName}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.orgName"
                  size="mini"
                  clearable
                  placeholder="请输入组织名称"
                  maxlength="50"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="组织简称">
              <span v-if="isEdit == false">{{deptForm.orgShortName}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.orgShortName"
                  size="mini"
                  clearable
                  placeholder="请输入组织简称"
                  maxlength="50"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="状态" prop="orgStatus">
              <span v-if="isEdit == false">{{deptForm.orgStatusValue}}</span>
              <span v-if="isEdit == true">
                <el-select v-model="deptForm.orgStatus" size="mini" clearable placeholder="请选择状态">
                  <el-option
                    v-for="item in orgStatusOptions"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="所在地区" prop="orgProvinceName">
              <span v-if="isEdit == false">
                <span class="long-field"
                  v-if="deptForm.orgProvinceName"
                >{{deptForm.orgProvinceName}}/{{deptForm.orgCityName}}/{{deptForm.orgDistrictName}}</span>
              </span>
              <span v-if="isEdit == true">
                <el-cascader
                  v-model="depts"
                  placeholder="请选择所在地区"
                  size="mini"
                  :options="deptsOptions"
                  :show-all-levels="false"
                  @active-item-change="handleExpandChangeDept"
                  @change="addDeptToForm"
                  @visible-change="changeDept"
                  ref="deptList"
                  :props="{
                    value: 'id',
                    label: 'name',
                    children: 'cities'
                  }"
                ></el-cascader>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="详细地址" prop="orgAddress">
              <span v-if="isEdit == false" class="long-field">{{deptForm.orgAddress}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.orgAddress"
                  size="mini"
                  clearable
                  placeholder="请输入详细地址"
                  maxlength="50"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系人">
              <span v-if="isEdit == false">{{deptForm.contactsName}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.contactsName"
                  size="mini"
                  clearable
                  placeholder="请输入联系人"
                  maxlength="50"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="contactsTel">
              <span v-if="isEdit == false">{{deptForm.contactsTel}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.contactsTel"
                  size="mini"
                  clearable
                  placeholder="请输入联系电话"
                  maxlength="11"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="邮箱" prop="orgEmail">
              <span v-if="isEdit == false" class="long-field">{{deptForm.orgEmail}}</span>
              <span v-if="isEdit == true">
                <el-input
                  v-model="deptForm.orgEmail"
                  size="mini"
                  clearable
                  placeholder="请输入邮箱"
                  maxlength="50"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="附件">
              <span v-if="isEdit == false">
                <span v-if="AFUDFileList.length>0">
                  <el-col v-for="(item,index) of AFUDFileList" :key="index">
                    <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                      {{item.name}}
                      <i class="el-icon-view"></i>
                    </el-link>
                  </el-col>
                </span>
              </span>
              <span v-if="isEdit == true">
                <file-upload
                  :multiple="false"
                  :limit="10"
                  :action="actionUrl"
                  :file-list="AFUDFileList"
                  @handleGetUrl="getAFUDFUrl"
                  @handleRemoveList="removeAFUDFList"
                ></file-upload>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注">
              <span v-if="isEdit == false" class="long-field">{{deptForm.remark}}</span>
              <span v-if="isEdit == true">
                <el-input
                  type="textarea"
                  class="remark-style"
                  v-model="deptForm.remark"
                  size="mini"
                  clearable
                  placeholder="请输入备注"
                  maxlength="100"
                  show-word-limit
                  resize="none"
                  rows="4"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import FileUpload from "components/FileUpload";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail,
  isRegisterCapital
} from "@/utils/validate";
import {
  insertEhrOrg,
  editEhrOrg,
  getEhrOrgDetailByCode,
  findEhrOrgChangeRecordList,
  insertEhrOrgChangeRecord,
  editEhrOrgChangeRecord,
  deleteEhrOrgChangeRecord
} from "api/orgStructure";
export default {
  data() {
    return {
      tagName: "新增下级",
      //是否可编辑模式
      isEdit: true,
      isdefaultShow: false,
      //是否是部门组
      isDepartment: false,
      //按钮加载
      loadingBtn: false,
      //保存/修改按钮的状态
      flag: true,
      //总公司/子公司/分公司/护理站
      orgGroup: ["10", "20", "30", "40"],
      //长照/日托/部门/组
      deptGroup: ["50", "60", "70", "80"],
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",

      /*
       *
       * 公司信息Form
       * 总公司/子公司/分公司/护理站
       * 验证
       *
       *
       */
      orgForm: {
        orgCode: "",
        orgType: "",
        orgName: "",
        orgShortName: "",
        orgStatus: "10",
        orgProvinceName: "",
        orgAddress: "",
        registerAddress: "",
        orgEmail: "",
        orgCreditCode: "",
        validStartDate: "",
        validDuration: "",
        certificateDate: "",
        certificateOffice: "",
        businessScope: "",
        registerCapital: "",
        legalRepresentative: "",
        companyType: "",
        contactsName: "",
        contactsTel: "",
        investigationFileUrl: "",
        empowerFileUrl: "",
        appendFileUrl: "",
        remark: ""
      },
      //验证
      orgFormRules: {
        orgType: [
          {
            required: true,
            message: "请选择组织类型",
            trigger: "change"
          }
        ],
        orgName: [
          {
            required: true,
            message: "请输入组织名称",
            trigger: "blur"
          }
        ],
        orgStatus: [
          {
            required: true,
            message: "请选择状态",
            trigger: "change"
          }
        ],
        orgAddress: [
          {
            required: true,
            message: "请输入详细地址",
            trigger: "blur"
          }
        ],
        orgProvinceName: [
          {
            required: true,
            message: "请选择所在地区",
            trigger: "change"
          }
        ],
        registerAddress: [
          {
            required: true,
            message: "请输入注册地址",
            trigger: "blur"
          }
        ],
        orgEmail: [
          {
            validator: validateEmail
          }
        ],
        contactsTel: [
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        registerCapital: [
          {
            validator: isRegisterCapital
          }
        ]
      },
      //调档材料上传
      IFUFileList: [],
      //附件材料上传
      AFUFileList: [],
      //授权材料上传
      EFUFileList: [],
      //动态加载组织省市区
      orgsOptions: [],
      orgs: [],
      orgsName: [],
      /*
       *
       * 变更信息
       * 验证
       *
       *
       */
      infoForm: {
        //验证
        rules: {
          changeDate: [
            {
              required: true,
              message: "请选择变更时间",
              trigger: "blur"
            }
          ],
          changeReason: [
            {
              required: true,
              message: "请输入变更事由",
              trigger: "blur"
            }
          ],
          changeInfo: [
            {
              required: true,
              message: "请输入变更信息",
              trigger: "blur"
            }
          ]
        },
        tableData: [
          {
            changeDate: null,
            changeReason: null,
            changeInfo: null
          }
        ]
      },
      infoListLoading: false,
      /*
       *
       * 部门信息Form
       * 长照/日托/部门/组
       * 验证
       *
       *
       */
      deptForm: {
        orgCode: "",
        orgType: "",
        orgName: "",
        orgShortName: "",
        orgProvinceName: "",
        orgAddress: "",
        contactsName: "",
        contactsTel: "",
        orgEmail: "",
        orgStatus: "10",
        appendFileUrl: "",
        remark: ""
      },
      //验证
      deptFormRules: {
        orgType: [
          {
            required: true,
            message: "请选择组织类型",
            trigger: "change"
          }
        ],
        orgName: [
          {
            required: true,
            message: "请输入组织名称",
            trigger: "blur"
          }
        ],
        orgStatus: [
          {
            required: true,
            message: "请选择状态",
            trigger: "change"
          }
        ],
        orgAddress: [
          {
            required: true,
            message: "请输入详细地址",
            trigger: "blur"
          }
        ],
        orgProvinceName: [
          {
            required: true,
            message: "请选择所在地区",
            trigger: "change"
          }
        ],
        orgEmail: [
          {
            validate: validateEmail
          }
        ],
        contactsTel: [
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ]
      },
      //附件材料上传
      AFUDFileList: [],
      //动态加载组织省市区
      deptsOptions: [],
      depts: [],
      deptsName: [],
      /*
       *
       * 选择下拉框
       *
       */
      //组织类型
      orgTypeOptions: [],
      //状态
      orgStatusOptions: [],
      /**
       *
       * 页面传参
       *
       */
      parentNode: [],
      status: ""
    };
  },
  components: {
    HeadTag,
    FileUpload
  },
  methods: {
    /**
     *
     * 组织机构信息保存
     * 分公司/子公司/护理站
     * 长照/日托/部门/组
     *
     */
    saveOrgStructure() {
      if (this.deptGroup.indexOf(this.orgForm.orgType) != -1) {
        this.$refs.deptForm.validate(valid => {
          if (valid) {
            this.loadingBtn = true;
            if (this.deptForm.orgCode) {
              editEhrOrg(this.deptForm)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    this.$message.success("修改成功");
                    this.getEhrOrgDetailByCode(this.deptForm.orgCode);
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                  } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrOrg:" + error);
                  this.loadingBtn = false;
                  return false;
                });
            } else {
              this.deptForm.orgPcode = this.parentNode.orgCode;
              this.deptForm.orgPcodes = this.parentNode.orgPcodes;
              insertEhrOrg(this.deptForm)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    this.$message.success("新增成功");
                    this.getEhrOrgDetailByCode(response.data.responseData);
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                  } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrOrg:" + error);
                  this.loadingBtn = false;
                  return false;
                });
            }
          } else {
            this.$message.error("请检查是否填写完整");
            return false;
          }
        });
      } else {
        this.$refs.orgForm.validate(valid => {
          if (valid) {
            this.loadingBtn = true;
            if (this.orgForm.effectiveDate != null) {
              this.orgForm.validStartDate = this.orgForm.effectiveDate[0];
              this.orgForm.validEndDate = this.orgForm.effectiveDate[1];
            }
            if (this.orgForm.orgCode) {
              editEhrOrg(this.orgForm)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    this.$message.success("修改成功");
                    this.getEhrOrgDetailByCode(this.orgForm.orgCode);
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                  } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrOrg:" + error);
                  this.loadingBtn = false;
                  return false;
                });
            } else {
              this.orgForm.orgPcode = this.parentNode.orgCode;
              this.orgForm.orgPcodes = this.parentNode.orgPcodes;
              insertEhrOrg(this.orgForm)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    this.$message.success("新增成功");
                    this.getEhrOrgDetailByCode(response.data.responseData);
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                  } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrOrg:" + error);
                  this.loadingBtn = false;
                  return false;
                });
            }
          } else {
            this.$message.error("请检查是否填写完整");
            return false;
          }
        });
      }
    },
    //根据code加载组织信息
    getEhrOrgDetailByCode(code) {
      this.IFUFileList = [];
      this.AFUFileList = [];
      this.EFUFileList = [];
      this.AFUDFileList = [];
      var params = {
        orgCode: code
      };
      getEhrOrgDetailByCode(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.orgForm = response.data.responseData;
            this.deptForm = response.data.responseData;
            if (this.deptGroup.indexOf(this.orgForm.orgType) != -1) {
              if (this.deptForm.appendFileUrl) {
                let obj = this.deptForm.appendFileUrl;
                let temp = obj.split(",");
                for (let i = 0; i < temp.length; i++) {
                  let url = temp[i];
                  this.AFUDFileList.push({
                    url: url,
                    name: decodeURI(url)
                      .toString()
                      .split("com/")[1]
                      .split("?Expires")[0]
                      .substr(18)
                  });
                } 
              }
              if (typeof this.$refs["deptList"] == "undefined") {
                return false;
              } else {
                this.$refs[
                  "deptList"
                ].inputValue = this.deptForm.orgDistrictName;
              }
            } else {
              if (this.orgForm.investigationFileUrl) {
                let IFUFile = this.orgForm.investigationFileUrl;
                let tempInvestigation = IFUFile.split(",");
                for (let i = 0; i < tempInvestigation.length; i++) {
                  let url = tempInvestigation[i];
                  this.IFUFileList.push({
                    url: url,
                    name: decodeURI(url)
                      .toString()
                      .split("com/")[1]
                      .split("?Expires")[0]
                      .substr(18)
                  });
                }
              }
              if (this.orgForm.appendFileUrl) {
                let AFUFile = this.orgForm.appendFileUrl;
                let tempAppend = AFUFile.split(",");
                for (let i = 0; i < tempAppend.length; i++) {
                  let url = tempAppend[i];
                  this.AFUFileList.push({
                    url: url,
                    name: decodeURI(url)
                      .toString()
                      .split("com/")[1]
                      .split("?Expires")[0]
                      .substr(18)
                  });
                }
              }
              if (this.orgForm.empowerFileUrl) {
                let EFUFile = this.orgForm.empowerFileUrl;
                let tempEmpower = EFUFile.split(",");
                for (let i = 0; i < tempEmpower.length; i++) {
                  let url = tempEmpower[i];
                  this.EFUFileList.push({
                    url: url,
                    name: decodeURI(url)
                      .toString()
                      .split("com/")[1]
                      .split("?Expires")[0]
                      .substr(18)
                  });
                }
              }
              if (this.orgForm.validStartDate) {
                this.orgForm.effectiveDate = [];
                this.orgForm.effectiveDate[0] = changeYMD(
                  this.orgForm.validStartDate
                );
                this.orgForm.effectiveDate[1] = changeYMD(
                  this.orgForm.validEndDate
                );
                this.orgForm.validStartDate = changeYMD(
                  this.orgForm.validStartDate
                );
                this.orgForm.validEndDate = changeYMD(
                  this.orgForm.validEndDate
                );
              }

              if (this.orgForm.certificateDate) {
                this.orgForm.certificateDate = changeYMD(
                  this.orgForm.certificateDate
                );
              }

              if (typeof this.$refs["orgList"] == "undefined") {
                return false;
              } else {
                this.$refs["orgList"].inputValue = this.orgForm.orgDistrictName;
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getEhrOrgDetailByCode:" + error);
          return false;
        });
    },
    /**
     *
     * 公司信息调档材料
     *
     */
    //调档材料上传限制
    getIFUUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let investigationFileUrl = "";
        urls.forEach(items => {
          investigationFileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (investigationFileUrl.length > 0) {
          investigationFileUrl = investigationFileUrl.substr(
            0,
            investigationFileUrl.length - 1
          );
        }
        this.orgForm.investigationFileUrl = investigationFileUrl;
      }
    },
    //删除文件
    removeIFUList(file, inputFileMainList) {
      let fileList = this.IFUFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1);
      let investigationFileUrl = "";
      this.IFUFileList.map(items => {
        investigationFileUrl += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (investigationFileUrl.length > 0) {
        investigationFileUrl = investigationFileUrl.substr(
          0,
          investigationFileUrl.length - 1
        );
      }
      this.orgForm.investigationFileUrl = investigationFileUrl;
    },
    /**
     *
     * 公司信息附件材料
     *
     */
    //获取回传URL
    getAFUUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let appendFileUrl = "";
        urls.forEach(items => {
          appendFileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (appendFileUrl.length > 0) {
          appendFileUrl = appendFileUrl.substr(0, appendFileUrl.length - 1);
        }
        this.orgForm.appendFileUrl = appendFileUrl;
      }
    },
    //删除文件
    removeAFUList(file, inputFileMainList) {
      let fileList = this.AFUFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1);
      let appendFileUrl = "";
      this.AFUFileList.map(items => {
        appendFileUrl += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (appendFileUrl.length > 0) {
        appendFileUrl = appendFileUrl.substr(0, appendFileUrl.length - 1);
      }
      this.orgForm.appendFileUrl = appendFileUrl;
    },
    /**
     *
     * 公司信息授权材料
     *
     */
    //获取回传URL
    getEFUUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let empowerFileUrl = "";
        urls.forEach(items => {
          empowerFileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (empowerFileUrl.length > 0) {
          empowerFileUrl = empowerFileUrl.substr(0, empowerFileUrl.length - 1);
        }
        this.orgForm.empowerFileUrl = empowerFileUrl;
      }
    },
    //删除文件
    removeEFUList(file, inputFileMainList) {
      console.log(file, inputFileMainList);
      let fileList = this.EFUFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1);
      let empowerFileUrl = "";
      this.EFUFileList.map(items => {
        empowerFileUrl += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (empowerFileUrl.length > 0) {
        empowerFileUrl = empowerFileUrl.substr(0, empowerFileUrl.length - 1);
      }
      this.orgForm.empowerFileUrl = empowerFileUrl;
    },
    //加载组织省市区
    getOrgNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.orgsOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.orgsOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.orgsOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //组织省市区选择下拉框
    handleExpandChangeOrg(val) {
      this.getOrgNodes(val);
    },
    //将组织省市区注入到Form中
    addOrgToForm(val) {
      this.orgs = val;
      this.orgsName = this.$refs["orgList"].getCheckedNodes();
      this.orgForm.orgProvinceCode = this.orgs[0];
      this.orgForm.orgProvinceName = this.orgsName[0].pathLabels[0];
      this.orgForm.orgCityCode = this.orgs[1];
      this.orgForm.orgCityName = this.orgsName[0].pathLabels[1];
      this.orgForm.orgDistrictCode = this.orgs[2];
      this.orgForm.orgDistrictName = this.orgsName[0].pathLabels[2];
    },
    changeOrg(val) {
      this.$refs["orgList"].presentText = "";
      if (!val) {
        this.$refs["orgList"].inputValue = this.orgForm.orgDistrictName;
        this.$refs["orgList"].presentText = this.orgForm.orgDistrictName;
      }
    },
    //根据有效日期计算有效期限
    changeValidDuration() {
      if (this.orgForm.effectiveDate != null) {
        var start = this.orgForm.effectiveDate[0].split("-");
        var startDate = new Date(start[0], start[1], start[2]);
        var end = this.orgForm.effectiveDate[1].split("-");
        var endDate = new Date(end[0], end[1], end[2]);
        var iDays = parseInt(
          Math.abs(endDate - startDate) / 1000 / 60 / 60 / 24
        ); //把相差的毫秒数转换为天数
        this.orgForm.validDuration = (iDays / 365).toFixed(1);
      }
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editOrgStructure() {
      this.isEdit = true;
      this.flag = true;
      this.getEhrOrgDetailByCode(this.orgForm.orgCode);
    },
    /**
     *
     * 变更信息列表操作
     *
     */
    // 查询当前组织变更信息
    findEhrOrgChangeRecordList(code) {
      var params = {
        orgCode: code
      };
      this.infoListLoading = true;
      findEhrOrgChangeRecordList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.infoForm.tableData = response.data.responseData;
            for (let i = 0; i < this.infoForm.tableData.length; i++) {
              this.infoForm.tableData[i].changeDate = changeYMD(
                this.infoForm.tableData[i].changeDate
              );
            }
            this.infoListLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.infoListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgChangeRecordList:" + error);
          this.infoListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditInfoForm($index, row) {
      this.$set(this.infoForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveInfoForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.infoForm.tableData[$index].id) {
            var params = {
              orgCode: this.parentNode.orgCode,
              id: this.infoForm.tableData[$index].id,
              changeDate: this.infoForm.tableData[$index].changeDate,
              changeInfo: this.infoForm.tableData[$index].changeInfo,
              changeReason: this.infoForm.tableData[$index].changeReason
            };
            this.infoListLoading = true;
            editEhrOrgChangeRecord(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.findEhrOrgChangeRecordList(this.parentNode.orgCode);
                  this.infoListLoading = false;
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  this.infoListLoading = false;
                  return false;
                }
              })
              .catch(error => {
                console.log("editEhrOrgChangeRecord:" + error);
                this.infoListLoading = false;
                return false;
              });
          } else {
            var params = {
              orgCode: this.parentNode.orgCode,
              changeDate: this.infoForm.tableData[$index].changeDate,
              changeInfo: this.infoForm.tableData[$index].changeInfo,
              changeReason: this.infoForm.tableData[$index].changeReason
            };
            this.infoListLoading = true;
            insertEhrOrgChangeRecord(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.findEhrOrgChangeRecordList(this.parentNode.orgCode);
                  this.infoListLoading = false;
                  this.$message.success("保存成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  this.infoListLoading = false;
                  return false;
                }
              })
              .catch(error => {
                console.log("insertEhrOrgChangeRecord:" + error);
                this.infoListLoading = false;
                return false;
              });
          }
          // this.$set(this.infoForm.tableData[$index], "editing", false);
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条变更信息数据
    addInfoForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.orgForm.orgCode) {
            this.infoForm.tableData = this.infoForm.tableData || [];
            this.infoForm.tableData.push({
              changeDate: null,
              changeReason: null,
              changeInfo: null,
              editing: true
            });
          } else {
            this.$message.error("请先保存公司信息后再操作");
            return false;
          }
        }
      });
    },
    // 删除
    handleDeleteInfoForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.infoForm.tableData[$index].id) {
            var params = {
              orgCode: this.parentNode.orgCode,
              id: this.infoForm.tableData[$index].id
            };
            deleteEhrOrgChangeRecord(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.infoForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteEhrOrgChangeRecord:" + error);
                return false;
              });
          } else {
            this.infoForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    /**
     *
     * 部门信息保存
     * 长照/日托/部门/组
     *
     */
    /**
     *
     * 部门信息附件材料
     *
     */
    //获取回传URL
    getAFUDFUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let appendFileUrl = "";
        urls.forEach(items => {
          appendFileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (appendFileUrl.length > 0) {
          appendFileUrl = appendFileUrl.substr(0, appendFileUrl.length - 1);
        }
        this.deptForm.appendFileUrl = appendFileUrl;
      }
    },
    //删除文件
    removeAFUDFList(file, inputFileMainList) {
      console.log(file, inputFileMainList);
      let fileList = this.AFUDFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1);
      let appendFileUrl = "";
      this.AFUDFileList.map(items => {
        appendFileUrl += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (appendFileUrl.length > 0) {
        appendFileUrl = appendFileUrl.substr(0, appendFileUrl.length - 1);
      }
      this.orgForm.appendFileUrl = appendFileUrl;
    },

    //加载部门省市区
    getDeptNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.deptsOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.deptsOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.deptsOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //组织省市区选择下拉框
    handleExpandChangeDept(val) {
      this.getDeptNodes(val);
    },
    //将组织省市区注入到Form中
    addDeptToForm(val) {
      this.depts = val;
      this.deptsName = this.$refs["deptList"].getCheckedNodes();
      this.deptForm.orgProvinceCode = this.depts[0];
      this.deptForm.orgProvinceName = this.deptsName[0].pathLabels[0];
      this.deptForm.orgCityCode = this.depts[1];
      this.deptForm.orgCityName = this.deptsName[0].pathLabels[1];
      this.deptForm.orgDistrictCode = this.depts[2];
      this.deptForm.orgDistrictName = this.deptsName[0].pathLabels[2];
    },
    changeDept(val) {
      this.$refs["deptList"].presentText = "";
      if (!val) {
        this.$refs["deptList"].inputValue = this.deptForm.orgDistrictName;
        this.$refs["deptList"].presentText = this.deptForm.orgDistrictName;
      }
    },
    /**
     *
     * 根据组织类型更换Form表单
     *
     */
    changeOrgForm(code) {
      this.isdefaultShow = true;
      if (this.deptGroup.indexOf(code) != -1) {
        this.isDepartment = true;
        this.deptForm.orgType = code;
        this.$nextTick(() => {
          if (typeof this.$refs["deptList"] == "undefined") {
            return false;
          } else {
            this.$refs["deptList"].inputValue = this.deptForm.orgDistrictName;
          }
        });
      } else {
        this.orgForm.orgType = code;
        this.$nextTick(() => {
          if (typeof this.$refs["orgList"] == "undefined") {
            return false;
          } else {
            this.$refs["orgList"].inputValue = this.orgForm.orgDistrictName;
          }
        });
      }
    },
    changeDeptForm(code) {
      if (this.orgGroup.indexOf(code) != -1) {
        this.isDepartment = false;
        this.orgForm.orgType = code;
        this.$nextTick(() => {
          if (typeof this.$refs["orgList"] == "undefined") {
            return false;
          } else {
            this.$refs["orgList"].inputValue = this.orgForm.orgDistrictName;
          }
        });
      } else {
        this.deptForm.orgType = code;
        this.$nextTick(() => {
          if (typeof this.$refs["deptList"] == "undefined") {
            return false;
          } else {
            this.$refs["deptList"].inputValue = this.deptForm.orgDistrictName;
          }
        });
      }
    },
    /**
     *
     * 返回组织架构列表
     *
     */
    returnOrgStructure() {
      this.$router.push({
        path: "/orgManagement/orgStructureList"
      });
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //组织类别
      findValueBySetCode({ valueSetCode: "ORG_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            var options = response.data.responseData;
            for (let i = 0; i < options.length; i++) {
              if (options[i].value == "10") {
                options.splice(i, 1);
              }
            }
            this.orgTypeOptions = options;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //状态
      findValueBySetCode({ valueSetCode: "ORG_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.orgStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.parentNode = param.node;
    if (this.parentNode.orgCode == undefined) {
      this.parentNode = JSON.parse(sessionStorage.getItem("addOrgParentNode"));
    } else {
      sessionStorage.setItem(
        "addOrgParentNode",
        JSON.stringify(this.parentNode)
      );
    }
    this.status = param.status;
    this.isDepartment = param.isDept;
    //初始化参数
    this.infoForm.tableData = [];
    if (this.status == "edit") {
      this.tagName = "修改信息";
      this.isdefaultShow = true;
      this.getEhrOrgDetailByCode(this.parentNode.orgCode);
      this.findEhrOrgChangeRecordList(this.parentNode.orgCode);
    }
    //初始化数据字典
    this.initDataDictionary();
    //加载组织省市区
    this.getOrgNodes();
    //加载部门所在地省市区
    this.getDeptNodes();
  },
  destroyed() {
    sessionStorage.removeItem("addOrgParentNode");
  }
};
</script>

<style lang="scss" scoped>
#orgManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
  .form-content .el-form-item {
    margin-bottom: 15px;
  }
}

.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 0px 20px 20px 20px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.formTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.upOrg {
  font-size: 16px;
  display: block;
  margin-left: 30px;
}
.remark-style {
  display: block;
  width: 300px;
  margin-top:5px;
}
.form-item {
  width: 30%;
  min-width: 450px;
}
</style>
<style lang="scss">
#orgManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
.hideUl {
  display: none;
}
.showUl {
  margin-top: -40px;
  width: 200px;
}
</style>