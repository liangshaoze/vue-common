<template>
  <div id="orgManage">
    <headTag :tagName="tagName"/>

    <div class="formToolbar">
      <div class="main-left">
        <h3>
          <i type="primary" class="el-icon-office-building"></i>
          福寿康（上海）医疗养老服务有限公司
        </h3>
        <el-input
          class="filter-input"
          suffix-icon="el-icon-search"
          placeholder="请输入想查找的部门"
          v-model="filterOrgName"
        ></el-input>
        <el-tree
          class="filter-tree"
          node-key="orgCode"
          :data="data"
          :props="defaultProps"
          :render-content="renderContent"
          :highlight-current="true"
          :expand-on-click-node="false"
          :default-expanded-keys="['1']"
          @node-click="nodeClick"
          ref="tree"
        ></el-tree>
      </div>
      <div class="main-right">
        <div class="panel-card">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">公司信息</span>
              <el-button class="rightBtn" style="display: none;"></el-button>
              <el-button size="small" type="primary" @click="seeStaff()" class="rightBtn" v-if="false">查看员工</el-button>
              <el-button
                size="small"
                type="primary"
                @click="jumpOrgEdit('edit')"
                class="rightBtn"
              >修改信息</el-button>
              <el-button
                size="small"
                type="primary"
                @click="jumpOrgEdit('insert')"
                class="rightBtn"
              >新增下级</el-button>
            </el-col>
          </el-row>
          <div v-if="isDepartment == false">
            <div class="form-content">
              <el-form :inline="false" :model="orgForm" label-width="150px" class="demo-ruleForm">
                <el-col class="form-item">
                  <el-form-item required label="组织类型:">
                    <span>{{orgForm.orgTypeValue}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="组织名称:">
                    <span class="long-field">{{orgForm.orgName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="组织简称:">
                    <span>{{orgForm.orgShortName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="状态:">
                    <span>{{orgForm.orgStatusValue}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="所在地区:">
                    <span
                      class="long-field"
                      v-if="orgForm.orgProvinceName"
                    >{{orgForm.orgProvinceName}}/{{orgForm.orgCityName}}/{{orgForm.orgDistrictName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="详细地址:">
                    <span class="long-field">{{orgForm.orgAddress}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="证照名称:">
                    <span class="long-field">{{orgForm.certificateName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="联系人:">
                    <span>{{orgForm.contactsName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="联系电话:">
                    <span>{{orgForm.contactsTel}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="注册地址:">
                    <span class="long-field">{{orgForm.registerAddress}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="公司类型:">
                    <span>{{orgForm.companyType}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="发证日期:">
                    <span>{{orgForm.certificateDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="发证机关:">
                    <span class="long-field">{{orgForm.certificateOffice}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="邮箱:">
                    <span class="long-field">{{orgForm.orgEmail}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="法人代表:">
                    <span>{{orgForm.legalRepresentative}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="有效日期:">
                    <span
                      v-if="orgForm.validStartDate"
                    >{{orgForm.validStartDate}}---{{orgForm.validEndDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="统一信用代码:">
                    <span class="long-field">{{orgForm.orgCreditCode}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="有效期限:">
                    <span v-if="orgForm.validDuration">{{orgForm.validDuration}}年</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="注册资本:">
                    <span v-if="orgForm.registerCapital">{{orgForm.registerCapital}}万</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="经营范围:">
                    <span class="remark-style long-field">{{orgForm.businessScope}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="备注:">
                    <span class="remark-style long-field">{{orgForm.remark}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="授权委托书上传:">
                    <span v-if="EFUFileList.length>0">
                      <el-col v-for="(item,index) of EFUFileList" :key="index">
                        <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                          {{item.name}}
                          <i class="el-icon-view"></i>
                        </el-link>
                      </el-col>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="调档材料上传:">
                    <span v-if="IFUFileList.length>0">
                      <el-col v-for="(item,index) of IFUFileList" :key="index">
                        <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                          {{item.name}}
                          <i class="el-icon-view"></i>
                        </el-link>
                      </el-col>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="附件:">
                    <span v-if="AFUFileList.length>0">
                      <el-col v-for="(item,index) of AFUFileList" :key="index">
                        <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                          {{item.name}}
                          <i class="el-icon-view"></i>
                        </el-link>
                      </el-col>
                    </span>
                  </el-form-item>
                </el-col>
              </el-form>
            </div>
          </div>
          <div v-if="isDepartment == true">
            <div class="formToolbar">
              <el-form :inline="false" :model="orgForm" label-width="150px" class="demo-ruleForm">
                <el-col class="form-item">
                  <el-form-item required label="组织类型:">
                    <span>{{orgForm.orgTypeValue}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="组织名称:">
                    <span class="long-field">{{orgForm.orgName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="组织简称:">
                    <span>{{orgForm.orgShortName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="状态:">
                    <span>{{orgForm.orgStatusValue}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="所在地区">
                    <span class="long-field"
                      v-if="orgForm.orgProvinceName"
                    >{{orgForm.orgProvinceName}}/{{orgForm.orgCityName}}/{{orgForm.orgDistrictName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item required label="详细地址:">
                    <span class="long-field">{{orgForm.orgAddress}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="联系人:">
                    <span>{{orgForm.contactsName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="联系电话:">
                    <span>{{orgForm.contactsTel}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="邮箱:">
                    <span class="long-field">{{orgForm.orgEmail}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="附件:">
                    <span v-if="AFUFileList.length>0">
                      <el-col v-for="(item,index) of AFUFileList" :key="index">
                        <el-link :href="item.url" type="primary" :underline="false" target="_blank">
                          {{item.name}}
                          <i class="el-icon-view"></i>
                        </el-link>
                      </el-col>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="备注:">
                    <span class="remark-style long-field">{{orgForm.remark}}</span>
                  </el-form-item>
                </el-col>
              </el-form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { changeYMD } from "utils";
import { findEhrOrgList, getEhrOrgDetailByCode } from "api/orgStructure";

export default {
  data() {
    return {
      tagName: "组织架构",
      //是否部门组
      isDepartment: true,
      //组织架构查询框
      filterOrgName: "",
      orgForm: {},
      data: [],
      //调档材料上传
      IFUFileList: [],
      //附件材料上传
      AFUFileList: [],
      //授权材料上传
      EFUFileList: [],
      //部门组类型
      deptGroup: ["50", "60", "70", "80"],
      defaultProps: {
        children: "childrenOrgList",
        label: "orgName"
      },
      //默认条件过滤树形结构
      filterFlag: false
    };
  },
  components: {
    HeadTag
  },
  watch: {
    //监听搜索框
    filterOrgName(val) {
      if (val) {
        this.filterLoadTree();
      } else {
        this.loadTree();
      }
    }
  },
  methods: {
    //加载树结构数据
    loadTree() {
      var params = {
        orgName: ""
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.data = response.data.responseData;
            this.$nextTick(() => {
              this.nodeClick(this.data[0], this.$refs.tree.root, null);
            });
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgList:" + error);
          return false;
        });
    },
    //条件加载树结构数据
    filterLoadTree() {
      var params = {
        orgName: this.filterOrgName
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.data = response.data.responseData;
            this.$nextTick(() => {
              this.nodeClick(this.data[0], this.$refs.tree.root, null);
            });
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgList:" + error);
          return false;
        });
    },
    //当前选择节点
    nodeClick(data, node, self) {
      this.IFUFileList = [];
      this.AFUFileList = [];
      this.EFUFileList = [];
      if (data.orgPcode == "0") {
        this.$refs.tree.setCurrentKey("1");
      }
      //根据组织code查询Form数据
      var params = {
        orgCode: data.orgCode
      };
      getEhrOrgDetailByCode(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.orgForm = response.data.responseData;
            console.log(
              this.orgForm.investigationFileUrl,
              this.orgForm.appendFileUrl,
              this.orgForm.empowerFileUrl
            );
            if (this.deptGroup.indexOf(this.orgForm.orgType) >= 0) {
              this.isDepartment = true;
            } else {
              this.isDepartment = false;
            }
            if (this.orgForm.validStartDate) {
              this.orgForm.validStartDate = changeYMD(
                this.orgForm.validStartDate
              );
              this.orgForm.validEndDate = changeYMD(this.orgForm.validEndDate);
            }
            if (this.orgForm.certificateDate) {
              this.orgForm.certificateDate = changeYMD(
                this.orgForm.certificateDate
              );
            }
            if (this.orgForm.investigationFileUrl) {
              let IFUFile = response.data.responseData.investigationFileUrl;
              let tempInvestigation = IFUFile.split(",");
              for (let i = 0; i < tempInvestigation.length; i++) {
                let url = tempInvestigation[i];
                this.IFUFileList.push({
                  url: url,
                  name: decodeURI(url)
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18)
                });
              }
            }
            if (this.orgForm.appendFileUrl) {
              let AFUFile = response.data.responseData.appendFileUrl;
              let tempAppend = AFUFile.split(",");
              for (let i = 0; i < tempAppend.length; i++) {
                let url = tempAppend[i];
                this.AFUFileList.push({
                  url: url,
                  name: decodeURI(url)
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18)
                });
              }
            }
            if (this.orgForm.empowerFileUrl) {
              let EFUFile = response.data.responseData.empowerFileUrl;
              let tempEmpower = EFUFile.split(",");
              for (let i = 0; i < tempEmpower.length; i++) {
                let url = tempEmpower[i];
                this.EFUFileList.push({
                  url: url,
                  name: decodeURI(url)
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18)
                });
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getEhrOrgDetailByCode:" + error);
          return false;
        });
    },
    //渲染样式
    renderContent(h, { node, data, store }) {
      return (
        <span>
          <i />
          <span>{node.label}</span>
        </span>
      );
    },
    //新增下级/修改信息
    jumpOrgEdit(status) {
      let node = this.$refs.tree.getCurrentNode();
      if (node == null) {
        node = this.data[0];
      }
      this.$router.push({
        path: "/orgManagement/addOrgStructure",
        query: {
          node: node,
          status: status,
          isDept: status == "insert" ? false : this.isDepartment
        }
      });
    },
    //查看员工
    seeStaff() {
      let node = this.$refs.tree.getCurrentNode();
      if (node == null) {
        node = this.data[0];
      }
      this.$router.push({
        path: "/orgManagement/seeStaffList",
        query: {
          node: node
        }
      });
    }
  },
  created() {
    //初始化树形
    this.loadTree();
  }
};
</script>

<style lang="scss" scoped>
#orgManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
  .form-content .el-form-item {
    margin-bottom: 15px;
  }
}

.main-left {
  min-width: 320px;
  border-right: 1px solid rgba(224, 224, 224, 0.5);
}
.main-right {
  width: 100%;
}
.filter-input {
  width: 300px;
}
.filter-tree {
  max-width: 300px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 18px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  margin: 0px 0px 10px 0px;
  background: #fff;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}
.form-item {
  width: 30%;
  min-width: 280px;
}
.remark-style {
  display: block;
  width: 200px;
  margin-top:5px;
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
</style>
<style lang="scss">
#orgManage .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#orgManage .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#orgManage .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#orgManage .el-tree-node.is-current > .el-tree-node__content {
  color: #f98c3c;
}
#orgManage .el-tree-node.is-current > .el-tree-node__content i {
  background-color: #f98c3c;
  width: 8px;
  height: 8px;
  display: -webkit-inline-box;
  border-radius: 50%;
  margin-right: 5px;
}
</style>
