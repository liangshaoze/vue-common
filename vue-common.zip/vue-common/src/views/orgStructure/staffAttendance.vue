<template>
  <div id="scheduling">
    <headTag :tagName="tagName"/>

    <div class="container">
      <div class="seettingTop">
        <div style="width:calc(100% - 200px);float:left;">
          <el-col style="width:200px;">服务人数:13555</el-col>
          <el-col style="width:200px;">本月总计服务人次:351245</el-col>
        </div>
        <div style="width:600px;float:right;">
          <el-col style="width:200px;float:left;">
            <el-radio v-model="radio" label="1">上月</el-radio>
            <el-radio v-model="radio" label="2">当月</el-radio>
          </el-col>
          <el-col style="width:200px;float:right;">
            <el-button @click="returnBack" class="rightBtn" type="primary" size="mini">返回</el-button>
            <el-button @click="exportToExcel" class="rightBtn" type="primary" size="mini">导出考勤</el-button>
          </el-col>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="tablePanel">
        <!--列表-->
        <el-table
          :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
          size="mini"
          stripe
          :data="attendances"
          highlight-current-row
          v-loading="listLoading"
          element-loading-text="拼命加载中"
        >
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="clientName" label="员工姓名" width="150"></el-table-column>
          <el-table-column prop="clientGrade" label="岗位" min-width="150"></el-table-column>
          <el-table-column prop="clientPhone" label="星级" min-width="100"></el-table-column>
          <el-table-column prop="clientAddress" label="保底工时" min-width="150"></el-table-column>
          <el-table-column prop="clientGrade" label="住宿" min-width="100"></el-table-column>
          <el-table-column prop="clientPhone" label="商业" min-width="100"></el-table-column>
          <el-table-column prop="clientAddress" label="服务人数" min-width="150"></el-table-column>
          <el-table-column label="出勤情况" center>
            <el-table-column prop="m1" label="1" min-width="50"></el-table-column>
            <el-table-column prop="m2" label="2" min-width="50"></el-table-column>
            <el-table-column prop="m3" label="3" min-width="50"></el-table-column>
            <el-table-column prop="m4" label="4" min-width="50"></el-table-column>
            <el-table-column prop="m5" label="5" min-width="50"></el-table-column>
            <el-table-column prop="m6" label="6" min-width="50"></el-table-column>
            <el-table-column prop="m7" label="7" min-width="50"></el-table-column>
            <el-table-column prop="m8" label="8" min-width="50"></el-table-column>
            <el-table-column prop="m9" label="9" min-width="50"></el-table-column>
            <el-table-column prop="m10" label="10" min-width="50"></el-table-column>
            <el-table-column prop="m11" label="11" min-width="50"></el-table-column>
            <el-table-column prop="m12" label="12" min-width="50"></el-table-column>
            <el-table-column prop="m13" label="13" min-width="50"></el-table-column>
            <el-table-column prop="m14" label="14" min-width="50"></el-table-column>
            <el-table-column prop="m15" label="15" min-width="50"></el-table-column>
            <el-table-column prop="m16" label="16" min-width="50"></el-table-column>
            <el-table-column prop="m17" label="17" min-width="50"></el-table-column>
            <el-table-column prop="m18" label="18" min-width="50"></el-table-column>
            <el-table-column prop="m19" label="19" min-width="50"></el-table-column>
            <el-table-column prop="m20" label="20" min-width="50"></el-table-column>
            <el-table-column prop="m21" label="21" min-width="50"></el-table-column>
            <el-table-column prop="m22" label="22" min-width="50"></el-table-column>
            <el-table-column prop="m23" label="23" min-width="50"></el-table-column>
            <el-table-column prop="m24" label="24" min-width="50"></el-table-column>
            <el-table-column prop="m25" label="25" min-width="50"></el-table-column>
            <el-table-column prop="m26" label="26" min-width="50"></el-table-column>
            <el-table-column prop="m27" label="27" min-width="50"></el-table-column>
            <el-table-column prop="m28" label="28" min-width="50"></el-table-column>
            <el-table-column prop="m29" label="29" min-width="50"></el-table-column>
            <el-table-column prop="m30" label="30" min-width="50"></el-table-column>
            <el-table-column prop="m31" label="31" min-width="50"></el-table-column>
          </el-table-column>
          <el-table-column prop="clientAddress" label="本月实际出勤" min-width="150"></el-table-column>
          <el-table-column prop="clientGrade" label="本月应出勤" min-width="150"></el-table-column>
          <el-table-column prop="clientPhone" label="备注" min-width="100"></el-table-column>
        </el-table>

        <!--工具条-->
        <el-row class="pageToolbar">
          <el-col>
            <pagination
              v-if="totalCount>0"
              :total="totalCount"
              :page.sync="filters.pageNum"
              :limit.sync="filters.pageSize"
              @pagination="pageChange"
            ></pagination>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { getOrderDetail } from "api/orderManagement";

export default {
  data() {
    return {
      tagName: "查看考勤",
      orderInfo: {},
      attendances: [],
      radio: '1',
      //条件查询
      filters: {
        pageNum: 1,
        pageSize: 10
      },
      totalCount: 0,
      listLoading: false
    };
  },
  components: {
    HeadTag,
    Pagination
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.getOrderDetail(val.page); //改变页码，重新渲染页面
    },
    getOrderDetail(page) {
      this.filters.pageNum = page;
      var param = {
        pageNum: page,
        pageSize: this.filters.pageSize
      }; //TODO
      this.attendances = [
        {
          clientName: "张三",
          clientGrade: "四级",
          clientPhone: "15800773929",
          clientAddress: "水电路1388号",
        },
        {
          clientName: "张三",
          clientGrade: "四级",
          clientPhone: "15800773929",
          clientAddress: "水电路1388号",
        },
        {
          clientName: "张三",
          clientGrade: "四级",
          clientPhone: "15800773929",
          clientAddress: "水电路1388号",
        }
      ];
      // getOrderDetail(param)
      // .then(response => {
      //   if (response.data.statusCode == "200") {
      //     this.orderInfo = response.data.responseData;
      //   } else {
      //     this.$message.error(response.data.statusMsg);
      //     return false;
      //   }
      // })
      // .catch(error => {
      //   console.log("getOrderDetail:" + error);
      // });
    },
    //导出明细
    exportToExcel() {
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [
          "客户姓名",
          "等级",
          "电话",
          "住址",
          "周一",
          "周二",
          "周三",
          "周四",
          "周五",
          "周六",
          "周日"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [
          "clientName",
          "clientGrade",
          "clientPhone",
          "clientAddress",
          "week1",
          "week2",
          "week3",
          "week4",
          "week5",
          "week6",
          "week7"
        ];
        // 上面的index、phone_Num、school_Name是tableData里对象的属性
        let params = {
          staffId: this.staffId
        };
        findWorkOrderDutyStaffId(params)
          .then(response => {
            const list = response.data.responseData; //把data里的tableData存到list
            if (list.length > 0) {
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, this.title + "明细");
            } else {
              this.$message.error("操作失败");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    //返回列表
    returnBack() {
      this.$router.push({
        path: "/orgManagement/staffInfoList"
      });
    }
  },
  created() {
    //初始化被照护人信息
    this.getOrderDetail();
  }
};
</script>

<style lang="scss" scoped>
#scheduling {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  min-width: 80px;
  font-weight: 800;
  margin-left: 10px;
  height: 20px;
}

.form-item-service {
  width: 80px;
  min-width: 80px;
  margin-top: -3px;
  .font-style {
    height: 20px;
    line-height: 20px;
  }
}

.container {
  background-color: #fff;
  border-radius: 10px;
  margin: 0px 20px 20px 20px;
}

.tablePanel {
  padding: 20px;
}

.seettingTop {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
  height: 80px;
  display: flex;
  padding:30px 0px 0px 20px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}

.avatar {
  width: 60px;
  height: 60px;
  cursor: pointer;
}
</style>