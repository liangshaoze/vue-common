<template>
  <div id="scheduling">
    <headTag :tagName="tagName"/>

    <div class="container">
      <!-- <div class="seettingTop">
        <div class="info-left">
          <div class="person-detail">
            <el-avatar
              size="large"
              style="vertical-align: middle;"
              src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
              class="avatar"
            ></el-avatar>
          </div>
          <div class="person-info">
            <span>{{staffInfo.staffFullName}}</span>
          </div>
        </div>
        <div class="info-right" style="width:100%;padding:10px 0;">
          <div class="basic-info">
            <el-row style="margin-top:30px">
              <el-col style="font-size:16px;color:#333333;float:left;width:100px;">基本信息</el-col>
              <el-col style="width:200px;float:right;">
                <el-button @click="returnBack" class="rightBtn" type="primary" size="mini">返回</el-button>
              </el-col>
            </el-row>
            <el-row style="margin-top:20px">
              <el-col class="info-text" :span="8">性别:{{staffInfo.staffGenderValue}}</el-col>
              <el-col class="info-text" :span="8">联系方式:{{staffInfo.staffTel}}</el-col>
              <el-col class="info-text" :span="8">地址:{{staffInfo.liveProvinceName}}{{staffInfo.liveCityName}}{{staffInfo.liveDistrictName}}{{staffInfo.liveDetailAddress}}</el-col>
            </el-row>
          </div>
        </div>
      </div> -->
      <el-form>
        <el-row type="flex">
          <el-col style="width:120px">
            <div>
              <div class="avatar">
                <el-avatar
                  size="large"
                  src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
                  style="height:60px;width:60px;"
                ></el-avatar>
              </div>
              <div class="avatar" style="margin-top:10px;text-size:16px">{{staffInfo.staffFullName}}</div>
            </div>
          </el-col>
          <el-col style="justify-content:space-between">
            <div style="color:#333;text-size:16px;margin-top:10px">基本信息</div>
            <el-col style="width:80px;float:right;">
              <el-button @click="returnBack" class="rightBtn" type="primary" size="mini">返回</el-button>
            </el-col>
            <el-row style="margin-top:43px">
              <el-col class="info-text" :span="8">性别:{{staffInfo.staffGenderValue}}</el-col>
              <el-col class="info-text" :span="8">联系方式:{{staffInfo.staffTel}}</el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="container">
      <el-row class="tableTopBtn">
				<el-col :span="24">
          <span v-if="isShowHeader">
					  <el-button @click="exportToExcel" class="rightBtn" type="primary" size="mini">导出排程</el-button>
          </span>
				</el-col>
			</el-row>
      <div class="tablePanel">
        <div v-if="isMonth == true">
          <!--列表-->
          <el-table
            :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
            size="mini"
            stripe
            :data="schedulings"
            highlight-current-row
            v-loading="listLoading"
            element-loading-text="拼命加载中"
          >
            <el-table-column prop="careReceiverName" label="被照护人姓名" min-width="100"></el-table-column>
            <el-table-column prop="productName" label="产品名称" min-width="150"></el-table-column>
            <el-table-column prop="assessGrade" label="评估等级" min-width="100"></el-table-column>
            <el-table-column prop="careReceiverTel" label="联系电话" min-width="150"></el-table-column>
            <el-table-column prop="liveDetailAddress" label="详细地址" min-width="150"></el-table-column>
            <el-table-column label="排程情况">
              <el-table-column prop="1" label="1号" min-width="100"></el-table-column>
              <el-table-column prop="2" label="2号" min-width="100"></el-table-column>
              <el-table-column prop="3" label="3号" min-width="100"></el-table-column>
              <el-table-column prop="4" label="4号" min-width="100"></el-table-column>
              <el-table-column prop="5" label="5号" min-width="100"></el-table-column>
              <el-table-column prop="6" label="6号" min-width="100"></el-table-column>
              <el-table-column prop="7" label="7号" min-width="100"></el-table-column>
              <el-table-column prop="8" label="8号" min-width="100"></el-table-column>
              <el-table-column prop="9" label="9号" min-width="100"></el-table-column>
              <el-table-column prop="10" label="10号" min-width="100"></el-table-column>
              <el-table-column prop="11" label="11号" min-width="100"></el-table-column>
              <el-table-column prop="12" label="12号" min-width="100"></el-table-column>
              <el-table-column prop="13" label="13号" min-width="100"></el-table-column>
              <el-table-column prop="14" label="14号" min-width="100"></el-table-column>
              <el-table-column prop="15" label="15号" min-width="100"></el-table-column>
              <el-table-column prop="16" label="16号" min-width="100"></el-table-column>
              <el-table-column prop="17" label="17号" min-width="100"></el-table-column>
              <el-table-column prop="18" label="18号" min-width="100"></el-table-column>
              <el-table-column prop="19" label="19号" min-width="100"></el-table-column>
              <el-table-column prop="20" label="20号" min-width="100"></el-table-column>
              <el-table-column prop="21" label="21号" min-width="100"></el-table-column>
              <el-table-column prop="22" label="22号" min-width="100"></el-table-column>
              <el-table-column prop="23" label="23号" min-width="100"></el-table-column>
              <el-table-column prop="24" label="24号" min-width="100"></el-table-column>
              <el-table-column prop="25" label="25号" min-width="100"></el-table-column>
              <el-table-column prop="26" label="26号" min-width="100"></el-table-column>
              <el-table-column prop="27" label="27号" min-width="100"></el-table-column>
              <el-table-column prop="28" label="28号" min-width="100"></el-table-column>
              <el-table-column prop="29" label="29号" min-width="100"></el-table-column>
              <el-table-column prop="30" label="30号" min-width="100"></el-table-column>
              <el-table-column prop="31" label="31号" min-width="100"></el-table-column>
            </el-table-column>
          </el-table>
        </div>
        <div v-else>
          <!--列表-->
          <el-table
            :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
            size="mini"
            stripe
            :data="schedulings"
            :show-header="isShowHeader"
            highlight-current-row
            v-loading="listLoading"
            element-loading-text="拼命加载中"
          >
            <el-table-column prop="careReceiverName" label="被照护人姓名" min-width="100"></el-table-column>
            <el-table-column prop="productName" label="产品名称" min-width="150"></el-table-column>
            <el-table-column prop="assessGrade" label="评估等级" min-width="100"></el-table-column>
            <el-table-column prop="careReceiverTel" label="联系电话" min-width="150"></el-table-column>
            <el-table-column prop="liveDetailAddress" label="详细地址" min-width="150"></el-table-column>
            <el-table-column label="排程情况">
              <el-table-column label="周一" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Monday">
                    <el-tag>{{scope.row.Monday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周二" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Tuesday">
                    <el-tag>{{scope.row.Tuesday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周三" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Wednesday">
                    <el-tag>{{scope.row.Wednesday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周四" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Thursday">
                    <el-tag>{{scope.row.Thursday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周五" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Friday">
                    <el-tag>{{scope.row.Friday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周六" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Saturday">
                    <el-tag>{{scope.row.Saturday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="周日" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.Sunday">
                    <el-tag>{{scope.row.Sunday}}</el-tag>
                  </span>
                </template>
              </el-table-column>
            </el-table-column>
          </el-table>
        </div>

        <!--工具条-->
        <el-row class="pageToolbar">
          <el-col>
            <pagination
              v-if="totalCount>0"
              :total="totalCount"
              :page.sync="filters.pageNum"
              :limit.sync="filters.pageSize"
              @pagination="pageChange"
            ></pagination>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { getOrderDetail } from "api/orderManagement";
import { queryWorkOrderSchedule } from "api/workOrderManagement";

export default {
  data() {
    return {
      tagName: "排程",
      orderInfo: {},
      schedulings: [],
      isMonth: false,
      //默认不展示表头
      isShowHeader: false,
      //条件查询
      filters: {
        pageNum: 1,
        pageSize: 10
      },
      totalCount: 0,
      listLoading: false,
      //页面传参
      staffInfo: {},
      staffCode: ""
    };
  },
  components: {
    HeadTag,
    Pagination
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.queryWorkOrderSchedule(val.page); //改变页码，重新渲染页面
    },
    queryWorkOrderSchedule(page) {
      this.filters.pageNum = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        careGiverCode: this.staffCode
      };
      this.listLoading = true;
      queryWorkOrderSchedule(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.schedulings = response.data.responseData;
            if (this.schedulings.length > 0) {
              this.isShowHeader = true;
              if (this.schedulings[0].serviceFrequencyType !== "10") {
                this.isMonth = true;
              }
            }
            this.listLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("queryWorkOrderSchedule:" + error);
          this.listLoading = false;
          return false;
        });
    },
    exportToExcel() {
      if(this.isMonth == true) {
        this.exportMonthToExcel();
      } else {
        this.exportWeekToExcel();
      }
    },
    //导出周排程明细
    exportWeekToExcel() {
      let myDate = new Date();
      let yy = String(myDate.getFullYear());
      let mm = myDate.getMonth() + 1;
      mm = mm > 9 ? mm : "0" + mm;
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [
          "被照护人姓名",
          "被照护人编号",
          "产品名称",
          "评估等级",
          "联系电话",
          "详细地址",
          "周一",
          "周二",
          "周三",
          "周四",
          "周五",
          "周六",
          "周日"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [
          "careReceiverName",
          "",
          "productName",
          "assessGrade",
          "careReceiverTel",
          "liveDetailAddress",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday"
        ];
        // 上面的index、phone_Num、school_Name是tableData里对象的属性
        let params = {
          careGiverCode: this.staffCode
        };
        queryWorkOrderSchedule(params)
          .then(response => {
            const list = response.data.responseData; //把data里的tableData存到list
            if (list.length > 0) {
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, this.staffInfo.staffFullName+ '(' + this.staffInfo.staffTel +')' + "的排程信息");
            } else {
              this.$message.error("操作失败");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      });
    },
    //导出月排程明细
    exportMonthToExcel() {
      let myDate = new Date();
      let yy = String(myDate.getFullYear());
      let mm = myDate.getMonth() + 1;
      mm = mm > 9 ? mm : "0" + mm;
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [
          "被照护人姓名",
          "被照护人编号",
          "产品名称",
          "评估等级",
          "联系电话",
          "详细地址",
          "1号",
          "2号",
          "3号",
          "4号",
          "5号",
          "6号",
          "7号",
          "8号",
          "9号",
          "10号",
          "11号",
          "12号",
          "13号",
          "14号",
          "15号",
          "16号",
          "17号",
          "18号",
          "19号",
          "20号",
          "21号",
          "22号",
          "23号",
          "24号",
          "25号",
          "26号",
          "27号",
          "28号",
          "29号",
          "30号",
          "31号"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [
          "careReceiverName",
          "",
          "productName",
          "assessGrade",
          "careReceiverTel",
          "liveDetailAddress",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9",
          "10",
          "11",
          "12",
          "13",
          "14",
          "15",
          "16",
          "17",
          "18",
          "19",
          "20",
          "21",
          "22",
          "23",
          "24",
          "25",
          "26",
          "27",
          "28",
          "29",
          "30",
          "31"
        ];
        // 上面的index、phone_Num、school_Name是tableData里对象的属性
        let params = {
          careGiverCode: this.staffCode
        };
        queryWorkOrderSchedule(params)
          .then(response => {
            const list = response.data.responseData; //把data里的tableData存到list
            if (list.length > 0) {
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, this.staffInfo.staffFullName + "的排程信息");
            } else {
              this.$message.error("操作失败");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    //返回列表
    returnBack() {
      this.$router.push({
        path: "/orgManagement/staffInfoList"
      });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.staffInfo = param.staffInfo;
    this.staffCode = param.staffCode;
    if (this.staffInfo && this.staffInfo.staffCode == undefined) {
      this.staffInfo = JSON.parse(
        sessionStorage.getItem("staffInfoScheduling")
      );
    } else {
      sessionStorage.setItem(
        "staffInfoScheduling",
        JSON.stringify(this.staffInfo)
      );
    }
  },
  mounted() {
    //初始化被照护人信息
    this.queryWorkOrderSchedule(1);
  },
  destroyed() {
    sessionStorage.removeItem("staffInfoScheduling");
  }
};
</script>

<style lang="scss" scoped>
#scheduling {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  min-width: 80px;
  font-weight: 800;
  margin-left: 10px;
  height: 20px;
}

.form-item-service {
  width: 80px;
  min-width: 80px;
  margin-top: -3px;
  .font-style {
    height: 20px;
    line-height: 20px;
  }
}

.container {
  background-color: #fff;
  border-radius: 10px;
  margin: 0px 20px 20px 20px;
  padding: 20px;
  .avatar {
    display: flex;
    justify-content: center;
    justify-items: center;
  }
}

.tableTopBtn {
	background-color: white;
	text-align: right;
	padding-right: 20px;
}

.tablePanel {
  padding: 20px;
}

.seettingTop {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
  height: 140px;
  display: flex;
  .info-left {
    width: 170px;
    text-align: center;
    .person-detail {
      padding: 30px 0px 10px 45px;
    }
    .person-info {
      span {
        font-size: 16px;
        color: #333333;
      }
      .person-color {
        background: rgba(240, 75, 95, 1);
        border-radius: 10px;
        color: #ffffff;
        margin-left: 10px;
        padding: 4px;
        font-size: 14px;
      }
    }
  }
  .info-right {
    .rightBtn {
      float: right;
      margin-right: 20px;
    }
  }
}
</style>