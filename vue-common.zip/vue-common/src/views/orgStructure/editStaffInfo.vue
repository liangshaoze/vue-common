<template>
  <div id="orgManage">
    <headTag :tagName="tagName"/>

    <div class="main-content">
      <div class="main-left">
        <div class="margin-left-form">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">基本信息</span>
              <el-button type="primary" size="mini" @click="returnStaffList()" class="rightBtn">返回</el-button>
              <el-button
                type="primary"
                size="mini"
                @click="saveStaff('staffForm')"
                class="rightBtn"
                :loading="loadingBtn"
                v-if="flag"
              >保存</el-button>
              <el-button
                type="primary"
                size="mini"
                @click="editStaff()"
                class="rightBtn"
                :loading="loadingBtn"
                v-if="!flag"
              >修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form
              ref="staffForm"
              :inline="false"
              :model="staffForm"
              :rules="rules"
              label-width="150px"
              class="form-content"
            >
              <el-row>
                <el-col class="form-item">
                  <el-form-item label="姓名">{{staffForm.staffFullName}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="性别">{{staffForm.staffGenderValue}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="入职时间">{{staffForm.entryDate}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="手机号码" prop="staffTel">
                    <span v-if="isEdit == false">{{staffForm.staffTel}}</span>
                    <span v-if="isEdit == true">
                      <el-input
                        v-model="staffForm.staffTel"
                        size="mini"
                        clearable
                        placeholder="请输入手机号码"
                        maxlength="11"
                      ></el-input>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="组织" prop="orgName">{{staffForm.orgName}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="岗位" prop="positionName">{{staffForm.positionName}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="身份证号码" prop="idCard">{{staffForm.idCard}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="身份证地址">{{staffForm.idCardAddress }}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="籍贯">{{staffForm.nativePlace}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="现居住地址" prop="liveDistrictName">
                    <span v-if="isEdit == false">
                      <span
                        v-if="staffForm.liveDistrictName"
                      >{{staffForm.liveProvinceName}}/{{staffForm.liveCityName}}/{{staffForm.liveDistrictName}}</span>
                    </span>
                    <span v-if="isEdit == true">
                      <el-cascader
                        v-model="live"
                        placeholder="请选择现居住地址"
                        size="mini"
                        :options="liveOptions"
                        :show-all-levels="false"
                        @active-item-change="handleExpandChangeLive"
                        @change="addLiveToForm"
                        @visible-change="changeLive"
                        ref="liveList"
                        :props="{
                      value: 'id',
                      label: 'name',
                      children: 'cities'
                    }"
                      ></el-cascader>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                    <span v-if="isEdit == false" class="long-field">{{staffForm.liveDetailAddress }}</span>
                    <span v-if="isEdit == true">
                      <el-tooltip class="item" effect="dark" :disabled="staffForm.liveDetailAddress == '' ? true : false" :content="staffForm.liveDetailAddress" placement="top">
                        <el-input
                          v-model="staffForm.liveDetailAddress"
                          size="mini"
                          clearable
                          placeholder="请输入现居住详细地址"
                          maxlength="50"
                        ></el-input>
                      </el-tooltip>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="最高学历">{{staffForm.staffEducationValue}}</el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="员工星级">
                    <span v-if="isEdit == false">{{staffForm.staffGradeValue }}</span>
                    <span v-if="isEdit == true">
                      <el-select
                        v-model="staffForm.staffGrade"
                        size="mini"
                        clearable
                        :disabled="disabledGrade"
                        placeholder="请选择星级"
                      >
                        <el-option
                          v-for="item in staffGradeOptions"
                          :key="item.value"
                          :label="item.name"
                          :value="item.value"
                        />
                      </el-select>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="评定星级时间">
                    <span v-if="isEdit == false">{{staffForm.staffGradeEvaluateDate }}</span>
                    <span v-if="isEdit == true">
                      <el-date-picker
                        v-model="staffForm.staffGradeEvaluateDate"
                        size="mini"
                        clearable
                        :disabled="disabledGrade"
                        value-format="yyyy-MM-dd"
                        type="date"
                        placeholder="请选择评定时间"
                      ></el-date-picker>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="紧急联系人" prop="urgentContactsName">
                    <span v-if="isEdit == false">{{staffForm.urgentContactsName}}</span>
                    <span v-if="isEdit == true">
                      <el-input
                        v-model="staffForm.urgentContactsName"
                        size="mini"
                        clearable
                        placeholder="请输入紧急联系人"
                        maxlength="20"
                      ></el-input>
                    </span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="紧急联系号码" prop="urgentContactsTel">
                    <span v-if="isEdit == false">{{staffForm.urgentContactsTel}}</span>
                    <span v-if="isEdit == true">
                      <el-input
                        v-model="staffForm.urgentContactsTel"
                        size="mini"
                        clearable
                        placeholder="请输入紧急联系号码"
                        maxlength="20"
                      ></el-input>
                    </span>
                  </el-form-item>
                </el-col>
                <!-- <el-col class="form-item">
                <el-form-item label="病史">
                  <span v-if="staffForm.diseaseHistoryStatus == 0">无</span>
                  <span
                    v-if="staffForm.diseaseHistoryStatus == 1"
                  >有 {{staffForm.diseaseHistoryInfo}}</span>
                </el-form-item>
                </el-col>-->
              </el-row>
            </el-form>
          </el-row>
        </div>
        <div class="margin-left-form">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">岗位管理</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addPostForm('postForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="postForm.rules" :model="postForm" ref="postForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="postForm.tableData"
                  v-loading="postListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="orgName" label="组织" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.orgName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.orgName'"
                          :rules="postForm.rules.orgName"
                        >
                          <el-input
                            v-model="scope.row.orgName"
                            size="mini"
                            placeholder="请选择组织"
                            @focus="openDialog(scope.$index)"
                            clearable
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="positionName" label="岗位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.positionName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.positionName'"
                          :rules="postForm.rules.positionName"
                        >
                          <el-autocomplete
                            :trigger-on-focus="true"
                            v-model="scope.row.positionName"
                            size="mini"
                            clearable
                            :fetch-suggestions="queryPositionName"
                            placeholder="请输入岗位"
                            @select="selectPositionName($event,scope.$index)"
                            @input="removePositionCode(scope.$index)"
                          ></el-autocomplete>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isDefault" label="默认岗位" min-width="100px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.isDefault == 1">是</span>
                        <span v-else>否</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.isDefault'"
                          :rules="postForm.rules.isDefault"
                        >
                          <span v-if="scope.row.isDefault == 1">是</span>
                          <span v-else>否</span>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isManager" label="组织权限" min-width="100px">
                    <template slot-scope="scope">
                      <span v-if="!scope.row.editing">
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.isManager'"
                          :rules="postForm.rules.isManager"
                        >
                          <el-switch
                            @change="handleChangeManageStatus(scope.$index, scope.row)"
                            v-model="scope.row.isManager"
                          ></el-switch>
                        </el-form-item>
                      </span>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditPostForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSavePostForm(scope.$index, scope.row, 'postForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          v-if="scope.row.isDefault == '0' "
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeletePostForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
      </div>

      <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
        <org-select v-on:listenTochildEvent="getCurrentNode"/>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  chineseName
} from "@/utils/validate";
import {
  findEhrStaffByCode,
  insertEhrStaff,
  editEhrStaffForOrgModule,
  findEhrPositionList,
  findEhrStaffPositionList,
  insertEhrStaffPosition,
  editEhrStaffPosition,
  editEhrStaffPositionManageStatus,
  deleteEhrStaffPosition
} from "api/customerManagement";
export default {
  data() {
    return {
      tagName: "查看员工",
      //是否可编辑模式
      isEdit: false,
      //按钮加载
      loadingBtn: false,
      //保存/修改按钮的状态
      flag: false,
      //修改当前行
      currentIndex: 0,
      //星级禁用
      disabledGrade: true,
      /*
       *
       * 基本信息Form
       * 验证
       *
       *
       */
      staffForm: {
        diseaseHistoryStatus: 0,
        liveDistrictName: "",
        probationDate: [],
        ehrStaffPositionInDtoList: []
      },
      //验证
      rules: {
        staffFullName: [
          {
            type: "string",
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        staffGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        staffTel: [
          {
            required: true,
            message: "请输入手机号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        liveDistrictName: [
          {
            required: true,
            message: "请选择现居住地址",
            trigger: "input"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "blur"
          }
        ],
        idCard: [
          {
            required: true,
            message: "请输入身份证号码",
            trigger: "blur"
          },
          {
            required: true,
            trigger: "blur",
            validator: validateIdCard
          }
        ],
        urgentContactsName: [
          {
            required: true,
            message: "请输入紧急联系人",
            trigger: "blur"
          }
        ],
        urgentContactsTel: [
          {
            required: true,
            message: "请输入紧急联系号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ]
      },
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载本市地址省市区
      liveOptions: [],
      live: [],
      liveName: [],
      /*
       *
       * 岗位管理
       * 验证
       *
       *
       */
      postForm: {
        //验证
        rules: {
          orgName: [
            {
              required: true,
              message: "请选择组织",
              trigger: "change"
            }
          ],
          positionName: [
            {
              required: true,
              message: "请选择岗位",
              trigger: "change"
            }
          ]
        },
        tableData: []
      },
      //选择组织弹窗
      dialogVisible: false,
      //岗位选择
      position: [],
      //岗位列表加载
      postListLoading: false,
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      staffGenderOptions: [],
      //最高学历
      staffEducationOptions: [],
      //员工星级
      staffGradeOptions: [],
      /**
       *
       * 页面传参
       *
       */
      parentNode: [],
      staffCode: "",
      staffId: ""
    };
  },
  components: {
    HeadTag,
    OrgSelect
  },
  methods: {
    /**
     *
     * 基本信息保存
     *
     */
    saveStaff(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loadingBtn = true;
          editEhrStaffForOrgModule(this.staffForm)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$message.success("修改成功");
                this.findEhrStaffByCode(this.staffForm.staffCode);
                this.loadingBtn = false;
                this.isEdit = false;
                this.flag = false;
              } else {
                this.$message.error(response.data.statusMsg);
                this.loadingBtn = false;
                return false;
              }
            })
            .catch(error => {
              console.log("editEhrStaffForOrgModule:" + error);
              this.loadingBtn = false;
              return false;
            });
        } else {
          this.$message.error("请检查是否填写完整");
          console.log(response.data.statusMsg);
          return false;
        }
      });
    },
    //查询员工详情
    findEhrStaffByCode(code) {
      var params = {
        staffCode: code
      };
      findEhrStaffByCode(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.staffForm = response.data.responseData;
            this.staffForm.entryDate = changeYMD(this.staffForm.entryDate);

            this.staffForm.diseaseHistoryStatus = parseInt(
              this.staffForm.diseaseHistoryStatus
            );

            // if (this.staffForm.staffGradeEvaluateDate) {
            //   this.staffForm.staffGradeEvaluateDate = changeYMD(
            //     this.staffForm.staffGradeEvaluateDate
            //   );
            // }

            if (this.flag == true) {
              if (this.staffForm.liveDistrictName) {
                this.$refs[
                  "liveList"
                ].inputValue = this.staffForm.liveDistrictName;
              }
            }
            //查询岗位信息
            this.findEhrStaffPositionList(this.staffForm.staffCode);
          }
        })
        .catch(error => {
          console.log("findEhrStaffByCode:" + error);
          return false;
        });
    },
    //加载本市地址省市区
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.staffForm.liveProvinceCode = this.live[0];
      this.staffForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.staffForm.liveCityCode = this.live[1];
      this.staffForm.liveCityName = this.liveName[0].pathLabels[1];
      this.staffForm.liveDistrictCode = this.live[2];
      this.staffForm.liveDistrictName = this.liveName[0].pathLabels[2];
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs["liveList"].inputValue = this.staffForm.liveDistrictName;
        this.$refs["liveList"].presentText = this.staffForm.liveDistrictName;
      }
    },
    /**
     *
     * 病史切换
     * 如果无则清空病史输入
     *
     */
    medicalChange(val) {
      if (val == 0) {
        this.staffForm.diseaseHistoryInfo = "";
      }
    },
    /**
     *
     * 岗位管理列表操作
     *
     */
    // 查询当前岗位管理
    findEhrStaffPositionList(code) {
      var params = {
        staffCode: code
      };
      this.postListLoading = true;
      findEhrStaffPositionList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.postForm.tableData = response.data.responseData;
            var data = this.postForm.tableData;
            for (let i = 0; i < data.length; i++) {
              if (data[i].isManager == "1") {
                data[i].isManager = true;
              } else {
                data[i].isManager = false;
              }
            }
            this.postListLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.postListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrStaffPositionList:" + error);
          this.postListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditPostForm($index, row) {
      this.$set(this.postForm.tableData[$index], "editing", true);
      this.postForm.tableData[$index].isDefault =
        this.postForm.tableData[$index].isDefault == 1 ? true : false;
      this.postForm.tableData[$index].isManager =
        this.postForm.tableData[$index].isManager == 1 ? true : false;
    },
    // 保存
    handleSavePostForm($index, row, formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            var postData = this.postForm.tableData;
            if (postData.length > 0) {
              for (let l = 0; l < postData.length; l++) {
                if (postData[l].positionCode == "") {
                  postData[l].positionName = "";
                  this.$refs.postForm.validate(valid => {});
                  this.$message.error("输入的岗位不存在");
                  this.loadingBtn = false;
                  return false;
                }
              }
            }
            if (postData.length > 1) {
              for (let j = 1; j < postData.length; j++) {
                if (
                  postData[j].orgName + postData[j].positionName ==
                  postData[0].orgName + postData[0].positionName
                ) {
                  this.$message.error("存在相同组织岗位");
                  this.loadingBtn = false;
                  this.handleEditPostForm();
                  return false;
                }
              }
            }
            if (this.postForm.tableData[$index].id) {
              var params = {
                staffCode: this.staffForm.staffCode,
                id: this.postForm.tableData[$index].id,
                orgCode: this.postForm.tableData[$index].orgCode,
                orgName: this.postForm.tableData[$index].orgName,
                positionCode: this.postForm.tableData[$index].positionCode,
                positionName: this.postForm.tableData[$index].positionName,
                isDefault:
                  this.postForm.tableData[$index].isDefault == true ? "1" : "0",
                isManager:
                  this.postForm.tableData[$index].isManager == true ? "1" : "0"
              };
              editEhrStaffPosition(params)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    var currentData = response.data.responseData;
                    this.postForm.tableData[$index].id = currentData.id;
                    this.postForm.tableData[$index].staffCode =
                      currentData.staffCode;
                    this.postForm.tableData[$index].orgCode =
                      currentData.orgCode;
                    this.postForm.tableData[$index].orgName =
                      currentData.orgName;
                    this.postForm.tableData[$index].positionCode =
                      currentData.positionCode;
                    this.postForm.tableData[$index].positionName =
                      currentData.positionName;
                    this.postForm.tableData[$index].isDefault =
                      currentData.isDefault;
                    this.postForm.tableData[$index].isManager =
                      currentData.isManager;
                    this.$set(
                      this.postForm.tableData[$index],
                      "editing",
                      false
                    );
                    this.$message.success("保存成功");
                    this.findEhrStaffByCode(currentData.staffCode);
                    this.findEhrStaffPositionList(currentData.staffCode);
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("editEhrStaffPosition:" + error);
                  return false;
                });
            } else {
              var params = {
                staffCode: this.staffForm.staffCode,
                orgCode: this.postForm.tableData[$index].orgCode,
                orgName: this.postForm.tableData[$index].orgName,
                positionCode: this.postForm.tableData[$index].positionCode,
                positionName: this.postForm.tableData[$index].positionName,
                isDefault:
                  this.postForm.tableData[$index].isDefault == true ? "1" : "0",
                isManager:
                  this.postForm.tableData[$index].isManager == true ? "1" : "0"
              };
              insertEhrStaffPosition(params)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    var currentData = response.data.responseData;
                    this.postForm.tableData[$index].id = currentData.id;
                    this.postForm.tableData[$index].staffCode =
                      currentData.staffCode;
                    this.postForm.tableData[$index].orgCode =
                      currentData.orgCode;
                    this.postForm.tableData[$index].orgName =
                      currentData.orgName;
                    this.postForm.tableData[$index].positionCode =
                      currentData.positionCode;
                    this.postForm.tableData[$index].positionName =
                      currentData.positionName;
                    this.postForm.tableData[$index].isDefault =
                      currentData.isDefault;
                    this.postForm.tableData[$index].isManager =
                      currentData.isManager;
                    this.$set(
                      this.postForm.tableData[$index],
                      "editing",
                      false
                    );
                    this.$message.success("保存成功");
                    this.findEhrStaffByCode(currentData.staffCode);
                    this.findEhrStaffPositionList(currentData.staffCode);
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrStaffPosition:" + error);
                  return false;
                });
            }
          } else {
            this.$message.error("请检查是否填写完整");
            this.loadingBtn = false;
            return false;
          }
        });
      } else {
        this.$message.error("请检查是否填写完整");
        return false;
      }
    },
    // 新增一条岗位管理数据
    addPostForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.postForm.tableData = this.postForm.tableData || [];
            this.postForm.tableData.push({
              orgCode: null,
              orgName: null,
              positionCode: null,
              positionName: null,
              isDefault: 0,
              isManager: 0,
              status: 10,
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeletePostForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if(!this.postForm.tableData[$index].id){
            this.postForm.tableData.splice($index, 1);
            return;
          }
          var params = {
            staffCode: this.staffForm.staffCode,
            id: this.postForm.tableData[$index].id
          };
          deleteEhrStaffPosition(params)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.postForm.tableData.splice($index, 1);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("deleteEhrStaffPosition:" + error);
              return false;
            });
        })
        .catch(err => {
          return false;
        });
    },
    //修改岗位管理当前行组织权限
    handleChangeManageStatus($index, row) {
      var params = {
        staffCode: this.staffForm.staffCode,
        id: this.postForm.tableData[$index].id,
        isManager: this.postForm.tableData[$index].isManager == true ? "1" : "0"
      };
      editEhrStaffPositionManageStatus(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
          } else {
            console.log(this.postForm.tableData[$index].isManager);
          }
        })
        .catch(error => {
          console.log("editEhrStaffPositionManageStatus:" + error);
          return false;
        });
    },
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.postForm.tableData[this.currentIndex].orgName = data.orgName;
      this.postForm.tableData[this.currentIndex].orgCode = data.orgCode;
      this.handleClose();
    },
    openDialog($index) {
      this.currentIndex = $index;
      this.dialogVisible = true;
    },
    /**
     *
     * 模糊查询
     *
     */
    //列表岗位模糊查询
    selectPositionName(item, index) {
      if (item.value !== "无") {
        this.postForm.tableData[index].positionCode = item.code;
        this.postForm.tableData[index].positionName = item.value;
      } else {
        this.postForm.tableData[index].positionName = "";
      }
    },
    removePositionCode(index) {
      this.postForm.tableData[index].positionCode = "";
    },
    queryPositionName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.position = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.position.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.position;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 返回查看员工管理列表
     *
     */
    returnStaffList() {
      this.$router.push({
        path: "/orgManagement/staffInfoList"
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaff() {
      this.isEdit = true;
      this.flag = true;
      this.findEhrStaffByCode(this.staffCode);
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGenderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EHR_EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffEducationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //员工星级
      findValueBySetCode({ valueSetCode: "STAFF_GRADE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGradeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.staffCode = param.staffCode;
    //初始化参数
    this.postForm.tableData = [];
    //初始化查询员工信息
    this.findEhrStaffByCode(this.staffCode);
    //查询岗位信息
    this.findEhrStaffPositionList(this.staffCode);
    //初始化数据字典
    this.initDataDictionary();
    //加载本市地址省市区
    this.getLiveNodes();
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
#orgManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
  .form-content .el-form-item {
    margin-bottom: 15px;
  }
}

.main-content {
  width: 100%;
  display: flex;
  .tablePadding {
    padding: 0px 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}

.main-left {
  margin: 0px 0px 0px 20px;
  padding-right: 10px;
  min-width: 850px;
  .margin-left-form {
    border-radius: 10px;
    margin-bottom: 10px;
    padding-bottom: 20px;
    background: #fff;
  }
}

.importToolbar {
  padding: 20px 0px 10px 0px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    margin: 0px 20px;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.formTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.form-content {
  margin: 0px auto;
}
.form-item {
  width: 30%;
  min-width: 470px;
  height:50px;
}
.temp-title {
  width: 100%;
  text-align: right;
  padding: 0px 20px 20px 0px;
}
.upOrg {
  font-size: 16px;
  display: block;
  margin-left: 80px;
}
</style>
<style lang="scss">
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>