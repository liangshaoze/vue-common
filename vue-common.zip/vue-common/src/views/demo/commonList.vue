<!--通用列表demo-->
<template>
  <div>
    <el-form ref="propertyForm" :inline="true" :model="propertyForm" label-width="125px">
      <CommonTableWidget
        @queryMethod="queryMethod"
        :propertyList="tableColsConfigs"
        @saveRow="saveRow"
        :formModel="propertyForm"
        :tableDataName="'tableData'"
        ref="CommonTableWidget"
        :optWidth="200"
        :showTableIndex="true"
      />
    </el-form>
  </div>
</template>

<script>
import CommonTableWidget from "components/widget/CommonTableWidget";
export default {
  data() {
    return {
      propertyForm: {
          tableData:[]
      },
      tableColsConfigs: [
        {
            propertyName: "标题",propertyFieldName: "title",propertyType: "10"
        },
        {
            propertyName: "内容",propertyFieldName: "title",propertyType: "10"
        }
      ]
    };
  },
  methods: {
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    saveRow(){

    }
  }
};
</script>

<style>
</style>