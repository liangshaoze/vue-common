<template>
  <div id="maskOrderManage">
    <headTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="maskOrderFilters" :inline="true" :model="filters" label-width="85px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="所在区" prop="liveDistrictName">
              <el-select
                size="mini"
                v-model.trim="filters.liveDistrictName"
                placeholder="请选择区"
                clearable
                @focus="getDistrictNameByPid"
                @change="selectDistrict(filters.liveDistrictName)"
              >
                <el-option
                  v-for="item in district"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="所在街道" prop="liveSubdistrictName">
              <el-select
                size="mini"
                v-model.trim="filters.liveSubdistrictName"
                placeholder="请选择街道"
                clearable
                @focus="getSubDistrictNameByPid"
                @change="selectSubDistrict(filters.liveSubdistrictName)"
              >
                <el-option
                  v-for="item in subdistrict"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="所在居委" prop="liveNeighborName">
              <el-select
                size="mini"
                v-model.trim="filters.liveNeighborName"
                placeholder="请选择居委"
                clearable
                filterable
                allow-create
                @focus="getNeighborNameByPid"
                @change="selectNeighbor(filters.liveNeighborName)"
              >
                <el-option
                  v-for="item in neighbor"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="姓名">
              <el-input size="mini" v-model.trim="filters.customerName" clearable placeholder="请输入姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="手机号">
              <el-input size="mini" v-model.trim="filters.customerTel" clearable placeholder="请输入手机号" maxlength="11"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="身份证号">
              <el-input
                size="mini"
                v-model.trim="filters.customerIdCard"
                clearable
                placeholder="请输入身份证号"
                maxlength="18"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getMaskOrder(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="handleReset()">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-error" @click="batchFailure()">批量失效</el-button>
          <el-button size="mini" type="primary" icon="el-icon-upload" @click="exportMaskOrder()">导出</el-button>
        </el-col>
      </el-row>
      <!--列表-->
      <el-table
        ref="multipleTable"
        @selection-change="handleSelectionChange"
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="maskOrderForm"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column type="selection" width="50"></el-table-column>
        <el-table-column label="预约号" min-width="90" prop="orderCode"></el-table-column>
        <el-table-column label="所在区" min-width="60" prop="liveDistrictName"></el-table-column>
        <el-table-column label="所在街道" min-width="80" prop="liveSubdistrictName"></el-table-column>
        <el-table-column label="所在居委" min-width="120" prop="liveNeighborName"></el-table-column>
        <el-table-column label="居住地址" min-width="150" prop="liveDetailAddress"></el-table-column>
        <el-table-column label="姓名" min-width="50" prop="customerName"></el-table-column>
        <el-table-column label="手机号" min-width="70" prop="customerTel"></el-table-column>
        <el-table-column label="身份证号" min-width="120" prop="customerIdCard"></el-table-column>
        <el-table-column label="性别" min-width="50" prop="customerGender"></el-table-column>
        <el-table-column label="是否本市户籍" min-width="70" prop="isNativeHouse">
          <template slot-scope="scope">
            <span v-if="scope.isNativeHouse == 0">否</span>
            <span v-else>是</span>
          </template>
        </el-table-column>
      </el-table>

      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.page"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findAddressDictList } from "api/common";
import { findMaskOrderList, updateMaskOrderForOff } from "@/api/maskOrder";

export default {
  data() {
    return {
      tagName: "预约列表",
      //条件查询
      filters: {
        liveDistrictCode: "",
        liveDistrictName: "",
        liveSubdistrictCode: "",
        liveSubdistrictName: "",
        liveNeighborName: "",
        liveDetailAddress: "",
        customerName: "",
        customerTel: "",
        customerIdCard: "",
        isNativeHouse: "",
        page: 1,
        pageSize: 10
      },
      maskOrderForm: [],
      totalCount: 0,
      listLoading: false,
      searchLoading: false,
      //选中集合
      multipleSelection: [],
      //所在区
      district: [],
      //所在街道
      subdistrict: [],
      //所在居委
      neighbor: []
    };
  },
  components: {
    HeadTag,
    Pagination
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getMaskOrder(val.page); //改变页码，重新渲染页面
    },
    //获取预约列表
    getMaskOrder(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        liveDistrictCode: this.filters.liveDistrictCode,
        liveDistrictName: this.filters.liveDistrictName,
        liveSubdistrictCode: this.filters.liveSubdistrictCode,
        liveSubdistrictName: this.filters.liveSubdistrictName,
        liveNeighborName: this.filters.liveNeighborName,
        customerName: this.filters.customerName,
        customerTel: this.filters.customerTel,
        customerIdCard: this.filters.customerIdCard
      };
      this.listLoading = true;
      this.searchLoading = true;
      findMaskOrderList(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            if (response.data.responseData != undefined) {
              this.maskOrderForm = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          return false;
        });
    },
    //获取所在区下拉和选择
    getDistrictNameByPid() {
      let params = { pid: "310100" };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          this.district = response.data.responseData;
        }
      });
    },
    selectDistrict(val) {
      var obj = {};
      obj = this.district.find(item => {
        return item.id === val;
      });
      this.filters.liveDistrictCode = obj.id;
      this.filters.liveDistrictName = obj.name;
    },
    //获取所在街道下拉和选择
    getSubDistrictNameByPid(pid) {
      let params = { pid: this.filters.liveDistrictCode };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          this.subdistrict = response.data.responseData;
        }
      });
    },
    selectSubDistrict(val) {
      var obj = {};
      obj = this.subdistrict.find(item => {
        return item.id === val;
      });
      this.filters.liveSubdistrictCode = obj.id;
      this.filters.liveSubdistrictName = obj.name;
    },
    //获取所在居委下拉和选择
    getNeighborNameByPid(pid) {
      let params = { pid: this.filters.liveSubDistrictCode };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          this.neighbor = response.data.responseData;
        }
      });
    },
    selectNeighbor(val) {
      debugger
      var obj = {};
      if(this.neighbor.length > 0) {
        obj = this.neighbor.find(item => {
          return item.id === val;
        });
        // this.filters.liveNeighborCode = obj.id;
        this.filters.liveNeighborName = obj.name;
      } else {
        this.filters.liveNeighborName = val;
      }
    },
    /**
     *
     * 员工列表导出
     *
     */
    /**
     * 导出
     */
    exportMaskOrder() {
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [
          "预约号",
          "所在区",
          "所在街道",
          "所在居委",
          "居住地址",
          "姓名",
          "手机号",
          "身份证号",
          "性别",
          "是否本市户籍"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [
          "orderCode",
          "liveDistrictName",
          "liveSubdistrictName",
          "liveNeighborName",
          "liveDetailAddress",
          "customerName",
          "customerTel",
          "customerIdCard",
          "customerGender",
          "isNativeHouse"
        ];
        // 上面的index、phone_Num、school_Name是tableData里对象的属性
        const params = {
          liveDistrictCode: this.filters.liveDistrictCode,
          liveDistrictName: this.filters.liveDistrictName,
          liveSubdistrictCode: this.filters.liveSubdistrictCode,
          liveSubdistrictName: this.filters.liveSubdistrictName,
          liveNeighborName: this.filters.liveNeighborName,
          customerName: this.filters.customerName,
          customerTel: this.filters.customerTel,
          customerIdCard: this.filters.customerIdCard
        };
        findMaskOrderList(params)
          .then(response => {
            const list = response.data.responseData; //把data里的tableData存到list
            if (list.length > 0) {
              const data = this.formatJson(filterVal, list);
              try {
                export_json_to_excel(tHeader, data, "口罩预约列表");
              } catch (error) {
                this.$message.error("导出失败，请检查数据是否异常");
                return false;
              }
            } else {
              this.$message.error("暂无数据，无法导出Excel");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    //批量失效
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    batchFailure() {
      let list = this.multipleSelection;
      let orderCode = [];
      if (list.length == 0) {
        this.$message.error("请选择操作项");
        return false;
      } else {
        for (let i = 0; i < list.length; i++) {
          orderCode[i] = list[i].orderCode
        }
        var params = {
          orderCodes: orderCode
        }
        updateMaskOrderForOff(params)
          .then(response => {
            if (response.data.statusCode == "200") {
              this.$message.success("操作成功");
              this.getContractList();
            } else {
              this.$message.error("操作失败");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      }
    },
    //查询重置
    handleReset() {
      this.$refs.maskOrderFilters.resetFields();
      this.getMaskOrder(1);
    }
  },
  created() {},
  mounted() {},
  activated() {
    //初始化加载预约查询
    this.getMaskOrder(1);
  }
};
</script>

<style lang="scss" scoped>
#maskOrderManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 90px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
</style>
<style lang="scss">
#maskOrderManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>