<template>
  <div id="addCareReceiver">
    <headTag :tagName="tagName"/>

    <div class="main-content">
      <el-form
        ref="orderForm"
        :inline="false"
        :model="orderForm"
        :rules="orderFormRules"
        label-width="200px"
        class="form-content"
      >
        <div class="panel-card">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">被照护人信息</span>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                style="margin-left:5px;"
                @click="returnOrderList"
              >返回</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="saveCareReceiver('orderForm')"
                :loading="loadingBtn"
                v-if="flag"
              >保存</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="editStaff()"
                :loading="loadingBtn"
                v-if="!flag"
              >修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="姓名" prop="careReceiverName">
                <span v-if="isEdit == false">{{orderForm.careReceiverName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverName"
                    size="mini"
                    clearable
                    placeholder="请输入姓名"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身份证号" prop="careReceiverIdCard">
                <span v-if="isEdit == false">{{orderForm.careReceiverIdCard}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    id="idCard"
                    v-model="orderForm.careReceiverIdCard"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请输入身份证号"
                    maxlength="18"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
             <el-col class="form-item">
              <el-form-item label="联系方式" prop="careReceiverTel">
                <span v-if="isEdit == false">{{orderForm.careReceiverTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="性别" prop="careReceiverGender">
                <span v-if="isEdit == false">{{orderForm.careReceiverGenderValue}}</span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverGender"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in genderOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="出生年月" prop="careReceiverBirthday">
                <span v-if="isEdit == false">{{orderForm.careReceiverBirthday}}</span>
                <span v-if="isEdit == true">
                  <el-input v-model="orderForm.careReceiverBirthday" size="mini" :disabled="true"></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住省市区" prop="liveDistrictName">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.liveDistrictName"
                    class="long-field"
                  >{{orderForm.liveProvinceName}}/{{orderForm.liveCityName}}/{{orderForm.liveDistrictName}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-cascader
                    v-model="live"
                    placeholder="请选择现居住省市区"
                    size="mini"
                    :options="liveOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeLive"
                    @change="addLiveToForm"
                    @visible-change="changeLive"
                    ref="liveList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                <span v-if="isEdit == false" class="long-field">{{orderForm.liveDetailAddress}}</span>
                <span v-if="isEdit == true">
                  <el-tooltip
                    class="item"
                    effect="dark"
                    :disabled="orderForm.liveDetailAddress == '' ? true : false"
                    :content="orderForm.liveDetailAddress"
                    placement="top"
                  >
                    <el-input
                      v-model="orderForm.liveDetailAddress"
                      size="mini"
                      clearable
                      placeholder="请输入现居住详细地址"
                      maxlength="50"
                    />
                  </el-tooltip>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>

    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { findValueBySetCode, findAddressDictList } from "api/common";
import {
  validateTel,
  validateIdCard
} from "@/utils/validate";
export default {
  data() {
    return {
      tagName: "新增被照护人",
      //控制修改/保存
      flag: true,
      //是否可编辑
      isEdit: true,
      //修改禁用项
      isDisabled: false,
      loadingBtn: false,
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      orderForm: {
        careReceiverCode: "",
        careReceiverName: "",
        careReceiverGender: "",
        careReceiverBirthday: "",
        careReceiverIdCard: "",
        careReceiverTel: "",
        careReceiverReletion: "",
        liveProvinceCode: "",
        liveProvinceName: "",
        liveCityCode: "",
        liveCityName: "",
        liveDistrictCode: "",
        liveDistrictName: "",
        liveSubdistrictCode: "",
        liveSubdistrictName: "",
        liveDetailAddress: "",
        liveLongitude: "",
        liveLatitude: "",
        remark: ""
      },
      //验证
      orderFormRules: {
        careReceiverName: [
          {
            required: true,
            message: "请输入被照护人姓名",
            trigger: "input"
          }
        ],
        careReceiverIdCard: [
          {
            required: true,
            message: "请输入身份证号",
            trigger: "blur"
          },
          {
            validator: validateIdCard
          }
        ],
        careReceiverTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          },
          {
            validator: validateTel
          }
        ],
        careReceiverGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        careReceiverBirthday: [
          {
            required: true,
            message: "请输入出生年月",
            trigger: "blur"
          }
        ],
        careReceiverReletion: [
          {
            required: true,
            message: "请输入被照护人关系",
            trigger: "change"
          }
        ],
        liveProvinceName: [
          {
            required: true,
            message: "请选择所在地区",
            trigger: "input"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入详细地址",
            trigger: "input"
          }
        ]
      },
      //动态加载现居住省市区
      liveOptions: [],
      live: [],
      liveName: [],
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      genderOptions: [],
      //联系人关系
      relationOptions: [],
      /**
       *
       * 页面传参
       *
       */
      careReceiverCode: ""
    };
  },
  components: {
    HeadTag
  },
  methods: {
    /**
     *
     * 新增被照护人信息
     *
     *
     */
    saveCareReceiver(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //紧急联系人如果三项都没有填写直接移除
          if (this.orderForm.careReceiverFamilyList.length > 0) {
            var list = this.orderForm.careReceiverFamilyList;
            for (let i = 0; i < list.length; i++) {
              if (
                list[i].familyMemberName == "" &&
                list[i].contactsTel == "" &&
                list[i].relationship == "" &&
                list[i].isGuardian
              ) {
                this.orderForm.careReceiverFamilyList.splice(i, 1);
                i = 0;
              }
            }
          }
          var params = {
            //组织和服务信息
            orgCode: this.orderForm.orgCode,
            orgName: this.orderForm.orgName,
            careReceiverCode: this.orderForm.careReceiverCode,
            careReceiverName: this.orderForm.careReceiverName,
            careReceiverTel: this.orderForm.careReceiverTel,
            careReceiverBirthday: this.orderForm.careReceiverBirthday,
            careReceiverIdCard: this.orderForm.careReceiverIdCard,
            careReceiverIdCardPhoto: this.orderForm.careReceiverIdCardPhoto,
            careReceiverGender: this.orderForm.careReceiverGender,
            serviceStartDate: this.orderForm.serviceStartDate,
            serviceEndDate: this.orderForm.serviceEndDate,
            careProviderGender: this.orderForm.careProviderGender,
            recommendCode: this.orderForm.recommendCode,
            recommendName: this.orderForm.recommendName,
            recommendOrgCode: this.orderForm.recommendOrgCode,
            recommendOrgName: this.orderForm.recommendOrgName,
            remark: this.orderForm.remark,
            //被照护人信息
            etCareReceiverInDto: {
              careReceiverName: this.orderForm.careReceiverName,
              careReceiverGender: this.orderForm.careReceiverGender,
              careReceiverBirthday: this.orderForm.careReceiverBirthday,
              careReceiverIdCard: this.orderForm.careReceiverIdCard,
              careReceiverIdCardPhoto: this.orderForm.careReceiverIdCardPhoto,
              careReceiverTel: this.orderForm.careReceiverTel,
              careReceiverNation: this.orderForm.careReceiverNation,
              nativePlace: this.orderForm.nativePlace,
              houseProvinceCode: this.orderForm.houseProvinceCode,
              houseProvinceName: this.orderForm.houseProvinceName,
              houseCityCode: this.orderForm.houseCityCode,
              houseCityName: this.orderForm.houseCityName,
              houseDistrictCode: this.orderForm.houseDistrictCode,
              houseDistrictName: this.orderForm.houseDistrictName,
              houseDetailAddress: this.orderForm.houseDetailAddress,
              liveProvinceCode: this.orderForm.liveProvinceCode,
              liveProvinceName: this.orderForm.liveProvinceName,
              liveCityCode: this.orderForm.liveCityCode,
              liveCityName: this.orderForm.liveCityName,
              liveDistrictCode: this.orderForm.liveDistrictCode,
              liveDistrictName: this.orderForm.liveDistrictName,
              liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
              liveSubdistrictName: this.orderForm.liveSubdistrictName,
              liveDetailAddress: this.orderForm.liveDetailAddress,
              liveLongitude: this.orderForm.liveLongitude,
              liveLatitude: this.orderForm.liveLatitude,
              careReceiverPolitical: this.orderForm.careReceiverPolitical,
              careReceiverEducation: this.orderForm.careReceiverEducation,
              maritalStatus: this.orderForm.maritalStatus,
              medicalType: this.orderForm.medicalType,
              medicalCardNo: this.orderForm.medicalCardNo,
              careReceiverFaith: this.orderForm.careReceiverFaith,
              physicalDamage: this.orderForm.physicalDamage
            },
            //紧急联系人
            careReceiverFamilyList: this.orderForm.careReceiverFamilyList
          };
          if(this.orderCode) {
              this.loadingBtn = true;
              params.orderCode = this.orderCode;
              updateOrderInfoForCareReceiver(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("修改成功");
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                    this.getOrderDetail();
                } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                }
                })
                .catch(error => {
                console.log("updateOrderInfoForCareReceiver:" + error);
                });
          } else {
            insertEtOffLineProductOrder(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("新增成功");
                    this.$router.push({
                    path: "/businessServiceManagement/orderManagementList"
                    });
                } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                }
                })
                .catch(error => {
                console.log("insertEtOffLineProductOrder:" + error);
                return false;
                });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 查询被照护人信息
     *
     */
    getOrderDetail() {
      var param = {
        orderCode: this.orderCode
      }; //TODO
      getOrderDetail(param)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.orderInfo = response.data.responseData;
            this.orderInfo.isCopy = true;
            this.orderInfo.orderStatus = "10";
            //组织和服务信息
            if (this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto) {
              let photoUrl = this.orderInfo.etCareReceiverOutDto
                .careReceiverIdCardPhoto;
              this.idCardFileList = [];
              let photos = photoUrl.split(",");
              if (photos.length == 2) {
                this.hideBriefUpload = true;
              }
              for (let i = 0; i < photos.length; i++) {
                this.idCardFileList.push({
                  name: decodeURI(photos[i])
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18),
                  url: photos[i]
                });
              }
            }
            this.orderForm.careReceiverCode = this.orderInfo.etCareReceiverOutDto.careReceiverCode;
            this.orderForm.careReceiverName = this.orderInfo.etCareReceiverOutDto.careReceiverName;
            this.orderForm.careReceiverGender = this.orderInfo.etCareReceiverOutDto.careReceiverGender;
            this.orderForm.careReceiverBirthday = this.orderInfo.etCareReceiverOutDto.careReceiverBirthday;
            this.orderForm.careReceiverIdCard = this.orderInfo.etCareReceiverOutDto.careReceiverIdCard;
            this.orderForm.careReceiverIdCardPhoto = this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto;
            this.orderForm.careReceiverTel = this.orderInfo.etCareReceiverOutDto.careReceiverTel;
            this.orderForm.careReceiverNation = this.orderInfo.etCareReceiverOutDto.careReceiverNation;
            this.orderForm.nativePlace = this.orderInfo.etCareReceiverOutDto.nativePlace;
            this.orderForm.houseProvinceCode = this.orderInfo.etCareReceiverOutDto.houseProvinceCode;
            this.orderForm.houseProvinceName = this.orderInfo.etCareReceiverOutDto.houseProvinceName;
            this.orderForm.houseCityCode = this.orderInfo.etCareReceiverOutDto.houseCityCode;
            this.orderForm.houseCityName = this.orderInfo.etCareReceiverOutDto.houseCityName;
            this.orderForm.houseDistrictCode = this.orderInfo.etCareReceiverOutDto.houseDistrictCode;
            this.orderForm.houseDistrictName = this.orderInfo.etCareReceiverOutDto.houseDistrictName;
            this.orderForm.houseDetailAddress = this.orderInfo.etCareReceiverOutDto.houseDetailAddress;
            this.orderForm.liveProvinceCode = this.orderInfo.etCareReceiverOutDto.liveProvinceCode;
            this.orderForm.liveProvinceName = this.orderInfo.etCareReceiverOutDto.liveProvinceName;
            this.orderForm.liveCityCode = this.orderInfo.etCareReceiverOutDto.liveCityCode;
            this.orderForm.liveCityName = this.orderInfo.etCareReceiverOutDto.liveCityName;
            this.orderForm.liveDistrictCode = this.orderInfo.etCareReceiverOutDto.liveDistrictCode;
            this.orderForm.liveDistrictName = this.orderInfo.etCareReceiverOutDto.liveDistrictName;
            this.orderForm.liveSubdistrictCode = this.orderInfo.etCareReceiverOutDto.liveSubdistrictCode;
            this.orderForm.liveSubdistrictName = this.orderInfo.etCareReceiverOutDto.liveSubdistrictName;
            this.orderForm.liveDetailAddress = this.orderInfo.etCareReceiverOutDto.liveDetailAddress;
            this.orderForm.liveLongitude = this.orderInfo.etCareReceiverOutDto.liveLongitude;
            this.orderForm.liveLatitude = this.orderInfo.etCareReceiverOutDto.liveLatitude;
            this.orderForm.careReceiverPolitical = this.orderInfo.etCareReceiverOutDto.careReceiverPolitical;
            this.orderForm.careReceiverEducation = this.orderInfo.etCareReceiverOutDto.careReceiverEducation;
            this.orderForm.maritalStatus = this.orderInfo.etCareReceiverOutDto.maritalStatus;
            this.orderForm.medicalType = this.orderInfo.etCareReceiverOutDto.medicalType;
            this.orderForm.medicalCardNo = this.orderInfo.etCareReceiverOutDto.medicalCardNo;
            this.orderForm.careReceiverFaith = this.orderInfo.etCareReceiverOutDto.careReceiverFaith;
            this.orderForm.physicalDamage = this.orderInfo.etCareReceiverOutDto.physicalDamage;
            //组织和服务信息
            this.orderForm.visitDate = this.orderInfo.visitDate;
            this.orderForm.careProviderGender = this.orderInfo.careProviderGender;
            this.orderForm.recommendCode = this.orderInfo.recommendCode;
            this.orderForm.recommendName = this.orderInfo.recommendName;
            this.orderForm.recommendOrgCode = this.orderInfo.recommendOrgCode;
            this.orderForm.recommendOrgName = this.orderInfo.recommendOrgName;
            this.orderForm.remark = this.orderInfo.remark;
            this.orderForm.liveLongitude = this.orderInfo.liveLongitude;
            this.orderForm.liveLatitude = this.orderInfo.liveLatitude;
            var familyList = this.orderInfo.careReceiverFamilyList;
            var list = [];
            if (familyList.length > 0) {
              for (let i = 0; i < familyList.length; i++) {
                list.push({
                  careReceiverCode: familyList[i].careReceiverCode,
                  contactsTel: familyList[i].contactsTel,
                  familyMemberName: familyList[i].familyMemberName,
                  relationship: familyList[i].relationship,
                  relationshipValue: familyList[i].relationshipValue,
                  isGuardian: familyList[i].isGuardian
                });
              }
            } else {
              list.push({
                careReceiverCode: "",
                contactsTel: "",
                familyMemberName: "",
                relationship: "",
                relationshipValue: "",
                isGuardian: ""
              });
            }
            this.orderForm.careReceiverFamilyList = list;
            this.$nextTick(() => {
              if (this.flag == true) {
                this.$refs[
                  "houseList"
                ].inputValue = this.orderForm.houseDistrictName;
                this.$refs[
                  "liveList"
                ].inputValue = this.orderForm.liveSubdistrictName;
              }
            });
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getOrderDetail:" + error);
        });
    },
    //加载本市地址
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      } else if (val.length === 3) {
        idArea = val[2];
        sizeArea = val.length; //三级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.orderForm.liveProvinceCode = this.live[0];
      this.orderForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.orderForm.liveCityCode = this.live[1];
      this.orderForm.liveCityName = this.liveName[0].pathLabels[1];
      this.orderForm.liveDistrictCode = this.live[2];
      this.orderForm.liveDistrictName = this.liveName[0].pathLabels[2];
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs["liveList"].inputValue = this.orderForm.liveDistrictName;
        this.$refs["liveList"].presentText = this.orderForm.liveDistrictName;
      }
    },
    /**
     *
     * 返回查看被照护人列表
     *
     */
    returnOrderList() {
      this.$router.push({
        path: "/evaluationManagement/findCareReceiverlist"
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaff() {
      this.isEdit = true;
      this.flag = true;
      this.getOrderDetail();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //关系
      findValueBySetCode({ valueSetCode: "STAFF_POLITICAL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.politicalOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    if (param.type == "update") {
      this.tagName = "修改被照护人";
      this.careReceiverCode = param.careReceiverCode;
      this.isEdit = false;
      this.flag = false;
    }
    //查询订单详情
    // this.getOrderDetail();
    //初始化数据字典
    this.initDataDictionary();
    //加载现居住省市区
    this.getLiveNodes();
  }
};
</script>

<style lang="scss" scoped>
#addCareReceiver {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 20px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.remark-style {
  display: block;
  width: 300px;
  margin-top: 5px;
}
.form-item {
  width: 30%;
  min-width: 500px;
  height: 50px;
}
.form-item-table {
  width: 20%;
  min-width: 250px;
  height: 50px;
}
.radioRight {
  margin-right: 10px;
}
.footerBtn {
  margin: 50px 0px 20px 200px;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
</style>
<style lang="scss">
#addCareReceiver {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .hideBrief .el-upload--picture-card {
    display: none;
  }
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>