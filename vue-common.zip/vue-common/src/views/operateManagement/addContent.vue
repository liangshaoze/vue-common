<template>
	<div id="addContent">
		<headTag :tagName="tagName" />
		<el-row class="panel-card">
			<el-row class="importToolbar">
				<el-col :span="24">
					<el-button size="small" type="primary" class="rightBtn" @click="cancelClick()">返回</el-button>
				</el-col>
			</el-row>
			<el-row>
				<el-form
					:inline="false"
					:model="formContent"
					:rules="formContentRules"
					label-width="100px"
					ref="formContent"
				>
					<el-form-item label="分类" prop="userStatus">
						<el-select
							size="mini"
							@change="selectChange"
							v-model.trim="formContent.type"
							clearable
							placeholder="请选择分类"
						>
							<el-option
								v-for="item in typeOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="标题" prop="userCode">
						<el-input
							size="mini"
							v-model.trim="formContent.type"
							maxlength="30"
							placeholder="请输入标题"
							clearable
						>
							<template slot="append">30</template>
						</el-input>
						<p>(标题将显示在相关播放页面，建议填写清晰、准确生动的标题)</p>
					</el-form-item>
					<el-form-item label="视频" prop="userCode" v-if="isVideo">
						<el-upload
							class="upload-demo"
							action="https://jsonplaceholder.typicode.com/posts/"
							:on-preview="handlePreview"
							:on-remove="handleRemove"
							:before-remove="beforeRemove"
							multiple
							:limit="3"
							:on-exceed="handleExceed"
							:file-list="fileList"
						>
							<el-button size="small" type="primary">点击上传</el-button>
							<div slot="tip" class="el-upload__tip">请上传时长小于30分钟的视频，支持主流的视频格式</div>
						</el-upload>
					</el-form-item>
					<el-form-item label="音频" prop="userCode" v-if="isAudio">
						<el-upload
							class="upload-demo"
							action="https://jsonplaceholder.typicode.com/posts/"
							:on-preview="handlePreview"
							:on-remove="handleRemove"
							:before-remove="beforeRemove"
							multiple
							:limit="3"
							:on-exceed="handleExceed"
							:file-list="fileList"
						>
							<el-button size="small" type="primary">点击上传</el-button>
							<div slot="tip" class="el-upload__tip">
								格式支持mp3、wma、wav、amr、m4a，文件大小不能超过200M，
								音频时长不超过1小时
							</div>
						</el-upload>
					</el-form-item>
					<el-form-item label="封面" prop="userCode" v-if="isCover">
						<el-upload
							action="https://jsonplaceholder.typicode.com/posts/"
							list-type="picture-card"
							:on-preview="handlePictureCardPreview"
							:on-remove="handleRemove"
						>
							<i class="el-icon-plus"></i>
						</el-upload>
						<el-dialog :visible.sync="dialogVisible">
							<img width="100%" :src="dialogImageUrl" alt />
						</el-dialog>
					</el-form-item>
					<el-form-item label="简介" prop="userCode">
						<el-input
							size="mini"
							type="textarea"
							maxlength="120"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="formContent.cover"
							clearable
							placeholder="请输入简介"
						>
							<template slot="append">120</template>
						</el-input>
					</el-form-item>
					<el-form-item label="标签" class="tagClass" prop="userStatus">
						<div style="display:flex;">
							<el-select size="mini" v-model.trim="formContent.cover" clearable placeholder="请选择状态">
								<el-option
									v-for="item in typeOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
							<el-input
								style="margin-left:22px;"
								size="mini"
								v-model.trim="formContent.cover"
								placeholder="请输入标题"
								clearable
							></el-input>
						</div>
					</el-form-item>
					<el-form-item label="发布日期">
						<el-radio-group v-model="formContent.cover">
							<el-radio :label="'10'">立即发布</el-radio>
							<el-radio :label="'20'">定时发布</el-radio>
						</el-radio-group>
						<el-date-picker
							v-model.trim="formContent.cover"
							clearable
							size="mini"
							format="yyyy-MM-dd HH:mm"
							value-format="yyyy-MM-dd HH:mm"
							type="datetimerange"
							style="width: 320px;margin-left:20px;"
							range-separator="至"
							start-placeholder="开始日期"
							end-placeholder="结束日期"
						></el-date-picker>
					</el-form-item>
					<el-form-item label="备注" prop="userCode">
						<el-input
							size="mini"
							type="textarea"
							maxlength="225"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="formContent.cover"
							clearable
							placeholder="请输入简介"
						>
							<template slot="append">225</template>
						</el-input>
					</el-form-item>
					<el-form-item style="margin-bottom:20px;">
						<el-button type="primary" size="mini">提交</el-button>
					</el-form-item>
				</el-form>
			</el-row>
		</el-row>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";

export default {
	components: {
		HeadTag
	},
	props: {},
	data () {
		return {
			tagName: "新增",
			formContent: {
				type: '',
				cover: '',

			},
			formContentRules: {

			},
			typeOptions: [
				{
					value: '1',
					name: '图文信息'
				},
				{
					value: '2',
					name: '音频'
				},
				{
					value: '3',
					name: '视频'
				},
			],
			isCover: false,//图文
			isVideo: false,//视频
			isAudio: false,//音频
			dialogImageUrl: '',
			dialogVisible: false,
			fileList: []

		};
	},
	watch: {},
	computed: {},
	methods: {
		selectChange (val) {
			console.log(val)
			if (val == '1') {
				this.isCover = true
				this.isVideo = false
				this.isAudio = false

			} else if (val == '2') {
				this.isAudio = true
				this.isCover = false
				this.isVideo = false
			} else if (val == '3') {
				this.isVideo = true
				this.isCover = true
				this.isAudio = false
			}

		},
		handleRemove (file, fileList) {
			console.log(file, fileList);
		},
		handlePictureCardPreview (file) {
			this.dialogImageUrl = file.url;
			this.dialogVisible = true;
		},
		beforeRemove (file) {

		}
	},
	created () { },
	mounted () { }
};
</script>
<style lang="scss" scoped>
#addContent {
	width: 100%;
	min-width: 1024px;
	.el-form-item {
		margin-bottom: 15px;
	}
}
.panel-card {
	border: 1px solid #e0e6eb;
	border-radius: 8px;
	margin: 0px 10px 10px 10px;
	background: #ffffff;
}
.el-input {
	width: 220px;
}
.el-select {
	width: 220px;
}
.el-textarea {
	width: 400px;
}
.importToolbar {
	padding: 0px 0px 10px 0px;
	.rightBtn {
		float: right;
		margin-right: 20px;
		margin-top: 15px;
	}
}
.tagClass {
	.el-form-item__content {
		display: flex !important;
	}
}
</style>