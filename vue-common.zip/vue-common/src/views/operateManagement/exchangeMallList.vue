<template>
  <div id="exchangeMall">
    <headTag :tagName="tagName"/>
    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form :inline="true" ref="filterForm" :model="filters" label-width="80px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="商品名称" prop="productName">
              <el-input
                size="mini"
                v-model.trim="filters.productName"
                clearable
                placeholder="请输入商品名称"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="产品分类" prop="classCode">
              <el-select
                size="mini"
                v-model.trim="filters.classCode"
                clearable
                placeholder="请选择产品分类"
              >
                <el-option
                  v-for="item in productClassOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item-btn">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getList(1)"
              >查询</el-button>
              <!-- <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button> -->
              <el-button size="mini" type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
              <el-button size="mini" type="danger" icon="el-icon-delete" @click="selectDelete">批量删除</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="tableToolbar">
      <el-row class="tableTopBtn"></el-row>
      <!-- 列表 -->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="productClassList"
        v-loading="listLoading"
        highlight-current-row
        @selection-change="handleSelectionChange"
        element-loading-text="拼命加载中"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column label="产品编码" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="产品名称" min-width="150" prop="genderValue"></el-table-column>
        <el-table-column label="产品分类" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="需要积分数量" min-width="150" prop="genderValue"></el-table-column>
        <el-table-column label="可兑换数量" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="已兑换数量" min-width="150" prop="genderValue"></el-table-column>
        <el-table-column label="更新时间" min-width="200" prop="startWorkDate"></el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="updateHandle(scope.row)">修改</el-button>
            <el-button size="mini" type="text" @click="deleteHandle(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.pageNum"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
    </div>

    <!-- 新增/修改分类 -->
    <el-dialog
      :title="titleName"
      :visible.sync="dialogEditVisible"
      :before-close="editVisibleClose"
      width="600px"
      center
    >
      <el-form
        :inline="true"
        ref="productForm"
        :model="productForm"
        :rules="productFormRules"
        label-width="150px"
      >
        <el-row>
          <el-col class="form-items">
            <el-form-item label="产品名称" prop="productName">
              <el-input
                size="mini"
                v-model.trim="productForm.productName"
                maxlength="30"
                clearable
                placeholder="请输入产品名称"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="产品分类" prop="classCode">
              <el-select
                size="mini"
                v-model.trim="productForm.classCode"
                clearable
                placeholder="请选择产品分类"
              >
                <el-option
                  v-for="item in productClassOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="需要积分数量" prop="needCount">
              <el-input
                size="mini"
                v-model.trim="productForm.needCount"
                onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"
                clearable
                placeholder="请输入正整数"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="可兑换数量" prop="convertibleCount">
              <el-input
                size="mini"
                v-model.trim="productForm.convertibleCount"
                onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"
                clearable
                placeholder="请输入正整数"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item-product">
            <el-form-item label="资料上传">
              <upload
                :multiple="false"
                :limit="1"
                :action="actionUrl"
                :file-list="productFileList"
                :hideUpload="hideUpload"
                :disabled="disabledFile"
                :accept="'image/jpeg,image/gif,image/png'"
                @handleGetUrl="getUrl"
                @handleRemoveList="removeList"
              ></upload>
            </el-form-item>
          </el-col>
          <el-col class="form-item-product">
            <el-form-item label="产品描述">
              <el-input
                type="textarea"
                class="remark-style"
                v-model="productForm.remark"
                size="mini"
                clearable
                placeholder="请输入产品描述"
                maxlength="255"
                show-word-limit
                resize="none"
                rows="6"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="editVisibleClose">取 消</el-button>
        <el-button
          style="margin-left:40px;"
          size="mini"
          type="primary"
          :disabled="saveDisabled"
          @click="submitHandle('productForm')"
        >确 定</el-button>
      </div>
    </el-dialog>

    <!-- 批量删除 -->
    <el-dialog
      title="是否删除该内容？"
      :visible.sync="dialogDelete"
      width="500px"
      :before-close="handleDeleteClose"
      center
    >
      <el-row type="flex" justify="center">
        <h3>如果是请点击确定，否则点击取消</h3>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleDeleteClose()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitDelete()"
        >确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common";
import Upload from "components/FileUpload/upload";
import {
  findRecruitNeedList,
  updateRecruitNeed
} from "api/dispatchRequirement";

export default {
  components: {
    HeadTag,
    Upload,
    Pagination
  },
  props: {},
  data() {
    return {
      tagName: "兑换商城",
      productClassList: [],
      totalCount: 1,
      listLoading: false,
      //控制查询按钮加载
      searchLoading: false,
      //多选列
      multipleSelection: [],
      //批量删除
      dialogDelete: false,
      selectProduceClassList: [],
      filters: {
        pageNum: 1,
        pageSize: 10,
        productName: "",
        classCode: "",
        className: ""
      },
      //新增/修改分类
      titleName: "",
      dialogEditVisible: false,
      saveDisabled: false,
      productForm: {
        productCode: "",
        productName: "",
        classCode: "",
        className: "",
        needCount: "",
        convertibleCount: "",
        convertedCount: "",
        productFileUrls: "",
        remark: "",
        updateDate: ""
      },
      productFormRules: {
        productName: [
          {
            required: true,
            message: "请输入产品名称",
            trigger: "blur"
          }
        ],
        classCode: [
          {
            required: true,
            message: "请选择产品分类",
            trigger: "change"
          }
        ],
        needCount: [
          {
            required: true,
            message: "请输入需要积分数量",
            trigger: "blur"
          }
        ],
        convertibleCount: [
          {
            required: true,
            message: "请输入可兑换数量",
            trigger: "blur"
          }
        ]
      },
      //产品分类
      productClassOptions: [],
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      productFileList: [],
      hideUpload: false,
      disabledFile: false
    };
  },
  watch: {},
  computed: {},
  methods: {
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.getList(1);
    },
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page);
    },
    getList(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        productName: this.filters.productName,
        classCode: this.filters.classCode
      };
      this.listLoading = true;
      this.searchLoading = true;
      findRecruitNeedList(params)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            this.listLoading = false;
            this.searchLoading = false;
            this.productClassList = response.data.responseData;
            this.totalCount = response.data.totalCount;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
          }
        })
        .catch(error => {
          console.log("findRecruitNeedList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
        });
    },
    //批量删除
    selectDelete() {
      let list = this.multipleSelection;
      if (list.length == 0) {
        this.$message.error("请选择操作项");
        return false;
      } else {
        this.dialogDelete = true;
        for (let i = 0; i < list.length; i++) {
          this.selectProduceClassList[i] = list[i].classCode;
        }
      }
    },
    handleDeleteClose() {
      this.selectProduceClassList = [];
      this.dialogDelete = false;
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    deleteHandle(row) {
      this.selectProduceClassList[0] = row.classCode;
      this.dialogDelete = true;
    },
    submitDelete() {
      var params = {
        scheduleCodes: this.selectProduceClassList
      };
      //   deleteWorkorderScheduleByCheckBox(params)
      //     .then(response => {
      //       if (response.data.statusCode == "200") {
      //         this.$message.success("操作成功");
      //         this.dialogDelete = false;
      //         this.selectProduceClassList = [];
      //         this.getList(1);
      //       } else {
      //         this.$message.error(response.data.statusMsg);
      //         this.selectProduceClassList = [];
      //         return false;
      //       }
      //     })
      //     .catch(error => {
      //       console.log(error);
      //       return false;
      //     });
    },
    //新增/修改分类
    submitHandle(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //保存禁用
          this.saveDisabled = true;
          var params = {
            className: this.productForm.className,
            sort: this.productForm.sort
          };
          if (this.productForm.classCode) {
            params.classCode = this.productForm.classCode;
          } else {
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    addHandle() {
      this.titleName = "新增产品";
      this.dialogEditVisible = true;
    },
    updateHandle(row) {
      this.titleName = "修改产品";
      this.dialogEditVisible = true;
      this.productForm.productCode = row.productCode;
      this.productForm.productName = row.productName;
      this.productForm.classCode = row.classCode;
      this.productForm.className = row.className;
      this.productForm.needCount = row.needCount;
      this.productForm.convertibleCount = row.convertibleCount;
      this.productForm.convertedCount = row.convertedCount;
      this.productForm.productFileUrls = row.productFileUrls;
      this.productForm.remark = row.remark;
      if (
        row.productFileUrls !== undefined &&
        row.productFileUrls !== "undefined" &&
        row.productFileUrls
      ) {
        let photos = [];
        photos[0] = row.productFileUrls;
        this.productFileList = [];
        if (photos.length == 1) {
          this.hideUpload = true;
        }
        for (let i = 0; i < photos.length; i++) {
          this.productFileList.push({
            name: decodeURI(photos[i])
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18),
            url: photos[i]
          });
        }
      }
    },
    editVisibleClose() {
      this.dialogEditVisible = false;
      this.$refs.productForm.resetFields();
      this.productForm.classCode = "";
      this.productFileList = [];
    },
    /**
     *
     * 产品图片
     *
     */
    //产品图片上传
    getUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        this.productFileList = [];
        if (fileList.length == 1) {
          this.hideUpload = true;
        }
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
            this.productFileList.push({
              name: item.name,
              status: item.status,
              type: item.type,
              uid: item.uid,
              url: item.response.responseData
            });
          } else {
            urls.push(item.url);
            this.productFileList.push(item);
          }
        });
        let fileUrl = "";
        urls.forEach(items => {
          fileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (fileUrl.length > 0) {
          fileUrl = fileUrl.substr(0, fileUrl.length - 1);
        }
        this.productForm.productFileUrls = fileUrl;
      }
    },
    //删除文件
    removeList(file, cfileList) {
      let fileList = this.productFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      if (index > -1) {
        let deletArr = fileList.splice(index, 1);
        let fileUrl = "";
        this.productFileList.map(items => {
          fileUrl += items.url + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (fileUrl.length > 0) {
          fileUrl = fileUrl.substr(0, fileUrl.length - 1);
        }
        this.hideUpload = false;
        this.productForm.productFileUrls = fileUrl;
      }
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //工单状态
      findValueBySetCode({ valueSetCode: "WORKORDER_STATUS" })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.productClassOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    this.initDataDictionary();
  },
  mounted() {
    this.getList(1);
  }
};
</script>
<style lang="scss" scoped>
#exchangeMall {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }

  .el-input {
    width: 200px;
  }
  .el-select {
    width: 200px;
  }
  .el-autocomplete {
    width: 200px;
  }
  .form-item {
    width: 30%;
    min-width: 300px;
  }
  .form-item-btn {
    width: 30%;
    min-width: 300px;
  }
  .form-items {
    width: 100%;
    min-width: 400px;
    .el-form-item {
      margin-bottom: 15px;
    }
  }
  .form-item-product {
    margin: 18px 0px;
    width: 100%;
  }
  .tableTopBtn {
    background-color: white;
    text-align: right;
    padding: 10px 20px 10px 0px;
  }
  .search_btn {
    min-width: 300px;
    margin-left: 80px;
  }
  .remark-style {
    display: block;
    width: 300px;
    margin-top: 5px;
  }
  .el-dialog {
    display: flex;
    flex-direction: column;
    margin: 0 !important;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
  .el-dialog .el-dialog__body {
    flex: 1;
    overflow: auto;
  }
}
</style>
<style lang="scss">
#exchangeMall {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>