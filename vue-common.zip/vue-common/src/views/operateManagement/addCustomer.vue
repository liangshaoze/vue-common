<template>
  <div id="addCareReceiver">
    <headTag :tagName="tagName"/>

    <div class="main-content">
      <el-form
        ref="customerForm"
        :inline="false"
        :model="customerForm"
        :rules="customerFormRules"
        label-width="200px"
        class="form-content"
      >
        <div class="panel-card">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">客户信息</span>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                style="margin-left:5px;"
                @click="returnOrderList"
              >返回</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="saveCustomer('customerForm')"
                :loading="loadingBtn"
                v-if="flag"
              >保存</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="editCustomer()"
                :loading="loadingBtn"
                v-if="!flag"
              >修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="姓名" prop="customerName">
                <span v-if="isEdit == false">{{customerForm.customerName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="customerForm.customerName"
                    size="mini"
                    clearable
                    placeholder="请输入姓名"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="联系方式" prop="customerTel">
                <span v-if="isEdit == false">{{customerForm.customerTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="customerForm.customerTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身份证号" prop="idCard">
                <span v-if="isEdit == false">{{customerForm.idCard}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    id="idCard"
                    v-model="customerForm.idCard"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请输入身份证号"
                    maxlength="18"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="性别" prop="customerGender">
                <span v-if="isEdit == false">{{customerForm.customerGenderValue}}</span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="customerForm.customerGender"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in genderOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="出生年月" prop="customerBirthday">
                <span v-if="isEdit == false">{{customerForm.customerBirthday}}</span>
                <span v-if="isEdit == true">
                  <el-input v-model="customerForm.customerBirthday" size="mini" :disabled="true"></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="会员级别" prop="level">
                {{customerForm.level}}
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="会员有效期" prop="date">
                {{customerForm.date}}
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="推荐人">
                <span v-if="isEdit == false">{{customerForm.recommendName}}</span>
                <span v-if="isEdit == true">
                  <el-autocomplete
                    :trigger-on-focus="true"
                    v-model="customerForm.recommendName"
                    popper-class="my-autocomplete"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryStaffName"
                    placeholder="请输入员工姓名"
                    @select="selectStaffName"
                    @blur="removeStaffCode"
                  >
                    <template slot-scope="{ item }">
                      <span class="name">
                        {{ item.value }}
                        <span v-if="item.value != '无'">({{ item.staffTel }})</span>
                      </span>
                    </template>
                  </el-autocomplete>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-product">
              <el-form-item label="备注">
                <span v-if="isEdit == false">{{customerForm.remark}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    type="textarea"
                    class="remark-style"
                    v-model="customerForm.remark"
                    size="mini"
                    clearable
                    placeholder="请输入备注"
                    maxlength="100"
                    show-word-limit
                    resize="none"
                    rows="4"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>

    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { findValueBySetCode, findAddressDictList } from "api/common";
import {
  validateTel,
  validateIdCard
} from "@/utils/validate";
export default {
  data() {
    return {
      tagName: "新增客户",
      //控制修改/保存
      flag: true,
      //是否可编辑
      isEdit: true,
      //修改禁用项
      isDisabled: false,
      loadingBtn: false,
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      customerForm: {
        customerCode: "",
        customerName: "",
        customerTel: "",
        idCard: "",
        customerGender: "",
        customerBirthday: "",
        level: "",
        date: "",
        recommendCode: "",
        recommendName: "",
        remark: ""
      },
      //验证
      customerFormRules: {
        customerName: [
          {
            required: true,
            message: "请输入被照护人姓名",
            trigger: "input"
          }
        ],
        customerTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          },
          {
            validator: validateTel
          }
        ]
      },
      //推荐人
      recommend: [],
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      genderOptions: [],
      /**
       *
       * 页面传参
       *
       */
      careReceiverCode: ""
    };
  },
  components: {
    HeadTag
  },
  methods: {
    /**
     *
     * 新增/修改客户信息
     *
     *
     */
    saveCustomer(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var params = {
            //客户信息
            customerCode: this.customerForm.customerCode,
            customerName: this.customerForm.customerName,
            customerTel: this.customerForm.customerTel,
            idCard: this.customerForm.idCard,
            customerGender: this.customerForm.customerGender,
            customerBirthday: this.customerForm.customerBirthday,
            level: this.customerForm.level,
            date: this.customerForm.date,
            recommendCode: this.customerForm.recommendCode,
            recommendName: this.customerForm.recommendName,
            remark: this.customerForm.remark
          };
          if(this.customerCode) {
              this.loadingBtn = true;
              params.customerCode = this.customerCode;
              updateOrderInfoForCareReceiver(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("修改成功");
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                    this.getOrderDetail();
                } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                }
                })
                .catch(error => {
                console.log("updateOrderInfoForCareReceiver:" + error);
                });
          } else {
            insertEtOffLineProductOrder(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("新增成功");
                    this.$router.push({
                    path: "/evaluationManagement/customerManagementList"
                    });
                } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                }
                })
                .catch(error => {
                console.log("insertEtOffLineProductOrder:" + error);
                return false;
                });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 查询被照护人信息
     *
     */
    getOrderDetail() {
      var param = {
        orderCode: this.orderCode
      }; //TODO
      getOrderDetail(param)
        .then(response => {
          if (response.data.statusCode == "200") {
            var data = response.data.responseData;
            this.customerForm.customerCode = data.customerCode;
            this.customerForm.customerName = data.customerName;
            this.customerForm.customerTel = data.customerTel;
            this.customerForm.idCard = data.idCard;
            this.customerForm.customerGender = data.customerGender;
            this.customerForm.customerBirthday = data.customerBirthday;
            this.customerForm.level = data.level;
            this.customerForm.date = data.date;
            this.customerForm.recommendCode = data.recommendCode;
            this.customerForm.recommendName = data.recommendName;
            this.customerForm.remark = data.remark;
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getOrderDetail:" + error);
        });
    },
    /**
     *
     * 返回查看被照护人列表
     *
     */
    returnOrderList() {
      this.$router.push({
        path: "/evaluationManagement/customerManagementList"
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editCustomer() {
      this.isEdit = true;
      this.flag = true;
      this.getOrderDetail();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    if (param.type == "update") {
      this.tagName = "修改客户";
      this.customerCode = param.customerCode;
      this.isEdit = false;
      this.flag = false;
    }
    //查询订单详情
    // this.getOrderDetail();
    //初始化数据字典
    this.initDataDictionary();
  }
};
</script>

<style lang="scss" scoped>
#addCareReceiver {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 20px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.remark-style {
  display: block;
  width: 300px;
  margin-top: 5px;
}
.form-item {
  width: 30%;
  min-width: 500px;
  height: 50px;
}
.form-item-table {
  width: 20%;
  min-width: 250px;
  height: 50px;
}
.radioRight {
  margin-right: 10px;
}
.footerBtn {
  margin: 50px 0px 20px 200px;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
</style>
<style lang="scss">
#addCareReceiver {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .hideBrief .el-upload--picture-card {
    display: none;
  }
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>