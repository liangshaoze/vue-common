<template>
	<div id="suggestManagementList">
		<!-- 地址标签 -->
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filters" label-width="85px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="反馈用户" prop="feedbackUserName">
							<el-input
								size="mini"
								v-model.trim="filters.feedbackUserName"
								placeholder="请输入反馈用户"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="处理状态" prop="handleStatus">
							<el-select size="mini" v-model.trim="filters.handleStatus" clearable placeholder="请选择处理状态">
								<el-option
									v-for="item in handleStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="联系方式" prop="tel">
							<el-input size="mini" v-model.trim="filters.tel" placeholder="请输入联系方式" clearable></el-input>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="反馈时间" prop="dateTime">
							<el-date-picker
								v-model.trim="filters.dateTime"
								clearable
								size="mini"
								format="yyyy-MM-dd"
								value-format="yyyy-MM-dd"
								type="daterange"
								style="width: 320px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row></el-row>
			</el-form>
		</div>

		<!-- 列表数据 -->
		<div class="tableToolbar">
			<el-row class="tableTopBtn"></el-row>
			<el-table
				:data="tableData"
				:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
				element-loading-text="拼命加载中"
				highlight-current-row
				size="mini"
				stripe
				style="width:100%;"
				v-loading="listLoading"
			>
				<el-table-column label="反馈用户" min-width="100" prop="createName"></el-table-column>
				<el-table-column label="联系方式" min-width="100" prop="tel"></el-table-column>
				<el-table-column label="反馈内容" width="150" :show-overflow-tooltip="true" prop="content">
					<!-- <template slot-scope="scope">
					<div v-if="scope.row.content!==''" style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;">{{scope.row.content }}</div>
						<el-popover placement="top-start" title="反馈内容" width="250" trigger="hover">
							<div v-if="scope.row.content!==''">{{scope.row.content }}</div>
							<span slot="reference">
									<el-button
										type="text"
										style="color:#606266;"
										v-if="scope.row.content!==''"
									>{{ scope.row.content}}</el-button>
							</span>
						</el-popover>
					</template> -->
				</el-table-column>
				<el-table-column label="反馈图片" min-width="150">
					<template slot-scope="scope">
						<span v-if="scope.row.url">
							<el-image
								v-for="(item,index) in (scope.row.url.split(','))"
								:preview-src-list="scope.row.url.split(',')"
								:key="index"
								:src="item ? item : ''"
								style="width: 100px; height: 100px"
							></el-image>
						</span>
					</template>
				</el-table-column>
				<el-table-column label="反馈时间" min-width="100">
					<template slot-scope="scope">
						<span v-if="scope.row.createDate">{{scope.row.createDate.substring(-1,10)}}</span>
					</template>
				</el-table-column>
				<el-table-column label="处理状态" min-width="100" prop="handleStatusValue"></el-table-column>
				<el-table-column label="备注" width="150" :show-overflow-tooltip="true" prop="remark">
					<!-- <template slot-scope="scope">
						<el-popover placement="top-start" title="备注" width="250" trigger="hover">
							<div v-if="scope.row.remark!==''" style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;">{{scope.row.remark}}</div>
							<span slot="reference">
									<el-button
										type="text"
										style="color:#606266;"
										v-if="scope.row.remark!==''"
									>{{ scope.row.remark}}</el-button>
							</span>
						</el-popover>
					</template> -->
				</el-table-column>
				<el-table-column label="处理者" min-width="100" prop="handleUserName"></el-table-column>
				<el-table-column label="处理时间" min-width="100" prop="updateDate"></el-table-column>
				<el-table-column label="操作" width="100">
					<template slot-scope="scope">
						<span v-if="scope.row.handleStatus=='10'">
							<el-button @click="handleSuggest(scope.row.id)" size="mini" type="text">去处理</el-button>
						</span>
					</template>
				</el-table-column>
			</el-table>

			<!--工具条-->
			<el-row class="pageToolbar">
				<!--分页-->
				<pagination
					:limit.sync="filters.pageSize"
					:page.sync="filters.pageNum"
					:total="totalCount"
					@pagination="pageChange"
					v-if="totalCount > 0"
				/>
			</el-row>
		</div>
		<!--立即处理弹窗-->
		<el-dialog
			:visible.sync="suggestModal"
			width="400px"
			:before-close="handleClose"
			title="反馈处理"
			center
		>
			<el-row type="flex" justify="center" style="margin-right:65px;">
				<el-form
					:inline="false"
					:model="formSuggest"
					:rules="formSuggestRules"
					label-width="100px"
					ref="formSuggest"
				>
					<el-form-item label="处理状态:" style="margin-bottom:20px;" prop="handleStatus">
						<el-select
							size="mini"
							v-model.trim="formSuggest.handleStatus"
							clearable
							placeholder="请选择处理状态"
						>
							<el-option
								v-for="item in handleStatusOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="备注:" prop="remark">
						<el-input
							size="mini"
							type="textarea"
							maxlength="255"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="formSuggest.remark"
							clearable
							placeholder="请输入备注"
						></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div class="dialog-footer" slot="footer">
				<el-button @click="btnCancel('formSuggest')" size="mini">取 消</el-button>
				<el-button
					:loading="Loading"
					style="margin-left:40px;"
					@click="btnDefine('formSuggest')"
					size="mini"
					type="primary"
				>确定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import OrgSelect from "components/OrgSelect";

import {
	findCustValueSetList,
	handleCustFeedback,
} from "api/operateManagement/index.js";
import { findValueBySetCode } from "api/common/index.js";
import { get } from "http";
export default {
	components: {
		HeadTag,
		Pagination,
		OrgSelect,
	},
	props: {},
	data () {
		return {
			tagName: "意见反馈",
			totalCount: 0,
			handleStatusOptions: [],
			spreadOptions: [],
			isTrue: false,
			dialogVisible: false,
			//关键字搜索
			filters: {
				feedbackUserName: "",
				handleStatus: "",
				tel: "",
				userStatus: "",
				dateTime: '',
				pageNum: 1,
				pageSize: 10
			},
			srcList: [],
			cancleDisabled: false,
			listLoading: false,
			//列表数据
			tableData: [],
			suggestModal: false,
			Loading: false,

			//修改弹窗
			dialogEdit: false,
			formSuggest: {
				handleStatus: "",
				remark: "",
				id: ''
			},
			formSuggestRules: {
				handleStatus: [
					{ required: true, message: '请选择', trigger: 'change' }
				],
				remark: [
					{ required: false, message: '请填写备注', trigger: 'blur' }
				],
			}
		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClose () {
			this.$refs['formSuggest'].resetFields();
			this.suggestModal = false;
		},
		btnCancel (formSuggest) {
			this.$refs[formSuggest].resetFields();
			this.suggestModal = false;
		},
		handleSuggest (id) {
			this.formSuggest.id = id
			this.suggestModal = true
		},
		btnDefine (formSuggest) {
			this.$refs[formSuggest].validate(valid => {
				if (valid) {
					var params = {
						id: this.formSuggest.id,
						handleStatus: this.formSuggest.handleStatus,
						remark: this.formSuggest.remark,
					};
					handleCustFeedback(params)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.formSuggest.id = ''
								this.suggestModal = false;
								this.getList(1);
								this.$refs[formSuggest].resetFields();
							} else {
								this.$message.error("请检查是否填写完整");
								return false;
							}
						})
						.catch(error => {
							this.$message.error(this.ConstantData.requestErrorMsg)
						});
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});
		},
		//获取数据字典
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "FEEDBACK_HANDLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.handleStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.filters.pageNum = page;
			var params = {
				feedbackUserName: this.filters.feedbackUserName,
				handleStatus: this.filters.handleStatus,
				tel: this.filters.tel,
				userStatus: this.filters.userStatus,
				createDateBegin:
					this.filters.dateTime != null ? this.filters.dateTime[0] : null,
				createDateEnd: this.filters.dateTime != null ? this.filters.dateTime[1] : null,
				pageNum: page,
				pageSize: this.filters.pageSize
			}
			findCustValueSetList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getList(val.page);
		},
		resetForm () {
			this.$refs.filterForm.resetFields()
			this.getList(1);
		}
	},
	created () {
		this.initDataDictionary();
	},
	mounted () {
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#suggestManagementList {
	width: 100%;
	min-width: 1550px;
	.el-form-item {
		margin-bottom: 0px;
	}
	.userDialog .el-form-item {
		margin-bottom: 15px;
	}
	.el-tooltip__popper {
		font-size: 14px;
		width: 300px;
		height: 200px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 30%;
	min-width: 500px;
}
.search_btn {
	min-width: 250px;
	// min-width: 100px;
	margin-left: 88px;
}

.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
</style>
<style lang="scss" >
#suggestManagementList {
	width: 100%;
	min-width: 1550px;
}
 .el-tooltip__popper{
    max-width: 400px;
  }
</style>
