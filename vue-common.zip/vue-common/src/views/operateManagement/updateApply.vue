<template>
	<div id="updateApply">
		<headTag :tagName="tagName" />
		<div class="formStyle">
			<el-row class="importToolbar">
				<el-col :span="24">
					<el-button size="mini" type="primary" class="rightBtn" @click="cancelBack">返回</el-button>
					<el-button
						size="mini"
						type="primary"
						class="rightBtn"
						:loading="loadingBtn"
						@click="submitForm('applyForm')"
						v-if="isEdit"
					>保存</el-button>
					<el-button
						type="primary"
						size="mini"
						@click="editDispatchForm"
						class="rightBtn"
						v-if="!isEdit"
					>修改</el-button>
				</el-col>
				<el-form
					:inline="false"
					:model="applyForm"
					:rules="applyRules"
					ref="applyForm"
					label-width="135px"
				>
					<el-col class="form-item">
						<el-form-item label="申请人" prop="applyName">
							<span v-if="isEdit == false">{{applyForm.applyName}}</span>
							<span v-if="isEdit == true">
								<el-input size="mini" v-model="applyForm.applyName" clearable placeholder="请输入申请人" />
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="联系方式" prop="applyTel">
							<span v-if="isEdit == false">{{applyForm.applyTel}}</span>
							<span v-if="isEdit == true">
								<el-input
									size="mini"
									v-model="applyForm.applyTel"
									clearable
									placeholder="请输入申请人联系方式"
									maxlength="20"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-itemAssess">
						<el-form-item label="评估类型" prop="assessType">
							<span v-if="isEdit == false">{{applyForm.assessTypeValue}}</span>
							<span v-if="isEdit == true">
								<el-radio-group size="mini" v-model="applyForm.assessType">
									<el-radio
										v-for="item in assessTypeOptions"
										:key="item.value"
										:label="item.value"
									>{{item.name}}</el-radio>
								</el-radio-group>
								<!-- <el-select size="mini" v-model="applyForm.assessType" clearable placeholder="请选择">
									<el-option
										v-for="item in assessTypeOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									></el-option>
								</el-select>-->
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="性别" prop="applyGender">
							<span v-if="isEdit == false">{{applyForm.applyGenderValue}}</span>
							<span v-if="isEdit == true">
								<el-select size="mini" v-model="applyForm.applyGender" clearable placeholder="请选择">
									<el-option
										v-for="item in sexOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									></el-option>
								</el-select>
								<!-- <el-radio-group size="mini" v-model="applyForm.applyGender">
									<el-radio v-for="item in sexOptions" :key="item.value" :label="item.value">{{item.name}}</el-radio>
								</el-radio-group>-->
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="所在区域" required>
							<span
								v-if="isEdit == false"
							>{{applyForm.liveProvinceName}}{{applyForm.liveCityName}}{{applyForm.liveDistrictName}}</span>
							<span v-if="isEdit">
								<AddressAutocomplete
									ref="liveAddress"
									:address="{
                            provinceCode:applyForm.liveProvinceCode,
                            provinceName:applyForm.liveProvinceName,
                            cityCode: applyForm.liveCityCode,
                            cityName: applyForm.liveCityName,
                            districtCode:applyForm.liveDistrictCode,
                            districtName:applyForm.liveDistrictName
                            }"
									@selectedProvinceListener="selectedWorkProvinceListener"
									@selectedCityListener="selectedWorkCityListener"
									@selectedDistrictListener="selectedWorkDistrictListener"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="详细地址" prop="liveDetailAddress">
							<span v-if="isEdit == false">{{applyForm.liveDetailAddress}}</span>
							<span v-if="isEdit == true">
								<el-input
									size="mini"
									v-model="applyForm.liveDetailAddress"
									clearable
									placeholder="请输入详细地址"
									maxlength="20"
								/>
							</span>
						</el-form-item>
					</el-col>

					<el-col class="form-item">
						<el-form-item label="提交人" prop="customerName">
							<span v-if="isEdit == false">{{applyForm.customerName}}</span>
							<span v-if="isEdit == true">
								<el-input
									size="mini"
									:disabled="isDisabled"
									v-model="applyForm.customerName"
									clearable
									placeholder="请输入提交人"
									maxlength="20"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="提交人联系方式" prop="customerTel">
							<span v-if="isEdit == false">{{applyForm.customerTel}}</span>
							<span v-if="isEdit == true">
								<el-input
									size="mini"
									:disabled="isDisabled"
									v-model="applyForm.customerTel"
									clearable
									placeholder="请输入提交人联系方式"
									maxlength="20"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="身份证号" prop="applyIdCard">
							<span v-if="isEdit == false">{{applyForm.applyIdCard}}</span>
							<span v-if="isEdit == true">
								<el-input
									size="mini"
									v-model="applyForm.applyIdCard"
									clearable
									placeholder="请输入身份证号"
									maxlength="18"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="处理状态" prop="handleStatus">
							<span v-if="isEdit == false">
								{{applyForm.handleStatusValue }}
								<span
									v-if="applyForm.assessGrade!==''"
								>{{applyForm.assessGrade}}</span>
							</span>
							<span v-if="isEdit == true">
								<el-select
									v-model="applyForm.handleStatus"
									size="mini"
									@change="selectChange"
									style="width:100px;"
									clearable
									placeholder="请选择"
								>
									<el-option
										v-for="item in handleStatusOptions"
										:key="item.value"
										:label="item.name"
										:value="item.value"
									/>
								</el-select>
								<el-select
									v-if="isShow"
									size="mini"
									style="width:100px;"
									v-model.trim="applyForm.assessGrade"
									clearable
									placeholder="请选择评估等级"
								>
									<el-option
										v-for="item in options"
										:key="item.value"
										:label="item.label"
										:value="item.value"
									></el-option>
								</el-select>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="备注">
							<span v-if="isEdit == false">{{applyForm.remark}}</span>
							<span v-if="isEdit == true">
								<el-input
									style="width:300px;"
									type="textarea"
									maxlength="100"
									show-word-limit
									resize="none"
									rows="6"
									class="remark-style"
									size="mini"
									v-model="applyForm.remark"
									clearable
									placeholder="请输入备注"
								/>
							</span>
						</el-form-item>
					</el-col>
					<el-col class="form-item-product">
						<el-form-item label="身份证照片" prop="applyIdCardPhoto" ref="applyIdCardPhoto">
							<!-- <span v-if="isEdit == false">
								<span v-if="idCardFileList.length>0">
									<span style="width:100px;height:100px;" v-for="item in idCardFileList" :key="item.id">
										<img :src="item.url ? item.url : '' " style="width:100px;height:100px;margin-left:5px;" alt />
									</span>
								</span>
							</span>-->
							<!-- <span v-if="isEdit == true"> -->
							<el-upload
								size="mini"
								ref="uploadBrief"
								:class="{hideBriefImg:hideBriefUpload}"
								:action="actionUrl"
								list-type="picture-card"
								:on-success="handleBriefChange"
								accept="image/png, image/gif, image/jpg, image/jpeg"
								multiple
								:limit="2"
								:file-list="idCardFileList"
							>
								<i class="el-icon-plus"></i>
								<div slot="file" slot-scope="{file}">
									<img class="el-upload-list__item-thumbnail" :src="file.url" alt />
									<span class="el-upload-list__item-actions">
										<span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
											<i class="el-icon-zoom-in"></i>
										</span>
										<span class="el-upload-list__item-delete" @click="handleDownload(file)">
											<i class="el-icon-download"></i>
										</span>
										<span v-if="disabled" class="el-upload-list__item-delete" @click="handleRemove(file)">
											<i class="el-icon-delete"></i>
										</span>
									</span>
								</div>
								<span v-if="!disabled">
									<div slot="tip" class="el-upload__tip">仅限上传2张图片！</div>
								</span>
							</el-upload>
							<el-dialog :visible.sync="dialogVisible">
								<el-image style="width: 100%; height: 600px" :src="dialogImageUrl"></el-image>
							</el-dialog>
							<span v-if="idCardFileList.length > 0">
								<div v-for="(file,index) in idCardFileList" :key="index">
									<el-tooltip class="itemToptip" effect="dark" :content="file.name" placement="bottom">
										<div>{{file.name}}</div>
									</el-tooltip>
								</div>
							</span>
							<!-- </span> -->
						</el-form-item>
					</el-col>
				</el-form>
			</el-row>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import AddressAutocomplete from "components/AddressAutocomplete";
import { findValueBySetCode } from "api/common/index.js";
import { changeYMD } from "utils";
import { validateAge, validateIdCard } from "utils/validate";
import {
	getProductApplyById, editProductApply
} from "api/operateManagement/index.js";
export default {
	components: {
		HeadTag,
		AddressAutocomplete,
	},
	props: {},
	data () {
		return {
			tagName: "查看申请详情",
			isEdit: false,
			id: '',
			dialogVisible: false,
			dialogImageUrl: '',
			options: [{
				value: '二级',
				label: '二级'
			}, {
				value: '三级',
				label: '三级'
			}, {
				value: '四级',
				label: '四级'
			}, {
				value: '五级',
				label: '五级'
			}, {
				value: '六级',
				label: '六级'
			}
			],
			//身份证上传
			idCardFileList: [],
			assessGradeOptions: [],
			hideBriefUpload: true,
			disabled: false,
			//上传阿里云地址
			actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
			//按钮加载
			loadingBtn: false,
			dialogVisible: false,
			handleStatusOptions: [],
			applyForm: {
				applyName: "",
				applyTel: "",
				applyIdCard: "",
				liveProvinceName: "",
				liveCityName: "",
				liveDistrictName: "",
				liveSubdistrictName: "",
				liveDetailAddress: "",
				customerTel: "",
				handleStatus: "",
				assessType: "",
				assessTypeValue:'',
				applyGender: "",
				liveProvinceCode: "",
				liveCityCode: "",
				liveDistrictCode: "",
				customerName: "",
				applyIdCardPhoto: "",
				assessGrade: '',
				remark: ""
			},
			applyRules: {
				applyName: [
					{
						required: true,
						message: "请输入申请人",
						trigger: "blur"
					}
				],
				applyTel: [
					{
						required: true,
						message: "请输入申请人联系方式",
						trigger: "blur"
					}
				],
				applyIdCard: [
					{
						required: true,
						message: "请输入身份证号",
						trigger: "blur"
					},
					{
						validator: validateIdCard
					}
				],
				assessType: [
					{
						required: true,
						message: "请选择评估类型",
						trigger: "change"
					}
				],
				applyGender: [
					{
						required: true,
						message: "请选择性别",
						trigger: "change"
					},
				],
				liveDetailAddress: [
					{
						required: true,
						message: "请输入详情地址",
						trigger: "blur"
					},
				],
				applyIdCardPhoto: [
					{
						required: true,
						message: "请上传身份证照片",
						trigger: "change"
					},
				],
				customerName: [
					{
						required: true,
						message: "请输入提交人",
						trigger: "blur"
					}
				],
				customerTel: [
					{
						required: true,
						message: "请输入提交人联系方式",
						trigger: "blur"
					}
				],
				handleStatus: [
					{
						required: true,
						message: "请选择处理状态",
						trigger: "change"
					}
				]
			},
			sexOptions: [],
			assessTypeOptions: [],
			isShow: false,
		};
	},
	watch: {},
	computed: {},
	methods: {
		selectChange (val) {
			console.log(val)
			if (val == '30') {
				this.isShow = true
			} else {
				this.isShow = false
				this.applyForm.assessGrade=''
			}

		},
		handlePictureCardPreview (file) {
			this.dialogImageUrl = file.url;
			this.dialogVisible = true;
		},
		handleDownload (file) {
			window.open(file.url, "_blank");
		},
		handleRemove (file, inputFileMainList) {
			let fileList = this.idCardFileList;
			let index = fileList.findIndex(fileItem => {
				return fileItem.uid === file.uid;
			});
			let deletArr = fileList.splice(index, 1); //删除选中的元素,this.idCardFileList返回剩余的元素;
			let checkoutPhotos = "";
			this.idCardFileList.map(items => {
				checkoutPhotos += items.url + ",";
			});
			//去掉最后一个逗号(如果不需要去掉，就不用写)
			if (checkoutPhotos.length > 0) {
				checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
			}
			this.hideBriefUpload = false;
			this.applyForm.applyIdCardPhoto = checkoutPhotos;
		},
		handleBriefChange (response, file, fileList) {
			console.log(response, file, fileList)
			if (response) {
				this.$refs.applyIdCardPhoto.clearValidate()
				let urls = [];
				this.idCardFileList = [];
				if (fileList.length == 2) {
					this.hideBriefUpload = true;
				}
				fileList.forEach(item => {
					if (item.response) {
						urls.push(item.response.responseData);
						this.idCardFileList.push({
							name: item.name,
							status: item.status,
							type: item.type,
							uid: item.uid,
							url: item.response.responseData
						});
					} else {
						urls.push(item.url);
						this.idCardFileList.push(item);
					}
				});
				let checkoutPhotos = "";
				urls.forEach(items => {
					checkoutPhotos += items + ",";
				});
				//去掉最后一个逗号(如果不需要去掉，就不用写)
				if (checkoutPhotos.length > 0) {
					checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
				}
				this.applyForm.applyIdCardPhoto = checkoutPhotos;
			}
		},
		//获取数据字典
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "ASSESS_GRADE" })
				.then(response => {
					if (response.data.statusCode === "200") {
						this.assessGradeOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
				});
			// 性别
			findValueBySetCode({ valueSetCode: "GENDER" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.sexOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "APPLY_HANDLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.handleStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "APPLY_ASSESS_TYPE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.assessTypeOptions = response.data.responseData;
						console.log(this.assessTypeOptions)
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		cancelBack () {
			this.$router.back();
		},
		//加载本市地址省市区
		selectedWorkProvinceListener (obj) {
			this.applyForm.liveProvinceName = obj.provinceName;
			this.applyForm.liveProvinceCode = obj.provinceCode;
			this.applyForm.liveCityName = "";
			this.applyForm.liveCityCode = "";
			this.applyForm.liveDistrictName = "";
			this.applyForm.liveDistrictCode = "";
		},
		selectedWorkCityListener (obj) {
			this.applyForm.liveCityName = obj.cityName;
			this.applyForm.liveCityCode = obj.cityCode;
			this.applyForm.liveDistrictName = "";
			this.applyForm.liveDistrictCode = "";
		},
		selectedWorkDistrictListener (obj) {
			this.applyForm.liveDistrictName = obj.districtName;
			this.applyForm.liveDistrictCode = obj.districtCode;
		},
		// 点击编辑显示编辑框，地址组件载入初始化数据
		editDispatchForm () {
			this.isEdit = true;
			this.isDisabled = true
			this.hideBriefUpload = false;
			this.disabled = true;
			if (this.applyForm.handleStatus == '30') {
				this.isShow = true
			} else {
				this.isShow = false
				this.applyForm.assessGrade=''
			}
			this.getProductApplyById();;
			// setTimeout(() => {
			//   this.applyForm = Object.assign({}, this.applyForm); //模拟发请求效果
			// }, 0);
			// this.findDispatchDetail();//再次请求数据替换applyForm，造成address对象改变，触发地址组件watch，为组件赋值
		},
		submitForm (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					if (
						!(
							this.applyForm.liveProvinceName &&
							this.applyForm.liveCityName &&
							this.applyForm.liveDistrictName
						)
					) {
						this.$message.error("请选择区域");
						return false;
					}
					this.loadingBtn = true;
					let params = { ...this.applyForm };
					editProductApply(params)
						.then(response => {
							this.loadingBtn = false;
							if (
								response.data.statusCode === 200 ||
								response.data.statusCode === "200"
							) {
								this.$message.success("保存成功");
								this.isEdit = false;
								this.disabled = false;
								this.hideBriefUpload = true;
								this.getProductApplyById();
							} else {
								this.$message.error(response.data.statusMsg);
							}
						})
						.catch(error => {
							this.loadingBtn = false;
							console.log("editProductApply:" + error);
						});
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			});
		},
		// 根据id查询详情
		getProductApplyById () {
			let params = { id: this.id };
			getProductApplyById(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.applyForm = Object.assign({}, response.data.responseData, {
							liveProvinceName: response.data.responseData.liveProvinceName,
							liveCityName: response.data.responseData.liveCityName,
							liveDistrictName: response.data.responseData.liveDistrictName,
							liveProvinceCode: response.data.responseData.liveProvinceCode,
							liveCityCode: response.data.responseData.liveCityCode,
							liveDistrictCode: response.data.responseData.liveDistrictCode
						});
						if (
							this.applyForm.applyIdCardPhoto !==
							undefined &&
							this.applyForm.applyIdCardPhoto !==
							"undefined" &&
							this.applyForm.applyIdCardPhoto
						) {
							// debugger;
							let photoUrl = this.applyForm.applyIdCardPhoto;
							this.idCardFileList = [];
							let photos = photoUrl.split(",");
							if (photos.length == 2) {
								this.hideBriefUpload = true;
							}
							for (let i = 0; i < photos.length; i++) {
								this.idCardFileList.push({
									name: decodeURI(photos[i])
										.toString()
										.split("com/")[1]
										.split("?Expires")[0]
										.substr(18),
									url: photos[i]
								});
							}
						}
					} else {
						this.$message.error(response.data.statusMsg);
					}
				})
				.catch(error => {
					console.log("getProductApplyById:" + error);
				});
		}
	},

	created () {
		// var param = this.$route.query;
		// this.id = param.id;
		// this.getProductApplyById();
		// this.initDataDictionary();

	},
	mounted () {
	},
	activated () {
		this.$refs.applyIdCardPhoto.clearValidate()
		var param = this.$route.query;
		this.id = param.id;
		this.getProductApplyById();
		this.initDataDictionary();

	},
	deactivated () {
		this.isEdit = false;
		this.disabled = false;
	}
};
</script>
<style lang="scss" scoped>
#updateApply {
	width: 100%;
	min-width: 1200px;
	.el-form-item {
		margin-bottom: 15px;
	}
}
.el-input {
	width: 200px;
}

.el-select {
	width: 200px;
}
.el-cascader {
	width: 200px;
}
.el-autocomplete {
	width: 200px;
}
.remark-style {
	width: 200px;
}
.formStyle {
	margin: 0 20px 20px;
	background-color: #ffffff;
	border-radius: 10px;
}
.importToolbar {
	padding: 20px 0px 10px 20px;
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
}

.el-date-editor--daterange.el-input__inner {
	width: 250px;
}
.form-item {
	width: 30%;
	min-width: 300px;
	// height: 40px;
}
.form-itemSex {
	min-width: 300px;
	height: 40px;
}
.el-autocomplete-suggestion__wrap {
	max-height: 380px;
}
.itemToptip {
	position: relative;
	font-size: 12px;
	width: 140px;
	height: 30px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	float: left;
	margin-top: -25px;
	line-height: 30px;
	padding-right: 10px;
}
.form-item-product {
	margin-bottom: 40px;
	width: 100%;
}
.el-upload__tip {
	text-align: left;
	width: 130px;
	line-height: 15px;
}
</style>
<style lang="scss">
#updateApply {
	.form-itemAssess {
		width: 30%;
		min-width: 300px;
		.el-form-item {
			.el-form-item__content {
				line-height: 42px !important;
				position: relative !important;
				font-size: 14px !important;
				height: 42px !important;
			}
		}
	}
	.hideBriefImg .el-upload--picture-card {
		display: none;
	}
	.el-upload--picture-card {
		width: 130px;
		height: 130px;
		line-height: 146px;
	}
	.el-upload-list--picture-card .el-upload-list__item-actions:hover span {
		display: contents;
	}
	.el-upload-list--picture-card .el-upload-list__item {
		width: 130px;
		height: 130px;
	}
}
</style>