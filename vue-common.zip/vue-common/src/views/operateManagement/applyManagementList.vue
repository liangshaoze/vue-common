<template>
	<div id="applyManagementList">
		<!-- 地址标签 -->
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filters" label-width="125px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="申请人" prop="applyName">
							<el-input size="mini" v-model.trim="filters.applyName" placeholder="请输入申请人" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="申请人联系方式" prop="applyTel">
							<el-input size="mini" v-model.trim="filters.applyTel" placeholder="请输入申请人联系方式" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="处理状态" prop="handleStatus">
							<el-select size="mini" v-model.trim="filters.handleStatus" clearable placeholder="请选择状态">
								<el-option
									v-for="item in spreadOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="所在区域" prop="liveDetailAddress">
							<el-input
								size="mini"
								v-model.trim="filters.liveDetailAddress"
								placeholder="请输入所在区域"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="提交人联系方式" prop="customerTel">
							<el-input size="mini" v-model.trim="filters.customerTel" placeholder="请输入提交人联系方式" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="申请时间" prop="dataTime">
							<el-date-picker
								v-model.trim="filters.dataTime"
								clearable
								size="mini"
								format="yyyy-MM-dd"
								value-format="yyyy-MM-dd"
								type="daterange"
								style="width: 320px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<!-- 列表数据 -->
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<!-- <el-button size="mini" type="primary" icon="el-icon-plus" @click="insert()">新增</el-button> -->
				</el-col>
			</el-row>
			<el-table
				:data="tableData"
				:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
				element-loading-text="拼命加载中"
				highlight-current-row
				size="mini"
				stripe
				style="width:100%;"
				v-loading="listLoading"
			>
				<el-table-column label="申请人" min-width="100" prop="applyName"></el-table-column>
				<el-table-column label="申请人联系方式" min-width="100" prop="applyTel"></el-table-column>
				<el-table-column label="所在区域">
					<template slot-scope="scope">
						<span
							v-if="scope.row.liveDetailAddress != ''"
						>{{scope.row.liveProvinceName}}{{scope.row.liveCityName}}{{scope.row.liveDistrictName}}{{scope.row.liveDetailAddress}}</span>
					</template>
				</el-table-column>
				<el-table-column label="提交人联系方式" min-width="100" prop="customerTel"></el-table-column>
				<el-table-column label="申请时间" min-width="100">
					<template slot-scope="scope">
						<span v-if="scope.row.createDate">{{scope.row.createDate.substring(-1,10)}}</span>
					</template>
				</el-table-column>
				<el-table-column label="处理状态" min-width="100" prop="handleStatusValue"></el-table-column>
				<el-table-column label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="handleSee(scope.row.id)" size="mini" type="text">查看</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<!--分页-->
				<pagination
					:limit.sync="filters.pageSize"
					:page.sync="filters.pageNum"
					:total="totalCount"
					@pagination="pageChange"
					v-if="totalCount > 0"
				/>
			</el-row>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import {
	findProductApplyList,
} from "api/operateManagement/index.js";
import { findValueBySetCode } from "api/common/index.js";
export default {
	components: {
		HeadTag,
		Pagination,
	},
	props: {},
	data () {
		return {
			tagName: "查看长护险申请",
			totalCount: 0,
			spreadOptions: [],
			//关键字搜索
			filters: {
				handleStatus: "",
				applyName: "",
				applyTel: "",
				liveDetailAddress: "",
				customerTel: '',
				dataTime: '',
				pageNum: 1,
				pageSize: 10
			},
			cancleDisabled: false,
			listLoading: false,
			//列表数据
			tableData: [],
			Loading: false,

		};
	},
	watch: {},
	computed: {},
	methods: {
		handleSee (id) {
			this.$router.push({
				path: "/operateManagement/updateApply",
				query: {
					id: id
				}
			});
		},
		insert () {
		},
		//获取数据字典
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "APPLY_HANDLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.spreadOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.filters.pageNum = page;
			var params = {
				pageNum: page,
				pageSize: this.filters.pageSize,
				handleStatus: this.filters.handleStatus,
				applyName: this.filters.applyName,
				applyTel: this.filters.applyTel,
				liveDetailAddress: this.filters.liveDetailAddress,
				customerTel: this.filters.customerTel,
				createDateB:
					this.filters.dataTime != null ? this.filters.dataTime[0] : null,
				createDateE:
					this.filters.dataTime != null ? this.filters.dataTime[1] : null
			};
			findProductApplyList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getList(val.page);
		},
		resetForm () {
			this.$refs.filterForm.resetFields()
			this.getList(1);
		}
	},
	created () {
		this.initDataDictionary();
	},
	mounted () {
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#applyManagementList {
	width: 100%;
	min-width: 1450px;
	.el-form-item {
		margin-bottom: 0px;
	}
	.userDialog .el-form-item {
		margin-bottom: 15px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.search_btn {
	width: 30%;
	min-width: 295px;
	// min-width: 100px;
	margin-left: 125px;
}

.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
</style>
