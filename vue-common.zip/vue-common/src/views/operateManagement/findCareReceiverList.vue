<template>
  <div id="findCareReceiver">
    <headTag :tagName="tagName"/>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="handleInsert()">新增</el-button>
        </el-col>
      </el-row>
      <!--列表-->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="dataList"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column label="被照护人姓名" min-width="100" prop="careReceiverName"></el-table-column>
        <el-table-column label="联系电话" min-width="100" prop="careReceiverTel"></el-table-column>
        <el-table-column label="身份证号" min-width="150" prop="careReceiverIdCard"></el-table-column>
        <el-table-column label="是您的" min-width="100" prop="careReceiverReletion"></el-table-column>
        <el-table-column label="创建时间" min-width="150" prop="createDate"></el-table-column>
        <el-table-column fixed="right" width="100" label="操作">
          <template slot-scope="scope">
            <span>
              <el-button size="mini" type="text" @click="handleEdit(scope.row)">查看</el-button>
              <el-button size="mini" type="text" @click="handleDelete(scope.row)">删除</el-button>
            </span>
          </template>
        </el-table-column>
      </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.page"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
    </div>

    <!-- 删除被照护人 -->
    <el-dialog
      title="是否删除该被照护人信息？"
      :visible.sync="dialogDelete"
      width="500px"
      :before-close="handleDeleteClose"
      center
    >
      <el-row type="flex" justify="center">
        <h3>如果是请点击确定，否则点击取消</h3>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleDeleteClose()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitDelete()"
        >确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findProductOrderList } from "api/businessService/orderPaymentReview";
export default {
  data() {
    return {
      tagName: "查看被照护人",
      //删除弹窗
      dialogDelete: false,
      currentDeleteCode: "",
      dataList: [],
      listLoading: false,
      //条件查询
      filters: {
        page: 1,
        pageSize: 10
      },
      totalCount: 0
    };
  },
  components: {
    HeadTag,
    Pagination
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page); //改变页码，重新渲染页面
    },
    getList(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize
      };
      this.listLoading = true;
      this.searchLoading = true;
      findProductOrderList(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            this.dataList = response.data.responseData;
            this.totalCount = response.data.totalCount;
            this.listLoading = false;
            this.searchLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findProductOrderList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    //新增被照护人
    handleInsert() {
      this.$router.push({
        path: "/evaluationManagement/addCareReceiver",
        query: {
          type: "insert"
        }
      });
    },
    //查看被照护人
    handleEdit(row) {
      this.$router.push({
        path: "/evaluationManagement/addCareReceiver",
        query: {
          type: "update",
          careReceiverCode: row.careReceiverCode
        }
      });
    },
    handleDelete(row) {
      this.currentDeleteCode = row.careReceiverCode;
      this.dialogDelete = true;
    },
    handleDeleteClose() {
      this.currentDeleteCode = "";
      this.dialogDelete = false;
    },
        submitDelete() {
      var params = {
        careReceiverCode: this.currentDeleteCode
      };
      //   deleteWorkorderScheduleByCheckBox(params)
      //     .then(response => {
      //       if (response.data.statusCode == "200") {
      //         this.$message.success("操作成功");
      //         this.dialogDelete = false;
      //         this.currentDeleteCode = "";
      //         this.getList(1);
      //       } else {
      //         this.$message.error(response.data.statusMsg);
      //         this.currentDeleteCode = "";
      //         return false;
      //       }
      //     })
      //     .catch(error => {
      //       console.log(error);
      //       return false;
      //     });
    }
  },
  created() {},
  mounted() {
    this.getList(1);
  }
};
</script>

<style lang="scss" scoped>
#findCareReceiver {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 305px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.form-itemss {
  width: 30%;
  min-width: 250px;
}
.search_btn {
  min-width: 250px;
  margin-left: 35px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
.fund-order {
  margin: 20px 0;
}
.orderNumber {
  font-size: 20px;
  color: #000;
  margin: 30px 0 30px 0;
}
.el-autocomplete {
  width: 200px;
}
.order_title {
  margin: 20px 0;
  text-align: center;
  font-size: 16px;
  color: #000;
}
</style>
<style lang="scss">
#orderManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
.el-dialog__body {
  padding: 0px 20px;
}
.filter-input {
  width: 100%;
}
#orgSelect .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#orgSelect .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#orgSelect .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content {
  color: #f98c3c;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content i {
  background-color: #f98c3c;
  width: 8px;
  height: 8px;
  display: -webkit-inline-box;
  border-radius: 50%;
  margin-right: 5px;
}
.el-autocomplete-suggestion {
  min-width: 220px;
}
</style>
