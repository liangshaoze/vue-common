<template>
	<div id="labelManagement">
		<!-- 地址标签 -->
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="keyWords" label-width="85px">
				<el-row v-if="activeName=='first'">
					<el-col class="form-item">
						<el-form-item label="分类名称" prop="userTel">
							<el-input size="mini" v-model.trim="keyWords.userTel" placeholder="请输入联系电话" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="使用对象" prop="userStatus">
							<el-input size="mini" v-model.trim="keyWords.userTel" placeholder="请输入联系电话" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row v-if="activeName=='second'">
					<el-col class="form-item">
						<el-form-item label="标签名称" prop="userTel">
							<el-input size="mini" v-model.trim="keyWords.userTel" placeholder="请输入联系电话" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="标签分类" prop="userStatus">
							<el-input size="mini" v-model.trim="keyWords.userTel" placeholder="请输入联系电话" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<!-- 列表数据 -->
		<div class="tableToolbar">
			<el-tabs v-model="activeName" type="card" @tab-click="handleClick">
				<el-tab-pane label="标签分类" name="first">
					<el-row class="tableTopBtn">
						<el-button size="mini" type="primary" @click="addType()">新增分类</el-button>
					</el-row>
					<el-table
						:data="tableData"
						:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
						element-loading-text="拼命加载中"
						highlight-current-row
						size="mini"
						stripe
						style="width:100%;"
						v-loading="listLoading"
					>
						<el-table-column label="分类名称" min-width="100" prop="orgName"></el-table-column>
						<el-table-column label="使用对象" min-width="100" prop="userCode"></el-table-column>
						<el-table-column label="备注" min-width="100" prop="userFullName"></el-table-column>
						<el-table-column label="操作" width="100">
							<template slot-scope="scope">
								<el-button @click="handleDelete(scope.row.userCode)" size="mini" type="text">删除</el-button>
							</template>
						</el-table-column>
					</el-table>
					<!--工具条-->
					<el-row class="pageToolbar">
						<!--分页-->
						<pagination
							:limit.sync="keyWords.pageSize"
							:page.sync="keyWords.pageNum"
							:total="totalCount"
							@pagination="pageChange"
							v-if="totalCount > 0"
						/>
					</el-row>
				</el-tab-pane>
				<el-tab-pane label="标签信息" name="second">
					<el-row class="tableTopBtn">
						<el-button size="mini" type="primary" @click="addLabelInfo()">新增分类</el-button>
					</el-row>
					<el-table
						:data="tableData"
						:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
						element-loading-text="拼命加载中"
						highlight-current-row
						size="mini"
						stripe
						style="width:100%;"
						v-loading="listLoading"
					>
						<el-table-column label="标签名称" min-width="100" prop="orgName"></el-table-column>
						<el-table-column label="所属分类" min-width="100" prop="userCode"></el-table-column>
						<el-table-column label="排序" min-width="100" prop="userFullName"></el-table-column>
						<el-table-column label="备注" min-width="100" prop="userFullName"></el-table-column>
						<el-table-column label="操作" width="100">
							<template slot-scope="scope">
								<el-button @click="handleEdit(scope.row.userCode)" size="mini" type="text">修改</el-button>
								<el-button @click="handleDelete(scope.row.userCode)" size="mini" type="text">删除</el-button>
							</template>
						</el-table-column>
					</el-table>
					<!--工具条-->
					<el-row class="pageToolbar">
						<!--分页-->
						<pagination
							:limit.sync="keyWords.pageSize"
							:page.sync="keyWords.pageNum"
							:total="totalCount"
							@pagination="pageChange"
							v-if="totalCount > 0"
						/>
					</el-row>
				</el-tab-pane>
			</el-tabs>
		</div>
		<!-- 新增标签分类-->
		<el-dialog :visible.sync="labelModal" width="400px" title="新增标签分类" center>
			<el-row type="flex" justify="center">
				<el-form
					:inline="false"
					:model="addLabelForm"
					:rules="addLabelFormRules"
					class="userDialog"
					label-width="100px"
					ref="addLabelForm"
				>
					<el-form-item label="分类名称:" prop="typeName">
						<el-input
							clearable
							maxlength="25"
							placeholder="请输入分类名称"
							size="mini"
							v-model="addLabelForm.typeName"
						></el-input>
					</el-form-item>
					<el-form-item label="使用对象:" prop="userObj">
						<el-select
							size="mini"
							multiple
							v-model.trim="addLabelForm.userObj"
							clearable
							placeholder="请选择使用对象"
						>
							<el-option
								v-for="item in userOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="备注:">
						<el-input
							size="mini"
							type="textarea"
							maxlength="255"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="addLabelForm.tyep"
							clearable
							placeholder="请输入备注"
						></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div class="dialog-footer" slot="footer" style="padding-left:56px;">
				<el-button @click="labelModal = false" size="mini">取 消</el-button>
				<el-button
					:loading="btnLoading"
					style="margin-left:40px;"
					@click="labelTypeSave()"
					size="mini"
					type="primary"
				>确定</el-button>
			</div>
		</el-dialog>
		<!-- 删除弹窗 -->
		<el-dialog :visible.sync="deleteModal" width="400px" title="提示?">
			<el-col style="text-align:center;color#666666；font-size:16px;">此操作将永久删除该条数，是否继续？</el-col>
			<div class="dialog-footer" slot="footer">
				<el-button @click="deleteModal = false" size="mini">取 消</el-button>
				<el-button :loading="Loading" @click="btnDelete()" size="mini" type="primary">确定</el-button>
			</div>
		</el-dialog>
		<!-- 新增标签信息 -->
		<el-dialog :visible.sync="dialogInfo" title="新增标签" center width="500px">
			<el-row type="flex" justify="center">
				<el-form
					:inline="false"
					:model="addLabelInfoForm"
					:rules="addLabelInfoFormRules"
					class="userDialog"
					label-width="100px"
					ref="addLabelInfoForm"
				>
					<el-form-item label="标签名称:" prop="labelName">
						<el-input
							clearable
							placeholder="请输入分类名称"
							maxlength="25"
							size="mini"
							v-model="addLabelInfoForm.labelName"
						></el-input>
					</el-form-item>
					<el-form-item label="所属分类:" prop="category">
						<el-select
							size="mini"
							multiple
							v-model.trim="addLabelForm.category"
							clearable
							placeholder="请选择使用对象"
						>
							<el-option
								v-for="item in userOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="排序:" prop="sort">
						<el-input clearable placeholder="请输入排序" size="mini" v-model="addLabelInfoForm.sort"></el-input>
					</el-form-item>
					<el-form-item label="备注:">
						<el-input
							size="mini"
							type="textarea"
							maxlength="255"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="addLabelInfoForm.remark"
							clearable
							placeholder="请输入备注"
						></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div class="dialog-footer" style="padding-left:56px;" slot="footer">
				<el-button :disabled="cancleDisabled" @click="dialogInfo=false" size="mini">取消</el-button>
				<el-button
					style="margin-left:40px;"
					@click="btnInfo('addLabelInfoForm')"
					size="mini"
					type="primary"
				>确定</el-button>
			</div>
		</el-dialog>
		<!-- 修改标签信息弹窗 -->
		<el-dialog :visible.sync="dialogEdit" title="修改标签" center width="500px">
			<el-row type="flex" justify="center">
				<el-form
					:inline="false"
					:model="addLabelEditForm"
					:rules="addLabelEditFormRules"
					class="userDialog"
					label-width="100px"
					ref="addLabelEditForm"
				>
					<el-form-item label="标签名称:" prop="labelName">
						<el-input clearable placeholder="请输入分类名称" size="mini" v-model="addLabelEditForm.labelName"></el-input>
					</el-form-item>
					<el-form-item label="所属分类:" prop="category">
						<el-select
							size="mini"
							multiple
							v-model.trim="addLabelForm.category"
							clearable
							placeholder="请选择所属分类"
						>
							<el-option
								v-for="item in userOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="排序:" prop="sort">
						<el-input clearable placeholder="请输入排序" size="mini" v-model="addLabelEditForm.sort"></el-input>
					</el-form-item>
					<el-form-item label="备注:">
						<el-input
							size="mini"
							type="textarea"
							maxlength="100"
							show-word-limit
							resize="none"
							rows="4"
							class="remark-style"
							v-model="addLabelEditForm.remark"
							clearable
							placeholder="请输入备注"
						></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div class="dialog-footer" slot="footer" style="padding-left:56px;">
				<el-button :disabled="cancleDisabled" @click="cancelEdit('addLabelEditForm')" size="mini">取消</el-button>
				<el-button
					@click="btnEdit('addLabelEditForm')"
					style="margin-left:40px;"
					size="mini"
					type="primary"
				>保存</el-button>
			</div>
		</el-dialog>
	</div>
</template>
<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";

import {
	findSysUserList,
	editSysUser,
	getSysUserByCode,
	findSysUserMenus,
	editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
import { validateTel } from "@/utils/validate";
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget"
import { findValueBySetCode } from "api/common/index.js";
import { get } from "http";
export default {
	components: {
		HeadTag,
		Pagination,
		CommonPropertyWidget
	},
	props: {},
	data () {

		return {
			tagName: "标签管理",
			activeName: 'first',
			addLabelForm: {
				typeName: '',
				userObj: ''
			},
			addLabelFormRules: {
				typeName: [
					{ required: true, message: '请输入分类名称', trigger: 'blur' },
				],
				userObj: [
					{ required: true, message: '请选择使用对象', trigger: 'change' }
				],

			},
			addLabelEditForm: {
				labelName: '',
				category: '',
				sort: '',
				remark: ''

			},
			addLabelEditFormRules: {
				labelName: [
					{ required: true, message: '请输入标签名称', trigger: 'blur' },
				],
				category: [
					{ required: true, message: '请选择所属分类', trigger: 'change' }
				],
				sort: [
					{ required: true, message: '请输入排序', trigger: 'blur' },
				],
			},
			addLabelInfoForm: {
				labelName: '',
				category: '',
				sort: '',
				remark: ''

			},
			addLabelInfoFormRules: {
				labelName: [
					{ required: true, message: '请输入分类名称', trigger: 'blur' },
				],
				category: [
					{ required: true, message: '请选择所属分类', trigger: 'change' }
				],
				sort: [
					{ required: true, message: '请输入排序', trigger: 'blur' },
				],

			},
			deleteModal: false,
			dialogEdit: false,
			dialogInfo: false,
			Loading: false,
			userOptions: [],
			totalCount: 0,
			statusOptions: [],
			dialogVisible: false,
			//关键字搜索
			keyWords: {
				userCode: "",
				userTel: "",
				userFullName: "",
				userStatus: "",
				orgName: '',
				orgCode: '',
				pageNum: 1,
				pageSize: 10
			},

			cancleDisabled: false,
			listLoading: false,
			//列表数据
			tableData: [],
			//权限弹窗
			labelModal: false,
			btnLoading: false,
			multipleSelection: [],
			checkedKeys: [], //该数组回显数据根据所对应的ID  进行默认勾选 (:default-checked-keys 这个) 和 (node-key="id") 这个两个并存
			currCheckedKeys: [], //当前选中的keys  后端返回
			userMenus: [], //传给后端的选中值
			defaultProps: {
				children: "childMenus",
				label: "menuName"
			},
			authCode: "",
			treeData: [], // 该数组是存储 要渲染的树形结构数据
			//修改弹窗
			dialogModify: false,
			formUserMessage: {
				confirmPassword: "",
				password: "",
				userTel: ""
			},

		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClick (tab, event) {
			console.log(tab, event);
		},
		addType () {
			this.labelModal = true
		},
		handleDelete () {
			this.deleteModal = true

		},
		//获取数据字典
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "USER_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.statusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.keyWords.pageNum = page;
			findSysUserList(this.keyWords)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.keyWords.page = val.page;
			this.keyWords.pageSize = val.limit;
			this.getList(val.page);
		},

		//根据userCode查询用户信息
		modify (userCode) {
			this.dialogModify = true;
			var params = {
				userCode: userCode
			};
			getSysUserByCode(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.formUserMessage = response.data.responseData;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//修改用户信息
		btnEdit (formUserMessage) {
			this.$refs[formUserMessage].validate(valid => {
				if (valid) {
					editSysUser(this.formUserMessage)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.$refs[formUserMessage].resetFields();
								this.dialogModify = false;
								this.getList(1);
							} else {
								this.$message.error("操作失败");
								return false;
							}
						})
						.catch(error => {
							console.log(error);
						});
				} else {
					this.$message.error("请输入必填内容");
					console.log("error submit!!");
					return false;
				}
			});
		},
		cancelEdit (formUserMessage) {
			this.$refs[formUserMessage].resetFields();
			this.dialogEdit = false;
		},
		addLabelInfo () {
			this.dialogInfo = true

		},
		//权限操作
		handleEdit (userCode) {
			this.authCode = userCode;
			this.dialogEdit = true;
			var params = {
				userCode: userCode
			};
			findSysUserMenus(params)
				.then(response => {
					if (response.data.statusCode == 200) {


					}
				})
				.catch(error => {
					console.log(error);
				});
		},

		handleClose () {
			this.labelModal = false;
		},

		resetForm () {
			this.$refs.filterForm.resetFields()
			this.getList(1);
		}
	},
	created () {
		this.initDataDictionary();
	},
	mounted () {
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#labelManagement {
	width: 100%;
	min-width: 1024px;
	.el-form-item {
		margin-bottom: 0px;
	}
	.userDialog .el-form-item {
		margin-bottom: 15px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}

.search_btn {
	width: 30%;
	min-width: 295px;
	// min-width: 100px;
	margin-left: 90px;
}
.tableToolbar {
	background: #fff;
	border-radius: 10px;
	margin: 0px 20px 20px 20px;
	padding: 26px 20px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 20px 0px;
}
</style>
