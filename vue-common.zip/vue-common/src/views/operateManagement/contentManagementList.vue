<template>
	<div id="contentManagement">
		<!-- 地址标签 -->
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="keyWords" label-width="85px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="标题" prop="userCode">
							<el-input size="mini" v-model.trim="keyWords.userCode" placeholder="请输入标题" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="分类" prop="userStatus">
							<el-select size="mini" v-model.trim="keyWords.userStatus" clearable placeholder="请选择状态">
								<el-option
									v-for="item in classOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="分布状态" prop="userStatus">
							<el-select size="mini" v-model.trim="keyWords.userStatus" clearable placeholder="请选择状态">
								<el-option
									v-for="item in spreadOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="标签" prop="userTel">
							<el-input size="mini" v-model.trim="keyWords.userTel" placeholder="请输入标签" clearable></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="发布时间" prop="planDate">
							<el-date-picker
								v-model.trim="keyWords.planDate"
								clearable
								size="mini"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								type="datetimerange"
								style="width: 290px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row></el-row>
			</el-form>
		</div>

		<!-- 列表数据 -->
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="insert()">新增</el-button>
				</el-col>
			</el-row>
			<el-table
				:data="tableData"
				:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
				element-loading-text="拼命加载中"
				highlight-current-row
				size="mini"
				stripe
				style="width:100%;"
				v-loading="listLoading"
			>
				<el-table-column label="序号" min-width="100" prop="orgName"></el-table-column>
				<el-table-column label="标题" min-width="100" prop="userCode"></el-table-column>
				<el-table-column label="分类" min-width="100" prop="userFullName"></el-table-column>
				<el-table-column label="标签" min-width="100" prop="userTel"></el-table-column>
				<el-table-column label="发布状态" min-width="50" prop="role">
					<template slot-scope="scope">
						<span v-if="scope.row.userStatus == 10">正常</span>
						<span v-if="scope.row.userStatus == 20">停用</span>
					</template>
				</el-table-column>
				<el-table-column label="备注" min-width="100" prop="userTel"></el-table-column>
				<el-table-column label="创建时间" min-width="100" prop="userTel"></el-table-column>
				<el-table-column label="发布时间" min-width="100" prop="userTel"></el-table-column>
				<el-table-column label="创作者" min-width="100" prop="userTel"></el-table-column>
				<el-table-column label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="handleRelease(scope.row.userCode)" size="mini" type="text">立即发布</el-button>
						<el-button @click="handleEdit(scope.row.userCode)" size="mini" type="text">修改</el-button>
						<el-button @click="handleDelete(scope.row.userCode)" size="mini" type="text">删除</el-button>
					</template>
				</el-table-column>
			</el-table>

			<!--工具条-->
			<el-row class="pageToolbar">
				<!--分页-->
				<pagination
					:limit.sync="keyWords.pageSize"
					:page.sync="keyWords.pageNum"
					:total="totalCount"
					@pagination="pageChange"
					v-if="totalCount > 0"
				/>
			</el-row>
		</div>
		<!--立即发布弹窗-->
		<el-dialog :visible.sync="releaseModal" width="400px" title="是否立即发布该素材？">
			<el-col style="text-align:center;">如果是请点击确定，否则点击取消</el-col>
			<div class="dialog-footer" slot="footer">
				<el-button @click="releaseModal = false" size="mini">取 消</el-button>
				<el-button
					:loading="Loading"
					style="margin-left:40px;"
					@click="btnDefine()"
					size="mini"
					type="primary"
				>确定</el-button>
			</div>
		</el-dialog>
		<!-- 删除弹窗 -->
		<el-dialog :visible.sync="deleteModal" width="400px" title="是否删除该素材?">
			<el-col style="text-align:center;">如果是请点击确定，否则点击取消</el-col>
			<div class="dialog-footer" slot="footer">
				<el-button @click="deleteModal = false" size="mini">取 消</el-button>
				<el-button
					:loading="Loading"
					style="margin-left:40px;"
					@click="btnDelete()"
					size="mini"
					type="primary"
				>确定</el-button>
			</div>
		</el-dialog>
		<!-- 修改操作弹窗 -->
		<el-dialog :visible.sync="dialogEdit" title="修改用户信息" center width="500px">
			<el-row type="flex" justify="center">
				<el-form
					:inline="false"
					:model="formUserMessage"
					:rules="rules"
					class="userDialog"
					label-width="100px"
					ref="formUserMessage"
				>
					<el-form-item label="员工编号:">
						<el-input
							clearable
							disabled="disabled"
							placeholder="请输入员工编号"
							size="mini"
							v-model="formUserMessage.userCode"
						></el-input>
					</el-form-item>
					<el-form-item label="员工姓名:">
						<el-input
							clearable
							disabled="disabled"
							placeholder="请输入员工姓名"
							size="mini"
							v-model="formUserMessage.userFullName"
						></el-input>
					</el-form-item>
					<el-form-item label="联系电话:">
						<el-input
							clearable
							disabled="disabled"
							placeholder="请输入联系电话"
							size="mini"
							v-model="formUserMessage.userTel"
							maxlength="11"
						></el-input>
					</el-form-item>
					<el-form-item label="登录密码:" prop="password">
						<el-input clearable placeholder="请输入登录密码" size="mini" v-model="formUserMessage.password"></el-input>
					</el-form-item>
					<el-form-item label="确认密码:" prop="confirmPassword">
						<el-input clearable placeholder="请确认密码" size="mini" v-model="formUserMessage.confirmPassword"></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div class="dialog-footer" slot="footer">
				<el-button :disabled="cancleDisabled" @click="cancleModify('formUserMessage')" size="mini">取消</el-button>
				<el-button
					style="margin-left:40px;"
					@click="roleModifySubmit('formUserMessage')"
					size="mini"
					type="primary"
				>确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import OrgSelect from "components/OrgSelect";

import {
	findSysUserList,
	editSysUser,
	getSysUserByCode,
	findSysUserMenus,
	editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
import { validateTel } from "@/utils/validate";
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget"
import { findValueBySetCode } from "api/common/index.js";
import { get } from "http";
export default {
	components: {
		HeadTag,
		Pagination,
		OrgSelect,
		CommonPropertyWidget
	},
	props: {},
	data () {
		var validatePass = (rule, value, callback) => {
			if (value === "") {
				callback(new Error("请输入密码"));
			} else {
				if (this.formUserMessage.confirmPassword !== "") {
					this.$refs.formUserMessage.validateField("checkPass");
				}
				callback();
			}
		};
		var validatePass2 = (rule, value, callback) => {
			if (value === "") {
				callback(new Error("请再次输入密码"));
			} else if (value !== this.formUserMessage.password) {
				callback(new Error("两次输入密码不一致!"));
			} else {
				callback();
			}
		};
		return {
			tagName: "内容管理",
			totalCount: 0,
			classOptions: [],
			spreadOptions: [],
			dialogVisible: false,
			//关键字搜索
			keyWords: {
				userCode: "",
				userTel: "",
				userFullName: "",
				userStatus: "",
				orgName: '',
				orgCode: '',
				pageNum: 1,
				pageSize: 10
			},
			cancleDisabled: false,
			listLoading: false,
			//列表数据
			tableData: [],
			deleteModal: false,
			//权限弹窗
			releaseModal: false,
			Loading: false,
			multipleSelection: [],
			checkedKeys: [], //该数组回显数据根据所对应的ID  进行默认勾选 (:default-checked-keys 这个) 和 (node-key="id") 这个两个并存
			currCheckedKeys: [], //当前选中的keys  后端返回
			userMenus: [], //传给后端的选中值
			defaultProps: {
				children: "childMenus",
				label: "menuName"
			},
			authCode: "",
			treeData: [], // 该数组是存储 要渲染的树形结构数据
			//修改弹窗
			dialogEdit: false,
			formUserMessage: {
				confirmPassword: "",
				password: "",
				userTel: ""
			},
			rules: {
				userTel: [
					{
						required: true,
						message: "请输入联系电话",
						trigger: "blur"
					},
					{ validator: validateTel }
				],
				password: [
					{
						type: "string",
						min: 1,
						max: 20,
						message: "密码不能为空",
						trigger: "blur",
						required: true
					},
					{ validator: validatePass, trigger: "blur" }
				],
				confirmPassword: [
					{
						type: "string",
						min: 1,
						max: 20,
						message: "确认密码不能为空",
						trigger: "blur",
						required: true
					},
					{ validator: validatePass2, trigger: "blur" }
				]
			}
		};
	},
	watch: {},
	computed: {},
	methods: {
		handleRelease () {
			this.releaseModal = true

		},
		handleDelete () {
			this.deleteModal = true

		},
		insert () {
			this.$router.push({
				path: "/evaluationManagement/addcontent"
			});
		},
		//获取数据字典
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "USER_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.statusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.keyWords.pageNum = page;
			findSysUserList(this.keyWords)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.keyWords.page = val.page;
			this.keyWords.pageSize = val.limit;
			this.getList(val.page);
		},

		//根据userCode查询用户信息
		modify (userCode) {
			this.dialogEdit = true;
			var params = {
				userCode: userCode
			};
			getSysUserByCode(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.formUserMessage = response.data.responseData;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//修改用户信息
		roleModifySubmit (formUserMessage) {
			this.$refs[formUserMessage].validate(valid => {
				if (valid) {
					editSysUser(this.formUserMessage)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								this.$refs[formUserMessage].resetFields();
								this.dialogEdit = false;
								this.getList(1);
							} else {
								this.$message.error("操作失败");
								return false;
							}
						})
						.catch(error => {
							console.log(error);
						});
				} else {
					this.$message.error("请输入必填内容");
					console.log("error submit!!");
					return false;
				}
			});
		},
		cancleModify (formUserMessage) {
			this.$refs[formUserMessage].resetFields();
			this.dialogEdit = false;
		},
		//获取选中的Key 后端选中的keys currCheckedKeys  菜单选中的keys checkedKeys
		getCheckedParamsKeys (treeData) {
			let arrMenuList = Object.keys(this.$refs.userTree.store.nodesMap);
			treeData.map(v => {
				if (v.isHave == "1") {
					this.currCheckedKeys.push(v.menuCode);
					if (v.childMenus) {
						this.getCheckedParamsKeys(v.childMenus);
						//判断选中和后台菜单数量是否相等
						// if (this.currCheckedKeys.length == arrMenuList.length) {
						//   this.checked = true;
						// }
					} else {
						this.checkedKeys.push(v.menuCode);
					}
				}
				// else {
				//   this.checked = false;
				// }
			});
		},
		//权限操作
		permission (userCode) {
			this.authCode = userCode;
			this.releaseModal = true;
			var params = {
				userCode: userCode
			};
			findSysUserMenus(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						if (response.data.responseData) {
							//设置默认数据
							//  this.isTree=true
							this.treeData = response.data.responseData;

							//设置选中的数据
							(this.currCheckedKeys = []),
								(this.checkedKeys = []),
								this.getCheckedParamsKeys(this.treeData);
							// this.setArr(this.treeData)
						}
						// else{
						//   this.isTree=false
						// }

					}
				})
				.catch(error => {
					console.log(error);
				});
		},

		//递归取isHave判断1,0
		//   setArr(arr,newArr,arrList) {
		//     newArr = newArr || [];
		//     arrList=arrList||[]
		//     let arrMenu=(Object.keys(this.$refs.userTree.store.nodesMap))
		//     arr.forEach(item => {
		//       if(item.isHave=='1'){
		//         newArr.push({menuCode:item.menuCode,isHave:item.isHave})
		//         if(item.childMenus){
		//           this.setArr(item.childMenus, newArr,arrList);
		//           if(newArr.length==arrMenu.length){
		//              this.checked = true
		//           }
		//         }
		//       }else{
		//         arrList.push({menuCode:item.menuCode,isHave:item.isHave})
		//         this.checked = false;
		//       }
		//     })
		//     return newArr;
		// },
		//监听菜单改变
		currentChecked (data, currentChecked) {
			//判断选中的所有菜单是否和后台返回的菜单长度一样
			// let checkList = this.$refs.userTree
			//   .getHalfCheckedNodes()
			//   .concat(this.$refs.userTree.getCheckedNodes());
			// console.log(checkList, "111");
			// let arrMenu = Object.keys(this.$refs.userTree.store.nodesMap);
			// debugger;
			// console.log(this.$refs.userTree, "00");
			this.userMenus = [];
			let arrs = [
				...currentChecked.checkedKeys,
				...currentChecked.halfCheckedKeys
			];

			// let arrMenu = Object.keys(this.$refs.userTree.store.nodesMap);
			// if (arrs.length == arrMenu.length) {
			//   this.checked = true;
			// } else {
			//   this.checked = false;
			// }
			arrs.forEach(v => {
				var item = new Object();
				item.menuCode = v;
				this.userMenus.push(item);

			});
		},
		handleClose () {
			this.releaseModal = false;
		},
		//权限保存
		btnDefine () {
			let params = {
				userCode: this.authCode,
				userMenus: this.userMenus
			};
			editSysUserMenusByUserCode(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.releaseModal = false;
						this.getList(1);
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		filterNode (value, data) {
			if (!value) return true;
			return data.label.indexOf(value) !== -1;
		},
		resetForm () {
			this.$refs.filterForm.resetFields()
			this.getList(1);
		}
	},
	created () {
		this.initDataDictionary();
	},
	mounted () {
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#contentManagement {
	width: 100%;
	min-width: 1450px;
	.el-form-item {
		margin-bottom: 0px;
	}
	.userDialog .el-form-item {
		margin-bottom: 15px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 300px;
}
.search_btn {
	width: 30%;
	min-width: 295px;
	// min-width: 100px;
	margin-left: 90px;
}

.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
</style>
