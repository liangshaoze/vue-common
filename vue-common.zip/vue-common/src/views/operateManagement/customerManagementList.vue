<template>
  <div id="customerManage">
    <headTag :tagName="tagName"/>
    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form :inline="true" ref="filterForm" :model="filters" label-width="80px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="姓名" prop="className">
              <el-input
                size="mini"
                v-model.trim="filters.className"
                clearable
                placeholder="请输入姓名"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系方式" prop="className">
              <el-input
                size="mini"
                v-model.trim="filters.className"
                clearable
                placeholder="请输入联系方式"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="推荐人" prop="className">
              <el-input
                size="mini"
                v-model.trim="filters.className"
                clearable
                placeholder="请输入推荐人"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item-btn">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getList(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
              <el-button size="mini" type="primary" icon="el-icon-plus" @click="handleInsert">新增</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="tableToolbar">
      <el-row class="tableTopBtn"></el-row>
      <!-- 列表 -->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="productClassList"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column label="姓名" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="联系方式" min-width="150" prop="genderValue"></el-table-column>
        <el-table-column label="会员级别" min-width="100" prop="age"></el-table-column>
        <el-table-column label="会员有效期" min-width="200" prop="startWorkDate"></el-table-column>
        <el-table-column label="推荐人" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="备注" min-width="150" prop="genderValue"></el-table-column>
        <el-table-column label="创建时间" min-width="200" prop="orgName"></el-table-column>
        <el-table-column fixed="right" label="操作" width="300">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="handleEdit(scope.row)">查看</el-button>
            <el-button size="mini" type="text" @click="toVipGradeList(scope.row)">会员信息</el-button>
            <el-button size="mini" type="text" @click="updateHandle(scope.row)">查看被照护人</el-button>
            <el-button size="mini" type="text" @click="deleteHandle(scope.row)">收货地址</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.pageNum"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
    </div>

  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import {
  findRecruitNeedList,
  updateRecruitNeed
} from "api/dispatchRequirement";

export default {
  components: {
    HeadTag,
    Pagination
  },
  props: {},
  data() {
    return {
      tagName: "客户管理",
      productClassList: [],
      totalCount: 1,
      listLoading: false,
      //控制查询按钮加载
      searchLoading: false,
      filters: {
        pageNum: 1,
        pageSize: 10,
        customerName: "",
        customerTel: "",
        recommender: ""
      }
    };
  },
  watch: {},
  computed: {},
  methods: {
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.getList(1);
    },
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page);
    },
    getList(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        customerName: this.filters.customerName,
        customerTel: this.filters.customerTel,
        recommender: this.filters.recommender
      };
      this.listLoading = true;
      this.searchLoading = true;
      findRecruitNeedList(params)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            this.listLoading = false;
            this.searchLoading = false;
            this.productClassList = response.data.responseData;
            this.totalCount = response.data.totalCount;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
          }
        })
        .catch(error => {
          console.log("findRecruitNeedList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
        });
    },
    //新增客户
    handleInsert() {
      this.$router.push({
        path: "/evaluationManagement/addCustomer",
        query: {
          type: "insert"
        }
      });
    },
    //查看客户
    handleEdit(row) {
      this.$router.push({
        path: "/evaluationManagement/addCustomer",
        query: {
          type: "update",
          customerCode: row.customerCode
        }
      });
    },
    toVipGradeList(row){
       this.$router.push({
        path: "/vipManagement/vipGradeList",
        query: {
          customerCode: row.customerCode
        }
      });
    }
  },
  created() {},
  mounted() {
    this.getList(1);
  }
};
</script>
<style lang="scss" scoped>
#customerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }

  .el-input {
    width: 200px;
  }
  .form-item {
    width: 30%;
    min-width: 300px;
  }
  .form-item-btn {
    width: 30%;
    min-width: 300px;
  }
  .tableTopBtn {
    background-color: white;
    text-align: right;
    padding: 10px 20px 10px 0px;
  }
  .search_btn {
    min-width: 250px;
    margin-left: 80px;
  }
}
</style>
<style lang="scss">
#dispatchRequirementList {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>