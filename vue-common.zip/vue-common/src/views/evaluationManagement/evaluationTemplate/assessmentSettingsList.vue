<template>
  <div id="assessmentSettingsList">
    <headTag :tagName="tagName" />
    <div class="tableToolbar">
        <el-row class="tableTopBtn">
            <el-col :span="24">
                <el-button size="mini" type="primary" icon="el-icon-plus" @click="addSettingsForm()">新增</el-button>
            </el-col>
        </el-row>
        <el-table :data="tableData" :header-cell-style="{
            background: 'rgba(57, 138, 241, 0.1)',
            color: '#606266'
            }" element-loading-text="拼命加载中" highlight-current-row size="mini" stripe style="width:100%;" v-loading="listLoading">
            <el-table-column label="序号" min-width="100" prop="userCode"></el-table-column>
            <el-table-column label="表的名称" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="更新时间" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="操作">
            <template slot-scope="scope">
               <el-button @click="topMove(scope.row,scope.$index)" size="mini" :disabled="scope.$index == 0" type="text">上移</el-button>
                <el-button @click="domnMove(scope.row,scope.$index)" size="mini" :disabled="(scope.$index + 1) == tableData.length" type="text">下移</el-button>
                <el-button @click="editSettingsForm(scope.row.userCode)" size="mini" type="text">修改</el-button>
                <el-button @click="deleteSettingsForm(scope.row.userCode)" size="mini" type="text">删除</el-button>
            </template>
            </el-table-column>
        </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <!--分页-->
        <pagination :limit.sync="keyWords.pageSize" :page.sync="keyWords.pageNum" :total="totalCount" @pagination="pageChange" v-if="totalCount > 0" />
      </el-row>
         <!-- 删除题痛点信息 -->
       <!-- <el-dialog title="删除痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogDeleteSettings " :before-close="handleDeleteSettingsClose" >
           <h3 style="text-align:center;">与痛点关联关系将同时解除，删除后不可恢复!</h3>
           <div slot="footer" class="dialog-footer">
            <el-button size="mini"  @click="dialogDeleteSettings =false">取消</el-button>
            <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="SettingsDeleteSubmit()">确 定</el-button>
        </div>
       </el-dialog> -->
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common/index.js";
import Pagination from "components/Pagination/pagination";
import HeadTag from "components/HeadTag";

import {
  findSysUserList,
  editSysUser,
  getSysUserByCode,
  findSysUserMenus,
  editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
export default {
  components: {
    Pagination,
    HeadTag,
  },
  props: {},
  data() {
    return {
      tagName: "评估模板表设置",
      keyWords: {
        pageNum: 1,
        pageSize: 10
       },
      tableData:[],
      totalCount: 0,
      listLoading: false,
      cancleDisabled:false,
      //新增商品
    //   dialogSettings :false,
    //   formSettingsRules:{
    //      productName: [
    //       {
    //         required: true,
    //         message: "请选择产品名称",
    //         trigger: "change"
    //       }
    //     ],
    //   },
    // formSettings :{
    //     selectDay:'',
    //     orgName:'',
    //     radio:'',
    //     type:''
    // },
      //删除题目
    // dialogDeleteSettings :false,
    //   //编辑痛点
    // dialogEditSettings :false,
    //   formEditSettingsRules:{
    //      productName: [
    //       {
    //         required: true,
    //         message: "请选择产品名称",
    //         trigger: "change"
    //       }
    //     ],
    //   },
    // formEditSettings :{
    //     selectDay:'',
    //     orgName:'',
    //     radio:''
    // },
    // isRadio:false,
    // typeOptions:[]
  };  
  },
  watch: {},
  computed: {},
  methods: {
     topMove(row,index){
      if (index > 0) {
            let upData = this.tableData[index - 1];
            this.tableData.splice(index - 1, 1);
            this.tableData.splice(index, 0, upData);
        } else {
            this.$message({
                message: '已经是第一条，上移失败',
                type: 'warning'
            });
      }
    },
    domnMove(row, index) {
      if ((index + 1) == this.tableData.length) {
          this.$message({
              message: '已经是最后一条，下移失败',
              type: 'warning'
          });
      } else {
          let downData = this.tableData[index + 1];
          this.tableData.splice(index + 1, 1);
          this.tableData.splice(index, 0, downData);
      }
  },
    // selectRadio(val){
    //   console.log(val)
    //   if(val=='1'){
    //     this.isRadio=true
    //   }else{
    //     this.isRadio=false
    //   }
    // },
    // 列表数据
    getList(page) {
      this.listLoading = true;
      this.keyWords.pageNum = page;
      findSysUserList(this.keyWords)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode === 200 ||
              response.data.statusCode === "200"
            ) {
              this.tableData = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
     //父组件触发事件
    pageChange(val) {
      this.keyWords.page = val.page;
      this.keyWords.pageSize = val.limit;
      this.getList(val.page);
    },
    addSettingsForm(){
      this.$router.push({
        path: "/evaluationManagement/addEvaluationForms"
      });
    },
    editSettingsForm(){

    },
    deleteSettingsForm(){

    },

  },
  created() {
    this.getList(1);
  },
  mounted() {
     
  },
  activated() {
    this.getList(1);
   }
};
</script>
<style lang="scss" scoped>
#assessmentSettingsList{
   width: 100%;
   min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.workOrderClass {
	margin-top: 20px;
	margin-bottom: 0;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.search_btn {
   width: 30%;
  min-width: 295px;
  margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.remark-style {
  // display: block;
  width: 200px;
  margin: 10px;
}

</style>