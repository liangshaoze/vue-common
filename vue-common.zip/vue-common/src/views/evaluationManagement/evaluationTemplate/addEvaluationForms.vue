<template>
  <div id="addEvaluationForms">
    <headTag :tagName="tagName" />
    <div class="main-content">
       <div class="panel-card">
        <el-row class="importToolbar">
            <el-col :span="24">
                <span class="form-tag">评估表</span>
                <el-button  class="rightBtn" size="mini" type="primary"  @click="btnList()">返回</el-button>
            </el-col>
        </el-row>
         <el-form
          ref="assessmentForm"
          :inline="false"
          :model="assessmentForm"
          :rules="assessmentFormRules"
          label-width="110px"
         
        >  
        <el-row class="form-content">
          <el-form-item label="表的名称" prop="formName">
            <el-input
              v-model="assessmentForm.formName"
              size="mini"
              clearable
              placeholder="请输入表的名称"
            ></el-input>
          </el-form-item>
        </el-row>
        </el-form>
        <el-row class="selectClass">
            <el-col :span="24">
                <span style="color:red;margin-left:30px;">* </span><span class="selectTitle">选择题目</span>
                <el-button  class="rightBtn" icon="el-icon-plus" size="mini" type="primary"  @click="addTopic()">新增</el-button>
            </el-col>
        </el-row>
         <el-row class="questionClass">
            <el-col :span="24" style="text-align:center;">
               暂时没有题目预览，请先添加题目
             </el-col>
         </el-row >
         <el-row class="questionClass">
            <el-col :span="24" style="color:'#333333;font-size:18px;font-weight:normal;margin-left:35px;">
               新增题目预览
             </el-col>
         </el-row >
       </div>
       <!--新增题目弹框-->
        <el-dialog title="新增题目" center width="1087px"  :close-on-click-modal="false" :visible.sync="dialogTopic" :before-close="handleTopicClose" >
          <el-row type="flex" justify="center">
           <el-form ref="filterForm" :inline="true" :model="keyWords" label-width="80px">
              <el-row>
                <el-col class="form-item">
                  <el-form-item label="题目">
                    <el-input size="mini" v-model.trim="keyWords.orgName" placeholder="请选择组织" 
                        clearable></el-input>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="题目编号" prop="careGiverName">
                    <el-input size="mini" v-model.trim="keyWords.orgName" clearable placeholder="请输入服务人员"></el-input>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="题目类型" prop="careReceiverName">
                    <el-select size="mini" v-model.trim="keyWords.auditStatus" clearable placeholder="请选择审核状态">
                      <el-option v-for="item in auditStatusOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col class="form-item">
                  <el-form-item label="题目分类" prop="careReceiverName">
                    <el-select size="mini" v-model.trim="keyWords.auditStatus" clearable placeholder="请选择审核状态">
                      <el-option v-for="item in auditStatusOptions" :key="item.value" :label="item.name" :value="item.value" />
                    </el-select>
                  </el-form-item>
                </el-col>
                  <el-col class="form-item">
                    <el-form-item></el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item class="search_btn">
                    <el-button @click="getTopicList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
                    </el-form-item>
                </el-col>
               </el-row>
            </el-form>
          </el-row>
          <div style="margin-left:45px;">
           <el-table :data="tableData" :header-cell-style="{
              background: 'rgba(57, 138, 241, 0.1)',
              color: '#606266'
              }" element-loading-text="拼命加载中" highlight-current-row size="mini" stripe  v-loading="listLoading">
              <el-table-column label="编号" min-width="100" prop="number"></el-table-column>
              <el-table-column label="题目" min-width="120" prop="subject"></el-table-column>
              <el-table-column label="题目类型" min-width="120" prop="subjectType"></el-table-column>
              <el-table-column label="题目分类" min-width="120" prop="subjectkind"></el-table-column>
              <el-table-column label="操作">
              <template slot-scope="scope">
                  <el-button @click="addTo(scope.row.userCode)" size="mini" type="text">添加</el-button>
              </template>
              </el-table-column>
             </el-table>
          </div>
        </el-dialog>
      <!--工具条-->
      <!-- <el-row class="pageToolbar">
        <pagination :limit.sync="keyWords.pageSize" :page.sync="keyWords.pageNum" :total="totalCount" @pagination="pageChange" v-if="totalCount > 0" />
      </el-row> -->
         <!-- 删除题痛点信息 -->
       <!-- <el-dialog title="删除痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogDeleteSettings " :before-close="handleDeleteSettingsClose" >
           <h3 style="text-align:center;">与痛点关联关系将同时解除，删除后不可恢复!</h3>
           <div slot="footer" class="dialog-footer">
            <el-button size="mini"  @click="dialogDeleteSettings =false">取消</el-button>
            <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="SettingsDeleteSubmit()">确 定</el-button>
        </div>
       </el-dialog> -->
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common/index.js";
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget"

import Pagination from "components/Pagination/pagination";
import HeadTag from "components/HeadTag";

import {
  findSysUserList,
  editSysUser,
  getSysUserByCode,
  findSysUserMenus,
  editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
export default {
  components: {
    Pagination,
    HeadTag,
    CommonPropertyWidget
  },
  props: {},
  data() {
    return {
      tagName: "新增评估表",
      keyWords: {
        pageNum: 1,
        pageSize: 10,
        orgName:'',
        auditStatus:''
       },
      tableData:[
         {
            number: '001',
            subject: '肢体健康',
            subjectType: '问答',
            subjectkind: '认知'
          }, 
           {
            number: '002',
            subject: '肢体健康',
            subjectType: '问答',
            subjectkind: '认知'
          }, 
      ],
      dialogTopic:false,
      auditStatusOptions:[],
      totalCount: 0,
      listLoading: false,
      cancleDisabled:false,
      //新增表
      assessmentFormRules:{
        formName: [
          {
            required: true,
            message: "请选择表名称",
            trigger: "change"
          }
        ],
         choiceTopic: [
          {
            required: true,
            message: "请选择表名称",
            trigger: "change"
          }
        ],
      },
      assessmentForm:{
        formName:'',
        choiceTopic:''
      }
      //新增商品
    //   dialogSettings :false,
    //   formSettingsRules:{
    //      productName: [
    //       {
    //         required: true,
    //         message: "请选择产品名称",
    //         trigger: "change"
    //       }
    //     ],
    //   },
    // formSettings :{
    //     selectDay:'',
    //     orgName:'',
    //     radio:'',
    //     type:''
    // },
      //删除题目
    // dialogDeleteSettings :false,
    //   //编辑痛点
    // dialogEditSettings :false,
    //   formEditSettingsRules:{
    //      productName: [
    //       {
    //         required: true,
    //         message: "请选择产品名称",
    //         trigger: "change"
    //       }
    //     ],
    //   },
    // formEditSettings :{
    //     selectDay:'',
    //     orgName:'',
    //     radio:''
    // },
    // isRadio:false,
    // typeOptions:[]
  };  
  },
  watch: {},
  computed: {},
  methods: {
       //获取数据字典
    initDataDictionary() {
      findValueBySetCode({ valueSetCode: "USER_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.statusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
     topMove(row,index){
      if (index > 0) {
            let upData = this.tableData[index - 1];
            this.tableData.splice(index - 1, 1);
            this.tableData.splice(index, 0, upData);
        } else {
            this.$message({
                message: '已经是第一条，上移失败',
                type: 'warning'
            });
      }
    },
    domnMove(row, index) {
      if ((index + 1) == this.tableData.length) {
          this.$message({
              message: '已经是最后一条，下移失败',
              type: 'warning'
          });
      } else {
          let downData = this.tableData[index + 1];
          this.tableData.splice(index + 1, 1);
          this.tableData.splice(index, 0, downData);
      }
  },
    // 列表数据
    getList(page) {
      this.listLoading = true;
      this.keyWords.pageNum = page;
      findSysUserList(this.keyWords)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode === 200 ||
              response.data.statusCode === "200"
            ) {
              // this.tableData = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
     //父组件触发事件
    pageChange(val) {
      this.keyWords.page = val.page;
      this.keyWords.pageSize = val.limit;
      this.getList(val.page);
    },
    addTopic(){
      this.dialogTopic=true
    },
    handleTopicClose(){
      this.dialogTopic=false
    },
    editSettingsForm(){

    },
    deleteSettingsForm(){

    },

  },
  created() {
    this.initDataDictionary();
    this.getList(1);
  },
  mounted() {
     
  },
  activated() {
    this.getList(1);
   }
};
</script>
<style lang="scss" scoped>
#addEvaluationForms{
   width: 100%;
   min-width: 1024px;
  .el-form-item {
   margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 20px 10px 20px 10px;
}
.importToolbar {
  padding:27px 10px 26px 35px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  border-bottom: 1px solid #E6E6E6;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
.selectClass{
  padding:35px 0 35px 0px;
  border-bottom: 1px solid #E6E6E6;
  .selectTitle{
      font-size: 14px;
      color: #606266;
      font-weight: 700;
  }
   .rightBtn{
     float: right;
    margin-right: 20px;
  } 
}
.questionClass{
  padding:35px 0 35px 0px;
  border-bottom: 1px solid #E6E6E6;
}
.form-content{
  padding:35px 0 35px 0;
  border-bottom: 1px solid #E6E6E6;
}

.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
  
}
.search_btn {
   width: 30%;
  min-width: 295px;
  margin-left: 85px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.remark-style {
  // display: block;
  width: 200px;
  margin: 10px;
}

</style>