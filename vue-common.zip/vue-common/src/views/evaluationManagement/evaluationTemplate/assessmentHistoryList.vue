<template>
  <div id="assessmentHistoryList">
    <headTag :tagName="tagName" />
    <div class="tableToolbar">
        <el-row class="tableTopBtn">
            <el-col :span="24">
                <el-button size="mini" type="primary" icon="el-icon-plus" @click="addHistory()">新增</el-button>
            </el-col>
        </el-row>
        <el-table :data="tableData" :header-cell-style="{
            background: 'rgba(57, 138, 241, 0.1)',
            color: '#606266'
            }" element-loading-text="拼命加载中" highlight-current-row size="mini" stripe style="width:100%;" v-loading="listLoading">
            <el-table-column label="组织" min-width="100" prop="userCode"></el-table-column>
            <el-table-column label="名称" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="版本" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="类型" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="评估报告" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="更新时间" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="操作">
            <template slot-scope="scope">
                <el-button @click="editHistoryInfo(scope.row.userCode)" size="mini" type="text">编辑</el-button>
                <el-switch style="margin-left:20px;" size="mini" v-model="switchValue"></el-switch>
                <!-- <el-button @click="deleteHistoryInfo(scope.row.userCode)" size="mini" type="text">删除</el-button> -->
            </template>
            </el-table-column>
        </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <!--分页-->
        <pagination :limit.sync="keyWords.pageSize" :page.sync="keyWords.pageNum" :total="totalCount" @pagination="pageChange" v-if="totalCount > 0" />
      </el-row>
        <!-- 新增评估模板 -->
       <el-dialog title="新增评估模板" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogHistory " :before-close="handleHistoryClose" >
        <el-row type="flex" justify="center">
          <el-form :inline="false" :rules="formHistoryRules" ref="formService" :model="formHistory " label-width="85px">
            <el-form-item   prop="productName" label="组织">
              <el-input size="mini" clearable v-model="formHistory.orgName" placeholder="自动生成，不可重复"></el-input>
            </el-form-item>
            <el-form-item class="workOrderClass" label="名称">
                <el-input size="mini" clearable v-model="formHistory.orgName" placeholder="自动生成，不可重复"></el-input>
            </el-form-item>
            <el-form-item class="workOrderClass" label="类型">
              <el-input size="mini" clearable v-model="formHistory.orgName" placeholder="自动生成，不可重复"></el-input>
             </el-form-item>
            <el-form-item class="workOrderClass" label="是否复制">
              <el-radio-group v-model="formHistory.radio" @change="selectRadio">
                <el-radio :label="0">否</el-radio>
                <el-radio :label="1">是</el-radio>
              </el-radio-group>
             </el-form-item>
             <div v-if="isRadio">
                <el-form-item label="类型"  class="workOrderClass">
                    <el-select v-model="formHistory.type" size="mini" clearable placeholder="请选择服务分类">
                        <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                 <el-form-item label="名称"  class="workOrderClass">
                    <el-select v-model="formHistory.type" size="mini" clearable placeholder="请选择服务分类">
                        <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                 <el-form-item label="版本"  class="workOrderClass">
                    <el-select v-model="formHistory.type" size="mini" clearable placeholder="请选择服务分类">
                        <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
             </div>
          </el-form>
        </el-row>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini"  @click="cancleHistory ('formHistory')">取消</el-button>
          <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="painSubmit('formHistory')">确 定</el-button>
        </div>
       </el-dialog>
         <!-- 编辑痛点信息 -->
       <el-dialog title="编辑痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogEditHistory " :before-close="handleEditHistoryClose" >
        <el-row type="flex" justify="center">
          <el-form :inline="false" :rules="formEditHistoryRules" ref="formService" :model="formEditHistory " label-width="85px">
            <el-form-item  prop="productName" label="编号">
                <el-input size="mini" clearable v-model="formEditHistory .orgName" placeholder="自动生成，不可重复"></el-input>
            </el-form-item>
            <el-form-item label="痛点">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formEditHistory .remark"
                      size="mini"
                      clearable
                      placeholder="请输入痛点"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
                <el-form-item label="目标">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formEditHistory .remark"
                      size="mini"
                      clearable
                      placeholder="请输入目标"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
          </el-form>
        </el-row>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini"  @click="cancleEditHistory ('formEditHistory ')">取消</el-button>
          <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="painEditSubmit('formEditHistory ')">确 定</el-button>
        </div>
       </el-dialog>
         <!-- 删除题痛点信息 -->
       <el-dialog title="删除痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogDeleteHistory " :before-close="handleDeleteHistoryClose" >
           <h3 style="text-align:center;">与痛点关联关系将同时解除，删除后不可恢复!</h3>
           <div slot="footer" class="dialog-footer">
            <el-button size="mini"  @click="dialogDeleteHistory =false">取消</el-button>
            <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="HistoryDeleteSubmit()">确 定</el-button>
        </div>
       </el-dialog>
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common/index.js";
import Pagination from "components/Pagination/pagination";
import HeadTag from "components/HeadTag";

import {
  findSysUserList,
  editSysUser,
  getSysUserByCode,
  findSysUserMenus,
  editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
export default {
  components: {
    Pagination,
    HeadTag,
  },
  props: {},
  data() {
    return {
      tagName: "评估模板历史",
      keyWords: {
        pageNum: 1,
        pageSize: 10
       },
      tableData:[],
      totalCount: 0,
      listLoading: false,
      cancleDisabled:false,
      switchValue:'',
      //新增商品
      dialogHistory :false,
      formHistoryRules:{
         productName: [
          {
            required: true,
            message: "请选择产品名称",
            trigger: "change"
          }
        ],
      },
    formHistory :{
        selectDay:'',
        orgName:'',
        radio:'',
        type:''
    },
      //删除题目
    dialogDeleteHistory :false,
      //编辑痛点
    dialogEditHistory :false,
      formEditHistoryRules:{
         productName: [
          {
            required: true,
            message: "请选择产品名称",
            trigger: "change"
          }
        ],
      },
    formEditHistory :{
        selectDay:'',
        orgName:'',
        radio:''
    },
    isRadio:false,
    typeOptions:[]
  };  
  },
  watch: {},
  computed: {},
  methods: {
    selectRadio(val){
      console.log(val)
      if(val=='1'){
        this.isRadio=true
      }else{
        this.isRadio=false
      }
    },
    // 列表数据
    getList(page) {
      this.listLoading = true;
      this.keyWords.pageNum = page;
      findSysUserList(this.keyWords)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode === 200 ||
              response.data.statusCode === "200"
            ) {
              this.tableData = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
     //父组件触发事件
    pageChange(val) {
      this.keyWords.page = val.page;
      this.keyWords.pageSize = val.limit;
      this.getList(val.page);
    },
    //新增痛点信息
    addHistory(){
     this.dialogHistory =true
    },
     handleHistoryClose(){
      this.dialogHistory =false
      this.formHistory.radio=''
      this.isRadio=false
    },
    cancleHistory (){
      this.dialogHistory =false
      this.formHistory.radio=''
      this.isRadio=false
    },
    //编辑痛点信息
    editHistoryInfo(){
      this.dialogEditHistory =true

    },
    handleEditHistoryClose(){
      this.dialogEditHistory =false
    },
    cancleEditHistory (){
      this.dialogEditHistory =false
    },
    //删除痛点信息
    deleteHistoryInfo(){
      this.dialogDeleteHistory =true
    },
    HistoryDeleteSubmit(){

    },
   handleDeleteHistoryClose(){
      this.dialogDeleteHistory =false
    },

  },
  created() {
    this.getList(1);
  },
  mounted() {
     
  },
  activated() {
    this.getList(1);
   }
};
</script>
<style lang="scss" scoped>
#assessmentHistoryList{
   width: 100%;
   min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.workOrderClass {
	margin-top: 20px;
	margin-bottom: 0;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.search_btn {
   width: 30%;
  min-width: 295px;
  margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.remark-style {
  // display: block;
  width: 200px;
  margin: 10px;
}

</style>