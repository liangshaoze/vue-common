<!--编辑评估模板-->
<template>
  <div>
    <el-row type="flex">
      <div>
        <headTag :tagName="tagName" />
      </div>
      <div>
        <el-button v-if="isEdit==true" size="mini" type="primary" @click="editTitle(1)">编辑</el-button>
      </div>
    </el-row>
    <div>
      <BaseInfoTable/>
    </div>
    <div style="width:800px">
      <Personas/>
    </div>
    <el-dialog :title="titleList[dialogIndex].title+'编辑'" :visible.sync="dialogCommon" width="500px" :before-close="handleClose" center>
	        <el-form ref="propertyForm" :inline="true" :model="titleList[dialogIndex].formModel" label-width="125px">
                <CommonTableWidget
                    @queryMethod ="queryMethod"
                    :propertyList="titleList[dialogIndex].cols"
                    @saveRow ="saveRow"
                    :formModel="titleList[dialogIndex].formModel"
                    :tableDataName="'tableData'"
                    ref="CommonTableWidget"
                    :optWidth="200"
                    :showTableIndex="true"
                />
                <div slot="footer" class="dialog-footer">
                    <el-button  size="mini" @click="dialogServerEffect = false">取 消</el-button>
                    <el-button  size="mini" style="margin-left:40px;" type="primary" @click="ServerOrderEffect()">确 定</el-button>
                </div>
            </el-form>
	</el-dialog>
  </div>
  
</template>

<script>
import HeadTag from "components/HeadTag";
import CommonTableWidget from "components/widget/CommonTableWidget"
import BaseInfoTable from "@/views/evaluationManagement/assessInformation/widget/BaseInfoTable"
import Personas from "@/views/evaluationManagement/assessInformation/widget/Personas"

export default {
  data() {
    return {
      dialogCommon:false,
      dialogIndex:0,//弹窗索引
      isEdit:true,
      tagName:this.isEdit?'评估报告模板':"评估报告",
      titleList: [
        {
          id: 1,
          sort: 0,
          title: "个人基础信息",
          formModel:{
            tableData:[{title:"姓名",relateItem:"标题",isSingleLine:""}]
          },
          cols: [
            {
              propertyName: "标题",propertyFieldName: "title",propertyType: "10"
            },
            {
              propertyName: "关联项",propertyFieldName: "relateItem",propertyType: "20",
              options: [
                { value: "1", name: "表" },
                { value: "2", name: "结果" }
              ]
            },
            {
              propertyName: "是否单行显示",propertyFieldName: "isSingleLine",propertyType: "20",
              options: [
                { value: "1", name: "是" },
                { value: "2", name: "否" }
              ]
            }
          ]
        },
        {
          id:2,
          sort: 1,
          title: "客户基础信息画像",
          formModel:{
            tableData:[]
          },
          cols: [
            {
              propertyName: "标题",propertyFieldName: "title",propertyType: "10"
            },
            {
              propertyName: "关联项",propertyFieldName: "relateItem",propertyType: "20",
              options: [
                { value: "1", name: "表" },
                { value: "2", name: "结果" }
              ]
            },
          ]
        }
      ]
    };
  },
  components: {
    HeadTag,
    CommonTableWidget,
    BaseInfoTable,
    Personas
  },
  methods: {
    queryMethod(obj,query,cb){
      if(typeof(obj.queryMethod) =="function"){
        obj.queryMethod(query,cb);
      }else{
        this[obj.queryMethod](query,cb);
      }
    },
    editTitle(index){
      this.dialogCommon=true;
      this.dialogIndex=index;
    }
  },
  mounted() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
</style>
