<template>
	<div id="assessmentList" :style="ScreenFitter.style({'min-width': 1024})">
		<div id="hidemap"></div>
		<HeadTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filter" label-width="125px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="filter.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评估模板" prop="assessCode">
							<el-select size="mini" v-model.trim="filter.assessCode" clearable placeholder="请选择评估版本">
								<el-option
									v-for="item in acessTemplateOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评估人员" prop="assessorName">
							<el-input size="mini" v-model.trim="filter.assessorName" clearable placeholder="请输入评估人员"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filter.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人身份证号" prop="careReceiverIdCard">
							<el-input
								size="mini"
								v-model.trim="filter.careReceiverIdCard"
								clearable
								placeholder="请输入被照护人身份证号"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人性别" prop="careReceiverGender">
							<el-select
								size="mini"
								v-model.trim="filter.careReceiverGender"
								clearable
								placeholder="请选择被照护人性别"
							>
								<el-option
									v-for="item in staffGenderOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评估等级" prop="assessGrade">
							<el-select size="mini" v-model.trim="filter.assessGrade" clearable placeholder="请选择评估等级">
								<el-option
									v-for="item in assessGradeOptions"
									:key="item.name"
									:label="item.name"
									:value="item.name"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评估状态" prop="assessStatus">
							<el-select size="mini" v-model.trim="filter.assessStatus" placeholder="请选择评估状态">
								<el-option
									v-for="item in assessStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评估时间" prop="assessDate">
							<el-date-picker
								v-model.trim="filter.assessDate"
								clearable
								size="mini"
								value-format="yyyy-MM-dd"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="关键字">
							<el-input
								size="mini"
								style="width:120px;"
								v-model.trim="filter.keyTitle"
								clearable
								placeholder="请输入题目"
							></el-input>
							<el-input
								size="mini"
								style="width:120px;"
								v-model.trim="filter.keyTitleValue"
								clearable
								placeholder="请输入题目值"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="getList(1)"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<div class="tableToolbar">
			<el-row class="tableTopBtn"></el-row>
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				size="mini"
				stripe
				:data="tableData"
				v-loading="listLoading"
				highlight-current-row
				element-loading-text="拼命加载中"
			>
				<el-table-column prop="orgName" label="组织" width="150"></el-table-column>
				<el-table-column prop="assessName" label="评估版本" width="70"></el-table-column>
				<el-table-column prop="assessStatusValue" label="评估状态" width="70"></el-table-column>
				<el-table-column prop="careReceiverName" label="被照护人姓名" width="120"></el-table-column>
				<el-table-column prop="careReceiverIdCard" label="被照护人身份证号" width="150"></el-table-column>
				<el-table-column prop="careReceiverGenderValue" label="被照护人性别" width="150"></el-table-column>
				<el-table-column prop="careReceiverAge" label="被照护人年龄" width="150"></el-table-column>
				<el-table-column label="被照护人地址" width="280">
					<template slot-scope="scope">
						<span>{{scope.row.liveProvinceName}}{{scope.row.liveCityName}}{{scope.row.liveDistrictName}}{{scope.row.liveSubdistrictName}}{{scope.row.liveDetailAddress}}</span>
					</template>
				</el-table-column>
				<el-table-column prop="assessGrade" label="评估等级" min-width="100"></el-table-column>
				<el-table-column label="评估时间" min-width="100">
					<template slot-scope="scope">
						<span v-if="scope.row.assessEndDate">
							<span>{{scope.row.assessEndDate}}</span>
						</span>
					</template>
				</el-table-column>
				<el-table-column prop="assessorName" label="评估人员" min-width="70"></el-table-column>
				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-button
							size="mini"
							v-if="scope.row.assessStatus==10&& (scope.row.assessorCode==userCode)&&scope.row.assessStatus!==40 "
							type="text"
							@click="getMapAssess(scope.row,false)"
						>评估</el-button>
						<el-button
							size="mini"
							v-if="scope.row.assessStatus==20 && (scope.row.assessorCode==userCode)&&scope.row.assessStatus!==40"
							type="text"
							@click="goOnAssess(scope.row,false)"
						>继续评估</el-button>
						<el-button
							size="mini"
							v-if="scope.row.assessStatus==25&& (scope.row.assessorCode==userCode)&&scope.row.assessStatus!==40 "
							type="text"
							@click="generateReport(scope.row)"
						>生成报告</el-button>
						<el-button
							size="mini"
							v-if="(scope.row.assessStatus==25||scope.row.assessStatus==30)&&scope.row.assessStatus!==40"
							type="text"
							@click="toAssessDetail(scope.row,true)"
						>评估详情</el-button>
						<el-button
							size="mini"
							v-if="(scope.row.assessStatus==25||scope.row.assessStatus==30)&&scope.row.assessStatus!==40&&scope.row.synchronizeStatus==0&& (scope.row.assessorCode==userCode)"
							type="text"
							@click="assessLoation(scope.row)"
						>同步定位</el-button>
						<el-button
							size="mini"
							v-if="scope.row.assessStatus==30&&scope.row.assessStatus!==40"
							type="text"
							@click="assessmentReport(scope.row)"
						>评估报告</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filter.pageNum"
					:limit.sync="filter.pageSize"
					@pagination="pageChange"
				/>
			</el-row>
		</div>
		<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
			<org-select v-on:listenTochildEvent="getCurrentNode" />
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import {
	findAssessOrderList,
	startAssessByCode,
	findEtAssessList,
	editPositioningInfo
} from "api/assessment";
import { findValueBySetCode } from "api/common";
import { changeYMD } from "utils";
import OrgSelect from "components/OrgSelect";

export default {
	data () {
		return {
			tagName: "评估列表",
			totalCount: 0,
			listLoading: false,
			dialogVisible: false,
			filter: {
				orgCode: "",
				orgName: "",
				assessCode: "",
				assessName: "",
				assessorCode: "",
				assessorName: "",
				assessGrade: "",
				assessStatus: "10",
				assessEndDateB: "",
				assessEndDateE: "",
				assessDate: "",
				careReceiverName: "",
				careReceiverIdCard: "",
				careReceiverGender: "",
				keyTitle: "",
				keyTitleValue: "",
				pageNum: 1,
				pageSize: 10
			},
			userCode: this.$store.getters.userCode,
			//评估状态
			assessStatusOptions: [],
			//评估等级
			assessGradeOptions: [],
			//评估模板
			acessTemplateOptions: [],
			//性别
			staffGenderOptions: [],
			searchLoading: false,
			tabList: [],
			contractId: "",
			tableData: [],
			plaform: "",
			checkinLatitude: '',
			checkinLongitude: '',
		};
	},
	components: {
		HeadTag,
		Pagination,
		OrgSelect
	},
	methods: {
		//评估报告
		assessmentReport (item) {
			this.$router.push({
				path: "/assessMobileReport",
				query: {
					assessOrderCode: item.assessOrderCode,
					careReceiverName: item.careReceiverName
				}
			});
		},
		//生成报告
		generateReport (item) {
			this.$router.push({
				path: "/assessMobileReport",
				query: {
					assessOrderCode: item.assessOrderCode,
					careReceiverName: item.careReceiverName
				}
			});

		},
		/* 同步定位 */
		assessLoation (row) {
			this.$confirm("是否确定同步该照护人的定位信息", "提示", {
				confirmButtonText: "确定",
				cancelButtonText: "取消",
				type: "warning"
			})
				.then(() => {
					this.listLoading = true;
					var params = {
						assessOrderCode: row.assessOrderCode
					}
					editPositioningInfo(params)
						.then(response => {
							this.listLoading = false;
							if (response.data.statusCode == "200") {
								this.$message.success("同步定位成功")
								this.getList(1);
							} else {
								this.$message.error(response.data.statusMsg);
							}
						})
						.catch(error => {
							this.listLoading = false;
							return false;
						});

				})
				.catch(err => {
					return false;
				});
		},
		//评估详情
		toAssessDetail (row, flag,) {
			this.$router.push({
				path: "/assessMobileInsertAssess",
				query: {
					assesserInfo: row,
					isDisabled: flag
				}
			});
		},
		//继续评估
		goOnAssess (row, flag) {
			this.$router.push({
				path: "/assessMobileInsertAssess",
				query: {
					assesserInfo: row,
					isDisabled: flag
				}
			});
		},
		//去评估
		toAssess (row, flag) {
			if (this.checkinLatitude && this.checkinLongitude) {
				var params = {
					assessOrderCode: row.assessOrderCode,
					checkinLatitude: this.checkinLatitude,
					checkinLongitude: this.checkinLongitude,
					assessStatus: "20"
				};
				startAssessByCode(params)
					.then(response => {
						if (
							response.data.statusCode == "200" ||
							response.data.statusCode == 200
						) {
							this.$router.push({
								path: "/assessMobileInsertAssess",
								query: {
									assesserInfo: row,
									isDisabled: flag
								}
							});
						} else {
							this.$message.error(response.data.statusMsg);
							return false;
						}
					})
					.catch(error => {
						console.log("startAssessByCode:" + error);
					});
			}
		},
		getList (page) {
			this.filter.pageNum = page;
			var params = {
				pageNum: page,
				pageSize: this.filter.pageSize,
				orgCode: this.filter.orgCode,
				orgName: this.filter.orgName,
				assessCode: this.filter.assessCode,
				assessName: this.filter.assessName,
				assessorCode: this.filter.assessorCode,
				assessorName: this.filter.assessorName,
				assessGrade: this.filter.assessGrade,
				assessStatus: this.filter.assessStatus,
				careReceiverIdCard: this.filter.careReceiverIdCard,
				careReceiverName: this.filter.careReceiverName,
				careReceiverGender: this.filter.careReceiverGender,
				keyTitle: this.filter.keyTitle,
				keyTitleValue: this.filter.keyTitleValue,
				assessEndDateB: (this.filter.assessDate && this.filter.assessDate.length > 0) ? (this.filter.assessDate[0] + " 00:00:00") : null,
				assessEndDateE: (this.filter.assessDate && this.filter.assessDate.length > 0) ? (this.filter.assessDate[1] + " 23:59:59") : null,
			};
			this.searchLoading = true;
			this.listLoading = true;
			// this.filter.pageNum = page;
			findAssessOrderList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						if (response.data.responseData != undefined) {
							this.tableData = response.data.responseData;
							this.tableData.forEach(item => {
								item.assessEndDateB =
									item.assessEndDateB !== undefined
										? changeYMD(item.assessEndDateB)
										: "";
								item.assessEndDateE =
									item.assessEndDateE !== undefined
										? changeYMD(item.assessEndDateE)
										: "";
								//根据身份证计算年龄
								if (item.careReceiverIdCard) {
									item.careReceiverAge = this.changeAge(
										item.careReceiverIdCard
									);
								}
								return item;
							});
							this.totalCount = response.data.totalCount;
							this.listLoading = false;
							this.searchLoading = false;
						} else {
							this.listLoading = false;
							this.searchLoading = false;
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findContractManagementList:" + error);
					return false;
				});
		},
		//根据身份证获取年龄信息
		changeAge (identityCard) {
			var len = (identityCard + "").length;
			if (len == 0) {
				return 0;
			} else {
				if (len != 15 && len != 18) {
					//身份证号码只能为15位或18位其它不合法
					return 0;
				}
			}
			var strBirthday = "";
			if (len == 18) {
				//处理18位的身份证号码从号码中得到生日和性别代码
				strBirthday =
					identityCard.substr(6, 4) +
					"/" +
					identityCard.substr(10, 2) +
					"/" +
					identityCard.substr(12, 2);
			}
			if (len == 15) {
				strBirthday =
					"19" +
					identityCard.substr(6, 2) +
					"/" +
					identityCard.substr(8, 2) +
					"/" +
					identityCard.substr(10, 2);
			}
			//时间字符串里，必须是“/”
			var birthDate = new Date(strBirthday);
			var nowDateTime = new Date();
			var age = nowDateTime.getFullYear() - birthDate.getFullYear();
			//再考虑月、天的因素;.getMonth()获取的是从0开始的，这里进行比较，不需要加1
			if (
				nowDateTime.getMonth() < birthDate.getMonth() ||
				(nowDateTime.getMonth() == birthDate.getMonth() &&
					nowDateTime.getDate() < birthDate.getDate())
			) {
				age--;
			}
			return age;
		},
		//查询评估版本
		findEtAssessList () {
			this.acessTemplateOptions = [];
			var params = {
				assessStatus: "10"
			};
			findEtAssessList(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.acessTemplateOptions.push({
								value: data[i].assessCode,
								name: data[i].assessName
							});
						}
						//只有一个评估版本默认选中
						// if (this.acessTemplateOptions.length == 1) {
						// 	this.filter.assessCode = this.acessTemplateOptions[0].value;
						// 	this.filter.assessName = this.acessTemplateOptions[0].name;
						// }
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					return false;
				});
		},
		//选择评估版本
		changeAssess (val) {
			var obj = {};
			obj = this.acessTemplateOptions.find(item => {
				return item.value === val;
			});
			this.filter.assessCode = obj.value;
			this.filter.assessName = obj.name;
		},
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "ASSESS_GRADE" })
				.then(response => {
					if (response.data.statusCode === "200") {
						this.assessGradeOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
				});
			findValueBySetCode({ valueSetCode: "ASSESS_ORDER_STATUS" })
				.then(response => {
					if (response.data.statusCode === "200") {
						this.assessStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
				});
			findValueBySetCode({ valueSetCode: "GENDER" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.staffGenderOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		pageChange (val) {
			this.filter.pageNum = val.page;
			this.filter.pageSize = val.limit;
			this.getList(val.page); //改变页码，重新渲染页面
		},
		handleClose () {
			this.dialogVisible = false;
		},
		//获取组织
		getCurrentNode (data) {
			this.filter.orgName = data.orgName;
			this.filter.orgCode = data.orgCode;
			this.handleClose();
		},
		//清空组织过滤
		clearOrgCode () {
			this.filter.orgName = "";
			this.filter.orgCode = "";
		},
		//合同类型
		changeContractType (val) {
			var obj = {};
			obj = this.contractList.find(item => {
				return item.value === val;
			});
			this.filter.contractType = obj.value;
		},
		//续签类型
		changeRenewContractType (val) {
			var obj = {};
			obj = this.renewalList.find(item => {
				return item.value === val;
			});
			this.filter.renewContractType = obj.value;
		},
		resetForm () {
			this.filter.keyTitle = "";
			this.filter.keyTitleValue = "";
			this.$refs.filterForm.resetFields();
			this.filter.orgCode = "";
			this.filter.assessorCode = "";
			this.getList(1);
		},
		getMapAssess (row, flag) {
			var that = this;
			var map = new BMap.Map("hidemap");
			var point = new BMap.Point(116.331398, 39.897445);
			map.centerAndZoom(point, 12);
			var geolocation = new BMap.Geolocation();
			geolocation.getCurrentPosition(
				function (r) {
					if (this.getStatus() == BMAP_STATUS_SUCCESS) {
						var mk = new BMap.Marker(r.point);
						map.addOverlay(mk);
						map.panTo(r.point);
						that.checkinLatitude = r.point.lat
						that.checkinLongitude = r.point.lng
						that.toAssess(row, flag)
						console.log("您的位置：" + r.point.lng + "," + r.point.lat);
					}
					// else {
					// 	console.log("failed" + this.getStatus());
					// }
				},
				{ enableHighAccuracy: true }
			);
		}
	},
	mounted () {

	},
	created () {
		//查询评估版本
		this.findEtAssessList();
		//查询数据字典
		this.initDataDictionary();
	},
	activated () {
		this.getList(1);
	}
};
</script>
<style lang="scss" scoped>
#assessmentList {
	width: 100%;
	min-width: 1000px;
	.el-form-item {
		margin-bottom: 0px;
	}
}
.el-input {
	min-width: 100px;
}
.el-select {
	min-width: 100px;
}
.form-item {
	width: 50%;
	min-width: 400px;
}
.form-items {
	width: 30%;
	min-width: 350x;
}
.search_btn {
	min-width: 250px;
	margin-left: 125px;
}
.tableToolbar .el-button + .el-button {
	margin-left: 0px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
</style>
<style lang="scss">
#assessmentList {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
</style>