<template>
  <div id="assessReport">
    <HeadTag :tagName="tagName" />
    <div class="main-content">
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">评估报告</span>
            <div class="rightBtn">
              <el-button
                @click="exportToPDF"
                size="small"
                primary
                v-if="!isShow"
                :loading="exportLoading"
              >导出评估报告</el-button>
              <el-button size="small" @click="cancelBtn()">返回</el-button>
            </div>
          </el-col>
        </el-row>
      </div>
      <div class="content">
        <!--startpoint-->
        <div class="left">
          <ul class="left-Box">
            <li v-for="(item,index) in reportList" :key="index">
              <div class="left-title" @click="showToggle(item,index)">
                <div class="report_title" :id="'jump'+index">
                  <img :src="item.isSubShow==true ? imgRight:imgLeft" v-if="showItemIcon" />
                  <div class="scroll-item" :id="'scrollItem'+index">{{item.formName}}</div>
                </div>
              </div>
              <div class="reportBox">
                <!-- type等于10,基础信息 -->
                <div v-if="item.type==10&&item.isSubShow&&item.formTitles.length>0">
                  <BaseInfoTable :formTitles="item.formTitles" />
                </div>

                <!-- type等于20,长者等级 -->
                <div v-if="item.type==20&&item.isSubShow&&item.formTitles.length>0">
                  <ComponentReportTexts :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于30,客户基本信息画像 -->
                <div v-if="item.type==30&&item.isSubShow&&item.formTitles.length>0">
                  <Personas :formTitles="item.formTitles" :isExportPdf="isExportPdf" />
                </div>
                <!-- type等于40,健康风险标签 -->
                <div v-if="item.type==40&&item.isSubShow &&item.formTitles.length>0">
                  <ComponentReportTexts :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于50,客户躯体症状 -->
                <div v-if="item.type==50&&item.isSubShow&&item.formTitles.length>0">
                  <ComponentCustomerSymptoms
                    :formTitles.sync="item.formTitles"
                    :dataType="item.type"
                  />
                </div>
                <!-- type等于60,客户既往病史 -->
                <div v-if="item.type==60&&item.isSubShow &&item.formTitles.length>0">
                  <ComponentCustomerMedical
                    :formTitles.sync="item.formTitles"
                    :dataType="item.type"
                  />
                </div>
                <!-- type等于70,感知觉与沟通能力 -->
                <div v-if="item.type==70&&item.isSubShow&&item.formTitles.length>0">
                  <componentReportText :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于80,日常生活活动 -->
                <div v-if="item.type==80&&item.isSubShow &&item.formTitles.length>0">
                  <componentReportText :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于90,精神状态与社会参与 -->
                <div v-if="item.type==90&&item.isSubShow&&item.formTitles.length>0">
                  <componentReportText :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于100,压疮发生风险评估 -->
                <div v-if="item.type==100&&item.isSubShow&&item.formTitles.length>0">
                  <ComponentReportTexts :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于110,跌倒风险评估 -->
                <div v-if="item.type==110&&item.isSubShow&&item.formTitles.length>0">
                  <ComponentReportTexts :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于120,服务需求 -->
                <div v-if="item.type==120&&item.isSubShow&&item.formTitles.length>0">
                  <componentReportText :formTitles.sync="item.formTitles" :dataType="item.type" />
                </div>
                <!-- type等于130,客户照护计划 -->
                <div v-if="item.type==130&&item.isSubShow == true&&item.formTitles.length>0">
                  <ComponentCustomerCarePlan
                    :formTitles.sync="item.formTitles"
                    :dataType="item.type"
                  />
                </div>
                <!-- type等于140,给家属的建议 -->
                <div
                  v-if="item.type==140&&item.isSubShow == true&&item.formTitles.length>0"
                  style="padding: 4px 24px 24px 15px;"
                >
                  <span v-if="inputDisbaled" style="color:#666">{{familyTitleValue}}</span>
                  <el-input
                    type="textarea"
                    v-model.trim="familyTitleValue"
                    clearable
                    size="mini"
                    placeholder="请输入家属建议"
                    class="titleValue-style"
                    maxlength="255"
                    show-word-limit
                    resize="none"
                    :disabled="inputDisbaled"
                    rows="4"
                    v-if="!inputDisbaled"
                  ></el-input>
                </div>
              </div>
            </li>
          </ul>
          <el-button
            v-if="isShow"
            style="width:60px;margin-left:40px;"
            @click="submitSuggest"
            :disabled="cancelDisabled"
            size="small"
            type="primary"
          >提交</el-button>
          <reportFooter :reportObj="reportObj" />
        </div>
        <!--endpoint-->
        <div class="right" id="nav-fixed" :class="{nav_fixed : isFixed}">
          <ul class="menu-right">
            <li
              v-for="(item,index) in reportList"
              :key="index"
              :class="activeStep === index ? 'colorClass':''"
              @click="jump(index)"
            >{{item.formName}}</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import {
  getAssessReport,
  addSuggest,
  getAssessOrderByCode
} from "api/assessment";
import componentReportText from "./components/ComponentReportText";
import ComponentReportTexts from "./components/ComponentReports";
import ComponentCustomerSymptoms from "./components/ComponentCustomerSymptoms";
import ComponentCustomerMedical from "./components/ComponentCustomerMedical";
import ComponentCustomerCarePlan from "./components/ComponentCustomerCarePlan";
import ComponentFamilyInput from "./components/ComponentFamilyInput";
import reportFooter from "./components/reportFooter";
import Personas from "./components/Personas";
import BaseInfoTable from "./components/BaseInfoTablePlus";
import htmlToPDF from "@/utils/htmlToPDF";
import { getAbsPosition, getStyleProperty, getStyle, setStyle } from "@/utils";

export default {
  components: {
    HeadTag,
    componentReportText,
    ComponentReportTexts,
    Personas,
    ComponentCustomerSymptoms,
    ComponentCustomerMedical,
    BaseInfoTable,
    ComponentCustomerCarePlan,
    ComponentFamilyInput,
    reportFooter
  },
  props: {},
  data() {
    return {
      tagName: "评估报告",
      loading: false,
      assessOrderCode: "",
      imgUrl: "",
      toggelIndex: 0,
      show: true,
      reportList: [],
      reportObj: {},
      imgLeft:
        process.env.NODE_ENV === "development"
          ? "/static/img/up-icon.png"
          : "/fsk/static/img/up-icon.png",
      imgRight:
        process.env.NODE_ENV === "development"
          ? "/static/img/down-icon.png"
          : "/fsk/static/img/down-icon.png",
      // imgRight: '/fsk/static/img/down-icon.png',
      isSubShow: null,
      activeStep: 0,
      isFixed: true,
      offsetTop: 0,
      inputDisbaled: false,
      cancelDisabled: false,
      familyTitleValue: "",
      familyAssessOrderCode: "",
      familyAssessCode: "",
      isShow: false,
      careReceiverName: "",
      showItemIcon: true,
      resumeNodeList: [],
      orginPaddingTopList: [],
      exportLoading: false,
      nodeList: [],
      isExportPdf: false
    };
  },
  watch: {},
  computed: {},
  methods: {
    submitSuggest() {
      if (this.familyTitleValue == "") {
        this.cancelDisabled = false;
        this.$message.error("请填写家属建议");
        return false;
      } else {
        this.cancelDisabled = true;
        var params = {
          assessOrderCode: this.familyAssessOrderCode,
          assessCode: this.familyAssessCode,
          formName: "给家属的建议",
          titleValue: this.familyTitleValue
        };
        addSuggest(params)
          .then(response => {
            if (
              response.data.statusCode == "200" ||
              response.data.statusCode == 200
            ) {
              this.$message.success("操作成功");
              this.cancelDisabled = false;
              this.$router.push({
                path: "/evaluationManagement/assessInformation"
              });
            } else {
              this.$message.error(response.data.statusMsg);
              this.cancelDisabled = false;
              return false;
            }
          })
          .catch(error => {
            console.log("getAssessReport:" + error);
          });
      }
    },
    //获取评估报告
    getAssessReport(assessOrderCode) {
      var params = {
        assessOrderCode: this.assessOrderCode
      };
      getAssessReport(params)
        .then(response => {
          if (
            response.data.statusCode == "200" ||
            response.data.statusCode == 200
          ) {
            this.reportList = response.data.responseData;
            // console.log(JSON.stringify(this.reportList))
            for (let i = 0; i < this.reportList.length; i++) {
              // console.log(this.reportList[i])
              this.reportList[i].isSubShow = true;
              /*  ("10", "基础信息"),("20", "长者等级"),("30", "客户基本信息画像"),
								("40", "健康风险标签"),("50", "客户躯体症状"),("60", "客户既往病史"),
								("70", "感知觉与沟通能力"),("80", "日常生活活动"),("90", "精神状态与社会参与"),
								("100", "压疮发生风险评估"),("110", "跌倒风险评估"),("120", "服务需求"),
								("130", "客户照护计划");  */
              if (this.reportList[i].type == "140") {
                let tableList = this.reportList[i].formTitles;
                for (let j = 0; j < tableList.length; j++) {
                  let titleList = tableList[j].titleValues;
                  for (let k = 0; k < titleList.length; k++) {
                    this.familyAssessOrderCode = titleList[j].assessOrderCode;
                    this.familyAssessCode = titleList[j].assessCode;
                    if (titleList[k].titleValue == "") {
                      this.inputDisbaled = false;
                      this.isShow = true;
                    } else {
                      this.inputDisbaled = true;
                      this.isShow = false;
                      this.familyTitleValue = titleList[k].titleValue;
                    }
                  }
                }
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getAssessReport:" + error);
        });
    },
    getAssessOrderByCode(assessOrderCode) {
      var params = {
        assessOrderCode: this.assessOrderCode
      };
      getAssessOrderByCode(params)
        .then(response => {
          if (
            response.data.statusCode == "200" ||
            response.data.statusCode == 200
          ) {
            this.reportObj = response.data.responseData;
            // console.log( response.data.responseData)
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getAssessReport:" + error);
        });
    },
    cancelBtn() {
      this.$router.push({
        path: "/evaluationManagement/assessInformation"
      });
    },
    submitBtn() {
      this.$refs.familyInput.SubmitSuggest();
    },
    showToggle(item, index) {
      // console.log(item, index, '999999')
      this.reportList.forEach(i => {
        // console.log(i, 'iiiiiiiiiiiii')
        // 判断如果数据中的reportList[i]的show属性不等于当前数据的isSubShow属性那么reportList[i]等于false
        if (i.isSubShow !== this.reportList[index].isSubShow) {
          // i.isSubShow = true;
          i.isSubShow = !this.reportList[index].isSubShow;
        }
      });
      item.isSubShow = !item.isSubShow;
      this.$forceUpdate();
    },
    jump(domId) {
      this.activeStep = domId;
      //获取头部是否固定
      let headerFlag = this.$store.state.settings.fixedHeader;
      // 当前窗口正中心位置到指定dom位置的距离
      //页面滚动了的距离
      let height =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      //指定dom到页面顶端的距离
      let dom = document.getElementById("jump" + domId);
      let domHeight;

      if (headerFlag) {
        domHeight = dom.offsetTop - 60;
      } else {
        domHeight = dom.offsetTop + 40;
      }

      //滚动距离计算
      var S = Number(height) - Number(domHeight);

      //判断上滚还是下滚
      if (S < 0) {
        //下滚
        S = Math.abs(S);
        window.scrollBy({ top: S, behavior: "smooth" });
      } else if (S == 0) {
        //不滚
        window.scrollBy({ top: 0, behavior: "smooth" });
      } else {
        //上滚
        S = -S;
        window.scrollBy({ top: S, behavior: "smooth" });
      }
    },
    // 滚动监听  滚动触发的效果写在这里
    handleScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop >= this.offsetTop) {
        this.isFixed = true;
      } else {
        this.isFixed = false;
      }
    },
    exportToPDF() {
      this.isExportPdf = true;
      this.handleWindowPrint('.left','评估报告-'+this.careReceiverName)
      // this.printMe(document.querySelector('.left'))
      return;
      this.showItemIcon = false;
      this.exportLoading = true;
      this.isExportPdf = true;
      var that = this;
      this.EventBus.handleEvent("finishedExportPDF", function(val) {
        that.exportLoading = false;
        that.isExportPdf = false;
        that.EventBus.post("refreshCurrent");
        that.EventBus.post("closeMenuBar");
      });
      this.EventBus.post("closeMenuBar");
      // document.body.innerHTML=document.querySelector('.left').outerHTML;
      //为每页底部留出空白
      // document.body.innerHTML=document.querySelector(".left").outerHTML
      // ele=document.querySelector(".left");
      // pdfContent.innerHTML=document.querySelector('.left').outerHTML
      //一页pdf显示html页面生成的canvas高度;
      // this.setChildNodes(pdfContent,pageHeight)
      setTimeout(() => {
        window.pageYoffset = 0;
        window.pageXOffset = 0;
        document.body.scrollTop = 0; // ie的
        document.body.scrollLeft = 0;
        var pdfContent = document.querySelector(".left");
        pdfContent.style.padding = "40px";
        var pageHeight = (pdfContent.offsetWidth / 592.28) * 841.89;
        if (document.documentElement) {
          document.documentElement.scrollTop = 0; // 其他
          document.documentElement.scrollLeft = 0;
        }
        var startTime = new Date().getTime();
        this.setChildNodes(pdfContent, pageHeight);
        console.log("耗时==" + (new Date().getTime() - startTime));
        setTimeout(() => {
          console.log("耗时==");
          //导出PDF
          htmlToPDF.downloadPDF(
            this,
            document.querySelector(".left"),
            "评估报告-" + this.careReceiverName
          );
          this.showItemIcon = true;
        }, 200);
      }, 800);
    },
    setChildNodes(item, pageHeight) {
      let paddingTop = 0;
      let originPaddingTop = "0px";
      if (item && item.style) {
        // item.originStyle=JSON.parse(JSON.stringify(getStyle(item)));
        item.originFontSize = getStyleProperty(item, "fontSize");
        item.originColor = getStyleProperty(item, "color");
        item.style.fontSize = "18px";
        item.style.color = "#000";
        if (item.nodeName == "TABLE") {
          item.originBorder = getStyleProperty(item, "border");
          item.style.border = "solid 1px #000";
          item.style.width = "100%";
        }
        if (item.nodeName == "TR") {
        }
        if (item.nodeName == "TH") {
          item.originBorder = getStyleProperty(item, "border");
          item.style.border = "solid 0.1px #000";
        }
        if (item.nodeName == "TD") {
          item.originBorderRight = getStyleProperty(item, "borderRight");
          item.originBorderBottom = getStyleProperty(item, "borderBottom");
          item.style.borderRight = "solid 1px #000";
          item.style.borderBottom = "solid 1px #000";
        }
        if (getStyleProperty(item, "borderRadius").indexOf("50%") != -1) {
          item.style.border = "solid 1px #000";
        }
        if (getStyleProperty(item, "borderBottom").indexOf("dashed") != -1) {
          item.style.borderBottom = "dashed 1px #000";
        }

        this.nodeList.push(item);
      }
      for (let i = 0; i < item.childNodes.length; i++) {
        var node = item.childNodes[i];
        if (node.offsetTop) {
          node.style.fontSize = "18px";
          node.style.color = "#000";
          // node.originStyle=JSON.parse(JSON.stringify(getStyle(node)));
          var obj = getAbsPosition(node);
          if (
            node.offsetTop &&
            obj.y > pageHeight &&
            (obj.y - 180) % pageHeight >= pageHeight - node.offsetHeight
          ) {
            //控件靠近分隔线
            if (node.offsetHeight <= 200) {
              if (
                node.offsetTop &&
                (node.nodeName == "TD" ||
                  node.nodeName == "SPAN" ||
                  node.innerHTML.indexOf("<") == -1)
              ) {
                if (paddingTop == 0) {
                  if (node.parentNode && node.nodeName == "TD") {
                    paddingTop =
                      node.parentNode.childNodes[
                        node.parentNode.childNodes.length - 1
                      ].offsetHeight;
                  } else if (
                    node.parentNode &&
                    node.nodeName == "SPAN" &&
                    node.parentNode.childNodes.length > 0
                  ) {
                    paddingTop = node.parentNode.offsetHeight;
                    if (originPaddingTop == "0px") {
                      originPaddingTop = getStyleProperty(
                        node.parentNode,
                        "paddingTop"
                      );
                    }
                    this.orginPaddingTopList.push(originPaddingTop);
                    // node.parentNode.style.backgroundColor="blue";
                    node.parentNode.style.paddingTop = paddingTop + 10 + "px";
                    this.resumeNodeList.push(node.parentNode);
                    break;
                  } else {
                    paddingTop = node.offsetHeight;
                  }
                }
                if (originPaddingTop == "0px") {
                  originPaddingTop = getStyleProperty(node, "paddingTop");
                }
                this.orginPaddingTopList.push(originPaddingTop);
                // node.style.backgroundColor="blue";
                node.style.paddingTop = paddingTop + 10 + "px";
                this.resumeNodeList.push(node);
              }
            }
          }
        }
        // 过滤 text 节点、script 节点
        if (node.nodeType != 3 && node.nodeName != "SCRIPT") {
          this.setChildNodes(node, pageHeight);
        }
      }
    },
     setChildNodes2(item) {
      let paddingTop = 0;
      let originPaddingTop = "0px";
      if (item && item.style) {
        // item.originStyle=JSON.parse(JSON.stringify(getStyle(item)));
        item.originFontSize = getStyleProperty(item, "fontSize");
        item.originColor = getStyleProperty(item, "color");
        item.style.fontSize = "18px";
        item.style.color = "#000";
        if (item.nodeName == "TABLE") {
          item.originBorder = getStyleProperty(item, "border");
          item.style.border = "solid 1px #000";
          item.style.width = "100%";
        }
        if (item.nodeName == "TR") {
        }
        if (item.nodeName == "TH") {
          item.originBorder = getStyleProperty(item, "border");
          item.style.border = "solid 0.1px #000";
        }
        if (item.nodeName == "TD") {
          item.originBorderRight = getStyleProperty(item, "borderRight");
          item.originBorderBottom = getStyleProperty(item, "borderBottom");
          item.style.borderRight = "solid 1px #000";
          item.style.borderBottom = "solid 1px #000";
        }
        if (getStyleProperty(item, "borderRadius").indexOf("50%") != -1) {
          item.style.border = "solid 1px #000";
        }
        if (getStyleProperty(item, "borderBottom").indexOf("dashed") != -1) {
          item.style.borderBottom = "dashed 1px #000";
        }

        this.nodeList.push(item);
      }
      for (let i = 0; i < item.childNodes.length; i++) {
        var node = item.childNodes[i];
        // if (node.offsetTop) {
        //   node.style.fontSize = "18px";
        //   node.style.color = "#000";
        //   // node.originStyle=JSON.parse(JSON.stringify(getStyle(node)));
        //   var obj = getAbsPosition(node);
        //   if (
        //     node.offsetTop &&
        //     obj.y > pageHeight &&
        //     (obj.y - 180) % pageHeight >= pageHeight - node.offsetHeight
        //   ) {
        //     //控件靠近分隔线
        //     if (node.offsetHeight <= 200) {
        //       if (
        //         node.offsetTop &&
        //         (node.nodeName == "TD" ||
        //           node.nodeName == "SPAN" ||
        //           node.innerHTML.indexOf("<") == -1)
        //       ) {
        //         if (paddingTop == 0) {
        //           if (node.parentNode && node.nodeName == "TD") {
        //             paddingTop =
        //               node.parentNode.childNodes[
        //                 node.parentNode.childNodes.length - 1
        //               ].offsetHeight;
        //           } else if (
        //             node.parentNode &&
        //             node.nodeName == "SPAN" &&
        //             node.parentNode.childNodes.length > 0
        //           ) {
        //             paddingTop = node.parentNode.offsetHeight;
        //             if (originPaddingTop == "0px") {
        //               originPaddingTop = getStyleProperty(
        //                 node.parentNode,
        //                 "paddingTop"
        //               );
        //             }
        //             this.orginPaddingTopList.push(originPaddingTop);
        //             // node.parentNode.style.backgroundColor="blue";
        //             node.parentNode.style.paddingTop = paddingTop + 10 + "px";
        //             this.resumeNodeList.push(node.parentNode);
        //             break;
        //           } else {
        //             paddingTop = node.offsetHeight;
        //           }
        //         }
        //         if (originPaddingTop == "0px") {
        //           originPaddingTop = getStyleProperty(node, "paddingTop");
        //         }
        //         this.orginPaddingTopList.push(originPaddingTop);
        //         // node.style.backgroundColor="blue";
        //         node.style.paddingTop = paddingTop + 10 + "px";
        //         this.resumeNodeList.push(node);
        //       }
        //     }
        //   }
        // }
        // 过滤 text 节点、script 节点
        if (node.nodeType != 3 && node.nodeName != "SCRIPT") {
          this.setChildNodes2(node);
        }
      }
    },
    handleWindowPrint(ele, fileName) {
      this.showItemIcon = false;
      document.querySelector(ele).style.width = "1000px";
      //留存原来的 html
      // let bdHtml = window.document.body.innerHTML;
      // let bdHtml = document.querySelector('#app').innerHTML;

      //要打印的 内容 html
      // document.body.innerHTML =  document.querySelector('#demo').innerHTML;
      // document.body.innerHTML =  document.querySelector('#demo').outerHTML;
      // document.querySelector('#app').innerHTML =  document.querySelector('#demo').outerHTML;
      // document.querySelector('#main').innerHTML =  document.querySelector('#demo').outerHTML;
      // console.log(666);
      //去除页面不必要的 head 标签内  内容， 避免影响打印页 ， title 为保存为 pdf 的文件时的 文件名
      // document.head.innerHTML = '<meta charset="utf-8">\n' +
      //     ' <title> ' + fileName + '</title>\n' +
      //     ' <link rel="shortcut icon" href="http://192.168.29.50:8081/favicon.ico" type="image/x-icon" />\n' +
      //     ' <meta name="format-detection" content="telephone=no">\n' +
      //     ' <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">\n' +
      //     ' <meta name="viewport" content="width=device-width,initial-scale=1.0">\n' +
      //     ' <link rel="stylesheet" href="./static/css/assessReport.scss" lang="scss"/>';  //生成pdf的外部css样式
      // document.body.innerHTML =  document.querySelector('#demo').outerHTML;
      // document.querySelector('#main').innerHTML =  document.querySelector('#demo').outerHTML;
      // document.body.innerHTML =  document.querySelector('#demo').outerHTML;

      // document.head.innerHTML = '<meta charset="utf-8">\n' +
      //     ' <title> ' + fileName + '</title>\n' +
      //     ' <meta name="viewport" content="width=device-width,initial-scale=1.0">\n';
      setTimeout(() => {
        document.body.innerHTML = document.querySelector(ele).outerHTML;
      }, 100);

      // window.print();

      //转异步 等待dom元素渲染（样式）完毕在打印
      setTimeout(() => {
        // var pwin = window.open("Print.htm", "print");
        // pwin.document.write(document.querySelector(ele).outerHTML);
        // pwin.document.close();
        // pwin.print();
        this.setChildNodes2(document.querySelector(ele))
        this.reportList.forEach((item,index)=>{
          document.querySelector("#scrollItem"+index).style.paddingTop="10px"
          document.querySelector("#scrollItem"+index).style.paddingBottom="10px"
          document.querySelector("#scrollItem"+index).style.fontSize="22px"
        })
        //打印
        window.print();
        // //刷新页面
        window.location.reload();
      }, 200);

      //重新设会当前页面
      // window.document.body.innerHTML = bdHtml;
      // document.querySelector('#app').innerHTML =  bdHtml;
      //刷新页面
      // window.location.reload();
    },
    preview() {
            var body = window.document.body.innerHTML;
            var startpoint= "<!--startpoint-->";
            var endpoint= "<!--endpoint-->";
            var printdb= body.substring(body.indexOf(startpoint) + 17); 
            printdb = printdb.substring(0, printdb.indexOf(endpoint));
            console.log("printdb==="+body)
            window.document.body.innerHTML = printdb ;
            window.print();
            window.document.body.innerHTML = body ;
    },
    printMe (content) {
      this.showItemIcon = false;
      var printDiv = document.createElement('div');
      printDiv.innerHTML=content.innerHTML;
      printDiv.style.position = 'fixed';
      printDiv.style.left = '0';
      printDiv.style.top = '0';
      printDiv.style.width = '100%';
      printDiv.style.height = '100%';
      printDiv.style.zIndex = '100000';
      printDiv.style.background = '#fff';
      printDiv.style.overflow = 'auto';
      this.setChildNodes2(printDiv)
        this.reportList.forEach((item,index)=>{
          document.querySelector("#scrollItem"+index).style.paddingTop="20px"
          document.querySelector("#scrollItem"+index).style.paddingBottom="20px"
          document.querySelector("#scrollItem"+index).style.fontSize="22px"
        })
      document.body.appendChild(printDiv);
      window.print();
      document.body.removeChild(printDiv);
    }
  },
  created() {
    //获得传入参数
    var param = this.$route.query;
    this.assessOrderCode = param.assessOrderCode;
    this.careReceiverName = param.careReceiverName;
    this.getAssessReport(this.assessOrderCode);
    this.getAssessOrderByCode(this.assessOrderCode);
  },
  destroyed() {
    // 设置bar浮动阈值为 #fixedBar 至页面顶部的距离
    this.offsetTop = document.querySelector("#nav-fixed").offsetTop;
    // 开启滚动监听
    window.addEventListener("scroll", this.handleScroll);
  },
  mounted() {
    // 离开页面 关闭监听 不然会报错
    window.removeEventListener("scroll", this.handleScroll);
  }
};
</script>
<style lang="scss" scoped>
/* 评估报告样式 */
#assessReport {
  width: 100%;
  min-width: 1024px;
}
.main-content {
  border-radius: 10px;
  margin: 0 16px;
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
}
.importToolbar {
  padding: 20px 0;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    margin: 0px 20px;
  }
  .rightBtn {
    float: right;
    margin-right: 36px;
  }
}
.content {
  display: flex;
  background: #ffffff;
  .left {
    width: 90%;
    .left-Box {
      li:not(:last-child) {
        padding: 10px 10px 10px 10px;
        list-style: none;
        .left-title {
          .report_title {
            vertical-align: middle;
            display: flex;
            img {
              width: 12px;
              height: 12px;
              color: #666666;
              display: inline-block;
              margin: 0 8px;
              vertical-align: middle;
              transition: 0.5s;
              transform-origin: center;
              transform: rotateZ(360deg);
            }
            img:active {
              width: 12px;
              height: 12px;
              color: #666666;
              display: inline-block;
              margin: 0 8px;
              vertical-align: middle;
              transition: transform 0.3s;
              transform-origin: center;
              transform: rotateX(-45deg);
            }
            .scroll-item {
              color: #333333;
              font-size: 20px;
              font-family: "Adobe Heiti Std R";
              vertical-align: middle;
            }
          }
        }
        .reportBox {
          padding: 14px 0 14px 0;
          border-bottom: 1px solid #ededed;
          margin-left: 24px;
          margin-right: 24px;
          .reportText {
            background: #e6e6e6;
            color: #333333;
            font-size: 16px;
            line-height: 20px;
          }
        }
      }
    }
    .left-Box {
      li:last-child {
        list-style: none;
        .left-title {
          .report_title {
            vertical-align: middle;
            margin-left: 10px;
            display: flex;
            img {
              width: 12px;
              height: 12px;
              color: #666666;
              display: inline-block;
              margin: 0 8px;
              vertical-align: middle;
              transition: 0.5s;
              transform-origin: center;
              transform: rotateZ(360deg);
            }
            img:active {
              width: 12px;
              height: 12px;
              color: #666666;
              display: inline-block;
              margin: 0 8px;
              vertical-align: middle;
              transition: transform 0.3s;
              transform-origin: center;
              transform: rotateX(-45deg);
            }
            .scroll-item {
              color: #333333;
              font-size: 20px;
              font-family: "Adobe Heiti Std R";
              vertical-align: middle;
            }
          }
        }
        .reportBox {
          padding: 14px 0 14px 0;
          // border-bottom: 1px solid #ededed;
          margin-left: 24px;
          margin-right: 24px;
          .reportText {
            background: #e6e6e6;
            color: #606266;
            font-size: 16px;
            line-height: 20px;
          }
        }
      }
    }
  }
}
.right {
  position: fixed; /*fixed总是以body为定位时的对象，总是根据浏览器的窗口来进行元素的定位，通过"left"、 "top"、 "right"、 "bottom" 属性进行定位。*/
  right: 15px; /*设置与右侧的距离*/
  top: 179px; /*设置与底部的距离*/
  width: 10%;
  height: 600px;
  border: 1px solid #e4e5e6;
  .menu-right {
    background: #ffffffff;
    line-height: 34px;
    overflow-y: scroll;
    list-style: none;
    height: 595px;
    li {
      padding: 0 0 14px 15px;
      font-size: 14px;
      font-family: "Adobe Heiti Std";
      // font-weight: 600;
      color: #333333;
    }
    .colorClass {
      font-size: 14px;
      color: #398af1;
      font-family: "Adobe Heiti Std";
      font-weight: 600;
      border-left: 1px solid #398af1;
    }
  }
}
</style>
<style lang="scss">
::-webkit-scrollbar {
  display: none;
}

/* 长者等级 健康风险标签 压疮发生风险评估 跌倒风险评估*/
.report_type_text {
  li {
    font-size: 20px;
    color: #f98c3c;
    line-height: 20px;
    margin-left: 20px;
    line-height: 32px;
  }
}
/* 感知觉与沟通能力 日常生活活动 精神状态与社会参与 服务需求*/

.report_type_color {
  background: #f7f7f7;
  list-style: none;
  padding: 0px 20px 0 20px;
  li {
    font-size: 14px;
    color: #606266;
    line-height: 32px;
  }
}
/* 客户照护计划 */
.customer_care {
  p {
    margin: 22px 0 25px 0;
    font-size: 16px;
    color: #606266;
  }
}
/* 客户既往病史 */
.customer_medical {
  div {
    .customer_title {
      font-size: 16px;
      color: #606266;
      margin-right: 5px;
    }
    span {
      .titileColor {
        color: #f98c3c;
        font-size: 14px;
        margin-right: 10px;
        line-height: 32px;
        background: rgba(249, 140, 60, 0.08);
      }
    }
  }
  .table_medical {
    p {
      margin: 30px 0 20px 0;
      font-size: 16px;
      color: #333333;
    }
  }
}
/* 评估底部 */
.footer {
  background: #ffffff;
  text-align: center;
  padding: 30px 0 20px 0;
  span {
    color: #606266;
    font-size: 16px;
    margin-right: 14px;
    // font-weight: 700;
  }
}
</style>
