<template>
  <div>
    <!-- <div class="main-left"> -->
    <div id="nav-fixed" class="nav_fixed">
      <el-row>
        <el-col>
          <i class="el-icon-user">
            <span class="mLeft10">客户信息</span>
          </i>
        </el-col>
      </el-row>
      <br>
      <el-row class="demo-avatar demo-basic">
        <el-col>
          <div class="demo-basic--circle">
            <span v-if="assesserInfo.careReceiverIcon">
              <el-avatar
                size="large"
                style="vertical-align: middle;"
                :src="assesserInfo.careReceiverIcon"
              ></el-avatar>
            </span>
            <span v-else>
              <el-avatar
                size="large"
                style="vertical-align: middle;"
                src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
              ></el-avatar>
            </span>
            <span class="mLeft15">{{assesserInfo.careReceiverName}}</span>
            <span class="mLeft15">{{assesserInfo.careReceiverGenderValue}}</span>
            <span class="mLeft15">
              <span v-if="assesserInfo.careReceiverAge">{{assesserInfo.careReceiverAge}}岁</span>
            </span>
          </div>
        </el-col>
      </el-row>
      <br>
      <hr style="border-color:#f6f7fa;">
      <br>
      <el-row>
        <el-col>
          <i class="el-icon-tickets">
            <span class="mLeft10">评估表</span>
          </i>
        </el-col>
      </el-row>
      <br>
      <!-- {{queryTableList}} -->
      <el-menu ref="menuList" id="menuList" :default-active="activeIndex" @select="handleMenu">
        <el-menu-item
          v-for="(tbList,i) in queryTableList"
          :key="i"
          :index="''+tbList.formSort"
          v-if="tbList.isOpen == '1'"
        >
          <span slot="title">
            <span v-if="tbList.isAnswer == '1'">
              <i class="el-icon-check" style="color:#67C23A;font-size:20px;"></i>{{tbList.formName}}
            </span>
            <span v-else>
              <div style="display: -webkit-inline-box;width: 28px;"></div>{{tbList.formName}}
            </span>
          </span>
        </el-menu-item>
      </el-menu>
    </div>
    <!-- </div> -->
    <div class="mainRight">
      <el-row class="importToolbar">
        <el-col :span="24">
          <span class="form-tag">{{formName}}</span>
          <span v-if="careInfoForm.isFinish === '1' && (isDisabled == false || isDisabled == 'false')">
            <el-button
              type="primary"
              size="small"
              class="rightBtn"
              :loading="loadingBtn"
              @click="completeAssess"
            >完成</el-button>
          </span>
          <el-button size="small" class="rightBtn" @click="returnAssessList">返回</el-button>
        </el-col>
      </el-row>
      <el-row class="mainContent">
        <span v-if="isCareInfo == true">
          <el-card class="box-card mg20">
            <div slot="header" class="clearfix">
              <span style="font-size:15px;font-weight:800;">申请人信息</span>
              <span v-if="isDisabled == false || isDisabled == 'false'">
                <el-button
                  type="primary"
                  size="mini"
                  style="float: right;"
                  :disabled="saveDisabled"
                  v-if="isEdit"
                  @click="saveCareInfoForm('careInfoForm')"
                >保存</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  style="float: right;"
                  v-if="!isEdit"
                  @click="openEdit()"
                >修改</el-button>
              </span>
              <span v-else></span>
            </div>
            <el-form
              ref="careInfoForm"
              :inline="false"
              :model="careInfoForm"
              :rules="careInfoFormRules"
              label-width="200px"
              class="form-content"
            >
              <div class="panel-card">
                <el-row>
                  <el-col class="form-item">
                    <el-form-item label="申请人姓名" prop="careReceiverName">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverName}}</span>
                      <span v-if="isEdit == true">
                        <el-input
                          v-model="careInfoForm.careReceiverName"
                          size="mini"
                          clearable
                          placeholder="请输入申请人姓名"
                          :disabled="isDisableds"
                          maxlength="10"
                        />
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="性别" prop="careReceiverGender">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverGenderValue}}</span>
                      <span v-if="isEdit == true">
                        <el-select
                          v-model="careInfoForm.careReceiverGender"
                          :disabled="isDisableds"
                          size="mini"
                          clearable
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in genderOptions"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                          ></el-option>
                        </el-select>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="身份证号" prop="careReceiverIdCard">
                      <span>{{careInfoForm.careReceiverIdCard}}</span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="出生年月" prop="careReceiverBirthday">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverBirthday}}</span>
                      <span v-if="isEdit == true">
                        <el-input
                          v-model="careInfoForm.careReceiverBirthday"
                          size="mini"
                          :disabled="true"
                        ></el-input>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="年龄" prop="careReceiverAge">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverAge}}</span>
                      <span v-if="isEdit == true">
                        <el-input
                          v-model="careInfoForm.careReceiverAge"
                          size="mini"
                          :disabled="true"
                        ></el-input>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="联系方式" prop="careReceiverTel">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverTel}}</span>
                      <span v-if="isEdit == true">
                        <el-input
                          v-model="careInfoForm.careReceiverTel"
                          size="mini"
                          clearable
                          placeholder="请输入联系方式"
                          maxlength="11"
                        />
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="现居住省市区" prop="liveSubdistrictName">
                      <span v-if="isEdit == false">
                        <span
                          v-if="careInfoForm.liveSubdistrictName"
                          class="long-field"
                        >{{careInfoForm.liveProvinceName}}/{{careInfoForm.liveCityName}}/{{careInfoForm.liveDistrictName}}/{{careInfoForm.liveSubdistrictName}}</span>
                      </span>
                      <span v-if="isEdit == true">
                        <el-cascader
                          v-model="live"
                          placeholder="请选择现居住省市区"
                          size="mini"
                          :options="liveOptions"
                          :show-all-levels="false"
                          @active-item-change="handleExpandChangeLive"
                          @change="addLiveToForm"
                          @visible-change="changeLive"
                          ref="liveList"
                          :props="{
                    value: 'id',
                    label: 'name',
                    children: 'cities'
                  }"
                        ></el-cascader>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                      <span
                        v-if="isEdit == false"
                        class="long-field"
                      >{{careInfoForm.liveDetailAddress}}</span>
                      <span v-if="isEdit == true">
                        <el-tooltip
                          class="item"
                          effect="dark"
                          :disabled="careInfoForm.liveDetailAddress == '' ? true : false"
                          :content="careInfoForm.liveDetailAddress"
                          placement="top"
                        >
                          <el-input
                            v-model="careInfoForm.liveDetailAddress"
                            @focus="openMap"
                            size="mini"
                            clearable
                            placeholder="请输入现居住详细地址"
                            maxlength="50"
                          />
                        </el-tooltip>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="户籍省市区" prop="houseDistrictName">
                      <span v-if="isEdit == false">
                        <span
                          v-if="careInfoForm.houseDistrictName"
                          class="long-field"
                        >{{careInfoForm.houseProvinceName}}/{{careInfoForm.houseCityName}}/{{careInfoForm.houseDistrictName}}</span>
                      </span>
                      <span v-if="isEdit == true">
                        <el-cascader
                          v-model="house"
                          placeholder="请选择户籍省市区"
                          size="mini"
                          :options="houseOptions"
                          :show-all-levels="false"
                          @active-item-change="handleExpandChangeHouse"
                          @change="addHouseToForm"
                          @visible-change="changeHouse"
                          ref="houseList"
                          :props="{
                    value: 'id',
                    label: 'name',
                    children: 'cities'
                  }"
                        ></el-cascader>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                      <span
                        v-if="isEdit == false"
                        class="long-field"
                      >{{careInfoForm.houseDetailAddress}}</span>
                      <span v-if="isEdit == true">
                        <el-input
                          v-model="careInfoForm.houseDetailAddress"
                          size="mini"
                          clearable
                          placeholder="请输入户籍详细地址"
                          maxlength="50"
                        />
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="最高学历" prop="careReceiverEducation">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverEducationValue}}</span>
                      <span v-if="isEdit == true">
                        <el-select
                          v-model="careInfoForm.careReceiverEducation"
                          size="mini"
                          clearable
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in educationOptions"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                          ></el-option>
                        </el-select>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="婚姻状况" prop="maritalStatus">
                      <span v-if="isEdit == false">{{careInfoForm.maritalStatusValue}}</span>
                      <span v-if="isEdit == true">
                        <el-select
                          v-model="careInfoForm.maritalStatus"
                          size="mini"
                          clearable
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in maritalStatusOptions"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                          ></el-option>
                        </el-select>
                      </span>
                    </el-form-item>
                  </el-col>
                  <el-col class="form-item">
                    <el-form-item label="宗教信仰" prop="careReceiverFaith">
                      <span v-if="isEdit == false">{{careInfoForm.careReceiverFaithValue}}</span>
                      <span v-if="isEdit == true">
                        <el-select
                          v-model="careInfoForm.careReceiverFaith"
                          size="mini"
                          clearable
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in faithOptions"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                          ></el-option>
                        </el-select>
                      </span>
                    </el-form-item>
                  </el-col>
                </el-row>
              </div>
            </el-form>
          </el-card>
        </span>
        <span v-if="isShow == true">
          <el-form
            ref="queryForm"
            :inline="false"
            :rules="rules"
            :model="queryForm"
            label-width="50px"
          >
            <FormItemTemplate
              :propertyList="queryPropertyList"
              :queryFormItem="queryForm"
              ref="FormItemTemplate"
            />
            <span v-if="isDisabled == false || isDisabled == 'false'">
              <el-button
                type="primary"
                size="mini"
                class="saveBtn"
                :loading="saveLodingBtn"
                @click="saveTable('queryForm')"
              >保存该表</el-button>
            </span>
            <span v-else></span>
          </el-form>
        </span>
        <el-backtop target=".mainContent">
          <i class="el-icon-caret-top"></i>
        </el-backtop>
      </el-row>

      <map-point
        v-if="this.showMap"
        @GetMapPoint="getAddressDetail"
        @closeDialog="closeDialog"
        :placeholder="'请输入现居住详细地址'"
        :maxLength="50"
        :address="careInfoForm.liveDetailAddress"
        :provinceAddress="careInfoForm.liveProvinceName"
        :cityAddress="careInfoForm.liveCityName"
        :districtAddress="careInfoForm.liveDistrictName"
        :liveLongitude="careInfoForm.liveLongitude"
        :liveLatitude="careInfoForm.liveLatitude"
        :checkinLatitude="careInfoForm.checkinLatitude"
        :checkinLongitude="careInfoForm.checkinLongitude"
      ></map-point>
    </div>
  </div>
</template>

<script>
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail
} from "@/utils/validate";
import MapPoint from "components/MapPoint";
import { findValueBySetCode, findAddressDictList } from "api/common";
import {
  editAssessOrder,
  getAssessOrderForm,
  getFormInfoByFormId,
  saveAssessOrderTitle,
  addAssessReport
} from "api/assessment";
import FormItemTemplate from "components/FormItem/FormItemTemplate";

export default {
  data() {
    return {
      //按钮加载
      loadingBtn: false,
      saveLodingBtn: false,
      //是否滚动
      isFixed: false,
      //是否展示基本信息
      isCareInfo: true,
      //是否展示动态问答
      isShow: false,
      //保存禁用
      saveDisabled: false,
      //控制地图弹窗
      showMap: false,
      //是否可以修改
      isEdit: false,
      formName: "",
      activeIndex: "1",
      rules: {},
      setScrollTop: 0,
      careInfoForm: {
        assessOrderCode: "",
        careReceiverName: "",
        careReceiverGender: "",
        careReceiverBirthday: "",
        careReceiverAge: "",
        careReceiverIdCard: "",
        careReceiverTel: "",
        houseProvinceCode: "",
        houseProvinceName: "",
        houseCityCode: "",
        houseCityName: "",
        houseDistrictCode: "",
        houseDistrictName: "",
        houseDetailAddress: "",
        liveProvinceCode: "",
        liveProvinceName: "",
        liveCityCode: "",
        liveCityName: "",
        liveDistrictCode: "",
        liveDistrictName: "",
        liveSubdistrictCode: "",
        liveSubdistrictName: "",
        liveDetailAddress: "",
        liveLongitude: "",
        liveLatitude: "",
        maritalStatus: "",
        careReceiverFaith: "",
        careReceiverEducation: "",
        formIndex: "",
        isFinish: "0",
        checkinLatitude:"",
        checkinLongitude:""
      },
      careInfoFormRules: {
        careReceiverName: [
          {
            required: true,
            message: "请输入申请人姓名",
            trigger: "input"
          }
        ],
        careReceiverIdCard: [
          {
            required: true,
            message: "请输入身份证号",
            trigger: "blur"
          },
          {
            required: true,
            trigger: "blur",
            validator: validateIdCard
          }
        ],
        careReceiverGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        careReceiverTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          }
        ],
        houseProvinceName: [
          {
            required: true,
            message: "请选择户籍省市区",
            trigger: "input"
          }
        ],
        houseDetailAddress: [
          {
            required: true,
            message: "请输入户籍详细地址",
            trigger: "blur"
          }
        ],
        liveProvinceName: [
          {
            required: true,
            message: "请选择现居住省市区",
            trigger: "input"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "input"
          }
        ]
      },
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载现居住省市区
      liveOptions: [],
      live: [],
      liveName: [],
      //性别
      genderOptions: [],
      //最高学历
      educationOptions: [],
      //婚姻状况
      maritalStatusOptions: [],
      //宗教信仰
      faithOptions: [],
      //动态问答Form
      queryForm: {
        assessOrderCode: "",
        assessCode: "",
        formId: "",
        formName: "",
        formSort: "",
        formRelationType: "",
        formRelationId: "",
        remark: "",
        assessTitleInDtos: []
      },
      queryTableList: [],
      queryPropertyList: [],
      //传参
      assesserInfo: {},
      isDisabled: false
    };
  },
  components: {
    FormItemTemplate,
    MapPoint
  },
  methods: {
    handleMenu(index) {
      this.isShow = false;
      this.activeIndex = index.toString();
      if (index == 1) {
        this.isCareInfo = true;
      } else {
        this.isCareInfo = false;
      }

      this.formName = this.queryTableList[index - 1].formName;
      if (this.queryPropertyList.length > 0) {
        this.queryPropertyList = [];
      }
      this.$nextTick(() => {
        this.queryForm.assessOrderCode = this.careInfoForm.assessOrderCode;
        this.queryForm.assessCode = this.queryTableList[index - 1].assessCode;
        this.queryForm.formId = this.queryTableList[index - 1].id;
        this.queryForm.formName = this.queryTableList[index - 1].formName;
        this.queryForm.formSort = this.queryTableList[index - 1].formSort;
        this.queryForm.formRelationType = this.queryTableList[
          index - 1
        ].relationType;
        this.queryForm.formRelationId = this.queryTableList[
          index - 1
        ].relationId;
      });
      var params = {
        formId: this.queryTableList[index - 1].id,
        assessOrderCode: this.careInfoForm.assessOrderCode
      };
      getFormInfoByFormId(params)
        .then(response => {
          if (
            response.data.statusCode == "200" ||
            response.data.statusCode == 200
          ) {
            var data = response.data.responseData;
            var list = [];
            for (let i = 0; i < data.length; i++) {
              data[i].isDisabled = this.isDisabled;
              list.push(data[i]);
            }
            this.queryPropertyList = list;
            //组装数据
            this.queryForm.assessTitleInDtos = JSON.parse(JSON.stringify(list));
            this.queryForm.assessTitleInDtos.forEach(item => {
              if (!item.assessOrderTitleValues) {
                var arr = [];
                var obj;
                if (
                  item.assessTitleValueOutDtos &&
                  item.assessTitleValueOutDtos.length > 0
                ) {
                  obj = {
                    titleId: item.id || "", //题目ID",
                    titleType: item.titleType || "", //"题目类型",
                    titleName: item.titleName || "", //"题目名称",
                    titleClass: item.titleClass || "", //"题目分类",
                    titleScore: item.titleScore || "", //"题目分值",
                    titleSort: item.titleSort || "", //"题目顺序",
                    titleRelationType: item.relationType || "", //"题关联类型"
                    titleRelationId: item.relationId || "", //"题关联ID",
                    titleValueId: "", // "题目值ID",
                    titleValue: "", //"题目值",
                    titleValueClass:
                      item.assessTitleValueOutDtos[0].valueClass || "", //"题目值分类",
                    valueScore:
                      item.assessTitleValueOutDtos[0].valueScore || "0", //"题目值分值",
                    valueSort: item.assessTitleValueOutDtos[0].valueSort || "", //"顺序",
                    valueRelationType:
                      item.assessTitleValueOutDtos[0].relationType || "", //"值关联类型",
                    valueRelationId:
                      item.assessTitleValueOutDtos[0].relationId || "", //"值关联ID",
                    remark: item.assessTitleValueOutDtos[0].remark || "" //"remark"
                  };
                  arr.push(obj);
                } else {
                  obj = {
                    titleId: item.id || "", //题目ID",
                    titleType: item.titleType || "", //"题目类型",
                    titleName: item.titleName || "", //"题目名称",
                    titleClass: item.titleClass || "", //"题目分类",
                    titleScore: item.titleScore || "", //"题目分值",
                    titleSort: item.titleSort || "", //"题目顺序",
                    titleRelationType: item.relationType || "", //"题关联类型"
                    titleRelationId: item.relationId || "", //"题关联ID",
                    titleValueId: "", // "题目值ID",
                    titleValue: "", //"题目值",
                    titleValueClass: "", //"题目值分类",
                    valueScore: item.titleScore || "0", //"题目值分值",
                    valueSort: item.titleSort || "", //"顺序",
                    valueRelationType: item.relationType || "", //"值关联类型",
                    valueRelationId: item.relationId || "", //"值关联ID",
                    remark: item.remark || "" //"remark"
                  };
                  arr.push(obj);
                }
                this.$set(item, "assessOrderTitleValues", arr);
                if (item.titleType == "102" || item.titleType == "104") {
                  this.$set(item, "filled", []);
                  this.$set(item, "relationFilled", []);
                  for (let i = 0; item.assessTitleValueOutDtos && i < item.assessTitleValueOutDtos.length; i++) {
                    if(item.assessTitleValueOutDtos[i].relationTitle) {
                        this.$set(item.assessTitleValueOutDtos[i].relationTitle,"relationFilled",[]);
                    }
                  }
                } else {
                  this.$set(item, "filled", "");
                  this.$set(item, "relationFilled", "");
                  for (let i = 0; item.assessTitleValueOutDtos && i < item.assessTitleValueOutDtos.length; i++) {
                    if(item.assessTitleValueOutDtos[i].relationTitle) {
                        this.$set(item.assessTitleValueOutDtos[i].relationTitle,"relationFilled","");
                    }
                  }
                }
              } else {
                this.$set(
                  item,
                  "assessOrderTitleValues",
                  item.assessOrderTitleValues
                );
                this.$set(item, "filled", []);
                this.$set(item, "relationFilled", []);
                for (let i = 0; item.assessTitleValueOutDtos && i < item.assessTitleValueOutDtos.length; i++) {
                  if(item.assessTitleValueOutDtos[i].relationTitle) {
                      this.$set(item.assessTitleValueOutDtos[i].relationTitle,"relationFilled",[]);
                  }
                }
              }
            });
            this.isShow = true;
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getFormInfoByFormId:" + error);
        });
    },
    //提交该表
    saveTable(formName) {
      console.log("this.queryForm 提交时", this.queryForm);
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.saveLodingBtn = true;
          var activeFrom = this.queryForm; //当前保存的表数据
          saveAssessOrderTitle(this.queryForm)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$message.success("保存成功");
                this.findAssessOrderForm();
                this.saveLodingBtn = false;
              } else {
                this.$message.error(response.data.statusMsg);
                this.saveLodingBtn = false;
                return false;
              }
            })
            .catch(error => {
              this.$message.error(this.ConstantData.requestErrorMsg);
              this.saveLodingBtn = false;
            });
        } else {
          var list = this.queryForm.assessTitleInDtos;
          var noReq = "";
          for (let i = 0; i < list.length; i++) {
            if(list[i].assessOrderTitleValues.length == 0 || list[i].assessOrderTitleValues[0].titleValue == ""){
              noReq = "jump"+i
              break;
            }
          }
          this.$refs.FormItemTemplate.jump(noReq);
          return false;
        }
      });
    },
    //开启基本信息修改
    openEdit() {
      this.isEdit = true;
      this.$nextTick(() => {
        this.$refs[
          "houseList"
        ].inputValue = this.careInfoForm.houseDistrictName;
        this.$refs[
          "liveList"
        ].inputValue = this.careInfoForm.liveSubdistrictName;
      });
    },
    /**
     *
     * 申请人信息保存
     *
     */
    saveCareInfoForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //保存禁用
          this.saveDisabled = true;
          var params = {
            assessOrderCode: this.assesserInfo.assessOrderCode,
            careReceiverName: this.careInfoForm.careReceiverName,
            careReceiverGender: this.careInfoForm.careReceiverGender,
            careReceiverAge: this.careInfoForm.careReceiverAge,
            careReceiverBirthday: this.careInfoForm.careReceiverBirthday,
            careReceiverIdCard: this.careInfoForm.careReceiverIdCard,
            careReceiverTel: this.careInfoForm.careReceiverTel,
            houseProvinceCode: this.careInfoForm.houseProvinceCode,
            houseProvinceName: this.careInfoForm.houseProvinceName,
            houseCityCode: this.careInfoForm.houseCityCode,
            houseCityName: this.careInfoForm.houseCityName,
            houseDistrictCode: this.careInfoForm.houseDistrictCode,
            houseDistrictName: this.careInfoForm.houseDistrictName,
            houseDetailAddress: this.careInfoForm.houseDetailAddress,
            liveProvinceCode: this.careInfoForm.liveProvinceCode,
            liveProvinceName: this.careInfoForm.liveProvinceName,
            liveCityCode: this.careInfoForm.liveCityCode,
            liveCityName: this.careInfoForm.liveCityName,
            liveDistrictCode: this.careInfoForm.liveDistrictCode,
            liveDistrictName: this.careInfoForm.liveDistrictName,
            liveSubdistrictCode: this.careInfoForm.liveSubdistrictCode,
            liveSubdistrictName: this.careInfoForm.liveSubdistrictName,
            liveDetailAddress: this.careInfoForm.liveDetailAddress,
            liveLongitude: this.careInfoForm.liveLongitude,
            liveLatitude: this.careInfoForm.liveLatitude,
            careReceiverEducation: this.careInfoForm.careReceiverEducation,
            maritalStatus: this.careInfoForm.maritalStatus,
            careReceiverFaith: this.careInfoForm.careReceiverFaith,
            checkinLatitude:this.careInfoForm.checkinLatitude,
            checkinLongitude:this.careInfoForm.checkinLongitude,
          };
          editAssessOrder(params)
            .then(response => {
              if (
                response.data.statusCode == "200" ||
                response.data.statusCode == 200
              ) {
                this.$message.success("保存成功");
                this.findAssessOrderForm();
                this.saveDisabled = false;
                this.isEdit = false;
              } else {
                this.$message.error(response.data.statusMsg);
                this.saveDisabled = false;
                return false;
              }
            })
            .catch(error => {
              console.log("editAssessOrder:" + error);
              this.saveDisabled = false;
            });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    //查询评估模板对应表信息
    findAssessOrderForm() {
      var params = {
        assessCode: this.assesserInfo.assessCode,
        assessOrderCode: this.assesserInfo.assessOrderCode
      };
      getAssessOrderForm(params)
        .then(response => {
          if (
            response.data.statusCode == "200" ||
            response.data.statusCode == 200
          ) {
            var data = response.data.responseData;
            this.careInfoForm.assessOrderCode = data.assessOrderCode;
            this.careInfoForm.careReceiverName = data.careReceiverName;
            this.careInfoForm.careReceiverGender = data.careReceiverGender;
            this.careInfoForm.careReceiverGenderValue = data.careReceiverGenderValue;
            this.careInfoForm.careReceiverBirthday = data.careReceiverBirthday;
            this.careInfoForm.careReceiverIdCard = data.careReceiverIdCard;
            this.careInfoForm.careReceiverAge = data.careReceiverAge;
            this.careInfoForm.careReceiverTel = data.careReceiverTel;
            this.careInfoForm.houseProvinceCode = data.houseProvinceCode;
            this.careInfoForm.houseProvinceName = data.houseProvinceName;
            this.careInfoForm.houseCityCode = data.houseCityCode;
            this.careInfoForm.houseCityName = data.houseCityName;
            this.careInfoForm.houseDistrictCode = data.houseDistrictCode;
            this.careInfoForm.houseDistrictName = data.houseDistrictName;
            this.careInfoForm.houseDetailAddress = data.houseDetailAddress;
            this.careInfoForm.liveProvinceCode = data.liveProvinceCode;
            this.careInfoForm.liveProvinceName = data.liveProvinceName;
            this.careInfoForm.liveCityCode = data.liveCityCode;
            this.careInfoForm.liveCityName = data.liveCityName;
            this.careInfoForm.liveDistrictCode = data.liveDistrictCode;
            this.careInfoForm.liveDistrictName = data.liveDistrictName;
            this.careInfoForm.liveSubdistrictCode = data.liveSubdistrictCode;
            this.careInfoForm.liveSubdistrictName = data.liveSubdistrictName;
            this.careInfoForm.liveDetailAddress = data.liveDetailAddress;
            this.careInfoForm.liveLongitude = data.liveLongitude;
            this.careInfoForm.liveLatitude = data.liveLatitude;
            this.careInfoForm.careReceiverEducation =
              data.careReceiverEducation;
            this.careInfoForm.careReceiverEducationValue = data.careReceiverEducationValue;
            this.careInfoForm.maritalStatus = data.maritalStatus;
            this.careInfoForm.maritalStatusValue = data.maritalStatusValue;
            this.careInfoForm.careReceiverFaith = data.careReceiverFaith;
            this.careInfoForm.careReceiverFaithValue = data.careReceiverFaithValue;
            this.careInfoForm.checkinLatitude = data.checkinLatitude;
            this.careInfoForm.checkinLongitude = data.checkinLongitude;
            if (this.isDisabled == true || this.isDisabled == 'true') {
              //如果评估详情查看默认第一张表
              this.careInfoForm.formIndex = 1;
            } else {
              //获取当前表index
              this.careInfoForm.formIndex = data.formIndex;
            }
            //获取当前表格完成状态
            this.careInfoForm.isFinish = data.isFinish
              ? data.isFinish.toString()
              : "0";
            //获取评估表模板
            this.queryTableList = data.assessFormOutDtos;
            this.handleMenu(this.careInfoForm.formIndex);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getAssessOrderForm:" + error);
        });
    },
    //加载户籍省市区
    getHouseNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.houseOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //户籍选择下拉框
    handleExpandChangeHouse(val) {
      this.getHouseNodes(val);
    },
    //将户籍省市区注入到Form中
    addHouseToForm(val) {
      this.house = val;
      this.houseName = this.$refs["houseList"].getCheckedNodes();
      this.careInfoForm.houseProvinceCode = this.house[0];
      this.careInfoForm.houseProvinceName = this.houseName[0].pathLabels[0];
      this.careInfoForm.houseCityCode = this.house[1];
      this.careInfoForm.houseCityName = this.houseName[0].pathLabels[1];
      this.careInfoForm.houseDistrictCode = this.house[2];
      this.careInfoForm.houseDistrictName = this.houseName[0].pathLabels[2];
    },
    changeHouse(val) {
      this.$refs["houseList"].presentText = "";
      if (!val) {
        this.$refs[
          "houseList"
        ].inputValue = this.careInfoForm.houseDistrictName;
        this.$refs[
          "houseList"
        ].presentText = this.careInfoForm.houseDistrictName;
      }
    },
    //加载现居住省市区
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      } else if (val.length === 3) {
        idArea = val[2];
        sizeArea = val.length; //三级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name,
                          cities: []
                        };
                      });
                    }
                  }
                });
              }
            });
          } else if (sizeArea === 3) {
            // 点击三级 加载四级 街道
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    value.cities.map((value, i) => {
                      if (value.id === val[2]) {
                        if (!value.cities.length) {
                          // Items.pop();  //移除最后一个数组元素
                          value.cities = Items.map((value, i) => {
                            return {
                              id: value.id,
                              name: value.name
                            };
                          });
                        }
                      }
                    });
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.careInfoForm.liveProvinceCode = this.live[0];
      this.careInfoForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.careInfoForm.liveCityCode = this.live[1];
      this.careInfoForm.liveCityName = this.liveName[0].pathLabels[1];
      this.careInfoForm.liveDistrictCode = this.live[2];
      this.careInfoForm.liveDistrictName = this.liveName[0].pathLabels[2];
      this.careInfoForm.liveSubdistrictCode = this.live[3];
      this.careInfoForm.liveSubdistrictName = this.liveName[0].pathLabels[3];
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs[
          "liveList"
        ].inputValue = this.careInfoForm.liveSubdistrictName;
        this.$refs[
          "liveList"
        ].presentText = this.careInfoForm.liveSubdistrictName;
      }
    },
    //获取现居住详细地址
    openMap() {
      this.showMap = true;
    },
    closeDialog(flag) {
      this.showMap = flag;
    },
    getAddressDetail(data) {
      this.careInfoForm.liveDetailAddress = data[0];
      this.careInfoForm.liveLongitude = data[1].lng;
      this.careInfoForm.liveLatitude = data[1].lat;
    },
    /**
     *
     * 返回评估管理列表
     *
     */
    returnAssessList() {
      this.$router.back();
    },
    /**
     * 完成评估
     *
     */
    completeAssess() {
      this.loadingBtn = true;
      var params = {
        assessOrderCode: this.assesserInfo.assessOrderCode,
        liveLongitude: this.careInfoForm.liveLongitude,
        liveLatitude: this.careInfoForm.liveLatitude
      };
      addAssessReport(params)
        .then(response => {
          if (
            response.data.statusCode == "200" ||
            response.data.statusCode == 200
          ) {
            this.$message.success("操作完成");
            this.$router.push({
              path: "/evaluationManagement/assessReport",
              query: {
                assessOrderCode: this.assesserInfo.assessOrderCode
              }
            });
            this.loadingBtn = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.loadingBtn = false;
            return false;
          }
        })
        .catch(error => {
          console.log("editAssessOrder:" + error);
          this.loadingBtn = false;
        });
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //婚姻状况
      findValueBySetCode({ valueSetCode: "RECRUIT_MARITAL_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.maritalStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //宗教信仰
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    var param = this.$route.query;
    this.assesserInfo = param.assesserInfo;
    this.isDisabled = param.isDisabled; //false：评估，ture：评估详情
    if (this.assesserInfo && this.assesserInfo.assessOrderCode == undefined) {
      this.assesserInfo = JSON.parse(sessionStorage.getItem("seeAssesserInfo"));
    } else {
      sessionStorage.setItem(
        "seeAssesserInfo",
        JSON.stringify(this.assesserInfo)
      );
    }
    if(this.isDisabled) {
      this.$router.currentRoute.meta.title = "评估详情"
    } else {
      this.$router.currentRoute.meta.title = "评估信息"
    }
  },
  mounted() {
    //初始化数据字典
    this.initDataDictionary();
    //加载户籍省市区
    this.getHouseNodes();
    //加载现居住省市区
    this.getLiveNodes();
    //加载模板列表
    this.findAssessOrderForm();
  },
  destroyed() {
    //清除被照护人信息
    sessionStorage.removeItem("seeAssesserInfo");
  }
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.panel-card {
  padding: 20px 0px;
  overflow: hidden;
}
.form-item {
  width: 30%;
  min-width: 400px;
  height: 60px;
}
.el-main {
  padding: 0px;
}
.mLeft10 {
  margin-left: 10px;
}
.mLeft15 {
  margin-left: 15px;
}
.mg20 {
  margin: 20px;
}
.el-menu {
  border: 0px;
  .el-menu-item {
    height: 40px;
    line-height: 40px;
  }
}
.importToolbar {
  padding: 15px 0px 15px 0px;
  background: #f6f7fa;
  line-height: 30px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    margin: 0px 20px;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.main-left {
  margin: 20px 20px 0px 20px;
  padding: 10px;
  background: #fff;
  min-width: 250px;
  float: left;
}
.nav_fixed {
  position: fixed;
  padding: 10px;
  background: #fff;
  margin: 70px 20px 0px 20px;
  min-width: 250px;
  z-index: 2;
  top: 0;
  height: calc(100vh - 90px);
  overflow-y: scroll;
}
.mainRight {
  margin: 20px 20px 0px 300px;
  min-width: 710px;
  background: #fff;
  height: calc(100vh - 90px);
}
.mainContent {
  height: calc(100vh - 155px);
  overflow-y: scroll;
  overflow-x: hidden;
}
.saveBtn {
  margin: 30px 0px 30px 150px;
}
</style>
<style>
.el-form-item__error {
  padding-bottom: 10px;
}
</style>