<template>
	<div v-if="dataType==140">
		<el-input
			type="textarea"
			v-model.trim="titleValue"
			clearable
			size="mini"
			placeholder="请输入家属建议"
			class="titleValue-style"
			maxlength="255"
			show-word-limit
			resize="none"
			:disabled="inputDisbaled"
			rows="4"
		></el-input>
		<!-- <el-button
			v-if="isShow"
			style="width:60px;margin-top:40px;"
			@click="SubmitSuggest"
			:disabled="cancelDisabled"
			size="small"
			type="primary"
		>提交</el-button> -->
	</div>
</template>

<script>
import { getAssessReport, addSuggest } from "api/assessment";

export default {
	components: {},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			titleValue: '',
			cancelDisabled: false,
			assessOrderCode: '',
			assessCode: '',
			inputDisbaled: false,
			isShow: false,
		};
	},
	watch: {
	},
	computed: {},
	methods: {
		SubmitSuggest () {
			if (this.titleValue == '') {
				this.cancelDisabled = false
				this.$message.error("请填写家属建议");
				return false;
			} else {
				this.cancelDisabled = true
				var params = {
					assessOrderCode: this.assessOrderCode,
					assessCode: this.assessCode,
					formName: '给家属的建议',
					titleValue: this.titleValue
				}
				addSuggest(params)
					.then(response => {
						if (
							response.data.statusCode == "200" ||
							response.data.statusCode == 200
						) {
							this.$message.success("操作成功");
							this.cancelDisabled = false
							this.$router.push({
								path: "/evaluationManagement/assessInformation"
							});
						} else {
							this.$message.error(response.data.statusMsg);
							this.cancelDisabled = false
							return false;
						}
					})
					.catch(error => {
						console.log("getAssessReport:" + error);
					});

			}

		}
	},
	created () {
		if (this.formTitles) {
			for (let i = 0; i < this.formTitles.length; i++) {
				// console.log(this.formTitles[i].titleValues, '111111')
				let tableList = this.formTitles[i].titleValues
				for (let j = 0; j < tableList.length; j++) {
					// console.log(tableList[j])
					this.assessOrderCode = tableList[j].assessOrderCode
					this.assessCode = tableList[j].assessCode
					if (tableList[j].titleValue == '') {
						this.inputDisbaled = false
						this.isShow = true
					} else {
						this.inputDisbaled = true
						this.isShow = false
						this.titleValue = tableList[j].titleValue
					}
					// if (tableList[j].titleValue) {
					// 	console.log(tableList[j].titleValue)
					// 	this.titleValue = tableList[j].titleValue
					// 	debugger;
					// 	if (this.titleValue !== '') {
					// 		this.inputDisbaled = true
					// 		this.isShow = false
					// 	} else {
					// 		this.inputDisbaled = false
					// 		this.isShow = true
					// 	}
					// }
				}
			}
		}

	},
	mounted () {

	},
};
</script>
<style lang="scss" scoped>

</style>