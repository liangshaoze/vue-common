<template>
	<div v-if="dataType==60" class="customer_medical">
		<div v-for="(items,index) in formTitles" :key="index">
			<div class="table_medical" v-if="items.titleName=='既往疾病'||items.titleName=='用药情况'">
				<p>{{items.titleName}}</p>
				<el-table
					size="small"
					v-loading="listLoading"
					:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
					border
					:data="tableOneData[index]"
					:show-header="true"
				>
					<el-table-column
						v-for="(item,index) in tableColumn[index]"
						:key="index"
						:label="item.label"
						:prop="item.prop"
						:width="item.width"
					>
						<template slot-scope="scope">{{scope.row[item.prop]}}</template>
					</el-table-column>
				</el-table>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			tableData: [], //存放表格数据
			tableContent: [],
			tableColumn: [],
			tableOneContent: [],
			tableOneData: [],
			tableHeader: [],//存放表格title
			listLoading: false

		};
	},
	watch: {
	},
	computed: {},
	methods: {
		//创建表格结构
		createTableName (index) {
			var array = [];
			var str = this.tableHeader[index].split("|");
			var s = "";
			for (let i = 0; i < str.length; i++) {
				// s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
				if (index == 0) {
					if (i == 0) {
						s += '{"prop":"property' + i + '","label": "' + str[i] + '","width":"300"}|';

					} else {
						s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
					}
				} else {
					s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
				}
			}
			if (s) {
				var s1 = s.split("|");
				for (let i = 0; i < s1.length - 1; i++) {
					s1[i]=s1[i].replace(/\n/g, "");
					array.push(JSON.parse(s1[i]));
				}
			}
			if (array.length > 0) {
				this.tableColumn[index] = array;
			}
		},
		// 表格内容
		handleContent (index) {
			var contentStr = this.tableOneContent[index].split("#");
			var list = [];
			for (let k = 0; k < contentStr.length - 1; k++) {
				var array = [];
				var objlist = {};
				var str = contentStr[k].split("|");
				var s = "";
				for (let i = 0; i < str.length; i++) {
					s += '{"property' + [i] + '": "' + str[i] + '"}*';
				}
				if (s) {
					var s1 = s.split("*");
					for (let i = 0; i < s1.length - 1; i++) {
						s1[i]=s1[i].replace(/\n/g, "");
						array.push(JSON.parse(s1[i]));
					}
				}
				if (array.length > 0) {
					array.forEach(item => {
						for (var k in item) {
							objlist[k] = item[k];
						}
					})
					list[k] = objlist;
				}
				objlist.tableIndex = index;
			}
			this.tableOneData.push(list)
		},
		mergeColumns (tableData) {
			// let spanOneArr = [],
			let spanTwoArr = [],
				// concatOne = 0,
				concatTwo = 0;
			tableData.forEach((item, index) => {
				if (index === 0) {
					// spanOneArr.push(1);
					spanTwoArr.push(1);
				} else {
					// if (item.property0 === tableData[index - 1].property0) {
					// 	//第一列需合并相同内容的判断条件
					// 	spanOneArr[concatOne] += 1;
					// 	spanOneArr.push(0);
					// } else {
					// 	spanOneArr.push(1);
					// 	concatOne = index;
					// }
					if (item.property1 === tableData[index - 1].property1) {
						//第二列和需合并相同内容的判断条件
						spanTwoArr[concatTwo] += 1;
						spanTwoArr.push(0);
					} else {
						spanTwoArr.push(1);
						concatTwo = index;
					}
				}
			});
			return {
				// one: spanOneArr,
				two: spanTwoArr
			};
		},
		spanMethod ({ row, column, rowIndex, columnIndex }) {
			// if (columnIndex === 0) {
			// 	const _row = this.mergeColumns(this.tableOneData[row.tableIndex]).one[rowIndex];
			// 	const _col = _row > 0 ? 1 : 0;
			// 	return {
			// 		rowspan: _row,
			// 		colspan: _col
			// 	};
			// }
			if (column.label == '注意事项') {
				if (columnIndex === 1) {
					const _row = this.mergeColumns(this.tableOneData[row.tableIndex]).two[rowIndex];
					const _col = _row > 0 ? 1 : 0;
					return {
						rowspan: _row,
						colspan: _col
					};
				}
			}
		},
	},
	created () {
		if (this.formTitles.length > 0) {
			for (let i = 0; i < this.formTitles.length; i++) {
				let tableList = this.formTitles[i].titleValues //每条表格
				let tableType = this.formTitles[i].titleName //每条表格类型
				this.tableHeader[i] = tableList[0].titleValue //每个表格的标题
				if (tableType == '既往疾病' || tableType == '用药情况') {
					let tableOne = this.formTitles[i].titleValues
					var contentStr = ''
					for (let j = 1; j < tableOne.length; j++) {
						contentStr += tableOne[j].titleValue + "#"
					}

				}
				this.tableOneContent[i] = contentStr
				this.createTableName(i);//单独处理表头
				this.handleContent(i)//处理表格内容
			}

		}

	},
	mounted () {

	},
};
</script>
<style lang="scss" scoped>
.table_medical {
	p {
		margin: 20px 0 20px 0;
		font-size: 16px;
		color: #333333;
	}
}
</style>