<template>
	<div v-if="dataType==50">
		<el-table
			border
			:span-method="objectSpanMethod"
			v-loading="listLoading"
			:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
			:data="tableData"
			:show-header="true"
		>
			<el-table-column
				v-for="(item,index) in tableColumn"
				:key="index"
				:label="item.label"
				:prop="item.prop"
			>
				<!-- <template slot-scope="scope">
					<span v-if="!scope.row.isEdit">{{scope.row[item.prop]}}</span>
					<span>
						<el-input v-if="scope.row.isEdit" v-model="scope.row[item.prop]"></el-input>
					</span>
				</template>-->
				<template slot-scope="scope">{{scope.row[item.prop]}}</template>
			</el-table-column>
			<!-- <el-table-column label="操作" width="200">
				<template slot-scope="scope">
					<el-button
						type="danger"
						size="mini"
						@click="deleteRow(scope.$index, tableData,scope.row.id)"
					>删除</el-button>
					<el-button
						type="primary"
						size="mini"
						v-if="!scope.row.isEdit"
						@click="editRow(scope.$index,scope.row)"
					>编辑</el-button>
					<el-button
						size="mini"
						type="primary"
						v-if="scope.row.isEdit"
						@click="handleSaveRow(scope.$index, scope.row)"
					>保存</el-button>
				</template>
			</el-table-column>-->
		</el-table>
	</div>
</template>

<script>
export default {
	components: {},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			thHeader: [], //存放表头数据
			tableData: [], //存放表格数据
			tableLabel: [], //渲染内容数据
			tableContent: [],
			tableColumn: [],
			titleString: '',
			listLoading: false,
			tableString: '',
			baseItem: {},
			spanArr: [],
			spanCodeArr: [],
			pos: '',
			codePos: '',
			position: ''
		};
	},
	watch: {
		thHeader (newValue, oldValue) {
			// console.log(newValue, oldValue)
		},
		dataType (newValue, oldValue) {
			// console.log(newValue, oldValue)
		}
	},
	computed: {},
	methods: {
		deleteRow (index, tableData, id) {
			console.log(index, tableData, id)
			this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
				confirmButtonText: "确定",
				cancelButtonText: "取消",
				type: "warning"
			})
				.then(() => {
					tableData.splice(index, 1);
					this.$message.success("删除成功");
					// if (this.familyStatusForm.tableData[$index].id) {
					// 	var params = {
					// 		recruitCode: this.basicForm.recruitCode,
					// 		id: this.familyStatusForm.tableData[$index].id
					// 	};
					// 	deleteRecruitFamily(params)
					// 		.then(response => {
					// 			if (response.data.statusCode == 200) {
					// 				this.familyStatusForm.tableData.splice($index, 1);
					// 				this.$message.success("删除成功");
					// 			} else {
					// 				this.$message.error(response.data.statusMsg);
					// 				return false;
					// 			}
					// 		})
					// 		.catch(error => {
					// 			console.log("deleteRecruitFamily:" + error);
					// 			return false;
					// 		});
					// } else {
					// 	this.familyStatusForm.tableData.splice($index, 1);
					// 	this.$message.success("删除成功");
					// }
				})
				.catch(err => {
					return false;
				});
		},
		editRow (index, row) {
			console.log(index, row)
			this.$set(row, 'isEdit', true)
		},
		handleSaveRow (index, row) {
			let saveString = row.property0 + '|' + row.property1 + '|' + row.property2
			console.log(saveString, '99999')
			this.$set(row, 'isEdit', false)
		},
		//创建表格结构
		createTableName () {
			var array = [];
			// var operationString = this.baseItem.titleName + "|" + '操作'
			// console.log(operationString, '999')
			var str = this.baseItem.titleName.split("|");
			var s = "";
			for (let i = 0; i < str.length; i++) {
				s += '{"prop":"property' + i + '","label": "' + str[i] + '","isEdit":"false"}|';
			}
			// console.log(s,'11111')
			if (s) {
				var s1 = s.split("|");
				for (let i = 0; i < s1.length - 1; i++) {
					s1[i]=s1[i].replace(/\n/g, "");
					array.push(JSON.parse(s1[i]));
				}
			}
			if (array.length > 0) {
				this.tableColumn = array;
			}
			// console.log(this.tableColumn, '7777')
		},
		// 表格内容
		handleContent () {
			for (let k = 0; k < this.tableContent.length; k++) {
				// console.log(this.tableContent[k], this.tableContent.length)
				// var operationString = this.tableContent[k] + "|" + '操作'
				var array = [];
				var objlist = {};
				var str = this.tableContent[k].value.split("|");
				for (let i = 0; i < str.length; i++) {
					objlist['property' + i] = str[i];
				}
				objlist.id = this.tableContent[k].id
				this.tableData.push(objlist)
				// console.log(this.tableData,'8888')
			}

		},
		//排序部位
		sortCompare () {
			var compare = function (obj1, obj2) {
				var val1 = obj1.property0;
				var val2 = obj2.property0;
				if (val1 > val2) {
					return -1;
				} else if (val1 < val2) {
					return 1;
				} else {
					return 0;
				}
			}
			return compare;
		},
		getSpanArr (data) {
			let dataArr = data.sort(this.sortCompare())
			// console.log(dataArr,'dataArr')
			for (var i = 0; i < dataArr.length; i++) {
				if (i === 0) {
					this.spanArr.push(1);
					this.pos = 0
				} else {
					// 判断当前元素与上一个元素是否相同
					if (dataArr[i].property0 === dataArr[i - 1].property0) {
						// console.log(data[i].property0, '99999')
						this.spanArr[this.pos] += 1;
						this.spanArr.push(0);
					} else {
						this.spanArr.push(1);
						this.pos = i;
					}
				}
			}
		},
		objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
			if (columnIndex === 0) {
				const _row = this.spanArr[rowIndex];
				const _col = _row > 0 ? 1 : 0;
				// console.log(`rowspan:${_row} colspan:${_col}`)
				return {
					rowspan: _row,
					colspan: _col
				}
			}

		},

	},
	created () {
		if (this.formTitles.length > 0) {
			for (let i = 0; i < this.formTitles.length; i++) {
				let tableList = this.formTitles[i].titleValues
				this.baseItem.titleName = tableList[0].titleValue
				for (let j = 1; j < tableList.length; j++) {
					// this.tableContent[j - 1] = tableList[j].titleValue
					this.tableContent.push({
						value: tableList[j].titleValue,
						id: tableList[j].id
					})
				}
				// console.log(this.tableContent)
			}
			this.createTableName();//单独处理表头
			this.handleContent()//处理表格内容
		}

	},
	mounted () {
		this.getSpanArr(this.tableData)
	},
};
</script>
<style lang="scss" scoped>
</style>