<template>
	<div v-if="dataType==20||dataType==40||dataType==100||dataType==110">
		<div v-if="dataType==20||dataType==100||dataType==110" class="report_type_text">
			<span v-for="(val,index) in dataList" :key="index">{{val.titleValue}}</span>
		</div>
		<div v-if="dataType==40" class="report_type_text_four">
			<span v-for="(val,index) in dataList" :key="index">{{val.titleValue}}</span>
		</div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			dataList: []
		};
	},
	watch: {
		dataList (newValue, oldValue) {
			// console.log(newValue, oldValue)
		},
		dataType (newValue, oldValue) {
			// console.log(newValue, oldValue)
		}

	},
	computed: {},
	methods: {

	},
	created () {
		if (this.formTitles) {
			this.formTitles.forEach(ele => {
				// console.log(ele.titleValues, '数据')
				this.dataList = [...ele.titleValues]
			})

		}
	},
	mounted () {

	}
};
</script>
<style lang="scss" scoped>
.report_type_text {
	span {
		font-size: 14px;
		color: #f98c3c;
		line-height: 40px;
		margin-left: 5px;
		background: rgba(249, 140, 60, 0.08);
	}
}
.report_type_text_four {
	span {
		background: rgba(249,140,60, 0.08);
		font-size: 14px;
		color: #F75C4C;
		line-height: 40px;
		// font-weight: 700;
		margin-left: 10px;
		padding: 4px;
		border-radius: 2px;
	}
}
</style>