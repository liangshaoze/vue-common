import BaseTableAdapter from "components/widget/base-table-adapter";
import {
  editAssessTitleOrder,
  delAssessTitleOrder,
  findAssessService
} from "api/assessment";
export default {
  mixins: [BaseTableAdapter],
  data() {
    return {
      serviceItemsOptions:[],
      selectedServiceItem:{}
    };
  },
  methods: {
    getColumns(tableColumn) {
      var columns = [];
      if (tableColumn) {
        tableColumn.forEach(column => {
          if (column.label == "服务项") {
            columns.push({
              propertyName: column.label,
              propertyFieldName: column.prop,
              propertyType: "50",
              queryMethod: "findServiceItem",
            });
          } else if(column.label == "痛点"){
            columns.push({
              propertyName: column.label,
              propertyFieldName: column.prop,
              propertyType: "10",
              canEdit:false,
            });
          }else {
            columns.push({
              propertyName: column.label,
              propertyFieldName: column.prop,
              propertyType: "10",
            });
          }
        });
      }
      return columns;
    },
    getTableFormModel(tableData) {
      var tableFormModel = {
        dataList: tableData
      }
      return tableFormModel;
    },
    setTableDataList(dataList) {
      this.tableFormModel.dataList = dataList.filter((item, index) => {
        return index > 0;
      })
    },
    findServiceItem(query, cb) {
      var param = {
        serviceItem: query
      };
      findAssessService(param)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.serviceItems = [];
            var data = response.data.responseData;
            this.serviceItemsOptions = data;
            for (let i = 0; i < data.length; i++) {
              this.serviceItems.push({
                value: data[i].serviceItem,
                code: data[i].serviceCode
              });
            }
            var results = this.serviceItems;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => { });
    },
    saveRow(index, row, table) {
      var titleName = "";
      table.propertyList.forEach((item, index) => {
        titleName += item.propertyName + (index != table.propertyList.length - 1 ? "|" : "");
      })
      var titleValue = "";
      for (let field in row) {
        if (field.indexOf('property') != -1) {
          titleValue += row[field] + "|"
        }
      }
      titleValue = titleValue.substring(0, titleValue.length - 1);
      var param = {
        id: row.id,
        // titleName: titleName,//TODO
        titleValue: titleValue,
      }
      editAssessTitleOrder(param)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.$message.success("修改成功~")
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg)
        });
    },
    deleteRow(index,row,table){//删除行
      var param = {
        id: row.id,
      }
      delAssessTitleOrder(param)
        .then(response => {
          if (response.data.statusCode === "200") {
            table.formModel.dataList.splice(index,1);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg)
        });
    },
    changeEvent(val,layoutIndex,fieldName,table){
      var propertyList = table.propertyList;
      var propertyItem = propertyList.find(item=>{
        return item.propertyFieldName == fieldName;
      })
      if(val==""){//清空
        if(this.selectedServiceItem){
            var arr = this.selectedServiceItem.services.split("|");
            arr.forEach((item,i)=>{
              if(item){
                table.formModel.dataList[layoutIndex]["property"+i] = "";
              }
            })
        }
        return;
      }
      if(propertyItem){
        var result = this.serviceItemsOptions.find(item=>{
          return item.serviceCode==val;
        })
        if(result){
          this.selectedServiceItem=result;
          var services = result.services;
          var arr = services.split("|");
          arr.forEach((item,i)=>{
            if(item){
              table.formModel.dataList[layoutIndex]["property"+i] = item;
            }
          })
        }
        
      }
    }
  }
};