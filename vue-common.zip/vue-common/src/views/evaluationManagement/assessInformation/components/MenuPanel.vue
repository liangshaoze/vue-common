<template>
  <div ref="menuPanel" :class="{show:show}" class="menuPanel-container">
    <div class="menuPanel-background" />
    <div class="menuPanel">
      <div class="handle-button" :style="{'top':'100px','background-color':'rgb(24, 144, 255)'}" @click="show=!show">
        <i :class="show?'el-icon-s-unfold':'el-icon-s-fold'" />
      </div>
      <div class="menuPanel-items">
        <slot />
      </div>
    </div>
  </div>
</template>

<script>
import { addClass, removeClass } from 'utils'

export default {
  name: 'MenuPanel',
  data() {
    return {
      show: false
    }
  },
  watch: {
    show(value) {
      if (value) {
        this.addEventClick()
      }
      if (value) {
        addClass(document.body, 'showMenuPanel')
      } else {
        removeClass(document.body, 'showMenuPanel')
      }
    }
  },
  mounted() {
    this.insertToBody()
  },
  beforeDestroy() {
    const elx = this.$refs.menuPanel
    elx.remove()
  },
  methods: {
    addEventClick() {
      window.addEventListener('click', this.closeSidebar)
    },
    closeSidebar(evt) {
      const parent = evt.target.closest('.menuPanel')
      if (!parent) {
        this.show = false
        window.removeEventListener('click', this.closeSidebar)
      }
    },
    insertToBody() {
      const elx = this.$refs.menuPanel
      const body = document.querySelector('body')
      body.insertBefore(elx, body.firstChild)
    }
  }
}
</script>

<style>
.showMenuPanel {
  overflow: hidden;
  position: relative;
  width: calc(100% - 15px);
}
</style>

<style lang="scss" scoped>
.menuPanel-background {
  position: fixed;
  top: 0;
  left: 0;
  opacity: 0;
  transition: opacity .3s cubic-bezier(.7, .3, .1, 1);
  background: rgba(0, 0, 0, .2);
  z-index: -1;
}

.menuPanel {
  width: 100%;
  max-width: 260px;
  height: 100vh;
  position: fixed;
  top: 0;
  right: 0;
  box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, .05);
  transition: all .25s cubic-bezier(.7, .3, .1, 1);
  transform: translate(100%);
  background: #fff;
  z-index: 40000;
}

.show {
  transition: all .3s cubic-bezier(.7, .3, .1, 1);

  .menuPanel-background {
    z-index: 20000;
    opacity: 1;
    width: 100%;
    height: 100%;
  }

  .menuPanel {
    transform: translate(0);
  }
}

.handle-button {
  width: 35px;
  height: 35px;
  position: absolute;
  left: -35px;
  text-align: center;
  border-radius: 6px 0 0 6px !important;
  z-index: 0;
  pointer-events: auto;
  cursor: pointer;
  color: #fff;
  line-height: 35px;
  i {
    font-size: 18px;
    line-height: 35px;
  }
}
</style>
