<template>
	<div v-if="dataType==120||dataType==90||dataType==80||dataType==70">
		<ul  class="report_type_color" v-for="(val,index) in dataList" :key="index">
			<li>{{index+Number(1)+'.'}}{{val}}</li>
		</ul>
	</div>
</template>

<script>
export default {
	components: {},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			dataList: []
		};
	},
	watch: {
		dataList (newValue, oldValue) {
			// console.log(newValue, oldValue)
		},
		dataType (newValue, oldValue) {
			// console.log(newValue, oldValue)
		}
	},
	computed: {},
	methods: {

	},
	created () {
		if (this.formTitles) {
				for (let i = 0; i < this.formTitles.length; i++) {
					let tabList=this.formTitles[i].titleValues
					for(let j = 0; j < tabList.length; j++){
						this.dataList.push(tabList[j].titleValue)
					}
				}		
		}
	},
	mounted () {

	}
};
</script>
<style lang="scss" scoped>
li{
	list-style: none;
}
</style>