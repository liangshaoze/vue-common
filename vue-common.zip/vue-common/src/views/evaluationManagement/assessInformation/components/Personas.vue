<template>
	<div style="background-color:white;padding:10px">
		<!-- <div :class="ScreenFitter.className('pcStyle','padStyle')" :style="ScreenFitter.style({width:30,height:50,backgroundColor:'red'})"></div> -->
		<el-row type="flex" justify="center">
			<el-col class="valueContainer">
				<div style="width:100%">
					<ul>
						<li class="itemLi" v-for="(item,index) in leftList" :key="index">
							<div class="itemDot">&nbsp;</div>
							<div style="width:100%">
								<el-row type="flex">
									<div class="itemTitle">{{item.title}}</div>
									<img src="@/assets/img/assess_xie_left.png" v-if="!isExportPdf" class="leftXie" />
									<img src="@/assets/img/assess_xie_left_pdf.png" v-if="isExportPdf" class="leftXie" />
									<div class="itemValue">
										<div>{{item.relateItem}}</div>
									</div>
								</el-row>
							</div>
						</li>
					</ul>
				</div>
			</el-col>
			<div>
				<img v-if="male" src="@/assets/img/assess_male.png" style="width:130px;min-height:450px;" />
				<img v-if="!male" src="@/assets/img/assess_female.png" style="width:130px;min-height:450px;" />
			</div>
			<el-col class="valueContainer">
				<div style="width:100%">
					<ul>
						<li class="itemLi" v-for="(item,index) in rightList" :key="index">
							<div style="width:100%">
								<el-row type="flex" :style="{visibility:item.title==''?'hidden':'visible'}">
									<div class="itemValue">
										<div>{{item.relateItem}}</div>
									</div>
									<img src="@/assets/img/assess_xie_right.png" v-if="!isExportPdf" class="rightXie" />
									<img src="@/assets/img/assess_xie_right_pdf.png" v-if="isExportPdf" class="rightXie" />
									<div class="itemTitle">{{item.title}}</div>
								</el-row>
							</div>
							<div class="itemDot" :style="{visibility:item.title==''?'hidden':'visible'}">&nbsp;</div>
						</li>
					</ul>
				</div>
			</el-col>
		</el-row>
	</div>
</template>
<script>
export default {
	data () {
		return {
			male: true,
			colCount: 2,
			dataList: [],
			leftList: [],
			rightList: [],
		}
	},
	props: {
		formTitles: {
			type: Array,
			default: () => { }
		},
		isExportPdf:{
			type:Boolean,
			default:false
		}
	},
	methods: {
		setDataList () {
			for (let i = 0; i < this.dataList.length; i++) {
				if (i % 2 == 0) {
					this.leftList.push(this.dataList[i])
				} else {
					this.rightList.push(this.dataList[i])
				}
				if(this.dataList[i].title=="性别"&&this.dataList[i].relateItem=="女"){
					this.male=false;
				}
			}
			if (this.rightList.length != this.leftList.length) {
				this.rightList.push({
					title: "",
					relateItem: "",
				});
			}
		},
	},
	created () {
		if (this.formTitles) {
			this.formTitles.forEach(element => {
				this.dataList.push({
					title: element.titleName,
					relateItem: element.titleValues && element.titleValues.length > 0 ? element.titleValues[0].titleValue : "",
				});
			});
			this.setDataList();
		}
	}
}
</script>
<style  scoped>
.valueContainer {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
}
.itemLi {
	display: flex;
	justify-content: center;
	align-items: center;
}
.itemDot {
	border: 1px solid #c9c7c7;
	border-radius: 50%;
	width: 10px;
	height: 10px;
}
.itemTitle {
	width: 150px;
	border-bottom: 1px dashed #c9c7c7;
	height: 30px;
	align-items: center;
	display: flex;
	justify-content: center;
}
.leftXie {
	width: 40px;
	margin-top: 30px;
}
.rightXie {
	width: 40px;
	margin-top: 30px;
}
.itemValue {
	border-bottom: 1px dashed #c9c7c7;
	width: 100%;
	padding-top: 10px;
	align-items: bottom;
	display: flex;
	justify-content: center;
	flex:1;
	position:relative
}
.itemValue div{
	padding-bottom:10px;
	position: absolute;
	bottom:0px;
}
.pcStyle{
	background-color:aqua;
	width: @width;
	height: @height;
}
.padStyle{
	background-color:blue;
	width: 50px;
	height: 50px;
}
</style>
