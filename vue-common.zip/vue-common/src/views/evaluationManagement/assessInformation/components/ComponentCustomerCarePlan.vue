<template>
	<div v-if="dataType==130">
		<div class="customer_care" v-for="(items,index) in formTitles" :key="index">
			<div class="table-title">
				<p>{{items.titleName}}</p>
				<div>
					<el-button
						type="primary"
						size="mini"
						@click="updateTitleTable(items.titleName,index)"
						v-if="!exportToPDF&&(items.titleName=='医疗服务计划'||items.titleName=='生活服务计划'||items.titleName=='康复训练计划')"
					>{{!tableEditMap[items.titleName]?"修改":"取消"}}</el-button>
				</div>
			</div>
			<!-- <el-table
				v-if="items.titleName=='医疗服务计划'||items.titleName=='生活服务计划'||items.titleName=='康复训练计划'"
				border
				v-loading="listLoading"
				:span-method="spanMethod"
				:data="tableOneData[index]"
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				:show-header="true"
			>
				<el-table-column
					v-for="(item,i) in tableColumn[index]"
					:key="i"
					:label="item.label"
					:prop="item.prop"
				>
					<template slot-scope="scope">{{scope.row[item.prop]}}</template>
				</el-table-column>
			</el-table>-->
			<CommonTableWidget
				v-if="items.titleName=='医疗服务计划'||items.titleName=='生活服务计划'||items.titleName=='康复训练计划'"
				@queryMethod="queryMethod"
				:propertyList="getColumns(tableColumn[index])"
				:formModel="getTableFormModel(tableOneData[index])"
				:tableDataName="'dataList'"
				:ref="items.titleName"
				:optWidth="200"
				:border="true"
				:showPagination="false"
				:canSpan="!tableEditMap[items.titleName]"
				:hasOptColumn="tableEditMap[items.titleName]"
			></CommonTableWidget>
			<el-table
				v-if="items.titleName=='照护中所需物品'"
				border
				v-loading="listLoading"
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				:data="tableTwoData"
				:show-header="true"
			>
				<el-table-column
					v-for="(item,i) in tableColumn[index]"
					:key="i"
					:label="item.label"
					:prop="item.prop"
					:width="item.width"
				>
					<template slot-scope="scope">{{scope.row[item.prop]}}</template>
				</el-table-column>
			</el-table>
			<el-table
				v-if="items.titleName=='适老化改造'"
				border
				v-loading="listLoading"
				:data="tableThreeData"
				:show-header="true"
				:span-method="objectCerryMethod"
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
			>
				<el-table-column
					v-for="(item,i) in tableColumn[index]"
					:key="i"
					:label="item.label"
					:prop="item.prop"
					:width="item.width"
				>
					<template slot-scope="scope">{{scope.row[item.prop]}}</template>
				</el-table-column>
			</el-table>
		</div>
	</div>
</template>

<script>
import ReportCarePlanAdapter from "./report-care-plan-adapter"
import CommonTableWidget from "components/widget/CommonTableWidget"
export default {
	mixins: [ReportCarePlanAdapter],
	components: {
		CommonTableWidget
	},
	props: {
		formTitles: {
			type: Array,
			default: () => []
		},
		dataType: {
			type: String
		}
	},
	data () {
		return {
			tableData: [], //存放表格数据
			tableContent: [],
			tableColumn: [],
			tableOneContent: [],
			tableOneData: [],
			tableHeader: [],//存放表格title
			tableLabel: [],
			tableTwoContent: [],
			tableTwoData: [],
			tableThreeContent: [],
			tableThreeData: [],
			listLoading: false,
			spanArr: [],
			pos: '',
			tableEditMap: {
				"医疗服务计划": false,
				"生活服务计划": false,
				"康复训练计划": false,
			},
			exportToPDF: false,
		};
	},
	watch: {
	},
	computed: {},
	methods: {
		//创建表格结构
		createTableName (index) {
			var array = [];
			var str = this.tableHeader[index].split("|");
			var s = "";
			for (let i = 0; i < str.length; i++) {
				// debugger;
				if (i == 0) {
					s += '{"prop":"property' + i + '","label": "' + str[i] + '","width":"150"}|';

				} else {
					s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
				}
			}
			if (s) {
				var s1 = s.split("|");
				for (let i = 0; i < s1.length - 1; i++) {
					s1[i]=s1[i].replace(/\n/g, "");
					array.push(JSON.parse(s1[i]));
				}
			}
			if (array.length > 0) {
				this.tableColumn[index] = array;
			}
		},
		// 第一种表格内容
		handleOneContent (index) {
			if (this.tableOneContent[index]) {
				var contentStr = this.tableOneContent[index].split("#;");
				var list = [];
				for (let k = 0; k < contentStr.length - 1; k++) {
					var array = [];
					var objlist = {};
					var id = contentStr[k].split("#id")[0];
					var str = contentStr[k].split("#id")[1].split("|");
					var s = "";
					for (let i = 0; i < str.length; i++) {
						s += '{"id":"' + id + '","property' + [i] + '": "' + str[i] + '"}#,';
					}
					if (s) {
						var s1 = s.split("#,");
						for (let i = 0; i < s1.length - 1; i++) {
							s1[i]=s1[i].replace(/\n/g, "");
							array.push(JSON.parse(s1[i]));
						}
					}
					if (array.length > 0) {
						array.forEach(item => {
							for (var k in item) {
								objlist[k] = item[k];
							}
						})
						list[k] = objlist;
					}
					objlist.tableIndex = index;
				}
				this.tableOneData.push(list) //二维数组，每条表格数据
			}
		},
		// 第二种表格内容
		handleTwoContent () {
			for (let k = 0; k < this.tableTwoContent.length; k++) {
				var array = [];
				var objlist = {};
				var str = this.tableTwoContent[k].split("|");
				for (let i = 0; i < str.length; i++) {
					objlist['property' + i] = str[i];

				}
				this.tableTwoData.push(objlist)

			}
		},
		/* 第三种表格内容 */
		handleThreeContent () {
			for (let k = 0; k < this.tableThreeContent.length; k++) {
				var array = [];
				var objlist = {};
				var str = this.tableThreeContent[k].split("|");
				for (let i = 0; i < str.length; i++) {
					objlist['property' + i] = str[i];
				}
				this.tableThreeData.push(objlist)
			}
		},
		//排序部位
		sortCompare () {
			var compare = function (obj1, obj2) {
				var val1 = obj1.property0;
				var val2 = obj2.property0;
				if (val1 > val2) {
					return -1;
				} else if (val1 < val2) {
					return 1;
				} else {
					return 0;
				}
			}
			return compare;

		},
		mergeColumns (tableData) {
			let spanOneArr = [],
				spanTwoArr = [],
				concatOne = 0,
				concatTwo = 0;
			tableData.forEach((item, index) => {
				if (index === 0) {
					spanOneArr.push(1);
					spanTwoArr.push(1);
				} else {
					if (item.property0 === tableData[index - 1].property0) {
						//第一列需合并相同内容的判断条件
						spanOneArr[concatOne] += 1;
						spanOneArr.push(0);
					} else {
						spanOneArr.push(1);
						concatOne = index;
					}
					if (item.property1 === tableData[index - 1].property1) {
						//第二列和需合并相同内容的判断条件
						spanTwoArr[concatTwo] += 1;
						spanTwoArr.push(0);
					} else {
						spanTwoArr.push(1);
						concatTwo = index;
					}
				}
			});
			return {
				one: spanOneArr,
				two: spanTwoArr
			};
		},
		spanMethod ({ row, column, rowIndex, columnIndex }) {
			if (columnIndex === 0) {
				const _row = this.mergeColumns(this.tableOneData[row.tableIndex]).one[rowIndex];
				const _col = _row > 0 ? 1 : 0;
				return {
					rowspan: _row,
					colspan: _col
				};
			}
			if (columnIndex === 1) {
				const _row = this.mergeColumns(this.tableOneData[row.tableIndex]).two[rowIndex];
				const _col = _row > 0 ? 1 : 0;
				return {
					rowspan: _row,
					colspan: _col
				};
			}
		},
		objectCerryMethod ({ row, column, rowIndex, columnIndex }) {
			if (columnIndex === 0) {
				const _row = this.spanArr[rowIndex];
				const _col = _row > 0 ? 1 : 0;
				return {
					rowspan: _row,
					colspan: _col
				}
			}
		},
		getSpanArr (data) {
			let dataArr = data
			for (var i = 0; i < dataArr.length; i++) {
				if (i === 0) {
					this.spanArr.push(1);
					this.pos = 0
				} else {
					// 判断当前元素与上一个元素是否相同
					if (dataArr[i].property0 === dataArr[i - 1].property0) {
						this.spanArr[this.pos] += 1;
						this.spanArr.push(0);
					} else {
						this.spanArr.push(1);
						this.pos = i;
					}
				}
			}
		},
		updateTitleTable (titleName, index) {
			this.tableEditMap[titleName] = !this.tableEditMap[titleName];
			this.tableOneData[index].forEach((item, index) => {
				item.isEdit = this.tableEditMap[titleName];
			})
			this.$forceUpdate();
		}
	},
	created () {
		if (this.formTitles.length > 0) {
			for (let i = 0; i < this.formTitles.length; i++) {
				let tableList = this.formTitles[i].titleValues //每条表格
				let tableType = this.formTitles[i].titleName //每条表格类型
				this.tableHeader[i] = tableList[0].titleValue //每个表格的标题
				if (tableType == '生活服务计划' || tableType == '医疗服务计划' || tableType == '康复训练计划') {
					let tableOne = this.formTitles[i].titleValues
					var contentStr = ''
					for (let j = 1; j < tableOne.length; j++) {
						contentStr += tableOne[j].id + "#id" + tableOne[j].titleValue + "#;"
					}
				}
				if (tableType == '照护中所需物品') {
					let tableTwo = this.formTitles[i].titleValues
					for (let j = 1; j < tableTwo.length; j++) {
						this.tableTwoContent[j - 1] = tableTwo[j].titleValue
					}

				}
				if (tableType == '适老化改造') {
					let tableThree = this.formTitles[i].titleValues
					for (let j = 1; j < tableThree.length; j++) {
						this.tableThreeContent[j - 1] = tableThree[j].titleValue
					}
				}
				this.tableOneContent[i] = contentStr;
				this.handleOneContent(i)//处理第一种表格内容
				this.createTableName(i);//单独处理表头

			}
			this.handleThreeContent()//处理第三种种表格内容
			this.handleTwoContent()//处理第二种表格内容

		}
		var that = this;
		this.EventBus.handleEvent("exportToPDF", (val) => {
			that.exportToPDF = true;
			if(that.tableEditMap["医疗服务计划"]){
				that.tableEditMap["医疗服务计划"]=false;
			}
			if(that.tableEditMap["生活服务计划"]){
				that.tableEditMap["生活服务计划"]=false;
			}
			if(that.tableEditMap["康复训练计划"]){
				that.tableEditMap["康复训练计划"]=false;
			}
			that.formTitles.forEach((items,index)=>{
				this.tableOneData[index].forEach((item, index) => {
					item.isEdit = false;
				})
			})
		})
		this.EventBus.handleEvent("finishedExportPDF", (val) => {
			that.exportToPDF = false;
		});



	},
	mounted () {
		this.getSpanArr(this.tableThreeData)
	},
};
</script>
<style lang="scss">
// .el-autocomplete-suggestion__wrap {
//   min-width: 200px;
// }
.el-autocomplete {
	width: 100%;
}
.el-popper {
	min-width: 220px;
}
.table-title {
	display: flex;
	justify-content: space-between;
	align-items: center;
}
</style>