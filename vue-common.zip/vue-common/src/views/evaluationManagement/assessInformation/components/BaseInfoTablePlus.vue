<template>
	<div>
		<el-table border :data="tableData" :span-method="cellMerge" :show-header="false">
			<el-table-column v-for="(item,index) in tableData[0]" :key="index" :property="'col'+index">
				<template slot-scope="scope">
					<!-- <span style="font-size:13px;"> -->
					{{scope.row[index].title||""}}
					<!-- </span> -->
					{{scope.row[index].title&&scope.row[index].relateItem?": ":""}}
					<!-- <span style="font-weight:bold;font-size:17px;"> -->
					{{scope.row[index].relateItem||""}}
					<!-- </span> -->
				</template>
			</el-table-column>
		</el-table>
	</div>
</template>
<script>
export default {
	data () {
		return {
			colCount: 4,
			dataList: [],
			tableData: [],
			spanArrList: [] //维护多个spanArr
		};
	},
	props: {
		formTitles: {
			type: Array,
			default: () => { }
		}
	},
	methods: {
		setTableData () {
			let rowArr = this.getRowArr();
			for (let i = 0; i < rowArr.length; i++) {
				let rowObj = {};
				for (let k = 0; k < rowArr[i].length; k++) {
					this.$set(rowObj, "col" + k, rowArr[i][k]);
				}
				this.tableData.push(rowObj);
			}
		},
		getRowArr () {
			//表格数据对应的二维数组
			var rowArr = [];
			var rowIndex = 0;
			var colArr = [];
			for (let i = 0; i < this.dataList.length; i++) {
				var item = this.dataList[i];
				if (rowArr.length == 0) {
					colArr[0] = item;
					rowArr[0] = colArr;
				} else {
					if (colArr.length < this.colCount) {
						if (item.cellSize > 1) {
							if (colArr.length <= this.colCount - item.cellSize) {//放得下
								for (let k = 0; k < item.cellSize; k++) {
									colArr[colArr.length] = JSON.parse(JSON.stringify(item));
									if (k != 0) {
										colArr[colArr.length - 1].needSpan = true;
									}
								}
							} else {//放不下，放空对象
								var addedCount = colArr.length;
								for (let k = 0; k < this.colCount - addedCount; k++) {
									colArr[colArr.length] = {};
								}
								rowArr[rowIndex] = colArr;
								colArr = [];
								for (let k = 0; k < item.cellSize; k++) {
									colArr[colArr.length] = JSON.parse(JSON.stringify(item));
									if (k != 0) {
										colArr[colArr.length - 1].needSpan = true;
									}
								}
								rowIndex++;
							}
						} else {
							colArr[colArr.length] = item;
							if (i == this.dataList.length - 1) {
								//最后一项,少多少补多少
								var addedCount = colArr.length;
								for (let k = 0; k < this.colCount - addedCount; k++) {
									colArr[colArr.length] = {};
								}
							}
						}
					}
					if (colArr.length == this.colCount) {
						rowArr[rowIndex] = colArr;
						colArr = [];
						rowIndex++;
					}
				}
			}
			return rowArr;
		},
		cellMerge ({ row, column, rowIndex, columnIndex }) {
			var rowArr = this.getRowArr();
			var needSpan = false;
			//前一项是否与后一项相等
			if (
				rowArr[rowIndex][columnIndex + 1] &&
				rowArr[rowIndex][columnIndex + 1].title &&
				rowArr[rowIndex][columnIndex].title == rowArr[rowIndex][columnIndex + 1].title
			) {
				needSpan = true;
			}
			//前一项是否与后一项相等
			if (
				rowArr[rowIndex][columnIndex - 1] &&
				rowArr[rowIndex][columnIndex - 1].title &&
				rowArr[rowIndex][columnIndex - 1].title == rowArr[rowIndex][columnIndex].title
			) {
				needSpan = true;
			}
			if (needSpan) {
				if (rowArr[rowIndex][columnIndex].needSpan) {
					return {
						rowspan: 1,
						colspan: rowArr[rowIndex][columnIndex].cellSize //合并的单元格数
					};

				} else {
					return {
						rowspan: 0,
						colspan: 0
					};
				}

			}
		},
		cellStyle ({ row, column, rowIndex, columnIndex }) {
			if (columnIndex % 2 == 0) {
				return {
					// color: "#333333",
					// backgroundColor: "#F7F9FD",
					color: "#666666",
					fontSize: "16px",
				};
			} else {
				return { color: "#666666", fontSize: "16px" };
			}
		}
	},
	created () {
		if (this.formTitles) {
			this.formTitles.forEach(element => {
				this.dataList.push({
					title: element.titleName,
					relateItem: element.titleValues && element.titleValues.length > 0 ? element.titleValues[0].titleValue : "",
					cellSize: element.titleValues[0].valueSort
				});
			});
			this.setTableData();
		}
	}
};
</script>
<style>
/* .el-table__body tr:hover > td {
	background-color: #fff !important;
}

.el-table__body tr.current-row > td {
	background-color: #fff !important;
} */
</style>