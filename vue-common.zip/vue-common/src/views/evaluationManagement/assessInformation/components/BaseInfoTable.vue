<template>
  <div>
    <el-table
      border
      :data="tableData"
      :span-method="cellMerge"
      :show-header="false"
    >
      <el-table-column
        v-for="(item,index) in tableData[0]"
        :key="index"
        :property="'col'+index"
        
      >
        <template slot-scope="scope">{{scope.row[index]}}</template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  data() {
    return {
      colCount: 2,
      dataList: [],
      tableData: [],
      spanArrList: [] //维护多个spanArr
    };
  },
  props: {
    formTitles: {
      type: Array,
      default: () => {}
    }
  },
  methods: {
    setTableData() {
      let rowArr = this.getRowArr();
      for (let i = 0; i < rowArr.length; i++) {
        let rowObj = {};
        for (let k = 0; k < rowArr[i].length; k++) {
          this.$set(rowObj, "col" + k, rowArr[i][k]);
        }
        this.tableData.push(rowObj);
      }
    },
    getRowArr() {
      //表格数据对应的二维数组
      var rowArr = [];
      var rowIndex = 0;
      var colArr = [];
      for (let i = 0; i < this.dataList.length; i++) {
        var item = this.dataList[i];
        if (rowArr.length == 0) {
          colArr[0] = item.title;
          colArr[1] = item.relateItem;
          rowArr[0] = colArr;
        } else {
          if (colArr.length < this.colCount * 2) {
            colArr[colArr.length] = item.title;
            colArr[colArr.length] = item.relateItem;
            if (
              this.dataList[i + 1] &&
              this.dataList[i + 1].isSingleLine == 1
            ) {
              //下一项是单行显示,用空白补齐
              var addedCount = colArr.length;
              for (let k = 0; k < this.colCount * 2 - addedCount; k++) {
                //少多少补多少
                colArr[colArr.length] = "";
              }
            } else {
              if (item.isSingleLine == 1) {
                for (let k = 0; k < this.colCount * 2 - 2; k++) {
                  colArr[colArr.length] = item.relateItem;
                }
              } else {
                if (i == this.dataList.length - 1) {
                  //最后一项,少多少补多少
                  var addedCount = colArr.length;
                  for (let k = 0; k < this.colCount * 2 - addedCount; k++) {
                    colArr[colArr.length] = "";
                  }
                }
              }
            }
          }
          if (colArr.length == this.colCount * 2) {
            rowArr[rowIndex] = colArr;
            colArr = [];
            rowIndex++;
          }
        }
      }
      return rowArr;
    },
    cellMerge({ row, column, rowIndex, columnIndex }) {
      var rowArr = this.getRowArr();
      var needSpan = false;
      //前一项是否与后一项相等
      if (
        rowArr[rowIndex][columnIndex + 1] &&
        rowArr[rowIndex][columnIndex] == rowArr[rowIndex][columnIndex + 1]
      ) {
        needSpan = true;
      }
      //前一项是否与后一项相等
      if (
        rowArr[rowIndex][columnIndex - 1] &&
        rowArr[rowIndex][columnIndex - 1] == rowArr[rowIndex][columnIndex]
      ) {
        needSpan = true;
      }
      if (needSpan) {
        if (columnIndex != 1) {
          return {
            rowspan: 0,
            colspan: 0
          };
        }
        return {
          rowspan: 1,
          colspan: this.colCount * 2 - 1 //合并的单元格数
        };
      }
    },
    cellStyle({ row, column, rowIndex, columnIndex }) {
      if (columnIndex % 2 == 0) {
        return {
          color: "#333333",
          backgroundColor: "#F7F9FD",
          fontSize: "16px"
        };
      } else {
        return { color: "#666666", fontSize: "16px" };
      }
    }
  },
  created() {
    if (this.formTitles) {
      this.formTitles.forEach(element => {
        this.dataList.push({
          title: element.titleName,
          relateItem: element.titleValues&&element.titleValues.length>0? element.titleValues[0].titleValue: "",
          isSingleLine: element.titleType == "120" ? "1" : "0"
        });
      });
      this.setTableData();
    }
  }
};
</script>
<style scoped>
</style>