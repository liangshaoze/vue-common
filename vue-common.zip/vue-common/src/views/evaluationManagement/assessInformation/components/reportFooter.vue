<template>
	<div>
		<div class="footer">
			<span>{{reportObj.companyName}}</span>
			<span>{{reportObj.orgUnitName }}</span>
			<span>{{reportObj.assessEndDate }}</span>
		</div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {
		reportObj: {
			type: Object,
			default: ''
		}
	},
	data () {
		return {
		};
	},
	watch: {},
	computed: {},
	methods: {},
	created () { },
	mounted () { }
};
</script>
<style lang="scss" scoped>

</style>