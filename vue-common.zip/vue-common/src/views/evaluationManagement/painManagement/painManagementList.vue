<template>
  <div id="painManagementList">
    <headTag :tagName="tagName" />
    <div class="filter_wrap">
        <el-form ref="filterForm" :inline="true" :model="keyWords" label-width="85px">
            <CommonPropertyWidget
                    @queryMethod ="queryMethod"
                    :propertyList="queryPropertyList"
                    :resultItem ="keyWords"
            >
            <el-col class="search_btn" slot="append">
                <el-button @click="getList(1)" icon="el-icon-search" size="mini" type="primary">查询</el-button>
                <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-col>
            </CommonPropertyWidget>
        </el-form>
    </div>
    <div class="tableToolbar">
        <el-row class="tableTopBtn">
            <el-col :span="24">
                <el-button size="mini" type="primary" icon="el-icon-plus" @click="addPain()">新增</el-button>
            </el-col>
        </el-row>
        <el-table :data="serviceData" :header-cell-style="{
            background: 'rgba(57, 138, 241, 0.1)',
            color: '#606266'
            }" element-loading-text="拼命加载中" highlight-current-row size="mini" stripe style="width:100%;" v-loading="listLoading">
            <el-table-column label="编号" min-width="100" prop="userCode"></el-table-column>
            <el-table-column label="痛点" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="目标" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="服务项" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="商品" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="适老化" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="更新时间" min-width="120" prop="userFullName"></el-table-column>
            <el-table-column label="操作">
            <template slot-scope="scope">
                <el-button @click="editPainInfo(scope.row.userCode)" size="mini" type="text">编辑</el-button>
                <el-button @click="deletePainInfo(scope.row.userCode)" size="mini" type="text">删除</el-button>
            </template>
            </el-table-column>
        </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <!--分页-->
        <pagination :limit.sync="keyWords.pageSize" :page.sync="keyWords.pageNum" :total="totalCount" @pagination="pageChange" v-if="totalCount > 0" />
      </el-row>
        <!-- 新增痛点信息 -->
       <el-dialog title="新增商品信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogPain" :before-close="handlePainClose" >
        <el-row type="flex" justify="center">
          <el-form :inline="false" :rules="formPainRules" ref="formService" :model="formPain" label-width="85px">
            <el-form-item  prop="productName" label="编号">
                <el-input size="mini" clearable v-model="formPain.orgName" placeholder="自动生成，不可重复"></el-input>
            </el-form-item>
            <el-form-item label="痛点">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formPain.remark"
                      size="mini"
                      clearable
                      placeholder="请输入痛点"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
                <el-form-item label="目标">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formPain.remark"
                      size="mini"
                      clearable
                      placeholder="请输入目标"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
          </el-form>
        </el-row>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini"  @click="canclePain('formPain')">取消</el-button>
          <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="painSubmit('formService')">确 定</el-button>
        </div>
       </el-dialog>
         <!-- 编辑痛点信息 -->
       <el-dialog title="编辑痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogEditPain" :before-close="handleEditPainClose" >
        <el-row type="flex" justify="center">
          <el-form :inline="false" :rules="formEditPainRules" ref="formService" :model="formEditPain" label-width="85px">
            <el-form-item  prop="productName" label="编号">
                <el-input size="mini" clearable v-model="formEditPain.orgName" placeholder="自动生成，不可重复"></el-input>
            </el-form-item>
            <el-form-item label="痛点">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formEditPain.remark"
                      size="mini"
                      clearable
                      placeholder="请输入痛点"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
                <el-form-item label="目标">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="formEditPain.remark"
                      size="mini"
                      clearable
                      placeholder="请输入目标"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                </el-form-item>
          </el-form>
        </el-row>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini"  @click="cancleEditPain('formEditPain')">取消</el-button>
          <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="painEditSubmit('formEditPain')">确 定</el-button>
        </div>
       </el-dialog>
         <!-- 删除题痛点信息 -->
       <el-dialog title="删除痛点信息" center width="460px"  :close-on-click-modal="false" :visible.sync="dialogDeletePain" :before-close="handleDeletePainClose" >
           <h3 style="text-align:center;">与痛点关联关系将同时解除，删除后不可恢复!</h3>
           <div slot="footer" class="dialog-footer">
            <el-button size="mini"  @click="dialogDeletePain=false">取消</el-button>
            <el-button size="mini" type="primary" style="margin-left:30px;" :disabled="cancleDisabled" @click="PainDeleteSubmit()">确 定</el-button>
        </div>
       </el-dialog>
    </div>
  </div>
</template>

<script>
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget"
import { findValueBySetCode } from "api/common/index.js";
import Pagination from "components/Pagination/pagination";
import HeadTag from "components/HeadTag";

import {
  findSysUserList,
  editSysUser,
  getSysUserByCode,
  findSysUserMenus,
  editSysUserMenusByUserCode
} from "api/systemManagement/index.js";
export default {
  components: {
    Pagination,
    HeadTag,
    CommonPropertyWidget
  },
  props: {},
  data() {
    return {
      tagName: "痛点管理",
         //关键字搜索
      keyWords: {
        userCode: "",
        userTel: "",
        userFullName: "",
        userStatus: "",
        pageNum: 1,
        pageSize: 10
      },
      serviceData:[],
       queryPropertyList:[
         {
          propertyName: "编号",propertyFieldName: "userFullName",propertyType:"10"
        },
         {
          propertyName: "痛点",propertyFieldName: "userStatus",optionKeyFieldName:"value",optionValueFieldName:"name",//可选项值对应的value的字段名
          valueSetCode:"USER_STATUS",propertyType:"20",
        },
         {
          propertyName: "服务项",propertyFieldName: "userFullName",propertyType:"10"
        },
         {
          propertyName: "商品",propertyFieldName: "userFullName",propertyType:"10"
        },
         {
          propertyName: "适老化",propertyFieldName: "userFullName",propertyType:"10"
        },
        
      ],
      totalCount: 0,
      listLoading: false,
      cancleDisabled:false,
      //新增商品
      dialogPain:false,
      formPainRules:{
         productName: [
          {
            required: true,
            message: "请选择产品名称",
            trigger: "change"
          }
        ],
      },
    formPain:{
        selectDay:'',
        orgName:'',
    },
      //删除题目
    dialogDeletePain:false,
      //编辑痛点
    dialogEditPain:false,
      formEditPainRules:{
         productName: [
          {
            required: true,
            message: "请选择产品名称",
            trigger: "change"
          }
        ],
      },
    formEditPain:{
        selectDay:'',
        orgName:'',
    },
  };
    
  },
  watch: {},
  computed: {},
  methods: {
      //获取数据字典
    initDataDictionary() {
      findValueBySetCode({ valueSetCode: "USER_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.statusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    queryMethod(obj,query,cb){
      if(typeof(obj.queryMethod) =="function"){
        obj.queryMethod(query,cb);
      }else{
        this[obj.queryMethod](query,cb);
      }
    },
    // 列表数据
    getList(page) {
      this.listLoading = true;
      this.keyWords.pageNum = page;
      findSysUserList(this.keyWords)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode === 200 ||
              response.data.statusCode === "200"
            ) {
              this.serviceData = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
     //父组件触发事件
    pageChange(val) {
      this.keyWords.page = val.page;
      this.keyWords.pageSize = val.limit;
      this.getList(val.page);
    },
    //新增痛点信息
    addPain(){
     this.dialogPain=true
    },
     handlePainClose(){
      this.dialogPain=false
    },
    canclePain(){
      this.dialogPain=false
    },
    //编辑痛点信息
    editPainInfo(){
      this.dialogEditPain=true

    },
    handleEditPainClose(){
      this.dialogEditPain=false
    },
    cancleEditPain(){
      this.dialogEditPain=false
    },
    //删除痛点信息
    deletePainInfo(){
      this.dialogDeletePain=true
    },
    PainDeleteSubmit(){

    },
   handleDeletePainClose(){
      this.dialogDeletePain=false
    },
    resetForm() {
      let form=this.$refs.filterForm.model
      form.userCode=''
      form.userFullName=''
      form.userTel=''
      form.userStatus=''
      this.getList(1);
    }
  },
  created() {
    this.initDataDictionary();
    this.getList(1);
  },
  mounted() {
     
  },
  // activated() {
  //   this.getList(1);
  // }
};
</script>
<style lang="scss" scoped>
#painManagementList{
   width: 100%;
   min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.workOrderClass {
	margin-top: 20px;
	margin-bottom: 0;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.search_btn {
   width: 30%;
  min-width: 295px;
  margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.remark-style {
  // display: block;
  width: 200px;
  margin: 10px;
}

</style>