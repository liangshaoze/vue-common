<template>
	<div id="serviceItemList">
		<headTag :tagName="tagName" />
        <el-tabs v-model="activeName" @tab-click="handleClick" class="tabClass">
          <el-tab-pane label="服务项" name="first">
            <serviceItem></serviceItem>
          </el-tab-pane>
          <el-tab-pane label="商品" name="second">
            <shop></shop>
          </el-tab-pane>
          <el-tab-pane label="适老化" name="third">
            <suitableAging></suitableAging>
          </el-tab-pane>
        </el-tabs>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import ServiceItem from "./components/serviceItem"
import Shop from "./components/shop"
import SuitableAging from "./components/suitableAging"
export default {
  components: {
    HeadTag,
    ServiceItem,
    Shop,
    SuitableAging
  },
  props: {},
  data() {
    return {
      activeName:'first',
      tagName: "服务管理",
    };
  },
  watch: {},
  computed: {},
  methods: {
     handleClick(tab, event) {
        console.log(tab, event);
      }
  },
  created() {
  
  },
  mounted() {},
  activated() {
  }
};
</script>
<style lang="scss" scoped>
#serviceItemList {
	width: 100%;
	min-width: 1024px;
	}

</style>
<style lang="scss">
.tabClass {
    .el-tabs__header {
      padding: 0;
      position: relative;
      margin: 20px 30px; 
  } 
  .el-tabs__nav-wrap::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 2px;
      background-color: #EFEEF3;
      z-index: 1;
  }
}
</style>