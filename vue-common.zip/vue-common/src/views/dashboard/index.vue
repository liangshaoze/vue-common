<template>
  <div id="homeIndex">
    <el-form v-model="dataList">
      <el-row>
        <el-col style="min-width:800px;width:70%">
          <div class="div_shoadow" style="width:100%; height:460px">
            <table style="margin-top:-10px; width:100%;text-align: center;color:#ffffff;">
              <tr style="height: 50px;font-weight: bold;color:#2B3642;">
                <td colspan="3" style="font-size: 18px;">客户增长数据统计</td>
              </tr>
              <tr>
                <td>
                  <div class="table_left_div">
                    <span>
                      <p>当日新增客户</p>
                      <p class="font-p">
                        {{dataList.todayClientAddNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
                <td>
                  <div class="table_right_div">
                    <span>
                      <p>当月新增客户</p>
                      <p class="font-p">
                        {{dataList.monthClientAddNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="table_left_div">
                    <span>
                      <p>当日预约护理客户</p>
                      <p class="font-p">
                        {{dataList.todayOrderNursingNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
                <td>
                  <div class="table_right_div">
                    <span>
                      <p>当月预约护理客户</p>
                      <p class="font-p">
                        {{dataList.monthOrderNursingNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
                <td rowspan="2">
                  <div class="table_main_div">
                    <span>
                      服务APP装机数量
                      <br>
                      <p class="font-p">
                        {{dataList.appUseNum}}
                        <span>人/次</span>
                      </p>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="table_left_div">
                    <span>
                      <p>当日付款客户</p>
                      <p class="font-p">
                        {{dataList.todayClientPayNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
                <td>
                  <div class="table_right_div">
                    <span>
                      <p>当月付款客户</p>
                      <p class="font-p">
                        {{dataList.monthClientPayNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="table_left_div">
                    <span>
                      <p>当日退款客户</p>
                      <p class="font-p">
                        {{dataList.todayClientReturnNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
                <td>
                  <div class="table_right_div">
                    <span>
                      <p>当月退款客户</p>
                      <p class="font-p">
                        {{dataList.monthClientReturnNum}}
                        <span>人</span>
                      </p>
                    </span>
                  </div>
                </td>
              </tr>
            </table>
          </div>
        </el-col>
        <el-col style="min-width:400px;width:30%">
          <div id="chartUser" class="div_shoadow" style="width:100%; height:460px;"></div>
        </el-col>
        <el-col style="min-width:800px;width:70%">
          <div id="chartLine" class="div_shoadow" style="width:100%; height:400px;"></div>
        </el-col>
        <el-col style="min-width:400px;width:30%">
          <div id="chartOrder" class="div_shoadow" style="width:100%; height:400px;"></div>
        </el-col>
        
        
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { findFirstPageData } from "api/dashboard";

export default {
  data() {
    return {
      dataList: {
        //服务APP装机数量
        appUseNum: "6234",
        //当日新增客户
        todayClientAddNum: "33",
        //当月新增客户
        monthClientAddNum: "555",
        //当日预约护理计划
        todayOrderNursingNum: "11",
        //当月预约护理计划
        monthOrderNursingNum: "66",
        //当日付款客户
        todayClientPayNum: "11",
        //当月付款客户
        monthClientPayNum: "66",
        //当日退款客户
        todayClientReturnNum: "11",
        //当月退款客户
        monthClientReturnNum: "66",
        //客户总数量
        clientTotalNum: "",
        //订单管理
        orderManageList: [],
        //预约护理每月增长
        clientMonthAddOutDtoList: []
      },
      loading: false
    };
  },
  mounted(){
    this.loadData();
  },
  methods: {
    drawUserChart() {
      let chartUser = this.$echarts.init(document.getElementById("chartUser"));
      chartUser.setOption({
        title: {
          text: "福寿康客户统计图",
          x: "center"
        },
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        color: ["#4A8DF0"],
        series: [
          {
            name: "客户数量",
            type: "pie",
            radius: "60%",
            center: ["50%", "50%"],
            data: [{ value: 5455, name: "人数" }],
            label: {
              //饼图图形上的文本标签
              normal: {
                show: true,
                position: "center", //标签的位置
                textStyle: {
                  color: "#FFFFFF",
                  fontWeight: 800,
                  fontSize: 18 //文字的字体大小
                },
                formatter: "{c}"
              }
            }
          }
        ]
      });
      window.addEventListener('resize',function() {chartUser.resize()});
    },
    drawOrderManageChart() {
      var orders = [];

      var data = [
        {count:1293,status:'待付款'},
        {count:621,status:'已失效'},
        {count:7123,status:'已付款'},
        {count:123,status:'已退款'}
      ]

      for (var i = 0; i < data.length; i++) {
          orders.push({
            'name':data[i].status,
            'value':data[i].count
          })
      }

      let chartOrder = this.$echarts.init(document.getElementById("chartOrder"));
      chartOrder.setOption({
        title: {
          text: "订单管理",
          x: "center"
        },
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c}人 ({d}%)"
        },
        color: [
          "#E88457",
          "#4A8DF0",
          "#99CC66",
          "#E984EA"
        ],
        series: [
          {
            name: "人数",
            type: "pie",
            radius: [30, 130],
            center: ["50%", "50%"],
            // roseType: "area",
            data: orders
          }
        ]
      });
      window.addEventListener('resize',function() {chartOrder.resize()});
    },
    drawLineChart() {
      var months = [];
      var nursings = [];

      // var data = this.dataList.clientMonthAddOutDtoList
      var data = [
        {month:1,totalNum:3000},
        {month:2,totalNum:4000},
        {month:3,totalNum:5000},
        {month:4,totalNum:6000},
        {month:5,totalNum:7000},
        {month:6,totalNum:8000},
        {month:7,totalNum:9000},
        {month:8,totalNum:8000},
        {month:9,totalNum:7000},
        {month:10,totalNum:6000},
        {month:11,totalNum:5000},
        {month:12,totalNum:4000}
      ]

      for (var i = 0; i < data.length; i++) {
          months.push(parseInt(data[i].month)+'月')
          nursings.push(data[i].totalNum);
      }

      let chartLine = this.$echarts.init(document.getElementById("chartLine"));
      chartLine.setOption({
        title: {
          text: "预约护理每月增长柱形图",
          x: "center"
        },
        color: ["#4A8DF0"],
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            data: months,
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: "value"
          }
        ],
        series: [
          {
            name: "当月预约护理数",
            type: "bar",
            barWidth: "50",
            data: nursings
          }
        ]
      });
      window.addEventListener('resize',function() {chartLine.resize()});
    },
    drawCharts() {
      this.drawUserChart();
      this.drawOrderManageChart();
      this.drawLineChart();
    },
    loadData() {
      // this.loading = true;
      // let params = {
      //   sysOrgId:""
      // };
      // findFirstPageData(params)
      //   .then(response => {
      //     this.dataList = response.data.responseData;
      //     this.loading = false;
          this.drawCharts();
        // })
        // .catch(error => {
        //   console.log(error);
        // });
    }
  }
};
</script>

<style scoped>
.chart-container {
  width: 100%;
  float: left;
}

.el-col {
  padding-right: 15px;
}

.div_shoadow {
  background: #fff;
  color: #333;
  box-shadow: 2px 2px 10px #aaaaaa;
  margin: 10px;
  padding-top: 10px;
}

.font-p{
  font-size: 16px;
  font-weight: bold;
}

.table_left_div{
  background-color:#3EB592;
  margin: 10px;
  line-height: 5px;
  padding:10px 0px;
}

.table_right_div{
  background-color:#4A8DF0;
  margin: 10px;
  line-height: 5px;
  padding:10px 0px;
}

.table_main_div{
  background-color:#E88457;
  margin: 15px;
  line-height: 60px;
  height:150px;
}
</style>
