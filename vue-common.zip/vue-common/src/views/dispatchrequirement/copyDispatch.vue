<template>
  <div id="updateDispatch">
    <headTag :tagName="tagName" />
    <div class="formStyle">
      <el-row class="importToolbar">
        <el-col :span="24">
          <el-button size="small" type="primary" class="rightBtn" @click="cancelBack">返回</el-button>
          <el-button
            size="small"
            type="primary"
            class="rightBtn"
            :loading="loadingBtn"
            @click="submitForm('dispatchForm')"
          >保存</el-button>
        </el-col>
        <el-form
          :inline="false"
          :model="dispatchForm"
          :rules="dispatchRules"
          ref="dispatchForm"
          label-width="110px"
        >
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <span>
                <el-input
                  size="mini"
                  v-model="dispatchForm.orgName"
                  clearable
                  placeholder="请选择组织"
                  @focus="dialogVisible=true"
                  @clear="clearOrgCode"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="区域" required>
              <span>
                <AddressAutocomplete
                  ref="liveAddress"
                  :address="{
                            provinceCode:dispatchForm.workProvinceCode,
                            provinceName:dispatchForm.workProvinceName,
                            cityCode: dispatchForm.workCityCode,
                            cityName: dispatchForm.workCityName,
                            districtCode:dispatchForm.workDistrictCode,
                            districtName:dispatchForm.workDistrictName
                            }"
                  @selectedProvinceListener="selectedWorkProvinceListener"
                  @selectedCityListener="selectedWorkCityListener"
                  @selectedDistrictListener="selectedWorkDistrictListener"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="性别" prop="gender">
              <span>
                <el-select size="mini" v-model="dispatchForm.gender" clearable placeholder="请选择">
                  <el-option
                    v-for="item in sexOptions"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="年龄" prop="age">
              <span>
                <el-input
                  size="mini"
                  v-model.number="dispatchForm.age"
                  clearable
                  placeholder="请输入年龄"
                  maxlength="20"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="服务形式" prop="serviceType">
              <span>
                <el-select
                  size="mini"
                  v-model="dispatchForm.serviceType"
                  clearable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in serviceTypeOptions"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="要求到岗日期" prop="startWorkDate">
              <span>
                <el-date-picker
                  v-model.trim="dispatchForm.startWorkDate"
                  type="date"
                  size="mini"
                  value-format="yyyy-MM-dd"
                ></el-date-picker>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="客户情况描述" prop="careReceiverDesc">
              <span>
                <el-input
                  type="textarea"
                  maxlength="100"
                  show-word-limit
                  resize="none"
                  rows="4"
                  class="remark-style"
                  size="mini"
                  v-model="dispatchForm.careReceiverDesc"
                  clearable
                  placeholder="请输入客户情况描述"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="工资报价" prop="salaryQuoted">
              <span>
                <el-input
                  type="textarea"
                  maxlength="50"
                  show-word-limit
                  resize="none"
                  rows="4"
                  class="remark-style"
                  size="mini"
                  v-model="dispatchForm.salaryQuoted"
                  clearable
                  placeholder="请输入工资报价"
                />
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="特殊要求" prop="remark">
              <span>
                <el-input
                  type="textarea"
                  maxlength="100"
                  show-word-limit
                  resize="none"
                  rows="4"
                  class="remark-style"
                  size="mini"
                  v-model="dispatchForm.remark"
                  clearable
                  placeholder="请输入特殊要求"
                />
              </span>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
      <!-- 组织 -->
      <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
        <org-select v-on:listenTochildEvent="getCurrentNode" />
      </el-dialog>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import AddressAutocomplete from "components/AddressAutocomplete";
import OrgSelect from "components/OrgSelect";
import { findValueBySetCode } from "api/common/index.js";
import { changeYMD } from "utils";
import { validateAge } from "utils/validate";
import { addRecruitNeed, findDispatchDetail } from "api/dispatchRequirement";
import { getEhrOrgDetailByCode } from "api/orgStructure";

export default {
  components: {
    HeadTag,
    AddressAutocomplete,
    OrgSelect
  },
  props: {},
  data() {
    return {
      tagName: "复制派单需求",
      //按钮加载
      loadingBtn: false,
      dialogVisible: false,
      dispatchForm: {
        orgName: "",
        orgCode: "",
        workProvinceCode: "",
        workProvinceName: "",
        workCityCode: "",
        workCityName: "",
        workDistrictCode: "",
        workDistrictName: "",
        gender: "",
        age: "",
        serviceType: "",
        startWorkDate: "",
        careReceiverDesc: "",
        salaryQuoted: "",
        remark: ""
      },
      dispatchRules: {
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        gender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        age: [
          {
            required: true,
            message: "请填写年龄",
            trigger: "blur"
          },
          {
            required: true,
            validator: validateAge,
            trigger: "blur"
          }
        ],
        serviceType: [
          {
            required: true,
            message: "请选择服务形式",
            trigger: "change"
          }
        ],
        startWorkDate: [
          {
            required: true,
            message: "请选择到岗日期",
            trigger: "change"
          }
        ],
        careReceiverDesc: [
          {
            required: true,
            message: "请填写客户情况描述",
            trigger: "blur"
          }
        ],
        salaryQuoted: [
          {
            required: true,
            message: "请填写工资报价",
            trigger: "blur"
          }
        ]
      },
      sexOptions: [],
      serviceTypeOptions: []
    };
  },
  watch: {},
  computed: {},
  methods: {
    //获取数据字典
    initDataDictionary() {
      // 性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.sexOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      // 服务形式
      findValueBySetCode({ valueSetCode: "SERVICE_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.serviceTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },// 查询组织的默认区域
    getEhrOrgDetailByCode() {
      let params = { orgCode: this.dispatchForm.orgCode };
      getEhrOrgDetailByCode(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.dispatchForm = Object.assign({}, this.dispatchForm, {
              workProvinceName: response.data.responseData.orgProvinceName,
              workProvinceCode: response.data.responseData.orgProvinceCode,
              workCityName: response.data.responseData.orgCityName,
              workCityCode: response.data.responseData.orgCityCode,
              workDistrictName: response.data.responseData.orgDistrictName,
              workDistrictCode: response.data.responseData.orgDistrictCode
            });
          }
        })
        .catch(error => {
          console.log("getEhrOrgDetailByCode:" + error);
        });
    },
    /**
     *
     * 查询条件开窗选择组织
     *
     */
    close() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.dispatchForm.orgName = data.orgName;
      this.dispatchForm.orgCode = data.orgCode;
      this.close();
      this.getEhrOrgDetailByCode();
    },
    //清空组织过滤
    clearOrgCode() {
      this.dispatchForm.orgName = "";
      this.dispatchForm.orgCode = "";
    },
    cancelBack() {
      this.$router.back();
    },
    //加载本市地址省市区
    selectedWorkProvinceListener(obj) {
      this.dispatchForm.workProvinceName = obj.provinceName;
      this.dispatchForm.workProvinceCode = obj.provinceCode;
      this.dispatchForm.workCityName = "";
      this.dispatchForm.workCityCode = "";
      this.dispatchForm.workDistrictName = "";
      this.dispatchForm.workDistrictCode = "";
    },
    selectedWorkCityListener(obj) {
      this.dispatchForm.workCityName = obj.cityName;
      this.dispatchForm.workCityCode = obj.cityCode;
      this.dispatchForm.workDistrictName = "";
      this.dispatchForm.workDistrictCode = "";
    },
    selectedWorkDistrictListener(obj) {
      this.dispatchForm.workDistrictName = obj.districtName;
      this.dispatchForm.workDistrictCode = obj.districtCode;
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (
            !(
              this.dispatchForm.workProvinceName &&
              this.dispatchForm.workCityName &&
              this.dispatchForm.workDistrictName
            )
          ) {
            this.$message.error("请选择区域");
            return false;
          }
          this.loadingBtn = true;
          this.id = "";
          let params = {
            ...this.dispatchForm,
            id: "",
            appointStatusValue: "",
            createDate: "",
            careGiverName: ""
          };
          addRecruitNeed(params)
            .then(response => {
              this.loadingBtn = false;
              if (
                response.data.statusCode === 200 ||
                response.data.statusCode === "200"
              ) {
                this.$message.success("保存成功");
                this.cancelBack();
              } else {
                this.$message.error(response.data.statusMsg);
              }
            })
            .catch(error => {
              this.loadingBtn = false;
              console.log("updateRecruitNeed:" + error);
            });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 根据id查询派单详情
    findDispatchDetail() {
      let params = { id: this.id };
      findDispatchDetail(params)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            this.dispatchForm = Object.assign({}, response.data.responseData, {
              startWorkDate: response.data.responseData.startWorkDate
                ? changeYMD(response.data.responseData.startWorkDate)
                : ""
            });
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          console.log("findDispatchDetail:" + error);
        });
    }
  },

  created() {
    this.initDataDictionary();
  },
  mounted() {},
  activated() {
    this.id = this.$route.query.id;
    this.findDispatchDetail();
  },
  deactivated() {
    this.$refs.dispatchForm.resetFields(); //清除校验
  }
};
</script>
<style lang="scss" scoped>
#updateDispatch {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.remark-style {
  width: 200px;
}
.formStyle {
  margin: 0 20px 20px;
  background-color: #ffffff;
  border-radius: 10px;
}
.importToolbar {
  padding: 20px 0px 10px 20px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.el-date-editor--daterange.el-input__inner {
  width: 250px;
}
.form-item {
  width: 30%;
  min-width: 300px;
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>