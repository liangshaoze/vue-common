<template>
	<div id="dispatchRequirementList">
		<headTag :tagName="tagName" />
		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form :inline="true" ref="filterForm" :model="filters" label-width="115px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="filters.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="创建时间" prop="createDate">
							<el-date-picker
								v-model.trim="filters.createDate"
								range-separator="至"
								type="daterange"
								size="mini"
								value-format="yyyy-MM-dd"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="要求到岗日期" prop="startWorkDate">
							<el-date-picker
								v-model.trim="filters.startWorkDate"
								range-separator="至"
								type="daterange"
								size="mini"
								value-format="yyyy-MM-dd"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="工资报价" prop="salaryQuoted">
							<el-input size="mini" v-model.trim="filters.salaryQuoted" clearable placeholder="请输入工资报价" />
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="状态" prop="appointStatus">
							<el-select size="mini" v-model.trim="filters.appointStatus" clearable placeholder="请选择">
								<el-option
									v-for="item in statusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="getList(1)"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="addDispatch">新增</el-button>
					<el-button size="mini" type="primary" icon="el-icon-upload" @click="exportDispatch">导出</el-button>
				</el-col>
			</el-row>
			<!-- 列表 -->
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				stripe
				size="mini"
				:data="recruitNeedList"
				v-loading="listLoading"
				highlight-current-row
				element-loading-text="拼命加载中"
			>
				<el-table-column label="组织" min-width="100" prop="orgName"></el-table-column>
				<el-table-column label="创建时间" min-width="100" prop="createDate"></el-table-column>
				<el-table-column label="区域" min-width="140" prop="workDistrictName">
					<template slot-scope="scope">
						<span>{{scope.row.workProvinceName+scope.row.workCityName+scope.row.workDistrictName}}</span>
					</template>
				</el-table-column>
				<el-table-column label="性别" min-width="50" prop="genderValue"></el-table-column>
				<el-table-column label="年龄" min-width="50" prop="age"></el-table-column>
				<el-table-column label="服务形式" min-width="100" prop="serviceTypeValue"></el-table-column>
				<el-table-column label="客户情况描述" min-width="140" prop="careReceiverDesc"></el-table-column>
				<el-table-column label="工资报价" min-width="140" prop="salaryQuoted"></el-table-column>
				<el-table-column label="要求到岗日期" min-width="100" prop="startWorkDate"></el-table-column>
				<el-table-column label="特殊要求" min-width="140" prop="remark"></el-table-column>
				<el-table-column label="状态" min-width="100" prop="appointStatusValue"></el-table-column>
				<el-table-column label="护理员姓名" min-width="100" prop="careGiverName"></el-table-column>
				<el-table-column fixed="right" label="操作" min-width="180">
					<template slot-scope="scope">
						<el-button size="mini" type="text" @click="updateBtn(scope.row)">查看</el-button>
						<el-button size="mini" type="text" @click="copyBtn(scope.row)">复制</el-button>
						<el-button
							size="mini"
							type="text"
							@click="arrangeBtn(scope.row)"
							v-if="scope.row.appointStatus!='30'"
						>{{scope.row.appointStatus==='20'?'已安排':'安排'}}</el-button>
						<el-button
							size="mini"
							type="text"
							@click="cancelBtn(scope.row)"
							v-if="scope.row.appointStatus=='10'"
						>取消</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filters.pageNum"
					:limit.sync="filters.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
			<!-- 组织 -->
			<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
				<org-select v-on:listenTochildEvent="getCurrentNode" />
			</el-dialog>
			<!-- 安排护理员 -->
			<el-dialog title="安排护理员" :visible.sync="dialogArrangeVisible" width="500px" center>
				<el-input
					type="textarea"
					v-model.trim="careGiverName"
					placeholder="请输入护理员姓名"
					resize="none"
					show-word-limit
					rows="4"
					clearable
					maxlength="100"
				></el-input>
				<div slot="footer" class="dialog-footer">
					<el-button size="mini" @click="dialogArrangeVisible = false">取 消</el-button>
					<el-button style="margin-left:40px;" size="mini" type="primary" @click="dialogConfirmBtn">确 定</el-button>
				</div>
			</el-dialog>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import { changeYMD } from "utils";
import { findValueBySetCode } from "api/common";
import Pagination from "components/Pagination/pagination";
import {
	findRecruitNeedList,
	updateRecruitNeed
} from "api/dispatchRequirement";

import { validateOrderTime } from "utils/validate";
export default {
	components: {
		HeadTag,
		OrgSelect,
		Pagination
	},
	props: {},
	data () {
		return {
			tagName: "派单需求",
			dialogVisible: false,
			totalCount: 1,
			listLoading: false,
			//控制查询按钮加载
			searchLoading: false,
			// 状态
			statusOptions: [],
			// 安排护理员弹框
			dialogArrangeVisible: false,
			recruitNeedList: [],
			filters: {
				// userCode: "",
				// userTel: "",
				// userFullName: "",
				// userStatus: "",
				pageNum: 1,
				pageSize: 10,
				orgName: "",
				orgCode: "",
				createDate: [],
				startWorkDate: [],
				salaryQuoted: "",
				appointStatus: ""
			},
			careGiverName: "" //护理员姓名
		};
	},
	watch: {},
	computed: {},
	methods: {
		resetForm () {
			this.clearOrgCode();
			this.$refs.filterForm.resetFields();
			this.getList(1);
		},

		/**
		 *
		 * 查询条件开窗选择组织
		 *
		 */
		close () {
			this.dialogVisible = false;
		},
		getCurrentNode (data) {
			this.filters.orgName = data.orgName;
			this.filters.orgCode = data.orgCode;
			this.close();
		},
		//清空组织过滤
		clearOrgCode () {
			this.filters.orgName = "";
			this.filters.orgCode = "";
		},
		//初始化数据字典
		initDataDictionary () {
			// 状态
			findValueBySetCode({ valueSetCode: "APPOINT_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.statusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		},
		getList (page) {
			if (page) {
				this.filters.pageNum = page;
			}
			var params = {
				pageNum: this.filters.pageNum,
				pageSize: this.filters.pageSize,
				orgCode: this.filters.orgCode,
				createDateStart: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[0] + " 00:00:00") : null,
				createDateEnd: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[1] + " 23:59:59") : null,
				startWorkDateStart: (this.filters.startWorkDate && this.filters.startWorkDate.length > 0) ? (this.filters.startWorkDate[0] + " 00:00:00") : null,
				startWorkDateEnd: (this.filters.startWorkDate && this.filters.startWorkDate.length > 0) ? (this.filters.startWorkDate[1] + " 23:59:59") : null,
				salaryQuoted: this.filters.salaryQuoted,
				appointStatus: this.filters.appointStatus
			};
			this.listLoading = true;
			this.searchLoading = true;
			findRecruitNeedList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.listLoading = false;
						this.searchLoading = false;
						if (response.data.responseData != undefined) {
							this.recruitNeedList = response.data.responseData.map(item => {
								item.createDate = item.createDate
									? changeYMD(item.createDate)
									: "";
								item.startWorkDate = item.startWorkDate
									? changeYMD(item.startWorkDate)
									: "";
								return item;
							});
							this.totalCount = response.data.totalCount;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
					}
				})
				.catch(error => {
					console.log("findRecruitNeedList:" + error);
					this.listLoading = false;
					this.searchLoading = false;
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.filters.pageNum = val.page;
			this.filters.pageSize = val.limit;
			this.getList(); //改变页码，重新渲染页面
		},
		//新增派单
		addDispatch () {
			this.$router.push({
				path: "/personnelManagement/addDispatch"
			});
		},
		//查看派单
		updateBtn (data) {
			this.$router.push({
				path: "/personnelManagement/updateDispatch",
				query: {
					id: data.id,
					readOnly: data.appointStatus === "10" ? false : true //已安排护理员、已取消不可修改
				}
			});
		},
		//复制派单
		copyBtn (data) {
			this.$router.push({
				path: "/personnelManagement/copyDispatch",
				query: {
					id: data.id
				}
			});
		},
		//安排按钮
		arrangeBtn (data) {
			this.dialogArrangeVisible = true;
			this.careGiverName =
				data.appointStatus === "20" ? data.careGiverName : "";
			this.id = data.id; //存储当前行id
		},
		//取消派单
		cancelBtn (data) {
			this.$confirm("确定取消该派单？", "提示", {
				type: "warning"
			}).then(() => {
				let params = {
					id: data.id,
					appointStatus: "30", //'客户取消'状态对应的编码
					careGiverName: data.careGiverName
				};
				updateRecruitNeed(params)
					.then(response => {
						if (
							response.data.statusCode === 200 ||
							response.data.statusCode === "200"
						) {
							this.$message.success("取消派单成功");
							this.getList();
						} else {
							this.$message.error(response.data.statusMsg);
						}
					})
					.catch(error => {
						console.log("updateRecruitNeed:" + error);
					});
			});
		},
		// 安排护理员
		dialogConfirmBtn () {
			if (!this.careGiverName) {
				this.$message.error("请填写护理员姓名");
				return;
			}
			let params = {
				id: this.id,
				appointStatus: "20", //'已经安排'状态对应的编码
				careGiverName: this.careGiverName
			};
			updateRecruitNeed(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.dialogArrangeVisible = false;
						this.$message.success("安排护理员成功");
						this.getList();
					} else {
						this.$message.error(response.data.statusMsg);
					}
				})
				.catch(error => {
					console.log("updateRecruitNeed:" + error);
				});
		},
		/**
		 * 导出
		 */
		exportDispatch () {
			require.ensure([], () => {
				const { export_json_to_excel } = require("@/utils/Export2Excel");
				const tHeader = [
					"组织",
					"创建时间",
					"区域",
					"性别",
					"年龄",
					"服务形式",
					"客户情况描述",
					"工资报价",
					"要求到岗日期",
					"特殊要求",
					"状态",
					"护理员姓名"
				];
				// 上面设置Excel的表格第一行的标题
				const filterVal = [
					"orgName",
					"createDate",
					"workDistrictName",
					"genderValue",
					"age",
					"serviceTypeValue",
					"careReceiverDesc",
					"salaryQuoted",
					"startWorkDate",
					"remark",
					"appointStatusValue",
					"careGiverName"
				];
				const params = {
					pageNum: this.filters.pageNum,
					pageSize: this.filters.pageSize,
					orgCode: this.filters.orgCode,
					createDateStart: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[0] + " 00:00:00") : null, 
					createDateEnd: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[1] + " 23:59:59") : null,
					startWorkDateStart: (this.filters.startWorkDate && this.filters.startWorkDate.length > 0) ? (this.filters.startWorkDate[0] + " 00:00:00") : null, 
					startWorkDateEnd: (this.filters.startWorkDate && this.filters.startWorkDate.length > 0) ? (this.filters.startWorkDate[1] + " 23:59:59") : null,
					salaryQuoted: this.filters.salaryQuoted,
					appointStatus: this.filters.appointStatus
				};
				findRecruitNeedList(params)
					.then(response => {
						let list = [];
						if (response.data.responseData) {
							list = response.data.responseData.map(item => {
								item.createDate = item.createDate
									? changeYMD(item.createDate)
									: "";
								item.startWorkDate = item.startWorkDate
									? changeYMD(item.startWorkDate)
									: "";
								return item;
							}); //把data里的tableData存到list
						}
						if (list.length > 0) {
							const data = this.formatJson(filterVal, list);
							try {
								export_json_to_excel(tHeader, data, "派单需求列表");
							} catch (error) {
								this.$message.error("导出失败，请检查数据是否异常");
							}
						} else {
							this.$message.error("暂无数据，无法导出Excel");
						}
					})
					.catch(error => {
						console.log(error);
					});
			});
		},
		formatJson (filterVal, jsonData) {
			return jsonData.map(v => filterVal.map(j => v[j]));
		}
	},

	created () { },
	mounted () { },
	activated () {
		this.getList(1);
		this.initDataDictionary();
	}
};
</script>
<style lang="scss" scoped>
#dispatchRequirementList {
	width: 100%;
	min-width: 1200px;
	.el-form-item {
		margin-bottom: 0px;
	}

	.el-input {
		width: 200px;
	}
	.el-select {
		width: 200px;
	}
	.el-autocomplete {
		width: 200px;
	}
	.form-item {
		width: 30%;
		min-width: 305px;
	}
	.form-items {
		width: 30%;
		min-width: 380px;
	}
	.search_btn {
		min-width: 250px;
		margin-left: 120px;
	}
	.tableTopBtn {
		background-color: white;
		text-align: right;
		padding: 20px 20px 20px 0px;
	}
	.el-dialog {
		display: flex;
		flex-direction: column;
		margin: 0 !important;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}
	.el-dialog .el-dialog__body {
		flex: 1;
		overflow: auto;
	}
}
</style>
<style lang="scss">
#dispatchRequirementList {
	.el-date-editor--daterange.el-input__inner {
		width: 250px;
	}
}
// .el-autocomplete-suggestion__wrap {
//   max-height: 380px;
// }
// .el-time-panel__footer {
//   margin-right: 34px !important;
// }
</style>