<template>
  <div :class="classObj" class="app-wrapper">
    <div v-if="device==='mobile'&&sidebar.opened&&!isFullScreen" class="drawer-bg" @click="handleClickOutside"/>
    <sidebar class="sidebar-container" v-if="isFullScreen==false"/>
    <div :class="{hasTagsView:needTagsView}" class="main-container" :style="isFullScreen?{marginLeft:'0px'}:{}">
      <div :class="{'fixed-header':fixedHeader}" v-if="isFullScreen==false">
        <navbar/>
        <tags-view v-if="needTagsView" />
      </div>
      <app-main/>
      <right-panel v-if="showSettings&&!isFullScreen">
        <settings />
      </right-panel>
    </div>
  </div>
</template>

<script>
import RightPanel from 'components/RightPanel'
import { Navbar, Sidebar, AppMain, Settings, TagsView } from './components'
import ResizeMixin from './mixin/ResizeHandler'

export default {
  name: 'Layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    Settings,
    RightPanel,
    TagsView
  },
  mixins: [ResizeMixin],
  data(){
    return {
      isFullScreen:false,
    }
  },
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    },
    device() {
      return this.$store.state.app.device
    },
    fixedHeader() {
      return this.$store.state.settings.fixedHeader
    },
    showSettings() {
      return this.$store.state.settings.showSettings
    },
    needTagsView() {
      return this.$store.state.settings.tagsView
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile',
      }
    }
  },
  created(){
    var that = this;
    this.EventBus.handleEvent("screenFullEvent",(val)=>{
      if(val){
        that.isFullScreen = val.isFullScreen;
      }
    })
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('CloseSideBar', { withoutAnimation: false })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/mixin.scss";
  @import "~@/styles/variables.scss";
  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;
    &.mobile.openSidebar{
      position: fixed;
      top: 0;
    }
  }
  .drawer-bg {
    background: #000;
    opacity: 0.3;
    width: 100%;
    top: 0;
    height: 100%;
    position: absolute;
    z-index: 999;
  }
  .fixed-header {
    position: fixed;
    top: 0;
    right: 0;
    z-index: 9;
    width: calc(100% - #{$sideBarWidth});
    transition: width 0.28s;
  }

  .hideSidebar .fixed-header {
    width: calc(100% - 54px)
  }

  .mobile .fixed-header {
    width: 100%;
  }
</style>
