<template>
	<div class="navbar">
		<hamburger :toggle-click="toggleSideBar" :is-active="sidebar.opened" class="hamburger-container" />

		<breadcrumb class="breadcrumb-container" />

		<div class="right-menu">
			<div v-if="showGlobalRemind" style="margin-right:5px">
				<div class="red-point" v-if="isGlobalRemind"></div>
				<svg-icon class="icon-remind" icon-class="equip-remind" @click="toRemind" />
			</div>
			<el-dropdown class="avatar-container" trigger="click">
				<div class="avatar-wrapper">
					<img
						src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
						class="user-avatar"
					/>
					<span>你好,{{userFullName}}</span>
					<i class="el-icon-caret-bottom" />
				</div>
				<el-dropdown-menu slot="dropdown" class="user-dropdown">
					<router-link to="/personal/personalCenter">
						<el-dropdown-item>个人中心</el-dropdown-item>
					</router-link>
					<el-dropdown-item divided>
						<span style="display:block;" @click="logout">退出</span>
					</el-dropdown-item>
				</el-dropdown-menu>
			</el-dropdown>
		</div>
	</div>
</template>

<script>
import Cookies from 'js-cookie'
import { mapGetters } from 'vuex'
import Breadcrumb from 'components/Breadcrumb'
import Hamburger from 'components/Hamburger'
import { getUserInfo } from 'utils/userMgr'
import store from '@/store'
import { getMenu } from 'api/login'
import {selectAlarmCountByUer} from "@/api/equipmentManagement"

export default {
	data () {
		return {
			userFullName: "",
			isGlobalRemind: false,
			showGlobalRemind:false,
		}
	},
	mounted () {
		this.userFullName = getUserInfo().userFullName;
		var param={userCode:getUserInfo().userCode}
		selectAlarmCountByUer(param).then(response =>{
			if(response.data.statusCode == 200){
				if(response.data.responseData && response.data.responseData.count !=0){
					this.isGlobalRemind = true;
				}
			}
		})
		
	},
	components: {
		Breadcrumb,
		Hamburger
	},
	computed: {
		...mapGetters([
			'sidebar'
		])
	},
	methods: {
		toggleSideBar () {
			this.$store.dispatch('ToggleSideBar')
		},
		logout () {
			this.$router.push({ path: '/login' })
			this.$store.dispatch('LogOut').then(() => {
				location.reload() // 为了重新实例化vue-router对象 避免bug
			})
		},
		toRemind (obj) {
			this.isGlobalRemind = false;
			this.$router.push({
				path: "/wisdomCustody/AlarmList",
				query: {
					careReceiver:{
						orgName:this.$store.getters.userOrgName,
						orgCode:this.$store.getters.userOrgCode
					},
					type: '2'
				}
			})
		},
		audioPlay () {
			if (this.audioPlayer === undefined) {
				this.audioPlayer = new Audio("static/audio/remind.mp3");
				this.audioPlayer.play();
			} else {
				if (this.audioPlayer.paused) {
					this.audioPlayer.play();
				} else {
					this.audioPlayer.pause();
				}
			}
			this.clockAnimated();
		},
		//铃声动画
		clockAnimated: function () {
			this.animateCSS('.icon-remind', 'heartBeat')
		},
		animateCSS (element, animationName, callback) {
			const node = document.querySelector(element)
			node.classList.add('animated', animationName)
			function handleAnimationEnd () {
				node.classList.remove('animated', animationName)
				node.removeEventListener('animationend', handleAnimationEnd)
				if (typeof callback === 'function') callback()
			}
			node.addEventListener('animationend', handleAnimationEnd)
		},
	},
	created () {
		setTimeout(()=>{
			 getMenu(this.UserMgr.getUserInfo().userCode).then(response => {
         	 const data = response.data.responseData
			 if(data.privilegeNames&&data.privilegeNames.includes("alarm_global")){
				 this.showGlobalRemind = true;
				 this.WebSocketHelper.initWebSocketByAll(this);
			 }
			}).catch(error => {
			})
		},16)
		var that = this;
		this.EventBus.handleEvent("closeMenuBar", function (val) {
			//评估导出PDF控制左侧菜单隐藏
			Cookies.set('sidebarStatus', 1)
			that.$store.state.app.sidebar.opened = false;
			that.$store.state.app.sidebar.withoutAnimation = false
		})
		this.EventBus.handleEvent("receivedMsgAll", function (val) {
			that.isGlobalRemind = true;
			val = JSON.parse(val);
			if(val.messageType=="orgAlarm" && val.count != 0){//组织下的老人设备告警
				that.audioPlay();
			}
			if(val.messageType=="orgAlarmFirst" && val.count != 0){//第一次全局告警
				that.audioPlay();
			}
		})
	},
	beforeDestroy () {
	}
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
	height: 50px;
	overflow: hidden;
	position: relative;
	background: #fff;
	box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

	.hamburger-container {
		line-height: 60px;
		height: 100%;
		float: left;
		cursor: pointer;
		transition: background 0.3s;
		-webkit-tap-highlight-color: transparent;

		&:hover {
			background: rgba(0, 0, 0, 0.025);
		}
	}

	.breadcrumb-container {
		float: left;
	}

	.right-menu {
		float: right;
		height: 100%;
		line-height: 50px;
		display: flex;

		&:focus {
			outline: none;
		}

		.right-menu-item {
			display: inline-block;
			padding: 0 8px;
			height: 100%;
			font-size: 18px;
			color: #5a5e66;
			vertical-align: text-bottom;

			&.hover-effect {
				cursor: pointer;
				transition: background 0.3s;

				&:hover {
					background: rgba(0, 0, 0, 0.025);
				}
			}
		}

		.avatar-container {
			margin-right: 30px;

			.avatar-wrapper {
				position: relative;

				.user-avatar {
					cursor: pointer;
					width: 35px;
					height: 35px;
					border-radius: 10px;
					vertical-align: middle;
				}

				.el-icon-caret-bottom {
					cursor: pointer;
					position: absolute;
					right: -20px;
					top: 20px;
					font-size: 12px;
				}
			}
		}
	}
}
.global-remind {
	margin-right: 10px;
}
.red-point {
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background-color: red;
	float: right;
	margin-top: 12px;
	margin-right: 10px;
}
.icon-remind {
	cursor: pointer;
}
</style>

