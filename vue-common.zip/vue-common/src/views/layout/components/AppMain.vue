<template>
  <section class="app-main">
      <keep-alive>
        <router-view v-if="noCache&&refresh"></router-view>
      </keep-alive>
      <router-view v-if="!noCache&&refresh"></router-view>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  data(){
    return {
      refresh:true,
    }
  },
  computed: {
    noCache(){
      return this.$route.meta.noCache;
    }
  },
  created(){
    var that=this
    this.EventBus.handleEvent("refreshCurrent",(val)=>{
      that.refresh=false;
      that.$nextTick(function(){
        that.refresh=true;
      })
    })
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  /*50 = navbar  */
  min-height: calc(100vh - 0px);
  position: relative;
  overflow: auto;
  background-color: #edeff2;
}

.fixed-header+.app-main {
  padding-top: 50px;
}

.hasTagsView {
  .fixed-header+.app-main {
    padding-top: 84px;
  }
}
</style>