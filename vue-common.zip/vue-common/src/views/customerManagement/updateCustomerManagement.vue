<template>
  <div id="customerManage">
    <headTag :tagName="tagName"/>

    <div class="main-content">
      <div class="main-left">
        <div class="margin-left-form" style="padding-bottom:60px;" id="staffForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">基本信息</span>
              <el-button
                type="primary"
                size="small"
                @click="returnCustomerList()"
                class="rightBtn"
              >返回</el-button>
              <el-button
                type="primary"
                size="small"
                @click="saveStaff('staffForm')"
                class="rightBtn"
                :loading="loadingBtn"
                v-if="flag"
              >保存</el-button>
              <el-button
                type="primary"
                size="small"
                @click="editStaff()"
                class="rightBtn"
                :loading="loadingBtn"
                v-if="!flag"
              >修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-form
              ref="staffForm"
              :inline="false"
              :model="staffForm"
              :rules="rules"
              label-width="150px"
              class="form-content"
            >
              <el-col class="form-item">
                <el-form-item label="姓名" prop="staffFullName">
                  <span v-if="isEdit == false">{{staffForm.staffFullName}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffFullName"
                      size="mini"
                      clearable
                      placeholder="请输入姓名"
                      maxlength="20"
                    />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="性别" prop="staffGender">
                  <span v-if="isEdit == false">{{staffForm.staffGenderValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.staffGender"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in staffGenderOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="入职时间" prop="entryDate">
                  <span v-if="isEdit == false">{{staffForm.entryDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="staffForm.entryDate"
                      size="mini"
                      clearable
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="请选择入职时间"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="手机号码" prop="staffTel">
                  <span v-if="isEdit == false">{{staffForm.staffTel}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffTel"
                      size="mini"
                      clearable
                      placeholder="请输入手机号码"
                      maxlength="11"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="组织" prop="orgName">
                  <span v-if="isEdit == false">{{staffForm.orgName}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.orgName"
                      size="mini"
                      placeholder="请选择组织"
                      @focus="openDialogStaff"
                      clearable
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="岗位" prop="positionName">
                  <span v-if="isEdit == false">{{staffForm.positionName}}</span>
                  <span v-if="isEdit == true">
                    <el-autocomplete
                      :trigger-on-focus="true"
                      v-model="staffForm.positionName"
                      size="mini"
                      clearable
                      :fetch-suggestions="queryStaffPositionName"
                      placeholder="请输入岗位"
                      @select="selectStaffPositionName"
                      @blur="removeStaffPositionCode"
                      @input="inputStaffPositionName"
                    ></el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="身份证号码" prop="idCard">
                  <span v-if="isEdit == false">{{staffForm.idCard}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.idCard"
                      size="mini"
                      @blur="validatorIdCard(staffForm)"
                      clearable
                      placeholder="请输入身份证号码"
                      maxlength="18"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="身份证地址" prop="idCardAddress">
                  <span v-if="isEdit == false" class="long-field">{{staffForm.idCardAddress }}</span>
                  <span v-if="isEdit == true">
                    <el-tooltip class="item" effect="dark" :disabled="staffForm.idCardAddress == '' ? true : false" :content="staffForm.idCardAddress" placement="top">
                      <el-input
                        v-model="staffForm.idCardAddress"
                        size="mini"
                        clearable
                        placeholder="请输入身份证地址"
                        maxlength="30"
                      ></el-input>
                    </el-tooltip>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="出生年月" prop="staffBirthday">
                  <span v-if="isEdit == false">{{staffForm.staffBirthday}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffBirthday"
                      size="mini"
                      clearable
                      placeholder="请输入例如：1950-01-01"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="籍贯">
                  <span v-if="isEdit == false" class="long-field">{{staffForm.nativePlace}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.nativePlace"
                      size="mini"
                      clearable
                      placeholder="请输入籍贯"
                      maxlength="50"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <!-- <el-col class="form-item"2
              
              >
                <el-form-item label="户籍地址">
                  <span v-if="isEdit == false">
                    <span
                      v-if="staffForm.houseProvinceName != ''"
                    >{{staffForm.houseProvinceName}}{{staffForm.houseCityName}}{{staffForm.houseDistrictName}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <AddressAutocomplete
                      ref="houseAddress"
                      :address="{
                        provinceCode:staffForm.houseProvinceCode,
                        provinceName:staffForm.houseProvinceName,
                        cityCode: staffForm.houseCityCode,
                        cityName: staffForm.houseCityName,
                        districtCode:staffForm.houseDistrictCode,
                        districtName:staffForm.houseDistrictName
                        }"
                      @selectedProvinceListener="selectedHouseProvinceListener"
                      @selectedCityListener="selectedHouseCityListener"
                      @selectedDistrictListener="selectedHouseDistrictListener"
                    />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                  <span v-if="isEdit == false" class="long-field">{{staffForm.houseDetailAddress}}</span>
                  <span v-if="isEdit == true">
                    <el-tooltip class="item" effect="dark" :disabled="staffForm.houseDetailAddress == '' ? true : false" :content="staffForm.houseDetailAddress" placement="top">
                      <el-input
                        v-model="staffForm.houseDetailAddress"
                        size="mini"
                        clearable
                        placeholder="请输入户籍详细地址"
                        maxlength="50"
                      ></el-input>
                    </el-tooltip>
                  </span>
                </el-form-item>
              </el-col> -->
              <el-col class="form-item">
                <el-form-item label="现居住地址" required>
                  <span v-if="isEdit == false">
                    <span
                      v-if="staffForm.liveProvinceName" class="long-field"
                    >{{staffForm.liveProvinceName}}{{staffForm.liveCityName}}{{staffForm.liveDistrictName}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <AddressAutocomplete
                      ref="liveAddress"
                      :address="{
                        provinceCode:staffForm.liveProvinceCode,
                        provinceName:staffForm.liveProvinceName,
                        cityCode: staffForm.liveCityCode,
                        cityName: staffForm.liveCityName,
                        districtCode:staffForm.liveDistrictCode,
                        districtName:staffForm.liveDistrictName
                        }"
                      @selectedProvinceListener="selectedLiveProvinceListener"
                      @selectedCityListener="selectedLiveCityListener"
                      @selectedDistrictListener="selectedLiveDistrictListener"
                    />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                  <span v-if="isEdit == false" class="long-field">{{staffForm.liveDetailAddress }}</span>
                  <span v-if="isEdit == true">
                    <el-tooltip class="item" effect="dark" :disabled="staffForm.liveDetailAddress == '' ? true : false" :content="staffForm.liveDetailAddress" placement="top">
                      <el-input
                        v-model="staffForm.liveDetailAddress"
                        size="mini"
                        clearable
                        placeholder="请输入现居住详细地址"
                        maxlength="50"
                      ></el-input>
                    </el-tooltip>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="最高学历" prop="staffEducation">
                  <span v-if="isEdit == false">{{staffForm.staffEducationValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.staffEducation"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in staffEducationOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
               <el-col class="form-item">
                <el-form-item label="政治面貌" prop="staffPolitical">
                  <span v-if="isEdit == false">{{staffForm.staffPoliticalValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.staffPolitical"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in staffPoliticalOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="民族">
                  <span v-if="isEdit == false">{{staffForm.staffNation}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffNation"
                      size="mini"
                      clearable
                      placeholder="请输入民族"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="健康证到期时间" prop="healthCertificateDate">
                  <span v-if="isEdit == false">{{staffForm.healthCertificateDate}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.healthCertificateDate"
                      size="mini"
                      clearable
                      placeholder="请输入例如：2020-01-01"
                      @keyup.110.native="changeInputHCDate"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="员工归属" prop="staffBelong">
                  <span v-if="isEdit == false">{{staffForm.staffBelongValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.staffBelong"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in staffBelongOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="合作商">
                  <span v-if="isEdit == false">{{staffForm.cooperationName}}</span>
                  <span v-if="isEdit == true">
                    <el-autocomplete
                      :trigger-on-focus="true"
                      v-model="staffForm.cooperationName"
                      size="mini"
                      clearable
                      :fetch-suggestions="queryCooperationName"
                      placeholder="请输入合作商名称"
                      @select="selectCooperationName"
                      @blur="removeCooperationCode"
                      @input="inputCooperationName"
                    ></el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="在合作商岗位">
                  <span v-if="isEdit == false">{{staffForm.cooperationPositionValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.cooperationPosition"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in cooperationPositionOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="岗位类型" prop="positionType">
                  <span v-if="isEdit == false">{{staffForm.positionTypeValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.positionType"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in positionTypeOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="转正工资" prop="formalSalary">
                  <span v-if="isEdit == false">
                    <span
                      v-if="staffForm.formalSalary"
                    >{{staffForm.formalSalary}}/{{staffForm.formalSalaryUnitValue}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.formalSalary"
                      size="mini"
                      clearable
                      placeholder="请输入转正工资"
                    >
                      <el-select
                        v-model="staffForm.formalSalaryUnit"
                        slot="append"
                        size="mini"
                        style="width:60px;"
                      >
                        <el-option
                          v-for="item in formalSalaryUnitOptions"
                          :key="item.value"
                          :label="item.name"
                          :value="item.value"
                        />
                      </el-select>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="转正时间" prop="formalDate">
                  <span v-if="isEdit == false">{{staffForm.formalDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="staffForm.formalDate"
                      size="mini"
                      clearable
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="请选择转正时间"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="试用期工资" prop="probationSalary">
                  <span v-if="isEdit == false">
                    <span
                      v-if="staffForm.probationSalary"
                    >{{staffForm.probationSalary}}/{{staffForm.probationSalaryUnitValue}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.probationSalary"
                      size="mini"
                      clearable
                      placeholder="请输入试用期工资"
                    >
                      <el-select
                        v-model="staffForm.probationSalaryUnit"
                        slot="append"
                        size="mini"
                        style="width:60px;"
                      >
                        <el-option
                          v-for="item in probationSalaryUnitOptions"
                          :key="item.value"
                          :label="item.name"
                          :value="item.value"
                        />
                      </el-select>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="试用期时间" prop="probationStartDate">
                  <span v-if="isEdit == false">
                    <span
                      v-if="staffForm.probationStartDate"
                    >{{staffForm.probationStartDate }}---{{staffForm.probationEndDate }}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="probationDate"
                      size="mini"
                      value-format="yyyy-MM-dd"
                      format="yyyy-MM-dd"
                      type="daterange"
                      unlink-panels
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      @blur="choiceDatePicker"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="员工星级">
                  <span v-if="isEdit == false">{{staffForm.staffGradeValue }}</span>
                  <span v-if="isEdit == true">
                    <div style="width:300px;">
                      <el-select
                        v-model="staffForm.staffGrade"
                        size="mini"
                        style="width:70px;"
                        clearable
                        :disabled="disabledGrade"
                        @change="changeStaffGrade"
                        @clear="clearStaffGrade"
                        placeholder="星级"
                      >
                        <el-option
                          v-for="item in staffGradeOptions"
                          :key="item.value"
                          :label="item.name"
                          :value="item.value"
                        />
                      </el-select>
                      <span v-if="showDate">
                        <el-date-picker
                          v-model="staffForm.staffGradeEffectiveStartDate"
                          size="mini"
                          style="width: 180px;"
                          clearable
                          :disabled="disabledGrade"
                          value-format="yyyy-MM-dd"
                          type="date"
                          placeholder="请选择生效开始时间"
                        ></el-date-picker>
                      </span>
                    </div>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="评定星级时间">
                  <span v-if="isEdit == false">{{staffForm.staffGradeEvaluateDate }}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="staffForm.staffGradeEvaluateDate"
                      size="mini"
                      clearable
                      :disabled="disabledGrade"
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="请选择评定时间"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="紧急联系人" prop="urgentContactsName">
                  <span v-if="isEdit == false">{{staffForm.urgentContactsName}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.urgentContactsName"
                      size="mini"
                      clearable
                      placeholder="请输入紧急联系人"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="紧急联系号码" prop="urgentContactsTel">
                  <span v-if="isEdit == false">{{staffForm.urgentContactsTel}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.urgentContactsTel"
                      size="mini"
                      clearable
                      placeholder="请输入紧急联系号码"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="婚姻状况" prop="maritalStatus">
                  <span v-if="isEdit == false">{{staffForm.maritalStatusValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.maritalStatus"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in maritalStatusOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="在职状态" prop="workStatus">
                  <span v-if="isEdit == false">{{staffForm.workStatusValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.workStatus"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in workStatusOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="离职时间" prop="quitDate">
                  <span v-if="isEdit == false">{{staffForm.quitDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="staffForm.quitDate"
                      size="mini"
                      clearable
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="请选择离职时间"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="银行卡号">
                  <span v-if="isEdit == false">{{staffForm.bankCardAccount }}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.bankCardAccount"
                      size="mini"
                      clearable
                      placeholder="请输入建设银行卡号"
                      onkeyup="this.value = this.value.replace(/[^\d]/g,'');"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="公积金号码">
                  <span v-if="isEdit == false">{{staffForm.housingFundAccount }}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.housingFundAccount"
                      size="mini"
                      clearable
                      placeholder="请输入公积金号码"
                      onkeyup="this.value = this.value.replace(/[^\d]/g,'');"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="公积金基数">
                  <span v-if="isEdit == false">{{staffForm.housingFundBaseValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.housingFundBase"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in housingFundBaseOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="五险基数">
                  <span v-if="isEdit == false">{{staffForm.socialSecurityBaseValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.socialSecurityBase"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in socialSecurityBaseOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      />
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <!-- <el-col class="form-item">
                <el-form-item label="身高">
                  <span v-if="isEdit == false">
                    <span v-if="staffForm.staffHeight">{{staffForm.staffHeight}}cm</span>
                    <span v-else>{{staffForm.staffHeight}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffHeight"
                      size="mini"
                      clearable
                      placeholder="请输入身高"
                      onkeyup="this.value = this.value.replace(/[^\d]/g,'');"
                      maxlength="3"
                    >
                      <template slot="append">cm</template>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="爱好">
                  <span v-if="isEdit == false">{{staffForm.staffHobby}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffHobby"
                      size="mini"
                      clearable
                      placeholder="请输入爱好"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col> -->
              <el-col class="form-item">
                <el-form-item label="备注">
                  <span v-if="isEdit == false" class="long-field">{{staffForm.remark}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="staffForm.remark"
                      size="mini"
                      clearable
                      placeholder="请输入备注"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <!-- <el-col class="form-item">
                <el-form-item label="电脑水平">
                  <span v-if="isEdit == false">{{staffForm.computerLevelValue}}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.computerLevel"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in computerLevelOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="专业职称">
                  <span v-if="isEdit == false">{{staffForm.professionalTitle }}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.professionalTitle"
                      size="mini"
                      clearable
                      placeholder="请输入专业职称"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="专业">
                  <span v-if="isEdit == false">{{staffForm.staffMajor}}</span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffMajor"
                      size="mini"
                      clearable
                      placeholder="请输入专业"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col> 
              <el-col class="form-item">
                <el-form-item label="体重">
                  <span v-if="isEdit == false">
                    <span v-if="staffForm.staffWeight">{{staffForm.staffWeight}}kg</span>
                    <span v-else>{{staffForm.staffWeight}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-input
                      v-model="staffForm.staffWeight"
                      size="mini"
                      clearable
                      placeholder="请输入体重"
                      onkeyup="this.value = this.value.replace(/[^\d]/g,'');"
                      maxlength="3"
                    >
                      <template slot="append">kg</template>
                    </el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="病史">
                  <span v-if="isEdit == false">
                    <span v-if="staffForm.diseaseHistoryStatus == 0">无</span>
                    <span
                      v-if="staffForm.diseaseHistoryStatus == 1"
                    >有 {{staffForm.diseaseHistoryInfo}}</span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-radio-group
                      v-model="staffForm.diseaseHistoryStatus"
                      @change="medicalChange"
                    >
                      <el-radio :label="0">无</el-radio>
                      <el-radio :label="1">有</el-radio>
                    </el-radio-group>
                    <el-input
                      v-model="staffForm.diseaseHistoryInfo"
                      style="width:90px;"
                      clearable
                      placeholder="请输入"
                      v-if="staffForm.diseaseHistoryStatus == 1"
                      maxlength="20"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="是否背调" prop="backgroundCheckStatus">
                  <span v-if="isEdit == false">
                    <span v-if="staffForm.backgroundCheckStatus == 0">否</span>
                    <span v-if="staffForm.backgroundCheckStatus == 1">
                      有
                      <el-button size="mini" style="margin-left:10px;" @click="btnDetail()">查看详情</el-button>
                    </span>
                  </span>
                  <span v-if="isEdit == true">
                    <el-radio-group v-model="staffForm.backgroundCheckStatus">
                      <el-radio :label="0">否</el-radio>
                      <el-radio :label="1">是</el-radio>
                    </el-radio-group>
                    <span v-if="staffForm.backgroundCheckStatus == 1">
                      <el-button size="mini" style="margin-left:10px;" @click="btnDetail()">查看详情</el-button>
                    </span>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="信仰">
                  <span v-if="isEdit == false">{{staffForm.staffFaithValue }}</span>
                  <span v-if="isEdit == true">
                    <el-select
                      v-model="staffForm.staffFaith"
                      size="mini"
                      clearable
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="item in staffFaithOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="晋升前岗位">
                  <span v-if="isEdit == false">{{staffForm.promotionPositionName}}</span>
                  <span v-if="isEdit == true">
                    <el-autocomplete
                      :trigger-on-focus="true"
                      v-model="staffForm.promotionPositionName"
                      size="mini"
                      clearable
                      :fetch-suggestions="queryPromotionPositionName"
                      placeholder="请输入晋升前岗位"
                      @select="selectPromotionPositionName"
                      @blur="removePromotionPositionCode"
                      @input="inputPromotionPositionName"
                    ></el-autocomplete>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="晋升时间" prop="promotionDate">
                  <span v-if="isEdit == false">{{staffForm.promotionDate}}</span>
                  <span v-if="isEdit == true">
                    <el-date-picker
                      v-model="staffForm.promotionDate"
                      size="mini"
                      clearable
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="请选择晋升时间"
                    ></el-date-picker>
                  </span>
                </el-form-item>
              </el-col>-->
            </el-form>
          </el-row>
        </div>
        <div class="margin-left-form" id="postForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">岗位管理</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addPostForm('postForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="postForm.rules" :model="postForm" ref="postForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="postForm.tableData"
                  v-loading="postListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="orgName" label="入职组织" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.orgName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.orgName'"
                          :rules="postForm.rules.orgName"
                        >
                          <el-input
                            v-model="scope.row.orgName"
                            size="mini"
                            placeholder="请选择入职组织"
                            @focus="openDialog(scope.$index)"
                            clearable
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="positionName" label="岗位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.positionName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.positionName'"
                          :rules="postForm.rules.positionName"
                        >
                          <el-autocomplete
                            :trigger-on-focus="true"
                            v-model="scope.row.positionName"
                            size="mini"
                            clearable
                            :fetch-suggestions="queryPositionName"
                            placeholder="请输入岗位"
                            @select="selectPositionName($event,scope.$index)"
                            @blur="removePositionCode(scope.$index)"
                            @input="inputPostionName(scope.$index)"
                          ></el-autocomplete>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isDefault" label="默认岗位" min-width="100px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.isDefault == 1">是</span>
                        <span v-else>否</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.isDefault'"
                          :rules="postForm.rules.isDefault"
                        >
                          <span v-if="scope.row.isDefault == 1">是</span>
                          <span v-else>否</span>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isManager" label="组织权限" min-width="100px">
                    <template slot-scope="scope">
                      <span v-if="!scope.row.editing">
                      <el-form-item
                        :prop="'tableData.' + scope.$index + '.isManager'"
                        :rules="postForm.rules.isManager"
                      >
                        <el-switch
                          @change="handleChangeManageStatus(scope.$index, scope.row)"
                          v-model="scope.row.isManager"
                        ></el-switch>
                      </el-form-item>
                      </span>
                      <span v-else></span>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditPostForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSavePostForm(scope.$index, scope.row, 'postForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          v-if="scope.row.isDefault == '0' "
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeletePostForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <div class="margin-left-form" id="gradeForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">星级管理</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addGradeForm('gradeForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="gradeForm.rules" :model="gradeForm" ref="gradeForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="gradeForm.tableData"
                  v-loading="gradeListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column
                    prop="staffGrade"
                    label="星级"
                    min-width="220px"
                  >
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.staffGradeValue }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.staffGrade'"
                          :rules="gradeForm.rules.staffGrade"
                        >
                          <el-select
                            v-model="scope.row.staffGrade"
                            size="mini"
                            clearable
                            placeholder="请选择星级"
                          >
                            <el-option
                              v-for="item in staffGradeOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            />
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="staffGradeEffectiveStartDate" label="生效开始时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.staffGradeEffectiveStartDate">
                          <span>{{ scope.row.staffGradeEffectiveStartDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.staffGradeEffectiveStartDate'"
                          :rules="gradeForm.rules.staffGradeEffectiveStartDate"
                        >
                          <el-date-picker
                            v-model="scope.row.staffGradeEffectiveStartDate"
                            size="mini"
                            clearable
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="请选择生效开始时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="staffGradeEffectiveEndDate" label="生效结束时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.staffGradeEffectiveEndDate">
                          <span>{{ scope.row.staffGradeEffectiveEndDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.staffGradeEffectiveEndDate'"
                          :rules="gradeForm.rules.staffGradeEffectiveEndDate"
                        >
                          <el-date-picker
                            v-model="scope.row.staffGradeEffectiveEndDate"
                            size="mini"
                            clearable
                            :disabled="true"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="系统生成"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="staffGradeEvaluateDate" label="评定时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.staffGradeEvaluateDate">
                          <span>{{ scope.row.staffGradeEvaluateDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.staffGradeEvaluateDate'"
                          :rules="gradeForm.rules.staffGradeEvaluateDate"
                        >
                          <el-date-picker
                            v-model="scope.row.staffGradeEvaluateDate"
                            size="mini"
                            clearable
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择评定时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <!-- <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditGradeForm(scope.$index, scope.row)"
                        >编辑</el-button> -->
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveGradeForm(scope.$index, scope.row, 'gradeForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          v-if="scope.row.staffGradeEffectiveStatus == false"
                          @click="handleDeleteGradeForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <div class="margin-left-form" id="contractForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">合同</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addContractForm('contractForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="contractForm.rules" :model="contractForm" ref="contractForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="contractForm.tableData"
                  v-loading="contractListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="orgName" label="入职组织" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.orgName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.orgName'"
                          :rules="contractForm.rules.orgName"
                        >
                          <el-input
                            v-model="scope.row.orgName"
                            size="mini"
                            @focus="openDialogContract(scope.$index)"
                            placeholder="请选择入职组织"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contractCode" label="合同编号" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.contractCode }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.contractCode'"
                          :rules="contractForm.rules.contractCode"
                        >
                          <el-input
                            v-model="scope.row.contractCode"
                            size="mini"
                            placeholder="请输入合同编号"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contractType" label="合同类型" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.contractTypeName">
                          <span>{{scope.row.contractTypeName}}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.contractType'"
                          :rules="contractForm.rules.contractType"
                        >
                          <el-select
                            v-model="scope.row.contractType"
                            size="mini"
                            placeholder="请选择"
                            clearable
                            @change="changeContractType(scope.row.contractType,scope.$index)"
                          >
                            <el-option
                              v-for="item in contractTypeOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="renewContractType" label="续签类型" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.renewContractType">
                          <span>{{scope.row.renewContractTypeName}}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.renewContractType'"
                          :rules="contractForm.rules.renewContractType"
                        >
                          <el-select
                            v-model="scope.row.renewContractType"
                            placeholder="请选择"
                            size="mini"
                            clearable
                            @change="changeRenewContractType(scope.row.renewContractType,scope.$index)"
                          >
                            <el-option
                              v-for="item in renewContractTypeOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column label="合同时间" min-width="270px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.contractStartDate">
                          <span>{{scope.row.contractStartDate }}---{{scope.row.contractEndDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item>
                          <el-date-picker
                            v-model="scope.row.contractDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            format="yyyy-MM-dd"
                            unlink-panels
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            @change="changeContractDatePicker(scope.$index)"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column label="试用期时间" min-width="270px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.probationStartDate">
                          <span>{{scope.row.probationStartDate }}---{{scope.row.probationEndDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item>
                          <el-date-picker
                            v-model="scope.row.contractProbationDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            format="yyyy-MM-dd"
                            unlink-panels
                            type="daterange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            @change="changeContractProbationtDatePicker(scope.$index)"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="quitDate" label="离职日期" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.quitDate }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.quitDate'">
                          <el-date-picker
                            v-model="scope.row.quitDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择日期"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="quitReason" label="离职原因" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.quitReasonName">
                          <span>{{ scope.row.quitReasonName }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.quitReason'">
                          <el-select
                            v-model="scope.row.quitReason"
                            size="mini"
                            placeholder="请选择"
                            clearable
                            @change="changeQuitReason(scope.row.quitReason,scope.$index)"
                          >
                            <el-option
                              v-for="item in quitReasonOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contractUrl" label="附件" min-width="300px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.contList&&scope.row.contList.length>0">
                          <el-col v-for="(item,index) of scope.row.contList" :key="index">
                            <el-link
                              :href="item.url"
                              type="primary"
                              :underline="false"
                              target="_blank"
                            >
                              {{item.name}}
                              <i class="el-icon-view"></i>
                            </el-link>
                          </el-col>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.contractUrl'">
                          <table-upload
                            size="mini"
                            :multiple="false"
                            :limit="10"
                            :action="actionUrl"
                            :indexLine="scope.$index"
                            :file-list="scope.row.contList"
                            @handleGetUrl="getContractUrl"
                            @handleRemoveList="removeContractUrl"
                          ></table-upload>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="remark" label="备注" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.remark }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.remark'"
                          :rules="contractForm.rules.remark"
                        >
                          <el-input
                            v-model="scope.row.remark"
                            size="mini"
                            placeholder="请输入备注"
                            maxlength="100"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditContractForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveContractForm(scope.$index, scope.row, 'contractForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeleteContractForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <!-- <div class="margin-left-form" id="educationForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">教育情况</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addEducationForm('educationForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="educationForm.rules" :model="educationForm" ref="educationForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="educationForm.tableData"
                  v-loading="educationListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="startDate" label="开始时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.startDate">
                          <span>{{ scope.row.startDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.startDate'"
                          :rules="educationForm.rules.startDate"
                        >
                          <el-date-picker
                            v-model="scope.row.startDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="endDate" label="结束时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.endDate">
                          <span>{{ scope.row.endDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.endDate'"
                          :rules="educationForm.rules.endDate"
                        >
                          <el-date-picker
                            v-model="scope.row.endDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="schoolName" label="学校" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.schoolName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.schoolName'"
                          :rules="educationForm.rules.schoolName"
                        >
                          <el-input v-model="scope.row.schoolName" size="mini" placeholder="请输入学校"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="major" label="专业" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.major }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.major'"
                          :rules="educationForm.rules.major"
                        >
                          <el-input v-model="scope.row.major" size="mini" placeholder="请输入专业"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateName" label="证书" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.certificateName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.certificateName'"
                          :rules="educationForm.rules.certificateName"
                        >
                          <el-input
                            v-model="scope.row.certificateName"
                            size="mini"
                            placeholder="请输入证书"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateUrl" label="证书上传" min-width="200px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.urlList&&scope.row.urlList.length>0">
                          <el-col v-for="(item,index) of scope.row.urlList" :key="index">
                            <el-link
                              :href="item.url"
                              type="primary"
                              :underline="false"
                              target="_blank"
                            >
                              {{item.name}}
                              <i class="el-icon-view"></i>
                            </el-link>
                          </el-col>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateUrl'">
                          <table-upload
                            size="mini"
                            :multiple="false"
                            :limit="10"
                            :action="actionUrl"
                            :indexLine="scope.$index"
                            :file-list="scope.row.urlList"
                            @handleGetUrl="getCertificateUrl"
                            @handleRemoveList="removeCertificateUrl"
                          ></table-upload>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditEducationForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveEducationForm(scope.$index, scope.row, 'educationForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeleteEducationForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div> -->
        <!-- <div class="margin-left-form" id="workExpForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">工作经历</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addWorkExpForm('workExpForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="workExpForm.rules" :model="workExpForm" ref="workExpForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="workExpForm.tableData"
                  v-loading="workExpListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="startDate" label="开始时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.startDate">
                          <span>{{ scope.row.startDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.startDate'"
                          :rules="workExpForm.rules.startDate"
                        >
                          <el-date-picker
                            v-model="scope.row.startDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="endDate" label="结束时间" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.endDate">
                          <span>{{ scope.row.endDate }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.endDate'"
                          :rules="workExpForm.rules.endDate"
                        >
                          <el-date-picker
                            v-model="scope.row.endDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="companyName" label="工作单位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.companyName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.companyName'"
                          :rules="workExpForm.rules.companyName"
                        >
                          <el-input
                            v-model="scope.row.companyName"
                            size="mini"
                            placeholder="请输入工作单位"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="lastPosition" label="最后职位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.lastPosition }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.lastPosition'"
                          :rules="workExpForm.rules.lastPosition"
                        >
                          <el-input
                            v-model="scope.row.lastPosition"
                            size="mini"
                            placeholder="请输入最后职位"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="salary" label="薪水" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.salary }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.salary'"
                          :rules="workExpForm.rules.salary"
                        >
                          <el-input v-model="scope.row.salary" size="mini" placeholder="请输入薪水"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="leaveReason" label="离职原因" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.leaveReason }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.leaveReason'"
                          :rules="workExpForm.rules.leaveReason"
                        >
                          <el-input
                            v-model="scope.row.leaveReason"
                            size="mini"
                            placeholder="请输入离职原因"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="workEmployer" label="工作证明人" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.workEmployer }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.workEmployer'">
                          <el-input
                            v-model="scope.row.workEmployer"
                            size="mini"
                            placeholder="请输入工作证明人"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="relationship" label="与本人关系" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.relationship }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.relationship'">
                          <el-input
                            v-model="scope.row.relationship"
                            size="mini"
                            placeholder="请输入与本人关系"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contactsTel" label="联系方式" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.contactsTel }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.contactsTel'"
                          :rules="workExpForm.rules.contactsTel"
                        >
                          <el-input
                            v-model="scope.row.contactsTel"
                            size="mini"
                            placeholder="请输入联系方式"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="workYears" label="服务年限" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.workYearsValue">
                          <span>{{scope.row.workYearsValue}}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.workYears'"
                          :rules="workExpForm.rules.workYears"
                        >
                          <el-select
                            v-model="scope.row.workYears"
                            size="mini"
                            placeholder="请选择"
                            clearable
                            @change="changeWorkYears(scope.row.workYears,scope.$index)"
                          >
                            <el-option
                              v-for="item in workYearsOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="isProvideOneself" label="老人能否自理" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.isProvideOneselfValue">
                          <span>{{scope.row.isProvideOneselfValue}}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.isProvideOneself'"
                          :rules="workExpForm.rules.isProvideOneself"
                        >
                          <el-select
                            v-model="scope.row.isProvideOneself"
                            placeholder="请选择"
                            size="mini"
                            clearable
                            @change="changeIsProvideOneself(scope.row.isProvideOneself,scope.$index)"
                          >
                            <el-option
                              v-for="item in isProvideOneselfOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditWorkExpForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveWorkExpForm(scope.$index, scope.row, 'workExpForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeleteWorkExpForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div> -->
        <div class="margin-left-form" id="majorQualForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">专业资格或资质名称</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addMajorQualForm('majorQualForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form :rules="majorQualForm.rules" :model="majorQualForm" ref="majorQualForm">
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="majorQualForm.tableData"
                  v-loading="majorQualListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column
                    prop="professionalQualification"
                    label="专业资格或资质名称"
                    min-width="220px"
                  >
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.professionalQualification }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.professionalQualification'"
                          :rules="majorQualForm.rules.professionalQualification"
                        >
                          <el-input
                            v-model="scope.row.professionalQualification"
                            size="mini"
                            placeholder="请输入专业资格或资质名称"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateLevel" label="证书等级" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.certificateLevelValue">
                          <span>{{ scope.row.certificateLevelValue }}</span>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.certificateLevel'"
                          :rules="majorQualForm.rules.certificateLevel"
                        >
                          <el-select
                            v-model="scope.row.certificateLevel"
                            placeholder="请选择"
                            size="mini"
                            clearable
                            @change="changeCertificateLevel(scope.row.certificateLevel,scope.$index)"
                          >
                            <el-option
                              v-for="item in certificateLevelOptions"
                              :key="item.value"
                              :label="item.name"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="issueAuthority" label="颁发机构" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.issueAuthority }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.issueAuthority'"
                          :rules="majorQualForm.rules.issueAuthority"
                        >
                          <el-input
                            v-model="scope.row.issueAuthority"
                            size="mini"
                            placeholder="请输入颁发机构"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="issueDate" label="颁发日期" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.issueDate }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.issueDate'"
                          :rules="majorQualForm.rules.issueDate"
                        >
                          <el-date-picker
                            v-model="scope.row.issueDate"
                            size="mini"
                            value-format="yyyy-MM-dd"
                            type="date"
                            placeholder="选择时间"
                          ></el-date-picker>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="remark" label="备注" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.remark }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.remark'">
                          <el-input
                            v-model="scope.row.remark"
                            size="mini"
                            placeholder="请输入备注"
                            maxlength="100"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="certificateUrl" label="证书文件" min-width="300px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span v-if="scope.row.certList&&scope.row.certList.length>0">
                          <el-col v-for="(item,index) of scope.row.certList" :key="index">
                            <el-link
                              :href="item.url"
                              type="primary"
                              :underline="false"
                              target="_blank"
                            >
                              {{item.name}}
                              <i class="el-icon-view"></i>
                            </el-link>
                          </el-col>
                        </span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.certificateUrl'">
                          <table-upload
                            size="mini"
                            :multiple="false"
                            :limit="10"
                            :action="actionUrl"
                            :indexLine="scope.$index"
                            :file-list="scope.row.certList"
                            @handleGetUrl="getMajorCertificateUrl"
                            @handleRemoveList="removeMajorCertificateUrl"
                          ></table-upload>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditMajorQualForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveMajorQualForm(scope.$index, scope.row, 'majorQualForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeleteMajorQualForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div>
        <!-- <div class="margin-left-form" id="familyStatusForm">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">家庭状况</span>
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-plus"
                class="rightBtn"
                @click="addFamilyStatusForm('familyStatusForm')"
              >新增</el-button>
            </el-col>
          </el-row>
          <el-row>
            <div class="tablePadding">
              <el-form
                :rules="familyStatusForm.rules"
                :model="familyStatusForm"
                ref="familyStatusForm"
              >
                <el-table
                  :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                  size="mini"
                  stripe
                  :data="familyStatusForm.tableData"
                  v-loading="familyStatusListLoading"
                  highlight-current-row
                  element-loading-text="拼命加载中"
                  class="tableMain"
                >
                  <el-table-column prop="familyMemberName" label="姓名" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.familyMemberName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item
                          :prop="'tableData.' + scope.$index + '.familyMemberName'"
                          :rules="familyStatusForm.rules.familyMemberName"
                        >
                          <el-input
                            v-model="scope.row.familyMemberName"
                            size="mini"
                            placeholder="请输入姓名"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="relationship" label="关系" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.relationship }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.relationship'">
                          <el-input
                            v-model="scope.row.relationship"
                            size="mini"
                            placeholder="请输入关系"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="contactsTel" label="联系电话" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.contactsTel }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.contactsTel'">
                          <el-input
                            v-model="scope.row.contactsTel"
                            size="mini"
                            placeholder="请输入联系电话"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="companyName" label="工作单位" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.companyName }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.companyName'">
                          <el-input
                            v-model="scope.row.companyName"
                            size="mini"
                            placeholder="请输入工作单位"
                          ></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="position" label="职务" min-width="220px">
                    <template slot-scope="scope">
                      <div v-if="!scope.row.editing">
                        <span>{{ scope.row.position }}</span>
                      </div>
                      <div v-else>
                        <el-form-item :prop="'tableData.' + scope.$index + '.position'">
                          <el-input v-model="scope.row.position" size="mini" placeholder="请输入职务"></el-input>
                        </el-form-item>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column fixed="right" width="200px" label="操作">
                    <template slot-scope="scope">
                      <div class="operate-groups">
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="!scope.row.editing"
                          icon="el-icon-edit-outline"
                          @click="handleEditFamilyStatusForm(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                          type="primary"
                          size="mini"
                          v-if="scope.row.editing"
                          icon="el-icon-success"
                          @click="handleSaveFamilyStatusForm(scope.$index, scope.row, 'familyStatusForm')"
                        >保存</el-button>
                        <el-button
                          size="mini"
                          type="danger"
                          icon="el-icon-delete"
                          @click="handleDeleteFamilyStatusForm(scope.$index, scope.row)"
                        >删除</el-button>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-form>
            </div>
          </el-row>
        </div> -->

        <!-- 查看详情操作弹窗 -->
        <el-dialog title="人脸识别结果" :visible.sync="faceModal">
          <el-table
            :header-cell-style="{background:'#FAFAFA',color:'#606266'}"
            stripe
            :data="checkInfo"
            highlight-current-row
            element-loading-text="拼命加载中"
            style="width: 700px;"
          >
            <el-table-column prop="checkItem" label="查询项目" width="400"></el-table-column>
            <el-table-column prop="checkResult" label="核查结果" width="150"></el-table-column>
            <el-table-column prop="checkStatus" label="核查状态" width="150">
              <template slot-scope="scope">
                <span v-if="scope.row.checkStatus =='1'">
                  <i class="el-icon-success i-success"></i>
                </span>
                <span v-else-if="scope.row.checkStatus =='2'">
                  <i class="el-icon-warning i-warning"></i>
                </span>
                <span v-else-if="scope.row.checkStatus =='3'">
                  <i class="el-icon-remove i-remove"></i>
                </span>
                <span v-else-if="scope.row.checkStatus =='4'">
                  <i class="el-icon-error i-error"></i>
                </span>
              </template>
            </el-table-column>
          </el-table>
          <el-table
            :header-cell-style="{background:'#FAFAFA',color:'#606266'}"
            :data="reportInfo"
            style="width: 100%"
          >
            <el-table-column prop="queryDate" label="查询日期" width="250"></el-table-column>
            <el-table-column prop="pdfUrl" label="查询详情" align="right">
              <template slot-scope="scope">
                <span v-if="scope.row.pdfUrl != ''">
                  <el-button size="text" @click="handleSee(scope.row.pdfUrl)">查看详情</el-button>
                </span>
              </template>
            </el-table-column>
          </el-table>
          <el-row style="padding:10px;line-height:35px;color:#9B9C9E">
            <span style="font-weight:bold;">备注:</span>
            <el-col>
              <i class="el-icon-success i-success"></i> 代表调查项目结果“属实”，无风险
            </el-col>
            <el-col>
              <i class="el-icon-warning i-warning"></i> 代表调查项目结果“部分有差异或存在疑似风险”，属于中低等风险，建议适当关注
            </el-col>
            <el-col>
              <i class="el-icon-remove i-remove"></i> 代表调查项目无法评估风险，建议关注报告实际内容
            </el-col>
            <el-col>
              <i class="el-icon-error i-error"></i> 代表调查项目结果“存在较严重问题或虚假”，属于高等风险，建议务必关注
            </el-col>
          </el-row>
          <div style="text-align:center;padding:20px 0;">
            <el-button type="primary" @click="faceModal = false" style="width:150px;">确定</el-button>
          </div>
        </el-dialog>

        <el-dialog
          title="组织架构"
          :visible.sync="dialogVisible"
          width="50%"
          :before-close="handleClose"
        >
          <org-select v-on:listenTochildEvent="getCurrentNode"/>
        </el-dialog>

        <!-- 组织架构-弹窗 合同 -->
        <el-dialog
          title="组织架构"
          :visible.sync="dialogVisibleContract"
          width="50%"
          :before-close="handleCloseContract"
        >
          <org-select v-on:listenTochildEvent="getCurrentNodeContract"/>
        </el-dialog>

        <!-- 组织架构-弹窗 基本信息 -->
        <el-dialog
          title="组织架构"
          :visible.sync="dialogVisibleStaff"
          width="50%"
          :before-close="handleCloseStaff"
        >
          <org-select v-on:listenTochildEvent="getCurrentNodeStaff"/>
        </el-dialog>
      </div>
      <div class="main-right">
        <div id="nav-fixed" :class="{nav_fixed : isFixed}">
          <el-button type="text" @click="jump('staffForm')" icon="el-icon-s-opportunity" circle>基本信息</el-button>
          <br>
          <el-button
            type="text"
            @click="jump('postForm')"
            icon="el-icon-s-opportunity"
            circle
          >岗位管理</el-button>
          <br>
          <el-button
            type="text"
            @click="jump('gradeForm')"
            icon="el-icon-s-opportunity"
            circle
          >星级管理</el-button>
          <br>
          <el-button
            type="text"
            @click="jump('contractForm')"
            icon="el-icon-s-opportunity"
            circle
          >合同</el-button>
          <br>
          <!-- <el-button
            type="text"
            @click="jump('educationForm')"
            icon="el-icon-s-opportunity"
            circle
          >教育情况</el-button>
          <br> -->
          <!-- <el-button
            type="text"
            @click="jump('workExpForm')"
            icon="el-icon-s-opportunity"
            circle
          >工作经历</el-button> -->
          <el-button
            type="text"
            @click="jump('majorQualForm')"
            icon="el-icon-s-opportunity"
            circle
          >专业资格或资质名称</el-button>
          <br>
          <!-- <el-button
            type="text"
            @click="jump('familyStatusForm')"
            icon="el-icon-s-opportunity"
            circle
          >家庭状况</el-button>
          <br> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import TableUpload from "components/tableUpload";
import AddressAutocomplete from "components/AddressAutocomplete";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { getPartnerManagementList } from "api/partnerManagement/index.js";
import { getSurveyDetailByIdCard } from "api/recruitmentManagement/index.js";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  chineseName,
  validateBirthDay
} from "@/utils/validate";
import {
  findEhrStaffByCode,
  insertEhrStaff,
  editEhrStaff,
  findEhrPositionList,
  findEhrStaffPositionList,
  insertEhrStaffPosition,
  editEhrStaffPosition,
  getStaffContractList,
  insertStaffContract,
  editStaffContract,
  findStaffEducationList,
  insertStaffEducation,
  editStaffEducation,
  deleteStaffEducation,
  findStaffWorkExperienceList,
  insertStaffWorkExperience,
  editStaffWorkExperience,
  deleteStaffWorkExperience,
  findStaffProfessionalQualificationList,
  insertStaffProfessionalQualification,
  editStaffProfessionalQualification,
  deleteStaffProfessionalQualification,
  findStaffFamilyList,
  insertStaffFamily,
  editStaffFamily,
  deleteStaffFamily,
  checkRecruitIdCardExist,
  editEhrStaffPositionManageStatus,
  deleteEhrStaffPosition,
  addStaffGradeChangeRecord,
  findStaffGradeChangeRecordList,
  deleteStaffGradeChangeRecord
} from "api/customerManagement";
import { constants } from "fs";
export default {
  data() {
    return {
      tagName: "查看员工",
      //是否可编辑模式
      isEdit: false,
      //按钮加载
      loadingBtn: false,
      //保存/修改按钮的状态
      flag: false,
      //修改当前行
      currentIndex: 0,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      //星级禁用
      disabledGrade: true,
      showDate: false,
      /*
       *
       * 基本信息Form
       * 验证
       *
       *
       */
      probationDate: [],
      staffForm: {
        probationStartDate: "",
        probationEndDate: ""
      },
      //验证
      rules: {
        staffFullName: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        staffGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        entryDate: [
          {
            required: true,
            message: "请选择入职时间",
            trigger: "change"
          }
        ],
        staffTel: [
          {
            required: true,
            message: "请输入手机号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        positionName: [
          {
            required: true,
            message: "请选择岗位",
            trigger: "change"
          }
        ],
        idCard: [
          {
            required: true,
            message: "请输入身份证号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateIdCard 
          }
        ],
        idCardAddress: [
          {
            required: true,
            message: "请输入身份证地址",
            trigger: "blur"
          }
        ],
        staffBirthday: [
          {
            validator: validateBirthDay
          }
        ],
        liveProvinceName: [
          {
            required: true,
            message: "请输入现居住地址",
            trigger: "blur"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "blur"
          }
        ],
        staffEducation: [
          {
            required: true,
            message: "请选择最高学历",
            trigger: "change"
          }
        ],
        staffBelong: [
          {
            required: true,
            message: "请选择员工归属",
            trigger: "change"
          }
        ],
        positionType: [
          {
            required: true,
            message: "请选择岗位类型",
            trigger: "change"
          }
        ],
        formalSalary: [
          { validator: isMoney }
        ],
        formalDate: [
          {
            required: true,
            message: "请选择转正时间",
            trigger: "change"
          }
        ],
        probationSalary: [
          { validator: isMoney }
        ],
        probationStartDate: [
          {
            required: true,
            message: "请选择试用期时间",
            trigger: "input"
          }
        ],
        urgentContactsName: [
          {
            required: true,
            message: "请输入紧急联系人",
            trigger: "blur"
          }
        ],
        urgentContactsTel: [
          {
            required: true,
            message: "请输入紧急联系号码",
            trigger: "blur"
          },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        maritalStatus: [
          {
            required: true,
            message: "请选择婚姻状况",
            trigger: "change"
          }
        ],
        workStatus: [
          {
            required: true,
            message: "请选择在职状态",
            trigger: "change"
          }
        ],
        healthCertificateDate: [{ validator: validateBirthDay }]
      },
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载本市地址省市区
      liveOptions: [],
      live: [],
      liveName: [],
      //人脸识别弹窗
      faceModal: false,
      //岗位晋升
      promotionPosition: [],
      //合作商
      cooperations: [],
      //背调信息
      detailObj: {},
      //查看详情字段
      checkInfo: [
        {
          checkItem: "身份证实名信息校验",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "户籍信息",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "法院民事诉讼及失信记录查询",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "负面社会安全记录查询",
          checkResult: "",
          checkStatus: ""
        },
        {
          checkItem: "信贷逾期",
          checkResult: "",
          checkStatus: ""
        }
      ],
      reportInfo: [
        {
          queryDate: "",
          pdfUrl: ""
        }
      ],
      /*
       *
       * 岗位管理
       * 验证
       *
       *
       */
      postForm: {
        //验证
        rules: {
          orgName: [
            {
              required: true,
              message: "请选择入职组织",
              trigger: "change"
            }
          ],
          positionName: [
            {
              required: true,
              message: "请选择岗位",
              trigger: "change"
            }
          ],
          isDefault: [
            {
              required: true,
              message: "请选择是否默认岗位",
              trigger: "change"
            }
          ],
          isManager: [
            {
              required: true,
              message: "请选择是否是管理者",
              trigger: "change"
            }
          ]
        },
        tableData: []
      },
      //选择组织弹窗
      dialogVisible: false,
      //岗位选择
      position: [],
      //岗位列表加载
      postListLoading: false,
      /*
       *
       * 星级管理
       * 验证
       *
       *
       */
      gradeForm: {
        //验证
        rules: {
          staffGrade: [
            {
              required: true,
              message: "请选择星级",
              trigger: "change"
            }
          ],
          staffGradeEffectiveStartDate: [
            {
              required: true,
              message: "请选择生效开始日期",
              trigger: "change"
            }
          ]
        },
        tableData: []
      },
      //星级列表加载
      gradeListLoading: false,
      /**
       *
       * 合同
       *
       */
      contractForm: {
        //合同时间
        contractDate: [],
        //试用期时间
        contractProbationDate: [],
        //验证
        rules: {
          orgName: [
            {
              required: true,
              message: "请选择入职组织",
              trigger: "change"
            }
          ],
          contractType: [
            {
              required: true,
              message: "请选择合同类型",
              trigger: "change"
            }
          ]
        },
        tableData: []
      },
      //选择组织架构
      dialogVisibleContract: false,
      //选择组织基本信息
      dialogVisibleStaff: false,
      //加载员工合同列表
      contractListLoading: false,
      //附件上传
      contractFileList: [],
      /*
       *
       * 教育情况
       * 验证
       *
       *
       */
      educationForm: {
        //验证
        rules: {
          startDate: [
            {
              required: true,
              message: "请选择开始时间",
              trigger: "blur"
            }
          ],
          endDate: [
            {
              required: true,
              message: "请选择结束时间",
              trigger: "blur"
            }
          ],
          schoolName: [
            {
              required: true,
              message: "请输入学校",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      //证书上传
      certificateFileList: [],
      //加载教育情况列表
      educationListLoading: false,
      /*
       *
       * 工作经历
       * 验证
       *
       *
       */
      workExpForm: {
        //验证
        rules: {
          startDate: [
            {
              required: true,
              message: "请选择开始时间",
              trigger: "change"
            }
          ],
          endDate: [
            {
              required: true,
              message: "请选择结束时间",
              trigger: "change"
            }
          ],
          companyName: [
            {
              required: true,
              message: "请输入工作单位",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      workExpListLoading: false,
      /*
       *
       * 专业资格
       * 验证
       *
       *
       */
      majorQualForm: {
        //验证
        rules: {
          professionalQualification: [
            {
              required: true,
              message: "请输入专业资格或资质名称",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      majorCertificateFileList: [],
      //加载专业资格列表
      majorQualListLoading: false,
      /*
       *
       * 家庭状况
       * 验证
       *
       *
       */
      familyStatusForm: {
        //验证
        rules: {
          familyMemberName: [
            {
              required: true,
              message: "请输入姓名",
              trigger: "blur"
            }
          ],
          contactsTel: [
            {
              required: true,
              message: "请输入联系电话",
              trigger: "blur"
            }
          ]
        },
        tableData: []
      },
      familyStatusListLoading: false,
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      staffGenderOptions: [],
      //最高学历
      staffEducationOptions: [],
      //政治面貌
      staffPoliticalOptions: [],
      //电脑水平
      computerLevelOptions: [],
      //信仰
      staffFaithOptions: [],
      //婚姻生育情况
      maritalStatusOptions: [],
      //员工星级
      staffGradeOptions: [],
      //在职状态
      workStatusOptions: [],
      //在合作商岗位
      cooperationPositionOptions: [],
      //员工归属
      staffBelongOptions: [],
      //五险基金
      socialSecurityBaseOptions: [],
      //公积金基数
      housingFundBaseOptions: [],
      //合同类型
      contractTypeOptions: [],
      //续签类型
      renewContractTypeOptions: [],
      //离职原因
      quitReasonOptions: [],
      //岗位类型
      positionTypeOptions: [],
      //服务年限
      workYearsOptions: [],
      //老人能否自理
      isProvideOneselfOptions: [],
      //证书等级
      certificateLevelOptions: [],
      //试用期结算方式
      probationSalaryUnitOptions: [],
      //正式薪资结算方式
      formalSalaryUnitOptions: [],
      isFixed: false,
      offsetTop: 0,
      /**
       *
       * 页面传参
       *
       */
      staffCode: "",
      staffId: ""
    };
  },
  components: {
    HeadTag,
    OrgSelect,
    TableUpload,
    AddressAutocomplete
  },
  methods: {
    /**
     * 修改健康证到期日期输入
     */
    changeInputHCDate(event) {
      if (this.staffForm.healthCertificateDate.length > 0) {
        let newStr = this.staffForm.healthCertificateDate.substring(
          0,
          this.staffForm.healthCertificateDate.length - 1
        );
        this.staffForm.healthCertificateDate = newStr + "-";
      }
    },
    //验证身份证关联组织
    validatorIdCard(staff) {
      if (staff.idCard) {
        var params = {
          idCard: staff.idCard,
          staffCode: staff.staffCode
        };
        checkRecruitIdCardExist(params)
          .then(response => {
            if (response.data.statusCode == 200) {
            } else {
              this.$message.error("系统已存在");
              return false;
            }
          })
          .catch(error => {
            console.log("findEhrPositionList:" + error);
            return false;
          });
      }
    },
    /**
     *
     * 基本信息保存
     *
     */
    saveStaff(formName) {
      if (this.probationDate == null) {
        this.staffForm.probationStartDate = null;
        this.staffForm.probationEndDate = null;
      }
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$refs.liveAddress.$refs["addressForm"].validate(valid => {
            if (valid) {
              this.loadingBtn = true;
              if(this.staffForm.workStatus == '20') {
                if(!this.staffForm.quitDate) {
                  this.$message.error("请填写离职时间");
                  this.loadingBtn = false;
                  return false;
                }
              }
              if (this.staffForm.promotionPositionCode == "") {
                this.staffForm.promotionPositionName = "";
              }
              if (this.staffForm.cooperationCode == "") {
                this.staffForm.cooperationName = "";
              }
              // this.handleSavePostForm();
              editEhrStaff(this.staffForm)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    this.$message.success("修改成功");
                    this.findEhrStaffByCode(this.staffForm.staffCode);
                    //查询岗位信息
                    this.findEhrStaffPositionList(this.staffForm.staffCode);
                    this.findStaffGradeList(this.staffForm.staffCode);
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                  } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                  }
                })
                .catch(error => {
                  console.log("editEhrStaff:" + error);
                  this.loadingBtn = false;
                  return false;
                });
            } else {
              this.$message.error("请检查是否填写完整");
              return false;
            }
          });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    //查询员工详情
    findEhrStaffByCode(code) {
      var params = {
        staffCode: code
      };
      findEhrStaffByCode(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.staffForm = response.data.responseData;
            if (this.staffForm.quitDate) {
              this.staffForm.quitDate = changeYMD(this.staffForm.quitDate);
            }
            if (this.staffForm.formalDate) {
              this.staffForm.formalDate = changeYMD(this.staffForm.formalDate);
            }
            if (this.staffForm.promotionDate) {
              this.staffForm.promotionDate = changeYMD(
                this.staffForm.promotionDate
              );
            }
            // if (this.staffForm.staffGradeEvaluateDate) {
            //   this.staffForm.staffGradeEvaluateDate = changeYMD(
            //     this.staffForm.staffGradeEvaluateDate
            //   );
            // }
            if (this.staffForm.healthCertificateDate) {
              this.staffForm.healthCertificateDate = changeYMD(
                this.staffForm.healthCertificateDate
              );
            }
            if (this.staffForm.entryDate) {
              this.staffForm.entryDate = changeYMD(this.staffForm.entryDate);
            }
            if (this.staffForm.probationStartDate) {
              this.staffForm.probationStartDate = changeYMD(
                this.staffForm.probationStartDate
              );
            }else{
              this.staffForm.probationStartDate = "";
            }
            if (this.staffForm.probationEndDate) {
              this.staffForm.probationEndDate = changeYMD(
                this.staffForm.probationEndDate
              );
            }else{
              this.staffForm.probationEndDate = "";
            }
            if (this.staffForm.probationStartDate && this.staffForm.probationEndDate) {
              this.probationDate = [
                new Date(this.staffForm.probationStartDate),
                new Date(this.staffForm.probationEndDate)
              ];
            }else{
              this.probationDate = null
            }
            this.staffForm.backgroundCheckStatus = parseInt(
              this.staffForm.backgroundCheckStatus
            );
            this.staffForm.diseaseHistoryStatus = parseInt(
              this.staffForm.diseaseHistoryStatus
            );
            if(this.staffForm.staffGrade){
              this.disabledGrade = true;
              this.showDate = true;
              // this.staffForm.staffGradeEffectiveStartDate = changeYMD(
              //   this.staffForm.staffGradeEffectiveStartDate
              // )
            }
            // if (this.flag == true) {
            //   this.$refs[
            //     "houseList"
            //   ].inputValue = this.staffForm.houseDistrictName;
            //   if (this.staffForm.liveDistrictName) {
            //     this.$refs[
            //       "liveList"
            //     ].inputValue = this.staffForm.liveDistrictName;
            //   }
            // }
          }
        })
        .catch(error => {
          console.log("findEhrStaffByCode:" + error);
          return false;
        });
    },
    //加载户籍省市区
    selectedHouseProvinceListener(obj) {
      this.staffForm.houseProvinceName = obj.provinceName;
      this.staffForm.houseProvinceCode = obj.provinceCode;
      this.staffForm.houseCityName = "";
      this.staffForm.houseCityCode = "";
      this.staffForm.houseDistrictName = "";
      this.staffForm.houseDistrictCode = "";
    },
    selectedHouseCityListener(obj) {
      this.staffForm.houseCityName = obj.cityName;
      this.staffForm.houseCityCode = obj.cityCode;
      this.staffForm.houseDistrictName = "";
      this.staffForm.houseDistrictCode = "";
    },
    selectedHouseDistrictListener(obj) {
      this.staffForm.houseDistrictName = obj.districtName;
      this.staffForm.houseDistrictCode = obj.districtCode;
    },
    // getHouseNodes(val) {
    //   let idArea;
    //   let sizeArea;
    //   if (!val) {
    //     idArea = 0;
    //     sizeArea = 0;
    //   } else if (val.length === 1) {
    //     idArea = val[0];
    //     sizeArea = val.length; //一级
    //   } else if (val.length === 2) {
    //     idArea = val[1];
    //     sizeArea = val.length; //二级
    //   }
    //   let params = {
    //     pid: idArea
    //   };
    //   findAddressDictList(params).then(
    //     response => {
    //       let Items = response.data.responseData;
    //       if (sizeArea === 0) {
    //         this.houseOptions = Items.map((value, i) => {
    //           return {
    //             id: value.id,
    //             name: value.name,
    //             cities: []
    //           };
    //         });
    //       } else if (sizeArea === 1) {
    //         // 点击一级 加载二级 市
    //         this.houseOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             if (!value.cities.length) {
    //               value.cities = Items.map((value, i) => {
    //                 return {
    //                   id: value.id,
    //                   name: value.name,
    //                   cities: []
    //                 };
    //               });
    //             }
    //           }
    //         });
    //       } else if (sizeArea === 2) {
    //         // 点击二级 加载三级 区
    //         this.houseOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             value.cities.map((value, i) => {
    //               if (value.id === val[1]) {
    //                 if (!value.cities.length) {
    //                   Items.pop();
    //                   value.cities = Items.map((value, i) => {
    //                     return {
    //                       id: value.id,
    //                       name: value.name
    //                     };
    //                   });
    //                 }
    //               }
    //             });
    //           }
    //         });
    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }
    //   );
    // },
    // //户籍选择下拉框
    // handleExpandChangeHouse(val) {
    //   this.getHouseNodes(val);
    // },
    // //将户籍省市区注入到Form中
    // addHouseToForm(val) {
    //   this.house = val;
    //   this.houseName = this.$refs["houseList"].getCheckedNodes();
    //   this.staffForm.houseProvinceCode = this.house[0];
    //   this.staffForm.houseProvinceName = this.houseName[0].pathLabels[0];
    //   this.staffForm.houseCityCode = this.house[1];
    //   this.staffForm.houseCityName = this.houseName[0].pathLabels[1];
    //   this.staffForm.houseDistrictCode = this.house[2];
    //   this.staffForm.houseDistrictName = this.houseName[0].pathLabels[2];
    // },
    // changeHouse(val) {
    //   this.$refs["houseList"].presentText = "";
    //   if (!val) {
    //     this.$refs["houseList"].inputValue = this.staffForm.houseDistrictName;
    //     this.$refs["houseList"].presentText = this.staffForm.houseDistrictName;
    //   }
    // },
    //加载本市地址省市区
    selectedLiveProvinceListener(obj) {
      this.staffForm.liveProvinceName = obj.provinceName;
      this.staffForm.liveProvinceCode = obj.provinceCode;
      this.staffForm.liveCityName = "";
      this.staffForm.liveCityCode = "";
      this.staffForm.liveDistrictName = "";
      this.staffForm.liveDistrictCode = "";
    },
    selectedLiveCityListener(obj) {
      this.staffForm.liveCityName = obj.cityName;
      this.staffForm.liveCityCode = obj.cityCode;
      this.staffForm.liveDistrictName = "";
      this.staffForm.liveDistrictCode = "";
    },
    selectedLiveDistrictListener(obj) {
      this.staffForm.liveDistrictName = obj.districtName;
      this.staffForm.liveDistrictCode = obj.districtCode;
    },
    // getLiveNodes(val) {
    //   let idArea;
    //   let sizeArea;
    //   if (!val) {
    //     idArea = 0;
    //     sizeArea = 0;
    //   } else if (val.length === 1) {
    //     idArea = val[0];
    //     sizeArea = val.length; //一级
    //   } else if (val.length === 2) {
    //     idArea = val[1];
    //     sizeArea = val.length; //二级
    //   }
    //   let params = {
    //     pid: idArea
    //   };
    //   findAddressDictList(params).then(
    //     response => {
    //       let Items = response.data.responseData;
    //       if (sizeArea === 0) {
    //         this.liveOptions = Items.map((value, i) => {
    //           return {
    //             id: value.id,
    //             name: value.name,
    //             cities: []
    //           };
    //         });
    //       } else if (sizeArea === 1) {
    //         // 点击一级 加载二级 市
    //         this.liveOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             if (!value.cities.length) {
    //               value.cities = Items.map((value, i) => {
    //                 return {
    //                   id: value.id,
    //                   name: value.name,
    //                   cities: []
    //                 };
    //               });
    //             }
    //           }
    //         });
    //       } else if (sizeArea === 2) {
    //         // 点击二级 加载三级 区
    //         this.liveOptions.map((value, i) => {
    //           if (value.id === val[0]) {
    //             value.cities.map((value, i) => {
    //               if (value.id === val[1]) {
    //                 if (!value.cities.length) {
    //                   Items.pop();
    //                   value.cities = Items.map((value, i) => {
    //                     return {
    //                       id: value.id,
    //                       name: value.name
    //                     };
    //                   });
    //                 }
    //               }
    //             });
    //           }
    //         });
    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }
    //   );
    // },
    // //本市地址选择下拉框
    // handleExpandChangeLive(val) {
    //   this.getLiveNodes(val);
    // },
    // //将本市地址省市区注入到Form中
    // addLiveToForm(val) {
    //   this.live = val;
    //   this.liveName = this.$refs["liveList"].getCheckedNodes();
    //   this.staffForm.liveProvinceCode = this.live[0];
    //   this.staffForm.liveProvinceName = this.liveName[0].pathLabels[0];
    //   this.staffForm.liveCityCode = this.live[1];
    //   this.staffForm.liveCityName = this.liveName[0].pathLabels[1];
    //   this.staffForm.liveDistrictCode = this.live[2];
    //   this.staffForm.liveDistrictName = this.liveName[0].pathLabels[2];
    // },
    // changeLive(val) {
    //   this.$refs["liveList"].presentText = "";
    //   if (!val) {
    //     this.$refs["liveList"].inputValue = this.staffForm.liveDistrictName;
    //     this.$refs["liveList"].presentText = this.staffForm.liveDistrictName;
    //   }
    // },
    /**
     *
     * 模糊查询
     *
     */
    //晋升前岗位模糊查询
    selectPromotionPositionName(item) {
      if (item.value !== "无") {
        this.staffForm.promotionPositionName = item.value;
        this.staffForm.promotionPositionCode = item.code;
      } else {
        this.staffForm.promotionPositionName = "";
      }
    },
    removePromotionPositionCode() {
      if(!this.staffForm.promotionPositionCode) {
        this.staffForm.promotionPositionName = "";
      }
    },
    inputPromotionPositionName() {
      this.staffForm.promotionPositionCode = "";
    },
    queryPromotionPositionName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.promotionPosition = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.promotionPosition.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.promotionPosition;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //合作商模糊查询
    selectCooperationName(item) {
      if (item.value !== "无") {
        this.staffForm.cooperationCode = item.code;
        this.staffForm.cooperationName = item.value;
      } else {
        this.staffForm.cooperationName = "";
      }
    },
    removeCooperationCode() {
      if(!this.staffForm.cooperationCode) {
        this.staffForm.cooperationName = "";
      }
    },
    inputCooperationName() {
      this.staffForm.cooperationCode = "";
    },
    queryCooperationName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          cooperationName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          cooperationName: queryString
        };
      }
      getPartnerManagementList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.cooperations = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.cooperations.push({
                value: data[i].cooperationName,
                code: data[i].cooperationCode
              });
            }
            var results = this.cooperations;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //列表岗位模糊查询
    selectPositionName(item, index) {
      if (item.value !== "无") {
        this.postForm.tableData[index].positionCode = item.code;
        this.postForm.tableData[index].positionName = item.value;
      } else {
        this.postForm.tableData[index].positionName = "";
      }
    },
    removePositionCode(index) {
      if(!this.postForm.tableData[index].positionCode) {
        this.postForm.tableData[index].positionName = "";
      }
    },
    inputPostionName(index) {
      this.postForm.tableData[index].positionCode = "";
    },
    queryPositionName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.position = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.position.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.position;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 病史切换
     * 如果无则清空病史输入
     *
     */
    medicalChange(val) {
      if (val == 0) {
        this.staffForm.diseaseHistoryInfo = "";
      }
    },
    //获取试用期开始结束时间
    choiceDatePicker() {
      this.$nextTick(() => {
        this.staffForm.probationStartDate = this.probationDate[0];
        this.staffForm.probationEndDate = this.probationDate[1];
      });
    },
    //选择基本信息组织
    handleCloseStaff() {
      this.dialogVisibleStaff = false;
    },
    getCurrentNodeStaff(data) {
      this.staffForm.orgName = data.orgName;
      this.staffForm.orgCode = data.orgCode;
      this.handleCloseStaff();
    },
    openDialogStaff() {
      this.dialogVisibleStaff = true;
    },
    //基本信息岗位模糊查询
    selectStaffPositionName(item) {
      if (item.value !== "无") {
        this.staffForm.positionName = item.value;
        this.staffForm.positionCode = item.code;
        if(this.staffForm.positionName == "护理员") {
          this.staffForm.staffGrade = "20";
          this.showDate = true;
        } else{
          this.staffForm.staffGrade = "";
        }
      } else {
        this.staffForm.positionName = "";
        this.staffForm.staffGrade = "";
      }
    },
    removeStaffPositionCode() {
      if(!this.staffForm.positionCode) {
        this.staffForm.positionName = "";
      }
    },
    inputStaffPositionName() {
      this.staffForm.positionCode = "";
    },
    queryStaffPositionName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        positionName: queryString
      };
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.staffPosition = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.staffPosition.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.staffPosition;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 岗位管理列表操作
     *
     */
    // 查询当前岗位管理
    findEhrStaffPositionList(code) {
      var params = {
        staffCode: code
      };
      this.postListLoading = true;
      findEhrStaffPositionList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.postForm.tableData = response.data.responseData;
            var data = this.postForm.tableData;
            for (let i = 0; i < data.length; i++) {
              if (data[i].isManager == "1") {
                data[i].isManager = true;
              } else {
                data[i].isManager = false;
              }
            }
            this.postListLoading = false;
          } else {
            this.$message.error("岗位信息查询失败");
            this.postListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrStaffPositionList:" + error);
          this.postListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditPostForm($index, row) {
      this.$set(this.postForm.tableData[$index], "editing", true);
      this.postForm.tableData[$index].isManager =
        this.postForm.tableData[$index].isManager == 1 ? true : false;
    },
    // 保存
    handleSavePostForm($index, row, formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            var postData = this.postForm.tableData;
            if (postData.length > 0) {
              for (let l = 0; l < postData.length; l++) {
                if (postData[l].positionCode == "") {
                  postData[l].positionName = "";
                  this.$refs.postForm.validate(valid => {});
                  this.$message.error("输入的岗位不存在");
                  this.loadingBtn = false;
                  return false;
                }
              }
            }
            if (postData.length > 1) {
              for (let j = 1; j < postData.length; j++) {
                if (
                  postData[j].orgName + postData[j].positionName ==
                  postData[0].orgName + postData[0].positionName
                ) {
                  this.$message.error("存在相同组织岗位");
                  this.loadingBtn = false;
                  this.handleEditPostForm();
                  return false;
                }
              }
            }
            if (this.postForm.tableData[$index].id) {
              var params = {
                staffCode: this.staffForm.staffCode,
                id: this.postForm.tableData[$index].id,
                orgCode: this.postForm.tableData[$index].orgCode,
                orgName: this.postForm.tableData[$index].orgName,
                positionCode: this.postForm.tableData[$index].positionCode,
                positionName: this.postForm.tableData[$index].positionName,
                isDefault:
                  this.postForm.tableData[$index].isDefault == true ? "1" : "0",
                isManager:
                  this.postForm.tableData[$index].isManager == true ? "1" : "0"
              };
              editEhrStaffPosition(params)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    var currentData = response.data.responseData;
                    this.postForm.tableData[$index].id = currentData.id;
                    this.postForm.tableData[$index].staffCode =
                      currentData.staffCode;
                    this.postForm.tableData[$index].orgCode =
                      currentData.orgCode;
                    this.postForm.tableData[$index].orgName =
                      currentData.orgName;
                    this.postForm.tableData[$index].positionCode =
                      currentData.positionCode;
                    this.postForm.tableData[$index].positionName =
                      currentData.positionName;
                    this.postForm.tableData[$index].isDefault =
                      currentData.isDefault;
                    this.postForm.tableData[$index].isManager =
                      currentData.isManager;
                    this.$set(
                      this.postForm.tableData[$index],
                      "editing",
                      false
                    );
                    this.$message.success("保存成功");
                    this.findEhrStaffByCode(currentData.staffCode);
                    this.findEhrStaffPositionList(currentData.staffCode);
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("editEhrStaffPosition:" + error);
                  return false;
                });
            } else {
              var params = {
                staffCode: this.staffForm.staffCode,
                orgCode: this.postForm.tableData[$index].orgCode,
                orgName: this.postForm.tableData[$index].orgName,
                positionCode: this.postForm.tableData[$index].positionCode,
                positionName: this.postForm.tableData[$index].positionName,
                isDefault:
                  this.postForm.tableData[$index].isDefault == true ? "1" : "0",
                isManager:
                  this.postForm.tableData[$index].isManager == true ? "1" : "0"
              };
              insertEhrStaffPosition(params)
                .then(response => {
                  if (response.data.statusCode == 200) {
                    var currentData = response.data.responseData;
                    this.postForm.tableData[$index].id = currentData.id;
                    this.postForm.tableData[$index].staffCode =
                      currentData.staffCode;
                    this.postForm.tableData[$index].orgCode =
                      currentData.orgCode;
                    this.postForm.tableData[$index].orgName =
                      currentData.orgName;
                    this.postForm.tableData[$index].positionCode =
                      currentData.positionCode;
                    this.postForm.tableData[$index].positionName =
                      currentData.positionName;
                    this.postForm.tableData[$index].isDefault =
                      currentData.isDefault;
                    this.postForm.tableData[$index].isManager =
                      currentData.isManager;
                    this.$set(
                      this.postForm.tableData[$index],
                      "editing",
                      false
                    );
                    this.$message.success("保存成功");
                    this.findEhrStaffByCode(currentData.staffCode);
                    this.findEhrStaffPositionList(currentData.staffCode);
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertEhrStaffPosition:" + error);
                  return false;
                });
            }
          } else {
            this.$message.error("请检查是否填写完整");
            this.loadingBtn = false;
            return false;
          }
        });
      } else {
        this.$message.error("请检查是否填写完整");
        return false;
      }
    },
    // 新增一条岗位管理数据
    addPostForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.postForm.tableData = this.postForm.tableData || [];
            this.postForm.tableData.push({
              orgCode: null,
              orgName: null,
              positionCode: null,
              positionName: null,
              isDefault: 0,
              isManager: 0,
              status: 10,
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeletePostForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if(!this.postForm.tableData[$index].id){
            this.postForm.tableData.splice($index, 1);
            return;
          }
          var params = {
            staffCode: this.staffForm.staffCode,
            id: this.postForm.tableData[$index].id
          };
          deleteEhrStaffPosition(params)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.postForm.tableData.splice($index, 1);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("deleteEhrStaffPosition:" + error);
              return false;
            });
        })
        .catch(err => {
          return false;
        });
    },
    //修改岗位管理当前行组织权限
    handleChangeManageStatus($index, row) {
      var params = {
        staffCode: this.staffForm.staffCode,
        id: this.postForm.tableData[$index].id,
        isManager: this.postForm.tableData[$index].isManager == true ? "1" : "0"
      };
      editEhrStaffPositionManageStatus(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
          } else {
            console.log(this.postForm.tableData[$index].isManager);
          }
        })
        .catch(error => {
          console.log("editEhrStaffPositionManageStatus:" + error);
          return false;
        });
    },
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.postForm.tableData[this.currentIndex].orgName = data.orgName;
      this.postForm.tableData[this.currentIndex].orgCode = data.orgCode;
      this.handleClose();
    },
    openDialog($index) {
      this.currentIndex = $index;
      this.dialogVisible = true;
    },
    importFace(val) {
      let params = {
        idCard: val
      };
      getSurveyDetailByIdCard(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            if (response.data.responseData) {
              this.faceModal = true;
              this.detailObj = response.data.responseData;
              this.checkInfo[0].checkResult = this.detailObj.realNameResult;
              this.checkInfo[0].checkStatus = this.detailObj.realNameStatus;
              this.checkInfo[1].checkResult = this.detailObj.censusRegisterResult;
              this.checkInfo[1].checkStatus = this.detailObj.censusRegisterStatus;
              this.checkInfo[2].checkResult = this.detailObj.litigationResult;
              this.checkInfo[2].checkStatus = this.detailObj.litigationStatus;
              this.checkInfo[3].checkResult = this.detailObj.negativeRecordResult;
              this.checkInfo[3].checkStatus = this.detailObj.negativeRecordStatus;
              this.checkInfo[4].checkResult = this.detailObj.creditOverdueResult;
              this.checkInfo[4].checkStatus = this.detailObj.creditOverdueStatus;
              this.reportInfo[0].queryDate = this.detailObj.createDate;
              this.reportInfo[0].pdfUrl = this.detailObj.pdfUrl;
            } else {
              this.$message.error("暂无人脸识别信息");
              return false;
            }
          } else {
            this.$message.error("暂无人脸识别信息");
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
    //查看详情操作
    btnDetail() {
      this.importFace(this.staffForm.idCard);
    },
    handleSee(url) {
      window.open(url, "_blank");
    },
    /**
     *
     * 合同列表操作
     *
     */
    // 查询当前合同列表
    getStaffContractList(code) {
      var params = {
        staffCode: code
      };
      this.contractListLoading = true;
      getStaffContractList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.contractForm.tableData = response.data.responseData;
            if (this.contractForm.tableData.length > 0) {
              var arr = this.contractForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                this.$set(this.contractForm.tableData[i], "contList", []);
                if (arr[i].contractStartDate) {
                  arr[i].contractStartDate = changeYMD(
                    arr[i].contractStartDate
                  );
                  arr[i].contractEndDate = changeYMD(arr[i].contractEndDate);
                  this.$set(arr[i], "contractDate", [
                    new Date(arr[i].contractStartDate),
                    new Date(arr[i].contractEndDate)
                  ]);
                }
                if (arr[i].probationStartDate) {
                  arr[i].probationStartDate = changeYMD(
                    arr[i].probationStartDate
                  );
                  arr[i].probationEndDate = changeYMD(arr[i].probationEndDate);
                  this.$set(arr[i], "contractProbationDate", [
                    new Date(arr[i].probationStartDate),
                    new Date(arr[i].probationEndDate)
                  ]);
                }
                if (arr[i].quitDate) {
                  arr[i].quitDate = changeYMD(arr[i].quitDate);
                }
                if (arr[i].contractUrl) {
                  let obj = arr[i].contractUrl;
                  let temp = obj.split(",");
                  for (let j = 0; j < temp.length; j++) {
                    let url = temp[j];
                    this.contractForm.tableData[i].contList.push({
                      url: url,
                      name: decodeURI(url)
                        .toString()
                        .split("com/")[1]
                        .split("?Expires")[0]
                        .substr(18)
                    });
                  }
                }
              }
            }
            this.contractListLoading = false;
          } else {
            this.$message.error("岗位信息查询失败");
            console.log(response.data.statusMsg);
            this.contractListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("getStaffContractList:" + error);
          this.contractListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditContractForm($index, row) {
      this.$set(this.contractForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveContractForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.contractForm.tableData[$index].id) {
            var editContractForm = this.contractForm.tableData[$index];
            var params = {
              staffCode: this.staffCode,
              id: this.contractForm.tableData[$index].id,
              orgCode: this.contractForm.tableData[$index].orgCode,
              orgName: this.contractForm.tableData[$index].orgName,
              contractCode: this.contractForm.tableData[$index].contractCode,
              contractType: this.contractForm.tableData[$index].contractType,
              contractTypeName: this.contractForm.tableData[$index]
                .contractTypeName,
              renewContractType: this.contractForm.tableData[$index]
                .renewContractType,
              renewContractTypeName: this.contractForm.tableData[$index]
                .renewContractTypeName,
              contractStartDate:
                this.contractForm.tableData[$index].contractDate == null
                  ? ""
                  : this.contractForm.tableData[$index].contractDate[0],
              contractEndDate:
                this.contractForm.tableData[$index].contractDate == null
                  ? ""
                  : this.contractForm.tableData[$index].contractDate[1],
              probationStartDate:
                this.contractForm.tableData[$index].contractProbationDate ==
                null
                  ? ""
                  : this.contractForm.tableData[$index]
                      .contractProbationDate[0],
              probationEndDate:
                this.contractForm.tableData[$index].contractProbationDate ==
                null
                  ? ""
                  : this.contractForm.tableData[$index]
                      .contractProbationDate[1],
              quitDate: this.contractForm.tableData[$index].quitDate,
              quitReason: this.contractForm.tableData[$index].quitReason,
              quitReasonName: this.contractForm.tableData[$index]
                .quitReasonName,
              contractUrl: this.contractForm.tableData[$index].contractUrl,
              remark: this.contractForm.tableData[$index].remark,
              contractStatus: this.contractForm.tableData[$index].contractStatus
            };
            editStaffContract(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.contractForm.tableData[$index].id = currentData.id;
                  this.contractForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.contractForm.tableData[$index].orgCode =
                    currentData.orgCode;
                  this.contractForm.tableData[$index].orgName =
                    currentData.orgName;
                  this.contractForm.tableData[$index].contractCode =
                    currentData.contractCode;
                  this.contractForm.tableData[$index].contractType =
                    currentData.contractType;
                  this.contractForm.tableData[$index].contractTypeName =
                    currentData.contractTypeName;
                  this.contractForm.tableData[$index].renewContractType =
                    currentData.renewContractType;
                  this.contractForm.tableData[$index].renewContractTypeName =
                    currentData.renewContractTypeName;
                  this.contractForm.tableData[$index].contractStartDate =
                    currentData.contractStartDate == null
                      ? ""
                      : changeYMD(currentData.contractStartDate);
                  this.contractForm.tableData[$index].contractEndDate =
                    currentData.contractEndDate == null
                      ? ""
                      : changeYMD(currentData.contractEndDate);
                  if (currentData.contractStartDate) {
                    this.contractForm.tableData[$index].contractDate = [
                      changeYMD(currentData.contractStartDate),
                      changeYMD(currentData.contractEndDate)
                    ];
                  }
                  this.contractForm.tableData[$index].probationStartDate =
                    currentData.probationStartDate == null
                      ? ""
                      : changeYMD(currentData.probationStartDate);
                  this.contractForm.tableData[$index].probationEndDate =
                    currentData.probationEndDate == null
                      ? ""
                      : changeYMD(currentData.probationEndDate);
                  if (currentData.probationStartDate) {
                    this.contractForm.tableData[
                      $index
                    ].contractProbationDate = [
                      changeYMD(currentData.probationStartDate),
                      changeYMD(currentData.probationEndDate)
                    ];
                  }
                  this.contractForm.tableData[$index].quitDate =
                    currentData.quitDate;
                  this.contractForm.tableData[$index].quitReason =
                    currentData.quitReason;
                  this.contractForm.tableData[$index].quitReasonName =
                    currentData.quitReasonName;
                  this.contractForm.tableData[$index].contractUrl =
                    currentData.contractUrl;
                  this.contractForm.tableData[$index].remark =
                    currentData.remark;
                  this.contractForm.tableData[$index].contractStatus =
                    currentData.contractStatus;
                  this.contractForm.tableData[$index].editing = true;
                  this.$set(
                    this.contractForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffContract:" + error);
                return false;
              });
          } else {
            var params = {
              staffCode: this.staffCode,
              orgCode: this.contractForm.tableData[$index].orgCode,
              orgName: this.contractForm.tableData[$index].orgName,
              contractCode: this.contractForm.tableData[$index].contractCode,
              contractType: this.contractForm.tableData[$index].contractType,
              contractTypeName: this.contractForm.tableData[$index]
                .contractTypeName,
              renewContractType: this.contractForm.tableData[$index]
                .renewContractType,
              renewContractTypeName: this.contractForm.tableData[$index]
                .renewContractTypeName,
              contractStartDate:
                this.contractForm.tableData[$index].contractDate == null
                  ? ""
                  : this.contractForm.tableData[$index].contractDate[0],
              contractEndDate:
                this.contractForm.tableData[$index].contractDate == null
                  ? ""
                  : this.contractForm.tableData[$index].contractDate[1],
              probationStartDate:
                this.contractForm.tableData[$index].contractProbationDate ==
                null
                  ? ""
                  : this.contractForm.tableData[$index]
                      .contractProbationDate[0],
              probationEndDate:
                this.contractForm.tableData[$index].contractProbationDate ==
                null
                  ? ""
                  : this.contractForm.tableData[$index]
                      .contractProbationDate[1],
              quitDate: this.contractForm.tableData[$index].quitDate,
              quitReason: this.contractForm.tableData[$index].quitReason,
              quitReasonName: this.contractForm.tableData[$index]
                .quitReasonName,
              contractUrl: this.contractForm.tableData[$index].contractUrl,
              remark: this.contractForm.tableData[$index].remark,
              contractStatus: this.contractForm.tableData[$index].contractStatus
            };
            insertStaffContract(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.contractForm.tableData[$index].id = currentData.id;
                  this.contractForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.contractForm.tableData[$index].orgCode =
                    currentData.orgCode;
                  this.contractForm.tableData[$index].orgName =
                    currentData.orgName;
                  this.contractForm.tableData[$index].contractCode =
                    currentData.contractCode;
                  this.contractForm.tableData[$index].contractType =
                    currentData.contractType;
                  this.contractForm.tableData[$index].contractTypeName =
                    currentData.contractTypeName;
                  this.contractForm.tableData[$index].renewContractType =
                    currentData.renewContractType;
                  this.contractForm.tableData[$index].renewContractTypeName =
                    currentData.renewContractTypeName;
                  this.contractForm.tableData[$index].contractStartDate =
                    currentData.contractStartDate == null
                      ? ""
                      : changeYMD(currentData.contractStartDate);
                  this.contractForm.tableData[$index].contractEndDate =
                    currentData.contractEndDate == null
                      ? ""
                      : changeYMD(currentData.contractEndDate);
                  if (currentData.contractStartDate) {
                    this.contractForm.tableData[$index].contractDate = [
                      changeYMD(currentData.contractStartDate),
                      changeYMD(currentData.contractEndDate)
                    ];
                  }
                  this.contractForm.tableData[$index].probationStartDate =
                    currentData.probationStartDate == null
                      ? ""
                      : changeYMD(currentData.probationStartDate);
                  this.contractForm.tableData[$index].probationEndDate =
                    currentData.probationEndDate == null
                      ? ""
                      : changeYMD(currentData.probationEndDate);
                  if (currentData.probationStartDate) {
                    this.contractForm.tableData[
                      $index
                    ].contractProbationDate = [
                      changeYMD(currentData.probationStartDate),
                      changeYMD(currentData.probationEndDate)
                    ];
                  }
                  this.contractForm.tableData[$index].quitDate =
                    currentData.quitDate;
                  this.contractForm.tableData[$index].quitReason =
                    currentData.quitReason;
                  this.contractForm.tableData[$index].quitReasonName =
                    currentData.quitReasonName;
                  this.contractForm.tableData[$index].contractUrl =
                    currentData.contractUrl;
                  this.contractForm.tableData[$index].remark =
                    currentData.remark;
                  this.contractForm.tableData[$index].contractStatus =
                    currentData.contractStatus;
                  this.contractForm.tableData[$index].editing = true;
                  this.$set(
                    this.contractForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertStaffContract:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条合同数据
    addContractForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            if (this.contractForm.tableData.length > 2) {
              this.$message.error("最多增加三条合同记录");
              return false;
            } else {
              this.contractForm.tableData = this.contractForm.tableData || [];
              this.contractForm.tableData.push({
                orgName: null,
                contractCode: null,
                contractType: null,
                renewContractType: null,
                contractStartDate: null,
                contractEndDate: null,
                probationStartDate: null,
                probationEndDate: null,
                quitDate: null,
                quitReason: null,
                contractUrl: null,
                remark: null,
                contractStatus: 10,
                contractDate: [],
                contList: [],
                contractProbationDate: [],
                editing: true
              });
            }
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteContractForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.contractForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.contractForm.tableData[$index].id,
              contractStatus: 40
            };
            editStaffContract(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.contractForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffContract:" + error);
                return false;
              });
          } else {
            this.contractForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //选择组织
    handleCloseContract() {
      this.dialogVisibleContract = false;
    },
    getCurrentNodeContract(data) {
      this.contractForm.tableData[this.currentIndex].orgName = data.orgName;
      this.contractForm.tableData[this.currentIndex].orgCode = data.orgCode;
      this.handleCloseContract();
    },
    openDialogContract($index) {
      this.currentIndex = $index;
      this.dialogVisibleContract = true;
    },
    //附件上传
    getContractUrl(response, file, fileList, index) {
      if (response) {
        this.contractForm.tableData[index].contList = [];
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let contractUrl = "";
        urls.forEach(items => {
          contractUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (contractUrl.length > 0) {
          contractUrl = contractUrl.substr(0, contractUrl.length - 1);
        }
        this.contractForm.tableData[index].contractUrl = contractUrl;
        //回显当前行文件
        let temp = contractUrl.split(",");
        console.log(temp, "9999");
        for (let i = 0; i < temp.length; i++) {
          let url = temp[i];
          this.contractForm.tableData[index].contList.push({
            url: url,
            name: decodeURI(url)
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18)
          });
        }
      }
    },
    //删除文件
    removeContractUrl(file, inputFileMainList, indexLine) {
      let urls = [];
      inputFileMainList.forEach(item => {
        if (item) {
          urls.push(item.url);
        }
      });
      let contractUrl = "";
      urls.forEach(url => {
        contractUrl += url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (contractUrl.length > 0) {
        contractUrl = contractUrl.substr(0, contractUrl.length - 1);
      }
      this.contractForm.tableData[indexLine].contractUrl = certificateUrl;
      //回显当前行文件
      this.contractForm.tableData[indexLine].contList = [];
      let temp = contractUrl.split(",");
      for (let i = 0; i < temp.length; i++) {
        let url = temp[i];
        this.contractForm.tableData[indexLine].contList.push({
          url: url,
          name: decodeURI(url)
            .toString()
            .split("com/")[1]
            .split("?Expires")[0]
            .substr(18)
        });
      }
    },
    //合同类型
    changeContractType(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.contractTypeOptions.find(item => {
        return item.value === val;
      });
      this.contractForm.tableData[this.currentIndex].contractType = obj.value;
      this.contractForm.tableData[this.currentIndex].contractTypeName =
        obj.name;
    },
    //续签类型
    changeRenewContractType(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.renewContractTypeOptions.find(item => {
        return item.value === val;
      });
      this.contractForm.tableData[this.currentIndex].renewContractType =
        obj.value;
      this.contractForm.tableData[this.currentIndex].renewContractTypeName =
        obj.name;
    },
    //离职原因
    changeQuitReason(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.quitReasonOptions.find(item => {
        return item.value === val;
      });
      this.contractForm.tableData[this.currentIndex].quitReason = obj.value;
      this.contractForm.tableData[this.currentIndex].quitReasonName = obj.name;
    },
    //选择合同时间
    changeContractDatePicker($index) {
      this.$nextTick(() => {
        this.contractForm.tableData[
          $index
        ].contractStartDate = this.contractForm.tableData[
          $index
        ].contractDate[0];
        this.contractForm.tableData[
          $index
        ].contractEndDate = this.contractForm.tableData[$index].contractDate[1];
      });
    },
    //选择试用期时间
    changeContractProbationtDatePicker($index) {
      this.$nextTick(() => {
        this.contractForm.tableData[
          $index
        ].probationStartDate = this.contractForm.tableData[
          $index
        ].contractProbationDate[0];
        this.contractForm.tableData[
          $index
        ].probationEndDate = this.contractForm.tableData[
          $index
        ].contractProbationDate[1];
      });
    },
    /**
     *
     * 教育情况列表操作
     *
     */
    // 查询教育情况列表
    findStaffEducationList(code) {
      var params = {
        staffCode: code
      };
      this.educationListLoading = true;
      findStaffEducationList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationForm.tableData = response.data.responseData;
            if (this.educationForm.tableData.length > 0) {
              var arr = this.educationForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                this.$set(this.educationForm.tableData[i], "urlList", []);

                arr[i].startDate = changeYMD(arr[i].startDate);
                arr[i].endDate = changeYMD(arr[i].endDate);
                if (arr[i].certificateUrl) {
                  let obj = arr[i].certificateUrl;
                  let temp = obj.split(",");
                  console.log(temp, "9999");
                  for (let j = 0; j < temp.length; j++) {
                    let url = temp[j];
                    this.educationForm.tableData[i].urlList.push({
                      url: url,
                      name: decodeURI(url)
                        .toString()
                        .split("com/")[1]
                        .split("?Expires")[0]
                        .substr(18)
                    });
                  }
                }
              }
            }
            this.educationListLoading = false;
          } else {
            this.$message.error("教育情况查询失败");
            console.log(response.data.statusMsg);
            this.educationListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffEducationList:" + error);
          this.educationListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditEducationForm($index, row) {
      this.$set(this.educationForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveEducationForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.educationForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.educationForm.tableData[$index].id,
              startDate: this.educationForm.tableData[$index].startDate,
              endDate: this.educationForm.tableData[$index].endDate,
              schoolName: this.educationForm.tableData[$index].schoolName,
              major: this.educationForm.tableData[$index].major,
              certificateName: this.educationForm.tableData[$index]
                .certificateName,
              certificateUrl: this.educationForm.tableData[$index]
                .certificateUrl
            };
            editStaffEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.educationForm.tableData[$index].id = currentData.id;
                  this.educationForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.educationForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.educationForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.educationForm.tableData[$index].schoolName =
                    currentData.schoolName;
                  this.educationForm.tableData[$index].major =
                    currentData.major;
                  this.educationForm.tableData[$index].certificateName =
                    currentData.certificateName;
                  this.educationForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.$set(
                    this.educationForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffEducation:" + error);
                return false;
              });
          } else {
            var params = {
              staffCode: this.staffCode,
              startDate: this.educationForm.tableData[$index].startDate,
              endDate: this.educationForm.tableData[$index].endDate,
              schoolName: this.educationForm.tableData[$index].schoolName,
              major: this.educationForm.tableData[$index].major,
              certificateName: this.educationForm.tableData[$index]
                .certificateName,
              certificateUrl: this.educationForm.tableData[$index]
                .certificateUrl
            };
            insertStaffEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.educationForm.tableData[$index].id = currentData.id;
                  this.educationForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.educationForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.educationForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.educationForm.tableData[$index].schoolName =
                    currentData.schoolName;
                  this.educationForm.tableData[$index].major =
                    currentData.major;
                  this.educationForm.tableData[$index].certificateName =
                    currentData.certificateName;
                  this.educationForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.$set(
                    this.educationForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertStaffEducation:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条教育情况数据
    addEducationForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.educationForm.tableData = this.educationForm.tableData || [];
            this.educationForm.tableData.push({
              startDate: null,
              endDate: null,
              schoolName: null,
              major: null,
              certificateName: null,
              certificateUrl: null,
              urlList: [],
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteEducationForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.educationForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.educationForm.tableData[$index].id
            };
            deleteStaffEducation(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.educationForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteStaffEducation:" + error);
                return false;
              });
          } else {
            this.educationForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //证书上传
    getCertificateUrl(response, file, fileList, index) {
      if (response) {
        this.educationForm.tableData[index].urlList = [];
        console.log(response, file, fileList);
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let certificateUrl = "";
        urls.forEach(items => {
          certificateUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (certificateUrl.length > 0) {
          certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
        }
        this.educationForm.tableData[index].certificateUrl = certificateUrl;
        //回显当前行文件
        let temp = certificateUrl.split(",");
        console.log(temp, "9999");
        for (let i = 0; i < temp.length; i++) {
          let url = temp[i];
          this.educationForm.tableData[index].urlList.push({
            url: url,
            name: decodeURI(url)
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18)
          });
        }
      }
    },
    //删除文件
    removeCertificateUrl(file, inputFileMainList, indexLine) {
      let urls = [];
      inputFileMainList.forEach(item => {
        if (item) {
          urls.push(item.url);
        }
      });
      let certificateUrl = "";
      urls.forEach(url => {
        certificateUrl += url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (certificateUrl.length > 0) {
        certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
      }
      this.educationForm.tableData[indexLine].certificateUrl = certificateUrl;
      //回显当前行文件
      this.educationForm.tableData[indexLine].urlList = [];
      let temp = certificateUrl.split(",");
      for (let i = 0; i < temp.length; i++) {
        let url = temp[i];
        this.educationForm.tableData[indexLine].urlList.push({
          url: url,
          name: decodeURI(url)
            .toString()
            .split("com/")[1]
            .split("?Expires")[0]
            .substr(18)
        });
      }
    },
    /**
     *
     * 工作经历列表操作
     *
     */
    // 查询工作经历列表
    findStaffWorkExperienceList(code) {
      var params = {
        staffCode: code
      };
      this.workExpListLoading = true;
      findStaffWorkExperienceList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.workExpForm.tableData = response.data.responseData;
            if (this.workExpForm.tableData.length > 0) {
              var arr = this.workExpForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                arr[i].startDate = changeYMD(arr[i].startDate);
                arr[i].endDate = changeYMD(arr[i].endDate);
              }
            }
            this.workExpListLoading = false;
          } else {
            this.$message.error("教育情况查询失败");
            console.log(response.data.statusMsg);
            this.workExpListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffWorkExperienceList:" + error);
          this.workExpListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditWorkExpForm($index, row) {
      this.$set(this.workExpForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveWorkExpForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.workExpForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.workExpForm.tableData[$index].id,
              startDate: this.workExpForm.tableData[$index].startDate,
              endDate: this.workExpForm.tableData[$index].endDate,
              companyName: this.workExpForm.tableData[$index].companyName,
              lastPosition: this.workExpForm.tableData[$index].lastPosition,
              salary: this.workExpForm.tableData[$index].salary,
              leaveReason: this.workExpForm.tableData[$index].leaveReason,
              workEmployer: this.workExpForm.tableData[$index].workEmployer,
              relationship: this.workExpForm.tableData[$index].relationship,
              contactsTel: this.workExpForm.tableData[$index].contactsTel,
              workYears: this.workExpForm.tableData[$index].workYears,
              workYearsValue: this.workExpForm.tableData[$index].workYearsValue,
              isProvideOneself: this.workExpForm.tableData[$index]
                .isProvideOneself,
              isProvideOneselfValue: this.workExpForm.tableData[$index]
                .isProvideOneselfValue
            };
            editStaffWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.workExpForm.tableData[$index].id = currentData.id;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.workExpForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.workExpForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.workExpForm.tableData[$index].lastPosition =
                    currentData.lastPosition;
                  this.workExpForm.tableData[$index].salary =
                    currentData.salary;
                  this.workExpForm.tableData[$index].leaveReason =
                    currentData.leaveReason;
                  this.workExpForm.tableData[$index].workEmployer =
                    currentData.workEmployer;
                  this.workExpForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.workExpForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].workYears =
                    currentData.workYears;
                  this.workExpForm.tableData[$index].workYearsValue =
                    currentData.workYearsValue;
                  this.workExpForm.tableData[$index].isProvideOneself =
                    currentData.isProvideOneself;
                  this.workExpForm.tableData[$index].isProvideOneselfValue =
                    currentData.isProvideOneselfValue;
                  this.$set(
                    this.workExpForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffWorkExperience:" + error);
                return false;
              });
          } else {
            var params = {
              staffCode: this.staffCode,
              startDate: this.workExpForm.tableData[$index].startDate,
              endDate: this.workExpForm.tableData[$index].endDate,
              companyName: this.workExpForm.tableData[$index].companyName,
              lastPosition: this.workExpForm.tableData[$index].lastPosition,
              salary: this.workExpForm.tableData[$index].salary,
              leaveReason: this.workExpForm.tableData[$index].leaveReason,
              workEmployer: this.workExpForm.tableData[$index].workEmployer,
              relationship: this.workExpForm.tableData[$index].relationship,
              contactsTel: this.workExpForm.tableData[$index].contactsTel,
              workYears: this.workExpForm.tableData[$index].workYears,
              workYearsValue: this.workExpForm.tableData[$index].workYearsValue,
              isProvideOneself: this.workExpForm.tableData[$index]
                .isProvideOneself,
              isProvideOneselfValue: this.workExpForm.tableData[$index]
                .isProvideOneselfValue
            };
            insertStaffWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.workExpForm.tableData[$index].id = currentData.id;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].startDate =
                    currentData.startDate;
                  this.workExpForm.tableData[$index].endDate =
                    currentData.endDate;
                  this.workExpForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.workExpForm.tableData[$index].lastPosition =
                    currentData.lastPosition;
                  this.workExpForm.tableData[$index].salary =
                    currentData.salary;
                  this.workExpForm.tableData[$index].leaveReason =
                    currentData.leaveReason;
                  this.workExpForm.tableData[$index].workEmployer =
                    currentData.workEmployer;
                  this.workExpForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.workExpForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.workExpForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.workExpForm.tableData[$index].workYears =
                    currentData.workYears;
                  this.workExpForm.tableData[$index].workYearsValue =
                    currentData.workYearsValue;
                  this.workExpForm.tableData[$index].isProvideOneself =
                    currentData.isProvideOneself;
                  this.workExpForm.tableData[$index].isProvideOneselfValue =
                    currentData.isProvideOneselfValue;
                  this.$set(
                    this.workExpForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertStaffWorkExperience:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条工作经历数据
    addWorkExpForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.workExpForm.tableData = this.workExpForm.tableData || [];
            this.workExpForm.tableData.push({
              startDate: null,
              endDate: null,
              companyName: null,
              lastPosition: null,
              salary: null,
              leaveReason: null,
              workEmployer: null,
              relationship: null,
              contactsTel: null,
              workYears: null,
              isProvideOneself: null,
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteWorkExpForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.workExpForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.workExpForm.tableData[$index].id
            };
            deleteStaffWorkExperience(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.workExpForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteStaffWorkExperience:" + error);
                return false;
              });
          } else {
            this.workExpForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //服务年限
    changeWorkYears(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.workYearsOptions.find(item => {
        return item.value === val;
      });
      this.workExpForm.tableData[this.currentIndex].workYears = obj.value;
      this.workExpForm.tableData[this.currentIndex].workYearsValue = obj.name;
    },
    //老人能否自理
    changeIsProvideOneself(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.isProvideOneselfOptions.find(item => {
        return item.value === val;
      });
      this.workExpForm.tableData[this.currentIndex].isProvideOneself =
        obj.value;
      this.workExpForm.tableData[this.currentIndex].isProvideOneselfValue =
        obj.name;
    },
    /**
     *
     * 专业资格列表操作
     *
     */
    // 查询专业资格列表
    findStaffProfessionalQualificationList(code) {
      var params = {
        staffCode: code
      };
      this.majorQualListLoading = true;
      findStaffProfessionalQualificationList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.majorQualForm.tableData = response.data.responseData;
            if (this.majorQualForm.tableData.length > 0) {
              var arr = this.majorQualForm.tableData;
              for (let i = 0; i < arr.length; i++) {
                this.$set(this.majorQualForm.tableData[i], "certList", []);
                if (arr[i].issueDate) {
                  arr[i].issueDate = changeYMD(arr[i].issueDate);
                }
                if (arr[i].certificateUrl) {
                  let obj = arr[i].certificateUrl;
                  let temp = obj.split(",");
                  for (let j = 0; j < temp.length; j++) {
                    let url = temp[j];
                    this.majorQualForm.tableData[i].certList.push({
                      url: url,
                      name: decodeURI(url)
                        .toString()
                        .split("com/")[1]
                        .split("?Expires")[0]
                        .substr(18)
                    });
                  }
                }
              }
            }
            this.majorQualListLoading = false;
          } else {
            this.$message.error("专业资格查询失败");
            console.log(response.data.statusMsg);
            this.majorQualListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffProfessionalQualificationList:" + error);
          this.majorQualListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditMajorQualForm($index, row) {
      this.$set(this.majorQualForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveMajorQualForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.majorQualForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.majorQualForm.tableData[$index].id,
              professionalQualification: this.majorQualForm.tableData[$index]
                .professionalQualification,
              issueAuthority: this.majorQualForm.tableData[$index]
                .issueAuthority,
              issueDate: this.majorQualForm.tableData[$index].issueDate,
              certificateLevel: this.majorQualForm.tableData[$index]
                .certificateLevel,
              certificateLevelValue: this.majorQualForm.tableData[$index]
                .certificateLevelValue,
              certificateUrl: this.majorQualForm.tableData[$index]
                .certificateUrl,
              remark: this.majorQualForm.tableData[$index].remark
            };
            editStaffProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.majorQualForm.tableData[$index].id = currentData.id;
                  this.majorQualForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.majorQualForm.tableData[
                    $index
                  ].professionalQualification =
                    currentData.professionalQualification;
                  this.majorQualForm.tableData[$index].issueAuthority =
                    currentData.issueAuthority;
                  this.majorQualForm.tableData[$index].issueDate =
                    currentData.issueDate;
                  this.majorQualForm.tableData[$index].certificateLevel =
                    currentData.certificateLevel;
                  this.majorQualForm.tableData[$index].certificateLevelValue =
                    currentData.certificateLevelValue;
                  this.majorQualForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.majorQualForm.tableData[$index].remark =
                    currentData.remark;
                  this.$set(
                    this.majorQualForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffProfessionalQualification:" + error);
                return false;
              });
          } else {
            var params = {
              staffCode: this.staffCode,
              professionalQualification: this.majorQualForm.tableData[$index]
                .professionalQualification,
              issueAuthority: this.majorQualForm.tableData[$index]
                .issueAuthority,
              issueDate: this.majorQualForm.tableData[$index].issueDate,
              certificateLevel: this.majorQualForm.tableData[$index]
                .certificateLevel,
              certificateLevelValue: this.majorQualForm.tableData[$index]
                .certificateLevelValue,
              certificateUrl: this.majorQualForm.tableData[$index]
                .certificateUrl,
              remark: this.majorQualForm.tableData[$index].remark
            };
            insertStaffProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.majorQualForm.tableData[$index].id = currentData.id;
                  this.majorQualForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.majorQualForm.tableData[
                    $index
                  ].professionalQualification =
                    currentData.professionalQualification;
                  this.majorQualForm.tableData[$index].issueAuthority =
                    currentData.issueAuthority;
                  this.majorQualForm.tableData[$index].issueDate =
                    currentData.issueDate;
                  this.majorQualForm.tableData[$index].certificateLevel =
                    currentData.certificateLevel;
                  this.majorQualForm.tableData[$index].certificateLevelValue =
                    currentData.certificateLevelValue;
                  this.majorQualForm.tableData[$index].certificateUrl =
                    currentData.certificateUrl;
                  this.majorQualForm.tableData[$index].remark =
                    currentData.remark;
                  this.$set(
                    this.majorQualForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertStaffProfessionalQualification:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条专业资格数据
    addMajorQualForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.majorQualForm.tableData = this.majorQualForm.tableData || [];
            this.majorQualForm.tableData.push({
              professionalQualification: null,
              issueAuthority: null,
              issueDate: null,
              certificateLevel: null,
              certificateUrl: null,
              remark: null,
              certList: [],
              editing: true
            });
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteMajorQualForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.majorQualForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.majorQualForm.tableData[$index].id
            };
            deleteStaffProfessionalQualification(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.majorQualForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteStaffProfessionalQualification:" + error);
                return false;
              });
          } else {
            this.majorQualForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    //证书上传
    getMajorCertificateUrl(response, file, fileList, index) {
      if (response) {
        this.majorQualForm.tableData[index].certList = [];
        console.log(response, file, fileList);
        let urls = [];
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
        });
        let certificateUrl = "";
        urls.forEach(items => {
          certificateUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (certificateUrl.length > 0) {
          certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
        }
        this.majorQualForm.tableData[index].certificateUrl = certificateUrl;
        //回显当前行文件
        let temp = certificateUrl.split(",");
        console.log(temp, "9999");
        for (let i = 0; i < temp.length; i++) {
          let url = temp[i];
          this.majorQualForm.tableData[index].certList.push({
            url: url,
            name: decodeURI(url)
              .toString()
              .split("com/")[1]
              .split("?Expires")[0]
              .substr(18)
          });
        }
      }
    },
    //删除文件
    removeMajorCertificateUrl(file, inputFileMainList, indexLine) {
      let urls = [];
      inputFileMainList.forEach(item => {
        if (item) {
          urls.push(item.url);
        }
      });
      let certificateUrl = "";
      urls.forEach(url => {
        certificateUrl += url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (certificateUrl.length > 0) {
        certificateUrl = certificateUrl.substr(0, certificateUrl.length - 1);
      }
      this.majorQualForm.tableData[indexLine].certificateUrl = certificateUrl;
      //回显当前行文件
      this.majorQualForm.tableData[indexLine].certList = [];
      let temp = certificateUrl.split(",");
      for (let i = 0; i < temp.length; i++) {
        let url = temp[i];
        this.majorQualForm.tableData[indexLine].certList.push({
          url: url,
          name: decodeURI(url)
            .toString()
            .split("com/")[1]
            .split("?Expires")[0]
            .substr(18)
        });
      }
    },
    //证书等级
    changeCertificateLevel(val, $index) {
      var obj = {};
      this.currentIndex = $index;
      obj = this.certificateLevelOptions.find(item => {
        return item.value === val;
      });
      this.majorQualForm.tableData[this.currentIndex].certificateLevel =
        obj.value;
      this.majorQualForm.tableData[this.currentIndex].certificateLevelValue =
        obj.name;
    },
    /**
     *
     * 家庭状况列表操作
     *
     */
    // 查询家庭状况列表
    findStaffFamilyList(code) {
      var params = {
        staffCode: code
      };
      this.familyStatusListLoading = true;
      findStaffFamilyList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.familyStatusForm.tableData = response.data.responseData;
            this.familyStatusListLoading = false;
          } else {
            this.$message.error("家庭关系查询失败");
            console.log(response.data.statusMsg);
            this.familyStatusListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffFamilyList:" + error);
          this.familyStatusListLoading = false;
          return false;
        });
    },
    // 编辑
    handleEditFamilyStatusForm($index, row) {
      this.$set(this.familyStatusForm.tableData[$index], "editing", true);
    },
    // 保存
    handleSaveFamilyStatusForm($index, row, formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.familyStatusForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.familyStatusForm.tableData[$index].id,
              familyMemberName: this.familyStatusForm.tableData[$index]
                .familyMemberName,
              relationship: this.familyStatusForm.tableData[$index]
                .relationship,
              companyName: this.familyStatusForm.tableData[$index].companyName,
              position: this.familyStatusForm.tableData[$index].position,
              contactsTel: this.familyStatusForm.tableData[$index].contactsTel
            };
            editStaffFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.familyStatusForm.tableData[$index].id = currentData.id;
                  this.familyStatusForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.familyStatusForm.tableData[$index].familyMemberName =
                    currentData.familyMemberName;
                  this.familyStatusForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.familyStatusForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.familyStatusForm.tableData[$index].position =
                    currentData.position;
                  this.familyStatusForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.$set(
                    this.familyStatusForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editStaffFamily:" + error);
                return false;
              });
          } else {
            var params = {
              staffCode: this.staffCode,
              familyMemberName: this.familyStatusForm.tableData[$index]
                .familyMemberName,
              relationship: this.familyStatusForm.tableData[$index]
                .relationship,
              companyName: this.familyStatusForm.tableData[$index].companyName,
              position: this.familyStatusForm.tableData[$index].position,
              contactsTel: this.familyStatusForm.tableData[$index].contactsTel
            };
            insertStaffFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.familyStatusForm.tableData[$index].id = currentData.id;
                  this.familyStatusForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.familyStatusForm.tableData[$index].familyMemberName =
                    currentData.familyMemberName;
                  this.familyStatusForm.tableData[$index].relationship =
                    currentData.relationship;
                  this.familyStatusForm.tableData[$index].companyName =
                    currentData.companyName;
                  this.familyStatusForm.tableData[$index].position =
                    currentData.position;
                  this.familyStatusForm.tableData[$index].contactsTel =
                    currentData.contactsTel;
                  this.$set(
                    this.familyStatusForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                } else {
                  this.$message.error("保存失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertStaffFamily:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    // 新增一条家庭状况数据
    addFamilyStatusForm(formName) {
      this.familyStatusForm.tableData = this.familyStatusForm.tableData || [];
      this.familyStatusForm.tableData.push({
        familyMemberName: null,
        relationship: null,
        companyName: null,
        position: null,
        contactsTel: null,
        editing: true
      });
    },
    // 删除
    handleDeleteFamilyStatusForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (this.familyStatusForm.tableData[$index].id) {
            var params = {
              staffCode: this.staffCode,
              id: this.familyStatusForm.tableData[$index].id
            };
            deleteStaffFamily(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.familyStatusForm.tableData.splice($index, 1);
                  this.$message.success("删除成功");
                } else {
                  this.$message.error("删除失败");
                  console.log(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteStaffFamily:" + error);
                return false;
              });
          } else {
            this.familyStatusForm.tableData.splice($index, 1);
            this.$message.success("删除成功");
          }
        })
        .catch(err => {
          return false;
        });
    },
    /**
     *
     * 星级管理列表操作
     *
     */
    // 查询星级管理列表
    findStaffGradeList(code) {
      var params = {
        staffCode: code
      };
      this.gradeListLoading = true;
      findStaffGradeChangeRecordList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.gradeForm.tableData = response.data.responseData;
            this.gradeListLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.gradeListLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffGradeChangeRecordList:" + error);
          this.gradeListLoading = false;
          return false;
        });
    },
    // 编辑
    // handleEditGradeForm($index, row) {
    //   this.$set(this.gradeForm.tableData[$index], "editing", true);
    // },
    // 保存
    handleSaveGradeForm($index, row, formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            var params = {
              staffCode: this.staffForm.staffCode,
              staffGrade: this.gradeForm.tableData[$index]
                .staffGrade,
              staffGradeEffectiveStartDate: this.gradeForm.tableData[$index]
                .staffGradeEffectiveStartDate,
              staffGradeEffectiveEndDate: this.gradeForm.tableData[$index]
                .staffGradeEffectiveEndDate,
              staffGradeEvaluateDate: this.gradeForm.tableData[$index].staffGradeEvaluateDate
            };
            addStaffGradeChangeRecord(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  var currentData = response.data.responseData;
                  this.gradeForm.tableData[$index].id = currentData.id;
                  this.gradeForm.tableData[$index].staffCode =
                    currentData.staffCode;
                  this.gradeForm.tableData[$index].staffGrade =
                    currentData.staffGrade;
                  this.gradeForm.tableData[$index].staffGradeValue =
                    currentData.staffGradeValue;
                  this.gradeForm.tableData[$index].staffGradeEffectiveStartDate =
                    currentData.staffGradeEffectiveStartDate;
                  this.gradeForm.tableData[$index].staffGradeEffectiveEndDate =
                    currentData.staffGradeEffectiveEndDate;
                  this.gradeForm.tableData[$index].staffGradeEvaluateDate =
                    currentData.staffGradeEvaluateDate;
                  this.$set(
                    this.gradeForm.tableData[$index],
                    "editing",
                    false
                  );
                  this.$message.success("保存成功");
                  this.findEhrStaffByCode(this.staffForm.staffCode);
                  this.findStaffGradeList(this.staffForm.staffCode);
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("addStaffGradeChangeRecord:" + error);
                return false;
              });
          } else {
            this.$message.error("请检查是否填写完整");
            return false;
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 新增一条家庭状况数据
    addGradeForm(formName) {
      if (this.staffForm.staffCode) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.gradeForm.tableData =
              this.gradeForm.tableData || [];
              var arr = [{
                staffGrade: null,
                staffGradeEffectiveStartDate: null,
                staffGradeEffectiveEndDate: null,
                staffGradeEvaluateDate: null,
                staffGradeEffectiveStatus: false,
                editing: true
            }]
            this.gradeForm.tableData=arr.concat(this.gradeForm.tableData)
          }
        });
      } else {
        this.$message.error("请先保存员工信息后再操作");
        return false;
      }
    },
    // 删除
    handleDeleteGradeForm($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        if (this.gradeForm.tableData[$index].id) {
          var params = {
            staffCode: this.staffForm.staffCode,
            id: this.gradeForm.tableData[$index].id,
            staffGradeEffectiveStartDate: this.gradeForm.tableData[$index].staffGradeEffectiveStartDate
          };
          deleteStaffGradeChangeRecord(params)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.gradeForm.tableData.splice($index, 1);
                this.$message.success("删除成功");
                this.findEhrStaffByCode(this.staffForm.staffCode);
                this.findStaffGradeList(this.staffForm.staffCode);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("deleteStaffGradeChangeRecord:" + error);
              return false;
            });
        } else {
          this.gradeForm.tableData.splice($index, 1);
          this.$message.success("删除成功");
        }
      })
      .catch(err => {
        return false;
      });
    },
    /**
     *
     * 锚点跳转
     *
     */
    jump(domId) {
      //获取头部是否固定
      let headerFlag = this.$store.state.settings.fixedHeader;

      // 当前窗口正中心位置到指定dom位置的距离

      //页面滚动了的距离
      let height =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      //指定dom到页面顶端的距离
      let dom = document.getElementById(domId);
      let domHeight;

      if (headerFlag) {
        domHeight = dom.offsetTop - 60;
      } else {
        domHeight = dom.offsetTop + 40;
      }

      //滚动距离计算
      var S = Number(height) - Number(domHeight);

      //判断上滚还是下滚
      if (S < 0) {
        //下滚
        S = Math.abs(S);
        window.scrollBy({ top: S, behavior: "smooth" });
      } else if (S == 0) {
        //不滚
        window.scrollBy({ top: 0, behavior: "smooth" });
      } else {
        //上滚
        S = -S;
        window.scrollBy({ top: S, behavior: "smooth" });
      }
    },
    // 滚动监听  滚动触发的效果写在这里
    handleScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop >= this.offsetTop) {
        this.isFixed = true;
      } else {
        this.isFixed = false;
      }
    },
    /**
     *
     * 返回员工管理列表
     *
     */
    returnCustomerList() {
      this.$router.push({
        path: "/personnelManagement/customerManagementList"
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaff() {
      this.isEdit = true;
      this.flag = true;
      this.findEhrStaffByCode(this.staffCode);
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGenderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EHR_EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffEducationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //政治面貌
      findValueBySetCode({ valueSetCode: "STAFF_POLITICAL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffPoliticalOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //电脑水平
      findValueBySetCode({ valueSetCode: "COMPUTER_LEVEL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.computerLevelOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //信仰
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffFaithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //婚姻状况
      findValueBySetCode({ valueSetCode: "STAFF_MARITAL_STATUS2" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.maritalStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //员工星级
      findValueBySetCode({ valueSetCode: "STAFF_GRADE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGradeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //在职状态
      findValueBySetCode({ valueSetCode: "WORK_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.workStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //员工归属
      findValueBySetCode({ valueSetCode: "STAFF_BELONG" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffBelongOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //五险基金
      findValueBySetCode({ valueSetCode: "SOCIAL_SECURITY_BASE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.socialSecurityBaseOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //公积金基数
      findValueBySetCode({ valueSetCode: "HOUSING_FUND_BASE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.housingFundBaseOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //合同类型
      findValueBySetCode({ valueSetCode: "CONTRACT_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.contractTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //续签类型
      findValueBySetCode({ valueSetCode: "RENEW_CONTRACT_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.renewContractTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //离职原因
      findValueBySetCode({ valueSetCode: "QUIR_REASON" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.quitReasonOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //岗位类型
      findValueBySetCode({ valueSetCode: "POSITION_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.positionTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务年限
      findValueBySetCode({ valueSetCode: "WORK_YEARS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.workYearsOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //老人能否自理
      findValueBySetCode({ valueSetCode: "IS_PROVIDE_ONESELF" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isProvideOneselfOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //证书等级
      findValueBySetCode({ valueSetCode: "CERTIFICATE_LEVEL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.certificateLevelOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //在合作商岗位
      findValueBySetCode({ valueSetCode: "COOPERATION_POSTS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.cooperationPositionOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //试用期结算方式
      findValueBySetCode({ valueSetCode: "SALARY_UNIT" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.probationSalaryUnitOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //正式薪资结算方式
      findValueBySetCode({ valueSetCode: "SALARY_UNIT" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.formalSalaryUnitOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {},
  mounted() {
    //获取传入的参数
    var param = this.$route.query;
    this.staffCode = param.staffCode;
    this.staffId = param.staffId;
    //初始化参数
    this.contractForm.tableData = [];
    this.educationForm.tableData = [];
    this.workExpForm.tableData = [];
    this.majorQualForm.tableData = [];
    this.familyStatusForm.tableData = [];
    this.gradeForm.tableData = [];
    //初始化查询员工信息
    this.findEhrStaffByCode(this.staffCode, this.staffId);
    //查询岗位信息
    this.findEhrStaffPositionList(this.staffCode);
    //查询合同列表
    this.getStaffContractList(this.staffCode);
    //查询教育情况
    this.findStaffEducationList(this.staffCode);
    //查询工作经历
    this.findStaffWorkExperienceList(this.staffCode);
    //查询专业资格
    this.findStaffProfessionalQualificationList(this.staffCode);
    //查询家庭关系
    this.findStaffFamilyList(this.staffCode);
    //员工星级
    this.findStaffGradeList(this.staffCode);
    //初始化数据字典
    this.initDataDictionary();
    // 设置bar浮动阈值为 #fixedBar 至页面顶部的距离
    this.offsetTop = document.querySelector("#nav-fixed").offsetTop;
    // 开启滚动监听
    window.addEventListener("scroll", this.handleScroll);
  },
  destroyed() {
    // 离开页面 关闭监听 不然会报错
    window.removeEventListener("scroll", this.handleScroll);
  }
};
</script>

<style lang="scss" scoped>
#customerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
  .form-content .el-form-item {
    margin-bottom: 15px;
  }
}

.main-content {
  width: 100%;
  display: flex;
  .tablePadding {
    padding: 0px 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    margin: 0px 20px;
  }
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.formTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.main-left {
  margin: 0px 0px 0px 20px;
  padding-right: 10px;
  width: calc(100% - 200px);
  float: left;
  min-width: 850px;
  .margin-left-form {
    border-radius: 10px;
    margin-bottom: 10px;
    padding-bottom: 20px;
    background: #fff;
  }
}
.main-right {
  margin: 0px 20px 0px 10px;
  padding: 10px;
  background: #fff;
  min-width: 200px;
  float: right;
  .vertical-steps {
    height: 500px;
  }
}
.nav_fixed {
  position: fixed;
  margin-top: 60px;
  min-width: 200px;
  z-index: 2;
  top: 0;
}
.i-success {
  color: #0c9905;
  font-size: 15px;
}

.i-warning {
  color: #ebcd25;
  font-size: 15px;
}

.i-remove {
  color: #878787;
  font-size: 15px;
}

.i-error {
  color: #f14848;
  font-size: 15px;
}
.remark-style {
  display: block;
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 400px;
  height: 50px;
}
</style>
<style lang="scss">
#customerManage {
  #nav-fixed .el-button:hover {
    color: #f98c3c;
  }
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .el-form-item__content .el-input-group {
    vertical-align: unset;
  }
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>
