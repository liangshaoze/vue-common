<template>
  <div id="customerManage">
    <headTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="115px">
        <el-row>
           <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filters.orgName"
                @focus="dialogVisible = true"
                @clear="clearStructure"
                placeholder="请选择组织"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="姓名" prop="staffFullName">
              <el-input size="mini" v-model.trim="filters.staffFullName" clearable placeholder="请输入姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="身份证号" prop="idCard">
              <el-input size="mini" v-model.trim="filters.idCard" clearable placeholder="请输入身份证号" maxlength="18"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="staffTel">
              <el-input size="mini" v-model.trim="filters.staffTel" clearable placeholder="请输入联系电话" maxlength="11"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="岗位" prop="positionName">
              <el-autocomplete
                :trigger-on-focus="true"
                v-model.trim="filters.positionName"
                size="mini"
                clearable
                :fetch-suggestions="queryPositionName"
                placeholder="请输入岗位"
                @select="selectPositionName"
                @input="removePositionCode"
              ></el-autocomplete>
            </el-form-item>
          </el-col>
            <el-col class="form-item">
            <el-form-item label="星级" prop="staffGrade">
              <el-select size="mini" v-model.trim="filters.staffGrade" clearable placeholder="请选择星级">
                <el-option
                  v-for="item in staffGradeOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="员工归属" prop="staffBelong">
              <el-select size="mini" v-model.trim="filters.staffBelong" clearable placeholder="请选择">
                <el-option
                  v-for="item in staffBelongOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
           <el-col class="form-item">
            <el-form-item label="在职状态" prop="workStatus">
              <el-select size="mini" v-model.trim="filters.workStatus" clearable placeholder="请选择状态">
                <el-option
                  v-for="item in workStatusOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
           <el-col class="form-item">
            <el-form-item label="背调状态" prop="backgroundCheckStatus">
              <el-select
                size="mini"
                v-model.trim="filters.backgroundCheckStatus"
                clearable
                placeholder="请选择"
              >
                <el-option
                  v-for="item in backgroundCheckStatusOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-items">
            <el-form-item label="离职时间" prop="quitStartDate">
              <el-date-picker
                v-model.trim="filters.quitStartDate"
                clearable
                size="mini"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="试用期开始时间" prop="probationStartDate">
              <el-date-picker
                v-model.trim="filters.probationStartDate"
                clearable
                size="mini"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="试用期结束时间" prop="probationStartDateS">
              <el-date-picker
                v-model.trim="filters.probationStartDateS"
                clearable
                size="mini"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item class="search_btn">
              <el-button
                v-if="showList.customer_list_search"
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getStaffs(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <!-- <el-button v-if="showList.customer_list_add" type="primary" icon="el-icon-plus" @click="insertStaffs()">新增</el-button>
          <el-button v-if="showList.customer_list_export" type="primary" @click="exportStaffs()">
            <span style="text-aligin:center">
              <img src="@/assets/img/export.png" style="width:15px;height:100%;margin-right:7px;" />导出
            </span>
          </el-button>-->
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="insertStaffs()">新增</el-button>
          <el-button size="mini" type="primary" icon="el-icon-upload" @click="exportStaffs()">导出</el-button>
        </el-col>
      </el-row>
      <!--列表-->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="staffs"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column label="员工编号" width="110" prop="staffCode"></el-table-column>
        <el-table-column label="姓名" min-width="60" prop="staffFullName"></el-table-column>
        <el-table-column label="性别" min-width="45" prop="staffGenderValue"></el-table-column>
        <el-table-column label="身份证号" width="150" prop="idCard"></el-table-column>
        <el-table-column label="联系电话" width="120" prop="staffTel"></el-table-column>
        <el-table-column label="入职组织" min-width="150" prop="orgName"></el-table-column>
        <el-table-column label="岗位" min-width="100" prop="positionName"></el-table-column>
        <el-table-column label="背调状态" min-width="70" prop="backgroundCheckStatusValue"></el-table-column>
        <el-table-column label="在职状态" min-width="70" prop="workStatusValue"></el-table-column>
        <el-table-column label="星级" min-width="45" prop="staffGradeValue"></el-table-column>
        <el-table-column label="试用期时间" width="180" prop="probationStartDate">
          <template slot-scope="scope">
            <span
              v-if="scope.row.probationStartDate"
            >{{scope.row.probationStartDate}}---{{scope.row.probationEndDate}}</span>
          </template>
        </el-table-column>
        <el-table-column label="离职时间" width="100" prop="quitDate"></el-table-column>
        <el-table-column label="员工归属" min-width="70" prop="staffBelongValue"></el-table-column>
        <el-table-column fixed="right" min-width="50" label="操作">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="handleSee(scope.row)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.page"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>

      <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
        <org-select v-on:listenTochildEvent="getCurrentNode"/>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import OrgSelect from "components/OrgSelect";
import { findValueBySetCode } from "api/common";
import {
  findStaffList,
  findEhrPositionList,
  exportStaffList
} from "api/customerManagement";
import { changeYMD } from "utils";
import { hasPermission } from "utils/button";

export default {
  data() {
    return {
      showList: {
        customer_list_search: true,
        customer_list_add: true,
        customer_list_export: true,
        customer_list_see: true
      },
      tagName: "员工管理",
      //控制弹窗
      dialogVisible: false,
      //控制查询按钮加载
      searchLoading: false,
      //条件查询
      filters: {
        staffFullName: "",
        idCard: "",
        quitStartDate: [],
        staffTel: "",
        orgCode: "",
        orgName: "",
        workStatus: "",
        probationStartDate: [],
        probationStartDateS: [],
        positionCode: "",
        positionName: "",
        staffGrade: "",
        backgroundCheckStatus: "",
        staffBelong: "",
        page: 1,
        pageSize: 10
      },
      staffs: [],
      totalCount: 0,
      listLoading: false,
      //岗位选择
      position: [],
      //在职状态
      workStatusOptions: [],
      //星级
      staffGradeOptions: [],
      //背调状态
      backgroundCheckStatusOptions: [],
      //员工归属
      staffBelongOptions: []
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getStaffs(val.page); //改变页码，重新渲染页面
    },
    //获取员工列表
    getStaffs(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        staffFullName: this.filters.staffFullName,
        idCard: this.filters.idCard,
        quitStartDate: (this.filters.quitStartDate && this.filters.quitStartDate.length > 0) ? (this.filters.quitStartDate[0]+" 00:00:00") : null,
        quitEndDate: (this.filters.quitStartDate && this.filters.quitStartDate.length > 0) ? (this.filters.quitStartDate[1]+" 23:59:59") : null,
        staffTel: this.filters.staffTel,
        orgCode: this.filters.orgCode,
        workStatus: this.filters.workStatus,
        probationStartDate: (this.filters.probationStartDate && this.filters.probationStartDate.length > 0) ? (this.filters.probationStartDate[0]+" 00:00:00") : null,
        probationEndDate: (this.filters.probationStartDate && this.filters.probationStartDate.length > 0) ? (this.filters.probationStartDate[1]+" 23:59:59") : null,
        probationStartDateS: (this.filters.probationStartDateS && this.filters.probationStartDateS.length > 0) ? (this.filters.probationStartDateS[0]+" 00:00:00") : null,
        probationEndDateS: (this.filters.probationStartDateS && this.filters.probationStartDateS.length > 0) ? (this.filters.probationStartDateS[1]+" 23:59:59") : null,
        positionCode: this.filters.positionCode,
        positionName: this.filters.positionName,
        staffGrade: this.filters.staffGrade,
        backgroundCheckStatus: this.filters.backgroundCheckStatus,
        staffBelong: this.filters.staffBelong
      };
      this.listLoading = true;
      this.searchLoading = true;
      findStaffList(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            if (response.data.responseData != undefined) {
              this.staffs = response.data.responseData;
              for (let i = 0; i < this.staffs.length; i++) {
                this.staffs[i].probationStartDate = changeYMD(
                  this.staffs[i].probationStartDate
                );
                this.staffs[i].probationEndDate = changeYMD(
                  this.staffs[i].probationEndDate
                );
                if (this.staffs[i].entryDate) {
                  this.staffs[i].entryDate = changeYMD(
                    this.staffs[i].entryDate
                  );
                }
                if (this.staffs[i].quitDate) {
                  this.staffs[i].quitDate = changeYMD(this.staffs[i].quitDate);
                }
              }
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          return false;
        });
    },
    //跳转新增员工页面
    insertStaffs() {
      this.$router.push({
        path: "/personnelManagement/addCustomerManagement"
      });
    },
    //查看员工详情
    handleSee(row) {
      this.$router.push({
        path: "/personnelManagement/updateCustomerManagement",
        query: {
          staffCode: row.staffCode,
          staffId: row.id
        }
      });
    },
    /**
     *
     * 模糊查询
     *
     */
    //晋升前岗位模糊查询
    selectPositionName(item) {
      if (item.value !== "无") {
        this.filters.positionName = item.value;
        this.filters.positionCode = item.code;
      } else {
        this.filters.positionName = "";
      }
    },
    removePositionCode() {
      this.filters.positionCode = "";
    },
    queryPositionName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          positionName: queryString
        };
      }
      findEhrPositionList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.position = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.position.push({
                value: data[i].positionName,
                code: data[i].positionCode
              });
            }
            var results = this.position;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 查询条件开窗选择组织
     *
     */
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.filters.orgName = data.orgName;
      this.filters.orgCode = data.orgCode;
      this.handleClose();
    },
    /**
     *
     * 员工列表导出
     *
     */
    /**
     * 导出
     */
    exportStaffs() {
      require.ensure([], () => {
        const { export_json_to_excel } = require("@/utils/Export2Excel");
        const tHeader = [
          "序号",
          "组织单元",
          "组织",
          "合同编号",
          "员工归属",
          "姓名",
          "岗位",
          "专业资格证书名称",
          "在职状态",
          "入职时间",
          "离职时间",
          "离职原因",
          "手机号",
          "性别",
          "民族",
          "身份证号码",
          "出生年月",
          "身份证地址",
          "籍贯",
          "现居住地址",
          "现居住详细地址",
          "最高学历",
          "紧急联系人",
          "紧急联系号码",
          "试用期开始日期",
          "试用期结束日期",
          "首签合同类型",
          "合同首签日期",
          "合同到期日期",
          "续签合同类型",
          "合同续签日期",
          "合同到期日期"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [
          "orderNum",
          "orgUnitName",
          "orgName",
          "contractCodes",
          "staffBelongValue",
          "staffFullName",
          "positionName",
          "professionalQualification",
          "workStatusValue",
          "entryDates",
          "quitDates",
          "quitReasons",
          "staffTel",
          "staffGenderValue",
          "staffNation",
          "idCard",
          "staffBirthday",
          "idCardAddress",
          "nativePlace",
          "liveAddress",
          "liveDetailAddress",
          "staffEducationValue",
          "urgentContactsName",
          "urgentContactsTel",
          "probationStartDates",
          "probationEndDates",
          "firstContractTypeValue",
          "firstContractStartDate",
          "firstContractEndDate",
          "renewContractTypeValue",
          "renewContractStartDate",
          "renewContractEndDate"
        ];
        // 上面的index、phone_Num、school_Name是tableData里对象的属性
        const params = {
          staffFullName: this.filters.staffFullName,
          idCard: this.filters.idCard,
          quitStartDate: (this.filters.quitStartDate && this.filters.quitStartDate.length > 0) ? (this.filters.quitStartDate[0]+" 00:00:00") : null,
          quitEndTime: (this.filters.quitStartDate && this.filters.quitStartDate.length > 0) ? (this.filters.quitStartDate[1]+" 23:59:59") : null, 
          staffTel: this.filters.staffTel,
          orgCode: this.filters.orgCode,
          workStatus: this.filters.workStatus,
          probationStartDate: (this.filters.probationStartDate && this.filters.probationStartDate.length > 0) ? (this.filters.probationStartDate[0]+" 00:00:00") : null,
          probationEndDate: (this.filters.probationStartDate && this.filters.probationStartDate.length > 0) ? (this.filters.probationStartDate[1]+" 23:59:59") : null, 
          probationStartDateS: (this.filters.probationStartDateS && this.filters.probationStartDateS.length > 0) ? (this.filters.probationStartDateS[0]+" 00:00:00") : null,
          probationEndDateS: (this.filters.probationStartDateS && this.filters.probationStartDateS.length > 0) ? (this.filters.probationStartDateS[1]+" 23:59:59") : null, 
          positionType: this.filters.positionType,
          staffGrade: this.filters.staffGrade,
          backgroundCheckStatus: this.filters.backgroundCheckStatus,
          staffBelong: this.filters.staffBelong
        };
        exportStaffList(params)
          .then(response => {
            const list = response.data.responseData; //把data里的tableData存到list
            if (list.length > 0) {
              const data = this.formatJson(filterVal, list);
              try {
                export_json_to_excel(tHeader, data, "员工信息列表");
              } catch (error) {
                this.$message.error("导出失败，请检查数据是否异常");
                return false;
              }
            } else {
              this.$message.error("暂无数据，无法导出Excel");
              return false;
            }
          })
          .catch(error => {
            console.log(error);
          });
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    clearStructure() {
      this.filters.orgCode = "";
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //在职状态
      findValueBySetCode({ valueSetCode: "WORK_STATUS" })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.workStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //员工星级
      findValueBySetCode({ valueSetCode: "STAFF_GRADE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffGradeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //员工归属
      findValueBySetCode({ valueSetCode: "STAFF_BELONG" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.staffBelongOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.backgroundCheckStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    /**
     *
     * 按钮权限
     *
     */
    buttonControl() {
      this.showList.customer_list_search = hasPermission(
        "customer_list_search"
      );
      this.showList.customer_list_add = hasPermission("customer_list_add");
      this.showList.customer_list_export = hasPermission(
        "customer_list_export"
      );
      this.showList.customer_list_see = hasPermission("customer_list_see");
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.getStaffs(1);
    }
  },
  created() {
    //初始化按钮权限
    // this.buttonControl()
    //初始化数据字典
    this.initDataDictionary();
  },
  mounted() {
    //初始化加载员工查询
    // this.getStaffs(1);
  },
  activated() {
    this.getStaffs(1);
  }
};
</script>

<style lang="scss" scoped>
#customerManage {
  width: 100%;
  min-width: 1350px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.form-items {
  width: 30%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 115px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
</style>
<style lang="scss">
#customerManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>
