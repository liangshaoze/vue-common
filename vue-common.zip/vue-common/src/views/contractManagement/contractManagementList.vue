<template>
  <div id="contractManage">
    <HeadTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filter" label-width="90px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filter.orgName"
                placeholder="请选择组织"
                @focus="dialogVisible=true"
                @clear="clearOrgCode"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
           <el-col class="form-item">
            <el-form-item label="姓名" prop="staffFullName">
              <el-input size="mini" v-model.trim="filter.staffFullName" clearable placeholder="请输入姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="staffTel">
              <el-input size="mini" v-model.trim="filter.staffTel" clearable placeholder="请输入联系电话" maxlength="11"></el-input>
            </el-form-item>
          </el-col> 
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="合同编号" prop="contractCode">
              <el-input size="mini" v-model.trim="filter.contractCode" clearable placeholder="请输入合同编号"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="合同类型" prop="contractType">
              <el-select
                size="mini"
                v-model.trim="filter.contractType"
                @change="changeContractType(filter.contractType)"
                clearable
                placeholder="请选择合同类型"
              >
                <el-option
                  v-for="item in contractList"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="续签类型" prop="renewContractType">
              <el-select
                size="mini"
                v-model.trim="filter.renewContractType"
                @change="changeRenewContract(filter.renewContractType)"
                clearable
                placeholder="请选择续签类型"
              >
                <el-option
                  v-for="item in renewalList"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="searchContract(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn"></el-row>
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        stripe
        :data="tableData"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column prop="contractCode" label="合同编号" min-width="100"></el-table-column>
        <el-table-column prop="orgName" label="组织" min-width="150"></el-table-column>
        <el-table-column prop="contractType" label="合同类型" min-width="100"></el-table-column>
        <el-table-column prop="renewContractType" label="续签类型" min-width="100"></el-table-column>
        <el-table-column prop="staffFullName" label="姓名" min-width="100"></el-table-column>
        <el-table-column prop="staffTel" label="联系电话" width="130"></el-table-column>
        <el-table-column label="合同时间" width="180">
          <template slot-scope="scope">
            <span v-if="scope.row.contractStartDate">
              <span>{{scope.row.contractStartDate}} --- {{scope.row.contractEndDate}}</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column label="试用期时间" width="180">
          <template slot-scope="scope">
            <span v-if="scope.row.probationStartDate">
              <span>{{scope.row.probationStartDate}} --- {{scope.row.probationEndDate}}</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="quitDate" label="离职时间" width="100"></el-table-column>
        <el-table-column prop="createDate" label="创建时间" width="100"></el-table-column>
      </el-table>

      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filter.pageNum"
          :limit.sync="filter.pageSize"
          @pagination="pageChange"
        />
      </el-row>
    </div>
    <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleClose">
      <org-select v-on:listenTochildEvent="getCurrentNode"/>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findContractManagementList } from "api/contractManagement";
import { findValueBySetCode } from "api/common";
import { changeYMD } from "utils";
import OrgSelect from "components/OrgSelect";

export default {
  data() {
    return {
      tagName: "合同管理",
      totalCount: 0,
      listLoading: false,
      dialogVisible: false,
      filter: {
        contractCode: "",
        orgCode: "",
        orgName: "",
        renewContractType: "",
        contractType: "",
        staffFullName: "",
        staffTel: "",
        pageNum: 1,
        pageSize: 10
      },
      //续约类型
      renewalList: [],
      //合同类型
      contractList: [],
      searchLoading: false,
      tabList: [],
      contractId: "",
      tableData: []
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    searchContract(page) {
      this.searchLoading = true;
      this.listLoading = true;
      this.filter.pageNum = page;
      findContractManagementList(this.filter)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            if (response.data.responseData != undefined) {
              this.tableData = response.data.responseData;
              this.tableData.forEach(item => {
                item.contractStartDate =
                  item.contractStartDate !== undefined
                    ? changeYMD(item.contractStartDate)
                    : "";
                item.contractEndDate =
                  item.contractEndDate !== undefined
                    ? changeYMD(item.contractEndDate)
                    : "";
                item.probationStartDate =
                  item.probationStartDate !== undefined
                    ? changeYMD(item.probationStartDate)
                    : "";
                item.probationEndDate =
                  item.probationEndDate !== undefined
                    ? changeYMD(item.probationEndDate)
                    : "";
                item.quitDate =
                  item.quitDate !== undefined ? changeYMD(item.quitDate) : "";
                item.createDate =
                  item.createDate !== undefined
                    ? changeYMD(item.createDate)
                    : "";
                return item;
              });
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findContractManagementList:" + error);
          return false;
        });
    },
    searchRenewalList() {
      findValueBySetCode({ valueSetCode: "RENEW_CONTRACT_TYPE" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.renewalList = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
        });
    },
    searchContractList() {
      findValueBySetCode({ valueSetCode: "CONTRACT_TYPE" })
        .then(response => {
          if (response.data.statusCode === "200") {
            this.contractList = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
        });
    },
    pageChange(val) {
      this.filter.pageNum = val.page;
      this.filter.pageSize = val.limit;
      this.searchContract(val.page); //改变页码，重新渲染页面
    },
    handleClose() {
      this.dialogVisible = false;
    },
    //获取组织
    getCurrentNode(data) {
      this.filter.orgName = data.orgName;
      this.filter.orgCode = data.orgCode;
      this.handleClose();
    },
    //清空组织过滤
    clearOrgCode() {
      this.filter.orgName = "";
      this.filter.orgCode = "";
    },
    //合同类型
    changeContractType(val) {
      var obj = {};
      obj = this.contractList.find(item => {
        return item.value === val;
      });
      this.filter.contractType = obj.value;
    },
    //续签类型
    changeRenewContractType(val) {
      var obj = {};
      obj = this.renewalList.find(item => {
        return item.value === val;
      });
      this.filter.renewContractType = obj.value;
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filter.orgCode = "";
      this.searchContract(1);
    }
  },
  created() {
    // this.searchContract(1);
    this.searchRenewalList();
    this.searchContractList();
  },
  activated() {
    this.searchContract(1);
  }
};
</script>

<style lang="scss" scoped>
#contractManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 300px;
}

.search_btn {
  min-width: 100px;
  margin-left: 90px;
}

.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>