<!-- 合作商管理列表页面 -->
<template>
  <div id="partnerManage">
    <HeadTag :tagName="titlename"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="90px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filters.orgName"
                placeholder="请选择组织"
                @focus="orgDialogVisible=true"
                @clear="clearOrgCode"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="合作商名称" prop="cooperationName">
              <el-input
                size="mini"
                v-model.trim="filters.cooperationName"
                placeholder="请输入合作商名称"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
           <el-col class="form-item">
            <el-form-item label="联系人" prop="contactsName">
              <el-input size="mini" v-model.trim="filters.contactsName" placeholder="请输入联系人" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
           <el-col class="form-item">
            <el-form-item label="联系电话" prop="contactsTel">
              <el-input size="mini" v-model.trim="filters.contactsTel" placeholder="请输入联系电话" maxlength="11" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
             <el-form-item label="科目" prop="subjectType">
              <el-select v-model.trim="filters.subjectType" size="mini" placeholder="请选择科目" clearable>
                <el-option
                  v-for="item in subjectTypeOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议" prop="isSignAgreement">
              <el-select size="mini" v-model.trim="filters.isSignAgreement" placeholder="请选择" clearable>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getPartnerManagementList(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="addPartnerManagement">新增</el-button>
          <el-button size="mini" type="primary" icon="el-icon-upload" @click="exportToExcel">导出</el-button>
        </el-col>
      </el-row>
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        stripe
        :data="tableData"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column prop="orgName" label="组织" width="240"></el-table-column>
        <el-table-column prop="cooperationCode" label="合作商编号" width="120"></el-table-column>
        <el-table-column prop="cooperationName" label="合作商名称" min-width="120"></el-table-column>
        <el-table-column prop="subjectType" label="科目" min-width="70"></el-table-column>
        <!-- 地址拼接 -->
        <el-table-column label="地区" min-width="200">
          <template slot-scope="scope">
            <span>{{scope.row.cooperationDetailAddress}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="contactsName" label="联系人" min-width="70"></el-table-column>
        <el-table-column prop="contactsTel" label="联系电话" width="120"></el-table-column>
        <el-table-column prop="isSignAgreement" label="签署协议" min-width="100"></el-table-column>
        <el-table-column prop="agreementStartDate" label="协议开始时间" width="110"></el-table-column>
        <el-table-column prop="agreementEndDate" label="协议结束时间"  width="110"></el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="toDetail(scope.row)">查看</el-button>
            <el-button size="mini" type="text" @click="toEdit(scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-row class="pageToolbar">
        <!--分页-->
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.pageNum"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        />
      </el-row>
    </div>
    <el-dialog
      title="组织架构"
      :visible.sync="orgDialogVisible"
      width="50%"
      :before-close="handleClose"
    >
      <org-select v-on:listenTochildEvent="getCurrentNode"/>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { getPartnerManagementList } from "api/partnerManagement/index.js";
import { findValueBySetCode } from "api/common/index.js";
import OrgSelect from "components/OrgSelect";
import { export_json_to_excel } from "@/utils/Export2Excel.js";
import { changeYMD, keepDecimalFull } from "utils/index.js";
export default {
  data() {
    return {
      titlename: "合作商管理列表",
      orgDialogVisible: false, //组织对话框
      filters: {
        cooperationName: "",
        subjectType: "",
        isSignAgreement: "",
        contactsName: "",
        contactsTel: "",
        orgCode: "",
        orgName: "",
        pageNum: 1,
        pageSize: 10
      },
      tabList: [],
      name: "",
      tableData: [],
      totalCount: 0,
      searchLoading: false,
      listLoading: false,
      options: [],
      subjectTypeOptions: [],
      value: ""
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    //查询列表
    getPartnerManagementList(page) {
      this.listLoading = true;
      this.searchLoading = true;
      this.filters.pageNum = page;
      getPartnerManagementList(this.filters)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            if (response.data.responseData != undefined) {
              this.tableData = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.tableData.forEach(item => {
                item.agreementStartDate =
                  item.agreementStartDate !== undefined
                    ? item.agreementStartDate.substr(0, 10)
                    : "";
                item.agreementEndDate =
                  item.agreementEndDate !== undefined
                    ? item.agreementEndDate.substr(0, 10)
                    : "";
                item.cooperationDetailAddress = this.detailAddress(item);
                return item;
              });
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("getPartnerManagementList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.getPartnerManagementList(val.page); //改变页码，重新渲染页面
    },
    //新增合作商
    addPartnerManagement() {
      this.$router.push({
        path: "/personnelManagement/AddPartnerManagement"
      });
    },
    //编辑合作商
    toEdit(row) {
      this.$router.push({
        path: "/personnelManagement/EditPartnerManagement",
        query: {
          cooperationCode: row.cooperationCode,
          pid: row.cooperationProvinceCode,
          cid: row.cooperationCityCode,
          aid: row.cooperationDistrictCode
        }
      });
    },
    //查看合作商
    toDetail(row) {
      this.$router.push({
        path: "/personnelManagement/PartnerManagementDetail",
        query: {
          cooperationCode: row.cooperationCode
        }
      });
    },
    //获取数据字典
    findValueBySetCode(type) {
      const params = {
        valueSetCode: type
      };
      findValueBySetCode(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            switch (type) {
              case "SUBJECT_TYPE":
                this.subjectTypeOptions = response.data.responseData;
                break;
              case "YES_OR_NO":
                this.options = response.data.responseData;
                break;
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error("服务端异常，请稍后再试");
        });
    },
    handleClose() {
      this.orgDialogVisible = false;
    },
    //获取组织返回的name和code
    getCurrentNode(val) {
      this.filters.orgName = val.orgName;
      this.filters.orgCode = val.orgCode;
      this.handleClose();
    },
    //清空组织过滤
    clearOrgCode() {
      this.filters.orgName = "";
      this.filters.orgCode = "";
    },
    exportToExcel() {
      const tHeader = [
        "序号",
        "组织",
        "合作商名称",
        "科目(学校，家政，其它)",
        "企业对接人姓名",
        "企业联系电话",
        "地址区域(杨浦，虹口等)",
        "联系地址",
        "具体洽谈内容",
        "具体洽谈结果",
        "是否与我们签署协议",
        "协议开始时间",
        "协议结束时间",
        "具体洽谈费用",
        "备注"
      ];
      // 上面设置Excel的表格第一行的标题
      const filterVal = [
        "orderNum",
        "orgName",
        "cooperationName",
        "subjectType",
        "contactsName",
        "contactsTel",
        "address",
        "cooperationDetailAddress",
        "negotiationContent",
        "negotiationResult",
        "isSignAgreement",
        "agreementStartDate",
        "agreementEndDate",
        "negotiationFee",
        "remark"
      ];
      // 上面的index、phone_Num、school_Name是tableData里对象的属性
      const params = {
        pageNum: 1,
        pageSize: 100000,
        cooperationName: this.filters.cooperationName,
        subjectType: this.filters.subjectType,
        contactsName: this.filters.contactsName,
        contactsTel: this.filters.contactsTel,
        orgCode: this.filters.orgCode,
        isSignAgreement: this.filters.isSignAgreement
      };
      getPartnerManagementList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            const list = response.data.responseData;
            if (list.length > 0) {
              list.forEach((item, index) => {
                item.orderNum = index + Number(1);
                item.negotiationContent =
                  item.negotiationContent !== undefined
                    ? item.negotiationContent
                    : "";
                item.negotiationResult =
                  item.negotiationResult !== undefined
                    ? item.negotiationResult
                    : "";
                item.negotiationFee =
                  item.negotiationFee !== undefined ? item.negotiationFee : "";
                item.remark = item.remark !== undefined ? item.remark : "";
                item.address = this.getDetailAddress(item);
                item.agreementStartDate =
                  item.agreementStartDate !== undefined
                    ? changeYMD(item.agreementStartDate)
                    : "";
                item.agreementEndDate =
                  item.agreementEndDate !== undefined
                    ? changeYMD(item.agreementEndDate)
                    : "";
                item.cooperationDetailAddress =
                  item.cooperationDetailAddress !== undefined
                    ? item.cooperationDetailAddress
                    : "";
                return item;
              });
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, "合作商管理明细汇总");
            } else {
              this.$message.error("暂无数据，无法导出Excel");
              return false;
            }
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    getDetailAddress(item) {
      var result = "";
      if (item.cooperationProvinceName !== undefined) {
        result += item.cooperationProvinceName;
      }
      if (item.cooperationCityName !== undefined) {
        result += item.cooperationCityName;
      }
      if (item.cooperationDistrictName !== undefined) {
        result += item.cooperationDistrictName;
      }
      // if (item.cooperationDetailAddress !== undefined) {
      //   result += item.cooperationDetailAddress;
      // }
      return result;
    },
    detailAddress(item) {
      var result = "";
      if (item.cooperationProvinceName !== undefined) {
        result += item.cooperationProvinceName;
      }
      if (item.cooperationCityName !== undefined) {
        result += item.cooperationCityName;
      }
      if (item.cooperationDistrictName !== undefined) {
        result += item.cooperationDistrictName;
      }
      if (item.cooperationDetailAddress !== undefined) {
        result += item.cooperationDetailAddress;
      }
      return result;
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.orgCode = "";
      this.getPartnerManagementList(1);
    }
  },
  created() {
    // this.getPartnerManagementList(1);
    this.findValueBySetCode("SUBJECT_TYPE");
    this.findValueBySetCode("YES_OR_NO");
  },
  activated() {
    this.getPartnerManagementList(1);
  }
};
</script>

<style lang="scss" scoped>
// 筛选框
#partnerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  width: 30%;
  min-width: 300px;
}
.search_btn {
  min-width: 250px;
  margin-left: 90px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
.table {
  background-color: #ffffff;
  margin-left: 20px;
  margin-right: 20px;
}
.table-column {
  background-color: #398af1;
}
.content {
  background: #ffffff;
  //   margin-top: 20px;
  .search_btn {
    margin-left: 30px;
  }
}
.listClass {
  //   margin: 50px 0;
  background: "#ffffff";
  height: 40px;
  width: 100%;
}
.pic {
  width: 20px;
  height: 20px;
}
.tableTopBtn {
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.searchBtn {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin-top: 20px;
}
</style>