<template>
  <div id="partnerManage">
    <HeadTag :tagName="tagName" />

    <div class="formStyle">
      <el-row class="importToolbar">
        <el-col :span="24">
          <el-button size="small" type="primary" class="rightBtn" @click="cancel()">返回</el-button>
          <el-button
            size="small"
            type="primary"
            class="rightBtn"
            @click="submitForm('formData')"
            :disabled="disable"
          >保存</el-button>
        </el-col>
      </el-row>
      <el-row>
        <el-form
          :inline="false"
          :model="formData"
          :rules="rules"
          ref="formData"
          label-width="150px"
        >
          <el-col class="form-item">
            <el-form-item label="组织:" prop="orgName">
              <el-input
                size="mini"
                v-model="formData.orgName"
                clearable
                placeholder="请选择组织"
                @focus="orgDialogVisible=true"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="合作商名称:" prop="cooperationName">
              <el-input
                size="mini"
                v-model="formData.cooperationName"
                clearable
                placeholder="请输入合作商名称"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="科目:">
              <el-select size="mini" v-model="formData.subjectType" clearable placeholder="请选择科目">
                <el-option
                  v-for="item in subjectTypeOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系人:">
              <el-input
                maxlength="50"
                size="mini"
                v-model="formData.contactsName"
                clearable
                placeholder="请输入联系人"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="协议日期:">
              <el-date-picker
                v-model="formData.date"
                clearable
                size="mini"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话:">
              <el-input
                maxlength="11"
                size="mini"
                v-model="formData.contactsTel"
                clearable
                placeholder="请输入联系电话"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="洽谈费用:" prop="negotiationFee">
              <el-input
                size="mini"
                placeholder="请输入洽谈费用"
                v-model="formData.negotiationFee"
                clearable
              >
                <template slot="append">(元)</template>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="地区" prop="supplierProvinceName">
              <AddressSelector
                :address="{pCode:formData.cooperationProvinceCode,cCode:formData.cooperationCityCode,dCode:formData.cooperationDistrictCode}"
                @selectedProvinceListener="selectedProvinceListener"
                @selectedCityListener="selectedCityListener"
                @selectedDistrictListener="selectedDistrictListener"
              />
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系地址:">
              <el-input
                size="mini"
                v-model="formData.cooperationDetailAddress"
                clearable
                placeholder="请输入联系地址"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈内容:">
              <el-input
                type="textarea"
                size="mini"
                v-model="formData.negotiationContent"
                placeholder="请输入具体洽谈内容"
                clearable
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈结果:">
              <el-input
                type="textarea"
                size="mini"
                v-model="formData.negotiationResult"
                clearable
                placeholder="请输入具体洽谈结果"
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注:">
              <el-input
                type="textarea"
                size="mini"
                v-model="formData.remark"
                clearable
                placeholder="请输入备注"
                class="remark-style"
                maxlength="100"
                show-word-limit
                resize="none"
                rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议:" prop="isSignAgreement">
              <el-radio-group v-model="formData.isSignAgreement">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
    <el-dialog
      title="组织架构"
      :visible.sync="orgDialogVisible"
      width="50%"
      :before-close="handleClose"
    >
      <org-select v-on:listenTochildEvent="getCurrentNode" />
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Address from "components/Address";
import AddressSelector from "components/AddressPicker/addressSelector";
import { findAddressDictList } from "api/common/index.js";
import {
  addPartnerManagement,
  getPartnerManagementDetail,
  editPartnerManagement
} from "api/partnerManagement/index.js";
import { findValueBySetCode } from "api/common/index.js";
import { getNodes } from "utils/address.js";
import OrgSelect from "components/OrgSelect";
import { changeYMD, keepDecimalFull } from "utils/index.js";
import { isMoney } from "utils/validate.js";

export default {
  data() {
    return {
      tagName: "新增合作商",
      disable: false,
      orgDialogVisible: false, //组织对话框
      pid: "",
      cid: "",
      aid: "",
      formData: {
        orgName: this.$store.getters.userOrgName,
        orgCode: this.$store.getters.userOrgCode,
        cooperationCode: "",
        cooperationName: "",
        subjectType: "",
        contactsName: "",
        contactsTel: "",
        cooperationProvinceName: "",
        cooperationProvinceCode: "",
        cooperationCityName: "",
        cooperationCityCode: "",
        cooperationDistrictName: "",
        cooperationDistrictCode: "",
        cooperationDetailAddress: "",
        negotiationContent: "",
        negotiationResult: "",
        negotiationFee: "",
        isSignAgreement: 1,
        agreementStartDate: "",
        agreementEndDate: "",
        date: [],
        remark: "",
        isEdit: false
      },
      subjectTypeOptions: [],
      rules: {
        //普通输入框  50以内  备注200以内
        negotiationFee: [{ validator: isMoney }],
        cooperationName: [
          { required: true, message: "请输入合作商名称", trigger: "blur" },
          { min: 0, max: 50, message: "长度在 0 到 50 个字符", trigger: "blur" }
        ],
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        isSignAgreement: [
          { required: true, message: "请选择签署协议", trigger: "change" }
        ]
      }
    };
  },
  components: {
    HeadTag,
    Address,
    OrgSelect,
    AddressSelector
  },
  methods: {
    selectChange(val) {
      this.formData.cooperationProvinceName = val.pName;
      this.formData.cooperationProvinceCode = val.pCode;
      this.formData.cooperationCityName = val.cName;
      this.formData.cooperationCityCode = val.cCode;
      this.formData.cooperationDistrictName = val.aName;
      this.formData.cooperationDistrictCode = val.aCode;
    },
    //添加合作商管理
    addPartnerManagement() {
      this.formData.agreementStartDate =
        this.formData.date == null ? "" : this.formData.date[0];
      this.formData.agreementEndDate =
        this.formData.date == null ? "" : this.formData.date[1];
      if (this.formData.isEdit) {
        this.disable = true;
        editPartnerManagement(this.formData)
          .then(response => {
            if (response.data.statusCode === "200") {
              this.$router.push({
                path: "/personnelManagement/partnerManagementList"
              });
            } else {
              this.$message.error("保存失败");
              this.disable = false;
            }
          })
          .catch(error => {
            console.log("editPartnerManagement:" + error);
            this.disable = false;
          });
      } else {
        this.disable = true;
        addPartnerManagement(this.formData)
          .then(response => {
            if (response.data.statusCode === "200") {
              this.$router.push({
                path: "/personnelManagement/partnerManagementList"
              });
            } else {
              this.$message.error("保存失败");
              this.disable = false;
            }
          })
          .catch(error => {
            console.log("addPartnerManagement:" + error);
            this.disable = false;
          });
      }
    },
    //获取数据字典
    findValueBySetCode(type) {
      const params = {
        valueSetCode: type
      };
      findValueBySetCode(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            switch (type) {
              case "SUBJECT_TYPE":
                this.subjectTypeOptions = response.data.responseData;
                break;
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    handleClose() {
      this.orgDialogVisible = false;
    },
    //获取组织返回的name和code
    getCurrentNode(val) {
      this.formData.orgName = val.orgName;
      this.formData.orgCode = val.orgCode;
      this.handleClose();
    },
    //获取编辑选中的数据
    getPartnerManagementDetail(code) {
      const params = {
        cooperationCode: code
      };
      getPartnerManagementDetail(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            const data = response.data.responseData;
            this.formData.orgName = data.orgName;
            this.formData.orgCode = data.orgCode;
            this.formData.cooperationCode = data.cooperationCode;
            this.formData.cooperationName = data.cooperationName;
            this.formData.subjectType = data.subjectType;
            this.formData.contactsName = data.contactsName;
            this.formData.contactsTel = data.contactsTel;
            this.formData.cooperationProvinceName =
              data.cooperationProvinceName;
            this.formData.cooperationProvinceCode =
              data.cooperationProvinceCode;
            this.formData.cooperationCityName = data.cooperationCityName;
            this.formData.cooperationCityCode = data.cooperationCityCode;
            this.formData.cooperationDistrictName =
              data.cooperationDistrictName;
            this.formData.cooperationDistrictCode =
              data.cooperationDistrictCode;
            this.formData.cooperationDetailAddress =
              data.cooperationDetailAddress;
            this.formData.negotiationContent = data.negotiationContent;
            this.formData.negotiationResult = data.negotiationResult;
            this.formData.agreementStartDate = changeYMD(
              data.agreementStartDate
            );
            this.formData.agreementEndDate = changeYMD(data.agreementEndDate);
            this.formData.date = [
              this.formData.agreementStartDate,
              this.formData.agreementEndDate
            ];
            this.formData.negotiationFee = keepDecimalFull(
              data.negotiationFee,
              2
            );

            this.formData.remark = data.remark;
            this.formData.isEdit = true;
            this.formData.isSignAgreement = Number(data.isSignAgreement);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          this.$message.error("服务端异常，请稍后再试");
          return false;
        });
    },
    //取消
    cancel() {
      this.$router.push({
        path: "/personnelManagement/partnerManagementList"
      });
    },
    //添加数据
    submitForm(formName) {
      this.disable = true;
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.addPartnerManagement();
        } else {
          this.disable = false;
          return false;
        }
      });
    },
    selectedProvinceListener(obj) {
      this.formData.cooperationProvinceName = obj.name;
      this.formData.cooperationProvinceCode = obj.id;
      this.formData.cooperationCityName = "";
      this.formData.cooperationCityCode = "";
      this.formData.cooperationDistrictName = "";
      this.formData.cooperationDistrictCode = "";
    },
    selectedCityListener(obj) {
      this.formData.cooperationCityName = obj.name;
      this.formData.cooperationCityCode = obj.id;
      this.formData.cooperationDistrictName = "";
      this.formData.cooperationDistrictCode = "";
    },
    selectedDistrictListener(obj) {
      this.formData.cooperationDistrictName = obj.name;
      this.formData.cooperationDistrictCode = obj.id;
    }
  },
  created() {
    let cooperationCode = this.$route.query.cooperationCode;
    this.pid = this.$route.query.pid;
    this.cid = this.$route.query.cid;
    this.aid = this.$route.query.aid;
    if (cooperationCode != undefined) {
      this.tagName = "修改合作商";
      this.getPartnerManagementDetail(cooperationCode);
    }
    this.findValueBySetCode("SUBJECT_TYPE");
  }
};
</script>

<style lang="scss" scoped>
#partnerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.formStyle {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #ffffff;
  border-radius: 10px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.remark-style {
  display: block;
  width: 300px;
}
.form-item {
  width: 30%;
  min-width: 470px;
}
</style>
<style lang="scss">
#partnerManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>