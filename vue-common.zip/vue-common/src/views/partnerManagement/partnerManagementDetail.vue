<!-- 合作商管理查看页面-->
<template>
  <div id="partnerManage">
    <HeadTag :tagName="tagName" />

    <div class="formStyle">
      <el-row class="importToolbar">
        <el-col :span="24">
          <el-button size="small" type="primary" class="rightBtn" @click="cancelClick()">返回</el-button>
        </el-col>
      </el-row>
      <el-row>
        <el-form label-position="right" label-width="150px" :model="detail">
          <el-col class="form-item">
            <el-form-item label="组织:">
              <span>{{detail.orgName}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="合作商名称:">
              <span>{{detail.cooperationName}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="科目:">
              <span>{{detail.subjectTypeName}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系人:">
              <span>{{detail.contactsName}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="协议日期:">
              <span v-if="detail.agreementStartDate">
                <span>{{detail.agreementStartDate}}-{{detail.agreementEndDate}}</span>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系电话:">
              <span>{{detail.contactsTel}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="洽谈费用:">
              <span v-if="detail.negotiationFee">
                <span>{{detail.negotiationFee}}元</span>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="地区:">
              <span>{{detail.cooperationProvinceName}}{{detail.cooperationCityName}}{{detail.cooperationDistrictName}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="联系地址:">
              <span>{{detail.cooperationDetailAddress}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈内容:">
              <span>{{detail.negotiationContent}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="具体洽谈结果:">
              <span>{{detail.negotiationResult}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注:">
              <span>{{detail.remark}}</span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="签署协议:">
              <span>{{detail.isSignAgreementName}}</span>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { getPartnerManagementDetail } from "api/partnerManagement/index.js";
import { changeYMD, keepDecimalFull } from "utils/index.js";
import { isEmpty } from "utils/isEmpty.js";
export default {
  data() {
    return {
      tagName: "合作商详情",
      cooperationCode: "",
      detail: {}
    };
  },
  components: {
    HeadTag
  },
  methods: {
    cancelClick: function() {
      this.$router.push({
        path: "/personnelManagement/partnerManagementList"
      });
    },
    getPartnerManagementDetail() {
      this.cooperationCode = this.$route.query.cooperationCode;
      const params = {
        cooperationCode: this.cooperationCode
      };
      getPartnerManagementDetail(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.detail = response.data.responseData;

            if (this.detail.negotiationFee) {
              this.detail.negotiationFee = keepDecimalFull(
                this.detail.negotiationFee,
                2
              );
            }

            if (isEmpty(this.detail.agreementStartDate)) {
              this.detail.agreementStartDate = "";
              this.detail.agreementEndDate = "";
            } else {
              this.detail.agreementStartDate = changeYMD(
                this.detail.agreementStartDate
              );
              this.detail.agreementEndDate = changeYMD(
                this.detail.agreementEndDate
              );
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getPartnerManagementDetail:" + error);
          return false;
        });
    }
  },
  created() {
    this.getPartnerManagementDetail();
  }
};
</script>

<style lang="scss" scoped>
#partnerManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.formStyle {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #ffffff;
  border-radius: 10px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
  .rightBtn {
    float: right;
    margin-right: 20px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.remark-style {
  display: block;
  width: 300px;
}
.form-item {
  width: 30%;
  min-width: 470px;
}
</style>
<style lang="scss">
#partnerManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
</style>
