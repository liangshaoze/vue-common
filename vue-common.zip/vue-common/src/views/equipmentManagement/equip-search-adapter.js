import BaseSearchAdapter from 'components/widget/base-search-adapter'
import { findDeviceOrderDataByNo,findOrderDeviceByClass,getDeviceMessageType } from "@/api/equipmentManagement";
export default {
  mixins: [BaseSearchAdapter],
  data() {
    return {
      searchModel: {
        name: "",
        deviceId: "",
        msgType: "",
        queryTime: "",
        dataStatus: "",//消息类型
        dataDateB: "",
        dataDateE: "",
        deviceName:"",
        deviceCode:"",
        deviceOrderItems: [
          {
            orderItemCode: "SBZDD2006150001",
            deviceCode: "设备CODE",
            deviceName: "设备名称",
            deviceRawNo: "设备原no"
          }
        ],
        pageNum: 1,
        pageSize: 10
      },
      searchItems: [
        {
          propertyName: "名称",
          propertyFieldName: "deviceCode",
          propertyType: "20", //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
          optionKeyFieldName: "value",
          optionValueFieldName: "name",
          options: [],
        },
        {
          propertyName: "消息类型",
          propertyFieldName: "dataStatus",
          propertyType: "20", //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
          optionKeyFieldName: "value",
          optionValueFieldName: "name",
          options: [],
        },
        {
          propertyName: "时间",
          propertyFieldName: "queryTime",
          propertyType: "71"
        }
      ],
    }
  },
  methods: {
    queryData(){
      this.loading(true)
      if(this.searchModel.queryTime){
        this.searchModel.dataDateB = this.searchModel.queryTime[0];
        this.searchModel.dataDateE = this.searchModel.queryTime[1];
      }else{
        this.searchModel.dataDateB = "";
        this.searchModel.dataDateE = "";
      }
      this.searchModel.deviceOrderItems=[];
      var deviceOrderItem = this.filterDevices.find(item=>{
        return item.deviceName==this.searchModel.deviceName;
      })
      if(deviceOrderItem){
        this.searchModel.deviceOrderItems.push(deviceOrderItem)
      }else{
        this.searchModel.deviceOrderItems=this.filterDevices;
      }
      findDeviceOrderDataByNo(this.searchModel).then(response=>{
       this.loading(false);
        if(response.data.statusCode==200){
          this.tableFormModel.dataList = response.data.responseData;
          this.tableFormModel.totalCount = response.data.totalCount;
        }
      }).catch(error=>{
         this.loading(false);
         this.$message(this.ConstantData.requestErrorMsg)
      })
    },
    loading(searching){
      this.searchLoading = searching;
      this.tableLoading = searching;
    },
    findOrderDevices(){
      var params = {
        orderCode: this.careReceiver.orderCode,
        careReceiverCode: this.careReceiver.careReceiverCode,
        deviceClassCode: this.careReceiver.deviceClassCode,
        deviceClassName: this.careReceiver.deviceClassName
      }
      findOrderDeviceByClass(params).then(response=>{
        if(response.data.statusCode==200){
          if(response.data.responseData){
            this.filterDevices=response.data.responseData.devices;
            this.searchItems[0].options= response.data.responseData.devices.map(item=>{
              return {value:item.deviceCode,name:item.deviceName};
            })
            this.queryData();
          }
        }
      }).catch(error=>{

      })
    },
    findDeviceMessageType(){
      var params={
        deviceClassCode: this.careReceiver.deviceClassCode,
        deviceMessageTypeCode: "messageType"
      }
      getDeviceMessageType(params).then(response=>{
        if(response.data.statusCode==200){
          this.searchItems.find(item=>item.propertyFieldName=="dataStatus").options=response.data.responseData.map(item=>{
              return {value:item.name,name:item.name};
            })
        }
      }).catch(error=>{

      })
    },
  }
}