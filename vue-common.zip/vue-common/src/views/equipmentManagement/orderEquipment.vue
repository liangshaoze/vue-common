<template>
	<div id="orderManage">
		<headTag :tagName="tagName" />

		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filters" label-width="80px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="filters.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="订单状态" prop="orderStatus">
							<el-select size="mini" v-model.trim="filters.orderStatus" clearable placeholder="请选择订单状态">
								<el-option
									v-for="item in orderStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="创建时间" prop="createDate">
							<el-date-picker
								v-model.trim="filters.createDate"
								clearable
								size="mini"
								value-format="yyyy-MM-dd"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="身份证号" prop="careReceiverIdCard">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverIdCard"
								clearable
								placeholder="请输入身份证号"
								maxlength="18"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="订单号" prop="orderCode">
							<el-input size="mini" v-model.trim="filters.orderCode" clearable placeholder="请输入订单号"></el-input>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item></el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="getList(1)"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="insertOrder()">新增</el-button>
				</el-col>
			</el-row>
			<!--列表-->
			<el-table
				:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
				stripe
				size="mini"
				:data="orderList"
				v-loading="listLoading"
				highlight-current-row
				element-loading-text="拼命加载中"
			>
				<el-table-column label="订单号" min-width="150" prop="orderCode"></el-table-column>
				<el-table-column label="订单状态" min-width="150" prop="orderStatusValue"></el-table-column>
				<el-table-column label="被照护人姓名" min-width="150" prop="careReceiverName"></el-table-column>
				<el-table-column label="身份证号" min-width="150" prop="careReceiverIdCard"></el-table-column>
				<el-table-column label="地址" min-width="200" prop="liveProvinceName">
					<template slot-scope="scope">
						<span
							v-if="scope.row.liveProvinceName"
						>{{scope.row.liveProvinceName}}{{scope.row.liveCityName}}{{scope.row.liveDistrictName}}{{scope.row.liveSubdistrictName}}{{scope.row.liveDetailAddress}}</span>
					</template>
				</el-table-column>
				<el-table-column label="组织" min-width="200" prop="orgName"></el-table-column>
				<el-table-column label="创建时间" min-width="135" prop="createDate"></el-table-column>
				<el-table-column fixed="right" width="120" label="操作">
					<template slot-scope="scope">
						<el-button size="mini" type="text" @click="handleEditOrder(scope.row)">查看</el-button>
						<span v-if="scope.row.orderStatus == '10'">
							<el-button size="mini" type="text" @click="handleCancleOrder(scope.row)">取消订单</el-button>
							<!-- <el-button size="mini" type="text" @click="handleOrderEffect(scope.row)">订单生效</el-button> -->
						</span>
						<span v-if="scope.row.orderStatus == '20'">
						</span>
						<span v-if="scope.row.orderStatus == '25'">
							<el-button size="mini" type="text" @click="handleFinishOrder(scope.row)">订单完成</el-button>
						</span>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination
					v-if="totalCount>0"
					:total="totalCount"
					:page.sync="filters.page"
					:limit.sync="filters.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
		</div>

		<!-- 订单生效弹窗 -->
		<el-dialog
			title="确认订单"
			:visible.sync="dialogOrderEffect"
			width="500px"
			:before-close="handleCloseEffect"
			center
		>
			<h4 style="text-align:center">订单确认后服务开始生效！</h4>
			<div slot="footer" class="dialog-footer">
				<el-button size="mini" @click="handleCloseEffect">取 消</el-button>
				<el-button
					size="mini"
					style="margin-left:40px;"
					type="primary"
					@click="orderEffect()"
					:disabled="isDisabled"
				>确 定</el-button>
			</div>
		</el-dialog>

		<!-- 取消订单弹窗 -->
		<el-dialog
			title="取消订单"
			:visible.sync="dialogCancelOrder"
			width="500px"
			:before-close="handleCloseCancle"
			center
		>
			<h4 style="text-align:center">取消后不可恢复，请谨慎操作！</h4>
			<br>
			<el-input
				type="textarea"
				class="remark-style"
				v-model="cancelDescription"
				placeholder="请输入取消原因"
				resize="none"
				show-word-limit
				rows="4"
				clearable
				maxlength="100"
			></el-input>
			<div slot="footer" class="dialog-footer">
				<el-button size="mini" @click="handleCloseCancle">取 消</el-button>
				<el-button
					style="margin-left:40px;"
					size="mini"
					type="primary"
					@click="cancleOrder()"
					:disabled="isDisabled"
				>确 定</el-button>
			</div>
		</el-dialog>

		<!-- 订单完成弹窗 -->
		<el-dialog
			title="订单完成"
			:visible.sync="dialogFinishOrder"
			width="500px"
			:before-close="handleCloseFinish"
			center
		>
			<h4 style="text-align:center">完成后将不可恢复，请谨慎操作！</h4>
			<br>
			<el-input
				type="textarea"
				class="remark-style"
				v-model="completionReason"
				placeholder="完成说明"
				resize="none"
				show-word-limit
				rows="4"
				clearable
				maxlength="100"
			></el-input>
			<div slot="footer" class="dialog-footer">
				<el-button size="mini" @click="handleCloseFinish">取 消</el-button>
				<el-button
					style="margin-left:40px;"
					size="mini"
					type="primary"
					@click="finishOrder()"
					:disabled="isDisabled"
				>确 定</el-button>
			</div>
		</el-dialog>

		<!-- 列表过滤组织弹窗 -->
		<el-dialog
			title="组织架构"
			:visible.sync="dialogVisible"
			width="500px"
			:before-close="handleCloseOrg"
		>
			<org-select v-on:listenTochildEvent="getCurrentNode" />
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common";
import {
	findDeviceOrderList,
	cancelDeviceOrder,
	editDeviceOrderTakesEffect,
	editDeviceOrderCompleted
} from "api/equipmentManagement";
import OrgSelect from "components/OrgSelect";
import { hasPermission } from "@/utils/button";
export default {
	data () {
		return {
			tagName: "订单管理",
			//列表过滤组织弹窗控制
			dialogVisible: false,
			//取消订单弹窗
			dialogCancelOrder: false,
			cancelDescription: "",
			//订单生效弹窗
			dialogOrderEffect: false,
			//订单完成弹窗
			dialogFinishOrder: false,
			completionReason: "",
			isDisabled: false,
			//条件查询
			filters: {
				orderStatus: "10",
				createDate: [],
				careReceiverName: "",
				careReceiverIdCard: "",
				orderCode: "",
				orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : "",
        		orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : "",
				page: 1,
				pageSize: 10
			},
			orderList: [],
			totalCount: 0,
			//列表加载状态
			listLoading: false,
			//查询按钮加载状态
			searchLoading: false,
			//订单状态
			orderStatusOptions: []
		};
	},
	components: {
		HeadTag,
		Pagination,
		OrgSelect
	},
	methods: {
		//父组件触发事件
		pageChange (val) {
			this.filters.page = val.page;
			this.filters.pageSize = val.limit;
			this.getList(val.page); //改变页码，重新渲染页面
		},
		getList (page) {
			this.filters.page = page;
			var params = {
				pageNum: this.filters.page,
				pageSize: this.filters.pageSize,
				orderCode: this.filters.orderCode,
				careReceiverName: this.filters.careReceiverName,
				careReceiverIdCard: this.filters.careReceiverIdCard,
				orderStatus: this.filters.orderStatus,
				orgCode: this.filters.orgCode,
				createDateB:(this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[0]+" 00:00:00") : "",
				createDateE:(this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[1]+" 23:59:59") : ""
			};
			this.listLoading = true;
			this.searchLoading = true;
			findDeviceOrderList(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode == "200"
					) {
						this.orderList = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
						this.searchLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findDeviceOrderList:" + error);
					this.listLoading = false;
					this.searchLoading = false;
					return false;
				});
		},
		/**
		 * 列表过滤组织弹窗
		 */
		//关闭
		handleCloseOrg () {
			this.dialogVisible = false;
		},
		//获取组织
		getCurrentNode (data) {
			this.filters.orgName = data.orgName;
			this.filters.orgCode = data.orgCode;
			this.handleCloseOrg();
		},
		//清空组织过滤
		clearOrgCode () {
			// this.filters.orgName = "";
			this.filters.orgCode = "";
		},
		/**
		 * 新增/修改设备订单
		 */
		insertOrder () {
			this.$router.push({
				path: "/wisdomCustody/orderEquipmentAdd",
				query: {
					type: "insert"
				}
			});
		},
		handleEditOrder (row) {
			this.$router.push({
				path: "/wisdomCustody/orderEquipmentAdd",
				query: {
					type: "update",
					orderCode: row.orderCode
				}
			});
		},
		//订单生效弹窗
		handleOrderEffect (row) {
			this.dialogOrderEffect = true;
			this.orderCode = row.orderCode;
		},
		//订单生效关闭
		handleCloseEffect () {
			this.dialogOrderEffect = false;
		},
		//订单生效确认
		orderEffect () {
			this.isDisabled = true;
			var params = {
				orderCode: this.orderCode
			};
			editDeviceOrderTakesEffect(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.$message.success("操作成功");
						this.dialogOrderEffect = false;
						this.isDisabled = false;
						this.getList(1);
					} else {
						this.dialogOrderEffect = false;
						this.$message.error(response.data.statusMsg);
						this.isDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.isDisabled = false;
					this.dialogOrderEffect = false;
					return false;
				});
		},
		//订单完成弹窗
		handleFinishOrder (row) {
			this.dialogFinishOrder = true;
			this.orderCode = row.orderCode;
		},
		handleCloseFinish () {
			this.dialogFinishOrder = false;
		},
		//订单完成
		finishOrder () {
			this.isDisabled = true;
			var params = {
				orderCode: this.orderCode,
				completionReason: this.completionReason
			};
			editDeviceOrderCompleted(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.$message.success("操作成功");
						this.completionReason = "";
						this.dialogFinishOrder = false;
						this.isDisabled = false;
						this.getList(1);
					} else {
						this.$message.error(response.data.statusMsg);
						this.dialogFinishOrder = false;
						this.isDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.dialogFinishOrder = false;
					this.isDisabled = false;
					return false;
				});
		},
		//取消订单弹窗
		handleCancleOrder (row) {
			this.dialogCancelOrder = true;
			this.orderCode = row.orderCode;
		},
		handleCloseCancle () {
			this.dialogCancelOrder = false;
		},
		//取消订单确认
		cancleOrder () {
			this.isDisabled = true;
			var params = {
				orderCode: this.orderCode,
				cancelDescription: this.cancelDescription
			};
			cancelDeviceOrder(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.$message.success("操作成功");
						this.cancelDescription = "";
						this.dialogCancelOrder = false;
						this.isDisabled = false;
						this.getList(1);
					} else {
						this.$message.error(response.data.statusMsg);
						this.dialogCancelOrder = false;
						this.isDisabled = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.dialogCancelOrder = false;
					this.isDisabled = false;
					return false;
				});
		},
		/**
		 * 删除按钮
		 */
		// handleDelete(index, row) {
		//   this.orderList.splice(index, 1);
		// },
		/**
		 * 重置按钮
		 */
		resetForm () {
			this.$refs.filterForm.resetFields();
			this.filters.orgCode = "";
			this.getList(1);
		},
		/**
		 *
		 * 数据字典
		 *
		 */
		initDataDictionary () {
			//订单状态
			findValueBySetCode({ valueSetCode: "DEVICE_ORDER_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.orderStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}
		//按钮权限
		// buttonControl() {
		//   this.showList.edit_organization_onClick = hasPermission(
		//     "edit_organization_onClick"
		//   );
		// }
	},
	created () {
		// this.buttonControl()
		this.initDataDictionary();
	},
	mounted () {
	},
	activated () {
		this.getList(1);
	}
};
</script>

<style lang="scss" scoped>
#orgSelect {
	height: 500px;
	overflow-y: auto;
}
#orderManage {
	width: 100%;
	min-width: 1024px;
	.el-form-item {
		margin-bottom: 0px;
	}
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.el-autocomplete {
	width: 200px;
}
.form-item {
	width: 30%;
	min-width: 440px;
	line-height: 40px;
}
.search_btn {
	min-width: 250px;
	margin-left: 80px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 0px 10px 0px;
}
.tableList {
	width: 100%;
}
.table-label {
	max-width: 200px;
	word-break: break-all;
}
</style>
