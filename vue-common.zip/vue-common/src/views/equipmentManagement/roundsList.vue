<template>
	<div id="medicineChestList">
		<headTag :tagName="tagName" />
		<div class="seettingTop">
			<div class="info-left">
				<div class="person-detail">
					<img
						style="width:60px;height:60px;"
						src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
					/>
				</div>
				<div class="person-info">
					<span>{{careReceiver.careReceiverName}}</span>
					<!-- <span class="person-color">{{careReceiver.isLiveAlone=='0'?"非独居":'独居'}}</span> -->
					<span class="person-color" v-if="careReceiver.isLiveAlone=='1'">独居</span>
				</div>
			</div>
			<div class="info-right" style="width:100%;padding:30px 0;">
				<div class="basic-info">
					<el-row>
						<el-col :span="22" style="font-size:16px;color:#333333;">基本信息</el-col>
						<el-col :span="2">
							<el-button type="primary" size="mini" @click="btnBack">返回</el-button>
						</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">年龄：{{getAge(careReceiver)}}</el-col>
						<el-col class="info-text" :span="8">性别：{{careReceiver.careReceiverGenderValue}}</el-col>
						<el-col class="info-text" :span="8">生日：{{getBirthday(careReceiver)}}</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">电话：{{careReceiver.careReceiverTel}}</el-col>
						<el-col
							:span="8"
							class="info-text"
						>地址：{{careReceiver.liveProvinceName+careReceiver.liveCityName+careReceiver.liveDistrictName+careReceiver.liveSubdistrictName+careReceiver.liveDetailAddress}}</el-col>
					</el-row>
				</div>
			</div>
		</div>
		<div class="tableToolbar">
			<div class="tableContent">
				<el-form ref="roundsInfoForm" :inline="true" :model="roundsForm" label-width="65px">
					<el-form-item label="时间:" prop="roundsDate" style="margin-left:-35px;">
						<el-date-picker
							size="mini"
							v-model.trim="roundsForm.roundsDate"
							format="yyyy-MM-dd HH:mm:ss"
							value-format="yyyy-MM-dd HH:mm:ss"
							type="datetimerange"
							range-separator="至"
							style="width: 400px;"
							start-placeholder="开始日期"
							end-placeholder="结束日期"
						></el-date-picker>
					</el-form-item>
					<el-button
						@click="getList(1)"
						icon="el-icon-search"
						size="mini"
						type="primary"
						style="margin:4px 0 0 15px;"
					>查询</el-button>
				</el-form>
			</div>
			<div>
				<el-row class="tableTopBtn">
					<el-col :span="24">
						<el-button size="mini" type="primary" icon="el-icon-plus" @click="addTo">新增</el-button>
					</el-col>
				</el-row>
				<el-table
					:data="tableData"
					:header-cell-style="{
          			background: 'rgba(57, 138, 241, 0.1)',
          			color: '#606266'
        		}"
					element-loading-text="拼命加载中"
					highlight-current-row
					size="mini"
					stripe
					v-loading="listLoading"
				>
					<el-table-column label="时间" min-width="100" prop="orgName">
						<template slot-scope="scope">
							<span v-if="scope.row.roundDate">{{scope.row.roundDate}}</span>
						</template>
					</el-table-column>
					<el-table-column label="类型" min-width="100" prop="roundTypeValue"></el-table-column>
					<el-table-column label="查房人员"  prop="roundName"></el-table-column>
					<el-table-column label="结果"  prop="roundResultValue"></el-table-column>
					<el-table-column label="详情" min-width="350" prop="roundDetail"></el-table-column>
					<el-table-column label="状态"  prop="roundStatusValue"></el-table-column>
					<el-table-column label="信息状态" min-width="100" prop="messageStatus">
						<template slot-scope="scope">
							<span v-if="scope.row.messageStatus=='10'">
								<el-button size="mini" type="text" @click="sendMessgae(scope.row)">未发送</el-button>
							</span>
							<span v-if="scope.row.messageStatus=='20'">已发送</span>
						</template>
					</el-table-column>
					<el-table-column fixed="right" label="操作">
						<template slot-scope="scope">
							<span v-if="scope.row.roundStatus=='20'">
								<el-button size="mini" type="text" @click="examine(scope.row.groupId,'1')">查看</el-button>
							</span>
							<span v-if="scope.row.roundStatus=='10'">
								<el-button size="mini" type="text" @click="examine(scope.row.groupId,'2')">编辑</el-button>
							</span>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<!--工具条-->
			<el-row class="pageToolbar">
				<!--分页-->
				<pagination
					:limit.sync="roundsForm.pageSize"
					:page.sync="roundsForm.pageNum"
					:total="totalCount"
					@pagination="pageChange"
					v-if="totalCount > 0"
				/>
			</el-row>
		</div>
		<!--查看/编辑弹窗 -->
		<el-dialog
			:title="titleName"
			:close-on-click-modal="false"
			width="600px"
			:visible.sync="dialogExamine"
			:before-close="handleExamineClose"
			center
		>
			<el-row type="flex" justify="center">
				<el-timeline>
					<el-timeline-item
						v-for="(item, index) in examList"
						:key="index"
						:timestamp="item.roundDate"
						color="#3AC679"
						placement="top"
					>
						<el-card>
							<p>类型:{{item.roundTypeValue}}</p>
							<p>结果:{{item.roundResultValue}}</p>
							<p>详情:{{item.roundDetail}}</p>
							<p>状态:{{item.roundStatusValue}}</p>
							<p>查房人员:{{item.roundName}}</p>
							<p>描述:{{item.remark}}</p>
						</el-card>
					</el-timeline-item>
					<el-timeline-item color="#3AC679" placement="top" v-if="isEdit">
						<el-card>
							<el-button type="primary" size="mini" v-if="isShow" @click="updateRecord" round>添加</el-button>
							<el-form
								v-show="isRound"
								:inline="false"
								:model="editRoundsForm"
								:rules="editRoundsFormRules"
								label-width="90px"
								ref="editRoundsForm"
							>
								<el-form-item label="类型:">
									<el-col v-model.trim="editRoundsForm.roundType">手动查房</el-col>
								</el-form-item>
								<el-form-item label="结果:" prop="roundResult">
									<el-select
										size="mini"
										v-model.trim="editRoundsForm.roundResult"
										clearable
										placeholder="请选择结果"
									>
										<el-option
											v-for="item in roundResultOptions "
											:key="item.value"
											:label="item.name"
											:value="item.value"
										/>
									</el-select>
								</el-form-item>
								<el-form-item label="详情:" prop="roundDetail">
									<el-input
										class="remark-style"
										clearable
										placeholder="请输入详情"
										size="mini"
										type="textarea"
										resize="none"
										rows="8"
										show-word-limit
										v-model="editRoundsForm.roundDetail"
										maxlength="1000"
									></el-input>
								</el-form-item>
								<el-form-item label="状态:" prop="roundStatus">
									<el-select
										size="mini"
										v-model.trim="editRoundsForm.roundStatus"
										clearable
										placeholder="请选择状态"
									>
										<el-option
											v-for="item in roundStatusOptions"
											:key="item.value"
											:label="item.name"
											:value="item.value"
										/>
									</el-select>
								</el-form-item>
								<el-form-item label="查房人员:" prop="roundName">
									<el-autocomplete
										size="mini"
										:trigger-on-focus="true"
										style="width: 200px"
										v-model="editRoundsForm.roundName"
										popper-class="my-autocomplete"
										clearable
										:fetch-suggestions="queryEditStaffName"
										placeholder="请输入查房人员"
										@select="selectEditStaffName"
										@blur="removeEditStaffCode"
									>
										<template slot-scope="{ item }">
											<span class="name">
												{{ item.value }}
												<span v-if="item.value != '无'">({{ item.staffTel }})</span>
											</span>
										</template>
									</el-autocomplete>
								</el-form-item>
								<el-form-item label="描述:" prop="remark">
									<el-input
										clearable
										placeholder="请输入描述"
										size="mini"
										class="remark-style"
										type="textarea"
										resize="none"
										rows="4"
										show-word-limit
										v-model="editRoundsForm.remark"
										maxlength="100"
									></el-input>
								</el-form-item>
								<el-form-item>
									<el-button @click="cancelEditBtn" size="mini">取消</el-button>
									<el-button
										:disabled="cancleDisabled"
										style="margin-left:40px;"
										@click="editRounds('editRoundsForm')"
										size="mini"
										type="primary"
									>确 定</el-button>
								</el-form-item>
							</el-form>
						</el-card>
					</el-timeline-item>
				</el-timeline>
			</el-row>
		</el-dialog>
		<!-- 新增 -->
		<el-dialog
			title="新增"
			:close-on-click-modal="false"
			:visible.sync="dialogAdd"
			width="600px"
			:before-close="handleAddClose"
			center
		>
			<el-row type="flex" justify="center">
				<el-form
					:inline="false"
					:model="addRoundsForm"
					:rules="addRoundsFormRules"
					label-width="90px"
					ref="addRoundsForm"
				>
					<el-form-item label="类型:" prop="roundType">
						<el-col v-model.trim="addRoundsForm.roundType">手动查房</el-col>
					</el-form-item>
					<!-- <el-form-item label="时间:">
						<el-col>{{addRoundsForm.roundDate}}</el-col>
					</el-form-item>-->

					<el-form-item label="结果:" prop="roundResult">
						<el-select size="mini" v-model.trim="addRoundsForm.roundResult" clearable placeholder="请选择结果">
							<el-option
								v-for="item in roundResultOptions "
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="详情:" prop="roundDetail">
						<el-input
							clearable
							placeholder="请输入详情"
							size="mini"
							type="textarea"
							v-model="addRoundsForm.roundDetail"
							maxlength="1000"
						></el-input>
					</el-form-item>
					<el-form-item label="状态:" prop="roundStatus">
						<el-select size="mini" v-model.trim="addRoundsForm.roundStatus" clearable placeholder="请选择状态">
							<el-option
								v-for="item in roundStatusOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item label="查房人员:" prop="roundName">
						<el-autocomplete
							size="mini"
							:trigger-on-focus="true"
							style="width: 200px"
							v-model="addRoundsForm.roundName"
							popper-class="my-autocomplete"
							clearable
							:fetch-suggestions="queryStaffName"
							placeholder="请输入查房人员"
							@select="selectStaffName"
							@blur="removeStaffCode"
						>
							<template slot-scope="{ item }">
								<span class="name">
									{{ item.value }}
									<span v-if="item.value != '无'">({{ item.staffTel }})</span>
								</span>
							</template>
						</el-autocomplete>
					</el-form-item>
					<el-form-item label="描述:" prop="remark">
						<el-input
							clearable
							placeholder="请输入描述"
							size="mini"
							type="textarea"
							v-model="addRoundsForm.remark"
							maxlength="100"
						></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancelAddBtn" size="mini">取消</el-button>
				<el-button
					style="margin-left:40px;"
					@click="addRecord('addRoundsForm')"
					size="mini"
					:disabled="cancleDisabled"
					type="primary"
				>确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode, getNow } from "api/common";
import { timestampChangeDate } from "utils/index";
import { findStaffAll } from "api/customerManagement";
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";

import {
	findDeviceOrderRoundList,
	insertDeviceOrderRound,
	getDeviceOrderRound,
	addMessage
} from "api/equipmentManagement/device";
export default {
	components: {
		HeadTag,
		OrgSelect,
		Pagination,
	},
	props: {},
	data () {
		return {
			tagName: "查房",
			roundsForm: {
				roundsDate: '',
				pageNum: 1,
				pageSize: 10,
				orderCode: '',
			},
			activeName: 'first',
			totalCount: 0,
			eventOptions: [],
			statusOptions: [],
			tableData: [],
			dialogVisible: false,
			listLoading: false,
			roundsInfoForm: {

			},
			careReceiver: {

			},
			medicOptions: [],
			dialogExamine: false,
			// dialogEdit: false,
			isShow: true,
			isRound: false,
			editRoundsForm: {
				roundType: '10',//手动查房
				roundResult: '',//结果
				roundDetail: '',//详情
				roundStatus: '',//状态
				roundName: this.$store.getters.userFullName,//查房人员
				roundCode: this.$store.getters.userCode,//查房人员code
				remark: '',//描述
				careReceiverCode: '',
				careReceiverName: '',
				groupId: '',
				orderCode: '',
				orgCode: '',
				orgName: '',
				pageNum: 1,
			},
			editRoundsFormRules: {
				roundResult: [
					{ required: true, message: '请选择结果', trigger: 'change' }
				],
				roundStatus: [
					{ required: true, message: '请选择状态', trigger: 'change' }
				],
				roundDetail: [
					{ required: true, message: '请填写详情', trigger: 'blur' }
				],
				roundName: [
					{
						required: true,
						message: "请输入姓名",
						trigger: "input"
					}
				],
			},
			addRoundsForm: {
				// roundDate: '',//时间
				roundType: '10',//手动查房
				roundResult: '',//结果
				roundDetail: '',//详情
				roundStatus: '',//状态
				roundName: this.$store.getters.userFullName,//查房人员
				roundCode: this.$store.getters.userCode,//查房人员code
				remark: '',//描述
				careReceiverCode: '',
				careReceiverName: '',
				groupId: '',
				orderCode: '',
				orgCode: '',
				orgName: '',
				pageNum: 1,
				pageSize: 10,
			},
			addRoundsFormRules: {
				roundResult: [
					{ required: true, message: '请选择结果', trigger: 'change' }
				],
				roundStatus: [
					{ required: true, message: '请选择状态', trigger: 'change' }
				],
				roundDetail: [
					{ required: true, message: '请填写详情', trigger: 'blur' }
				],
				roundName: [
					{
						required: true,
						message: "请输入姓名",
						trigger: "input"
					}
				],

			},
			searchLoading: false,
			cancleDisabled: false,
			dialogAdd: false,
			roundResultOptions: [],
			roundStatusOptions: [],
			recommend: [],
			editRecommend: [],
			examList: [],
			titleName: '',
			isEdit: false,
			lastObj: {

			}


		};
	},

	watch: {},
	computed: {},
	methods: {
		sendMessgae (row) {
			let params = {
				id: row.id
			}
			addMessage(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.$message.success('发送成功')
						this.getList(1)
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("addMessage:" + error);
					return false;
				});
		},
		selectStaffName (item) {
			if (item.value !== "无") {
				this.addRoundsForm.recommendCode = item.code;
				this.addRoundsForm.roundName = item.value;
			} else {
				this.addRoundsForm.roundName = "";
			}
		},
		removeStaffCode () {
			this.addRoundsForm.recommendCode = "";
			this.addRoundsForm.roundName = "";
		},
		queryStaffName (queryString, cb) {
			let params = {
				pageNum: 1,
				pageSize: 10,
				staffFullName: queryString,
				isDataAuthority: 0
			};
			findStaffAll(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.recommend = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.recommend.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel
							});
						}
						var results = this.recommend;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		selectEditStaffName (item) {
			if (item.value !== "无") {
				this.editRoundsForm.recommendCode = item.code;
				this.editRoundsForm.roundName = item.value;
			} else {
				this.editRoundsForm.roundName = "";
			}
		},
		removeEditStaffCode () {
			this.editRoundsForm.recommendCode = "";
			this.editRoundsForm.roundName = "";
		},
		queryEditStaffName (queryString, cb) {
			let params = {
				pageNum: 1,
				pageSize: 10,
				staffFullName: queryString,
				isDataAuthority: 0
			};
			findStaffAll(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.editRecommend = [];
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.editRecommend.push({
								value: data[i].staffFullName,
								code: data[i].staffCode,
								staffTel: data[i].staffTel
							});
						}
						var results = this.editRecommend;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		addRecord (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					// if (this.addRoundsForm.groupId == '') {
					this.cancleDisabled = true
					/* 新增 */
					var params = {
						orgCode: this.careReceiver.orgCode,
						orgName: this.careReceiver.orgName,
						roundResult: this.addRoundsForm.roundResult,
						roundDetail: this.addRoundsForm.roundDetail,
						roundStatus: this.addRoundsForm.roundStatus,
						roundType: this.addRoundsForm.roundType,
						// roundDate: this.addRoundsForm.roundDate,
						roundName: this.addRoundsForm.roundName,
						roundCode: this.addRoundsForm.roundCode,
						pageNum: this.addRoundsForm.pageNum,
						pageSize: this.addRoundsForm.pageSize,
						careReceiverCode: this.careReceiver.careReceiverCode,
						careReceiverName: this.careReceiver.careReceiverName,
						orderCode: this.careReceiver.orderCode,
						groupId: '',
						remark: this.addRoundsForm.remark
					};
					insertDeviceOrderRound(params)
						.then(response => {
							if (response.data.statusCode === "200") {
								this.cancleDisabled = false
								this.dialogAdd = false;
								this.$refs.addRoundsForm.resetFields();
								this.$message.success("新增成功");
								this.getList(1);
							} else {
								this.cancleDisabled = false
								this.$message.error(response.data.statusMsg);
								return false;
							}
						})
						.catch(error => {
							this.cancleDisabled = false
							console.log("insertDeviceOrderRound:" + error);
							return false;
						});
					// }
				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			})
		},
		cancelAddBtn () {
			this.dialogAdd = false
			this.$refs.addRoundsForm.resetFields();
		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.searchLoading = true;
			this.roundsForm.pageNum = page;
			var params = {
				pageNum: page,
				pageSize: this.roundsForm.pageSize,
				orderCode: this.careReceiver.orderCode,
				roundDateB:
					this.roundsForm.roundsDate != null ? this.roundsForm.roundsDate[0] : null,
				roundDateE:
					this.roundsForm.roundsDate != null ? this.roundsForm.roundsDate[1] : null,
			}
			findDeviceOrderRoundList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
						this.searchLoading = false;

					} else {
						this.$message.error(response.data.statusMsg);
						this.searchLoading = false;
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.listLoading = false;
					this.searchLoading = false;
				});
		},
		// //获取当前时间
		// getNowTime () {
		// 	getNow()
		// 		.then(response => {
		// 			if (
		// 				response.data.statusCode === 200 ||
		// 				response.data.statusCode === "200"
		// 			) {
		// 				this.addRoundsForm.roundDate = timestampChangeDate(Number(response.data.responseData))
		// 				this.editRoundsForm.roundDate = timestampChangeDate(Number(response.data.responseData))
		// 			} else {
		// 				this.$message.error(response.data.statusMsg);
		// 				return false;
		// 			}
		// 		})
		// 		.catch(error => {
		// 			console.log(error);
		// 		});
		// },
		//父组件触发事件
		pageChange (val) {
			this.roundsForm.page = val.page;
			this.roundsForm.pageSize = val.limit;
			this.getList(val.page);
		},
		addTo () {
			this.dialogAdd = true
		},
		handleAddClose () {
			this.dialogAdd = false
			this.$refs.addRoundsForm.resetFields();
		},
		examine (groupId, status) {
			if (status == '1') {
				this.titleName = '查看'
				this.isEdit = false
			} else if (status == '2') {
				this.titleName = '编辑'
				this.isEdit = true
				this.editRoundsForm.groupId = groupId
			}
			let params = {
				groupId: groupId
			}
			getDeviceOrderRound(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode == "200"
					) {
						if (response.data.responseData) {
							this.dialogExamine = true
							this.examList = response.data.responseData
							this.lastObj = this.examList[this.examList.length - 1]
							this.editRoundsForm = { ...this.lastObj }
						} else {
							this.$message.error(response.data.statusMsg);
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("getDeviceOrderRound:" + error);
					return false;
				});
		},

		editRounds (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					this.cancleDisabled = true
					/* 编辑 */
					var params = {
						orgCode: this.careReceiver.orgCode,
						orgName: this.careReceiver.orgName,
						roundResult: this.editRoundsForm.roundResult,
						roundDetail: this.editRoundsForm.roundDetail,
						roundStatus: this.editRoundsForm.roundStatus,
						roundType: this.editRoundsForm.roundType,
						// roundDate: this.editRoundsForm.roundDate,
						roundName: this.editRoundsForm.roundName,
						roundCode: this.editRoundsForm.roundCode,
						pageNum: this.editRoundsForm.pageNum,
						pageSize: this.editRoundsForm.pageSize,
						groupId: this.editRoundsForm.groupId,
						careReceiverCode: this.careReceiver.careReceiverCode,
						careReceiverName: this.careReceiver.careReceiverName,
						orderCode: this.careReceiver.orderCode,
						remark: this.editRoundsForm.remark
					};
					insertDeviceOrderRound(params)
						.then(response => {
							if (response.data.statusCode === "200") {
								this.cancleDisabled = false
								this.dialogExamine = false;
								this.$refs.editRoundsForm.resetFields();
								this.editRoundsForm.groupId = ''
								this.$message.success("新增成功");
								this.isEdit = true
								this.isShow = true;
								this.isRound = false;
								this.getList(1);
							} else {
								this.cancleDisabled = false
								this.$message.error(response.data.statusMsg);
								return false;
							}
						})
						.catch(error => {
							this.cancleDisabled = false
							console.log("insertDeviceOrderRound:" + error);
							return false;
						});

				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			})
		},


		updateRecord () {
			this.isShow = false;
			this.isRound = true
			// this.getNowTime()
		},
		cancelEditBtn () {
			this.dialogExamine = false
			this.isShow = true;
			this.isRound = false;
			this.$refs.editRoundsForm.resetFields();
		},
		handleExamineClose () {
			this.dialogExamine = false
			this.$refs.editRoundsForm.resetFields();
		},
		getBirthday (item) {
			return getBirthdayFromIdentityCard(item.careReceiverIdCard);
		},
		getAge (item) {
			return getAgeFromIdentityCard(item.careReceiverIdCard);
		},

		btnBack () {
			this.$router.go(-1);
		},
		/**
	 *
	 * 数据字典
	 *
	 */
		initDataDictionary () {
			//查房状态
			findValueBySetCode({ valueSetCode: "ROUND_STATUS" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.roundStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			//查房结果
			findValueBySetCode({ valueSetCode: "ROUND_RESULT" })
				.then(response => {
					if (response.data.statusCode == "200") {
						this.roundResultOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}
	},
	created () {
		this.initDataDictionary();
		this.careReceiver = JSON.parse(this.$route.query.careReceiver);
		console.log(this.careReceiver, '999999')
		// this.getNowTime()
	},
	mounted () {
		this.getList(1)
	}
};
</script>
<style lang="scss" scoped>
#medicineChestList {
	width: 100%;
	min-width: 1024px;
	.seettingTop {
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
		border-radius: 6px;
		margin: 0px 20px 20px 20px;
		display: flex;
		.info-left {
			.person-detail {
				padding: 30px 75px 23px 55px;
			}
			.person-info {
				margin-left: 38px;
				margin-bottom: 45px;
				span {
					font-size: 14px;
					color: #333333;
				}
				.person-color {
					width: 45px;
					border-radius: 25px;
					background-color: #f04b5f;
					color: white;
					padding: 2px 6px 2px 6px;
				}
			}
		}
	}
	.tableToolbar {
	}
	.tableContent {
		padding: 35px 38px 6px 38px;
		border-bottom: 1px solid #cccccc;
	}
}

.el-form-item {
	margin-bottom: 20px;
}
.form-item {
	width: 30%;
	min-width: 295px;
}
.el-select {
	width: 200px;
}
.el-date-editor--daterange.el-input__inner {
	width: 250px;
}
.info-text {
	margin-top: 25px;
	font-size: 14px;
	color: #666666;
	color: #333333;
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.search_btn {
	width: 30%;
	min-width: 295px;
	margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 20px 20px 20px 0px;
}
.remark-style {
	display: block;
	width: 200px;
}
.el-timeline-item__content {
	// width: 300px;
	p {
		margin: 6px 0;
	}
}
.el-card__body {
	p {
		line-height: 22px;
	}
}
::v-deep .el-timeline-item__timestamp.is-top {
	position: absolute;
	left: -146px;
	top: -3px;
	color: #333333;
	font-size: 14px;
}
::v-deep .el-timeline {
	padding-left: 150px;
}
</style>