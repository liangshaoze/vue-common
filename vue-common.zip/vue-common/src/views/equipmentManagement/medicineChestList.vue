<template>
	<div id="medicineChestList">
		<headTag :tagName="tagName" />
		<div class="seettingTop">
			<div class="info-left">
				<div class="person-detail">
					<img
						style="width:60px;height:60px;"
						src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
					/>
				</div>
				<div class="person-info">
					<span>{{careReceiver.careReceiverName}}</span>
					<!-- <span class="person-color">{{careReceiver.isLiveAlone=='0'?"非独居":'独居'}}</span> -->
					<span class="person-color" v-if="careReceiver.isLiveAlone=='1'">独居</span>
				</div>
			</div>
			<div class="info-right" style="width:100%;padding:30px 0;">
				<div class="basic-info">
					<el-row>
						<el-col :span="22" style="font-size:16px;color:#333333;">基本信息</el-col>
						<el-col :span="2" style="font-size:16px;color:#333333;">
							<el-button type="primary" size="mini" @click="btnBack">返回</el-button>
						</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">年龄：{{getAge(careReceiver)}}</el-col>
						<el-col class="info-text" :span="8">性别：{{careReceiver.careReceiverGenderValue}}</el-col>
						<el-col class="info-text" :span="8">生日：{{getBirthday(careReceiver)}}</el-col>
					</el-row>
					<el-row>
						<el-col
							class="info-text"
						>地址：{{careReceiver.liveProvinceName+careReceiver.liveCityName+careReceiver.liveDistrictName+careReceiver.liveSubdistrictName+careReceiver.liveDetailAddress}}</el-col>
					</el-row>
				</div>
			</div>
		</div>
		<div class="medicInfo">
			<el-tabs class="tabClass" v-model="tabName" type="card" @tab-click="handleClick">
				<el-tab-pane
					:key="index"
					v-for="(item,index) in medicOptions"
					:label="item.value"
					:name="item.name"
					:orderItemCode="item.orderItemCode"
				>
					<div>
						<div style="margin-top:35px;">
							<span class="form-tag">服药信息</span>
							<el-row style="padding:30px 44px 30px 10px;">
								<!-- <el-col v-if="medicInfo.drugCount" class="info-text" :span="6">当前剂量：{{medicInfo.drugCount}}</el-col> -->
								<el-col class="info-text" :span="6">剩余总剂量：{{medicInfo.surplusDrugCount}}</el-col>
								<el-col class="info-text" :span="6">每天剂量：{{medicInfo.drugNum}}</el-col>
								<el-col class="info-text" :span="6">更新时间：{{medicInfo.updateDate}}</el-col>
							</el-row>
						</div>
						<div>
							<div class="medic_wrap">
								<el-form ref="mediciInfoForm" :inline="true" :model="mediciForm" label-width="65px">
									<!-- <el-form-item label="药箱:" prop="deviceName">
									<el-select size="mini" v-model.trim="mediciForm.deviceName" clearable placeholder="请选择药箱">
										<el-option
											v-for="item in medicOptions"
											:key="item.value"
											:label="item.name"
											:value="item.value"
										/>
									</el-select>
									</el-form-item>-->
									<el-form-item label="时间:" prop="queryTime">
										<el-date-picker
											size="mini"
											v-model.trim="mediciForm.queryTime"
											format="yyyy-MM-dd HH:mm:ss"
											value-format="yyyy-MM-dd HH:mm:ss"
											type="datetimerange"
											range-separator="至"
											style="width:350px;"
											start-placeholder="开始日期"
											end-placeholder="结束日期"
										></el-date-picker>
									</el-form-item>
									<el-button
										@click="queryData(1)"
										icon="el-icon-search"
										size="mini"
										type="primary"
										style="margin:4px 0 0 15px;"
									>查询</el-button>
								</el-form>
							</div>
							<el-table
								:data="medicData"
								:header-cell-style="{
                 background: 'rgba(57, 138, 241, 0.1)',
                 color: '#606266'
        }"
								element-loading-text="拼命加载中"
								highlight-current-row
								size="mini"
								stripe
								style="margin-top:40px;"
								v-loading="listLoading"
							>
								<!-- <el-table-column label="药箱" min-width="100" prop="deviceName"></el-table-column> -->
								<el-table-column label="提醒时间" min-width="100">
									<template slot-scope="scope">
										<span v-if="scope.row.dataDate">{{scope.row.dataDate.substr(-8,8)}}</span>
									</template>
								</el-table-column>
								<el-table-column label="消息内容" min-width="100" prop="dataValue"></el-table-column>
								<el-table-column label="取药时间" prop="createDate"></el-table-column>
							</el-table>
							<el-row class="pageToolbar">
								<pagination
									:limit.sync="mediciForm.pageSize"
									:page.sync="mediciForm.pageNum"
									:total="mediciTotalCount"
									@pagination="pageChange"
									v-if="mediciTotalCount > 0"
								/>
							</el-row>
						</div>
					</div>
				</el-tab-pane>
			</el-tabs>
		</div>

		<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
			<org-select v-on:listenTochildEvent="getCurrentNode" />
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";

import {	findOrderDeviceByClass,
	findDeviceOrderDataByNo, getDeviceMessageType, getMedicineInfo} from "@/api/equipmentManagement"
export default {
	components: {
		HeadTag,
		OrgSelect,
		Pagination
	},
	props: {},
	data () {
		return {
			tagName: "药箱管理",
			tabName: "0",
			mediciForm: {
				name: "",
				deviceId: "",
				queryTime: "",
				createDate: "",
				dataStatus: "",//消息类型
				dataDateB: "",
				dataDateE: "",
				deviceName: "",
				deviceCode: "",
				dataCode: "MEDICINE_BOX_TAKING_MEDICINE",
				deviceOrderItems: [
					{
						orderItemCode: "SBZDD2006150001",
						deviceCode: "设备CODE",
						deviceName: "设备名称",
						deviceRawNo: "设备原no"
					}
				],
				pageNum: 1,
				pageSize: 10
			},
			filterDevices: [],

			mediciTotalCount: 0,
			eventOptions: [],
			statusOptions: [],
			medicData: [],
			dialogVisible: false,
			listLoading: false,
			medicOptions: [],
			medicInfo: {},
			careReceiver: {

			},
			orderItemCode: '',
			deviceName: ''
		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClick (tab, event) {
			if (tab) {
				this.mediciForm.deviceName = tab.label
				this.orderItemCode = tab.$attrs.orderItemCode
				this.medicineInfo()
				this.queryData(1, this.mediciForm.deviceName);
			}
		},
		btnBack () {
			this.$router.go(-1);

		},
		close () {
			this.dialogVisible = false;
		},
		getCurrentNode (data) {
			this.mediciForm.orgName = data.orgName;
			this.mediciForm.orgCode = data.orgCode;
			this.close();
		},
		//清空组织过滤
		clearOrgCode () {
			this.mediciForm.orgName = "";
			this.mediciForm.orgCode = "";
		},
		getBirthday (item) {
			return getBirthdayFromIdentityCard(item.careReceiverIdCard);
		},
		getAge (item) {
			return getAgeFromIdentityCard(item.careReceiverIdCard);
		},
		resetForm () {

		},
		findOrderDevices () {
			var params = {
				orderCode: this.careReceiver.orderCode,
				careReceiverCode: this.careReceiver.careReceiverCode,
				deviceClassCode: this.careReceiver.deviceClassCode,
				deviceClassName: this.careReceiver.deviceClassName
			}
			findOrderDeviceByClass(params).then(response => {
				if (response.data.statusCode == 200) {
					if (response.data.responseData) {
						this.filterDevices = response.data.responseData.devices;
						let medicList = response.data.responseData.deviceNames
						for (let i = 0; i < medicList.length; i++) {
							if (medicList[i].devices) {
								for (let j = 0; j < medicList[i].devices.length; j++) {
									this.medicOptions.push({
										orderItemCode: medicList[i].devices[j].orderItemCode, value: medicList[i].devices[j].deviceName, name: i.toString()
									})
								}
							}
						}
						console.log(this.medicOptions)
						this.medicineInfo(this.medicOptions[0].orderItemCode)
						this.queryData(1, this.medicOptions[0].value);
					}
				}
			}).catch(error => {

			})
		},
		medicineInfo (orderItemCode) {
			var params = {
				orderItemCode: orderItemCode ? orderItemCode : this.orderItemCode
			}
			getMedicineInfo(params).then(response => {
				if (response.data.statusCode == 200) {
					if (response.data.responseData) {
						this.medicInfo = response.data.responseData
					} else {
						this.medicInfo = {}
					}
				}
			}).catch(error => {

			})
		},

		// 列表数据
		queryData (page, deviceName) {
			this.listLoading = true;
			this.mediciForm.pageNum = page;
			if (this.mediciForm.queryTime) {
				this.mediciForm.dataDateB = this.mediciForm.queryTime[0];
				this.mediciForm.dataDateE = this.mediciForm.queryTime[1];
			} else {
				this.mediciForm.dataDateB = "";
				this.mediciForm.dataDateE = "";
			}
			this.mediciForm.deviceOrderItems = [];
			var deviceOrderItem = this.filterDevices.find(item => {
				return item.deviceName == this.mediciForm.deviceName;
			})
			console.log(this.filterDevices[0],'2222')
			if (deviceOrderItem) {
				this.mediciForm.deviceOrderItems.push(deviceOrderItem)
			} else {
				this.mediciForm.deviceName = this.filterDevices[0].deviceName;
				this.mediciForm.deviceOrderItems.push(this.filterDevices[0])
			}
			console.log(this.mediciForm, 'mediciForm')
			findDeviceOrderDataByNo(this.mediciForm)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.medicData = response.data.responseData;
						this.mediciTotalCount = response.data.totalCount;
						this.listLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.mediciForm.page = val.page;
			this.mediciForm.pageSize = val.limit;
			this.queryData(val.page);
		},

	},
	created () {
		this.careReceiver = JSON.parse(this.$route.query.careReceiver);
		this.findOrderDevices();//查询药箱
	},
	mounted () {

	}
};
</script>
<style lang="scss" scoped>
#medicineChestList {
	width: 100%;
	min-width: 1200px;
	.seettingTop {
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
		border-radius: 6px;
		// height: 270px;
		margin: 0px 20px 20px 20px;
		display: flex;
		.info-left {
			.person-detail {
				padding: 30px 75px 23px 55px;
			}
			.person-info {
				margin-left: 38px;
				margin-bottom: 45px;
				span {
					font-size: 14px;
					color: #333333;
				}
				.person-color {
					width: 45px;
					border-radius: 25px;
					background-color: #f04b5f;
					color: white;
					padding: 2px 6px 2px 6px;
				}
			}
		}
	}
	.medicInfo {
		margin: 0 20px 20px 20px;
		border: 0.1px solid #e0e6eb;
		border-bottom-left-radius: 0px;
		border-bottom-right-radius: 0px;
		border-top-left-radius: 6px;
		border-top-right-radius: 6px;
		background: rgba(255, 255, 255, 1);
		padding: 18px 0 29px 20px;
		.form-tag {
			font-size: 16px;
			border-left: 5px solid #f98c3c;
			padding-left: 10px;
			font-weight: 550;
		}
	}
	.tableToolbar {
		// padding: 20px 50px 0 50px;
	}
}
.medic_wrap {
	background-color: #fff;
	border-top: 1px solid #cccccc;
	padding-top: 30px;
	// padding: 20px;
	// border-radius: 10px;
	// margin: 0px 20px 10px -20px;
}
.el-form-item {
	margin-bottom: 0px;
}
.form-item {
	width: 30%;
	min-width: 295px;
}
.el-select {
	width: 200px;
}
.el-date-editor--daterange.el-input__inner {
	width: 250px;
}
.info-text {
	margin-top: 25px;
	font-size: 14px;
	color: #666666;
	color: #333333;
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.search_btn {
	width: 30%;
	min-width: 295px;
	margin-left: 90px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	// padding: 10px 20px 10px 0px;
}
</style>