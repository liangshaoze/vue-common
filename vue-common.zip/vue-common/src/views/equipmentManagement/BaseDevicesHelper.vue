<template></template>

<script>
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";
export default {
  data() {
    return {
      //查看监控
      dialogMonitor: false,
      //日报|周报
      dailyOrWeeklyDialog: false,
      clickedReceiver: {},
      careReceiver: {}
    };
  },
  methods: {
    jumpByDeviceItem(deviceItem) {
      var path = "";
      switch (deviceItem.deviceClassCode) {
        case "ZNCD": //智能床垫
          this.clickedReceiver = this.getReceiver(deviceItem);
          this.dailyOrWeeklyDialog = true;
          return;
          break;
        case "DDJC": //跌倒监测
          //TODO
          break;
        case "JKSB": //监控设备
          this.clickedReceiver = this.getReceiver(deviceItem);
          this.dialogMonitor = true;
          return;
          break;
        case "MCGYQ": //门磁感应器
          path = "/wisdomCustody/accessControlList";
          break;
        case "RQTCQ": //燃气探测器
          path = "/wisdomCustody/gasDevicesList";
          break;
        case "YWTCQ": //烟雾探测器
          path = "/wisdomCustody/smokeSensationList";
          break;
        case "ZNYX": //智能药箱
          path = "/wisdomCustody/medicineChestList";
          break;
      }
      this.EventBus.post("screenFullEvent",{isFullScreen:false});
      this.$router.push({
        path: path,
        query: {
          careReceiver: JSON.stringify(this.getReceiver(deviceItem))
        }
      });
    },
    //查房
    toRoundsList(obj) {
      this.EventBus.post("screenFullEvent",{isFullScreen:false});
      this.$router.push({
        path: "/wisdomCustody/roundsList",
        query: {
          careReceiver: JSON.stringify(this.getReceiver(obj))
        }
      });
    },
    //报警
    toRemind(obj) {
      this.EventBus.post("screenFullEvent",{isFullScreen:false});
      this.$router.push({
        path: "/wisdomCustody/alarmList",
        query: {
          careReceiver: JSON.stringify(obj),
          type: "1"
        }
      });
    },
    //设置
    toSettings(obj) {
      this.EventBus.post("screenFullEvent",{isFullScreen:false});
      this.$router.push({
        path: "/wisdomCustody/equipSettings",
        query: {
          careReceiver: JSON.stringify(obj)
        }
      });
    },
    getReceiver(obj) {
      var careReceiverCode = obj.careReceiverCode;
      var careReceiver = this.customerList.find(item => {
        return item.careReceiverCode == careReceiverCode;
      });
      if (!careReceiver) {
        return {};
      }
      careReceiver.deviceClassCode = obj.deviceClassCode;
      careReceiver.deviceClassName = obj.deviceClassName;
      return careReceiver;
    },
    handleClose() {
      this.dialogMonitor = false;
      this.dailyOrWeeklyDialog = false;
    },
    //显示监控页面
    showMonitor() {
      this.dialogMonitor = true;
    },
    //显示日报/周报
    showReport() {
      this.dailyOrWeeklyDialog = true;
    },
    showRightMenu() {
      alert("右键菜单");
    },
    getBirthday(item) {
      return getBirthdayFromIdentityCard(item.careReceiverIdCard);
    },
    getAge(item) {
      return getAgeFromIdentityCard(item.careReceiverIdCard);
    },
    toOrderInfo(careReceiver) {
      this.EventBus.post("screenFullEvent",{isFullScreen:false});
      this.$router.push({
        path: "/wisdomCustody/orderEquipmentAdd",
        query: {
          type: "update",
          orderCode: careReceiver.orderCode
        }
      });
    },
    getIconClass(dataStatus) {
      switch (dataStatus) {
        case "体动":
          return "equip-status-kinesis";
        case "掉线":
          return "equip-status-offline";
        case "离床":
          return "equip-status-outofbed";
        case "静卧":
          return "equip-status-repose";
        case "静止":
          return "equip-status-rest";
        case "运动":
          return "equip-status-activity";
        case "摔倒":
          return "equip-status-fall";
      }
      return "";
    }
  }
};
</script>

