<template>
  <div>
    <div class="seettingTop">
      <div class="info-left">
        <div class="person-detail">
          <!--头像-->
          <span v-if="careReceiver.careReceiverIcon" slot="reference">
            <el-avatar
              size="large"
              style="vertical-align: middle;"
              :src="careReceiver.careReceiverIcon"
              class="avatar"
            ></el-avatar>
          </span>
          <span v-else slot="reference">
            <svg-icon icon-class="equip-avatar-default" class="avatar" />
          </span>
        </div>
        <div class="person-info">
          <span>{{careReceiver.careReceiverName}}</span>
          <span class="person-color" v-if="careReceiver.isLiveAlone=='1'">独居</span>
        </div>
      </div>
      <div style="width:100%;padding:10px">
        <div>
          <div style="margin-top:20px;height:20px">
            <div style="font-size:16px;color:#333333;">基本信息</div>
          </div>
          <div style="margin-top:20px;height:20px;display:flex;justify-content:space-between;">
            <div style="font-size:16px">年龄:{{getAge(careReceiver)}}</div>
            <div style="font-size:16px">性别:{{careReceiver.careReceiverGenderValue}}</div>
            <div style="font-size:16px">生日:{{getBirthday(careReceiver)}}</div>
          </div>
          <div style="margin-top:20px;height:20px">
            <div
            style="font-size:16px"
            >地址:{{careReceiver.liveProvinceName+careReceiver.liveCityName+careReceiver.liveDistrictName+careReceiver.liveSubdistrictName+careReceiver.liveDetailAddress}}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <el-tabs class="tabClass" @tab-click="handleClick" type="border-card" v-model="activeName" v-if="monitorDevices.length>0">
        <el-tab-pane v-for="(item,index) in monitorDevices" :key="index" :label="item.deviceName" :name="index+''">
          <div class="room-monitor">
             <video
              :id="'myPlayer'+index"
              style="width: 100%;height: 360px;"
              poster
              controls
              playsinline
              webkit-playsinline
              autoplay
            >
              <source :src="videoUrl" type="rtmp/flv" />
            </video>  
            <!-- <div :id="'myPlayer'+index" style="width:600px;height:600px"></div> -->
          </div>
        </el-tab-pane>
        <!-- <el-tab-pane label="厨房" name="second">
           <video
              id="myPlayer"
              style="width: 100%;height: 360px;"
              poster
              controls
              playsinline
              webkit-playsinline
              autoplay
            >
              <source :src="videoUrl" type="rtmp/flv" />
            </video>
        </el-tab-pane>
        <el-tab-pane label="客厅" name="third">
           <video
              id="myPlayer"
              style="width: 100%;height: 360px;"
              poster
              controls
              playsinline
              webkit-playsinline
              autoplay
            >
              <source :src="videoUrl" type="rtmp/flv" />
            </video>
        </el-tab-pane> -->
      </el-tabs>
       <div class="no-data" v-if="monitorDevices.length==0">暂无监控数据</div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import { findSysUserList } from "api/systemManagement/index.js";
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget";
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";
import { findOrderDeviceByClass,testHealth} from "@/api/equipmentManagement";
export default {
  components: {},
  props: {
    careReceiver: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      searchLoading: false,
      dialogDetail: false,
      mediciTotalCount: 0,
      activeName: "0",
      player: null,
      videoUrl:"",
      monitorDevices:[],
    };
  },
  watch: {},
  computed: {},
  mounted() {
    this.findOrderDevices();
  },
  methods: {
    handleClick(tab, event) {
      this.videoUrl = this.monitorDevices[this.activeName].url;
      this.getInfoPath();
    },
    /**
     * 视频监控
     */
    getInfoPath() {
      // this.videoUrl = item.playerUrl
      setTimeout(() => {
        // this.player = new EZUIKit.EZUIPlayer("myPlayer"+this.activeName);
        this.player =  new EZUIKit.EZUIPlayer({
          autoplay: true,
          id: "myPlayer"+this.activeName,
          // accessToken:"at.0ynxyw4o0z679n851ap5z1rm6trzkk4z-3ut4sme89t-18ldong-pr2280tzp",
          // url: "rtmp://rtmp01open.ys7.com/openlive/02ea182aa12f47939c7bc3f7bee8e649.hd",
          url:this.videoUrl,
          template: "standard", // simple - 极简版;standard-标准版;security - 安防版(预览回放);voice-语音版；
          // 视频上方头部控件
          //header: ["capturePicture", "save", "zoom"], // 如果templete参数不为simple,该字段将被覆盖
          //plugin: ['talk'],                       // 加载插件，talk-对讲
          // 视频下方底部控件
          // footer: ["talk", "broadcast", "hd", "fullScreen"], // 如果template参数不为simple,该字段将被覆盖
          // audio: 1, // 是否默认开启声音 0 - 关闭 1 - 开启
          openSoundCallBack: data => console.log("开启声音回调", data),
          closeSoundCallBack: data => console.log("关闭声音回调", data),
          startSaveCallBack: data => console.log("开始录像回调", data),
          stopSaveCallBack: data => console.log("录像回调", data),
          capturePictureCallBack: data => console.log("截图成功回调", data),
          fullScreenCallBack: data => console.log("全屏回调", data),
          getOSDTimeCallBack: data => console.log("获取OSDTime回调", data),
          width: 600,
          height: 400
        });
        // try{
        //    this.player.on('log', (logStr)=>{
        //   console.log("player log==="+JSON.stringify(logStr))
        //   });
        // }catch(e){
        //   console.log(e)
        // }
       
      },1000)
      // if (this.videoUrl != "") {
      //   if (this.player != null) {
      //     setTimeout(() => {
      //       var oldUrl = this.player.opt.currentSource;
      //       this.player.opt.currentSource = this.videoUrl;
      //       this.player.opt.sources[0] = this.videoUrl;
      //       this.player.video.innerHTML = this.player.video.innerHTML.replace(
      //         oldUrl,
      //         this.videoUrl
      //       );
      //       this.player.videoFlash.innerHTML = this.player.videoFlash.innerHTML.replace(
      //         oldUrl,
      //         this.videoUrl
      //       );
      //     }, 2000);
      //   } else {
      //     setTimeout(() => {
      //       this.player = new EZUIPlayer("myPlayer");
      //     }, 2000);
      //   }
      // }
    },
    getBirthday(item) {
      return getBirthdayFromIdentityCard(item.careReceiverIdCard);
    },
    getAge(item) {
      return getAgeFromIdentityCard(item.careReceiverIdCard);
    },
     findOrderDevices(){
      var params = {
        orderCode: this.careReceiver.orderCode,
        careReceiverCode: this.careReceiver.careReceiverCode,
        deviceClassCode: this.careReceiver.deviceClassCode,
        deviceClassName: this.careReceiver.deviceClassName
      }
      findOrderDeviceByClass(params).then(response=>{
        if(response.data.statusCode==200){
          if(response.data.responseData){
            var devices=response.data.responseData.devices;
            this.monitorDevices=[];
            devices.forEach(item=>{
              if(item.deviceConfig){
                var monitorDevice = JSON.parse(item.deviceConfig)||{};
                monitorDevice.deviceName = item.deviceName;
                this.monitorDevices.push(monitorDevice);
              }
            })
            if(this.monitorDevices[0]){
              this.videoUrl = this.monitorDevices[0].url;
            }
            if(this.monitorDevices.length>0){
                this.getInfoPath();
            }
            
          }
        }
      }).catch(error=>{

      })
    },
  },
  created() {}
};
</script>
<style lang="scss" scoped>
.seettingTop {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
  // height: 270px;
  display: flex;
  .info-left {
    .person-detail {
      padding: 30px 75px 10px 40px;
    }
    .person-info {
      margin-left: 20px;
      margin-bottom: 40px;
      span {
        font-size: 16px;
        color: #333333;
      }
      .person-color {
        background: rgba(240, 75, 95, 1);
        border-radius: 10px;
        color: #ffffff;
        margin-left: 10px;
        padding: 4px;
        font-size: 14px;
      }
    }
  }
}
.container {
  // background-color: #fff;
  // box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  // border-radius: 6px;
  margin-top: 20px;
  .tabClass {
    border-radius: 5px;
    // border: 1px solid #e0e0e0;
    .room-monitor {
      padding: 10px;
      align-items: center;
      display: flex;
      align-content: center;
    }
  }
}
.avatar {
  width: 60px;
  height: 60px;
  cursor: pointer;
}
.no-data{
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100px;
  background: #ffffff;
  color: #999;
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
}
</style>