<template>
	<div id="monitoringSettings">
		<headTag :tagName="tagName" />
		<div>
			<personInfo :settingObj="settingObj" :familyInDtoList="familyInDtoList" />
		</div>
		<div class="main-content">
			<div class="panel-card">
				<span class="form-tag">硬件设备</span>
				<span>
					<el-button
						type="primary"
						size="small"
						class="rightBtn"
						:loading="loadingBtn"
						@click="btnBack"
					>返回</el-button>
				</span>
			</div>
			<div class="main-box">
				<div class="main-left">
					<ul class="equipment-box">
						<li v-for="(item,index) in settingNameList" :key="index">
							<div class="left-title" @click="showToggle(item,index)">
								<div class="setting_title" :id="'jump'+index">
									<img :src="item.isSubShow==true ? imgRight:imgLeft" />
									<span class="scroll-item">{{item.deviceClassName}}</span>
								</div>
							</div>
							<div class="contentForm">
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='JKSB'">
									<monitor :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='ZNCD'">
									<mattress :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='ZNYX'">
									<medicine :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='DDJC'">
									<!-- <fall :equipmentList="item.deviceList" @selectList="selectList" /> -->
									<fall :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='YWTCQ'">
									<smokeAlarm :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='RQTCQ'">
									<gasAlarm :equipmentList="item.deviceList" />
								</div>
								<div class="settingForm" v-if="item.isSubShow&&item.deviceClassCode=='MCGYQ'">
									<gateAlarm :equipmentList="item.deviceList" />
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="main-right" id="nav-fixed" :class="{nav_fixed : isFixed}">
					<ul class="menu-right">
						<li
							v-for="(item,index) in settingNameList"
							:key="index"
							:class="activeStep === index ? 'colorClass':''"
							@click="jump(index)"
						>{{item.deviceClassName}}</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import PersonInfo from "./components/personInfo"
import Monitor from "./components/monitor"
import GasAlarm from "./components/gasAlarm"
import SmokeAlarm from "./components/smokeAlarm"
import Mattress from "./components/mattress"
import Medicine from "./components/medicine"
import Fall from "./components/fall"
import GateAlarm from "./components/gateAlarm"

import {
	findDeviceSettingByOrderCode
} from "api/equipmentManagement/device";
const cubic = value => Math.pow(value, 3);
const easyInOutCubic = value =>
	value < 0.5
		? cubic(value * 2) / 2
		: 1 - cubic((1 - value) * 2) / 2;
export default {
	components: {
		HeadTag,
		OrgSelect,
		Pagination,
		PersonInfo,
		Monitor,
		GasAlarm,
		SmokeAlarm,
		Mattress,
		Medicine,
		Fall,
		GateAlarm
	},
	props: {},
	data () {
		return {
			tagName: "设置",
			activeStep: 0,
			lastOffsetTop: 0,
			isJump: false,
			loadingBtn: false,
			keyWords: {
				orgName: '',
				eventStatus: '',
				alarmTime: '',
				careReceiverName: '',
				userStatus: '',
				pageNum: 1,
				pageSize: 10
			},
			equipmentList: [],
			familyInDtoList: [

			],
			roundForm: {

			},
			settingNameList: [
			],
			// value1: '',
			imgLeft: process.env.NODE_ENV === 'development' ? '/static/img/up-icon.png' : '/fsk/static/img/up-icon.png',
			imgRight: process.env.NODE_ENV === 'development' ? '/static/img/down-icon.png' : '/fsk/static/img/down-icon.png',
			totalCount: 0,
			eventOptions: [],
			tableData: [],
			statusOptions: [],
			settingObj: {},
			dialogVisible: false,
			// listLoading: false,
			isFixed: true,
			offsetTop: 0,
			careReceiver: {}, //传入数据
			loadingBtn: false,
		};
	},
	watch: {},
	computed: {},
	methods: {
		btnBack () {
			this.$router.go(-1);

		},
		selectList (orderCode) {
			this.getDeviceSetting(orderCode)
		},
		showToggle (item, index) {
			this.settingNameList.forEach(i => {
				// 判断如果数据中的reportList[i]的show属性不等于当前数据的isSubShow属性那么reportList[i]等于false
				if (i.isSubShow !== this.settingNameList[index].isSubShow) {
					// i.isSubShow = true;
					i.isSubShow = !this.settingNameList[index].isSubShow;
				}
			});
			item.isSubShow = !item.isSubShow;
			this.$forceUpdate()
		},
		jump (domId) {
			this.activeStep = domId
			//获取头部是否固定
			let headerFlag = this.$store.state.settings.fixedHeader;
			// 当前窗口正中心位置到指定dom位置的距离
			//页面滚动了的距离
			let height =
				window.pageYOffset ||
				document.documentElement.scrollTop ||
				document.body.scrollTop;

			//指定dom到页面顶端的距离
			let dom = document.getElementById('jump' + domId);
			let domHeight;

			if (headerFlag) {
				domHeight = dom.offsetTop - 60;
			} else {
				domHeight = dom.offsetTop + 40;
			}
			//滚动距离计算
			var S = Number(height) - Number(domHeight);

			//判断上滚还是下滚
			if (S < 0) {
				//下滚
				S = Math.abs(S);
				window.scrollBy({ top: S, behavior: "smooth" });
			} else if (S == 0) {
				//不滚
				window.scrollBy({ top: 0, behavior: "smooth" });
			} else {
				//上滚
				S = -S;
				window.scrollBy({ top: S, behavior: "smooth" });
			}
			// const container = document.querySelector(".main-left");
			// var raf = window.requestAnimationFrame || (func => setTimeout(func, 16));
			// const beginTime = Date.now();
			// var animationFunc = (timeStample) => {
			// 	const progress = (Date.now() - beginTime) / 500;
			// 	window.scrollTo({
			// 		top:
			// 			domHeight + (this.lastOffsetTop - domHeight) * (1 - easyInOutCubic(progress)),
			// 	});
			// 	if (progress < 1) {
			// 		this.isJump = true;
			// 		raf(animationFunc);
			// 	} else {
			// 		this.lastOffsetTop = domHeight;
			// 		setTimeout(() => {
			// 			this.isJump = false;
			// 		}, 16);
			// 	}
			// };
			// raf(animationFunc);
		},
		// 滚动监听  滚动触发的效果写在这里
		handleScroll () {
			// if (this.isJump) {
			// 	return;
			// }
			var scrollTop =
				window.pageYOffset ||
				document.documentElement.scrollTop ||
				document.body.scrollTop;
			if (scrollTop >= this.offsetTop) {
				this.isFixed = true;
			} else {
				this.isFixed = false;
			}
			// if (scrollTop) {
			// 	for (let i = 0; i < this.settingNameList.length; i++) {
			// 		let currentItem = document.querySelector("#jump" + i);
			// 		let nextItem = document.querySelector("#jump" + (i + 1));
			// 		if (
			// 			nextItem &&
			// 			scrollTop > currentItem.offsetTop - 60 &&
			// 			scrollTop < nextItem.offsetTop - 60
			// 		) {
			// 			this.activeStep = i;
			// 			this.lastOffsetTop = currentItem.offsetTop - 60;
			// 		}
			// 	}
			// }
		},
		// 列表数据
		getDeviceSetting (orderCode) {
			let params = {
				orderCode: orderCode
			}
			findDeviceSettingByOrderCode(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.settingObj = response.data.responseData.careReceiver //个人信息
						this.familyInDtoList = response.data.responseData.familyInDtoList //监护人
						this.settingNameList = response.data.responseData.deviceClass//所有设备类型
						if (this.settingNameList.length > 0) {
							for (let i = 0; i < this.settingNameList.length; i++) {
								this.settingNameList[i].isSubShow = true;
								// this.settingNameList[i].type = i+Number(1);
							}
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.keyWords.page = val.page;
			this.keyWords.pageSize = val.limit;
			this.getList(val.page);
		},
	},
	destroyed () {
		// 设置bar浮动阈值为 #fixedBar 至页面顶部的距离
		this.offsetTop = document.querySelector("#nav-fixed").offsetTop;
		// 开启滚动监听
		window.removeEventListener("scroll", this.handleScroll);
	},
	created () {
		this.careReceiver = JSON.parse(this.$route.query.careReceiver);
		this.getDeviceSetting(this.careReceiver.orderCode)
	},
	mounted () {
		// 离开页面 关闭监听 不然会报错
		window.addEventListener("scroll", this.handleScroll);
	}
};
</script>
<style lang="scss" scoped>
#monitoringSettings {
	width: 100%;
	min-width: 1400px;
	.main-content {
		border-radius: 10px;
		background: #fff;
		margin: 0px 20px 20px 20px;
		border-radius: 10px;
		.panel-card {
			border-top-left-radius: 10px;
			border-top-right-radius: 10px;
			padding: 24px 0 24px 17px;
			background-color: #f9f9f9;
			border-bottom: 1px solid #e6e6e6;
			.form-tag {
				font-size: 20px;
				border-left: 5px solid #f98c3c;
				padding-left: 10px;
			}
			.rightBtn {
				float: right;
				margin-right: 45px;
			}
		}
		.main-box {
			display: flex;
			.main-left {
				background: #ffffff;
				width: 90%;
				.equipment-box {
					list-style: none;
					li {
						padding: 30px 25px 30px 30px;
						.left-title {
							.setting_title {
								vertical-align: middle;
								img {
									width: 12px;
									height: 12px;
									color: #666666;
									display: inline-block;
									margin: 0 4px;
									vertical-align: middle;
									transition: 0.5s;
									transform-origin: center;
									transform: rotateZ(360deg);
								}
								img:active {
									width: 12px;
									height: 12px;
									color: #666666;
									display: inline-block;
									margin: 0 4px;
									vertical-align: middle;
									transition: transform 0.3s;
									transform-origin: center;
									transform: rotateX(-45deg);
								}
								.scroll-item {
									color: #333333;
									font-size: 16px;
									font-family: 'Adobe Heiti Std R';
									vertical-align: middle;
								}
							}
						}
					}
					.contentForm {
						// padding: 14px 0 14px 0;
						border-bottom: 1px solid #ededed;
						margin-left: 30px;
						margin-right: 24px;
						margin-top: 30px;
						.settingForm {
							.titleName {
								color: #333333;
								font-size: 16px;
								margin: 25px 0 20px 0;
							}
							.rightBtn {
								float: right;
								margin-right: 20px;
							}
						}
					}
				}
			}
			.main-right {
				background: #ffffff;
				position: fixed; /*fixed总是以body为定位时的对象，总是根据浏览器的窗口来进行元素的定位，通过"left"、 "top"、 "right"、 "bottom" 属性进行定位。*/
				right: 18px; /*设置与右侧的距离*/
				top: 466px; /*设置与底部的距离*/
				width: 10%;
				height: 300px;
				.menu-right {
					background: #ffffffff;
					line-height: 34px;
					overflow-y: scroll;
					list-style: none;
					height: 300px;
					border: 1px solid #e4e5e6;
					li {
						padding: 0 0 14px 15px;
						font-size: 14px;
						font-family: 'Adobe Heiti Std';
						// font-weight: 600;
						color: #333333;
						cursor: pointer;
					}
					.colorClass {
						font-size: 14px;
						color: #398af1;
						font-family: 'Adobe Heiti Std';
						font-weight: 600;
						border-left: 1px solid #398af1;
						cursor: pointer;
					}
				}
			}
		}
	}
}
.info-text {
	margin-top: 25px;
	font-size: 16px;
	color: #666666;
	font-family: Adobe Heiti Std;
}
.titleFormName {
	margin: 20px 0 20px 35px;
}

.el-select {
	width: 200px;
}

.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
.timedate {
	width: 290px;
}
.seetingBottom {
	font-size: 16px;
	color: #333333;
	margin-bottom: 20px;
}
.el-form-item__label {
	font-size: 16px;
	color: #333333;
	font-weight: normal !important;
}
.titleText {
	margin: 15px 0 25px 0;
	color: #333333;
	font-size: 16px;
}
</style>

