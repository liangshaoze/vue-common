<template>
  <div id="homeIndex">
    <el-form>
      <el-row>
        <el-col v-if="customerList.length==0">
          <div class="no-data">暂无数据</div>
        </el-col>
        <el-col style="width:330px;" v-for="(item,index) in customerList" :key="index">
          <div id="chartSex" :class="item.alarmCount <= 0?'div_shoadow':'div_shoadow_anim'">
            <el-row type="flex" justify="center" style="align-items:center">
              <el-popover placement="right" width="300" trigger="hover">
                <!--弹出内容-->
                <div style="padding-left:10px">
                  <div style="display:flex">
                    <span style="color:#333;font-size:20px">{{item.careReceiverName}}</span>
                    <span style="color:#333;font-size:14px"></span>
                  </div>
                  <div style="display:flex;margin-top:5px">
                    <span style="color:#333;font-size:14px">{{getBirthday(item)}}</span>
                    <span
                      style="color:#333;font-size:14px;margin-left:20px"
                    >{{item.careReceiverTel}}</span>
                  </div>
                  <div
                    style="display:flex;margin-top:5px"
                    v-if="item.familyInDtoList&&item.familyInDtoList.length>0"
                  >
                    <span
                      style="color:#333;font-size:14px"
                    >{{item.familyInDtoList[0].familyMemberName}}</span>
                    <span
                      style="color:#333;font-size:14px;margin-left:20px"
                    >{{item.familyInDtoList[0].contactsTel}}</span>
                    <span
                      style="color:#F04B5F;font-size:14px;background-color:rgba(240,75,95,0.2);margin-left:20px"
                    >紧急联系人</span>
                  </div>
                  <div style="display:flex;margin-top:5px">
                    <span
                      style="color:#666;font-size:14px"
                    >{{item.liveProvinceName+item.liveCityName+item.liveDistrictName+item.liveSubdistrictName+item.liveDetailAddress}}</span>
                  </div>
                </div>
                <!--头像-->
                <span v-if="item.careReceiverIcon" slot="reference" @click="toOrderInfo(item)">
                  <el-avatar
                    size="large"
                    style="vertical-align: middle;"
                    :src="item.careReceiverIcon"
                    class="avatar"
                  ></el-avatar>
                </span>
                <span v-else slot="reference" @click="toOrderInfo(item)">
                  <!-- <el-avatar
                    size="large"
                    style="vertical-align: middle;"
                    src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
                  ></el-avatar>-->
                  <svg-icon icon-class="equip-avatar-default" class="avatar" />
                </span>
              </el-popover>
              <div style="width:100%;margin-left:10px">
                <div class="customer-settings">
                  <div class="info">
                    <span
                      style="color:#333;font-size:16px;max-width:148px;text-overflow:ellipsis;overflow:hidden;white-space: nowrap;"
                    >{{item.careReceiverName}}</span>
                    
                    <!-- <svg-icon
                      class="icon-info"
                      icon-class="equip-body-sign-on"
                      @click="toRoundsList(item)"
                    />-->
                    <!--生命体征-->
                  </div>
                  <div class="settings">
                     <!--查房-->
                  <el-tooltip effect="dark" content="查房" placement="top">
                    <svg-icon
                      class="icon-info"
                      icon-class="equip-ward-round-on"
                      @click="toRoundsList(item)"
                    />
                  </el-tooltip>
                    <el-badge
                      :value="item.alarmCount"
                      :max="99"
                      class="item"
                      :hidden="item.alarmCount<=0"
                    >
                      <svg-icon
                        class="icon-remind"
                        icon-class="equip-remind"
                        @click="toRemind(item)"
                      />
                    </el-badge>
                    <svg-icon
                      class="icon-settings"
                      icon-class="equip-settings"
                      @click="toSettings(item)"
                    />
                  </div>
                </div>
                <div style="display:flex">
                  <span
                      style="color:#333;font-size:16px;"
                    >{{item.careReceiverGenderValue}}</span>
                    <span style="color:#333;font-size:16px;margin-left:5px">{{getAge(item)}}</span>
                    <span class="live-status" v-if="item.isLiveAlone!='0'">独居</span>
                </div>
              </div>
            </el-row>
            <el-row
              type="flex"
              justify="space-between"
              style="margin-top:5px;align-items:center;height:65px"
            >
              <div>
                <div>
                  <div class="customer-status">
                    <svg-icon class="icon-status" icon-class="equip-heart-rate" />
                    <span style="color:#999;font-size:14px;margin-left:5px">心率</span>
                     <span style="color:#333;font-size:18px;margin-left:5px">{{item.userData&&item.userData.data&&item.userData.data.breath?item.userData.data.heartbeat:""}}</span>
                    <span
                      style="color:#999;font-size:16px;margin-left:5px"
                    >{{item.userData&&item.userData.data&&item.userData.data.heartbeat?'次/分':"--"}}</span>
                  </div>
                </div>
                <div style="margin-top:10px">
                  <div class="customer-status">
                    <svg-icon class="icon-status" icon-class="equip-breath" />
                    <span style="color:#999;font-size:14px;margin-left:5px">呼吸</span>
                    <span style="color:#333;font-size:18px;margin-left:5px">{{item.userData&&item.userData.data&&item.userData.data.breath?item.userData.data.breath:""}}</span>
                    <span
                      style="color:#999;font-size:16px;margin-left:5px"
                    >{{item.userData&&item.userData.data&&item.userData.data.breath?'次/分':"--"}}</span>
                  </div>
                </div>
              </div>
              <div style="margin-right:20px">
                <div class="customer-status" v-if="item.userData&&item.userData.dataStatus&&getIconClass(item.userData.dataStatus)">
                  <el-tooltip effect="dark" :content="item.userData.dataStatus" placement="top">
                    <svg-icon
                      :class="item.userData.dataStatus=='摔倒'?'svg-fall':'svg-bling'"
                      :iconClass="getIconClass(item.userData.dataStatus)"
                    />
                  </el-tooltip>
                </div>
                <div class="no-data" v-else>暂无信息</div>
              </div>
            </el-row>
            <div class="device-list">
              <div v-for="(deviceItem,index) in item.deviceList" :key="index">
                <EquipItem
                  v-if="updateDeviceItem(deviceItem)&&index<5"
                  :deviceItem="deviceItem"
                  @click="jumpByDeviceItem(deviceItem)"
                />
                <el-popover
                  placement="top"
                  width="300"
                  trigger="hover"
                  offset="130"
                  v-if="index==5"
                >
                  <div class="device-list-more">
                    <div
                      v-for="moreDeviceItem in getMoreItemList(item.deviceList)"
                      :key="moreDeviceItem"
                    >
                      <EquipItem
                        v-if="updateDeviceItem(moreDeviceItem)"
                        :deviceItem="moreDeviceItem"
                        @click="jumpByDeviceItem(moreDeviceItem)"
                      />
                    </div>
                  </div>
                  <div style="justify-content:center;align-items:center" slot="reference">
                    <svg-icon class="icon-device" icon-class="equip-more" />
                    <div style="color:#666;margin-top:5px;test-size:10px">更多</div>
                  </div>
                </el-popover>
              </div>
            </div>
            <!-- <a>老人卡片</a> -->
          </div>
        </el-col>
      </el-row>
    </el-form>
    <!-- 监控弹窗 -->
    <el-dialog
      title="查看监控"
      v-if="dialogMonitor"
      :visible.sync="dialogMonitor"
      width="1000px"
      :before-close="handleClose"
      center
    >
      <Monitor @showMonitor="showMonitor" :careReceiver="clickedReceiver" />
    </el-dialog>

    <!-- 日报/周报 -->
    <el-dialog
      title="睡眠报告"
      v-if="dailyOrWeeklyDialog"
      :visible.sync="dailyOrWeeklyDialog"
      width="1000px"
      top="5vh"
      :before-close="handleClose"
      center
    >
      <DailyAndWeekly @showReport="showReport" :careReceiver="clickedReceiver" />
    </el-dialog>
  </div>
</template>

<script>
import BaseDevicesHelper from "./BaseDevicesHelper";
import Monitor from "./MonitorList";
import DailyAndWeekly from "./dailyAndWeekly";
import EquipItem from "./components/EquipItem";
export default {
  mixins: [BaseDevicesHelper],
  components: {
    Monitor,
    DailyAndWeekly,
    EquipItem
  },
  data() {
    return {
      onLine: "10",
      assessInfoForm: {
        contentFirst: "",
        contentTwo: ""
      }
    };
  },
  props: {
    customerList: {
      type: Array,
      default: () => []
    }
  },
  created() {
    var that = this;
    this.EventBus.handleEvent("receivedMsg", function(val) {
      val = JSON.parse(val);
      if (val && val.userData) {
        var careReceiver = that.customerList.find(
          item => item.careReceiverCode == val.careReceiverCode
        );
        careReceiver.deviceList = val.deviceList;
        if (
          careReceiver &&
          val.userData &&
          val.userData.deviceClassCode &&
          val.userData.deviceClassCode == "ZNCD"||////智能床垫
          val.userData.deviceClassCode == "DDJC"//跌倒监测
        ) {
          if (val.userData) {
            careReceiver.userData = val.userData;
          }
          that.$forceUpdate();
          return;
        }
      }
      //alarmCount
      var careReceiver = that.customerList.find(
        item => item.careReceiverCode == val.careReceiverCode
      );
      if (careReceiver&&val.alarmCount) {
        careReceiver.alarmCount = val.alarmCount||0;
        careReceiver.deviceList = val.deviceList;
      }
      that.$forceUpdate();
    });
    // this.EventBus.handleEvent("receivedMsgAll", function(val) {
    //   if (val) {
    //     val = JSON.parse(val);
    //     var careReceiver = that.customerList.find(
    //       item => item.careReceiverCode == val.careReceiverCode
    //     );
    //     if (careReceiver) {
    //       //智能床垫
    //       careReceiver.alarmCount = val.data.count;
    //       careReceiver.alarmType = val.data.alarmType;
    //       careReceiver.alarmEvent = val.data.alarmEvent;
    //       that.$forceUpdate();
    //     }
    //   }
    // });
  },
  mounted() {
    this.$watch("customerList", () => {
      var ids = this.customerList.map(item => item.careReceiverCode);
      this.WebSocketHelper.initWebSocketBySmart(this, ids);
    });
  },
  methods: {
    updateDeviceItem(deviceItem) {
      switch (deviceItem.deviceClassCode) {
        case "ZNCD": //智能床垫
          deviceItem.onlineClass = "equip-bed-online";
          deviceItem.offlineClass = "equip-bed-offline";
          deviceItem.deviceName = "床垫";
          break;
        case "DDJC": //跌倒监测
          deviceItem.onlineClass = "equip-fall-alarm-on";
          deviceItem.offlineClass = "equip-fall-alarm-off";
          deviceItem.deviceName = "跌倒";
          break;
        case "JKSB": //监控设备
          deviceItem.onlineClass = "equip-monitor-on";
          deviceItem.offlineClass = "equip-monitor-off";
          deviceItem.deviceName = "监控";
          break;
        case "MCGYQ": //门磁感应器
          deviceItem.onlineClass = "equip-access-control-on";
          deviceItem.offlineClass = "equip-access-control-off";
          deviceItem.deviceName = "门禁";
          break;
        case "RQTCQ": //燃气探测器
          deviceItem.onlineClass = "equip-gas-on";
          deviceItem.offlineClass = "equip-gas-off";
          deviceItem.deviceName = "燃气";
          break;
        case "YWTCQ": //烟雾探测器
          deviceItem.onlineClass = "equip-smoke-sensation-on";
          deviceItem.offlineClass = "equip-smoke-sensation-off";
          deviceItem.deviceName = "烟感";
          break;
        case "ZNYX": //智能药箱
          deviceItem.onlineClass = "equip-medicine-chest-on";
          deviceItem.offlineClass = "equip-medicine-chest-ff";
          deviceItem.deviceName = "药箱";
          break;
      }
      return true;
    },
    getMoreItemList(deviceList) {
      //超过6个设备
      var list = deviceList.filter((item, index) => {
        if (index >= 5) {
          return item;
        }
      });
      return list;
    }
  }
};
</script>

<style lang="scss" scoped>
.chart-container {
  width: 100%;
  float: left;
}

.el-col {
  padding-right: 15px;
}

.div_shoadow {
  width: 310px;
  height: 215px;
  color: #333;
  box-shadow: 1px 1px 3px #cccccc;
  margin: 5px;
  padding: 8px;
  border-radius: 8px;
}
.div_shoadow_anim {
  width: 310px;
  height: 215px;
  color: #333;
  margin: 5px;
  padding: 8px;
  border-radius: 8px;
  animation: myBounce 1s linear infinite, myBorder 1s linear infinite;
  background-color: #fff;
  position: relative;
  box-shadow: 0 0 3px 1px red;
  &:hover {
    animation-play-state: paused;
  }
}

@keyframes myBounce {
  from,
  20%,
  53%,
  80%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    transform: translate3d(0, 0, 0);
  }

  40%,
  43% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -4px, 0);
    box-shadow: 0 0 6px 2px red;
  }

  70% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -3px, 0);
    box-shadow: 0 0 5px 1.6px red;
  }

  90% {
    transform: translate3d(0, -1px, 0);
    box-shadow: 0 0 4px 1.2px red;
  }
}
@keyframes myBorder {
  from,
  20%,
  53%,
  80%,
  to {
  }

  40%,
  43% {
    box-shadow: 0 0 6px 2px red;
  }

  70% {
    box-shadow: 0 0 5px 1.6px red;
  }

  90% {
    box-shadow: 0 0 4px 1.2px red;
  }
}
@keyframes myPulse {
  from {
    transform: scale3d(1, 1, 1);
    border: 1px solid red;
  }

  50% {
    transform: scale3d(1.02, 1.02, 1.02);
    border: 3px solid red;
  }

  to {
    transform: scale3d(1, 1, 1);
    border: 1px solid red;
  }
}
@keyframes myShake {
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(-2px, 0, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(2px, 0, 0);
  }
}

.tipFont {
  font-size: 16px;
}
.avatar {
  width: 45px;
  height: 45px;
  cursor: pointer;
}
.customer-settings {
  height: 35px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .info {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  .settings {
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
.icon-info {
  width: 25px;
  height: 25px;
  cursor: pointer;
}
.icon-remind {
  width: 15px;
  height: 15px;
  margin-left: 10px;
  cursor: pointer;
}
.icon-settings {
  width: 15px;
  height: 15px;
  margin-left: 15px;
  cursor: pointer;
  margin-top: 2px;
}
.icon-device {
  width: 30px;
  height: 30px;
  cursor: pointer;
}
.icon-status {
  width: 25px;
  height: 25px;
}
.customer-status {
  display: flex;
  align-items: center;
}
.no-data {
  font-size: 14px;
  color: #999;
}
.v-line {
  height: 20px;
  width: 1px;
  background-color: #cccccc;
}
.device-list {
  margin-top: 15px;
  display: grid;
  grid-template-columns: 50px 50px 50px 50px 50px 50px;
  grid-row-gap: 20px;
  height: 50px;
}
.device-list-more {
  display: grid;
  grid-template-columns: 50px 50px 50px 50px 50px 50px;
  grid-row-gap: 20px;
}
.live-status {
  width: 45px;
  border-radius: 25px;
  background-color: #f04b5f;
  color: white;
  display: flex;
  justify-content: center;
  padding: 2px 6px 2px 6px;
  margin-left: 5px;
}
.no-data {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 50px;
}
.bounce-enter-active {
  animation: bounce-in 0.5s;
}
.bounce-leave-active {
  animation: bounce-in 0.5s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}
.svg-fall {
  animation: fall 2s linear infinite;
  width: 65px;
  height: 65px;
  vertical-align: text-bottom;
}
@keyframes fall {
  0% {
    opacity: 0.1;
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }

  10% {
    opacity: 1;
    -webkit-transform: rotate(5deg);
    -moz-transform: rotate(5deg);
    -ms-transform: rotate(5deg);
    transform: rotate(5deg);
  }

  49% {
    opacity: 0.5;
    -webkit-transform: rotate(25deg);
    -moz-transform: rotate(25deg);
    -ms-transform: rotate(25deg);
    transform: rotate(25deg);
  }

  98% {
    opacity: 0;
    -webkit-transform: rotate(5deg);
    -moz-transform: rotate(5deg);
    -ms-transform: rotate(5deg);
    transform: rotate(5deg);
  }

  100% {
    opacity: 0.1;
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
  }
}
.svg-bling {
  animation: bling 2s linear infinite;
  width: 65px;
  height: 65px;
  vertical-align: text-bottom;
}
@keyframes bling {
  0% {
    opacity: 0.1;
  }

  10% {
    opacity: 1;
  }

  49% {
    opacity: 0.5;
  }

  98% {
    opacity: 0;
  }

  100% {
    opacity: 0.1;
  }
}

$green: #4cd964;
$syan: #5ac8fa;
$blue: #007aff;
$purple: #5856d6;
$magenta: #ff2d70;
$red: #ff3b30;
$orange: #ff9500;
$yellow: #ffcc00;
$gray: #8e8e93;
//定义需要实现的按钮名和颜色，键值对
$btn-types: (
  "nomal": white,
  "primary": $blue,
  "success": $green,
  "danger": $red,
  "warning": $orange,
  "second": $gray
);
/**
把一些常用的需要多平台适配的（-webkit-）做成mixin方便调用，写的时候代码也简洁
像这种还有box-shadow transform transition animation 等等
一般在项目中都单独定义成一个文件 _utility.scss,直接引用使用，也方便
*/
@mixin border-radius($value) {
  -webkit-border-radius: $value;
  -moz-border-radius: $value;
  border-radius: $value;
}
/**
 这里定义最常用的通用方法，比如 .link .btn .block .hidden
 一般保存为_normalize.scss文件
*/
.unselectable {
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
//.btn只放button最基础的行为和动作
.btn {
  padding: 6px 10px;
  text-align: center;
  font-size: 1rem;
  cursor: pointer;
  margin-right: 5px;
  @extend .unselectable;
  @include border-radius(5px);
  &:active {
    transform: translateY(2px);
  }
}
@each $name, $color in $btn-types {
  .btn-#{$name} {
    @if $name == normal {
      color: #333;
      border: 1px solid darken($color, 20%);
    } @else {
      color: white;
      border: 1px solid darken($color, 5%);
    }
    background-color: $color;
    &:hover {
      background-color: lighten($color, 5%);
    }
    &:active {
      border-color: transparent;
      background-color: darken($color, 5%);
    }
  }
}
</style>
