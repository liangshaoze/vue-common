<template>
  <div id="equipList">
    <headTag :tagName="tagName" v-if="!isFullScreen" />

    <!-- 搜索筛选 -->
    <div class="search_wrap" v-if="!isFullScreen">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="80px">
        <CommonPropertyWidget
          @queryMethod="queryMethod"
          @clearEvent="clearEvent"
          :propertyList="queryPropertyList"
          :resultItem="filters"
        >
          <el-col class="form-item" slot="append">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="queryGetList()"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
          <el-form-item slot="deviceClassName" prop="deviceRunningStatus">
            <el-select
              size="mini"
              clearable
              :placeholder="'请选择消息类型'"
              v-model="filters.deviceRunningStatus"
              style="width:95px;margin-left:5px"
            >
              <el-option
                v-for="item in msgTypeOptions"
                :key="item.value"
                :label="item.name"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </CommonPropertyWidget>
      </el-form>
    </div>
    <div class="tableToolbar" :style="{minWidth:'1024px',marginTop:isFullScreen?'20px':'0px'}">
      <!--操作按钮-->
      <el-row class="optBtns" type="flex" justify="space-between">
        <div style="display:flex">
          <div
            class="change-btn"
            :style="{backgroundColor:isPanelList?'#398AF1':'#fff',cursor:'pointer'}"
            @click="isPanelList=true"
          >
            <svg-icon
              :icon-class="isPanelList?'equip-panel-checked':'equip-panel-uncheck'"
              class="btn-img"
            />
            <span :style="{color:isPanelList?'#fff':'#333',fontSize:'14px'}">面板</span>
          </div>
          <div
            class="change-btn"
            :style="{backgroundColor:!isPanelList?'#398AF1':'#fff',cursor:'pointer',marginLeft:'10px'}"
            @click="isPanelList=false"
          >
            <svg-icon
              :icon-class="isPanelList?'equip-list-uncheck':'equip-list-checked'"
              class="btn-img"
            />
            <span :style="{color:!isPanelList?'#fff':'#333',fontSize:'14px'}">列表</span>
          </div>
        </div>
        <div>
          <svg-icon :icon-class="!isFullScreen?'equip-screen-full':'equip-screen-full-cancel'" @click="doScreenfull" style="cursor:pointer"/>
          <!-- <el-button size="mini" type="primary" @click="doScreenfull">{{!isFullScreen?'全屏':'取消全屏'}}</el-button> -->
        </div>
      </el-row>
      <!--九宫格-->
      <div class="grid-list" v-if="isPanelList">
        <IndexGrid
          :customerList="customerList"
          v-loading="listLoading"
          element-loading-text="拼命加载中"
        />
      </div>
      <!--列表-->
      <div class="common-list" v-if="!isPanelList">
        <el-table
          :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
          stripe
          size="mini"
          :data="customerList"
          v-loading="listLoading"
          highlight-current-row
          element-loading-text="拼命加载中"
        >
          <el-table-column label="机构" min-width="150" prop="orgName"></el-table-column>
          <el-table-column label="姓名" min-width="100" prop="careReceiverName"></el-table-column>
          <el-table-column label="是否独居" width="100" prop="isLiveAloneValue"></el-table-column>
          <el-table-column label="性别" width="50" prop="careReceiverGenderValue"></el-table-column>
          <el-table-column label="电话" min-width="100" prop="careReceiverTel"></el-table-column>
          <el-table-column label="地址" min-width="200" prop="liveDetailAddress"></el-table-column>
          <!-- <el-table-column label="生命体征" min-width="135" prop="vitalSigns">
           <template slot-scope="scope">
            <el-button size="mini" type="text" ><svg-icon icon-class="equip-list-scan"></svg-icon>查看</el-button>
          </template>
          </el-table-column>-->
          <el-table-column label="设备" min-width="150" prop="deviceList">
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="text"
                v-for="item in scope.row.deviceList"
                :key="item"
                @click="deviceBtnClick(item)"
              >{{item.deviceClassName}}</el-button>
              <!-- <el-button size="mini" type="text" v-if="scope.row.device.monitor">监控</el-button> -->
            </template>
          </el-table-column>
          <el-table-column fixed="right" width="140" label="操作">
            <template slot-scope="scope">
              <el-button size="mini" type="text" @click="toRemind(scope.row)">
                <svg-icon icon-class="equip-list-remind"></svg-icon>告警
              </el-button>
              <el-button size="mini" type="text" @click="toSettings(scope.row)">
                <svg-icon icon-class="equip-list-setting"></svg-icon>设置
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.pageNum"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
      <!-- <iframe 
      width="100%"
      height="600px"
      src="http://org.yymedic.com/guardians/58635cd37c049da077996918/users/5dd797c25a445d0001131d03/userSleepReport?date=2020-06-07&tab=weekly&onlyShowContent=true">
      </iframe>-->
    </div>
    <!-- 监控弹窗 -->
    <el-dialog
      title="查看监控"
      v-if="dialogMonitor"
      :visible.sync="dialogMonitor"
      width="1000px"
      :before-close="handleClose"
      center
    >
      <Monitor @showMonitor="showMonitor" :careReceiver="clickedReceiver" />
    </el-dialog>

    <!-- 日报/周报 -->
    <el-dialog
      title="睡眠报告"
      v-if="dailyOrWeeklyDialog"
      :visible.sync="dailyOrWeeklyDialog"
      width="1000px"
      top="5vh"
      :before-close="handleClose"
      center
    >
      <DailyAndWeekly @showReport="showReport" :careReceiver="clickedReceiver" />
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common";
import { changeYMD } from "utils";
import { isMoney } from "utils/validate.js";
import { export_json_to_excel } from "@/utils/Export2Excel.js";
import OrgSelect from "components/OrgSelect";
import axios from "axios";
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget";
import IndexGrid from "./indexGrid";
import {
  findIotList,
  findOrderDeviceByClass,
  getDeviceMessageType
} from "@/api/equipmentManagement";
import BaseDevicesHelper from "./BaseDevicesHelper";
import Monitor from "./MonitorList";
import DailyAndWeekly from "./dailyAndWeekly";
import screenfull from "screenfull";
export default {
  data() {
    return {
      tagName: "智能监护",
      treeData: [],
      orderStop: "",
      orderComplete: "",
      //控制查询按钮加载
      searchLoading: false,
      isDisabled: false,
      title: null,
      tableData: [],
      isPanelList: true,
      msgTypeOptions: [],
      //条件查询
      filters: {
        orgCode: this.$store.getters.userOrgCode,
        orgName: this.$store.getters.userOrgName,
        deviceClassCode: "", //设备分类code
        deviceClassName: "", //设备分类名称
        deviceRunningStatus: "",
        deviceOnlineStatus: "", //设备状态
        isLiveAlone: "", //是否独居
        careReceiverCode: "", //被照护人CODE
        careReceiverName: "", //被照护人姓名
        pageNum: 1,
        pageSize: 10
      },
      listLoading: false,
      queryPropertyList: [
        {
          propertyName: "组织",
          propertyFieldName: "orgName",
          propertyType: "60" //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "设备类型",
          propertyFieldName: "deviceClassName",
          additionFieldName: "deviceClassCode",
          propertyType: "50", //属性类别，10输入框，20单项选择框,21单项级联选择，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
          valueSetCode: "DEVICE_CLASS",
          style: "width:100px",
          queryMethod: "findDeviceMessageType",
          clearEvent: "clearDeviceClass"
          // selectChangeMethod:"findDeviceMessageType",
          // relationFieldName:"status",
          // relationOptions:[],
        },
        {
          propertyName: "在线状态",
          propertyFieldName: "deviceOnlineStatus",
          optionKeyFieldName: "value",
          optionValueFieldName: "name", //可选项值对应的value的字段名
          valueSetCode: "DEVICE_ONLINE_STATUS",
          propertyType: "20" //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "姓名",
          propertyFieldName: "careReceiverName",
          propertyType: "10" //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "是否独居",
          propertyFieldName: "isLiveAlone",
          propertyType: "20",
          optionKeyFieldName: "value",
          optionValueFieldName: "name", //可选项值对应的value的字段名
          valueSetCode: "YES_OR_NO"
        }
      ],
      customerList: [],
      totalCount: 0,
      // 全屏/不全屏
      isFullScreen: false,
      originWidth: 0
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect,
    CommonPropertyWidget,
    IndexGrid,
    Monitor,
    DailyAndWeekly
  },
  mixins: [IndexGrid],
  created() {},
  methods: {
    queryPropertyType(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        productName: queryString
      };
      findEtProductByDataAuthority(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.options = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.options.push({
                value: data[i].productName,
                code: data[i].productCode
              });
            }
            var results = this.options;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEtProductByDataAuthority:" + error);
          return false;
        });
    },
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    clearEvent(obj) {
      this[obj.clearEvent]();
    },
    getList() {
      this.searchLoading = true;
      this.listLoading = true;
      findIotList(this.filters)
        .then(response => {
          this.searchLoading = false;
          this.listLoading = false;
          if (response.data.statusCode == 200) {
            if (response.data.responseData) {
              this.customerList = response.data.responseData;
              this.totalCount = response.data.totalCount;
            }
          }
        })
        .catch(error => {
          this.searchLoading = false;
          this.listLoading = false;
        });
    },
    queryGetList() {
      this.filters.pageNum = 1;
      this.getList();
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.deviceClassCode = "";
      // this.filters.pageNum=1
      this.getList();
    },
    //父组件触发事件
    pageChange(val) {
      this.filters.pageNum = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page); //改变页码，重新渲染页面
    },
    deviceBtnClick(item) {
      this.jumpByDeviceItem(item);
    },
    findDeviceMessageType() {
      this.msgTypeOptions = [];
      this.filters.deviceRunningStatus = "";
      var deviceClassCode = this.filters.deviceClassCode;
      if (!deviceClassCode) {
        return;
      }
      var params = {
        deviceClassCode: deviceClassCode,
        deviceMessageTypeCode: "status"
      };
      getDeviceMessageType(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.msgTypeOptions = response.data.responseData.map(item => {
              return { value: item.name, name: item.name };
            });
          }
        })
        .catch(error => {});
    },
    clearDeviceClass() {
      this.filters.deviceRunningStatus = ""; //清空设备运行状态
    },
    doScreenfull() {
      this.isFullScreen = !this.isFullScreen;
      this.originWidth = document.querySelector("#equipList").offsetWidth;
      screenfull.toggle();
      screenfull.on('change', () => {
        if(screenfull.isFullscreen){
          //全屏时，要执行的操作
           this.EventBus.post("screenFullEvent", { isFullScreen: true});
        }else{
          //取消全屏时，要执行的操作
          this.isFullScreen = false;
          this.EventBus.post("screenFullEvent", { isFullScreen: false });
        }
      });
      //按esc键取消全屏，因scrennfull占用了esc键，需要按两次才能取消全屏状态，故注释掉
      // document.addEventListener("keydown",(event)=>{
      //   var e = event || window.event || arguments.callee.caller.arguments[0];  
      //   if(e && e.keyCode==27){ // 按 Esc   
      //       this.isFullScreen = false;
      //       this.EventBus.post("screenFullEvent", { isFullScreen: false });
      //     }  
      // })
    },
    // Esc 全屏监测
    checkFull() {
      let isFull =
        document.fullscreenEnabled ||
        window.fullScreen ||
        document.webkitIsFullScreen ||
        document.msFullscreenEnabled;
      if (isFull === undefined) {
        isFull = false;
      }
      return isFull;
    },
    inFullCreeen(element) {
      debugger
    let el = element;
    let rfs =
      el.requestFullScreen ||
      el.webkitRequestFullScreen ||
      el.mozRequestFullScreen ||
      el.msRequestFullScreen;
    if (typeof rfs != "undefined" && rfs) {
      rfs.call(el);
    } else if (typeof window.ActiveXObject != "undefined") {
      let wscript = new ActiveXObject("WScript.Shell");
      if (wscript != null) {
        wscript.SendKeys("{F11}");
      }
    }
  },
  outFullCreeen(element) {
    let el = element;
    let cfs =
      el.cancelFullScreen ||
      el.webkitCancelFullScreen ||
      el.mozCancelFullScreen ||
      el.exitFullScreen;
    if (typeof cfs != "undefined" && cfs) {
      cfs.call(el);
    } else if (typeof window.ActiveXObject != "undefined") {
      let wscript = new ActiveXObject("WScript.Shell");
      if (wscript != null) {
        wscript.SendKeys("{F11}");
      }
    }
  }
  },
  mounted() {
    window.onresize = val => {
      // var changedScreenWidth = document.querySelector("#equipList")
      //   .offsetWidth;
      // if (this.originWidth > changedScreenWidth && this.isFullScreen) {
      //   this.isFullScreen = false;
      //   this.EventBus.post("screenFullEvent", { isFullScreen: false });
      // }
    };
  },
  activated() {
    this.getList();
  },
  watch:{
    $route(to,from){
      if(to.path != '/wisdomCustody/equipmentIndex'){
        this.WebSocketHelper.closeWebSocket();
      }
    }
}


  
};
</script>

<style lang="scss" scoped>
#orgSelect {
  height: 500px;
  overflow-y: auto;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 125px;
}
.el-autocomplete {
  width: 200px;
}
.search_wrap {
  min-width: 1024px;
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  margin: 0px 20px 10px 20px;
}
</style>
<style lang="scss">
.el-dialog__body {
  padding: 0px 20px;
}
.filter-input {
  width: 100%;
}
#orgSelect .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#orgSelect .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#orgSelect .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content {
  color: #f98c3c;
}
.change-btn {
  border-top-left-radius: 50px;
  border-top-right-radius: 50px;
  border-bottom-left-radius: 50px;
  border-bottom-right-radius: 50px;
  display: flex;
  padding: 5px;
  width: 70px;
  align-items: center;
}
.btn-img {
  width: 15px;
  height: 15px;
  margin-right: 5px;
}
.optBtns {
  padding-top: 10px;
  padding-bottom: 10px;
}
.el-autocomplete-suggestion {
  min-width: 150px;
}

.el-autocomplete-suggestion__wrap {
  min-width: 150px;
}
</style>
