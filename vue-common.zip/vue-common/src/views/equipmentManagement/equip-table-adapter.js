import BaseTableAdapter from 'components/widget/base-table-adapter'
export default {
    mixins: [BaseTableAdapter],
    data(){
        return {
            columns: [
                {
                  propertyName: "名称",
                  propertyFieldName: "deviceName",
                  propertyType: "10"
                },
                {
                  propertyName: "设备ID",
                  propertyFieldName: "deviceCode",
                  propertyType: "10",
                  width: "250"
                },
                {
                  propertyName: "消息类型",
                  propertyFieldName: "dataStatus",
                  propertyType: "10",
                  width: "200"
                },
                {
                  propertyName: "时间",
                  propertyFieldName: "dataDate",
                  propertyType: "10"
                },
                {
                  propertyName: "电量",
                  propertyFieldName: "dataValue",
                  propertyType: "10"
                }
              ],
        }
    },
    methods: {
    }
}