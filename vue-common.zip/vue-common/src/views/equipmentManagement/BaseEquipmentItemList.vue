<template>
  <div id="equipmentItemList">
    <div class="seettingTop">
      <div class="info-left">
        <div class="person-detail">
          <img
            style="width:60px;height:60px;"
            src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
          />
        </div>
        <div class="person-info">
          <span>{{careReceiver.careReceiverName}}</span>
          <span class="person-color" v-if="careReceiver.isLiveAlone!='0'">独居</span>
        </div>
      </div>
      <div class="info-right" style="width:100%;padding:30px 0;">
        <div class="basic-info">
          <el-row>
            <el-col :span="22" style="font-size:16px;color:#333333;">基本信息</el-col>
            <el-col :span="2" style="font-size:16px;color:#333333;">
              <el-button type="primary" size="mini" @click="btnBack">返回</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="info-text" :span="8">年龄:{{getAge(careReceiver)}}</el-col>
            <el-col class="info-text" :span="8">性别:{{careReceiver.careReceiverGenderValue}}</el-col>
            <el-col class="info-text" :span="8">生日:{{getBirthday(careReceiver)}}</el-col>
          </el-row>
          <el-row>
            <el-col class="info-text" >地址:{{careReceiver.liveProvinceName+careReceiver.liveCityName+careReceiver.liveDistrictName+careReceiver.liveSubdistrictName+careReceiver.liveDetailAddress}}</el-col>
          </el-row>
        </div>
      </div>
    </div>
    <div class="tableToolbar">
      <div class="search_wrap">
          <CommonSearchWidget
            @queryMethod="queryMethod"
            :propertyList="searchItems"
            :resultItem="searchModel"
            ref="CommonSearchWidget"
          >
            <el-col class="form-item" slot="append">
              <el-form-item></el-form-item>
            </el-col>
            <el-col class="form-item" slot="append">
              <el-form-item></el-form-item>
            </el-col>
            <el-col class="form-item" slot="append">
              <el-form-item>
                <el-button
                  size="mini"
                  type="primary"
                  icon="el-icon-search"
                  :loading="searchLoading"
                  style="margin-left:125px"
                  @click="queryData()"
                >查询</el-button>
                <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
              </el-form-item>
            </el-col>
          </CommonSearchWidget>
      </div>
        <CommonTableWidget
          @queryMethod="queryMethod"
          :formModel="tableFormModel"
          :tableDataName="'dataList'"
          :propertyList="columns"
          :loading ="tableLoading"
          ref="CommonTableWidget"
          :optWidth="80"
          :showTableIndex="false"
          :hasOptColumn="false"
          @pageChange="pageChange"
        >
          <el-button size="mini" type="text" @click="dialogDetail=true">查看</el-button>
        </CommonTableWidget>
    </div>
  </div>
</template>

<script>
import CommonSearchWidget from "components/widget/CommonSearchWidget";
import CommonTableWidget from "@/components/widget/CommonTableWidget";
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";
import EquipSearchAdapter from "./equip-search-adapter"
import EquipTableAdapter from "./equip-table-adapter"
export default {
  mixins:[EquipSearchAdapter,EquipTableAdapter],
  components: {
    CommonSearchWidget,
    CommonTableWidget
  },
  props: {},
  data() {
    return {
      dialogDetail: false,
      careReceiver:{},
    };
  },
  watch: {
    
  },
  computed: {},
  created() {
    this.careReceiver = JSON.parse(this.$route.query.careReceiver);
    this.findOrderDevices();
    this.findDeviceMessageType();
  },
  methods: {
    handleClose() {
      this.dialogDetail = false;
    },
    getBirthday(item) {
      return getBirthdayFromIdentityCard(item.careReceiverIdCard);
    },
    getAge(item) {
      return getAgeFromIdentityCard(item.careReceiverIdCard);
    },
    btnBack(){
      this.$router.go(-1);
    },
    pageChange(val){
      this.searchModel.pageNum = val.page;
      this.searchModel.pageSize = val.limit;
      this.queryData();
    }
  },
  mounted() {
    this.table = this.$refs["CommonTableWidget"];
    this.searcher = this.$refs["CommonSearchWidget"];
  }
};
</script>
<style lang="scss">
#equipmentItemList {
  width: 100%;
  min-width: 1200px;
  .seettingTop {
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
    border-radius: 6px;
    // height: 270px;
    margin: 0px 20px 20px 20px;
    display: flex;
    .info-left {
      .person-detail {
        padding: 30px 50px 23px 50px;
      }
      .person-info {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 45px;
        span {
          font-size: 16px;
          color: #333333;
        }
        .person-color {
          background: rgba(240, 75, 95, 1);
          border-radius: 10px;
          color: #ffffff;
          margin-left: 10px;
          padding: 4px;
          font-size: 14px;
        }
      }
    }
  }
  .tableToolbar {
    padding: 20px 20px 0 20px;
  }
}
.search_wrap {
  padding: 0px;
  margin: 0px 0px 10px 0px;
}
.el-form-item {
  margin-bottom: 0px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.el-select {
  width: 200px;
}
// .el-date-editor--daterange.el-input__inner {
//   width: 250px;
// }
.info-text {
  margin-top: 25px;
  font-size: 16px;
  color: #666666;
  font-family: Adobe Heiti Std;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}

.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
.search_btn {
  width: 30%;
  min-width: 295px;
  margin-left: 90px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
.el-date-editor--datetimerange.el-input,
.el-date-editor--datetimerange.el-input__inner {
  width: 280px;
  min-width: 170px;
}
.el-date-editor.el-range-editor.el-input__inner.el-date-editor--daterange.el-range-editor--mini{
  width: 260px;
}
</style>