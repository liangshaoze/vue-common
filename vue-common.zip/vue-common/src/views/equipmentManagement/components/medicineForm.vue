<template>
	<div id="medicineForm">
		<el-form ref="medicineForm" :inline="true" :model="medicineForm" label-width="125px">
			<div class="titleName">
				设备信息
				<el-button
					type="primary"
					size="mini"
					class="rightBtn"
					:loading="loadingBtn"
					v-if="isShow"
					@click="saveForm()"
				>保存</el-button>
				<el-button
					type="primary"
					size="mini"
					:loading="loadingBtn"
					@click="editForm()"
					class="rightBtn"
					v-if="!isShow"
				>修改</el-button>
			</div>
			<div style="margin-left:-60px;">
				<el-form-item label="型号：">{{formObj.deviceModelName}}</el-form-item>
				<el-form-item label="ID：">{{formObj.deviceCode}}</el-form-item>
				<el-form-item label="状态：">{{formObj.deviceOnlineStatus}}</el-form-item>
				<el-form-item label="更新时间：">{{formObj.updateDate}}</el-form-item>
			</div>
			<div style="margin-left:-49px;">
				<el-form-item label="总剂量：">{{config.drugCount}}</el-form-item>
				<el-form-item label="告警剂量：" style="margin-left:248px;">
					<span v-if="isEdit == false">{{config.alarmDose}}</span>
					<span v-if="isEdit == true">
						<el-input
							size="mini"
							v-model.trim="config.alarmDose"
							@blur="blurText($event)"
							clearable
							class="inputClass"
							placeholder="请输入正整数"
						></el-input>
					</span>
				</el-form-item>
			</div>
			<div style="margin-left:-36px;">
				<el-form-item label="服药次数：">{{config.drugNum}}</el-form-item>
				<el-form-item
					style="margin-left:248px;"
					label="每天服药时间："
				>第一次：{{config.drugTime1}} &nbsp;第二次：{{config.drugTime2}}&nbsp; 第三次：{{config.drugTime3}}&nbsp; 第四次：{{config.drugTime4}}</el-form-item>
			</div>

			<!-- <el-col>
				<el-col class="titleName">总剂量</el-col>
				<el-form-item label="总剂量:">
					{{config.drugCount}}
					<span v-if="isEdit == false">{{config.drugCount}}</span>
					<span v-if="isEdit == true">
						<el-input
							size="mini"
							v-model.trim="config.drugCount"
							clearable
							class="inputClass"
							placeholder="请输入正整数"
						></el-input>
					</span>
				</el-form-item>
			</el-col>
			<el-col>
				<el-col class="titleName">告警剂量</el-col>
				<el-form-item label="告警剂量:">
					<span v-if="isEdit == false">{{config.alarmDose}}</span>
					<span v-if="isEdit == true">
						<el-input
							size="mini"
							v-model.trim="config.alarmDose"
							clearable
							class="inputClass"
							placeholder="请输入正整数"
						></el-input>
					</span>
				</el-form-item>
			</el-col>
			<el-col>
				<el-col class="titleName">服药次数（次/天）</el-col>
				<el-form-item label="服药次数（次/天）:">
					{{config.drugNum}}
					<span v-if="isEdit == false">{{config.drugNum}}</span>
					<span v-if="isEdit == true">
						<el-input
							size="mini"
							v-model.trim="config.drugNum"
							clearable
							class="inputClass"
							placeholder="请输入正整数"
						></el-input>
					</span>
				</el-form-item>
			</el-col>
			<el-col>
				<el-col class="titleName">每天服药时间</el-col>
				<el-form-item
					label="每天服药时间:"
				>第一次：{{config.drugTime1}}第二次：{{config.drugTime2}}第三次：{{config.drugTime3}}第四次：{{config.drugTime4}}</el-form-item>
				<el-col
					v-if="isEdit == false"
				>每天服药时间:&nbsp;第一次：{{config.drugTime1}}第二次：{{config.drugTime2}}第三次：{{config.drugTime3}}第四次：{{config.drugTime4}}</el-col>
				<el-col v-if="isEdit == true">
					<el-form-item label="第一次:">
						<el-time-picker
							v-model="config.drugTime1"
							format="HH:mm"
							size="mini"
							value-format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</el-form-item>
					<el-form-item label="第二次:">
						<el-time-picker
							v-model="config.drugTime2"
							format="HH:mm"
							size="mini"
							value-format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</el-form-item>
					<el-form-item label="第三次:">
						<el-time-picker
							v-model="config.drugTime3"
							format="HH:mm"
							size="mini"
							value-format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</el-form-item>
					<el-form-item label="第四次:">
						<el-time-picker
							v-model="config.drugTime4"
							format="HH:mm"
							size="mini"
							value-format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</el-form-item>
				</el-col>
			</el-col>-->
		</el-form>
	</div>
</template>

<script>
import {
	editDeviceConfig,
} from "api/equipmentManagement/device";
export default {
	components: {},
	props: {
		formObj: {
			type: Object,
			default: () => { }
		},
	},
	data () {
		return {
			medicineForm: {
				smTime: [],
			},
			isShow: false,
			loadingBtn: false,
			// 是否编辑模式
			isEdit: false,
			config: {}
		};
	},
	watch: {},
	computed: {},
	methods: {
		blurText (e) {
			let inputValue = new RegExp("^[1-9][0-9]*$").test(e.target.value)
			if (!inputValue) {
				this.$message.warning('请输入正整数')
				e.target.value = ''
			}
		},
		saveForm () {
			let config = {
				drugCount: this.config.drugCount,
				drugNum: this.config.drugNum,
				alarmDose: this.config.alarmDose,
				drugTime1: this.config.drugTime1,
				drugTime2: this.config.drugTime2,
				drugTime3: this.config.drugTime3,
				drugTime4: this.config.drugTime4,
			}
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify({ config: config })
			}
			// console.log(params)
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
						this.$forceUpdate()
						this.$message.success("操作成功");
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});
		},
		editForm () {
			this.isEdit = true;
			this.isShow = true;
		}
	},
	created () { },
	mounted () {
		if (this.formObj.deviceConfig) {
			let jsonData = JSON.parse(this.formObj.deviceConfig)
			this.config = jsonData.config
		}
	}
};
</script>
<style lang="scss" scoped>
#medicineForm {
	.titleName {
		color: #333333;
		font-size: 14px;
		margin: 25px 0 20px 12px;
	}
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
	.el-form-item {
		margin-bottom: 8px !important;
	}
}
</style>