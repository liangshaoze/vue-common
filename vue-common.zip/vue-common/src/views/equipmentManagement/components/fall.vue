<template>
	<div id="fall">
		<el-tabs class="tabClass" v-model="tabName" type="card" @tab-click="handleClick">
			<el-tab-pane
				:key="index"
				v-for="(item,index) in equipmentList"
				:label="item.deviceName"
				:name="item.name"
			>
				<!-- <fallForm v-if="index==tabName" @reloadData="reloadData(item.orderCode)" :formObj="item" /> -->
				<fallForm v-if="index==tabName"  :formObj="item" />
			</el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import fallForm from "./fallForm"
import {
	findDeviceSettingByOrderCode
} from "api/equipmentManagement/device";
export default {
	components: {
		fallForm
	},
	props: {
		equipmentList: {
			type: Array,
			default: () => []
		},
	},
	data () {
		return {
			tabName: 0,
		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClick () {
		},
		reloadData (orderCode) {
			this.$emit("selectList", orderCode)
		},
		getDeviceSetting (orderCode) {
			let params = {
				orderCode: orderCode
			}
			findDeviceSettingByOrderCode(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.$forceUpdate()
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log(error);
				});
		},
	},
	created () {

	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
#fall {
	.tabClass {
		margin: 30px 0 0 -8px;
	}
}
.titleName {
	color: #333333;
	font-size: 14px;
	margin: 25px 0 20px 0;
}
.inputClass {
	width: 150px;
}
.timeClass {
	width: 170px;
}
.rightBtn {
	float: right;
	margin-right: 20px;
}
// .titleName {
// 	margin: 15px 0 25px 0;
// 	color: #333333;
// 	font-size: 16px;
// }
</style>