<template>
	<div id="mattressForm">
		<el-form ref="mattressForm" :inline="true" :model="mattressForm" label-width="145px">
			<div class="titleName">
				设备信息
				<el-button
					type="primary"
					size="mini"
					class="rightBtn"
					:loading="loadingBtn"
					v-if="isShow"
					@click="saveForm()"
				>保存</el-button>
				<el-button
					type="primary"
					size="mini"
					:loading="loadingBtn"
					@click="editForm()"
					class="rightBtn"
					v-if="!isShow"
				>修改</el-button>
			</div>
			<div style="margin-left:-60px;">
				<el-form-item label="型号：" style="margin-left:-10px;">{{formObj.deviceModelName}}</el-form-item>
				<el-form-item label="ID：">{{formObj.deviceCode}}</el-form-item>
				<el-form-item label="状态：">{{formObj.deviceOnlineStatus}}</el-form-item>
				<el-form-item label="更新时间：">{{formObj.updateDate}}</el-form-item>
			</div>
			<div>
				<div class="titleName">睡眠设置</div>
				<el-form-item label="开始时间：" style="margin-left:-42px;">
					<span v-if="isEdit == false">{{setTime(sleepConfig.sleepBeginTime)}}</span>
					<span v-if="isEdit == true">
						<el-time-picker
							size="mini"
							style="width:150px;"
							@change="inputChangeText('9',sleepConfig.sleepBeginTime)"
							v-model="sleepConfig.sleepBeginTime"
							value-format="HH:mm"
							format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</span>
				</el-form-item>
				<el-form-item label="结束时间：">
					<span v-if="isEdit == false">{{setTime(sleepConfig.sleepEndTime)}}</span>
					<span v-if="isEdit == true">
						<el-time-picker
							size="mini"
							style="width:150px;"
							@change="inputChangeText('10',sleepConfig.sleepEndTime)"
							v-model="sleepConfig.sleepEndTime"
							value-format="HH:mm"
							format="HH:mm"
							placeholder="任意时间点"
						></el-time-picker>
					</span>
				</el-form-item>
			</div>
			<div :key="index" v-for="(item,index) in alarmCmos">
				<div v-if="item.id=='breath-alarm'">
					<el-col class="titleName">呼吸异常（次/分）</el-col>
					<el-form-item label="告警下限：" style="margin-left:-42px;">
						<span v-if="isEdit == false">
							<span style="width:32px;display:block;">{{item.lowerThreshold}}</span>
						</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								@change="inputText(item.id,item.lowerThreshold,'1')"
								v-model.trim="item.lowerThreshold"
								@blur="blurText($event)"
								clearable
								style="width:150px;"
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
					<el-form-item label="告警上限：">
						<span v-if="isEdit == false">{{item.upperThreshold}}</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								v-model.trim="item.upperThreshold"
								clearable
								@blur="blurText($event)"
								@change="inputText(item.id,item.upperThreshold,'2')"
								style="width:150px;"
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
				</div>
				<div v-if="item.id=='heartbeat-alarm'">
					<el-col class="titleName">心率异常（次/分）</el-col>
					<el-form-item label="告警下限：" style="margin-left:-42px;">
						<span v-if="isEdit == false">
							<span style="width:32px;display:block;">{{item.lowerThreshold}}</span>
						</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								@change="inputText(item.id,item.lowerThreshold,'3')"
								v-model.trim="item.lowerThreshold"
								clearable
								style="width:150px;"
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
					<el-form-item label="告警上限：">
						<span v-if="isEdit == false">{{item.upperThreshold}}</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								style="width:150px;"
								@blur="blurText($event)"
								@change="inputText(item.id,item.upperThreshold,'4')"
								v-model.trim="item.upperThreshold"
								clearable
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
				</div>

				<div v-if="item.id=='offbed-alarm'">
					<el-col class="titleName">离床过久</el-col>
					<el-form-item label="开始时间：" style="margin-left:-42px;">
						<span v-if="isEdit == false">{{setTime(item.checkTime[0])}}</span>
						<span v-if="isEdit == true ">
							<el-time-picker
								size="mini"
								style="width:150px;"
								v-model="item.checkTime[0]"
								value-format="HH:mm"
								format="HH:mm"
								placeholder="任意时间点"
								@blur="blurText($event)"
								@change="inputText(item.id,item.checkTime,'5',true)"
							></el-time-picker>
						</span>
					</el-form-item>
					<el-form-item label="结束时间：">
						<span v-if="isEdit == false">{{setTime(item.checkTime[1])}}</span>
						<span v-if="isEdit == true ">
							<el-time-picker
								size="mini"
								style="width:150px;"
								v-model="item.checkTime[1]"
								value-format="HH:mm"
								format="HH:mm"
								placeholder="任意时间点"
								@blur="blurText($event)"
								@change="inputText(item.id,item.checkTime,'5',false)"
							></el-time-picker>
						</span>
					</el-form-item>
					<el-form-item label="离床时长（min）：">
						<span v-if="isEdit == false">{{item.upperThreshold}}</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								style="width:150px;"
								@blur="blurText($event)"
								@change="inputText(item.id,item.upperThreshold,'6')"
								v-model.trim="item.upperThreshold"
								clearable
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
				</div>
				<div v-if="item.id=='restless-alarm'">
					<el-col class="titleName">体动频繁</el-col>
					<el-form-item label="开始时间：" style="margin-left:-42px;">
						<span v-if="isEdit == false">{{setTime(item.checkTime[0])}}</span>
						<span v-if="isEdit == true ">
							<el-time-picker
								size="mini"
								style="width:150px;"
								v-model="item.checkTime[0]"
								value-format="HH:mm"
								format="HH:mm"
								placeholder="任意时间点"
								@blur="blurText($event)"
								@change="inputText(item.id,item.checkTime,'7',true)"
							></el-time-picker>
						</span>
					</el-form-item>
					<el-form-item label="结束时间：">
						<span v-if="isEdit == false">{{setTime(item.checkTime[1])}}</span>
						<span v-if="isEdit == true ">
							<el-time-picker
								size="mini"
								style="width:150px;"
								v-model="item.checkTime[1]"
								value-format="HH:mm"
								format="HH:mm"
								placeholder="任意时间点"
								@blur="blurText($event)"
								@change="inputText(item.id,item.checkTime,'7',false)"
							></el-time-picker>
						</span>
					</el-form-item>
					<el-form-item label="体动时长（min）：">
						<span v-if="isEdit == false">{{item.upperThreshold}}</span>
						<span v-if="isEdit == true">
							<el-input
								size="mini"
								style="width:150px;"
								@blur="blurText($event)"
								@change="inputText(item.id,item.upperThreshold,'8')"
								v-model.trim="item.upperThreshold"
								clearable
								placeholder="请输入正整数"
							></el-input>
						</span>
					</el-form-item>
				</div>
			</div>
		</el-form>
	</div>
</template>

<script>
import {
	editDeviceConfig,
} from "api/equipmentManagement/device";
import { setTime } from "@/utils/index";
export default {
	components: {},
	props: {
		formObj: {
			type: Object,
			default: () => { }
		},
	},
	data () {
		return {
			mattressForm: {
				smTime: [],
			},
			alarmCmos: [],
			list: [],
			isShow: false,
			loadingBtn: false,
			// 是否编辑模式
			isEdit: false,
			sleepConfig: {}
		};
	},
	watch: {},
	computed: {},
	methods: {
		inputChangeText (status, value) {
			if (status == '9') {
				this.sleepConfig.sleepBeginTime = value + ':00'
			} else {
				this.sleepConfig.sleepEndTime = value + ':00'
			}
		},
		blurText (e) {
			let inputValue = new RegExp("^[1-9][0-9]*$").test(e.target.value)
			if (!inputValue) {
				this.$message.warning('请输入正整数')
				e.target.value = ''
			}
		},
		saveForm () {
			let sleepConfig = {
				sleepEndTime: this.sleepConfig.sleepEndTime,
				sleepBeginTime: this.sleepConfig.sleepBeginTime,
			}
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify({
					sleepConfig: sleepConfig,
					alarmCmos: this.alarmCmos
				}
				)
			}
			// console.log(params)
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
						this.$forceUpdate()
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});
		},
		editForm () {
			this.isEdit = true;
			this.isShow = true;
		},
		inputText (id, val, status, time) {
			console.log(val, status)
			for (let i = 0; i < this.alarmCmos.length; i++) {
				if (this.alarmCmos[i].id == 'breath-alarm') {
					if (status == '1') {
						this.alarmCmos[i].lowerThreshold = val
					}
					if (status == '2') {
						this.alarmCmos[i].upperThreshold = val
					}
				}
				if (this.alarmCmos[i].id == 'heartbeat-alarm') {
					if (status == '3') {
						this.alarmCmos[i].lowerThreshold = val
					}
					if (status == '4') {
						this.alarmCmos[i].upperThreshold = val
					}
				}
				if (this.alarmCmos[i].id == 'offbed-alarm') {
					if (status == '5') {
						if (time == true) {
							this.alarmCmos[i].checkTime[0] = val[0] + ":00"
						}
						if (time == false) {
							this.alarmCmos[i].checkTime[1] = val[1] + ":00"
						}
						console.log(this.alarmCmos[i].checkTime)
					}
					if (status == '6') {
						this.alarmCmos[i].upperThreshold = val
					}
				}
				if (this.alarmCmos[i].id == 'restless-alarm') {
					if (status == '7') {
						if (time == true) {
							this.alarmCmos[i].checkTime[0] = val[0] + ":00"
						}
						if (time == false) {
							this.alarmCmos[i].checkTime[1] = val[1] + ":00"
						}
						console.log(this.alarmCmos[i].checkTime)
						// this.alarmCmos[i].checkTime = val
					}
					if (status == '8') {
						this.alarmCmos[i].upperThreshold = val
					}
				}
			}
		},

	},
	created () { },
	mounted () {
		if (this.formObj.deviceConfig) {
			let jsonData = JSON.parse(this.formObj.deviceConfig)
			this.sleepConfig = jsonData.sleepConfig
			// this.mattressForm.smTime[0] = this.sleepConfig.sleepEndTime
			// this.mattressForm.smTime[1] = this.sleepConfig.sleepBeginTime
			this.alarmCmos = jsonData.alarmCmos
		}
	}
};
</script>
<style lang="scss" scoped>
#mattressForm {
	.titleName {
		color: #333333;
		font-size: 14px;
		margin: 25px 0 20px 20px;
	}
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
	.el-form-item {
		margin-bottom: 8px !important;
	}
}
</style>