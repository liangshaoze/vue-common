<template>
  <div style="justify-content:center;align-items:center">
      <svg-icon
        class="icon-device"
        :iconClass="deviceItem.onlineClass"
        v-if="deviceItem.deviceOnlineStatus=='10'"
        @click="click(deviceItem)"
      />
      <svg-icon
        class="icon-device"
        :iconClass="deviceItem.offlineClass"
        v-else
        @click="click(deviceItem)"
      />
    <div style="color:#666;margin-top:5px;text-size:10px">{{deviceItem.deviceName}}</div>
  </div>
</template>

<script>
export default {
  props: {
    deviceItem: {
      type: Object,
      default: {}
    }
  },
  methods: {
    click(deviceItem) {
      this.$emit("click", deviceItem);
    },
  }
};
</script>

<style scoped>
.icon-device {
  width: 30px;
  height: 30px;
  cursor: pointer;
}
</style>