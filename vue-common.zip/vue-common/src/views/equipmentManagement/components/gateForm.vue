<template>
	<div id="gateForm">
		<el-form ref="gateForm" :inline="true" :model="gateForm" label-width="125px">
			<div class="titleName">设备信息</div>
			<div style="margin-left:-60px;">
				<el-form-item label="型号：">{{formObj.deviceModelName}}</el-form-item>
				<el-form-item label="ID：">{{formObj.deviceCode}}</el-form-item>
				<el-form-item label="状态：">{{formObj.deviceOnlineStatus}}</el-form-item>
				<el-form-item label="更新时间：">{{formObj.updateDate}}</el-form-item>
			</div>
		</el-form>
	</div>
</template>

<script>

export default {
	components: {},
	props: {
		formObj: {
			type: Object,
			default: () => { }
		},
	},
	data () {
		return {
			gateForm: {
			},

		};
	},
	watch: {},
	computed: {},
	methods: {

	},
	created () { },
	mounted () {
		if (this.formObj) {
			console.log(this.formObj, '门磁')
		}
	}
};
</script>
<style lang="scss" scoped>
#gateForm {
	.titleName {
		color: #333333;
		font-size: 14px;
		margin: 25px 0 20px 12px;
	}
}
</style>