<template>
	<div id="mattress">
		<el-tabs class="tabClass" v-model="tabName" type="card" @tab-click="handleClick">
			<el-tab-pane
				:key="index"
				v-for="(item,index) in equipmentList"
				:label="item.deviceName"
				:name="item.name"
			>
				<mattressForm v-if="index==tabName" :formObj="item" />
			</el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import mattressForm from "./mattressForm"

export default {
	components: {
		mattressForm
	},
	props: {
		equipmentList: {
			type: Array,
			default: () => []
		},
	},
	data () {
		return {
			tabName: 0,
		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClick () {
		},
	},
	created () {
		// console.log(this.equipmentList, '9999')
		// if (this.equipmentList.length > 0) {
		// 	for (let i = 0; i < this.equipmentList.length; i++) {
		// 		// console.log(JSON.stringify(JSON.parse(this.equipmentList[i].deviceConfig)))
		// 		let josnData = this.equipmentList[i].deviceConfig
		// 		// console.log(JSON.parse(josnData))
		// 	}
		// }
	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
#mattress {
	.tabClass {
		margin: 30px 0 0 -8px;
	}
}

</style>