<template>
	<div id="monitorForm">
		<el-form ref="monitorForm" :inline="true" :model="monitorForm" label-width="125px">
			<div class="titleName">
				设备信息
				<!-- <el-button
					type="primary"
					size="mini"
					class="rightBtn"
					:loading="loadingBtn"
					v-if="isShow"
					@click="saveForm()"
				>保存</el-button>
				<el-button
					type="primary"
					size="mini"
					:loading="loadingBtn"
					@click="editForm()"
					class="rightBtn"
					v-if="!isShow"
				>修改</el-button> -->
			</div>
			<div style="margin-left:-60px;">
				<el-form-item label="型号：">{{formObj.deviceModelName}}</el-form-item>
				<el-form-item label="ID：">{{formObj.deviceCode}}</el-form-item>
				<el-form-item label="状态：">{{formObj.deviceOnlineStatus}}</el-form-item>
				<el-form-item label="更新时间：">{{formObj.updateDate}}</el-form-item>
			</div>
			<div style="margin:0 0 10px -33px;">
				<el-form-item label="直播地址：">
					<span v-if="isEdit == false">{{config.url}}</span>
					<span v-if="isEdit == true">
						<el-input
							style="width:600px;"
							size="mini"
							v-model.trim="config.url"
							clearable
							placeholder="请输入直播地址"
						></el-input>
					</span>
				</el-form-item>
			</div>
		</el-form>
	</div>
</template>

<script>
import {
	editDeviceConfig,
} from "api/equipmentManagement/device";
export default {
	components: {},
	props: {
		formObj: {
			type: Object,
			default: () => { }
		},
	},
	data () {
		return {
			monitorForm: {
			},
			isShow: false,
			loadingBtn: false,
			// 是否编辑模式
			isEdit: false,
			config: {
				url: '',
			}
		};
	},
	watch: {},
	computed: {},
	methods: {
		saveForm () {
			let str = {
				url: this.config.url
			}
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify(str)
			}
			// console.log(params)
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
						this.$forceUpdate()
						// this.$emit('reloadData');
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});
		},
		editForm () {
			this.isEdit = true;
			this.isShow = true;
		}
	},
	created () { },
	mounted () {
		if (this.formObj.deviceConfig) {
			// console.log(this.formObj, '监控')
			let jsonData = JSON.parse(this.formObj.deviceConfig)
			this.config = jsonData
		}
	}
};
</script>
<style lang="scss" scoped>
#monitorForm {
	.titleName {
		color: #333333;
		font-size: 14px;
		margin: 25px 0 20px 12px;
	}
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
}
</style>