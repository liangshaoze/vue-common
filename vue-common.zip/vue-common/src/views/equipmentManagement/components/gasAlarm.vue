<template>
	<div>
		<el-tabs class="tabClass" v-model="tabName" type="card" @tab-click="handleClick">
			<el-tab-pane
				:key="index"
				v-for="(item,index) in equipmentList"
				:label="item.deviceName"
				:name="item.name"
			>
				<gasForm v-if="index==tabName" :formObj="item" />
			</el-tab-pane>
		</el-tabs>
	</div>
</template>

<script>
import gasForm from "./gasForm"

export default {
	components: {
		gasForm
	},
	props: {
		equipmentList: {
			type: Array,
			default: () => []
		},
	},
	data () {
		return {
			tabName: 0,

		};
	},
	watch: {},
	computed: {},
	methods: {
		handleClick (tab) {
			console.log(tab);
		},

	},
	created () {

	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
.tabClass {
	margin: 30px 0 0 -8px;
}
</style>