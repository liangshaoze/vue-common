<template>
	<div id="alarmDetail">
		<div class="seettingTop">
			<div class="info-left">
				<div class="person-detail">
					<img
						style="width:60px;height:60px;"
						src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
					/>
				</div>
				<div class="person-info">
					<div>{{careReceiverDetail.careReceiverName}}</div>
					<span class="person-color" v-if="careReceiverDetail.isLiveAlone=='1'">独居</span>
				</div>
			</div>
			<div class="info-right">
				<div class="basic-info">
					<el-row>
						<el-col :span="24" style="font-size:16px;color:#333333;">基本信息</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">年龄：{{getAge(careReceiverDetail)}}</el-col>
						<el-col class="info-text" :span="8">性别：{{careReceiverDetail.careReceiverGenderValue}}</el-col>
						<el-col class="info-text" :span="8">生日：{{getBirthday(careReceiverDetail)}}</el-col>
					</el-row>
					<el-row>
						<el-col
							class="info-text"
							:span="24"
						>地址：{{careReceiverDetail.liveProvinceName+careReceiverDetail.liveCityName+careReceiverDetail.liveDistrictName+careReceiverDetail.liveSubdistrictName+careReceiverDetail.liveDetailAddress}}</el-col>
					</el-row>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";
export default {
	components: {
	},
	props: {
		careReceiverDetail: {
			type: Object,
			default: () => { }
		}
	},
	data () {
		return {
			tagName: "处理告警详情",
		};
	},
	watch: {},
	computed: {},
	methods: {
		getBirthday (item) {
			return getBirthdayFromIdentityCard(item.careReceiverIdCard);
		},
		getAge (item) {
			return getAgeFromIdentityCard(item.careReceiverIdCard);
		},
	},
	created () { },
	mounted () { }
};
</script>
<style lang="scss" scoped>
#alarmDetail {
	width: 100%;
	.seettingTop {
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
		border-radius: 6px;
		// margin: 0px 20px 20px 20px;
		display: flex;
		.info-left {
			.person-detail {
				padding: 28px 30px 10px 26px;
			}
			.person-info {
				display: flex;
				margin: 10px 0 0 10px;
				div {
					font-size: 14px;
					color: #333333;
					width: 80px;
					vertical-align: middle;
				}
				.person-color {
					width: 45px;
					border-radius: 25px;
					background-color: #f04b5f;
					color: white;
					padding: 2px 6px 2px 6px;
				}
			}
		}
		.info-right {
			width: 100%;
			padding: 30px 0 30px 20px;
		}
	}
}
.info-text {
	margin-top: 25px;
	font-size: 14px;
	color: #333333;
}
</style>