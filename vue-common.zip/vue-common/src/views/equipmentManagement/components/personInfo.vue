<template>
	<div id="basicInfo">
		<div class="seettingTop">
			<div class="info-left">
				<div class="person-detail">
					<p class="info-news">
						<img
							style="width:60px;height:60px;"
							:src="settingObj.careReceiverIcon ? settingObj.careReceiverIcon :'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png' "
						/>
					</p>
					<p class="info-news" style="margin:16px 0;">{{settingObj.careReceiverName}}</p>
					<!-- <p class="info-news" style="margin-top:16px;">{{settingObj.careReceiverTel}}</p> -->
				</div>
			</div>
			<div class="info-right" style="width:100%;padding-top:40px;margin-bottom:25px;">
				<div class="basic-info">
					<!-- <el-col style="font-size:16px;color:#333333;font-family:Adobe Heiti Std;">基本信息</el-col> -->
					<el-row>
						<el-col class="info-text" :span="8">性别：{{settingObj.careReceiverGenderValue =='0'?'男':'女'}}</el-col>
						<el-col class="info-text" :span="8">年龄：{{getAge(settingObj)}}</el-col>
						<el-col class="info-text" :span="8">生日：{{getBirthday(settingObj)}}</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">组织：{{settingObj.orgUnitName}}</el-col>
						<el-col class="info-text" :span="8">电话：{{settingObj.careReceiverTel}}</el-col>
						<el-col
							class="info-text"
							:span="8"
						>详细地址：{{settingObj.liveProvinceName+settingObj.liveCityName+settingObj.liveDistrictName+settingObj.liveSubdistrictName+settingObj.liveDetailAddress}}</el-col>

						<!-- <el-col class="info-text" :span="8">电话：{{settingObj.careReceiverTel}}</el-col> -->
					</el-row>
				</div>
				<!-- <div class="basic-info" style="margin-top:32px;">
					<el-col style="font-size:16px;color:#333333;">监护人</el-col>
					<div v-for="(item,index) in familyInDtoList" :key="index">
						<el-col
							:span="8"
							style="font-size:14px;color:#666666;margin-top:25px;"
						>监护人：{{item.familyMemberName}}&nbsp;{{item.contactsTel}}</el-col>
					</div>
				</div>-->
			</div>
		</div>
	</div>
</template>

<script>
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";

export default {
	components: {},
	props: {
		settingObj: {
			type: Object,
			default: () => { }
		},
		familyInDtoList: {
			type: Array,
			default: () => []
		}
	},
	data () {
		return {

		};
	},
	watch: {},
	computed: {},
	methods: {
		getBirthday (item) {
			return getBirthdayFromIdentityCard(item.careReceiverIdCard);
		},
		getAge (item) {
			return getAgeFromIdentityCard(item.careReceiverIdCard);
		},

	},
	created () {
		console.log(this.settingObj)
	},
	mounted () { }
};
</script>
<style lang="scss" scoped>
#basicInfo {
	width: 100%;
	min-width: 1300px;
	.seettingTop {
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
		border-radius: 6px;
		margin: 0px 20px 20px 20px;
		display: flex;
		.info-left {
			padding: 25px 55px 0 55px;
			display: flex;
			.person-detail {
				flex: 1;
				.info-news {
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;
					color: rgba(51, 51, 51, 1);
					font-size: 16px;
					width: 100px;
				}
			}
		}
	}
}
.info-text {
	margin-top: 25px;
	font-size: 14px;
	color: #666666;
}
</style>