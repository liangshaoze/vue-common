<template>
	<div id="fallForm">
		<el-form ref="fallForm" :inline="true" :model="fallForm" label-width="125px">
			<div class="titleName">设备信息</div>
			<div style="margin-left:-60px;">
				<el-form-item label="型号：">{{formObj.deviceModelName}}</el-form-item>
				<el-form-item label="ID：">{{formObj.deviceCode}}</el-form-item>
				<el-form-item label="状态：">{{formObj.deviceOnlineStatus}}</el-form-item>
				<el-form-item label="更新时间：">{{formObj.updateDate}}</el-form-item>
				<el-form-item label="绑定的手机号：">{{formObj.phone}}</el-form-item>
			</div>
			<div style="margin:20px 0;">
				<el-button
					class="rightBtn"
					type="primary"
					size="mini"
					:loading="loadingBtn"
					@click="deleteName()"
				>删除</el-button>
				<el-button
					type="primary"
					size="mini"
					class="rightBtn"
					:loading="loadingBtn"
					@click="addContacts()"
				>新增联系人</el-button>
			</div>
			<div style="margin:70px 20px;">
				<el-table
					ref="multipleTable"
					:data="tableData"
					border
					v-loading="listLoading"
					:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
					:show-header="true"
					@selection-change="handleSelectionChange"
				>
					<el-table-column :selectable="checkSelect" type="selection" width="55"></el-table-column>
					<el-table-column
						v-for="(item,index) in tableHeader"
						:key="index"
						:label="item.label"
						:prop="item.prop"
					>
						<template slot-scope="scope">{{scope.row[item.property]}}</template>
					</el-table-column>
					<el-table-column label="操作">
						<template slot-scope="scope" v-if="scope.row.type=='普通白名单'">
							<el-button type="text" size="mini" @click="handeleUrgent(scope.row)">紧急求助</el-button>
							<el-button type="text" size="mini" @click="handeleCall(scope.row)">日常呼叫</el-button>
							<el-button type="text" size="mini" @click="handeleCenter(scope.row)">呼叫中心</el-button>
						</template>
					</el-table-column>
				</el-table>
			</div>
		</el-form>
		<el-dialog title="新增白名单" :visible.sync="dialogVisible" width="500px" :before-close="close" center>
			<el-row type="flex" justify="center">
				<el-form
					:inline="true"
					:rules="nameListRules"
					ref="nameList"
					:model="nameList"
					label-width="125px"
				>
					<el-form-item class="formClass" label="类型" prop="type">
						<el-select size="mini" v-model.trim="nameList.type" clearable placeholder="请选择">
							<el-option
								v-for="item in nameStatusOptions"
								:key="item.value"
								:label="item.name"
								:value="item.value"
							/>
						</el-select>
					</el-form-item>
					<el-form-item class="formClass" label="联系人" prop="name">
						<el-input size="mini" v-model.trim="nameList.name" clearable placeholder="请输入联系人"></el-input>
					</el-form-item>
					<el-form-item class="formClass" label="电话" prop="phone">
						<el-input size="mini" v-model.trim="nameList.phone" clearable placeholder="请输入电话"></el-input>
					</el-form-item>
				</el-form>
			</el-row>
			<div slot="footer" class="dialog-footer">
				<el-button size="mini" @click="cancle('nameList')">取消</el-button>
				<el-button
					size="mini"
					style="margin-left:40px;"
					type="primary"
					@click="handleOk('nameList')"
				>确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import { findValueBySetCode } from "api/common";
import {
	editDeviceConfig,
} from "api/equipmentManagement/device";
export default {
	// inject: ['reload'],
	components: {},
	props: {
		formObj: {
			type: Object,
			default: () => { }
		},
	},
	data () {
		return {
			fallForm: {
				smTime: [],
			},
			type: '',
			nameList: {
				type: '',
				name: '',
				phone: ''
			},
			nameListRules: {
				type: [
					{ required: true, message: '请选择类型', trigger: 'change' }
				],
				name: [
					{ required: true, message: '请输入联系人', trigger: 'blur' }],
				phone: [
					{ required: true, message: '请输入电话', trigger: 'blur' }]
			},
			nameStatusOptions: [],
			alarmCmos: [],
			tableData: [],
			tableHeader: [{
				label: '类型',
				property: 'type'
			}, {
				label: '联系人',
				property: 'name'
			},
			{
				label: '号码',
				property: 'phone'
			},
			{
				label: '更新时间',
				property: 'updateTime'
			},
			],
			isShow: false,
			loadingBtn: false,
			// 是否编辑模式
			isEdit: false,
			listLoading: false,
			dialogVisible: false,
			config: {},
			multipleSelection: [],
			deleteList: [],
			childValue: '123'
		};
	},
	watch: {

	},
	computed: {},
	methods: {
		checkSelect (row, index) {
			let isChecked = true;
			if (row.type === '呼叫中心号码') { // 判断里面是否存在某个参数
				isChecked = false
			} else {
				isChecked = true
			}
			return isChecked
		},

		addContacts () {
			this.dialogVisible = true
		},
		close () {
			this.dialogVisible = false
			this.$refs.nameList.resetFields();
		},
		saveForm () {
			this.isEdit = false;
			this.isShow = false;
		},
		cancle () {
			this.dialogVisible = false
			this.$refs.nameList.resetFields();

		},
		/* 新增 */
		handleOk (nameList) {
			this.$refs[nameList].validate(valid => {
				if (valid) {
					let typeValue = ''
					if (this.nameList.type == '0') {
						typeValue = '普通白名单'
					} else if (this.nameList.type == '1') {
						typeValue = '日常拨出号码'
					} else if (this.nameList.type == '2') {
						typeValue = '紧急求助号码'
					} else if (this.nameList.type == '2') {
						typeValue = '呼叫中心号码'
					}
					let params = {
						type: '20',
						orderItemCode: this.formObj.orderItemCode,
						deviceConfig: JSON.stringify({
							phone: this.nameList.phone,
							type: this.nameList.type,
							name: this.nameList.name,
							typeValue: typeValue
						})
					}
					editDeviceConfig(params)
						.then(response => {
							if (response.data.statusCode == "200") {
								this.$message.success("操作成功");
								let data = JSON.parse(response.data.responseData)
								this.tableData = data.list
								if (this.tableData.length > 0) {
									for (let i = 0; i < this.tableData.length; i++) {
										if (this.tableData[i].type == '0') {
											this.tableData[i].type = '普通白名单'
										} else if (this.tableData[i].type == '1') {
											this.tableData[i].type = '日常拨出号码'
										} else if (this.tableData[i].type == '2') {
											this.tableData[i].type = '紧急求助号码'
										} else if (this.tableData[i].type == '3') {
											this.tableData[i].type = '呼叫中心号码'
										}
									}
								}
								this.dialogVisible = false
								this.loadingBtn = false;
								this.isEdit = false;
								this.isShow = false;
								this.$refs.nameList.resetFields();
								// this.$emit("reloadData")
							} else {
								this.$message.error(response.data.statusMsg);
								this.loadingBtn = false;
								return false;
							}
						})
						.catch(error => {
							console.log(error);
							this.$message.error(response.data.statusMsg);
							this.loadingBtn = false;
							return false;
						});
				} else {
					this.$message.error("请检查是否填写完整");
					this.isDisabled = false
				}
			})
		},
		handeleUrgent (row) {
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify({
					number: this.formObj.deviceRawNo,
					phone: row.phone,
					type: 2
				}
				)
			}
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						let data = JSON.parse(response.data.responseData)
						this.tableData = data.list
						if (this.tableData.length > 0) {
							for (let i = 0; i < this.tableData.length; i++) {
								if (this.tableData[i].type == '0') {
									this.tableData[i].type = '普通白名单'
								} else if (this.tableData[i].type == '1') {
									this.tableData[i].type = '日常拨出号码'
								} else if (this.tableData[i].type == '2') {
									this.tableData[i].type = '紧急求助号码'
								} else if (this.tableData[i].type == '3') {
									this.tableData[i].type = '呼叫中心号码'
								}
							}
						}
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
						// this.$emit("reloadData")
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});


		},
		handeleCall (row) {
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify({
					number: this.formObj.deviceRawNo,
					phone: row.phone,
					type: 1
				}
				)
			}
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						// this.$emit("reloadData")
						let data = JSON.parse(response.data.responseData)
						this.tableData = data.list
						if (this.tableData.length > 0) {
							for (let i = 0; i < this.tableData.length; i++) {
								if (this.tableData[i].type == '0') {
									this.tableData[i].type = '普通白名单'
								} else if (this.tableData[i].type == '1') {
									this.tableData[i].type = '日常拨出号码'
								} else if (this.tableData[i].type == '2') {
									this.tableData[i].type = '紧急求助号码'
								} else if (this.tableData[i].type == '3') {
									this.tableData[i].type = '呼叫中心号码'
								}
							}
						}
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});
		},
		handeleCenter (row) {
			let params = {
				type: '10',
				orderItemCode: this.formObj.orderItemCode,
				deviceConfig: JSON.stringify({
					number: this.formObj.deviceRawNo,
					phone: row.phone,
					type: 3
				}
				)
			}
			editDeviceConfig(params)
				.then(response => {
					if (response.data.statusCode == "200") {
						this.$message.success("操作成功");
						// this.$emit("reloadData")
						let data = JSON.parse(response.data.responseData)
						this.tableData = data.list
						if (this.tableData.length > 0) {
							for (let i = 0; i < this.tableData.length; i++) {
								if (this.tableData[i].type == '0') {
									this.tableData[i].type = '普通白名单'
								} else if (this.tableData[i].type == '1') {
									this.tableData[i].type = '日常拨出号码'
								} else if (this.tableData[i].type == '2') {
									this.tableData[i].type = '紧急求助号码'
								} else if (this.tableData[i].type == '3') {
									this.tableData[i].type = '呼叫中心号码'
								}
							}
						}
						this.loadingBtn = false;
						this.isEdit = false;
						this.isShow = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.$message.error(response.data.statusMsg);
					this.loadingBtn = false;
					return false;
				});
		},
		deleteName () {
			let tels = []
			let list = this.multipleSelection;
			if (list.length == 0) {
				this.$message.error("请选择操作项");
				return false;
			} else if (list.length > 2) {
				this.$message.error("只能选择两条！");
				return false;
			} else {
				for (let i = 0; i < list.length; i++) {
					tels.push(
						list[i].phone
					)
				}
				let params = {
					type: '30',
					orderItemCode: this.formObj.orderItemCode,
					deviceConfig: JSON.stringify({
						tels
					}
					)
				}
				editDeviceConfig(params)
					.then(response => {
						if (response.data.statusCode == "200") {
							this.$message.success("操作成功");
							let data = JSON.parse(response.data.responseData)
							this.tableData = data.list
							if (this.tableData.length > 0) {
								for (let i = 0; i < this.tableData.length; i++) {
									if (this.tableData[i].type == '0') {
										this.tableData[i].type = '普通白名单'
									} else if (this.tableData[i].type == '1') {
										this.tableData[i].type = '日常拨出号码'
									} else if (this.tableData[i].type == '2') {
										this.tableData[i].type = '紧急求助号码'
									} else if (this.tableData[i].type == '3') {
										this.tableData[i].type = '呼叫中心号码'
									}
								}
							}
							this.loadingBtn = false;
							this.isEdit = false;
							this.isShow = false;
							tels = []
							// this.$emit("reloadData")
						} else {
							this.$message.error(response.data.statusMsg);
							this.loadingBtn = false;
							return false;
						}
					})
					.catch(error => {
						console.log(error);
						this.$message.error(response.data.statusMsg);
						this.loadingBtn = false;
						return false;
					});
			}



		},
		editForm () {
			this.isEdit = true;
			this.isShow = true;
		},
		handleSelectionChange (val) {
			this.multipleSelection = val;
		},
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "TDUN_SETTING_TYPE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.nameStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}
	},
	created () {
		this.initDataDictionary()
	},
	mounted () {
		if (this.formObj.deviceConfig) {
			let jsonData = JSON.parse(this.formObj.deviceConfig)
			this.tableData = jsonData.list
			if (this.tableData.length > 0) {
				for (let i = 0; i < this.tableData.length; i++) {
					if (this.tableData[i].type == '0') {
						this.tableData[i].type = '普通白名单'
					} else if (this.tableData[i].type == '1') {
						this.tableData[i].type = '日常拨出号码'
					} else if (this.tableData[i].type == '2') {
						this.tableData[i].type = '紧急求助号码'
					} else if (this.tableData[i].type == '3') {
						this.tableData[i].type = '呼叫中心号码'
					}
				}
			}
		}
	}
};
</script>
<style lang="scss" scoped>
#fallForm {
	.titleName {
		color: #333333;
		font-size: 14px;
		margin: 25px 0 20px 12px;
	}
	.rightBtn {
		float: right;
		margin-right: 20px;
	}
	.el-form-item {
		margin-bottom: 15px !important;
	}
}
</style>