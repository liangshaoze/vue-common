<template>
  <div id="equipmentList">
    <headTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="80px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filters.orgName"
                placeholder="请选择组织"
                @focus="dialogVisible=true"
                @clear="clearOrgCode"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="设备类型" prop="deviceClassCode">
              <el-select
                size="mini"
                v-model.trim="filters.deviceClassCode"
                @change="findFiltersDeviceModel"
                clearable
                placeholder="请选择设备类型"
              >
                <el-option
                  v-for="item in deviceClassOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="型号名称" prop="deviceModelId">
              <el-select
                size="mini"
                v-model.trim="filters.deviceModelId"
                @change="showFiltersDeviceProp"
                @clear="clearFilterMode"
                clearable
                placeholder="请选择型号名称"
              >
                <el-option
                  v-for="item in filtersDeviceModelOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="设备状态" prop="deviceStatus">
              <el-select
                size="mini"
                v-model.trim="filters.deviceStatus"
                clearable
                placeholder="请选择设备状态"
              >
                <el-option
                  v-for="item in deviceStatusOptions2"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="设备ID" prop="deviceCode">
              <el-input
                size="mini"
                v-model.trim="filters.deviceCode"
                clearable
                placeholder="请输入设备ID"
                maxlength="30"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="原始ID" prop="deviceRawNo">
              <el-input
                size="mini"
                v-model.trim="filters.deviceRawNo"
                clearable
                placeholder="请输入设备ID"
                maxlength="30"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item></el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getList(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="insertEquipment()">新增</el-button>
        </el-col>
      </el-row>
      <!--列表-->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="orderList"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column label="组织" min-width="200" prop="orgName"></el-table-column>
        <el-table-column label="设备ID" min-width="150" prop="deviceCode"></el-table-column>
        <el-table-column label="设备类型" min-width="150" prop="deviceClassName"></el-table-column>
        <el-table-column label="型号名称" min-width="150" prop="deviceModel"></el-table-column>
        <el-table-column label="设备原始ID" min-width="150" prop="deviceRawNo"></el-table-column>
        <el-table-column label="设备状态" min-width="100" prop="deviceStatusValue"></el-table-column>
        <el-table-column label="创建时间" min-width="135" prop="createDate"></el-table-column>
        <el-table-column fixed="right" width="120" label="操作">
          <template slot-scope="scope">
            <span>
              <el-button size="mini" type="text" @click="handleEditEquipment(scope.row)">修改</el-button>
              <el-button size="mini" type="text" @click="handleTableHistory(scope.row,1)">历史</el-button>
            </span>
            <span>
              <span v-if="showList.equipment_originalData_onClick">
                <el-button size="mini" type="text" @click="handleTabOldData(scope.row,1)">原始数据</el-button>
              </span>
              <span v-if="scope.row.delButton == 'TRUE' && scope.row.deviceStatus == '10'">
                <el-button size="mini" type="text" @click="handleDelete(scope.$index,scope.row)">删除</el-button>
              </span>
            </span>
          </template>
        </el-table-column>
      </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.page"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>
    </div>

    <!-- 列表过滤组织弹窗 -->
    <el-dialog
      title="组织架构"
      :visible.sync="dialogVisible"
      width="500px"
      :before-close="handleCloseOrg"
    >
      <org-select v-on:listenTochildEvent="getCurrentNode"/>
    </el-dialog>

    <!-- 设备历史列表 -->
    <!-- Table -->
    <el-dialog title="设备历史" width="950px" :visible.sync="dialogTableHistory">
      <el-form :inline="false" label-width="85px">
        <el-row>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备ID"><span class="long-field" >{{deviceInfo.deviceCode}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备类型"><span class="long-field" >{{deviceInfo.deviceClassName}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="型号名称"><span class="long-field" >{{deviceInfo.deviceModelName}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备原始ID"><span class="long-field" >{{deviceInfo.deviceRawNo}}</span></el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <br>
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        border
        class="tableList"
        :data="historyDataList"
        v-loading="listLoading1"
      >
        <el-table-column property="orgName" label="组织" min-width="150"></el-table-column>
        <el-table-column property="createDate" label="时间" min-width="150"></el-table-column>
        <el-table-column property="event" label="事件" min-width="150"></el-table-column>
        <el-table-column property="remark" label="备注" min-width="150"></el-table-column>
        <el-table-column property="createName" label="操作人" min-width="100"></el-table-column>
      </el-table>

      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount1>0"
          :total="totalCount1"
          :page.sync="filters1.page"
          :limit.sync="filters1.pageSize"
          @pagination="pageChange1"
        ></pagination>
      </el-row>
    </el-dialog>

    <!-- 原始数据列表 -->
    <!-- Table -->
    <el-dialog title="原始数据" width="950px" :visible.sync="dialogTableOldData">
      <el-form :inline="false" label-width="85px">
        <el-row>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备ID"><span class="long-field" >{{deviceInfo.deviceCode}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备类型"><span class="long-field" >{{deviceInfo.deviceClassName}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="型号名称"><span class="long-field" >{{deviceInfo.deviceModelName}}</span></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item class="table-label" label="设备原始ID"><span class="long-field" >{{deviceInfo.deviceRawNo}}</span></el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <br>
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        border
        class="tableList"
        :data="oldDataList"
        v-loading="listLoading2"
      >
        <el-table-column property="createDate" label="时间" min-width="200"></el-table-column>
        <el-table-column property="rawData" label="数据" min-width="300"></el-table-column>
      </el-table>

      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount2>0"
          :total="totalCount2"
          :page.sync="filters2.page"
          :limit.sync="filters2.pageSize"
          @pagination="pageChange2"
        ></pagination>
      </el-row>
    </el-dialog>

    <!-- 添加/修改 -->
    <el-dialog
      :title="dialogTitle"
      :visible.sync="dialogAddEquipment"
      :before-close="handleClose"
      width="400px"
      center
    >
      <el-form
        :inline="true"
        class="tableForm"
        ref="objectForm"
        :model="objectForm"
        :rules="objectRules"
        label-width="105px"
      >
        <el-row>
          <span v-if="objectForm.deviceCode">
            <el-col class="form-item">
              <el-form-item label="设备ID" prop="deviceCode">{{objectForm.deviceCode}}</el-form-item>
            </el-col>
          </span>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-autocomplete
                :trigger-on-focus="true"
                v-model="objectForm.orgName"
                popper-class="my-autocomplete"
                size="mini"
                clearable
                :fetch-suggestions="queryOrgName"
                placeholder="请输入组织"
                @select="selectOrgName"
                @blur="removeOrgCode"
                @clear="removeOrgCode"
              >
                <template slot-scope="{ item }">
                  <span class="name">{{ item.value }}</span>
                </template>
              </el-autocomplete>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="设备类型" prop="deviceClassName">
              <span v-if="editFlag == true">{{objectForm.deviceClassName}}</span>
              <span v-if="editFlag == false">
                <el-select
                  size="mini"
                  v-model.trim="objectForm.deviceClassName"
                  @change="findDeviceModel"
                  clearable
                  placeholder="请选择设备类型"
                >
                  <el-option
                    v-for="item in deviceClassOptions"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  />
                </el-select>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="型号名称" prop="deviceModelName">
              <span v-if="editFlag == true">{{objectForm.deviceModelName}}</span>
              <span v-if="editFlag == false">
                <el-select
                  size="mini"
                  v-model.trim="objectForm.deviceModelName"
                  @change="showDeviceProp"
                  clearable
                  placeholder="请选择型号名称"
                >
                  <el-option
                    v-for="item in deviceModelOptions"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  />
                </el-select>
              </span>
            </el-form-item>
          </el-col>
          <span v-if="objectForm.currentModelProp.length > 0">
            <div v-for="(item,index) in objectForm.currentModelProp" :key="index">
              <span v-if="item.isHide !== '1'">
                <el-col class="form-item">
                  <el-form-item
                    :label="item.name"
                    :prop="'currentModelProp.' + index + '.value'"
                    :rules="{required: item.isMust == '1',message: item.name+'不能为空', tigger:'blur' }"
                  >
                    <span v-if="editFlag == true">{{item.value}}</span>
                    <span v-if="editFlag == false">
                      <el-input
                        size="mini"
                        v-model.trim="item.value"
                        clearable
                        :placeholder="item.name"
                      ></el-input>
                    </span>
                  </el-form-item>
                </el-col>
              </span>
            </div>
          </span>
          <el-col class="form-item">
            <el-form-item label="设备状态" prop="deviceStatus">
              <el-select
                size="mini"
                v-model.trim="objectForm.deviceStatus"
                clearable
                placeholder="请选择设备状态"
              >
                <el-option
                  v-for="item in deviceStatusOptions"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                  :disabled="item.disabled"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="备注" prop="remark">
              <el-input
                size="mini"
                v-model.trim="objectForm.remark"
                clearable
                placeholder="请输入备注"
                maxlength="20"
              ></el-input>
            </el-form-item>
          </el-col>
          <span v-if="objectForm.createDate">
            <el-col class="form-item">
              <el-form-item label="创建时间" prop="createDate">{{objectForm.createDate}}</el-form-item>
            </el-col>
          </span>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleClose">取消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="saveEquipment('objectForm')"
        >确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common";
import {
  findDevice,
  findDeviceRecord,
  findDeviceData,
  findDeviceModel,
  addDevice,
  updateDevice,
  findDeviceByPrimarykey,
  delDeviceByDeviceCode
} from "api/equipmentManagement/device";
import { changeYMD } from "utils";
import { isMoney } from "utils/validate.js";
import OrgSelect from "components/OrgSelect";
import { hasPermission } from "@/utils/button";
import { findEhrOrgAll, findEhrOrgList } from "api/orgStructure";
export default {
  data() {
    return {
      showList: {
				equipment_originalData_onClick: true
			},
      tagName: "设备列表",
      dialogTitle: "添加设备",
      //列表过滤组织弹窗控制
      dialogVisible: false,
      //新增/修改弹窗控制
      dialogAddEquipment: false,
      editFlag: false,
      //历史列表弹窗控制
      dialogTableHistory: false,
      historyDataList: [],
      //原始数据弹窗控制
      dialogTableOldData: false,
      oldDataList: [],
      //条件查询
      filters: {
        deviceClassCode: "",
        deviceModelId: "",
        deviceStatus: "",
        deviceCode: "",
        deviceRawNo: "",
        orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : "",
        orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : "",
        page: 1,
        pageSize: 10
      },
      //设备历史
      filters1: {
        page: 1,
        pageSize: 10
      },
      //原始数据
      filters2: {
        page: 1,
        pageSize: 10
      },
      orderList: [],
      totalCount: 0,
      totalCount1: 0,
      totalCount2: 0,
      //列表加载状态
      listLoading: false,
      listLoading1: false,
      listLoading2: false,
      //查询按钮加载状态
      searchLoading: false,
      //新增/修改
      objectForm: {
        deviceId: "",
        orgCode: "",
        orgName: "",
        deviceClassCode: "",
        deviceClassName: "",
        deviceModelId: "",
        deviceModelName: "",
        deviceStatus: "10",
        deviceCode: "",
        remark: "",
        //根据设备型号获取原始id拼接规则
        deviceSpec: [],
        currentModelProp: []
      },
      prop0: "",
      prop1: "",
      prop2: "",
      objectRules: {
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        deviceClassName: [
          {
            required: true,
            message: "请选择设备类型",
            trigger: "change"
          }
        ],
        deviceModelName: [
          {
            required: true,
            message: "请选择型号名称",
            trigger: "change"
          }
        ],
        deviceStatus: [
          {
            required: true,
            message: "请选择设备状态",
            trigger: "change"
          }
        ]
      },
      //新增/修改模糊查询组织
      currentOrg: [],
      //设备分类
      deviceClassOptions: [],
      //设备型号
      deviceModelOptions: [],
      //设备状态
      deviceStatusOptions: [],
      deviceStatusOptions1: [],
      deviceStatusOptions2: [],
      //过滤设备型号
      filtersDeviceModelOptions: [],
      //历史和原始数据头部展示
      deviceInfo: {
        deviceCode: "",
        deviceName: "",
        deviceModelName: "",
        deviceRawNo: ""
      },
      //设备ID
      deviceId: ""
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page); //改变页码，重新渲染页面
    },
    getList(page) {
      this.filters.page = page;
      var params = {
        pageNum: this.filters.page,
        pageSize: this.filters.pageSize,
        orgCode: this.filters.orgCode,
        deviceClassCode: this.filters.deviceClassCode,
        deviceModelId: this.filters.deviceModelId,
        deviceStatus: this.filters.deviceStatus,
        deviceCode: this.filters.deviceCode,
        deviceRawNo: this.filters.deviceRawNo
      };
      this.listLoading = true;
      this.searchLoading = true;
      findDevice(params)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode == 200 ||
              response.data.statusCode == "200"
            ) {
              this.orderList = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.$message.error(response.data.statusMsg);
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    //组织模糊查询
    selectOrgName(item) {
      if (item.value !== "无") {
        this.objectForm.orgCode = item.code;
        this.objectForm.orgName = item.value;
      } else {
        this.objectForm.orgName = "";
      }
    },
    removeOrgCode() {
      this.objectForm.orgName = "";
      this.objectForm.orgCode = "";
    },
    queryOrgName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        orgName: queryString
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.currentOrg = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.currentOrg.push({
                value: data[i].orgName,
                code: data[i].orgCode
              });
            }
            var results = this.currentOrg;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgList:" + error);
          return false;
        });
    },
    /**
     * 根据设备型号获取原始id拼接规则
     * deviceProp
     */
    findDeviceModel(val) {
      let option = this.deviceClassOptions.find(item => {
        return item.value === val;
      });
      this.objectForm.deviceClassCode = option.value;
      this.objectForm.deviceClassName = option.name;

      this.objectForm.deviceModelId = "";
      this.objectForm.deviceModelName = "";
      this.objectForm.deviceStatus = "10";
      this.objectForm.remark = "";
      this.objectForm.currentModelProp = [];

      if (this.objectForm.deviceClassCode && this.objectForm.orgCode) {
        var params = {
          deviceClassCode: this.objectForm.deviceClassCode,
          orgCode: this.objectForm.orgCode
        };
        findDeviceModel(params)
          .then(response => {
            if (response.data.statusCode === "200") {
              this.deviceModelOptions = [];
              var list = response.data.responseData;
              if (list.length > 0) {
                for (let i = 0; i < list.length; i++) {
                  this.deviceModelOptions.push({
                    name: list[i].deviceModel,
                    value: list[i].id,
                    prop: list[i].deviceSpec
                  });
                }
              }
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          })
          .catch(error => {
            console.log("findDeviceRecord:" + error);
            return false;
          });
      } else {
        this.deviceModelOptions = [];
      }
    },
    //获取型号规则
    showDeviceProp(val) {
      this.objectForm.currentModelProp = [];
      let option = this.deviceModelOptions.find(item => {
        return item.value === val;
      });
      this.objectForm.deviceModelId = option.value;
      this.objectForm.deviceModelName = option.name;
      this.objectForm.currentModelProp = JSON.parse(option.prop);
    },
    /**
     * 新增保存设备
     *
     */
    saveEquipment(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var params = {
            orgCode: this.objectForm.orgCode,
            orgName: this.objectForm.orgName,
            deviceClassCode: this.objectForm.deviceClassCode,
            deviceName: this.objectForm.deviceClassName,
            deviceModelId: this.objectForm.deviceModelId,
            remark: this.objectForm.remark
          };
          if (this.objectForm.deviceId) {
            this.objectForm.deviceSpec = [];
            //有设备id调用修改接口
            var propList = this.objectForm.currentModelProp;
            for (let i = 0; i < propList.length; i++) {
              this.objectForm.deviceSpec.push(
                {
                  code: propList[i].code,
                  isId: propList[i].isId,
                  isMust: propList[i].isMust,
                  name: propList[i].name,
                  value: propList[i].value
                }
              );
            }
            params.deviceSpec = JSON.stringify(this.objectForm.deviceSpec);
            params.deviceStatus = this.objectForm.deviceStatus;
            params.id = this.objectForm.deviceId;
            updateDevice(params)
            .then(response => {
              if (response.data.statusCode === "200") {
                this.dialogAddEquipment = false;
                this.$message.success("修改成功");
                this.handleClose();
                this.getList(1);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("updateDevice:" + error);
              return false;
            });
          } else {
            this.objectForm.deviceSpec = [];
            var propList = this.objectForm.currentModelProp;
            for (let i = 0; i < propList.length; i++) {
              this.objectForm.deviceSpec.push(
                {
                  code: propList[i].code,
                  isId: propList[i].isId,
                  isMust: propList[i].isMust,
                  name: propList[i].name,
                  value: propList[i].value
                }
              );
            }
            params.deviceSpec = JSON.stringify(this.objectForm.deviceSpec);
            addDevice(params)
            .then(response => {
              if (response.data.statusCode === "200") {
                this.dialogAddEquipment = false;
                this.$message.success("新增成功");
                this.handleClose();
                this.getList(1);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("addDevice:" + error);
              return false;
            });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     * 获取设备详情
     *
     */
    getDeviceInfo(deviceId) {
      var params = {
        id: deviceId
      };
      findDeviceByPrimarykey(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            var data = response.data.responseData;
            this.objectForm.deviceId = data.id;
            this.objectForm.orgCode = data.orgCode;
            this.objectForm.orgName = data.orgName;
            this.objectForm.deviceCode = data.deviceCode;
            this.objectForm.deviceClassCode = data.deviceClassCode;
            this.objectForm.deviceClassName = data.deviceClassName;
            this.objectForm.deviceModelId = data.deviceModelId;
            this.objectForm.deviceModelName = data.deviceModel;
            this.objectForm.deviceStatus = data.deviceStatus;
            this.objectForm.remark = data.remark;
            this.objectForm.currentModelProp = JSON.parse(data.deviceSpec);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findDeviceByPrimarykey:" + error);
          return false;
        });
    },
    /**
     * Filters 根据设备型号获取原始id拼接规则
     * deviceProp
     */
    findFiltersDeviceModel(val) {
      let option = this.deviceClassOptions.find(item => {
        return item.value === val;
      });
      this.filters.deviceClassCode = option.value;
      this.filters.deviceClassName = option.name;

      if (this.filters.deviceClassCode && this.filters.orgCode) {
        var params = {
          deviceClassCode: this.filters.deviceClassCode,
          orgCode: this.filters.orgCode
        };
        findDeviceModel(params)
          .then(response => {
            if (response.data.statusCode === "200") {
              this.filtersDeviceModelOptions = [];
              var list = response.data.responseData;
              if (list.length > 0) {
                for (let i = 0; i < list.length; i++) {
                  this.filtersDeviceModelOptions.push({
                    name: list[i].deviceModel,
                    value: list[i].id,
                    prop: list[i].deviceSpec
                  });
                }
              }
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          })
          .catch(error => {
            console.log("findDeviceRecord:" + error);
            return false;
          });
      } else {
        this.filtersDeviceModelOptions = [];
      }
    },
    //获取型号规则
    showFiltersDeviceProp(val) {
      let option = this.filtersDeviceModelOptions.find(item => {
        return item.value === val;
      });
      this.filters.deviceModelId = option.value;
      this.filters.deviceModelName = option.name;
    },
    clearFilterMode() {
      this.filtersDeviceModelOptions = [];
      this.filters.deviceModelId = "";
      this.filters.deviceModelName = "";
    },
    /**
     * 列表过滤组织弹窗
     */
    //关闭
    handleCloseOrg() {
      this.dialogVisible = false;
    },
    //获取组织
    getCurrentNode(data) {
      this.filters.orgName = data.orgName;
      this.filters.orgCode = data.orgCode;
      this.handleCloseOrg();
    },
    //清空组织过滤
    clearOrgCode() {
      this.filters.orgName = "";
      this.filters.orgCode = "";
    },
    /**
     * 新增/修改设备信息
     */
    insertEquipment() {
      this.dialogTitle = "新增设备";
      this.dialogAddEquipment = true;
      this.editFlag = false;
      this.deviceStatusOptions = this.deviceStatusOptions1;
    },
    handleEditEquipment(row) {
      this.dialogTitle = "修改设备";
      this.dialogAddEquipment = true;
      this.deviceId = row.id;
      this.editFlag = true;
      this.getDeviceInfo(this.deviceId);
      this.deviceStatusOptions = this.deviceStatusOptions2;
    },
    //关闭添加修改设备弹窗，清空form
    handleClose() {
      this.dialogAddEquipment = false;
      this.$refs.objectForm.resetFields();
      this.objectForm.deviceId = "";
      this.objectForm.orgCode = "";
      this.objectForm.deviceCode = "";
      this.objectForm.deviceClassCode = "";
      this.objectForm.deviceModelId = "";
      this.objectForm.currentModelProp = [];
      this.objectForm.remark = "";
    },
    //父组件触发事件
    pageChange1(val) {
      this.filters1.page = val.page;
      this.filters1.pageSize = val.limit;
      this.handleTableHistory(this.deviceInfo,val.page); //改变页码，重新渲染页面
    },
    /**
     * 历史列表弹窗
     */
    handleTableHistory(row,page) {
      this.dialogTableHistory = true;
      this.listLoading1 = true;
      this.deviceInfo.deviceCode = row.deviceCode;
      this.deviceInfo.deviceClassName = row.deviceClassName;
      this.deviceInfo.deviceModelName = row.deviceModel;
      this.deviceInfo.deviceRawNo = row.deviceRawNo;
      //历史查询接口
      this.filters1.page = page;
      var params = {
        pageNum: this.filters1.page,
        pageSize: this.filters1.pageSize,
        deviceCode: row.deviceCode
      };
      findDeviceRecord(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.historyDataList = response.data.responseData;
            this.totalCount1 = response.data.totalCount;
            this.listLoading1 = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading1 = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findDeviceRecord:" + error);
          this.listLoading1 = false;
          return false;
        });
    },
        //父组件触发事件
    pageChange2(val) {
      this.filters2.page = val.page;
      this.filters2.pageSize = val.limit;
      this.handleTabOldData(this.deviceInfo,val.page); //改变页码，重新渲染页面
    },
    /**
     * 原始数据列表弹窗
     */
    handleTabOldData(row,page) {
      this.dialogTableOldData = true;
      this.listLoading2 = true;
      this.deviceInfo.deviceCode = row.deviceCode;
      this.deviceInfo.deviceClassName = row.deviceClassName;
      this.deviceInfo.deviceModelName = row.deviceModel;
      this.deviceInfo.deviceRawNo = row.deviceRawNo;
      //历史查询接口
      this.filters2.page = page;
      var params = {
        pageNum: this.filters2.page,
        pageSize: this.filters2.pageSize,
        deviceCode: row.deviceCode
      };
      findDeviceData(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.oldDataList = response.data.responseData;
            this.totalCount2 = response.data.totalCount;
            this.listLoading2 = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading2 = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findDeviceData:" + error);
          this.listLoading2 = false;
          return false;
        });
    },
    /**
     * 删除按钮
     */
    handleDelete(index, row) {
      this.$confirm("此操作将永久删除该设备, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        var params = {
          deviceCode: row.deviceCode
        };
        delDeviceByDeviceCode(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.$message.success("删除成功");
            this.getList(1);
          } else {
            return false;
          }
        })
        .catch(error => {
          console.log("delDeviceByDeviceRawNo:" + error);
          return false;
        });
      })
      .catch(err => {
        console.log("delDeviceByDeviceRawNo:" + err);
        return false;
      });
    },
    /**
     * 重置按钮
     */
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.orgCode = "";
      this.getList(1);
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //设备分类
      findValueBySetCode({ valueSetCode: "DEVICE_CLASS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.deviceClassOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //设备状态
      //所有状态
      findValueBySetCode({ valueSetCode: "DEVICE_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.deviceStatusOptions2 = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //只能选择未使用
      findValueBySetCode({ valueSetCode: "DEVICE_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.deviceStatusOptions1 = response.data.responseData;
            for (let i = 0; i < this.deviceStatusOptions1.length; i++) {
              if(this.deviceStatusOptions1[i].value !== '10') {
                this.deviceStatusOptions1[i].disabled = true
              }
            }
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    buttonControl () {
			this.showList.equipment_originalData_onClick = hasPermission(
				"equipment_originalData_onClick"
			);
		}
  },
  created() {
    this.buttonControl();
    this.initDataDictionary();
  },
  mounted() {},
  activated() {
    this.getList(1);
  }
};
</script>

<style lang="scss" scoped>
#equipmentList {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 80px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 0px 10px 0px;
}
.tableList {
  width: 100%;
  overflow-y: auto;
  height:500px;
}
.table-label {
  max-width: 250px;
  word-break: break-all;
}
.tableForm {
  .form-item {
    width: 30%;
    min-width: 350px;
    height: 50px;
  }
}
</style>
<style lang="scss">
#equipmentList {
  .el-form-item__error {
    padding-top: 0px;
  }
}
.el-autocomplete-suggestion {
  min-width: 300px;
}

.el-autocomplete-suggestion__wrap {
  min-width: 300px;
}
</style>