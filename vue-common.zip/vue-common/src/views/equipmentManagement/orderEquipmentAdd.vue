<template>
  <div id="orderManage">
    <headTag :tagName="tagName"/>
    <div class="main-content">
      <el-form
        ref="orderForm"
        :inline="false"
        :model="orderForm"
        :rules="orderFormRules"
        label-width="200px"
        class="form-content"
      >
        <div class="panel-card">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">被照护人信息</span>
              <span v-if="!isShow">
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="saveCareReceiver('orderForm',10)"
                  v-if="flagCare"
                >保存</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="editCareReceiver()"
                  v-if="!flagCare"
                >修改</el-button>
              </span>
              <el-button type="primary" size="mini" class="rightBtn mR5" @click="returnOrderList">返回</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="组织" prop="orgName">
                <span v-if="isEditCare == false">{{orderForm.orgName}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    size="mini"
                    v-model.trim="orderForm.orgName"
                    placeholder="请选择组织"
                    @focus="dialogVisible=true"
                    @clear="clearOrgCode"
                    clearable
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="订单号" prop="orderCode">
                <span v-if="isEditCare == false">{{orderForm.orderCode}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.orderCode"
                    size="mini"
                    clearable
                    :disabled="true"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身份证号" prop="careReceiverIdCard">
                <span v-if="isEditCare == false">{{orderForm.careReceiverIdCard}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    id="idCard"
                    v-model="orderForm.careReceiverIdCard"
                    size="mini"
                    @blur="validatorIdCard(orderForm.careReceiverIdCard)"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请输入身份证号"
                    maxlength="18"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="姓名" prop="careReceiverName">
                <span v-if="isEditCare == false">{{orderForm.careReceiverName}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.careReceiverName"
                    size="mini"
                    clearable
                    placeholder="请输入姓名"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="出生年月" prop="careReceiverBirthday">
                <span v-if="isEditCare == false">{{orderForm.careReceiverBirthday}}</span>
                <span v-if="isEditCare == true">
                  <el-input v-model="orderForm.careReceiverBirthday" size="mini" :disabled="true"></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="性别" prop="careReceiverGender">
                <span v-if="isEditCare == false">{{orderForm.careReceiverGenderValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    v-model="orderForm.careReceiverGender"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in genderOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="是否独居" prop="isLiveAlone" required>
                <span v-if="isEditCare == false">{{orderForm.isLiveAloneValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select v-model="orderForm.isLiveAlone" size="mini" clearable>
                    <el-option
                      v-for="item in isLiveAloneOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="联系方式" prop="careReceiverTel">
                <span v-if="isEditCare == false">{{orderForm.careReceiverTel}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.careReceiverTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住省市区" prop="liveProvinceName">
                <span v-if="isEditCare == false">
                  <span
                    v-if="orderForm.liveProvinceName"
                    class="long-field"
                  >{{orderForm.liveProvinceName}}/{{orderForm.liveCityName}}/{{orderForm.liveDistrictName}}</span>
                </span>
                <span v-if="isEditCare == true">
                  <el-cascader
                    v-model="live"
                    placeholder="请选择现居住省市区"
                    size="mini"
                    :options="liveOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeLive"
                    @change="addLiveToForm"
                    @visible-change="changeLive"
                    ref="liveList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居街道/乡镇" prop="liveSubdistrictName">
                <span v-if="isEditCare == false">{{orderForm.liveSubdistrictName}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    size="mini"
                    v-model="orderForm.liveSubdistrictName"
                    placeholder="请选择街道"
                    @change="selectDistrict(orderForm.liveSubdistrictName)"
                  >
                    <el-option
                      v-for="item in subdistrict"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                <span v-if="isEditCare == false" class="long-field">{{orderForm.liveDetailAddress}}</span>
                <span v-if="isEditCare == true">
                  <el-tooltip
                    class="item"
                    effect="dark"
                    :disabled="orderForm.liveDetailAddress == '' ? true : false"
                    :content="orderForm.liveDetailAddress"
                    placement="top"
                  >
                    <el-input
                      v-model="orderForm.liveDetailAddress"
                      @focus="openMap"
                      size="mini"
                      clearable
                      placeholder="请输入现居住详细地址"
                      maxlength="50"
                    />
                  </el-tooltip>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍省市区" prop="houseProvinceName">
                <span v-if="isEditCare == false">
                  <span
                    v-if="orderForm.houseProvinceName"
                    class="long-field"
                  >{{orderForm.houseProvinceName}}/{{orderForm.houseCityName}}/{{orderForm.houseDistrictName}}</span>
                </span>
                <span v-if="isEditCare == true">
                  <el-cascader
                    v-model="house"
                    placeholder="请选择户籍省市区"
                    size="mini"
                    :options="houseOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeHouse"
                    @change="addHouseToForm"
                    @visible-change="changeHouse"
                    ref="houseList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                <span v-if="isEditCare == false" class="long-field">{{orderForm.houseDetailAddress}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.houseDetailAddress"
                    size="mini"
                    clearable
                    placeholder="请输入户籍详细地址"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="籍贯" prop="nativePlace">
                <span v-if="isEditCare == false">{{orderForm.nativePlace}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.nativePlace"
                    size="mini"
                    clearable
                    placeholder="籍贯"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="民族" prop="careReceiverNation">
                <span v-if="isEditCare == false">{{orderForm.careReceiverNation}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="orderForm.careReceiverNation"
                    size="mini"
                    clearable
                    placeholder="请输入民族"
                    maxlength="20"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="婚姻状况" prop="maritalStatus">
                <span v-if="isEditCare == false">{{orderForm.maritalStatusValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    v-model="orderForm.maritalStatus"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in maritalStatusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="政治面貌" prop="careReceiverPolitical">
                <span v-if="isEditCare == false">{{orderForm.careReceiverPoliticalValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    v-model="orderForm.careReceiverPolitical"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in politicalOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="最高学历" prop="careReceiverEducation">
                <span v-if="isEditCare == false">{{orderForm.careReceiverEducationValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    v-model="orderForm.careReceiverEducation"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in educationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="宗教信仰" prop="careReceiverFaith">
                <span v-if="isEditCare == false">{{orderForm.careReceiverFaithValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select
                    v-model="orderForm.careReceiverFaith"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in faithOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-for="(item, index) in orderForm.careReceiverFamilyList" :key="item.key">
            <el-col class="form-item">
              <el-form-item label="紧急联系人">
                <span v-if="isEditCare == false">{{item.familyMemberName}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="item.familyMemberName"
                    size="mini"
                    maxlength="20"
                    clearable
                    placeholder="请输入紧急联系人"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="联系方式">
                <span v-if="isEditCare == false">{{item.contactsTel}}</span>
                <span v-if="isEditCare == true">
                  <el-input
                    v-model="item.contactsTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item
                label="是联系人的谁"
                :prop="'careReceiverFamilyList.' + index + '.relationship'"
              >
                <span v-if="isEditCare == false">{{item.relationshipValue}}</span>
                <span v-if="isEditCare == true">
                  <el-select v-model="item.relationship" size="mini" clearable placeholder="请选择">
                    <el-option
                      v-for="item in relationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
                <span v-if="index > 0">
                  <el-button
                    type="danger"
                    size="mini"
                    icon="el-icon-delete"
                    style="margin-left:5px;"
                    circle
                    @click="removeContacts(item)"
                    v-if="flagCare"
                  ></el-button>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item>
                <el-button
                  type="primary"
                  icon="el-icon-circle-plus"
                  size="mini"
                  @click="addContacts()"
                  v-if="flagCare"
                >新增紧急联系人</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div v-if="flagEquipment == true">
          <div class="panel-card">
            <el-row class="importToolbar">
              <el-col :span="24">
                <span class="form-tag">设备信息</span>
                <span class="addBtn">
                  <el-button
                    size="mini"
                    icon="el-icon-plus"
                    v-if="!isShow"
                    circle
                    @click="handleOpenDialog"
                  ></el-button>
                </span>
              </el-col>
            </el-row>
            <div v-if="equipmentList.length > 0">
              <el-table
                :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
                size="mini"
                border
                :data="equipmentList"
              >
                <el-table-column property="deviceClassName" label="设备类型" min-width="150"></el-table-column>
                <el-table-column property="deviceModelName" label="型号名称" min-width="150"></el-table-column>
                <el-table-column property="deviceName" label="设备名称" min-width="150"></el-table-column>
                <el-table-column property="deviceCode" label="设备ID" min-width="150"></el-table-column>
                <el-table-column property="orderStartDate" label="服务起止日期" min-width="200">
                  <template slot-scope="scope">
                    <span
                      v-if="scope.row.orderStartDate"
                    >{{scope.row.orderStartDate}}—{{scope.row.orderEndDate}}</span>
                  </template>
                </el-table-column>
                <!-- <el-table-column property="marketPrice" label="市场价" min-width="100"></el-table-column> -->
                <!-- <el-table-column property="sellPrice" label="销售价" min-width="100"></el-table-column> -->
                <el-table-column property="createDate" label="添加时间" min-width="150"></el-table-column>
                <el-table-column label="操作" width="100">
                  <template slot-scope="scope">
                    <span v-if="scope.row.deviceStatus == '10'">
                      <el-button
                        size="mini"
                        type="text"
                        @click="handleEdit(scope.$index,scope.row)"
                      >编辑</el-button>
                      <el-button size="mini" type="text" @click="handleBind(scope.row)">绑定</el-button>
                      <span v-if="scope.row.orderItemStatus == '10'">
                        <el-button
                          size="mini"
                          type="text"
                          @click="handleDelete(scope.$index,scope.row)"
                        >删除</el-button>
                      </span>
                    </span>
                    <span v-if="scope.row.deviceStatus == '20'">
                      <el-button
                        size="mini"
                        type="text"
                        style="color:red;"
                        @click="handleUnBind(scope.row)"
                      >解绑</el-button>
                    </span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="panel-card">
            <el-row class="importToolbar">
              <el-col :span="24">
                <span class="form-tag">服务信息</span>
                <span v-if="!isShow">
                  <el-button
                    type="primary"
                    size="mini"
                    class="rightBtn"
                    @click="saveCareReceiver('orderForm',20)"
                    v-if="flagService"
                  >保存</el-button>
                  <el-button
                    type="primary"
                    size="mini"
                    class="rightBtn"
                    @click="editService()"
                    v-if="!flagService"
                  >修改</el-button>
                </span>
              </el-col>
            </el-row>
            <el-row>
              <!-- <el-col class="form-item">
                <el-form-item label="市场价" prop="marketPrice">
                  <span v-if="isEditService == false">{{orderForm.marketPrice}}</span>
                  <span v-if="isEditService == true">
                    <el-input
                      v-model="orderForm.marketPrice"
                      size="mini"
                      clearable
                      :disabled="true"
                      placeholder="请输入市场价"
                      maxlength="10"
                    />
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="销售价" prop="sellPrice">
                  <span v-if="isEditService == false">{{orderForm.sellPrice}}</span>
                  <span v-if="isEditService == true">
                    <el-input
                      v-model="orderForm.sellPrice"
                      size="mini"
                      clearable
                      :disabled="true"
                      placeholder="请输入销售价"
                      maxlength="10"
                    />
                  </span>
                </el-form-item>
              </el-col>-->
              <el-col class="form-item">
                <el-form-item label="订单状态" prop="orderStatus">
                  <span v-if="isEditService == false">{{orderForm.orderStatusValue}}</span>
                  <span v-if="isEditService == true">
                    <el-select
                      v-model="orderForm.orderStatus"
                      size="mini"
                      clearable
                      :disabled="true"
                      placeholder="请选择订单状态"
                    >
                      <el-option
                        v-for="item in orderStatusOptions"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                        :disabled="item.disabled"
                      ></el-option>
                    </el-select>
                  </span>
                </el-form-item>
              </el-col>
              <el-col class="form-items">
                <el-form-item label="备注">
                  <span v-if="isEditService == false">{{orderForm.remark}}</span>
                  <span v-if="isEditService == true">
                    <el-input
                      type="textarea"
                      class="remark-style"
                      v-model="orderForm.remark"
                      size="mini"
                      clearable
                      placeholder="请输入备注"
                      maxlength="100"
                      show-word-limit
                      resize="none"
                      rows="4"
                    ></el-input>
                  </span>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
        </div>
      </el-form>
    </div>

    <!-- 组织弹窗 -->
    <el-dialog
      title="组织架构"
      :visible.sync="dialogVisible"
      width="500px"
      :before-close="handleCloseOrg"
    >
      <org-select v-on:listenTochildEvent="getCurrentNode"/>
    </el-dialog>

    <map-point
      v-if="this.showMap"
      @GetMapPoint="getAddressDetail"
      @closeDialog="closeDialog"
      :address="orderForm.liveDetailAddress"
      :provinceAddress="orderForm.liveProvinceName"
      :cityAddress="orderForm.liveCityName"
      :districtAddress="orderForm.liveDistrictName"
      :liveLongitude="orderForm.liveLongitude"
      :liveLatitude="orderForm.liveLatitude"
      :placeholder="'请输入现居住详细地址'"
      :maxLength="50"
    ></map-point>

    <!-- 添加设备 -->
    <el-dialog
      title="添加设备"
      :visible.sync="dialogAddEquipment"
      :before-close="handleClose"
      width="450px"
      center
    >
      <el-form
        :inline="true"
        ref="objectForm"
        :model="objectForm"
        :rules="objectRules"
        label-width="120px"
      >
        <el-row>
          <el-col class="form-item">
            <el-form-item label="设备类型" prop="deviceClassCode">
              <span v-if="editFlag == true">{{objectForm.deviceClassName}}</span>
              <span v-if="editFlag == false">
                <span v-if="bindFlag == true">{{objectForm.deviceClassName}}</span>
                <span v-if="bindFlag == false">
                  <el-select
                    size="mini"
                    v-model.trim="objectForm.deviceClassCode"
                    @change="findDeviceModel"
                    clearable
                    placeholder="请选择设备类型"
                  >
                    <el-option
                      v-for="item in deviceClassOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    />
                  </el-select>
                </span>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="型号名称" prop="deviceModelId">
              <span v-if="editFlag == true">{{objectForm.deviceModelName}}</span>
              <span v-if="editFlag == false">
                <span v-if="bindFlag == true">{{objectForm.deviceModelName}}</span>
                <span v-if="bindFlag == false">
                  <el-select
                    size="mini"
                    v-model.trim="objectForm.deviceModelId"
                    @change="showDeviceProp"
                    clearable
                    placeholder="请选择型号名称"
                  >
                    <el-option
                      v-for="item in deviceModelOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    />
                  </el-select>
                </span>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="服务起止日期" prop="orderDate">
              <span
                v-if="bindFlag == true"
              >{{objectForm.orderStartDate}}—{{objectForm.orderEndDate}}</span>
              <span v-if="bindFlag == false">
                <el-date-picker
                  v-model.trim="objectForm.orderDate"
                  clearable
                  size="mini"
                  value-format="yyyy-MM-dd"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
              </span>
            </el-form-item>
          </el-col>
          <!-- <el-col class="form-item">
            <el-form-item label="市场价" prop="marketPrice">
              <span v-if="bindFlag == true">{{objectForm.marketPrice}}</span>
              <span v-if="bindFlag == false">
                <el-input
                  size="mini"
                  v-model.trim="objectForm.marketPrice"
                  clearable
                  placeholder="请输入市场价"
                  maxlength="20"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="销售价" prop="sellPrice">
              <span v-if="bindFlag == true">{{objectForm.sellPrice}}</span>
              <span v-if="bindFlag == false">
                <el-input
                  size="mini"
                  v-model.trim="objectForm.sellPrice"
                  clearable
                  placeholder="请输入销售价"
                  maxlength="20"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>-->
          <el-col class="form-item">
            <el-form-item label="设备名称" prop="deviceName">
              <span v-if="bindFlag == true">{{objectForm.deviceName}}</span>
              <span v-if="bindFlag == false">
                <el-input
                  size="mini"
                  v-model.trim="objectForm.deviceName"
                  clearable
                  placeholder="请输入设备名称"
                  maxlength="20"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <span v-if="bindFlag == true">
            <el-form-item label="设备原始Id" prop="deviceRawNo">
              <el-autocomplete
                :trigger-on-focus="true"
                v-model.trim="objectForm.deviceRawNo"
                popper-class="my-autocomplete"
                size="mini"
                clearable
                :fetch-suggestions="queryDeviceCode"
                placeholder="请输入设备原始ID"
                @select="selectDeviceCode"
                @blur="removeDeviceCode"
                @clear="removeDeviceCode"
              ></el-autocomplete>
            </el-form-item>
            <span v-if="objectForm.deviceClassCode == 'DDJC'">
              <el-form-item label="绑定手机号" prop="phone">
                <el-input
                  size="mini"
                  v-model.trim="objectForm.phone"
                  clearable
                  placeholder="请输入绑定手机号"
                  maxlength="11"
                ></el-input>
              </el-form-item>
            </span>
          </span>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleClose">取消</el-button>
        <el-button
          size="mini"
          style="margin-left:20px;"
          type="primary"
          @click="saveEquipment('objectForm')"
        >确定</el-button>
      </div>
    </el-dialog>

    <!-- 解绑设备弹窗 -->
    <el-dialog
      title="解绑设备"
      :visible.sync="dialogDeviceUnBind"
      width="500px"
      :before-close="handleCloseUnBind"
      center
    >
      <h3 style="text-align:center">解绑后不可恢复，且将不会收到该设备的信息，请谨慎操作！</h3>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleCloseUnBind">取 消</el-button>
        <el-button size="mini" style="margin-left:40px;" type="primary" @click="deviceUnBind">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import MapPoint from "components/MapPoint";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { changeYMD, changeYMDHMS } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail
} from "@/utils/validate";
import { getCareReceiverAuthority } from "api/orderManagement";
import {
  findDeviceModel,
  getDeviceCodeByModelId
} from "api/equipmentManagement/device";
import {
  insertDeviceOrder,
  editDeviceOrder,
  getDeviceOrderDetail,
  insertDeviceOrderItem,
  editDeviceOrderItem,
  deleteDeviceOrderItem,
  findDeviceSettingByOrderCode,
  bindDeviceInfo,
  unBindDeviceInfo
} from "api/equipmentManagement";
import { getEhrOrgDetailByCode } from "api/orgStructure";
import OrgSelect from "components/OrgSelect";
import { parseInt } from "lodash-es";
export default {
  data() {
    return {
      tagName: "订单-设备信息",
      //组织弹窗控制
      dialogVisible: false,
      //添加设备控制
      dialogAddEquipment: false,
      editFlag: false,
      //绑定设备弹窗
      bindFlag: false,
      //解绑设备弹窗
      dialogDeviceUnBind: false,
      unBindCode: "",
      unBindPhone: "",
      //保存禁用
      saveDisabled: false,
      //动态隐藏
      isDisabled: false,
      //控制修改/保存
      isEditCare: false,
      flagCare: false,
      flagEquipment: false,
      isEditService: false,
      flagService: false,
      isShow: false,
      //控制地图弹窗
      showMap: false,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      //图片上传
      hideBriefUpload: false,
      //当前设备列表修改行
      currentIndex: 0,
      /**
       *
       * 设备信息Form
       *
       */
      objectForm: {
        orderCode: "",
        careReceiverCode: "",
        careReceiverIdCard: "",
        deviceClassCode: "",
        deviceClassName: "",
        deviceModelId: "",
        deviceModelName: "",
        deviceName: "",
        deviceRawNo: "",
        orderDate: "",
        orderStartDate: "",
        orderEndDate: "",
        // marketPrice: "",
        // sellPrice: "",
        deviceCode: "",
        phone: ""
      },
      objectRules: {
        deviceClassCode: [
          {
            required: true,
            message: "请选择设备类型",
            trigger: "change"
          }
        ],
        deviceModelId: [
          {
            required: true,
            message: "请选择型号名称",
            trigger: "change"
          }
        ],
        deviceName: [
          {
            required: true,
            message: "请输入设备名称",
            trigger: "blur"
          }
        ],
        orderDate: [
          {
            required: true,
            message: "请选择服务起止日期",
            trigger: "change"
          }
        ],
        // marketPrice: [
        //   {
        //     required: true,
        //     message: "请输入市场价",
        //     trigger: "blur",
        //   },
        //   { validator: isMoney }
        // ],
        // sellPrice: [
        //   {
        //     required: true,
        //     message: "请输入销售价",
        //     trigger: "blur",
        //   },
        //   { validator: isMoney }
        // ],
        deviceRawNo: [
          {
            required: true,
            message: "请选择设备原始Id",
            trigger: "change"
          }
        ],
        phone: [
          {
            required: true,
            message: "请输入绑定手机号",
            trigger: "blur"
          }
        ]
      },
      equipmentList: [],
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      orderForm: {
        //被照护人信息
        orgCode: this.$store.state.user.userOrgCode
          ? this.$store.state.user.userOrgCode
          : "",
        orgName: this.$store.state.user.userOrgName
          ? this.$store.state.user.userOrgName
          : "",
        orgUnitCode: "",
        orgUnitName: "",
        orderCode: "",
        careReceiverCode: "",
        careReceiverIdCard: "",
        careReceiverName: "",
        careReceiverBirthday: "",
        careReceiverGender: "",
        careReceiverGenderValue: "",
        isLiveAlone: "0",
        isLiveAloneValue: "",
        careReceiverTel: "",
        liveProvinceCode: "",
        liveProvinceName: "",
        liveCityCode: "",
        liveCityName: "",
        liveDistrictCode: "",
        liveDistrictName: "",
        liveSubdistrictCode: "",
        liveSubdistrictName: "",
        liveDetailAddress: "",
        liveLatitude: "",
        liveLongitude: "",
        houseProvinceCode: "",
        houseProvinceName: "",
        houseCityCode: "",
        houseCityName: "",
        houseDistrictCode: "",
        houseDistrictName: "",
        houseDetailAddress: "",
        nativePlace: "",
        careReceiverNation: "",
        maritalStatus: "",
        maritalStatusValue: "",
        careReceiverPolitical: "",
        careReceiverPoliticalValue: "",
        careReceiverEducation: "",
        careReceiverEducationValue: "",
        careReceiverFaith: "",
        careReceiverFaithValue: "",
        //服务信息
        // marketPrice: "",
        // sellPrice: "",
        orderStatus: "",
        orderStatusValue: "",
        remark: "",
        careReceiverFamilyList: [
          {
            careReceiverCode: "",
            familyMemberName: "",
            relationship: "",
            relationshipValue: "",
            contactsTel: "",
            contactsStatus: ""
          }
        ]
      },
      //验证
      orderFormRules: {
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "blur"
          }
        ],
        careReceiverName: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        careReceiverIdCard: [
          {
            required: true,
            message: "请输入身份证号",
            trigger: "blur"
          },
          {
            validator: validateIdCard
          }
        ],
        careReceiverBirthday: [
          {
            required: true,
            message: "请输入出生年月",
            trigger: "blur"
          }
        ],
        careReceiverGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        careReceiverTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          }
        ],
        // houseProvinceName: [
        //   {
        //     required: true,
        //     message: "请选择户籍省市区",
        //     trigger: "input"
        //   }
        // ],
        // houseDetailAddress: [
        //   {
        //     required: true,
        //     message: "请输入户籍详细地址",
        //     trigger: "blur"
        //   }
        // ],
        liveProvinceName: [
          {
            required: true,
            message: "请选择现居住省市区",
            trigger: "change"
          }
        ],
        liveSubdistrictName: [
          {
            required: true,
            message: "请选择现居街道/乡镇",
            trigger: "change"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "change"
          }
        ],
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ],
        serviceStartDate: [
          {
            required: true,
            message: "请选择服务开始日期",
            trigger: "blur"
          }
        ],
        contactsTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          }
        ]
      },
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载现居住省市区
      liveOptions: [],
      live: [],
      liveName: [],
      //动态加载街道
      subdistrict: [],
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      genderOptions: [],
      //政治面貌
      politicalOptions: [],
      //最高学历
      educationOptions: [],
      //婚姻状况
      maritalStatusOptions: [],
      //医保类型
      mediacalTypeOptions: [],
      //宗教信仰
      faithOptions: [],
      //身体损伤
      physicalInjuryOptions: [],
      //服务者性别
      careProviderGenderOptions: [],
      //联系人关系
      relationOptions: [],
      //订单状态
      orderStatusOptions: [],
      //是否独居
      isLiveAloneOptions: [],
      //设备分类
      deviceClassOptions: [],
      //设备型号
      deviceModelOptions: [],
      //设备Code
      deviceCodeOptions: [],
      /**
       *
       * 页面传参
       *
       */
      orderCode: ""
    };
  },
  components: {
    HeadTag,
    MapPoint,
    OrgSelect
  },
  methods: {
    /**
     *
     * 保存被照护人信息
     *
     *
     */
    saveCareReceiver(formName, type) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //紧急联系人如果三项都没有填写直接移除
          if (this.orderForm.careReceiverFamilyList.length > 0) {
            var list = this.orderForm.careReceiverFamilyList;
            for (let i = 0; i < list.length; i++) {
              if (
                list[i].familyMemberName == "" &&
                list[i].contactsTel == "" &&
                list[i].relationship == ""
              ) {
                this.orderForm.careReceiverFamilyList.splice(i, 1);
                i = 0;
              }
            }
          }
          if (this.orderForm.orderCode) {
            var params = {
              editType: type,
              orderCode: this.orderForm.orderCode,
              orgCode: this.orderForm.orgCode,
              orgName: this.orderForm.orgName,
              // marketPrice: this.orderForm.marketPrice,
              // sellPrice: this.orderForm.sellPrice,
              orderStatus: this.orderForm.orderStatus,
              remark: this.orderForm.remark,
              //被照护人信息
              careReceiver: {
                orgUnitCode: this.orderForm.orgUnitCode,
                orgUnitName: this.orderForm.orgUnitName,
                careReceiverCode: this.orderForm.careReceiverCode,
                careReceiverName: this.orderForm.careReceiverName,
                careReceiverGender: this.orderForm.careReceiverGender,
                careReceiverBirthday: this.orderForm.careReceiverBirthday,
                careReceiverIdCard: this.orderForm.careReceiverIdCard,
                careReceiverTel: this.orderForm.careReceiverTel,
                liveProvinceCode: this.orderForm.liveProvinceCode,
                liveProvinceName: this.orderForm.liveProvinceName,
                liveCityCode: this.orderForm.liveCityCode,
                liveCityName: this.orderForm.liveCityName,
                liveDistrictCode: this.orderForm.liveDistrictCode,
                liveDistrictName: this.orderForm.liveDistrictName,
                liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
                liveSubdistrictName: this.orderForm.liveSubdistrictName,
                liveDetailAddress: this.orderForm.liveDetailAddress,
                liveLongitude: this.orderForm.liveLongitude,
                liveLatitude: this.orderForm.liveLatitude,
                careReceiverNation: this.orderForm.careReceiverNation,
                nativePlace: this.orderForm.nativePlace,
                houseProvinceCode: this.orderForm.houseProvinceCode,
                houseProvinceName: this.orderForm.houseProvinceName,
                houseCityCode: this.orderForm.houseCityCode,
                houseCityName: this.orderForm.houseCityName,
                houseDistrictCode: this.orderForm.houseDistrictCode,
                houseDistrictName: this.orderForm.houseDistrictName,
                houseDetailAddress: this.orderForm.houseDetailAddress,
                careReceiverPolitical: this.orderForm.careReceiverPolitical,
                careReceiverEducation: this.orderForm.careReceiverEducation,
                maritalStatus: this.orderForm.maritalStatus,
                medicalType: this.orderForm.medicalType,
                medicalCardNo: this.orderForm.medicalCardNo,
                careReceiverFaith: this.orderForm.careReceiverFaith,
                physicalDamage: this.orderForm.physicalDamage,
                isLiveAlone: this.orderForm.isLiveAlone
              },
              //紧急联系人
              familyInDtoList: this.orderForm.careReceiverFamilyList
            };
            editDeviceOrder(params)
              .then(response => {
                if (
                  response.data.statusCode == "200" ||
                  response.data.statusCode == 200
                ) {
                  this.$message.success("修改成功");
                  this.isEditCare = false;
                  this.flagCare = false;
                  this.isEditService = false;
                  this.flagService = false;
                  this.getOrderDetail();
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("editDeviceOrder:" + error);
              });
          } else {
            var params = {
              orgCode: this.orderForm.orgCode,
              orgName: this.orderForm.orgName,
              //被照护人信息
              careReceiver: {
                careReceiverCode: this.orderForm.careReceiverCode,
                careReceiverName: this.orderForm.careReceiverName,
                careReceiverGender: this.orderForm.careReceiverGender,
                careReceiverBirthday: this.orderForm.careReceiverBirthday,
                careReceiverIdCard: this.orderForm.careReceiverIdCard,
                careReceiverTel: this.orderForm.careReceiverTel,
                liveProvinceCode: this.orderForm.liveProvinceCode,
                liveProvinceName: this.orderForm.liveProvinceName,
                liveCityCode: this.orderForm.liveCityCode,
                liveCityName: this.orderForm.liveCityName,
                liveDistrictCode: this.orderForm.liveDistrictCode,
                liveDistrictName: this.orderForm.liveDistrictName,
                liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
                liveSubdistrictName: this.orderForm.liveSubdistrictName,
                liveDetailAddress: this.orderForm.liveDetailAddress,
                liveLongitude: this.orderForm.liveLongitude,
                liveLatitude: this.orderForm.liveLatitude,
                careReceiverNation: this.orderForm.careReceiverNation,
                nativePlace: this.orderForm.nativePlace,
                houseProvinceCode: this.orderForm.houseProvinceCode,
                houseProvinceName: this.orderForm.houseProvinceName,
                houseCityCode: this.orderForm.houseCityCode,
                houseCityName: this.orderForm.houseCityName,
                houseDistrictCode: this.orderForm.houseDistrictCode,
                houseDistrictName: this.orderForm.houseDistrictName,
                houseDetailAddress: this.orderForm.houseDetailAddress,
                careReceiverPolitical: this.orderForm.careReceiverPolitical,
                careReceiverEducation: this.orderForm.careReceiverEducation,
                maritalStatus: this.orderForm.maritalStatus,
                medicalType: this.orderForm.medicalType,
                medicalCardNo: this.orderForm.medicalCardNo,
                careReceiverFaith: this.orderForm.careReceiverFaith,
                physicalDamage: this.orderForm.physicalDamage,
                isLiveAlone: this.orderForm.isLiveAlone
              },
              //紧急联系人
              familyInDtoList: this.orderForm.careReceiverFamilyList
            };
            insertDeviceOrder(params)
              .then(response => {
                if (
                  response.data.statusCode == "200" ||
                  response.data.statusCode == 200
                ) {
                  this.$message.success("新增成功");
                  this.isEditCare = false;
                  this.flagCare = false;
                  this.isEditService = false;
                  this.flagService = false;
                  this.orderForm.orderCode = response.data.responseData;
                  this.orderCode = response.data.responseData;
                  this.getOrderDetail();
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertDeviceOrder:" + error);
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 获取服务Form
     *
     */
    getOrderDetail() {
      var param = {
        orderCode: this.orderCode
      };
      getDeviceOrderDetail(param)
        .then(response => {
          if (response.data.statusCode == 200) {
            var data = response.data.responseData;
            //被照护人信息
            this.orderForm.orderCode = data.orderCode;
            this.orderForm.careReceiverCode = data.careReceiverCode;
            this.orderForm.orderStatus = data.orderStatus;
            this.orderForm.orderStatusValue = data.orderStatusValue;
            this.orderForm.remark = data.remark;
            this.orderForm.orgCode = data.careReceiver.orgCode;
            this.orderForm.orgName = data.careReceiver.orgName;
            this.orderForm.orgUnitCode = data.careReceiver.orgUnitCode;
            this.orderForm.orgUnitName = data.careReceiver.orgUnitName;
            this.orderForm.careReceiverIdCard =
              data.careReceiver.careReceiverIdCard;
            this.orderForm.careReceiverName =
              data.careReceiver.careReceiverName;
            this.orderForm.careReceiverBirthday =
              data.careReceiver.careReceiverBirthday;
            this.orderForm.careReceiverGender =
              data.careReceiver.careReceiverGender;
            this.orderForm.careReceiverGenderValue =
              data.careReceiver.careReceiverGenderValue;
            this.orderForm.isLiveAlone = data.careReceiver.isLiveAlone;
            this.orderForm.isLiveAloneValue =
              data.careReceiver.isLiveAloneValue;
            this.orderForm.careReceiverTel = data.careReceiver.careReceiverTel;
            this.orderForm.liveProvinceCode =
              data.careReceiver.liveProvinceCode;
            this.orderForm.liveProvinceName =
              data.careReceiver.liveProvinceName;
            this.orderForm.liveCityCode = data.careReceiver.liveCityCode;
            this.orderForm.liveCityName = data.careReceiver.liveCityName;
            this.orderForm.liveDistrictCode =
              data.careReceiver.liveDistrictCode;
            this.orderForm.liveDistrictName =
              data.careReceiver.liveDistrictName;
            this.orderForm.liveSubdistrictCode =
              data.careReceiver.liveSubdistrictCode;
            this.orderForm.liveSubdistrictName =
              data.careReceiver.liveSubdistrictName;
            this.orderForm.liveDetailAddress =
              data.careReceiver.liveDetailAddress;
            this.orderForm.liveLongitude = data.careReceiver.liveLongitude;
            this.orderForm.liveLatitude = data.careReceiver.liveLatitude;
            this.orderForm.houseProvinceCode =
              data.careReceiver.houseProvinceCode;
            this.orderForm.houseProvinceName =
              data.careReceiver.houseProvinceName;
            this.orderForm.houseCityCode = data.careReceiver.houseCityCode;
            this.orderForm.houseCityName = data.careReceiver.houseCityName;
            this.orderForm.houseDistrictCode =
              data.careReceiver.houseDistrictCode;
            this.orderForm.houseDistrictName =
              data.careReceiver.houseDistrictName;
            this.orderForm.houseDetailAddress =
              data.careReceiver.houseDetailAddress;
            this.orderForm.nativePlace = data.careReceiver.nativePlace;
            this.orderForm.careReceiverNation =
              data.careReceiver.careReceiverNation;
            this.orderForm.maritalStatus = data.careReceiver.maritalStatus;
            this.orderForm.maritalStatusValue =
              data.careReceiver.maritalStatusValue;
            this.orderForm.careReceiverPolitical =
              data.careReceiver.careReceiverPolitical;
            this.orderForm.careReceiverPoliticalValue =
              data.careReceiver.careReceiverPoliticalValue;
            this.orderForm.careReceiverEducation =
              data.careReceiver.careReceiverEducation;
            this.orderForm.careReceiverEducationValue =
              data.careReceiver.careReceiverEducationValue;
            this.orderForm.careReceiverFaith =
              data.careReceiver.careReceiverFaith;
            this.orderForm.careReceiverFaithValue =
              data.careReceiver.careReceiverFaithValue;
            if (data.familyInDtoList.length == 0) {
              this.orderForm.careReceiverFamilyList = [
                {
                  careReceiverCode: "",
                  familyMemberName: "",
                  relationship: "",
                  relationshipValue: "",
                  contactsTel: "",
                  contactsStatus: ""
                }
              ];
            } else {
              this.orderForm.careReceiverFamilyList = data.familyInDtoList;
            }
            if (data.deviceList.length > 0) {
              this.equipmentList = data.deviceList;
              for (let i = 0; i < this.equipmentList.length; i++) {
                this.equipmentList[i].orderStartDate = changeYMD(
                  this.equipmentList[i].orderStartDate
                );
                this.equipmentList[i].orderEndDate = changeYMD(
                  this.equipmentList[i].orderEndDate
                );
              }
            }
            if (
              this.orderForm.orderStatus == "30" ||
              this.orderForm.orderStatus == "40"
            ) {
              this.isShow = true;
            } else {
              this.isShow = false;
            }
            // if (data.orderStatus) {
            //   for (let i = 0; i < this.orderStatusOptions.length; i++) {
            //     if (
            //       parseInt(this.orderStatusOptions[i].value) <
            //       parseInt(data.orderStatus)
            //     ) {
            //       this.orderStatusOptions[i].disabled = true;
            //     }
            //   }
            // }
            this.getAddressDictListByPid(this.orderForm.liveDistrictCode);
            this.blurChangeBirthday();
            this.blurChangeGender();
            this.$nextTick(() => {
              if (this.$refs["houseList"]) {
                this.$refs["houseList"].inputValue =
                  data.careReceiver.houseDistrictName;
                this.$refs["liveList"].inputValue =
                  data.careReceiver.liveDistrictName;
              }
            });
          }
        })
        .catch(error => {
          console.log("getDeviceOrderDetail:" + error);
        });
    },
    //保存添加设备
    saveEquipment(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var params = {
            orderCode: this.orderForm.orderCode,
            orgCode: this.orderForm.orgCode,
            orgName: this.orderForm.orgName,
            careReceiverCode: this.orderForm.careReceiverCode,
            careReceiverName: this.orderForm.careReceiverName,
            careReceiverIdCard: this.orderForm.careReceiverIdCard,
            deviceClassCode: this.objectForm.deviceClassCode,
            deviceClassName: this.objectForm.deviceClassName,
            deviceModelId: this.objectForm.deviceModelId,
            deviceModelName: this.objectForm.deviceModelName,
            deviceName: this.objectForm.deviceName,
            orderStartDate: this.objectForm.orderDate
              ? this.objectForm.orderDate[0]
              : "",
            orderEndDate: this.objectForm.orderDate
              ? this.objectForm.orderDate[1]
              : ""
            // marketPrice: this.objectForm.marketPrice,
            // sellPrice: this.objectForm.sellPrice
          };
          if (this.objectForm.orderItemCode) {
            if (this.objectForm.deviceCode) {
              params.orderItemCode = this.objectForm.orderItemCode;
              params.deviceCode = this.objectForm.deviceCode;
              params.deviceRawNo = this.objectForm.deviceRawNo;
              if (params.deviceClassCode == "DDJC") {
                params.phone = this.objectForm.phone;
              }
              bindDeviceInfo(params)
                .then(response => {
                  if (response.data.statusCode === "200") {
                    this.dialogAddEquipment = false;
                    this.bindFlag = false;
                    this.$message.success("绑定成功");
                    this.handleClose();
                    this.getOrderDetail();
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("bindDeviceInfo:" + error);
                  return false;
                });
            } else {
              params.orderItemCode = this.objectForm.orderItemCode;
              editDeviceOrderItem(params)
                .then(response => {
                  if (response.data.statusCode === "200") {
                    var data = response.data.responseData;
                    this.dialogAddEquipment = false;
                    this.$message.success("修改成功");
                    this.handleClose();
                    this.getOrderDetail();
                  } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                  }
                })
                .catch(error => {
                  console.log("insertDeviceOrderItem:" + error);
                  return false;
                });
            }
          } else {
            insertDeviceOrderItem(params)
              .then(response => {
                if (response.data.statusCode === "200") {
                  var data = response.data.responseData;
                  this.dialogAddEquipment = false;
                  this.$message.success("新增成功");
                  this.handleClose();
                  this.getOrderDetail();
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("insertDeviceOrderItem:" + error);
                return false;
              });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    //添加设备开窗
    handleOpenDialog() {
      this.dialogAddEquipment = true;
      this.editFlag = false;
    },
    //修改设备
    handleEdit(index, row) {
      this.dialogAddEquipment = true;
      this.editFlag = true;
      this.currentIndex = index;
      this.$nextTick(function() {
        this.objectForm.orderCode = row.orderCode;
        this.objectForm.orderItemCode = row.orderItemCode;
        this.objectForm.careReceiverCode = row.careReceiverCode;
        this.objectForm.careReceiverIdCard = row.careReceiverIdCard;
        this.objectForm.deviceClassCode = row.deviceClassCode;
        this.objectForm.deviceClassName = row.deviceClassName;
        this.objectForm.deviceModelId = row.deviceModelId;
        this.objectForm.deviceModelName = row.deviceModelName;
        this.objectForm.deviceName = row.deviceName;
        if (row.orderStartDate) {
          this.objectForm.orderDate = [row.orderStartDate, row.orderEndDate];
        }
        this.objectForm.orderStartDate = row.orderStartDate
          ? row.orderStartDate
          : "";
        this.objectForm.orderEndDate = row.orderEndDate ? row.orderEndDate : "";
        // this.objectForm.marketPrice = row.marketPrice;
        // this.objectForm.sellPrice = row.sellPrice;
        this.objectForm.deviceStatus = row.deviceStatus;
        this.objectForm.orderItemStatus = row.orderItemStatus;
      });
    },
    //关闭添加设备弹窗，清空form
    handleClose() {
      this.$refs.objectForm.resetFields();
      this.objectForm.careReceiverCode = "";
      this.objectForm.careReceiverIdCard = "";
      this.objectForm.deviceClassName = "";
      this.objectForm.deviceModelName = "";
      this.objectForm.orderCode = "";
      this.objectForm.deviceStatus = "";
      this.objectForm.orderEndDate = "";
      this.objectForm.orderStartDate = "";
      this.objectForm.orderItemCode = "";
      this.objectForm.orderItemStatus = "";
      this.objectForm.orderDate = "";
      this.objectForm.deviceRawNo = "";
      this.objectForm.phone = "";
      this.dialogAddEquipment = false;
      this.bindFlag = false;
    },
    //设备绑定
    handleBind(row) {
      this.dialogAddEquipment = true;
      this.bindFlag = true;
      this.$nextTick(function() {
        this.objectForm.orderCode = row.orderCode;
        this.objectForm.orderItemCode = row.orderItemCode;
        this.objectForm.careReceiverCode = row.careReceiverCode;
        this.objectForm.careReceiverIdCard = row.careReceiverIdCard;
        this.objectForm.deviceClassCode = row.deviceClassCode;
        this.objectForm.deviceClassName = row.deviceClassName;
        this.objectForm.deviceModelId = row.deviceModelId;
        this.objectForm.deviceModelName = row.deviceModelName;
        this.objectForm.deviceName = row.deviceName;
        if (row.orderStartDate) {
          this.objectForm.orderDate = [row.orderStartDate, row.orderEndDate];
        }
        this.objectForm.orderStartDate = row.orderStartDate
          ? row.orderStartDate
          : "";
        this.objectForm.orderEndDate = row.orderEndDate ? row.orderEndDate : "";
        // this.objectForm.marketPrice = row.marketPrice;
        // this.objectForm.sellPrice = row.sellPrice;
        this.objectForm.deviceStatus = row.deviceStatus;
        this.objectForm.orderItemStatus = row.orderItemStatus;
      });
    },
    //设备解绑
    handleUnBind(row) {
      this.dialogDeviceUnBind = true;
      this.unBindCode = row.orderItemCode;
      this.unBindPhone = row.phone;
    },
    deviceUnBind() {
      var params = {
        orderItemCode: this.unBindCode,
        phone: this.unBindPhone,
        orgCode: this.orderForm.orgCode,
        orgName: this.orderForm.orgName,
        careReceiverName: this.orderForm.careReceiverName
      };
      unBindDeviceInfo(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.dialogDeviceUnBind = false;
            this.$message.success("解绑成功");
            this.getOrderDetail();
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("bindDeviceInfo:" + error);
          return false;
        });
    },
    handleCloseUnBind() {
      this.dialogDeviceUnBind = false;
    },
    //设备删除
    handleDelete(index, row) {
      this.$confirm("删除后不可恢复,请谨慎操作！", "删除设备", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let params = {
            orderItemCode: row.orderItemCode
          };
          deleteDeviceOrderItem(params)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$message.success("删除成功");
                this.equipmentList.splice(index, 1);
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("deleteDeviceOrderItem:" + error);
              this.searchLoading = false;
            });
        })
        .catch(() => {
          console.log("已取消删除");
        });
    },
    //加载户籍省市区
    getHouseNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.houseOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //户籍选择下拉框
    handleExpandChangeHouse(val) {
      this.getHouseNodes(val);
    },
    //将户籍省市区注入到Form中
    addHouseToForm(val) {
      this.house = val;
      this.houseName = this.$refs["houseList"].getCheckedNodes();
      this.orderForm.houseProvinceCode = this.house[0];
      this.orderForm.houseProvinceName = this.houseName[0].pathLabels[0];
      this.orderForm.houseCityCode = this.house[1];
      this.orderForm.houseCityName = this.houseName[0].pathLabels[1];
      this.orderForm.houseDistrictCode = this.house[2];
      this.orderForm.houseDistrictName = this.houseName[0].pathLabels[2];
    },
    changeHouse(val) {
      this.$refs["houseList"].presentText = "";
      if (!val) {
        this.$refs["houseList"].inputValue = this.orderForm.houseDistrictName;
        this.$refs["houseList"].presentText = this.orderForm.houseDistrictName;
      }
    },
    //加载现居住省市区
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.orderForm.liveProvinceCode = this.live[0];
      this.orderForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.orderForm.liveCityCode = this.live[1];
      this.orderForm.liveCityName = this.liveName[0].pathLabels[1];
      this.orderForm.liveDistrictCode = this.live[2];
      this.orderForm.liveDistrictName = this.liveName[0].pathLabels[2];
      this.getAddressDictListByPid(this.orderForm.liveDistrictCode);
      this.$nextTick(() => {
        this.orderForm.liveSubdistrictCode = "";
        this.orderForm.liveSubdistrictName = "";
      });
    },
    getAddressDictListByPid(pid) {
      let params = { pid: pid };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          this.subdistrict = response.data.responseData;
        }
      });
    },
    selectDistrict(val) {
      var obj = {};
      obj = this.subdistrict.find(item => {
        return item.id === val;
      });
      this.orderForm.liveSubdistrictCode = obj.id;
      this.orderForm.liveSubdistrictName = obj.name;
      this.$refs["orderForm"].validateField("liveSubdistrictName");
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs["liveList"].inputValue = this.orderForm.liveDistrictName;
        this.$refs["liveList"].presentText = this.orderForm.liveDistrictName;
      }
    },
    //验证身份证关联组织
    validatorIdCard(query) {
      if (!this.orderForm.orgName) {
        this.orderForm.careReceiverIdCard = "";
        this.$message.error("请先选择组织");
        return false;
      }
      let params = {
        careReceiverIdCard: query,
        orgCode: this.orderForm.orgCode
      };
      getCareReceiverAuthority(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            var data = response.data.responseData;
            this.$confirm(
              response.data.responseData.careReceiverName +
                "(" +
                response.data.responseData.careReceiverIdCard +
                ")该被照护人信息已存在，是否自动导入?",
              "提示",
              {
                confirmButtonText: "是",
                cancelButtonText: "否",
                type: "warning"
              }
            )
              .then(() => {
                this.$nextTick(() => {
                  this.$refs["houseList"].inputValue = data.houseDistrictName;
                  this.$refs["liveList"].inputValue = data.liveDistrictName;
                });
                //被照护人信息
                this.orderForm.careReceiverIdCard = data.careReceiverIdCard;
                this.orderForm.careReceiverName = data.careReceiverName;
                this.orderForm.careReceiverBirthday = data.careReceiverBirthday;
                this.orderForm.careReceiverGender = data.careReceiverGender;
                this.orderForm.careReceiverGenderValue =
                  data.careReceiverGenderValue;
                this.orderForm.isLiveAlone = data.isLiveAlone
                  ? data.isLiveAlone
                  : "0";
                this.orderForm.isLiveAloneValue = data.isLiveAloneValue
                  ? data.isLiveAloneValue
                  : "否";
                this.orderForm.careReceiverTel = data.careReceiverTel;
                this.orderForm.liveProvinceCode = data.liveProvinceCode;
                this.orderForm.liveProvinceName = data.liveProvinceName;
                this.orderForm.liveCityCode = data.liveCityCode;
                this.orderForm.liveCityName = data.liveCityName;
                this.orderForm.liveDistrictCode = data.liveDistrictCode;
                this.orderForm.liveDistrictName = data.liveDistrictName;
                this.orderForm.liveSubdistrictCode = data.liveSubdistrictCode;
                this.orderForm.liveSubdistrictName = data.liveSubdistrictName;
                this.orderForm.liveDetailAddress = data.liveDetailAddress;
                this.orderForm.liveLongitude = data.liveLongitude;
                this.orderForm.liveLatitude = data.liveLatitude;
                this.orderForm.houseProvinceCode = data.houseProvinceCode;
                this.orderForm.houseProvinceName = data.houseProvinceName;
                this.orderForm.houseCityCode = data.houseCityCode;
                this.orderForm.houseCityName = data.houseCityName;
                this.orderForm.houseDistrictCode = data.houseDistrictCode;
                this.orderForm.houseDistrictName = data.houseDistrictName;
                this.orderForm.houseDetailAddress = data.houseDetailAddress;
                this.orderForm.nativePlace = data.nativePlace;
                this.orderForm.careReceiverNation = data.careReceiverNation;
                this.orderForm.maritalStatus = data.maritalStatus;
                this.orderForm.maritalStatusValue = data.maritalStatusValue;
                this.orderForm.careReceiverPolitical =
                  data.careReceiverPolitical;
                this.orderForm.careReceiverPoliticalValue =
                  data.careReceiverPoliticalValue;
                this.orderForm.careReceiverEducation =
                  data.careReceiverEducation;
                this.orderForm.careReceiverEducationValue =
                  data.careReceiverEducationValue;
                this.orderForm.careReceiverFaith = data.careReceiverFaith;
                this.orderForm.careReceiverFaithValue =
                  data.careReceiverFaithValue;
                if (data.careReceiverFamilyList.length == 0) {
                  this.orderForm.careReceiverFamilyList = [
                    {
                      careReceiverCode: "",
                      familyMemberName: "",
                      relationship: "",
                      relationshipValue: "",
                      contactsTel: "",
                      contactsStatus: ""
                    }
                  ];
                } else {
                  this.orderForm.careReceiverFamilyList =
                    data.careReceiverFamilyList;
                }
                this.getAddressDictListByPid(this.orderForm.liveDistrictCode);
                this.blurChangeBirthday();
                this.blurChangeGender();
              })
              .catch(error => {
                console.log("getCareReceiverAuthority:" + error);
                this.orderForm.careReceiverIdCard = "";
                return false;
              });
          } else if (response.data.statusCode == "221") {
            this.blurChangeBirthday();
            this.blurChangeGender();
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getCareReceiverAuthority:" + error);
        });
    },
    openMap() {
      this.showMap = true;
    },
    closeDialog(flag) {
      this.showMap = flag;
    },
    getAddressDetail(data) {
      this.orderForm.liveDetailAddress = data[0];
      this.orderForm.liveLongitude = data[1].lng;
      this.orderForm.liveLatitude = data[1].lat;
    },
    //新增删除联系人操作
    removeContacts(item) {
      var index = this.orderForm.careReceiverFamilyList.indexOf(item);
      if (index !== -1) {
        this.orderForm.careReceiverFamilyList.splice(index, 1);
      }
    },
    addContacts() {
      if (this.orderForm.careReceiverFamilyList.length > 10) {
        this.$message.error("紧急联系人最多增加10条记录");
        return false;
      } else {
        this.orderForm.careReceiverFamilyList.push({
          careReceiverCode: "",
          familyMemberName: "",
          relationship: "",
          relationshipValue: "",
          contactsTel: "",
          contactsStatus: "",
          key: Date.now()
        });
      }
    },
    //根据身份证计算出生年月
    blurChangeBirthday() {
      this.$refs.orderForm.validateField("careReceiverIdCard", cardError => {
        if (!cardError) {
          //当校验通过时，这里面写逻辑代码
          let card = this.orderForm.careReceiverIdCard;
          if (card.length == 15) {
            //第一代身份证
            this.orderForm.careReceiverBirthday =
              "19" +
              card.substring(6, 8) +
              "-" +
              card.substring(8, 10) +
              "-" +
              card.substring(10, 12);
          } else {
            this.orderForm.careReceiverBirthday =
              card.substring(6, 10) +
              "-" +
              card.substring(10, 12) +
              "-" +
              card.substring(12, 14);
          }
        } else {
          this.orderForm.careReceiverBirthday = "";
        }
      });
    },
    //根据身份证识别性别
    blurChangeGender() {
      this.$refs.orderForm.validateField("careReceiverIdCard", cardError => {
        if (!cardError) {
          //当校验通过时，这里面写逻辑代码
          let card = this.orderForm.careReceiverIdCard;
          let char = card.substring(16, 17);
          if (char % 2 == 0) {
            this.orderForm.careReceiverGender = "0";
          } else {
            this.orderForm.careReceiverGender = "1";
          }
        } else {
          this.orderForm.careReceiverGender = "";
        }
      });
    },
    /**
     * 根据设备型号获取原始id拼接规则
     * deviceProp
     */
    findDeviceModel(val) {
      if (val) {
        let option = this.deviceClassOptions.find(item => {
          return item.value === val;
        });
        this.objectForm.deviceClassCode = option.value;
        this.objectForm.deviceClassName = option.name;
        this.objectForm.deviceName = option.name;
      }

      if (this.objectForm.deviceClassCode && this.orderForm.orgCode) {
        var params = {
          deviceClassCode: this.objectForm.deviceClassCode,
          orgCode: this.orderForm.orgCode
        };
        findDeviceModel(params)
          .then(response => {
            if (response.data.statusCode === "200") {
              this.deviceModelOptions = [];
              var list = response.data.responseData;
              if (list.length > 0) {
                for (let i = 0; i < list.length; i++) {
                  this.deviceModelOptions.push({
                    name: list[i].deviceModel,
                    value: list[i].id,
                    prop: list[i].deviceSpec
                  });
                }
              }
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          })
          .catch(error => {
            console.log("findDeviceRecord:" + error);
            return false;
          });
      } else {
        this.deviceModelOptions = [];
      }
    },
    //获取型号规则
    showDeviceProp(val) {
      let option = this.deviceModelOptions.find(item => {
        return item.value === val;
      });
      this.objectForm.deviceModelId = option.value;
      this.objectForm.deviceModelName = option.name;
    },
    /**
     *
     * 模糊查询
     *
     */
    //设备ID模糊查询
    selectDeviceCode(item) {
      if (item.value !== "无") {
        this.objectForm.deviceCode = item.dCode;
        this.objectForm.deviceRawNo = item.value;
      } else {
        this.objectForm.deviceCode = "";
        this.objectForm.deviceRawNo = "";
      }
    },
    removeDeviceCode() {
      this.objectForm.deviceCode = "";
      this.objectForm.deviceRawNo = "";
    },
    queryDeviceCode(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        deviceModelId: this.objectForm.deviceModelId,
        deviceRawNo: queryString
      };
      getDeviceCodeByModelId(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.deviceCodeOptions = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.deviceCodeOptions.push({
                value: data[i].deviceRawNo,
                code: data[i].deviceRawNo,
                dCode: data[i].deviceCode
              });
            }
            var results = this.deviceCodeOptions;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getDeviceCodeByModelId:" + error);
          return false;
        });
    },
    //根据默认组织查询组织省市区
    getEhrOrgDetailByCode() {
      if (this.$store.state.user.userOrgCode) {
        var params = {
          orgCode: this.$store.state.user.userOrgCode
        };
        getEhrOrgDetailByCode(params)
          .then(response => {
            if (response.data.statusCode === "200") {
              var data = response.data.responseData;
              this.orderForm.liveProvinceCode = data.orgProvinceCode;
              this.orderForm.liveProvinceName = data.orgProvinceName;
              this.orderForm.liveCityCode = data.orgCityCode;
              this.orderForm.liveCityName = data.orgCityName;
              this.orderForm.liveDistrictCode = data.orgDistrictCode;
              this.orderForm.liveDistrictName = data.orgDistrictName;
              this.getAddressDictListByPid(this.orderForm.liveDistrictCode);
              this.$nextTick(() => {
                this.$refs["liveList"].inputValue = data.orgDistrictName;
              });
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          })
          .catch(error => {
            console.log("getEhrOrgDetailByCode:" + error);
            return false;
          });
      }
    },
    /**
     * 组织弹窗
     */
    //关闭
    handleCloseOrg() {
      this.dialogVisible = false;
    },
    //获取组织
    getCurrentNode(data) {
      this.orderForm.orgName = data.orgName;
      this.orderForm.orgCode = data.orgCode;
      this.handleCloseOrg();
    },
    //清空组织过滤
    clearOrgCode() {
      this.orderForm.orgName = "";
      this.orderForm.orgCode = "";
      this.orderForm.orgUnitName = "";
      this.orderForm.orgUnitCode = "";
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editCareReceiver() {
      //修改被照护人
      this.isEditCare = true;
      this.flagCare = true;
      this.isDisabled = true;
      this.getOrderDetail();
    },
    editService() {
      //修改服务信息
      this.isEditService = true;
      this.flagService = true;
      this.getOrderDetail();
    },
    /**
     *
     * 返回订单管理列表
     *
     */
    returnOrderList() {
      this.$router.push({
        path: "/wisdomCustody/orderEquipment"
      });
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //政治面貌
      findValueBySetCode({ valueSetCode: "STAFF_POLITICAL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.politicalOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //婚姻状况
      findValueBySetCode({ valueSetCode: "RECRUIT_MARITAL_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.maritalStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //医保类型
      findValueBySetCode({ valueSetCode: "HEALTH_INSURANCE_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.mediacalTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //宗教信仰
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //身体损伤
      findValueBySetCode({ valueSetCode: "PHYSICAL_INJURY" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.physicalInjuryOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务者性别
      findValueBySetCode({ valueSetCode: "CARE_PROVIDER_GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.careProviderGenderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //联系人关系
      findValueBySetCode({ valueSetCode: "CARE_RECEIVER_RELATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.relationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否独居
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isLiveAloneOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //订单状态
      findValueBySetCode({ valueSetCode: "DEVICE_ORDER_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.orderStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //设备分类
      findValueBySetCode({ valueSetCode: "DEVICE_CLASS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.deviceClassOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    if (param.type == "update") {
      this.orderCode = param.orderCode;
      this.isEditCare = false;
      this.flagCare = false;
      this.flagEquipment = true;
      this.isEditService = false;
      this.flagService = false;
      //获取服务Form详情
      this.getOrderDetail();
    } else {
      this.isEditCare = true;
      this.flagCare = true;
      this.flagEquipment = false;
      this.isEditService = true;
      this.flagService = true;
      //查询默认省市区
      this.getEhrOrgDetailByCode();
    }
    this.initDataDictionary();
    //加载户籍省市区
    this.getHouseNodes();
    //加载现居住省市区
    this.getLiveNodes();
  },
  mounted() {},
  destroyed() {
    // sessionStorage.removeItem("editOrderCode");
  }
};
</script>

<style lang="scss" scoped>
#orderManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.mR5 {
  margin-right: 5px;
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 20px 10px 10px 10px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .addBtn {
    margin-left: 10px;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.form-item {
  width: 30%;
  min-width: 450px;
  height: 50px;
}
.form-items {
  width: 100%;
  min-width: 450px;
  height: 110px;
}
.form-item-product {
  width: 100%;
}
.radioRight {
  margin-right: 10px;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
.remark-style {
  display: block;
  width: 250px;
  margin-top: 5px;
}
</style>
<style lang="scss">
#orderManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .el-form-item__content .el-input-group {
    vertical-align: unset;
  }
  .hideBrief .el-upload--picture-card {
    display: none;
  }
}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>