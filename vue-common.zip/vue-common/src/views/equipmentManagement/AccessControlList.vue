<template>
  <div>
    <headTag :tagName="tagName" />
    <base-equipment-item-list/>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import BaseEquipmentItemList from "./BaseEquipmentItemList"
export default {
  components: {
    HeadTag,
    BaseEquipmentItemList
  },
  props: {},
  data() {
    return {
      tagName: "门磁感应器",
    };
  },
  watch: {
    
  },
  computed: {},
  methods: {
    
  },
  created() {
   
  },
  mounted() {
  }
};
</script>
<style lang="scss">

</style>