<template>
  <div>
    <div class="seettingTop">
      <div class="info-left">
        <div class="person-detail">
          <!--头像-->
          <span v-if="careReceiver.careReceiverIcon" slot="reference">
            <el-avatar
              size="large"
              style="vertical-align: middle;"
              :src="careReceiver.careReceiverIcon"
              class="avatar"
            ></el-avatar>
          </span>
          <span v-else slot="reference">
            <svg-icon icon-class="equip-avatar-default" class="avatar" />
          </span>
        </div>
        <div class="person-info">
          <span>{{careReceiver.careReceiverName}}</span>
          <span v-if="careReceiver.isLiveAlone=='1'">
            <span class="person-color">独居</span>
          </span>
        </div>
      </div>
      <div class="info-right" style="width:100%;padding:10px 0;">
        <div class="basic-info">
          <el-row style="margin-top:20px">
            <el-col :span="22" style="font-size:16px;color:#333333;">基本信息</el-col>
          </el-row>
          <el-row style="margin-top:20px">
            <el-col class="info-text" :span="8">年龄:{{getAge(careReceiver)}}</el-col>
            <el-col class="info-text" :span="8">性别:{{careReceiver.careReceiverGenderValue}}</el-col>
            <el-col class="info-text" :span="8">生日:{{getBirthday(careReceiver)}}</el-col>
          </el-row>
          <el-row style="margin-top:20px">
            <el-col
              class="info-text"
            >地址:{{careReceiver.liveProvinceName+careReceiver.liveCityName+careReceiver.liveDistrictName+careReceiver.liveSubdistrictName+careReceiver.liveDetailAddress}}</el-col>
          </el-row>
        </div>
      </div>
    </div>
    <div style="width: 250px;height:50px;margin-top:10px;display:inline;">
      <el-select v-model="deviceName" size="mini" clearable @change="changeDevice" @clear="clearDevice">
        <el-option
          v-for="item in monitorDevices"
          :key="item.value"
          :label="item.name"
          :value="item.value"
        ></el-option>
      </el-select>
      <el-date-picker
        v-model="reportDate"
        :picker-options="pickerOptions"
        size="mini"
        type="date"
        @change="changeDate"
        style="margin:10px auto;"
        placeholder="选择日期">
      </el-date-picker>
    </div>
    <div class="container">
      <el-tabs class="tabClass" @tab-click="handleClick" type="border-card" v-model="activeName">
        <el-tab-pane label="日报" name="first">
          <iframe width="100%" height="400px"
          :src="dailyUrl"
          frameborder="0"></iframe>
        </el-tab-pane>
        <!-- <el-tab-pane label="周报" name="second">
          <iframe width="100%" height="350px"
          :src="weeklyUrl"
          frameborder="0"></iframe>
        </el-tab-pane> -->
      </el-tabs>
    </div>
  </div>
</template>

<script>
import { getAgeFromIdentityCard, getBirthdayFromIdentityCard } from "@/utils";
import { findOrderDeviceByClass} from "@/api/equipmentManagement";
import { getYueYangAccountInfo } from "@/api/equipmentManagement/device"
export default {
  props: {
    careReceiver: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      activeName: 'first',
      //日报链接
      dailyUrl:'',
      //周报链接
      weeklyUrl: '',
      //报告日期
      reportDate: this.getNowTime(),
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now() - 24 * 60 * 60 * 1000;
        }
      },
      //第三方参数
      account: "",
      password: "",
      guardianId: "",
      externalId: "",
      //床垫
      deviceName: "",
      monitorDevices: [],
      //接收跳转参数
      careReceiver: {},
    };
  },
  watch: {},
  computed: {},
  methods: {
    handleClick(tab, event) {
      if(tab.name == 'first') {
        this.dailyPanel();
      } else {
        this.weeklyPanel();
      }
    },
    dailyPanel(){
      this.dailyUrl = `https://org.yymedic.com/autoLogin?userName=${this.account}&password=${this.password}&redirect=/guardians/${this.guardianId}/users/${this.externalId}/userSleepReport?date=${this.reportDate}&tab=daily&onlyShowContent=true`
      this.$forceUpdate();
    },
    weeklyPanel(){
      this.weeklyUrl = `https://org.yymedic.com/autoLogin?userName=${this.account}&password=${this.password}&redirect=/guardians/${this.guardianId}/users/${this.externalId}/userSleepReport?date=${this.reportDate}&tab=weekly&onlyShowContent=true`
      this.$forceUpdate();
    },
    //处理默认选中当前日期
    getNowTime() {
      var now = new Date();
      var year = now.getFullYear(); //得到年份
      var month = now.getMonth() + 1; //得到月份
      var date = now.getDate() - 1; //得到日期
      month = month.toString().padStart(2, "0");
      date = date.toString().padStart(2, "0");
      var defaultDate = `${year}-${month}-${date}`;
      return defaultDate;
    },
    getBirthday (item) {
        return getBirthdayFromIdentityCard(item.careReceiverIdCard);
    },
    getAge (item) {
        return getAgeFromIdentityCard(item.careReceiverIdCard);
    },
    changeDate() {
      if(this.activeName == 'first') {
        this.dailyPanel();
      } else {
        this.weeklyPanel();
      }
    },
    changeDevice(val) {
      if(val) {
        var device = this.monitorDevices.find(item => {
          return item.value == val;
        })
        this.deviceName = device.name;
        this.externalId = device.externalId;
        this.$nextTick(()=>{
          this.activeName = 'first';
          this.dailyPanel();
        })
      }
    },
    clearDevice() {
      this.deviceName = "";
    },
    findOrderDevices(){
      var params = {
        orderCode: this.careReceiver.orderCode,
        careReceiverCode: this.careReceiver.careReceiverCode,
        deviceClassCode: this.careReceiver.deviceClassCode,
        deviceClassName: this.careReceiver.deviceClassName
      }
      findOrderDeviceByClass(params).then(response=>{
        if(response.data.statusCode==200){
          var devices=response.data.responseData.devices;
          this.monitorDevices=[];
          if(devices.length > 0) {
            devices.forEach(item=>{
              this.monitorDevices.push({
                name: item.deviceName,
                value: item.deviceRawNo,
                externalId: item.thirdPartyUserId
              });
            })
          }

          this.deviceName = this.monitorDevices[0].name;
          this.externalId = this.monitorDevices[0].externalId;
        }
      }).catch(error=>{
        this.$message.error("findOrderDeviceByClass:"+error);
        return false;
      })
    },
    getYueYangAccountInfo() {
      var params = {}
      getYueYangAccountInfo(params).then(response=>{
        if(response.data.statusCode==200){
          var data = response.data.responseData;
          this.account = data.account;
          this.password = data.password;
          this.guardianId = data.guardianId;
          // this.account = 'fsktest001';
          // this.password = 'e10adc3949ba59abbe56e057f20f883e';
          // this.guardianId = '5db954f747ca8e0001e7f1f8';
          this.dailyPanel();
        }
      }).catch(error=>{
        this.$message.error("getYueYangAccountInfo:"+error);
        return false;
      })
    }
  },
  created () {
    this.findOrderDevices();
  },
  mounted () {
    this.getYueYangAccountInfo();
  }
};
</script>
<style lang="scss" scoped>
.seettingTop {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  border-radius: 6px;
  // height: 270px;
  display: flex;
  .info-left {
    .person-detail {
      padding: 30px 50px 10px 50px
    }
    .person-info {
      text-align: center;
      span {
        font-size: 16px;
        color: #333333;
      }
      .person-color {
        background: rgba(240, 75, 95, 1);
        border-radius: 10px;
        color: #ffffff;
        margin-left: 10px;
        padding: 4px;
        font-size: 14px;
      }
    }
  }
}
.container {
  // background-color: #fff;
  // box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
  // border-radius: 6px;
  margin-top: 10px;
  .tabClass {
    border-radius: 5px;
    // border: 1px solid #e0e0e0;
    .room-monitor {
      padding: 10px;
      align-items: center;
      display: flex;
      align-content: center;
    }
  }
}
.avatar {
  width: 60px;
  height: 60px;
  cursor: pointer;
}
</style>