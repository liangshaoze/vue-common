<template>
	<div id="alarmList">
		<headTag :tagName="tagName" />
		<div class="filter_wrap">
			<el-form ref="keyWordsForm" :inline="true" :model="keyWords" label-width="125px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="组织" prop="orgName">
							<el-input
								size="mini"
								v-model.trim="keyWords.orgName"
								placeholder="请选择组织"
								@focus="dialogVisible=true"
								@clear="clearOrgCode"
								clearable
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="告警类型" prop="alarmType">
							<el-select size="mini" v-model.trim="keyWords.alarmType" clearable placeholder="请选择告警类型">
								<el-option
									v-for="item in alarmTypeOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-items">
						<el-form-item label="告警时间" prop="alarmTime">
							<el-date-picker
								v-model.trim="keyWords.alarmTime"
								clearable
								size="mini"
								format="yyyy-MM-dd HH:mm:ss"
								value-format="yyyy-MM-dd HH:mm:ss"
								type="datetimerange"
								style="width:370px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item" v-if="isSingle">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="keyWords.careReceiverName"
								clearable
								:disabled="true"
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item" v-if="isOverall">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-autocomplete
								:trigger-on-focus="true"
								popper-class="my-autocomplete"
								v-model.trim="keyWords.typeCareReceiverName"
								:fetch-suggestions="queryCareReceiverName"
								@select="selectCareReceiverName"
								@blur="removeCareReceiverName"
								@clear="removeCareReceiverName"
								size="mini"
								:disabled="false"
								clearable
								placeholder="请输入被照护人姓名"
							></el-autocomplete>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="处理状态" prop="handleStatus">
							<el-select size="mini" v-model.trim="keyWords.handleStatus" clearable placeholder="请选择状态">
								<el-option
									v-for="item in handlingStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								@click="getList(1)"
								icon="el-icon-search"
								:loading="searchLoading"
								size="mini"
								type="primary"
							>查询</el-button>
							<!-- <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button> -->
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<div class="tableToolbar">
			<el-row class="tableTopBtn"></el-row>
			<el-table
				:data="tableData"
				:header-cell-style="{
          background: 'rgba(57, 138, 241, 0.1)',
          color: '#606266'
        }"
				element-loading-text="拼命加载中"
				highlight-current-row
				size="mini"
				stripe
				style="width:100%;"
				v-loading="listLoading"
			>
				<el-table-column label="被照护人姓名" min-width="100" prop="careReceiverName"></el-table-column>
				<el-table-column label="组织" min-width="100" prop="orgName"></el-table-column>
				<el-table-column label="告警时间" min-width="100">
					<template slot-scope="scope">
						<span v-if="scope.row.alarmDate">{{scope.row.alarmDate}}</span>
					</template>
				</el-table-column>
				<el-table-column label="告警类型" min-width="100" prop="alarmType"></el-table-column>
				<el-table-column label="告警事件" min-width="100" prop="alarmEvent"></el-table-column>
				<el-table-column label="处理状态" min-width="100" prop="handleStatusValue"></el-table-column>
				<el-table-column label="处理时间" min-width="100" prop="handlingDate">
					<template slot-scope="scope">
						<span v-if="scope.row.handleDate">{{scope.row.handleDate}}</span>
					</template>
				</el-table-column>
				<el-table-column label="处理结果" min-width="100" prop="handleResult"></el-table-column>
				<el-table-column label="处理人" min-width="100" prop="handlerName"></el-table-column>
				<el-table-column label="设备ID" min-width="100" prop="deviceCode"></el-table-column>
				<el-table-column label="操作" width="100">
					<template slot-scope="scope">
						<el-button
							v-if="scope.row.handleStatus=='10'||scope.row.handleStatus=='20'"
							@click="details(scope.row.alarmCode,'2')"
							size="mini"
							type="text"
						>处理</el-button>
						<el-button
							v-if="scope.row.handleStatus=='30'"
							@click="details(scope.row.alarmCode,'1')"
							size="mini"
							type="text"
						>详情</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<!--分页-->
				<pagination
					:limit.sync="keyWords.pageSize"
					:page.sync="keyWords.pageNum"
					:total="totalCount"
					@pagination="pageChange"
					v-if="totalCount > 0"
				/>
			</el-row>
		</div>
		<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="close">
			<org-select v-on:listenTochildEvent="getCurrentNode" />
		</el-dialog>
		<!-- 报警处理弹窗 -->
		<el-dialog
			:title="titleName"
			:visible.sync="dialogAlarmProcess"
			width="750px"
			:before-close="alarmProcessclose"
		>
			<div class="timeLine">
				<basicInfo :careReceiverDetail="careReceiverDetail" />
				<div class="block">
					<el-timeline>
						<el-timeline-item :timestamp="timeFrist" color="#F04B5F" placement="top">
							<p>{{detailObj.alarmType}}:{{detailObj.alarmEvent}}</p>
						</el-timeline-item>
						<el-timeline-item
							v-for="(item, index) in detailObj.deviceOrderAlarmRecordOutDtos"
							:key="index"
							:timestamp="item.handleDate"
							color="#398AF1"
							placement="top"
						>
							<el-card>
								<p>情况描述：{{item.conditionDesc}}</p>
								<p>处理结果：{{item.handleResult}}</p>
								<p>处理人：{{item.handleName}}</p>
								<p>处理状态:{{item.handleStatusValue}}</p>
								<p>记录人：{{item.createName }}</p>
								<p>备注：{{item.remark}}</p>
							</el-card>
						</el-timeline-item>
						<el-timeline-item color="#398AF1" placement="top" v-if="isEdit">
							<el-button type="primary" size="mini" v-show="isShow" @click="addAlarm" round>添加</el-button>
							<el-card v-show="isAlarm">
								<el-form
									:inline="false"
									:model="alarmForm"
									:rules="alarmFormRules"
									label-width="100px"
									ref="alarmForm"
								>
									<el-form-item class="alarmClass" label="情况描述:" prop="conditionDesc">
										<el-input
											clearable
											type="textarea"
											placeholder="请输入情况描述"
											size="mini"
											resize="none"
											rows="4"
											show-word-limit
											v-model="alarmForm.conditionDesc"
										></el-input>
									</el-form-item>
									<el-form-item class="alarmClass" label="处理结果:" prop="handleResult">
										<el-input clearable placeholder="请输入处理结果" size="mini" v-model="alarmForm.handleResult"></el-input>
									</el-form-item>
									<el-form-item class="alarmClass" label="处理人:" prop="handleNameList">
										<el-select
											v-model.trim="alarmForm.handleNameList"
											clearable
											multiple
											filterable
											remote
											size="mini"
											reserve-keyword
											placeholder="请输入处理人"
											:remote-method="remoteMethod"
											:loading="loading"
											@focus="selectName"
											@change="selectChange"
										>
											<el-option
												v-for="item in serviceOptions "
												:key="item.value"
												:label="item.label"
												:value="item.value"
											></el-option>
										</el-select>
									</el-form-item>
									<el-form-item class="alarmClass" label="处理状态" prop="handleStatus">
										<el-select
											size="mini"
											v-model.trim="alarmForm.handleStatus"
											clearable
											placeholder="请选择状态"
										>
											<el-option
												v-for="item in options"
												:key="item.value"
												:label="item.name"
												:value="item.value"
											/>
										</el-select>
									</el-form-item>
									<el-form-item class="alarmClass" label="记录人:">
										<el-col>{{alarmName}}</el-col>
									</el-form-item>
									<el-form-item class="alarmClass" label="备注:" prop="remark">
										<el-input
											clearable
											placeholder="请输入备注"
											type="textarea"
											size="mini"
											v-model="alarmForm.remark"
											resize="none"
											rows="4"
											show-word-limit
											maxlength="100"
										></el-input>
									</el-form-item>
									<el-form-item class="alarmClass">
										<el-button @click="cancelBtn" size="mini">取消</el-button>
										<el-button
											style="margin-left:30px;"
											@click="editAlarms('alarmForm')"
											size="mini"
											type="primary"
										>确 定</el-button>
									</el-form-item>
								</el-form>
							</el-card>
						</el-timeline-item>
					</el-timeline>
				</div>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import basicInfo from "./components/basicInfo";
import { findValueBySetCode } from "api/common";
import { findStaffAll } from "api/customerManagement";
import {
	findDeviceOrderAlarmList,
	getDeviceOrderAlarm,
	insertDeviceOrderAlarmRecord,
	findCareReceiverForDevice
} from "api/equipmentManagement/device";
import {
	findInServiceOrderList,
} from "api/workOrderManagement";
import { getEtCareReceiver } from "@/api/businessService/workOrderSchedule"

export default {

	components: {
		HeadTag,
		OrgSelect,
		Pagination,
		basicInfo
	},
	props: {},

	data () {
		return {
			tagName: "报警管理",

			keyWords: {
				orgCode: '',
				orgName: '',
				orgCode: '',
				orgName: '',
				handleStatus: '',
				alarmTime: '',
				careReceiverCode: '',
				careReceiverName: '',
				typeCareReceiverCode: '',
				typeCareReceiverName: '',
				alarmType: '',
				pageNum: 1,
				pageSize: 10
			},
			alarmFormRules: {
				conditionDesc: [
					{
						required: true,
						message: "请输入情况描述",
						trigger: "change"
					}
				],
				handleStatus: [
					{
						required: true,
						message: "请选择处理状态",
						trigger: "change"
					}
				],
				handleResult: [
					{
						required: true,
						message: "请输入处理结果",
						trigger: "blur"
					}
				],
				handleNameList: [
					{
						required: true,
						message: "请选择处理人",
						trigger: "change"
					}
				],
				remark: [
					{
						required: false,
						message: "请输入备注",
						trigger: "blur"
					}
				],
			},
			nameArr: [],
			codeArr: [],
			alarmForm: {
				alarmCode: '',

				remark: '',
				handleStatus: '',
				handleNameList: [
					// this.$store.getters.userFullName
				],
				handleCode: '',
				handleName: '',
				handleResult: '',
				conditionDesc: '',
			},
			alarmName: this.$store.getters.userFullName,
			selectList: [],
			isShow: true,
			isAlarm: false,
			isSingle: false,
			isOverall: false,
			totalCount: 0,
			alarmTypeOptions: [],
			statusOptions: [],
			tableData: [],
			dialogVisible: false,
			dialogAlarmDetail: false,
			dialogAlarmProcess: false,
			listLoading: false,
			searchLoading: false,
			handlingStatusOptions: [],
			detailObj: {},
			timeFrist: '',
			staffList: [],
			dataList: [],
			loading: false,
			serviceOptions: [],
			options: [{
				value: '20',
				name: '处理中'
			}, {
				value: '30',
				name: '处理完成'
			}],
			isEdit: false,
			titleName: '',
			careReceiverNameOptions: [],
			careReceiverDetail: {},
			careReceiver: {}
		};
	},
	watch: {
		$route () {
			this.type = this.$route.query.type; //获取传来的参数 
			this.getList(1); //路由变化时就重新执行这个方法 更新传来的参数
		}
	},
	computed: {},
	methods: {
		selectCareReceiverName (item) {
			console.log(item)
			if (item.value !== "无") {
				this.keyWords.typeCareReceiverCode = item.code;
				this.keyWords.typeCareReceiverName = item.value;
			} else {
				this.keyWords.typeCareReceiverName = "";
			}
		},
		queryCareReceiverName (queryString, cb) {
			let params = {};
			if (queryString) {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.keyWords.productCode,
					careReceiverName: queryString,
				};
			} else {
				params = {
					pageNum: 1,
					pageSize: 10,
					productCode: this.keyWords.productCode,
					careReceiverName: queryString,
				};
			}
			findCareReceiverForDevice(params)
				.then(response => {
					if (response.data.statusCode === "200") {
						this.careReceiverNameOptions = [];//新增护理人员
						var data = response.data.responseData;
						for (let i = 0; i < data.length; i++) {
							this.careReceiverNameOptions.push({
								value: data[i].careReceiverName,
								code: data[i].careReceiverCode,
								careReceiverTel: data[i].careReceiverTel,
								// orderCode: data[i].orderCode,
								// orgCode: data[i].orgCode,
								// orgName: data[i].orgName,
								// serviceDuration: data[i].serviceDuration
							});
						}
						var results = this.careReceiverNameOptions;
						if (results.length === 0) {
							results = [{ value: "无", code: "-1" }];
						}
						cb(results);
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrPositionList:" + error);
					return false;
				});
		},
		removeCareReceiverName () {
			this.keyWords.careReceiverCode = "";
			this.keyWords.careReceiverName = "";

		},
		addAlarm () {
			this.isShow = false;
			this.isAlarm = true
			this.codeArr = []
			this.nameArr = []
			this.alarmForm.handleNameList = []
			var obj = {}
			this.serviceOptions = [...this.serviceList]
			obj = this.serviceList.find((item) => {
				return item.value === this.$store.getters.userCode;
			});
			if (obj) {
				this.alarmForm.handleNameList.push(obj.value)
				this.codeArr.push(obj.value);
				this.nameArr.push(obj.label);


			}
			let codeStr = ''
			if (this.codeArr.length > 0) {
				for (let i = 0; i < this.codeArr.length; i++) {
					codeStr += this.codeArr[i] + ","
				}
				if (codeStr.length > 0) {
					this.alarmForm.handleCode = codeStr.substr(0, codeStr.length - 1);
				}
			}
			let nameStr = ''
			if (this.nameArr.length > 0) {
				for (let i = 0; i < this.nameArr.length; i++) {
					nameStr += this.nameArr[i] + ","
				}
				if (nameStr.length > 0) {
					this.alarmForm.handleName = nameStr.substr(0, nameStr.length - 1);
				}
			}
		},
		cancelBtn () {
			this.alarmForm.handleCode = ''
			this.alarmForm.handleName = ''
			this.isShow = true;
			this.isEdit = true
			this.isAlarm = false
			this.$refs.alarmForm.resetFields();

		},
		close () {
			this.dialogVisible = false;
			this.$refs.alarmForm.resetFields();
		},
		getCurrentNode (data) {
			this.keyWords.orgName = data.orgName;
			this.keyWords.orgCode = data.orgCode;
			this.close();
		},
		//清空组织过滤
		clearOrgCode () {
			this.keyWords.orgName = "";
			this.keyWords.orgCode = "";
		},
		resetForm () {
			this.$refs.keyWordsForm.resetFields();
			this.keyWords.warnDateB = '';
			this.keyWords.warnDateE = '';
			this.getList(1)
		},
		alarmProcessclose () {
			this.dialogAlarmProcess = false
			this.isShow = false
			this.isAlarm = false
			this.isEdit = false
			this.alarmForm.handleCode = ''
			this.alarmForm.handleName = ''
		},
		details (alarmCode, status) {
			if (status == '1') {
				this.titleName = '查看告警'
				this.isShow = false
				this.isEdit = false
			} else if (status == '2') {
				this.titleName = '编辑报警'
				this.isShow = true
				this.isEdit = true


			}
			this.alarmForm.alarmCode = alarmCode
			let params = {
				alarmCode: this.alarmForm.alarmCode
			}
			getDeviceOrderAlarm(params)
				.then(response => {
					if (
						response.data.statusCode == 200 ||
						response.data.statusCode == "200"
					) {
						if (response.data.responseData) {
							this.dialogAlarmProcess = true;
							this.queryCarePerson(response.data.responseData.careReceiverCode)
							this.detailObj = response.data.responseData
							this.timeFrist = this.detailObj.alarmDate
						} else {
							this.$message.error(response.data.statusMsg);
							return false;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("getDeviceOrderRound:" + error);
					return false;
				});

		},
		// 列表数据
		getList (page) {
			this.listLoading = true;
			this.searchLoading = true;
			this.keyWords.pageNum = page;
			if (this.$route.query.type == '1') {
				this.isSingle = true
				this.isOverall = false
				this.careReceiver = JSON.parse(this.$route.query.careReceiver);
				this.keyWords.careReceiverName = this.careReceiver.careReceiverName
				this.keyWords.careReceiverCode = this.careReceiver.careReceiverCode
				this.keyWords.orgName = this.careReceiver.orgName
				this.keyWords.orgCode = this.careReceiver.orgCode
			} else {
				this.isOverall = true
				this.isSingle = false
				// this.careReceiver =  {}
				this.keyWords.careReceiverName = ''
				this.keyWords.careReceiverCode = ''
				this.keyWords.alarmTime = ''
				this.keyWords.handleStatus = ''
				this.keyWords.alarmType = ''
				this.keyWords.orgName = this.careReceiver.orgName
				this.keyWords.orgCode = this.careReceiver.orgCode
			}
			var params = {
				pageNum: page,
				pageSize: this.keyWords.pageSize,
				handleStatus: this.keyWords.handleStatus,
				alarmType: this.keyWords.alarmType,
				orgName: this.keyWords.orgName,
				orgCode: this.keyWords.orgCode,
				careReceiverCode: this.keyWords.careReceiverCode ? this.keyWords.careReceiverCode : this.keyWords.typeCareReceiverCode,
				careReceiverName: this.keyWords.careReceiverName ? this.keyWords.careReceiverName : this.keyWords.typeCareReceiverName,
				alarmDateB:
					this.keyWords.alarmTime != null ? this.keyWords.alarmTime[0] : null,
				alarmDateE:
					this.keyWords.alarmTime != null ? this.keyWords.alarmTime[1] : null,
			}
			findDeviceOrderAlarmList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						this.tableData = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
						this.searchLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log(error);
					this.listLoading = false;
					this.searchLoading = false;
				});
		},
		//父组件触发事件
		pageChange (val) {
			this.keyWords.page = val.page;
			this.keyWords.pageSize = val.limit;
			this.getList(val.page);
		},
		editAlarms (formName) {
			this.$refs[formName].validate(valid => {
				if (valid) {
					this.cancleDisabled = true
					/* 编辑 */
					var params = {
						handleResult: this.alarmForm.handleResult,
						handleStatus: this.alarmForm.handleStatus,
						remark: this.alarmForm.remark,
						alarmCode: this.alarmForm.alarmCode,
						conditionDesc: this.alarmForm.conditionDesc,
						handleCode: this.alarmForm.handleCode,
						handleName: this.alarmForm.handleName,
						// alarmName: this.alarmForm.alarmName
					};
					insertDeviceOrderAlarmRecord(params)
						.then(response => {
							if (response.data.statusCode === "200") {
								this.cancleDisabled = false
								this.dialogAlarmProcess = false;
								this.$refs.alarmForm.resetFields();
								this.alarmForm.alarmCode = ''
								this.alarmForm.handleName = ''
								this.alarmForm.handleCode = ''
								this.nameArr = []
								this.codeArr = []
								this.isAlarm = false;
								this.isShow = true
								this.isEdit = false
								this.$message.success("添加成功");
								this.getList(1);
							} else {
								this.cancleDisabled = false
								this.$message.error(response.data.statusMsg);
								return false;
							}
						})
						.catch(error => {
							this.cancleDisabled = false
							console.log("insertDeviceOrderRound:" + error);
							return false;
						});

				} else {
					this.$message.error("请检查是否填写完整");
					return false;
				}
			})
		},

		detailClose () {
			this.dialogAlarmDetail = false;
		},
		initData () {			{
				let params = {
					// pageNum: 1,
					// pageSize: 10,
					isDataAuthority: 0
				};
				findStaffAll(params)
					.then(response => {
						if (response.data.statusCode === "200") {
							let list = response.data.responseData
							this.serviceList = list.map(item => { //组装，只需要code和name
								return {
									value: `${item.staffCode}`,
									label: `${item.staffFullName}`,
								};
							});
						} else {
							this.$message.error(response.data.statusMsg);
							return false;
						}
						this.serviceOptions = [];
					})
					.catch(error => {
						console.log("findEhrPositionList:" + error);
						return false;
					});
			}
		},
		selectName () {
			this.serviceOptions = this.serviceList
		},
		selectChange (val) {
			this.codeArr = []
			this.nameArr = []
			if (val) {
				let that = this;
				val.forEach(element => {
					let obj = that.serviceList.find((item) => {
						return item.value === element;
					});
					if (obj) {
						this.nameArr.push(obj.label);
						this.codeArr.push(obj.value);
					}
				});
				let codeStr = ''
				if (this.codeArr.length > 0) {
					for (let i = 0; i < this.codeArr.length; i++) {
						codeStr += this.codeArr[i] + ","
					}
					if (codeStr.length > 0) {
						this.alarmForm.handleCode = codeStr.substr(0, codeStr.length - 1);
					}
				}
				let nameStr = ''
				if (this.nameArr.length > 0) {
					for (let i = 0; i < this.nameArr.length; i++) {
						nameStr += this.nameArr[i] + ","
					}
					if (nameStr.length > 0) {
						this.alarmForm.handleName = nameStr.substr(0, nameStr.length - 1);
					}
				}
			}
		},
		remoteMethod (queryString) {
			if (queryString !== '') {
				this.loading = true;
				setTimeout(() => {
					this.loading = false;
					this.serviceOptions = this.serviceList.filter(item => {
						return item.label.toLowerCase()
							.indexOf(queryString.toLowerCase()) > -1;
					});
				}, 200);
			} else {
				this.serviceOptions = [];
			}
		},
		queryCarePerson (code) {
			var params = { careReceiverCode: code }
			getEtCareReceiver(params).then(response => {
				if (response.data.statusCode == "200") {
					if (response.data.responseData) {
						this.careReceiverDetail = response.data.responseData;
					}
				} else {
					this.$message.error(reponse.data.statusMsg);
				}
			}).catch(error => {
				console.log(error)
			})
		},
		/**
		 *
		 * 数据字典
		 *
		 */
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "HANDLE_STATUS" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.handlingStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
			findValueBySetCode({ valueSetCode: "ALARM_TYPE" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.alarmTypeOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}

	},
	created () {
		//初始化数据字典
		this.initDataDictionary();
		this.initData()

	},
	mounted () {
		this.getList(1)
	}
};
</script>
<style lang="scss" scoped>
#alarmList {
	width: 100%;
	min-width: 1600px;
	.el-form-item {
		margin-bottom: 10px;
	}
}
.alarmClass {
	margin-bottom: 25px !important;
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}

.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.search_btn {
	width: 30%;
	min-width: 295px;
	margin-left: 125px;
}
.tableTopBtn {
	background-color: white;
	text-align: right;
	padding: 10px 20px 10px 0px;
}
.timeLine {
	background: #fff;
	// margin: 20px 20px 20px 20px;
	border-radius: 10px;
}
.block {
	padding: 50px 15px;
}
.el-card {
	width: 350px;
	p {
		margin: 10px;
	}
}
.el-card__body {
	p {
		line-height: 22px;
	}
}
::v-deep .el-timeline-item__timestamp.is-top {
	position: absolute;
	left: -146px;
	top: -3px;
	color: #333333;
	font-size: 14px;
}
::v-deep .el-timeline {
	padding-left: 150px;
}
</style>