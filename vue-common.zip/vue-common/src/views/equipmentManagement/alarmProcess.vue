<template>
	<div id="alarmProcess">
		<headTag :tagName="tagName" />
		<div class="seettingTop">
			<div class="info-left">
				<div class="person-detail">
					<img
						style="width:60px;height:60px;"
						src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
					/>
				</div>
				<div class="person-info">
					<span>张三丰</span>
					<span class="person-color">独居</span>
				</div>
			</div>
			<div class="info-right" style="width:100%;padding:30px 0;">
				<div class="basic-info">
					<el-row>
						<el-col :span="22" style="font-size:16px;color:#333333;">基本信息</el-col>
						<el-col :span="2" style="font-size:16px;color:#333333;">
							<el-button type="primary" size="mini" @click="btnBack">返回</el-button>
						</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">年龄：86</el-col>
						<el-col class="info-text" :span="8">性别：男</el-col>
						<el-col class="info-text" :span="8">生日：1985-02-12</el-col>
					</el-row>
					<el-row>
						<el-col class="info-text" :span="8">地址：上海市虹口区车站北路1388号10楼</el-col>
					</el-row>
				</div>
			</div>
		</div>
		<div class="timeLine">
			<div class="block">
				<el-timeline>
					<el-timeline-item timestamp="2020-06-19 19:10:30" color="#F04B5F" placement="top">
						<p>离床告警：2020-06-19 19:10:30</p>
					</el-timeline-item>
					<el-timeline-item timestamp="2020-06-19 19:10:30" color="#398AF1" placement="top">
						<el-card>
							<p>情况描述：需要紧急协助</p>
							<p>处理方式：电话联系</p>
							<p>记录人：张三</p>
							<p>情况描述：需要紧急协助</p>
							<p>处理方式：电话联系</p>
							<p>记录人：张三</p>
						</el-card>
					</el-timeline-item>
					<el-timeline-item timestamp="2020-06-19 19:10:30" color="#398AF1" placement="top">
						<el-card>
							<el-button type="primary" size="mini" v-show="isShow" @click="addAlarm" round>添加</el-button>
							<el-form
								v-show="isAlarm"
								:inline="false"
								:model="alarmForm"
								:rules="alarmFormRules"
								label-width="100px"
								ref="alarmForm"
							>
								<el-form-item label="情况描述:">
									<el-input clearable placeholder="请输入员工编号" size="mini" v-model="alarmForm.userCode"></el-input>
								</el-form-item>
								<el-form-item label="处理方式:">
									<el-input clearable placeholder="请输入员工姓名" size="mini" v-model="alarmForm.userFullName"></el-input>
								</el-form-item>
								<el-form-item label="处理方式:">
									<el-input
										clearable
										placeholder="请输入联系电话"
										size="mini"
										v-model="alarmForm.userTel"
										maxlength="11"
									></el-input>
								</el-form-item>
								<el-form-item label="处理方式:">
									<el-col>张三</el-col>
								</el-form-item>
								<el-form-item label="备注:">
									<el-input
										clearable
										placeholder="请输入联系电话"
										size="mini"
										v-model="alarmForm.userTel"
										maxlength="11"
									></el-input>
								</el-form-item>
								<el-form-item>
									<el-button :disabled="cancleDisabled" @click="cancelBtn" size="mini">取消</el-button>
									<el-button style="margin-left:40px;" size="mini" type="primary">确 定</el-button>
								</el-form-item>
							</el-form>
						</el-card>
					</el-timeline-item>
				</el-timeline>
			</div>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";

export default {
	components: {
		HeadTag
	},
	props: {},
	data () {
		return {
			tagName: "处理告警详情",
			alarmFormRules: {

			},
			alarmForm: {

			},
			isShow: true,
			isAlarm: false,
		};
	},
	watch: {},
	computed: {},
	methods: {
		btnBack () {

		},
		addAlarm () {
			this.isShow = false;
			this.isAlarm = true
		},
		cancelBtn () {
			this.isShow = true;
			this.isAlarm = false
		}
	},
	created () { },
	mounted () { }
};
</script>
<style lang="scss" scoped>
#alarmProcess {
	width: 100%;
	min-width: 1200px;
	.seettingTop {
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
		border-radius: 6px;
		margin: 0px 20px 20px 20px;
		display: flex;
		.info-left {
			.person-detail {
				padding: 30px 75px 23px 55px;
			}
			.person-info {
				margin-left: 38px;
				margin-bottom: 45px;
				span {
					font-size: 16px;
					color: #333333;
				}
				.person-color {
					background: rgba(240, 75, 95, 1);
					border-radius: 10px;
					color: #ffffff;
					margin-left: 10px;
					padding: 4px;
					font-size: 14px;
				}
			}
		}
	}
}
.info-text {
	margin-top: 25px;
	font-size: 16px;
	color: #666666;
	font-family: Adobe Heiti Std;
}
.timeLine {
	background: #fff;
	margin: 20px 20px 20px 20px;
	border-radius: 10p;
}
.block {
	padding: 50px 45px;
}
.el-timeline-item__content {
	// width: 300px;
	p {
		margin: 6px 0;
	}
}
::v-deep .el-timeline-item__timestamp.is-top {
	position: absolute;
	left: -146px;
	top: -3px;
	color: #333333;
	font-size: 14px;
}
::v-deep .el-timeline {
	padding-left: 150px;
}
</style>