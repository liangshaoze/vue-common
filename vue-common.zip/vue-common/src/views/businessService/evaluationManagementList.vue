<template>
	<div id="evaluationManage">
		<headTag :tagName="tagName" />

		<!-- 搜索筛选 -->
		<div class="filter_wrap">
			<el-form ref="filterForm" :inline="true" :model="filters" label-width="110px">
				<el-row>
					<el-col class="form-item">
						<el-form-item label="客户姓名" prop="customerFullName">
							<el-input
								size="mini"
								v-model.trim="filters.customerFullName"
								clearable
								placeholder="请输入客户姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="客户联系方式" prop="customerTel">
							<el-input size="mini" v-model.trim="filters.customerTel" clearable placeholder="请输入客户联系方式"></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="是否追评" prop="appendStatus">
							<el-select size="mini" v-model.trim="filters.appendStatus" clearable placeholder="请选择">
								<el-option
									v-for="item in appendStatusOptions"
									:key="item.value"
									:label="item.name"
									:value="item.value"
								/>
							</el-select>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="被照护人地址" prop="liveDetailAddress">
							<el-input
								size="mini"
								v-model.trim="filters.liveDetailAddress"
								clearable
								placeholder="请输入被照护人地址"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="被照护人姓名" prop="careReceiverName">
							<el-input
								size="mini"
								v-model.trim="filters.careReceiverName"
								clearable
								placeholder="请输入被照护人姓名"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="服务人员" prop="careGiverName">
							<el-input size="mini" v-model.trim="filters.careGiverName" clearable placeholder="请输入服务人员姓名"></el-input>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col class="form-item">
						<el-form-item label="评价总分">
							<el-input
								size="mini"
								v-model.trim="filters.evaluationScoreStart"
								clearable
								style="width:120px;"
								placeholder="请输入分数"
							></el-input>-
							<el-input
								size="mini"
								style="width:120px;"
								v-model.trim="filters.evaluationScoreEnd"
								clearable
								placeholder="请输入分数"
							></el-input>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item label="评价时间" prop="evaluationTime">
							<el-date-picker
								v-model.trim="filters.evaluationTime"
								clearable
								size="mini"
								format="yyyy-MM-dd HH:mm"
								value-format="yyyy-MM-dd HH:mm"
								type="datetimerange"
								style="width: 290px;"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
							></el-date-picker>
						</el-form-item>
					</el-col>
					<el-col class="form-item">
						<el-form-item class="search_btn">
							<el-button
								size="mini"
								type="primary"
								icon="el-icon-search"
								:loading="searchLoading"
								@click="getEvaluationList(1)"
							>查询</el-button>
							<el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
		</div>

		<div class="tableToolbar">
			<div class="tablePanel">
				<!--列表-->
				<el-table
					:header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
					size="mini"
					stripe
					:data="EvaluationList"
					v-loading="listLoading"
					highlight-current-row
					element-loading-text="拼命加载中"
				>
					<el-table-column label="工单单号" min-width="120" prop="workorderCode"></el-table-column>
					<el-table-column label="客户姓名" min-width="120" prop="customerFullName"></el-table-column>
					<el-table-column label="客户联系方式" min-width="120" prop="customerTel"></el-table-column>
					<el-table-column label="被照护人"   min-width="120" prop="careReceiverName"></el-table-column>
					<el-table-column label="被照护人地址" min-width="150">
						<template slot-scope="scope">{{scope.row.liveProvinceName}}{{scope.row.liveCityName}}{{scope.row.liveDistrictName}}{{scope.row.liveSubdistrictName}}{{scope.row.liveDetailAddress}}</template>
					</el-table-column>
					<el-table-column label="服务人员" min-width="100" prop="careGiverName"></el-table-column>
					<el-table-column label="评价总分(分)" min-width="120" prop="evaluationScore">
					</el-table-column>
					<el-table-column label="是否追评" width="100" prop="appendStatusValue"></el-table-column>
					<el-table-column label="评价时间" min-width="120">
						<template slot-scope="scope">
							<span v-if="scope.row.firstDate">{{scope.row.firstDate}}</span>
						</template>
					</el-table-column>
					<el-table-column label="追评时间" min-width="120">
						<template slot-scope="scope">
							<span v-if="scope.row.appendDate">{{scope.row.appendDate}}</span>
						</template>
					</el-table-column>
					<el-table-column fixed="right" width="100" label="操作">
						<template slot-scope="scope">
							<el-button size="mini" type="text" @click="handleDetail(scope.row)">查看详情</el-button>
						</template>
					</el-table-column>
				</el-table>

				<!--工具条-->
				<el-row class="pageToolbar">
					<el-col>
						<pagination
							v-if="totalCount>0"
							:total="totalCount"
							:page.sync="filters.pageNum"
							:limit.sync="filters.pageSize"
							@pagination="pageChange"
						></pagination>
					</el-col>
				</el-row>
			</div>
		</div>
	</div>
</template>

<script>
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { selectWorkorderEvaluationList } from "api/workOrderManagement";
import { findValueBySetCode } from "api/common";
import { changeYMD } from "utils";
export default {
	data () {
		return {
			tagName: "客户评价",
			//控制弹窗
			dialogVisible: false,
			//条件查询
			filters: {
				customerFullName: "",
				customerTel: "",
				appendStatus: null,
				liveDetailAddress: "",
				careReceiverName: "",
				careGiverName: "",
				evaluationTime: '',
				evaluationScoreStart:'',
				evaluationScoreEnd:'',
				pageNum: 1,
				pageSize: 10
			},
			appendStatusOptions: [],
			EvaluationList: [],
			totalCount: 0,
			listLoading: false,
			searchLoading: false,

		};
	},
	components: {
		HeadTag,
		Pagination,
	},
	methods: {
		//父组件触发事件
		pageChange (val) {
			this.filters.pageNum = val.page;
			this.filters.pageSize = val.limit;
			this.getEvaluationList(val.page); //改变页码，重新渲染页面
		},
		//获取员工列表
		getEvaluationList (page) {
			this.filters.pageNum = page;
			var params = {
				pageNum: page,
				pageSize: this.filters.pageSize,
				customerFullName: this.filters.customerFullName,
				customerTel: this.filters.customerTel,
				appendStatus: this.filters.appendStatus,
				liveDetailAddress: this.filters.liveDetailAddress,
				evaluationDateStart:
					this.filters.evaluationTime != null ? this.filters.evaluationTime[0] : null,
				evaluationDateEnd:
					this.filters.evaluationTime != null ? this.filters.evaluationTime[1] : null,
				careReceiverName: this.filters.careReceiverName,
				careGiverName: this.filters.careGiverName,
				evaluationScoreStart: this.filters.evaluationScoreStart,
				evaluationScoreEnd: this.filters.evaluationScoreEnd,

			};
			this.listLoading = true;
			this.searchLoading = true;
			selectWorkorderEvaluationList(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.EvaluationList = response.data.responseData;
						this.totalCount = response.data.totalCount;
						this.listLoading = false;
						this.searchLoading = false;
					} else {
						this.$message.error(response.data.statusMsg);
						this.listLoading = false;
						this.searchLoading = false;
						return false;
					}
				})
				.catch(error => {
					console.log("findStaffList:" + error);
					this.listLoading = false;
					this.searchLoading = false;
					return false;
				});
		},
		//查看详情
		handleDetail (row) {
			this.$router.push({
				path: "/businessServiceManagement/evaluationInfo",
				query: {
					workorderCode: row.workorderCode,
					evaluationId: row.id
				}
			});
		},
		resetForm () {
			this.$refs.filterForm.resetFields();
			this.filters.evaluationScoreStart = '';
			this.filters.evaluationScoreEnd = '';
			this.getEvaluationList(1);
		},
		/**
		 *
		 * 数据字典
		 *
		 */
		initDataDictionary () {
			findValueBySetCode({ valueSetCode: "YES_OR_NO" })
				.then(response => {
					if (response.data.statusCode == 200) {
						this.appendStatusOptions = response.data.responseData;
					}
				})
				.catch(error => {
					console.log("findValueBySetCode:" + error);
					return false;
				});
		}
	},
	created () {
		//初始化数据字典
		this.initDataDictionary();
	},
	activated () {
		//初始化查询列表
		this.getEvaluationList(1);

	}
};
</script>

<style lang="scss" scoped>
#evaluationManage {
	width: 100%;
	min-width: 1550px;
	.el-form-item {
		margin-bottom: 0px;
	}
}
.search_btn {
	min-width: 250px;
	margin-left: 110px;
}
.form-item {
	width: 30%;
	min-width: 295px;
}
.form-items {
	width: 35%;
	min-width: 350px;
}
.tablePanel {
	padding: 20px 0px;
}
.formItem {
	width: 500px;
}
.pic_icon {
	width: 20px;
	height: 20px;
}
</style>