<template>
  <div id="orderManage">
    <headTag :tagName="tagName" />

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="125px">
        <CommonPropertyWidget
                @queryMethod ="queryMethod"
                :propertyList="queryPropertyList"
                :resultItem ="filters"
              >
              <el-col class="form-item" slot="newLine">
                <el-form-item>
                  <el-button  size="mini" type="primary" icon="el-icon-search" :loading="searchLoading" @click="queryGetList()">查询</el-button>
                </el-form-item>
              </el-col>
              </CommonPropertyWidget>
        <el-row>
          <el-col class="form-item">
            <el-form-item>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item >
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item class="search_btn">
              <el-button size="mini" type="primary" icon="el-icon-search" :loading="searchLoading" @click="queryGetList()">查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

		<div class="tableToolbar">
			<el-row class="tableTopBtn">
				<el-col :span="24">
					<el-button size="mini" type="primary" icon="el-icon-plus" @click="insertOrders(1)">新增</el-button>
					<el-button size="mini" type="primary" icon="el-icon-upload" @click="exportOrders()">导出</el-button>
					<el-button size="mini" type="primary" icon="el-icon-upload2" @click="importOrders()">批量导入</el-button>
          <el-button size="mini" type="primary" icon="el-icon-edit-outline" @click="editOrgSelect()">修改组织</el-button>
          <el-button size="mini" type="primary" icon="el-icon-rank" @click="effectSelect()">批量生效</el-button>
				</el-col>
			</el-row>
			<!--列表-->
			<el-table :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" stripe size="mini" :data="orderList"
				v-loading="listLoading" highlight-current-row element-loading-text="拼命加载中" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="订单号" width="120" prop="orderCode"></el-table-column>
				<el-table-column label="订单状态" min-width="80" prop="orderStatusValue"></el-table-column>
				<el-table-column label="付款状态" min-width="80" prop="payStatusValue"></el-table-column>
				<el-table-column label="服务状态" min-width="80" prop="serviceStatusValue"></el-table-column>
				<el-table-column label="客户联系方式" width="110" prop="customerTel"></el-table-column>
				<el-table-column label="被照护人姓名" min-width="100" prop="careReceiverName"></el-table-column>
        <el-table-column label="被照护人联系方式" width="120" prop="careReceiverTel"></el-table-column>
        <el-table-column label="现居住详细地址" min-width="200" prop="liveDetailAddress"></el-table-column>
				<el-table-column label="被照护人身份证号" width="145" prop="careReceiverIdCard"></el-table-column>
				<el-table-column label="医保类型" min-width="80" prop="medicalTypeValue"></el-table-column>
				<el-table-column label="产品名称" min-width="100" prop="productName"></el-table-column>
				<el-table-column label="服务起止日期" width="185" prop="serviceDate">
					<template slot-scope="scope">
						<span v-if="scope.row.serviceStartDate">{{scope.row.serviceStartDate}}---{{scope.row.serviceEndDate}}</span>
					</template>
				</el-table-column>
				<el-table-column label="销售价（元）" min-width="100" prop="sellPrice"></el-table-column>
				<el-table-column label="订单来源" min-width="70" prop="orderSourceValue"></el-table-column>
				<el-table-column label="组织" min-width="100" prop="orgName"></el-table-column>
				<el-table-column label="支付方式" min-width="70" prop="payTypeValue"></el-table-column>
				<el-table-column label="关联订单号" min-width="120" prop="relationOrderCode"></el-table-column>
				<el-table-column label="是否被关联" min-width="100" prop="isRelatedValue"></el-table-column>
				<el-table-column label="备注" min-width="100" prop="remark" :show-overflow-tooltip="true"></el-table-column>
				<el-table-column label="创建时间" width="135" prop="createDate"></el-table-column>
				<el-table-column label="付款时间" width="135" prop="payDate"></el-table-column>
				<el-table-column fixed="right" min-width="150" label="操作">
					<template slot-scope="scope">
						<span v-if="scope.row.SchedulingBtn==true">
							<el-button size="mini" type="text" @click="handleScheduling(scope.row)">排程</el-button>
						</span>
						<span>
							<el-button size="mini" type="text" @click="handleOrder(scope.row)">查看</el-button>
						</span>
						<span v-if="scope.row.orderSourceStatus==true">
							<el-button size="mini" type="text" @click="copyOrder(scope.row)">复制</el-button>
						</span>
						<span v-if="scope.row.cancelStatus">
							<el-button size="mini" type="text" @click="cancelOrder(scope.row.orderCode,scope.row.orderSource)">取消订单</el-button>
						</span>
						<span v-if="scope.row.serviceValidationStatus==true">
							<el-button size="mini" type="text" @click="serviceValidation(scope.row.orderCode)">服务确认</el-button>
						</span>
						<span v-if="scope.row.transStatus==true">
							<el-button size="mini" type="text" @click="refundSlip(scope.row.orderCode)">交易流水</el-button>
						</span>
						<span v-if="scope.row.btnStatus==true">
							<el-button size="mini" type="text" @click="refundOrder(scope.row.orderCode,scope.row.orderSource,'20')">退款</el-button>
						</span>
						<span v-if="scope.row.btnStatus==true">
							<el-button size="mini" type="text" @click="refundOrder(scope.row.orderCode,scope.row.orderSource,'30')">补差价</el-button>
						</span>
						<span v-if="scope.row.btnStatus==true">
							<el-button size="mini" type="text" @click="serviceCompletion(scope.row.orderCode)">服务完成</el-button>
						</span>
						<span v-if="scope.row.serviceStopBtn==true">
							<el-button size="mini" type="text" @click="serviceStop(scope.row.orderCode)">服务暂停</el-button>
						</span>
						<span v-if="scope.row.serviceStartBtn==true">
							<el-button size="mini" type="text" @click="serviceStart(scope.row.orderCode)">服务开启</el-button>
						</span>
						<span v-if="scope.row.serviceCompleteBtn==true">
							<el-button size="mini" type="text" @click="serviceCWXComplete(scope.row.orderCode)">服务完成</el-button>
						</span>
						<span v-if="scope.row.orderEffectBtn==true">
							<el-button size="mini" type="text" @click="orderEffect(scope.row.orderCode)">订单生效</el-button>
						</span>
              <!-- <span v-if="scope.row.btnDditOrg==true">
							<el-button size="mini" type="text" @click="editLevel(scope.row.orderCode)">修改评估等级</el-button>
						</span> -->
					</template>
				</el-table-column>
			</el-table>
			<!--工具条-->
			<el-row class="pageToolbar">
				<pagination v-if="totalCount>0" :total="totalCount" :page.sync="filters.page" :limit.sync="filters.pageSize" @pagination="pageChange">
				</pagination>
			</el-row>
			<!-- 批量导入菜单 -->
			<el-dialog title="上传文件" :visible.sync="dialogImport" width="500px" center :before-close="handleImportClose">
				<el-row type="flex" justify="center" style="margin:10px">
					<el-upload ref="upload" :limit="1" :before-upload="beforeAvatarUpload" :on-change="handleChangeImportant"
						:file-list="fileImportList" :on-exceed="handleImportExceed" :on-remove="handleRemoveImport" :auto-upload="false" drag
						:http-request="uploadFile" accept='.xls,.xlsx' action="customize">
						<i class="el-icon-upload" style="color:#1890ff"></i>
						<div class="el-upload__text" style="font-size:16px;">将文件拖到此处，或
							<em style="font-size:16px;">点击上传</em>
						</div>
						<div class="el-upload__tip" style="font-size:16px;margin-top:10px;" slot="tip">请按照表格模板上传正确文件(*.xls,.xlsx)，限制2M</div>
					</el-upload>
				</el-row>
				<el-row type="flex" justify="center">
          <el-link :href="downLoadTempleFileUrl" icon="el-icon-download"  type="primary">下载表格模板</el-link>
				</el-row>
				<span slot="footer" class="dialog-footer">
					<el-button size="mini" @click="cancelImport()">取 消</el-button>
					<el-button size="mini" type="primary" style="margin-left:40px;" :disabled="importDisabled" v-loading="listLoading" @click="submitImport()">确 定</el-button>
				</span>
			</el-dialog>
			<!-- 订单生效弹窗 -->
			<el-dialog title="是否确认该长护险订单生效？" :visible.sync="dialogServerEffect" width="500px" :before-close="handleClose" center>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red;margin:10px 0;">注：订单生效后，服务状态变为“在服务”，订单状态变为“服务中”。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="dialogServerEffect = false">取 消</el-button>
					<el-button  size="mini" style="margin-left:40px;" type="primary" @click="ServerOrderEffect()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
      
			<!-- 服务确认弹窗 -->
			<el-dialog title="是否确认该订单服务？" :visible.sync="dialogServerOrder" width="500px" :before-close="handleClose" center>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red">注：服务确认后，付款状态变为“待付款”。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="dialogServerOrder = false">取 消</el-button>
					<el-button style="margin-left:40px;"  size="mini" type="primary" @click="ServiceOrder()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 服务开启弹窗 -->
			<el-dialog title="是否开启该长护险订单服务？" :visible.sync="dialogServerStart" width="500px" :before-close="handleClose" center>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red;margin-top:10px">注：服务开启后，服务状态变为“在服务”。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="dialogServerStart = false">取 消</el-button>
					<el-button style="margin-left:40px;"  size="mini" type="primary" @click="ServerOrderStart()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 服务暂停弹窗 -->
			<el-dialog title="是否暂停该长护险订单服务？" :visible.sync="dialogServerStop" width="500px" :before-close="handleClose" center>
				<el-col class="order_title">
					<span>服务暂停说明:&nbsp;</span>
					<el-select size="mini" v-model="servicePauseReason" clearable placeholder="请选择">
						<el-option v-for="item in servicePauseReasonOptions" :key="item.value" :label="item.name" :value="item.value" />
					</el-select>
				</el-col>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red">注：服务暂停后，服务状态变为“暂停服务”，订单状态不变。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="stopCancel">取 消</el-button>
					<el-button style="margin-left:40px;"   size="mini" type="primary" @click="ServerOrderStop()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 长务险服务完成弹窗 -->
			<el-dialog title="是否完成该长护险订单服务？" :visible.sync="dialogCHXServerComplete" width="500px" :before-close="handleClose" center>
				<el-col class="order_title">
					<span>服务完成说明:&nbsp;</span>
					<el-select size="mini" v-model="serviceCompletionReason" clearable placeholder="请选择">
						<el-option v-for="item in serviceCompletionReasonOptions" :key="item.value" :label="item.name" :value="item.value" />
					</el-select>
				</el-col>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red">注：服务完成后，服务状态变为“服务到期”，订单状态变为“服务完成”。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="dialogCHXServerComplete = false">取 消</el-button>
					<el-button  size="mini" style="margin-left:40px;" type="primary" @click="ServerCHXOrderComplete()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 订单服务完成确认弹窗 -->
			<el-dialog title="是否确定完成该订单服务？" :visible.sync="dialogServerComplentOrder" width="500px" :before-close="handleClose" center>
				<h3 style="text-align:center">如果是请点击确定，否则点击取消。</h3>
				<p style="text-align:center;color:red">注：服务完成后，订单状态变为“服务完成”。</p>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="dialogServerComplentOrder = false">取 消</el-button>
					<el-button style="margin-left:40px;"  size="mini" type="primary" @click="ServiceComplentOrder()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 取消订单弹窗 -->
			<el-dialog title="是否确定取消该订单？" :visible.sync="dialogCancelOrder"  width="500px" :before-close="handleClose" center>
				<h3 style="text-align:center">如果是请点击“确定”，不取消则点击“取消”</h3>
				<el-input type="textarea" class="remark-style" v-model="cancelDescription" placeholder="请输入订单取消的原因，谢谢~" resize="none" show-word-limit
					rows="4" clearable maxlength="100"></el-input>
				<div slot="footer" class="dialog-footer">
          <el-button  size="mini" @click="noOrder()">取 消</el-button>
					<el-button style="margin-left:40px;"  size="mini" type="primary" @click="okOrder()" :disabled="isDisabled">确 定</el-button>
				</div>
			</el-dialog>
			<!-- 退款弹窗 -->
			<el-dialog :title="title" :visible.sync="dialogreFundOrder" width="30%" :before-close="handleClose" center>
				<el-form :rules="formFundRules" ref="formFundOrder" :model="formFundOrder" label-width="100px">
					<el-col :span="24">
						<el-form-item class="fund-order" label="订单号:">
							<span class="orderNumber">{{fundCode}}</span>
						</el-form-item>
						<el-form-item class="fund-order" label="订单金额:" prop="fee">
							<el-input v-model="formFundOrder.fee" :placeholder="formFundOrder.title"></el-input>
						</el-form-item>
						<el-form-item class="fund-order" label="备注:">
							<el-input type="textarea" class="remark-style" v-model="formFundOrder.remark" :placeholder="formFundOrder.titles"
								resize="none" show-word-limit rows="4" clearable maxlength="100">
							</el-input>
						</el-form-item>
					</el-col>
				</el-form>
				<span slot="footer" class="dialog-footer">
					<el-button  size="mini" style="margin-top:20px;" type="primary" @click="okFundOrder('formFundOrder')" :disabled="isDisabled">确 定</el-button>
					<el-button style="margin-left:40px;"  size="mini" @click="cancelFundOrder('formFundOrder')">取 消</el-button>
				</span>
			</el-dialog>
			<!-- 交易流水弹窗 -->
			<el-dialog title="交易流水" :visible.sync="dialogPriceSlip" :before-close="handleClose" center width="70%">
				<el-col class="orderNumber">订单号:{{slipCode}}</el-col>
				<el-table :data="slipData" :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}" element-loading-text="拼命加载中"
					highlight-current-row stripe size="mini" align="center" v-loading="listLoading">
					<el-table-column type="index" width="50"></el-table-column>
					<el-table-column property="payNo" label="交易号"></el-table-column>
					<el-table-column property="fee" label="金额(元)"></el-table-column>
					<el-table-column property="feeTypeValue" label="费用类型"></el-table-column>
					<el-table-column property="remark" label="备注"></el-table-column>
					<el-table-column property="payDate" label="支付时间">
						<template slot-scope="scope">
							<span v-if="scope.row.payDate">{{scope.row.payDate}}</span>
						</template>
					</el-table-column>
				</el-table>
			</el-dialog>
			<el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleCloseOrg">
				<org-select v-on:listenTochildEvent="getCurrentNode" />
			</el-dialog>
      <el-dialog title="修改组织" :visible.sync="dialogEditVisible" width="500px" :before-close="handleEditCloseOrg" center>
        <div>
          <div id="orgSelect">
            <el-input
              style="width:100%;"
              class="filter-input"
              suffix-icon="el-icon-search"
              placeholder="请输入想查找的部门"
              v-model="editOrgName"
              clearable
            ></el-input>
            <el-tree
              class="filter-tree"
              :data="treeData"
              node-key="orgCode"
              :filter-node-method="filterEditNode"
              :render-content="renderEditContent"
              :highlight-current="true"
              :expand-on-click-node="false"
              :props="defaultEditProps"
              :default-expanded-keys="['1']"
              @node-click="editNodeClick"
              ref="tree"
            ></el-tree>
          </div>
          <el-row type="flex" justify="center">
            <el-button  size="mini"  @click="editOrgCancel()">取 消</el-button>
            <el-button style="margin-left:40px;"  size="mini" type="primary" @click="editOrderOrgByOrderCode()" :disabled="isDisabled">确 定</el-button>
          </el-row>
        </div>
			</el-dialog>
       <el-dialog title="批量生效订单" :visible.sync="dialogEffectVisible" width="400px" :before-close="handleCloseEffect" center>
          <el-row type="flex" justify="center">
            <div style="font-size:16px;color: #303133;">是否确定批量生效选中的订单?</div>
          </el-row>
          <span slot="footer" class="dialog-footer">
            <el-button  size="mini"  @click="effectCancel()">取 消</el-button>
            <el-button  style="margin-left:40px;" size="mini" type="primary" @click="effectSubmit()" :disabled="isDisabled">确 定</el-button>
            </span>
       </el-dialog>
		</div>
	</div>
</template>

<script>
import { findEhrOrgList } from "api/orgStructure";
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode } from "api/common";
import {
  findProductOrderList,
  updateProductOrderForCancel,
  findFeeListByOrderCode,
  insertOrderFee,
  updateProductOrderForOverord,
  updateProductOrderForPay,
  updateServiceOn,
  updateServiceSuspension,
  updateServiceComplete,
  updateServiceStatusEffective,
  importWorkOrder,
  editOrderOrgByOrderCode,
  findEtProductByDataAuthority
} from "api/businessService/orderPaymentReview";
import { findEtProductListForWebQuickSearch } from "api/workOrderManagement";
import { changeYMD } from "utils";
import { isMoney } from "utils/validate.js";
import { export_json_to_excel } from "@/utils/Export2Excel.js";
import OrgSelect from "components/OrgSelect";
import { hasPermission } from "@/utils/button";
import axios from 'axios'
import CommonPropertyWidget from "components/CustomerSelect/CommonPropertyWidget"
export default {
  data() {
    return {
      tagName: "订单管理",
      dialogEditVisible:false,
      editOrgName: "",
      editOrgCode:'',
      editOrgUnitCode:'',
      dialogEffectVisible:false,
      selectOrder:'',
      isProduct:false,
      isProducts:true,
      treeData: [],
      defaultEditProps: {
        children: "childrenOrgList",
        label: "orgName",
        id: "orgCode"
      },
      //按钮权限
      //  showList: {
      //  edit_organization_onClick: true
      // },
      //取消订单弹窗
      dialogCancelOrder: false,
      //服务确认
      dialogServerOrder: false,
      dialogServerComplentOrder: false,
      //服务开启
      dialogServerStart: false,
      //服务暂停
      dialogServerStop: false,
      orderStop: "",
      dialogVisible: false,
      //长护险服务完成
      dialogCHXServerComplete: false,
      orderComplete: "",
      //订单生效
      dialogServerEffect: false,
      //控制查询按钮加载
      searchLoading: false,
      isDisabled: false,
      title: null,
      //退款弹窗
      dialogreFundOrder: false,
      //导入弹窗
      dialogImport: false,
      isRelationOptions: [],
      tableData: [
        
      ],
      formFundRules: {
        fee: [
          { required: true, message: "请输入金额", trigger: "blur" },
          { validator: isMoney }
        ]
      },
      formFundOrder: {
        fee: "",
        remark: "",
        feeType: "",
        title: "",
        titles: ""
      },
      productTypeOptions: [],
      fundSourceOrder: "",
      serviceCompletionCode: "",
      serviceCWXCompletionCode: "",
      fundCode: "",
      remark: "",
      listLoading: false,
      //交易流水弹窗
      dialogPriceSlip: false,
      slipData: [],
      //条件查询
      filters: {
        orderCode: "",
        orderStatus: "",
        serviceStatus: "",
        payStatus: "",
        customerTel: "",
        careReceiverName: "",
        careReceiverTel: "",
        careReceiverGender: "",
        productCode: "",
        productName: "",
        careReceiverIdCard: "",
        orgCode: this.$store.getters.userOrgCode,
        orgName: this.$store.getters.userOrgName,
        isRelated: "",
        sellPrice: "",
        orderSource: "",
        payType: "",
        relationOrderCode: "",
        remark: "",
        createDate: "",
        payDate: "",
        medicalType: "",
        distinguishStatus:"10",
        page: 1,
        pageSize: 10
      },
      refundCode: "",
      slipCode: "",
      serviceStartCode: "",
      serviceStopCode: "",
      serviceStatusOptions: [],
      medicalTypeOptions: [],
      //取消订单描述
      cancelDescription: "",
      //订单号
      orderCode: "",
      //服务确认
      serviceCode: "",
      //订单来源
      orderSource: "",
      orderList: [],
      totalCount: 0,
      listLoading: false,
      importDisabled:false,
      //订单状态
      orderOptions: [],
      multipleSelection: [],
      //付款状态
      payOptions: [],
      //支付方式
      payTypeOptions: [],
      //订单来源
      orderSourceOptions: [],
      //服务暂停
      servicePauseReason: "",
      servicePauseReasonOptions: [],
      servicePauseCode: "",
      //长护险服务完成
      serviceCompletionReason: "",
      serviceCompletionReasonOptions: [],
      //订单生效
      orderEffectCode: "",
      orderEffectCodeList:[],
      orderEffectSeverCodeList:[],
      fileImportList: [],
      orderCodeList:[],
      fileTemp: null,
      downLoadTempleFileUrl:process.env.NODE_ENV=== 'development'?'/static/订单导入模板.xlsx':'/fsk/static/订单导入模板.xlsx',
      queryPropertyList:[
        {
          propertyName: "signvalue",propertyFieldName: "signName",
          propertyType:"60",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "产品名称",propertyFieldName: "productName",
          propertyType:"50",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
          queryMethod:"queryPropertyType"
        },
        {
          propertyName: "订单状态",propertyFieldName: "orderStatus",optionKeyFieldName:"value",optionValueFieldName:"name",//可选项值对应的value的字段名
          valueSetCode:"ORDER_STATUS",propertyType:"20",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
        {
          propertyName: "服务状态",propertyFieldName: "serviceStatus",optionKeyFieldName:"value",optionValueFieldName:"name",//可选项值对应的value的字段名
          propertyType:"20",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
          options:[],
          queryMethod:function(){
             //服务状态
            findValueBySetCode({ valueSetCode: "SERVICE_STATUS" })
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.options = response.data.responseData;
                }
              })
              .catch(error => {
                console.log("findValueBySetCode:" + error);
                return false;
              });
          }
        },
        {
          propertyName: "被照护人姓名",propertyFieldName: "careReceiverName",propertyType:"10"
        },
        {
          propertyName: "创建日期",propertyFieldName: "createDate",propertyType:"70"
        },
        {
          propertyName: "工单状态",propertyFieldName: "distinguishStatus",optionKeyFieldName:"value",optionValueFieldName:"name",//可选项值对应的value的字段名
          valueSetCode:"WORKORDER_DISTINGUISH_STATUS",propertyType:"40",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框，60组织选择
        },
      ]
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect,
    CommonPropertyWidget
  },

  watch: {
     //监听搜索框
    editOrgName(val) {
      this.loadListTree();
    }
  },
  methods: {
    queryPropertyType(queryString,cb){
                  let params = {
                    pageNum: 1,
                    pageSize: 10,
                    productName: queryString
                  };
                findEtProductByDataAuthority(params)
                  .then(response => {
                    if (response.data.statusCode === "200") {
                      this.options = [];
                      var data = response.data.responseData;
                      for (let i = 0; i < data.length; i++) {
                          this.options.push({
                            value: data[i].productName,
                            code: data[i].productCode,
                          });   
                      }
                      var results = this.options;
                      if (results.length === 0) {
                        results = [{ value: "无", code: "-1" }];
                      }
                      cb(results);
                    } else {
                      this.$message.error(response.data.statusMsg);
                      return false;
                    }
                  })
                  .catch(error => {
                    console.log("findEtProductByDataAuthority:" + error);
                    return false;
                  });
           },
    queryMethod(obj,query,cb){
      if(typeof(obj.queryMethod) =="function"){
        obj.queryMethod(query,cb);
      }else{
        this[obj.queryMethod](query,cb);
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    queryGetList(){
      this.filters.page=1
      this.getList();
    },
    editOrgSelect(){
      let list = this.multipleSelection;
      if (list.length == 0) {
        this.$message.error("请选择操作项");
        return false;
      } else {
        this.dialogEditVisible = true;
        // debugger;
        for (let i = 0; i < list.length; i++) {
          if (
            list[i].orderStatus == "20" || list[i].orderStatus == "10" 
          ) {
            this.orderCodeList[i] = list[i].orderCode;
          } else {
            this.dialogEditVisible = false;
            this.$message.error("只有待确认,服务中订单才能修改组织");
            this.orderCodeList=[]
            return false;
          }
        }
        console.log(this.orderCodeList)
      }
    },
    //加载树结构数据
    loadListTree() {
      var params = {
        orgName: this.editOrgName
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.treeData = response.data.responseData;
            // this.treeData.map((v)=>{
            //   console.log(v)
            //   if(v.childrenOrgList){
            //     this.filters.orgName = '';
            //     this.filters.orgCode ='';
            //   }else{
            //     this.filters.orgName=v.orgName
            //     this.filters.orgCode=v.orgCode
            //   }
            // })  
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrOrgList:" + error);
          return false;
        });
    },
    //触发搜索框
    filterEditNode(value, data) {
      this.loadListTree();
      return true;
    },
    //当前选择节点
    editNodeClick(data, node, self) {
      this.editOrgName=data.orgName
      this.editOrgCode=data.orgCode
      this.editOrgUnitCode=data.orgUnitCode
    },
    //渲染样式
    renderEditContent(h, { node, data, store }) {
      return (
        <span>
          <i></i>
          <span>{node.label}</span>
        </span>
      );
    },
    editOrderOrgByOrderCode(){
      this.isDisabled=true;
       var params = {
        orgName: this.editOrgName,
        orgCode:this.editOrgCode,
        orgUnitCode:this.editOrgUnitCode,
        orderCodeList:this.orderCodeList,
      };
      editOrderOrgByOrderCode(params)
        .then(response => {
          if (response.data.statusCode == 200) {
             this.dialogEditVisible=false;
              this.isDisabled=false;
              this.editOrgName='';
              this.editOrgCode='';
              this.editOrgUnitCode='';
              this.orderCodeList=[]
              this.$message.success("操作成功");
              this.getList()
          } else {
            this.editOrgName='';
            this.editOrgCode='';
            this.editOrgUnitCode='';
            this.orderCodeList=[]
            this.isDisabled=false;
            this.dialogEditVisible=false;
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
        this.orderCodeList=[]
          console.log("editOrderOrgByOrderCode:" + error);
          return false;
        });
    },
    editOrgCancel(){
       this.editOrgName='';
       this.editOrgCode='';
       this.editOrgUnitCode='';
       this.orderCodeList=[]
       this.dialogEditVisible=false;       
    },

    //产品名称模糊查询
    selectProductTypeName(item) {
      if (item.value !== "无") {
        this.filters.productCode = item.code;
        this.filters.productName = item.value;
      } else {
        this.filters.productName = "";
      }
    },
    removeProductTypeName() {
      this.filters.productCode = "";
    },
    queryProductTypeName(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          productName: queryString
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          productName: queryString
        };
      }
      findEtProductByDataAuthority(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.productTypeOptions = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
                this.productTypeOptions.push({
                  value: data[i].productName,
                  code: data[i].productCode,
                });   
            }
            var results = this.productTypeOptions;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEtProductByDataAuthority:" + error);
          return false;
        });
    },
    //单个组织，单个产品默认显示
    getOneproduct(){
      var params = {
         pageNum: 1,
        pageSize: 10,
      }
     findEtProductByDataAuthority(params)
        .then(response => {
          if (response.data.statusCode == 200) {
             var data = response.data.responseData;
             for (let i = 0; i < data.length; i++) {
              if(data.length==1){
                 this.filters.productName=data[i].productName
                 this.filters.productCode=data[i].productCode
                 this.isProduct=true
                 this.isProducts=false
                 this.getList()
              }else{
                this.isProduct=false
                this.isProducts=true
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          return false;
        });
    },
    //父组件触发事件
    pageChange(val) {
      console.log(val)
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page); //改变页码，重新渲染页面
    },
    getList() {
      // this.filters.page = page;
      var params = {
        pageNum: this.filters.page,
        pageSize: this.filters.pageSize,
        orderCode: this.filters.orderCode,
        careReceiverName: this.filters.careReceiverName,
        careReceiverTel: this.filters.careReceiverTel,
        createDateB:
          this.filters.createDate != null ? this.filters.createDate[0] : null,
        createDateE:
          this.filters.createDate != null ? this.filters.createDate[1] : null,
        customerTel: this.filters.customerTel,
        orderSource: this.filters.orderSource,
        productName: this.filters.productName,
        productCode: this.filters.productCode,
        payStatus: this.filters.payStatus,
        orderStatus: this.filters.orderStatus,
        serviceStatus: this.filters.serviceStatus,
        isRelated: this.filters.isRelated,
        careReceiverIdCard: this.filters.careReceiverIdCard,
        medicalType: this.filters.medicalType,
        payType: this.filters.payType,
        orgCode: this.filters.orgCode,
        distinguishStatus:this.filters.distinguishStatus
      };
      this.listLoading = true;
      this.searchLoading = true;
      findProductOrderList(params)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode == 200 ||
              response.data.statusCode == "200"
            ) {
              this.orderList = response.data.responseData;
              for (let i = 0; i < this.orderList.length; i++) {
                this.orderList[i].serviceStartDate = changeYMD(
                  this.orderList[i].serviceStartDate
                );
                this.orderList[i].serviceEndDate = changeYMD(
                  this.orderList[i].serviceEndDate
                );
                /* scope.row.orderStatus== 20 && scope.row.payStatus==20 退款 补差价 订单服务完成 */
                if (
                  this.orderList[i].orderStatus == 20 &&
                  this.orderList[i].payStatus == 20&&this.orderList[i].productType == 20
                ) {
                  this.orderList[i].btnStatus = true;
                  if (this.orderList[i].isRelation == 1) {
                    this.orderList[i].btnStatus = false;
                  }
                }
                //  * 线下订单存在 复制 *
                if (this.orderList[i].orderSource == 20) {
                  this.orderList[i].orderSourceStatus = true;
                } else {
                  this.orderList[i].orderSourceStatus = false;
                }
                /* 取消订单 */
                if (
                  this.orderList[i].orderStatus == 10 && (this.orderList[i].productType == 20||this.orderList[i].productType == 10) &&
                  (this.orderList[i].payStatus == 10 ||
                    this.orderList[i].payStatus == undefined ||
                    this.orderList[i].serviceStatus == 10)
                ) {
                  this.orderList[i].cancelStatus = true;
                  if (this.orderList[i].isRelation == 1) {
                    this.orderList[i].cancelStatus = false;
                  }
                }
                // 交易流水
                if (
                  (this.orderList[i].orderStatus == 20 &&
                    this.orderList[i].payStatus == 20&&this.orderList[i].productType == 20) ||
                  (this.orderList[i].orderStatus == 20 &&
                    this.orderList[i].payStatus == 30&&this.orderList[i].productType == 20) ||
                  (this.orderList[i].orderStatus == 30 &&
                    this.orderList[i].payStatus == 20&&this.orderList[i].productType == 20) ||
                  (this.orderList[i].orderStatus == 20 &&
                    this.orderList[i].payStatus == 40&&this.orderList[i].productType == 20) ||
                  (this.orderList[i].orderStatus == 30 &&
                    this.orderList[i].payStatus == 50&&this.orderList[i].productType == 20)
                ) {
                  this.orderList[i].transStatus = true;
                  if (this.orderList[i].isRelation == 1) {
                    this.orderList[i].transStatus = false;
                  }
                }
                //订单状态待确认 服务确认
                if (
                  this.orderList[i].orderStatus == 10 &&
                  this.orderList[i].payStatus == undefined  && this.orderList[i].productType == 20
                ) {
                  this.orderList[i].serviceValidationStatus = true;
                } else {
                  this.orderList[i].serviceValidationStatus = false;
                }
                //订单生效
                if (
                  this.orderList[i].serviceStatus == 10 &&
                  this.orderList[i].orderStatus == 10 &&this.orderList[i].productType == 10
                ) {
                  this.orderList[i].orderEffectBtn = true;
                } else {
                  this.orderList[i].orderEffectBtn = false;
                }
                //服务暂停
                if (
                  this.orderList[i].serviceStatus == 20 &&
                  this.orderList[i].orderStatus == 20&&this.orderList[i].productType == 10
                ) {
                  this.orderList[i].serviceStopBtn = true;
                } else {
                  this.orderList[i].serviceStopBtn = false;
                }
                //服务开启
                if (
                  this.orderList[i].serviceStatus == 30 &&
                  this.orderList[i].orderStatus == 20&&this.orderList[i].productType == 10
                ) {
                  this.orderList[i].serviceStartBtn = true;
                } else {
                  this.orderList[i].serviceStartBtn = false;
                }
                //修改组织
                // if (
                //   this.orderList[i].orderStatus == 20&&this.orderList[i].productCode == "CP1911270003"
                // ) {
                //   this.orderList[i].btnDditOrg = true;
                // } else {
                //   this.orderList[i].btnDditOrg = false;
                // }
                //订单长务险服务完成按钮
                if (
                  this.orderList[i].serviceStatus == 20 &&
                  this.orderList[i].orderStatus == 20&&this.orderList[i].productType == 10
                ) {
                  this.orderList[i].serviceCompleteBtn = true;
                } else {
                  this.orderList[i].serviceCompleteBtn = false;
                }
                //排程SchedulingBtn
                if (
                  (this.orderList[i].orderStatus == 20 ||
                    this.orderList[i].orderStatus == 40) &&
                  this.orderList[i].serviceStatus == 20&&this.orderList[i].productType == 10
                ) {
                  this.orderList[i].SchedulingBtn = true;
                } else {
                  this.orderList[i].SchedulingBtn = false;
                }
              }
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.$message.error(response.data.statusMsg);
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    //导出订单
    exportOrders() {
      const tHeader = [
        "序号",
        "订单号",
        "订单状态",
        "付款状态",
        "服务状态",
        "客户联系方式",
        "被照护人姓名",
        "被照护人身份证号",
        "医保类型",
        "产品名称",
        "服务起止日期",
        "销售价（元）",
        "订单来源",
        "组织",
        "支付方式",
        "关联订单号",
        "是否被关联",
        "备注",
        "创建时间",
        "付款时间"
      ];
      // 上面设置Excel的表格第一行的标题
      const filterVal = [
        "orderNum",
        "orderCode",
        "orderStatusValue",
        "payStatusValue",
        "serviceStatusValue",
        "customerTel",
        "careReceiverName",
        "careReceiverIdCard",
        "medicalTypeValue",
        "productName",
        "serviceDate",
        "sellPrice",
        "orderSourceValue",
        "orgName",
        "payTypeValue",
        "relationOrderCode",
        "isRelatedValue",
        "remark",
        "createDate",
        "payDate"
      ];
      const params = {
        pageNum: 1,
        pageSize: 100000,
        orderCode: this.filters.orderCode,
        careReceiverName: this.filters.careReceiverName,
        createDateB:
          this.filters.createDate != null ? this.filters.createDate[0] : null,
        createDateE:
          this.filters.createDate != null ? this.filters.createDate[1] : null,
        customerTel: this.filters.customerTel,
        isRelated: this.filters.isRelated,
        orderSource: this.filters.orderSource,
        payStatus: this.filters.payStatus,
        productName: this.filters.productName,
        productCode: this.filters.productCode,
        serviceStatus: this.filters.serviceStatus,
        payType: this.filters.payType,
        medicalType: this.filters.medicalType,
        orderStatus: this.filters.orderStatus,
        orgCode: this.filters.orgCode,
        careReceiverIdCard: this.filters.careReceiverIdCard
      };
      findProductOrderList(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            const list = response.data.responseData;
            // debugger;
            if (list.length > 0) {
              list.forEach((item, index) => {
                item.orderNum = index + Number(1);
                item.remark = item.remark !== undefined ? item.remark : "";
                // item.createDate =
                //   item.createDate !== undefined
                //     ? changeYMD(new Date(item.createDate))
                //     : "";
                item.payDate =
                  item.payDate !== undefined
                    ? changeYMD(new Date(item.payDate))
                    : "";
                item.serviceStartDate =
                  item.serviceStartDate !== undefined
                    ? changeYMD(new Date(item.serviceStartDate))
                    : "";
                item.serviceEndDate =
                  item.serviceEndDate !== undefined
                    ? changeYMD(new Date(item.serviceEndDate))
                    : "";
                item.serviceDate = this.getDate(item);
                return item;
              });
              const data = this.formatJson(filterVal, list);
              export_json_to_excel(tHeader, data, "订单管理");
            } else {
              this.$message.error("暂无数据，无法导出Excel");
              return false;
            }
          }
        })
        .catch(error => {
          console.log(error);
          this.searchLoading = false;
        });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    getDate(item) {
      var result = "";
      if (item.serviceStartDate !== undefined) {
        result += item.serviceStartDate;
      }
      if (item.serviceEndDate !== undefined) {
        result += "-" + item.serviceEndDate;
      }
      return result;
    },
    downExcel2() {
       axios.post('/static/dddr.xlsx', {
          responseType: 'blob', //重要
        }).then(response => {
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement('a');
          let fname = '模板.xls';
          link.href = url;
          link.setAttribute('download', fname);
          document.body.appendChild(link);
          link.click();
        })
      },
    //导入订单
    downExcel() {
      /* 下载模板 */
      require.ensure([], () => {
        const tHeader = [
          //  "序号",
          "(备注：带*的必填) *组织",
          "*产品名称",
          "*单次服务时长",
          "*评估等级",
          "*服务开始日期",
          "*服务结束日期",
          "*身份证",
          "*姓名",
          "*性别(男、女)",
           "*联系方式",
           "*户籍省",
           "*户籍市",
           "*户籍区",
           "*户籍详细地址",
           "*现居住省",
           "*现居住市",
           "*现居住区",
           "*现居住街道",
           "*现居住详细地址",
            "民族",
            "籍贯",
            "政治面貌",
            "最高学历",
            "婚姻状况",
            "医保类型（职保、居保、离休、帮困、其他）",
            "医保卡号",
            "宗教信仰",
            "身体损伤",
            "紧急联系人",
            "紧急联系人电话",
            "是联系人的谁",
            "备注"
        ];
        // 上面设置Excel的表格第一行的标题
        const filterVal = [];
        // table表格中对应的属性名
        const list = this.tableData; //把data里的tableData存到list
        // if(list.length>0){
        //   list.forEach((item,index)=>{
        //     // item.orderNum = index + Number(1);
        //     return item;
        //   })
        // }
        const data = this.formatJson(filterVal, list);
        export_json_to_excel(tHeader, data, "订单导入");
      });
    },
    beforeAvatarUpload(file) {
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "xls";
      const extension2 = testmsg === "xlsx";
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!extension && !extension2) {
        this.$message({
          message: "上传文件只能是 xls、xlsx格式!",
          type: "warning"
        });
      }
      if (!isLt2M) {
        this.$message({
          message: "上传文件大小不能超过 2MB!",
          type: "warning"
        });
      }
      return extension || (extension2 && isLt2M);
    },
    handleChangeImportant(file, fileList) {
      this.fileImportList[0] = file.raw;
    },
    handleImportExceed(files, fileList) {
     this.$message.error(
        `只能选择 1 个文件，当前共选择了 ${files.length +
          fileList.length} 个`
      );
    },
    handleRemoveImport(file, fileList) {
      this.fileImportList = [];
    },
    importOrders() {
      this.dialogImport = true;
    },
    handleImportClose() {
      this.dialogImport = false;
      this.fileImportList = [];
    },
    //导入订单
    uploadFile() {
       const loading = this.$loading({
        lock: true,
        text: "导入订单中...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.5)"
      });
      // 通过 FormData 对象上传文件
      this.importDisabled = true;
      var formData = new FormData();
      formData.append("file",   this.fileImportList[0]);
      importWorkOrder(formData).then(response => {
        if (response.data.statusCode == "200") {
          loading.close()
          this.$message.success("操作成功");
          this.dialogImport=false;
          this.importDisabled = false;
          this.fileImportList = [];
          this.getList();
        } else{
          loading.close()
          this.$message.error(response.data.statusMsg);
          this.importDisabled = false;
          this.fileImportList = [];
        }
      }).catch(error => {
        console.log(error);
      })
    },
    // 确认上传
    submitImport() {
      this.$refs.upload.submit();
    },

    cancelImport(){
      this.dialogImport = false;
      this.fileImportList = [];
    },
    handleCloseOrg() {
      this.dialogVisible = false;
    },
    
    //获取组织
    getCurrentNode(data) {
         this.filters.orgName = data.orgName;
         this.filters.orgCode = data.orgCode;
         this.handleCloseOrg(); 
    },
     handleEditCloseOrg() {
      this.dialogEditVisible = false;
    },
    //清空组织过滤
    clearOrgCode() {
      // this.filters.orgName = "";
      this.filters.orgCode = "";
    },
    //跳转新增订单页面
    insertOrders(page) {
     this.filters.page=page
      this.$router.push({
        path: "/businessServiceManagement/addOrderInfo"
      });
    },
    //查看订单详情
    handleOrder(row) {
      if (row.orderSource == "10") {
        this.$router.push({
          path: "/businessServiceManagement/updateOnlineOrderInfo",
          query: {
            orderCode: row.orderCode
          }
        });
      } else {
        this.$router.push({
          path: "/businessServiceManagement/updateOrderInfo",
          query: {
            orderCode: row.orderCode
          }
        });
      }
    },
    //跳转订单排程
    handleScheduling(row) {
      this.$router.push({
        path: "/businessServiceManagement/orderScheduling",
        query: {
          code: row.orderCode
        }
      });
    },
    //服务确认
    serviceValidation(orderCode) {
      this.serviceCode = orderCode;
      this.dialogServerOrder = true;
    },
    //订单服务完成
    serviceCompletion(orderCode) {
      this.serviceCompletionCode = orderCode;
      this.dialogServerComplentOrder = true;
    },

    //取消订单弹窗
    cancelOrder(orderCode, orderSource) {
      this.dialogCancelOrder = true;
      this.orderCode = orderCode;
      this.orderSource = orderSource;
    },
    //复制订单页面
    copyOrder(row) {
      this.filters.page=1
      this.$router.push({
        path: "/businessServiceManagement/copyOrderInfo",
        query: {
          orderCode: row.orderCode
        }
      });
    },
    //交易流水操作
    refundSlip(orderCode) {
      this.dialogPriceSlip = true;
      this.slipCode = orderCode;
      this.getProductOrder();
    },
    //查看交易流水
    async getProductOrder() {
      this.listLoading = true;
      var params = {
        orderCode: this.slipCode
      };
      const response = await findFeeListByOrderCode(params);
      if (response.data.responseData != undefined) {
        if (
          response.data.statusCode == 200 ||
          response.data.statusCode == "200"
        ) {
          this.listLoading = false;
          const {
            data: { responseData }
          } = response;
          this.slipData = responseData;
          // if (this.slipData.length > 0) {
          //   for (let i = 0; i < this.slipData.length; i++) {
          //     this.slipData[i].payDate = changeYMD(this.slipData[i].payDate);
          //   }
          // }
        }
      } else {
        this.$message.error(response.data.statusMsg);
        this.listLoading = false;
        return false;
      }
    },

    //退款操作
    refundOrder(orderCode, orderSource, feeType) {
      if (feeType == "20") {
        this.title = "退款";
        this.dialogreFundOrder = true;
        this.fundCode = orderCode;
        this.fundSourceOrder = orderSource;
        this.formFundOrder.feeType = feeType;
        this.formFundOrder.title = "请输入退款金额";
        this.formFundOrder.titles = "请输入退款退款原因，谢谢";
      } else {
        this.title = "补差价";
        this.dialogreFundOrder = true;
        this.fundCode = orderCode;
        this.fundSourceOrder = orderSource;
        this.formFundOrder.feeType = feeType;
        this.formFundOrder.title = "请输入补差价金额";
        this.formFundOrder.titles = "请输入补差价原因，谢谢";
      }
    },
    getRefund() {
      this.isDisabled = true;
      var params = {
        orderCode: this.fundCode,
        fee: this.formFundOrder.fee,
        feeType: this.formFundOrder.feeType,
        orderSource: this.fundSourceOrder,
        remark: this.formFundOrder.remark
      };
      insertOrderFee(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogreFundOrder = false;
            this.isDisabled = false;
            this.formFundOrder.remark = "";
            this.formFundOrder.fee = "";
            this.formFundOrder.feeType = "";
            this.fundCode = "";
            this.fundSourceOrder = "";
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            // this.formFundOrder.remark = "";
            // this.formFundOrder.fee = "";
            // this.formFundOrder.feeType = "";
            // this.fundCode = "";
            // this.fundSourceOrder = "";
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.isDisabled = false;
          return false;
        });
    },
    okFundOrder(formFundOrder) {
      this.isDisabled = true;
      this.$refs[formFundOrder].validate(valid => {
        if (valid) {
          this.getRefund();
          this.$refs[formFundOrder].resetFields();
        } else {
          this.isDisabled = false;
          return false;
        }
      });
    },
    cancelFundOrder(formFundOrder) {
      this.dialogreFundOrder = false;
      this.$refs[formFundOrder].resetFields();
    },
    noOrder(formFundOrder) {
      this.dialogCancelOrder = false;
      this.cancelDescription = "";
    },
    //服务确认
    ServiceOrder() {
      this.isDisabled = true;
      var params = {
        orderCode: this.serviceCode
      };
      updateProductOrderForPay(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogServerOrder = false;
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.isDisabled = false;
          return false;
        });
    },
    ServiceComplentOrder() {
      this.isDisabled = true;
      var params = {
        orderCode: this.serviceCompletionCode
      };
      updateProductOrderForOverord(params)
        .then(response => {
          if (
            response.data.statusCode == 200 ||
            response.data.statusCode == "200"
          ) {
            this.$message.success("操作成功");
            this.dialogServerComplentOrder = false;
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          this.isDisabled = false;
          return false;
        });
    },
    //取消订单确认
    okOrder() {
      this.isDisabled = true;
      var params = {
        orderCode: this.orderCode,
        orderSource: this.orderSource,
        cancelDescription: this.cancelDescription
      };
      updateProductOrderForCancel(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.cancelDescription = "";
            this.dialogCancelOrder = false;
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.isDisabled = false;
          return false;
        });
    },
    //服务开启
    serviceStart(orderCode) {
      this.serviceStartCode = orderCode;
      this.dialogServerStart = true;
    },
    ServerOrderStart() {
      this.isDisabled = true;
      var params = {
        orderCode: this.serviceStartCode
      };
      updateServiceOn(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogServerStart = false;
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            this.dialogServerStart = false;
            this.getList();
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.dialogServerStart = false;
          this.isDisabled = false;
          return false;
        });
    },
    //服务暂停
    serviceStop(orderCode) {
      this.serviceStopCode = orderCode;
      this.dialogServerStop = true;
    },
    ServerOrderStop() {
      this.isDisabled = true;
      var params = {
        orderCode: this.serviceStopCode,
        servicePauseReason: this.servicePauseReason
      };
      updateServiceSuspension(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogServerStop = false;
            this.isDisabled = false;
            this.servicePauseReason = "";
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.isDisabled = false;
          return false;
        });
    },
    stopCancel() {
      this.servicePauseReason = "";
      this.dialogServerStop = false;
    },
    //长务险订单完成操作
    serviceCWXComplete(orderCode) {
      this.serviceCWXCompletionCode = orderCode;
      this.dialogCHXServerComplete = true;
    },
    ServerCHXOrderComplete() {
      this.isDisabled = true;
      var params = {
        orderCode: this.serviceCWXCompletionCode,
        serviceCompletionReason: this.serviceCompletionReason
      };
      updateServiceComplete(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogCHXServerComplete = false;
            this.serviceCompletionReason = "";
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.serviceCompletionReason = "";
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.serviceCompletionReason = "";
          this.isDisabled = false;
          return false;
        });
    },
    handleCloseEffect(){
      this.dialogEffectVisible=false
    },
    //批量生效
   effectSelect(){
     let list = this.multipleSelection;
      if (list.length == 0) {
        this.$message.error("请选择操作项");
        return false;
      } else {
        this.dialogEffectVisible = true;
        // debugger;
        for (let i = 0; i < list.length; i++) {
          if (
            list[i].orderStatus == "10" && list[i].serviceStatus == "10"
          ) {
            this.orderEffectCodeList[i] = list[i].orderCode;
          } else {
            this.dialogEffectVisible = false;
            this.$message.error("请选择待确认且未服务状态的长护险产品");
            this.orderEffectCodeList=[]
            return false;
          }
        }
      }
   },
   effectSubmit(){
      this.isDisabled = true;
      var params = {
        // orderCode: this.orderEffectCode,
        orderCodeList: this.orderEffectCodeList

      };
      updateServiceStatusEffective(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogEffectVisible = false;
            this.orderEffectCodeList=[]
            this.isDisabled = false;
            this.getList();
          } else {
            this.$message.error(response.data.statusMsg);
            this.dialogEffectVisible = false;
            this.orderEffectCodeList=[]
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.dialogEffectVisible = false;
          this.orderEffectCodeList=[]
          this.isDisabled = false;
          return false;
        });
   },
   effectCancel(){
     this.dialogEffectVisible = false;
   },
    //单个订单生效弹窗操作
    orderEffect(orderEffectCode) {
      // this.orderEffectCode = orderEffectCode;
      this.orderEffectSeverCodeList.push(orderEffectCode)
      this.dialogServerEffect = true;
    },
    ServerOrderEffect() {
      this.isDisabled = true;
      var params = {
        // orderCode: this.orderEffectCode,
        orderCodeList: this.orderEffectSeverCodeList

      };
      updateServiceStatusEffective(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.$message.success("操作成功");
            this.dialogServerEffect = false;
            this.isDisabled = false;
            this.orderEffectSeverCodeList=[]
            this.getList();
          } else {
            this.dialogServerEffect = false;
            this.orderEffectSeverCodeList=[]
            this.$message.error(response.data.statusMsg);
            this.isDisabled = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
          this.isDisabled = false;
          this.orderEffectSeverCodeList=[]
          this.dialogServerEffect = false;
          return false;
        });
    },
    handleClose() {
      this.dialogCancelOrder = false;
      this.dialogreFundOrder = false;
      this.dialogPriceSlip = false;
      this.dialogServerOrder = false;
      this.dialogServerComplentOrder = false;
      this.dialogServerStart = false;
      this.dialogServerStop = false;
      this.dialogCHXServerComplete = false;
      this.dialogServerEffect = false;
      this.servicePauseReason = "";
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.filters.productCode = "";
      // this.filters.page=1
      alert(JSON.stringify(this.filters))
      this.getList();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //订单状态
      findValueBySetCode({ valueSetCode: "ORDER_STATUS" })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.orderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //付款状态
      findValueBySetCode({ valueSetCode: "PAY_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.payOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //订单来源
      findValueBySetCode({ valueSetCode: "ORDER_SOURCE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.orderSourceOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //支付方式
      findValueBySetCode({ valueSetCode: "PAY_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.payTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否被关联
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isRelationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //医保类型
      findValueBySetCode({ valueSetCode: "HEALTH_INSURANCE_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.medicalTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务状态
      findValueBySetCode({ valueSetCode: "SERVICE_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.serviceStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务暂停
      findValueBySetCode({ valueSetCode: "SERVICE_PAUSE_REASON" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.servicePauseReasonOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务完成
      findValueBySetCode({ valueSetCode: "SERVICE_COMPLETION_REASON" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.serviceCompletionReasonOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    },
    //按钮权限
    // buttonControl() {
    //   this.showList.edit_organization_onClick = hasPermission(
    //     "edit_organization_onClick"
    //   );
    // }
  },
  created() {
    // this.buttonControl()
    this.initDataDictionary();
    this.loadListTree();
    this.getOneproduct()
  },
  mounted() {
  },
  activated() {
    this.getList();

  }
};
</script>

<style lang="scss" scoped>
#orgSelect {
  height: 500px;
  overflow-y: auto;
}
#orderManage {
  width: 100%;
  min-width: 1200px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.search_btn {
  min-width: 250px;
  margin-left: 125px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
.fund-order {
  margin: 20px 0;
}
.orderNumber {
  font-size: 20px;
  color: #000;
  margin: 30px 0 30px 0;
}
.el-autocomplete {
  width: 200px;
}
.order_title {
  margin: 20px 0;
  text-align: center;
  font-size: 16px;
  color: #000;
}
</style>
<style lang="scss">
#orderManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
.el-dialog__body {
  padding: 0px 20px;
}
.filter-input {
  width: 100%;
}
#orgSelect .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#orgSelect .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#orgSelect .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content {
  color: #f98c3c;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content i {
  background-color: #f98c3c;
  width: 8px;
  height: 8px;
  display: -webkit-inline-box;
  border-radius: 50%;
  margin-right: 5px;
}
</style>
