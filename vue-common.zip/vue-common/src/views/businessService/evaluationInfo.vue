<template>
  <div id="evaluateInfo">
    <headTag :tagName="tagName"/>
    <div class="main-content">
      <el-row class="topToolbar" type="flex">
        <el-col>
          <el-button
            type="primary"
            size="mini"
            class="rightBtn"
            style="margin-left:20px;"
            @click="returnEvaluationList"
          >返回</el-button>
        </el-col>
      </el-row>
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">服务对象</span>
          </el-col>
        </el-row>
        <el-form :inline="false" :model="serviceObjForm" label-width="200px" class="form-content">
          <el-row>
            <el-col class="form-item">
              <el-form-item label="客户姓名">{{serviceObjForm.customerFullName}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="客户联系方式">{{serviceObjForm.customerTel}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="被照护人姓名">{{serviceObjForm.careReceiverName}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="被照护人联系方式">{{serviceObjForm.careReceiverTel}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务地址">
                <span class="long-field">{{serviceObjForm.serviceAddress}}</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">服务信息</span>
          </el-col>
        </el-row>
        <el-form :inline="false" :model="serviceInfoForm" label-width="200px" class="form-content">
          <el-row>
            <el-col class="form-item">
              <el-form-item label="服务人员">{{serviceInfoForm.careGiverName}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="签入时间">{{serviceInfoForm.checkinDate}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="签出时间">{{serviceInfoForm.checkoutDate}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务时长">
                <span
                  v-if="serviceInfoForm.planServiceDuration"
                >{{serviceInfoForm.planServiceDuration}}h</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务项">{{serviceInfoForm.serviceItems}}</el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 护理员 -->
      <div class="panel-card" v-if="isShow">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">生命体征</span>
          </el-col>
        </el-row>
        <el-row>
          <el-form :inline="false" label-width="150px">
            <el-col class="form-itemd">
              <el-form-item label="收缩压:">
                <span v-if="obj.ssy">{{obj.ssy}}&nbsp;mmHg</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="舒张压:">
                <span v-if="obj.szy">{{obj.szy}}&nbsp;mmHg</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="意识:">
                <span>{{obj.ys}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="面色:">
                <span>{{obj.ms}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="睡眠:">
                <span>{{obj.sm}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="食欲:">
                <span>{{obj.sy}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="大便:">
                <span>{{obj.db}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-itemd">
              <el-form-item label="饮水量:">
                <span>{{obj.ysl}}</span>
              </el-form-item>
            </el-col>
          </el-form>
        </el-row>
      </div>
      <!-- //护士 -->
      <div class="panel-card" v-if="!isShow">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">生命体征</span>
          </el-col>
        </el-row>
        <el-row>
          <el-form :inline="false" label-width="150px">
            <el-col class="form-item">
              <el-form-item label="脉搏:">
                <span v-if="obj.mb">{{obj.mb}}&nbsp;次/分</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="呼吸:">
                <span v-if="obj.hx">{{obj.hx}}&nbsp;次/分</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="体温:">
                <span v-if="obj.tw">{{obj.tw}}>&nbsp;℃</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="收缩压:">
                <span v-if="obj.ssy">{{obj.ssy}}&nbsp;mmHg</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="舒张压:">
                <span v-if="obj.szy">{{obj.szy}}&nbsp;mmHg</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="血糖:">
                <span v-if="obj.xt">{{obj.xt}}&nbsp;mol/L</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="检测时间段:">
                <span v-if="obj.jcsjd">{{obj.jcsjd}}&nbsp;</span>
              </el-form-item>
            </el-col>
          </el-form>
        </el-row>
      </div>
      <div class="panel-card" v-if="!isShow">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">健康状态</span>
          </el-col>
        </el-row>
        <el-row>
          <el-form :inline="false" label-width="150px">
            <el-col class="form-item">
              <el-form-item label="意识:">
                <span v-if="obj.ys">{{obj.ys}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="睡眠质量:">
                <span v-if="obj.smzl">{{obj.smzl}}&nbsp;h/天</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="水分摄入量:">
                <span v-if="obj.sfsrl">{{obj.sfsrl}}&nbsp;ml/天</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="水分摄入:">
                <span v-if="obj.sfsr">{{obj.sfsr}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="营养摄入:">
                <span v-if="obj.yysr">{{obj.yysr}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="进食形态:">
                <span v-if="obj.jszt">{{obj.jszt}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="皮肤:">
                <span v-if="obj.pf">{{obj.pf}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="皮肤情况说明:">
                <span v-if="obj.pfqksm">{{obj.pfqksm}}&nbsp;</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="尿量:">
                <span v-if="obj.nl">{{obj.nl}}&nbsp;ml/天</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="大便:">
                <span v-if="obj.db">{{obj.db}}&nbsp;</span>
              </el-form-item>
            </el-col>
          </el-form>
        </el-row>
      </div>
      <div class="panel-card" v-if="!isShow">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">用药情况</span>
          </el-col>
        </el-row>
        <el-row>
          <el-form :inline="false" label-width="150px">  
            <el-col class="serviceDetail">
              <div v-for="(item,i) in this.MedicationList" :key="i">
                <el-col class="form-itemD">
                  <el-form-item label="药物名称:">
                    <span>{{item[0]}}&nbsp;</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-itemD">
                  <el-form-item label="服用频次:">
                    <span>{{item[1]}}&nbsp;</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-itemD">
                  <el-form-item label="药物剂量:">
                    <span>{{item[2]}}&nbsp;</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-itemD">
                  <el-form-item label="是否按时服药:">
                    <span>{{item[3]}}&nbsp;</span>
                  </el-form-item>
                </el-col>
              </div>
            </el-col>
          </el-form>
        </el-row>
      </div>
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">评价信息</span>
          </el-col>
        </el-row>
        <el-form :inline="false" :model="evaluateInfoForm" label-width="200px" class="form-content">
          <el-row>
            <el-col class="form-item">
              <el-form-item label="评价总分">
                <span v-if="evaluateInfoForm.evaluationScore">
                  <span style="color:red;">{{evaluateInfoForm.evaluationScore}}</span>分
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="着装礼仪">
                <el-rate
                  v-model="evaluateInfoForm.dressEtiquette"
                  :colors="colors"
                  class="rateStyle"
                ></el-rate>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务态度">
                <el-rate
                  v-model="evaluateInfoForm.serviceAttitude"
                  :colors="colors"
                  class="rateStyle"
                ></el-rate>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务技能">
                <el-rate v-model="evaluateInfoForm.serviceSkill" :colors="colors" class="rateStyle"></el-rate>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="评价内容">
                <span style="word-break: break-all;" class="long-field">
                  <div v-if="evaluateInfoForm.firstEvaluation">
                    {{evaluateInfoForm.firstEvaluation}}
                  </div>
                  <div v-else>
                    <span>此用户没有填写评价</span>
                  </div>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="评价时间">{{evaluateInfoForm.firstDate}}</el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="评价人">{{evaluateInfoForm.customerFullName}}</el-form-item>
            </el-col>
            <div v-if="evaluateInfoForm.appendEvaluation">
              <el-col class="form-item">
                <el-form-item label="追评内容">
                  <span style="word-break: break-all;" class="long-field">{{evaluateInfoForm.appendEvaluation}}</span>
                </el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="追评时间">{{evaluateInfoForm.appendDate}}</el-form-item>
              </el-col>
              <el-col class="form-item">
                <el-form-item label="评价人">{{evaluateInfoForm.customerFullName}}</el-form-item>
              </el-col>
            </div>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import {
  getWorkorderDetail,
  selectWoWorkorderEvaluationById
} from "api/workOrderManagement";
import { parseInt } from "lodash-es";
export default {
  data() {
    return {
      tagName: "评价详情",
      value: 5,
      colors: ["#99A9BF", "#F7BA2A", "#FF9900"],
      isShow: true,
      /**
       *
       * 服务对象Form
       *
       */
      serviceObjForm: {},
      MedicationList: [],
      careReceiverSignList: [],
      obj: {},
      /*
       *
       * 服务信息Form
       *
       */
      serviceInfoForm: {},
      /*
       *
       * 评价信息Form
       *
       */
      evaluateInfoForm: {},
      /**
       *
       * 页面传参
       *
       */
      workorderCode: "",
      evaluationId: ""
    };
  },
  components: {
    HeadTag
  },
  methods: {
    /**
     *
     * 获取服务Form
     *
     */
    getWorkorderDetail() {
      var param = {
        workorderCode: this.workorderCode,
        distinguishStatus: "20"
      }; //TODO
      getWorkorderDetail(param)
        .then(response => {
          if (response.data.statusCode == 200) {
            var data = response.data.responseData;
            this.serviceObjForm.careReceiverName = data.careReceiverName;
            this.serviceObjForm.careReceiverTel = data.careReceiverTel;
            this.serviceObjForm.serviceAddress =
              data.liveProvinceName +
              data.liveCityName +
              data.liveDistrictName +
              data.liveSubdistrictName +
              data.liveDetailAddress;
            this.serviceInfoForm.careGiverName = data.careGiverName;
            this.serviceInfoForm.checkinDate = data.checkinDate;
            this.serviceInfoForm.checkoutDate = data.checkoutDate;
            this.serviceInfoForm.planServiceDuration = data.planServiceDuration;
            this.serviceInfoForm.serviceItems = data.serviceItems;
            if (data.servicePositionCode == "GW1911270089") {
							//护理员
							this.isShow = true;
							this.$forceUpdate()
						} else {
							//护士
							this.isShow = false;
							this.$forceUpdate()
						}
            if (data.careReceiverSignList.length > 0) {
							this.careReceiverSignList =
								data.careReceiverSignList;
							var hasMedication = false;
							this.careReceiverSignList.forEach(item => {
								if (item.signCode == "MEDICATION") {
									hasMedication = true;
								}
							})
							if (!hasMedication) {
								var obj = JSON.parse(JSON.stringify(this.careReceiverSignList[0]));
								obj.signValue = "|||";
								obj.signName = "用药情况";
								this.$set(obj, "signCode", "MEDICATION")
								this.careReceiverSignList.push(obj)
							}
							this.careReceiverSignList.forEach(item => {
								switch (item.signName) {

									case "收缩压":
										this.obj.ssy = item.signValue;
										break;
									case "舒张压":
										this.obj.szy = item.signValue;
										break;
									case "面色":
										this.obj.ms = item.signValue;
										break;
									case "睡眠":
										this.obj.sm = item.signValue;
										break;
									case "食欲":
										this.obj.sy = item.signValue;
										break;
									case "大便":
										this.obj.db = item.signValue;
										break;
									case "饮水量":
										this.obj.ysl = item.signValue;
										break;
									case "脉搏":
										this.obj.mb = item.signValue;
										break;
									case "呼吸":
										this.obj.hx = item.signValue;
										break;
									case "体温":
										this.obj.tw = item.signValue;
										break;
									case "血糖":
										this.obj.xt = item.signValue;
										break;
									case "检测时间段":
										this.obj.jcsjd = item.signValue;
										break;
									case "意识":
										this.obj.ys = item.signValue;
										break;
									case "睡眠质量":
										this.obj.smzl = item.signValue;
										break;
									case "水分摄入量":
										this.obj.sfsrl = item.signValue;
										break;
									case "水分摄入":
										this.obj.sfsr = item.signValue;
										break;
									case "营养摄入":
										this.obj.yysr = item.signValue;
										break;
									case "进食形态":
										this.obj.jszt = item.signValue;
										break;
									case "皮肤":
										this.obj.pf = item.signValue;
										break;
									case "尿量":
										this.obj.nl = item.signValue;
										break;
									case "皮肤情况说明":
										this.obj.pfqksm = item.signValue;
										break;
									case "用药情况":
										if (item.signValue) {
											this.MedicationList.push(item.signValue.split("|"))
										}
										break;
								}
							});
						} else if (data.careReceiverSignList.length == 0) {
							this.careReceiverSignList =
								data.careReceiverSignList;
							var obj = {}
							obj.signName = "用药情况";
							obj.signValue = "|||";
							obj.signCode = "MEDICATION";
							this.careReceiverSignList.push(obj)
							this.MedicationList.push(obj.signValue.split("|"))
						}
          }
        })
        .catch(error => {
          console.log("getServiceForm:" + error);
        });
    },
    /**
     *
     * 获取评价Form
     *
     */
    selectWorkorderEvaluation() {
      var param = {
        id: this.evaluationId
      };
      selectWoWorkorderEvaluationById(param)
        .then(response => {
          if (response.data.statusCode == 200) {
            // debugger
            var data = response.data.responseData;
            this.serviceObjForm.customerFullName = data.customerFullName;
            this.serviceObjForm.customerTel = data.customerTel;
            this.evaluateInfoForm.customerFullName = data.customerFullName;
            this.evaluateInfoForm.evaluationScore = data.evaluationScore;
            this.evaluateInfoForm.dressEtiquette = parseInt(
              data.dressEtiquette
            );
            this.evaluateInfoForm.serviceAttitude = parseInt(
              data.serviceAttitude
            );
            this.evaluateInfoForm.serviceSkill = parseInt(data.serviceSkill);
            this.evaluateInfoForm.firstEvaluation = data.firstEvaluation;
            this.evaluateInfoForm.firstDate = data.firstDate;
            this.evaluateInfoForm.appendEvaluation = data.appendEvaluation;
            this.evaluateInfoForm.appendDate = data.appendDate;
          }
        })
        .catch(error => {
          console.log("getServiceForm:" + error);
        });
    },
    /**
     * 返回评价列表
     *
     */
    returnEvaluationList() {
      this.$router.push({
        path: "/businessServiceManagement/evaluationManagementList"
      });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.workorderCode = param.workorderCode;
    this.evaluationId = param.evaluationId;
  },
  mounted() {
    //获取服务Form
    this.getWorkorderDetail();
    //获取评价Form
    this.selectWorkorderEvaluation();
  },
  destroyed() {
    // sessionStorage.removeItem("editOrderCode");
  }
};
</script>

<style lang="scss" scoped>
#evaluateInfo {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 0px 10px 10px 10px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.topToolbar {
  padding: 10px;
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.form-item {
  width: 30%;
  min-width: 500px;
  padding-bottom: 5px;
  max-height: 50px;
}
.form-itemd {
	width: 50%;
}
.form-itemD {
	width: 25%;
	min-width: 280px;
	height: 60px;
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
  padding-bottom:30px;
}
.rateStyle {
  line-height: 0;
  margin-top: 8px;
}
</style>
 <style lang="scss">
#evaluateInfo {
  .el-icon-star-on {
    font-size: 22px;
  }
}
</style>