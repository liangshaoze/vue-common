<template>
  <div style="padding:10px">
    <div class="productForm">
      <el-form
        ref="productForm"
        :inline="false"
        :model="productForm"
        :rules="productForm.rules"
        label-width="200px"
        class="form-content"
      >
        <el-row class="importToolbar" type="flex">
          <el-col>
            <span class="form-tag">产品信息</span>
          </el-col>
          <el-col>
            <span v-if="productForm.isCopy === false">
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                style="margin-left:20px;"
                @click="returnOrderList"
              >返回</el-button>
              <span v-if="orderInfo">
                <span v-if="orderInfo.orderStatus === '10'">
                  <!--产品信息：“订单状态”为“服务中”或是“服务中”之后的状态，产品信息所有字段，不可修改-->
                  <span
                    v-if="(orderInfo.orderSource === '10' || orderInfo.orderSource === '20') &&orderInfo.payStatus === undefined"
                  >
                    <el-button
                      type="primary"
                      size="mini"
                      class="rightBtn"
                      @click="updateInfos()"
                    >{{isEditInfo?'保存':'修改'}}</el-button>
                  </span>
                </span>
                <span v-if="isInserviceWithCHXOrder()">
                  <!--“订单状态”为“服务中”且仅限于产品类型是“长护险”的订单-->
                  <el-button
                    type="primary"
                    size="mini"
                    class="rightBtn"
                    @click="updateSpecs()"
                  >{{isEditInfo?'保存':'修改'}}</el-button>
                </span>
              </span>
            </span>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item
              label="组织"
              prop="orgName"
              :rules="[{required: true,message: '请选择组织',trigger: 'change'}]"
            >
              <span v-if="!canEdit()">{{orderInfo?orderInfo.orgName:""}}</span>
              <span v-if="canEdit()">
                <el-input
                  v-model="productForm.orgName"
                  size="mini"
                  placeholder="请选择组织"
                  @focus="openDialog()"
                  clearable
                  @input="removeOrgCode"
                  @clear="removeOrgCode"
                ></el-input>
              </span>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item
              label="产品名称"
              label-width="200px"
              prop="productCode"
              :rules="[{required: true,message: '请选择产品名称',trigger: 'change'}]"
            >
              <span v-if="!canEdit()">{{orderInfo?orderInfo.productName:""}}</span>
              <span v-else-if="canEdit()">
                <el-autocomplete
                  v-model="productForm.productName"
                  size="mini"
                  clearable
                  :fetch-suggestions="fetchProductList"
                  placeholder="请输入产品名称"
                  @select="changeProductName"
                  @clear="removeProductCode"
                  @input="removeProductCode"
                >
                  <template slot-scope="{ item }">
                    <el-tooltip
                      class="tooltip-item"
                      effect="dark"
                      :content="item.productName"
                      placement="right"
                    >
                      <span>{{item.productName}}</span>
                    </el-tooltip>
                  </template>
                </el-autocomplete>
              </span>
            </el-form-item>
          </el-col>
        </el-row>
        <div v-if="productInfo">
          <div v-for="(item,index) in productNamesOptions" :key="index">
            <span v-if="item.productCode == productForm.productCode">
              <ProductSpecGrid
                :productSpecificationList="productInfo.productSpecificationList"
                :productOrderSpecificationList="productForm.productOrderSpecificationList"
                :colNum="colNum"
                :isEdit="isEditInfo"
                @onSpecChangeListener="onSpecChangeListener"
              />
              <el-form-item
                label="服务频次"
                v-if="orderInfo&&!isEditInfo&&item.productType == '10'&&orderInfo.serviceFrequency"
                class="form-item"
              >
                <span
                  style="font-size:14px"
                >每{{orderInfo.serviceFrequencyTypeValue}}服务{{orderInfo.serviceFrequency}}次</span>
              </el-form-item>
              <el-row v-if="item.productType != '10'">
                <el-col class="form-item">
                  <el-form-item label="市场价格" prop="marketPrice">
                    <span v-if="isEditInfo == false">{{productForm.marketPrice}}(元)</span>
                    <el-input
                      v-if="isEditInfo == true"
                      v-model="productForm.marketPrice"
                      size="mini"
                      :placeholder="'请输入市场价格'"
                      clearable
                      style="margin-top:5px"
                    >
                      <template slot="append">(元)</template>
                    </el-input>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="销售价格" prop="sellPrice">
                    <span v-if="isEditInfo == false">{{productForm.sellPrice}}(元)</span>
                    <el-input
                      v-if="isEditInfo == true"
                      v-model="productForm.sellPrice"
                      size="mini"
                      :placeholder="'请输入销售价格'"
                      clearable
                      style="margin-top:5px"
                    >
                      <template slot="append">(元)</template>
                    </el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <ProductPropertyGrid
                :productPropertyList="productInfo.productPropertyList"
                :productOrderPropertyList="productForm.productOrderPropertyList"
                :colNum="colNum"
                :isEdit="isEditInfo"
              />
            </span>
          </div>
        </div>
      </el-form>
      <!-- 组织架构-弹窗-->
      <el-dialog
        title="组织架构"
        :visible.sync="dialogVisible"
        width="500px"
        :before-close="handleClose"
      >
        <org-select v-on:listenTochildEvent="getCurrentNode" />
      </el-dialog>
    </div>
    <ProductServiceItemTable
      ref="serviceItemTable"
      :etProductServiceList="productInfo.etProductServiceList"
      :productOrderServiceList="productForm.productOrderServiceList"
      :isEdit="isEditServiceItems"
      @saveServiceItems="saveServiceItems"
      :savedProduct="savedProduct"
      :orderStatus="orderInfo?orderInfo.orderStatus:''"
      :productType="productForm.productType"
    />
  </div>
</template>
<script>
import ProductPropertySelect from "components/CustomerSelect/ProductPropertySelect";
import SpecSelect from "components/CustomerSelect/SpecSelect";
import ProductPropertyRadioGroup from "components/CustomerSelect/ProductPropertyRadioGroup";
import ProductPropertyInput from "components/CustomerSelect/ProductPropertyInput";
import ProductSpecGrid from "@/views/businessService/widget/ProductSpecGrid";
import ProductPropertyGrid from "@/views/businessService/widget/ProductPropertyGrid";
import OrgSelect from "components/OrgSelect";
import ProductServiceItemTable from "@/views/businessService/widget/ProductServiceItemTable";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail
} from "@/utils/validate";
import {
  findEtProductListForWebQuickSearch,
  findProductByCodeForOrder,
  updateOrderInfoForProduct, //修改产品信息
  getProductAuthorityCode, //产品权限
  getProductPriceDetail,
  editAssessGradeByOrderCode //修改产品规格
} from "api/orderManagement";
import { getEhrOrgDetailByCode } from "api/orgStructure";
export default {
  props: {
    myFormName: {
      type: String,
      default: ""
    },
    isEdit: {
      type: Boolean,
      default: false
    },
    orderInfo: {
      type: Object,
      default: undefined
    }
  },
  data() {
    return {
      isEditInfo: false,
      //产品名称加载
      loading: false,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      //选择组织弹窗
      dialogVisible: false,
      colNum: 2,
      /**
       *
       * 动态产品信息Form
       *
       */
      productForm: {
        orgName: "",
        orgCode: "",
        // orgUnitCode:"",
        productCode: "",
        productName: "",
        productType: "",
        marketPrice: "",
        sellPrice: "",
        productOrderPropertyList: [], //产品属性
        productOrderSpecificationList: [], //规格
        productOrderServiceList: [], //服务项
        rules: {
          marketPrice: [
            { required: true, message: "市场价格不能为空", trigger: "blur" },
            { validator: isMoney }
          ],
          sellPrice: [
            { required: true, message: "销售价格不能为空", trigger: "change" },
            { validator: isMoney }
          ]
        }
      },
      productNamesOptions: [],
      //产品名称动态组件
      productInfo: {
        productPropertyList: [],
        productSpecificationList: [],
        etProductServiceList: []
      },
      productAuthorityOrgCode: "",
      savedProduct: false,
      isEditServiceItems: false
    };
  },
  computed: {},
  components: {
    ProductPropertySelect,
    SpecSelect,
    ProductPropertyRadioGroup,
    ProductPropertyInput,
    ProductSpecGrid,
    ProductPropertyGrid,
    OrgSelect,
    ProductServiceItemTable
  },
  methods: {
    //产品名称下拉菜单
    findProductNamesList() {
      let params = {
        productName: "", //不传值表示查所有产品名称
        productAuthorityOrgCode: this.productAuthorityOrgCode
        // orgUnitCode:this.productForm.orgUnitCode
      };
      findEtProductListForWebQuickSearch(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.productNamesOptions = response.data.responseData;
            if (this.productNamesOptions) {
              if (this.productNamesOptions.length == 0) {
                this.$message.warning("该组织下暂无对应的产品哦~");
              } else if (this.productNamesOptions.length == 1) {
                //只有一条时默认显示产品
                this.productForm.productCode = this.productNamesOptions[0].productCode;
                this.productForm.productName = this.productNamesOptions[0].productName;
                if (
                  !this.orderInfo ||
                  this.orderInfo.orgCode != this.productForm.orgCode
                ) {
                  //新增或者切换过组织
                  this.changeProductName(this.productForm.productCode);
                }
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
    fetchProductList(queryString, cb) {
      // if(!this.productForm.orgUnitCode){
      //    cb([])
      //   return;
      // }
      if (!this.productAuthorityOrgCode) {
        cb([]);
        return;
      }
      let params = {
        productName: queryString, //不传值表示查所有产品名称
        productAuthorityOrgCode: this.productAuthorityOrgCode
        // orgUnitCode:this.productForm.orgUnitCode
      };
      findEtProductListForWebQuickSearch(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.productNamesOptions = response.data.responseData;
            if (this.productNamesOptions) {
              if (this.productNamesOptions.length == 0) {
                this.$message.warning("未查询到对应的产品哦~");
                cb([]);
                return;
              }
              cb(this.productNamesOptions);
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
    },
    removeProductCode(val) {
      if (val != "") {
        return;
      }
      this.productForm.productCode = "";
      this.productForm.productName = "";
      this.productInfo.etProductServiceList = [];
      this.productForm.productOrderServiceList = [];
      this.productForm.productType = "";
      this.productForm.productOrderSpecificationList = [];
      this.productForm.productOrderPropertyList = [];
      this.productForm.marketPrice = "";
      this.productForm.sellPrice = "";
      this.$refs["serviceItemTable"].initSaveOrSelectTemplate(
        this.productForm.orgCode,
        this.productForm.productCode
      );
    },
    removeOrgCode(val) {
      if (val != "") {
        this.productForm.productNamesOptions = [];
        this.productAuthorityOrgCode = "";
        this.removeProductCode("");
      }
    },
    changeProductName(val) {
      if (this.isEditInfo && this.productForm.orgName == "") {
        this.$message.error("请先选择组织");
        return;
      }
      if (typeof val === "object") {
        //传入的是对象
        val = val.productCode;
      }
      let params = {
        productCode: val
      };
      this.productForm.productOrderSpecificationList = [];
      this.productForm.productOrderPropertyList = [];
      this.productForm.marketPrice = "";
      this.productForm.sellPrice = "";
      //先清除数据
      let timer = setInterval(() => {
        findProductByCodeForOrder(params)
          .then(response => {
            if (response.data.statusCode == "200") {
              this.productInfo = response.data.responseData;
              if (this.orderInfo && this.orderInfo.productCode == val) {
                this.productForm.productOrderServiceList = this.orderInfo.productOrderServiceList;
                this.productForm.marketPrice = this.orderInfo.marketPrice;
                this.productForm.sellPrice = this.orderInfo.sellPrice;
              } else {
                this.productForm.productOrderServiceList = [];
                this.productForm.marketPrice = "";
                this.productForm.sellPrice = "";
              }
              this.productForm.productCode = this.productInfo.productCode;
              this.productForm.productName = this.productInfo.productName;
              this.productForm.productType = this.productInfo.productType;
              this.productInfo.productSpecificationList.forEach(item => {
                var specValue = "";
                var specValueId = "";
                // item.specificationValueList.forEach(listItem=>{
                //   if(listItem.specificationName.indexOf("单次服务时长")!== -1 && listItem.specificationValue == "1"){
                //     specValue = listItem.specificationValue;
                //     specValueId = listItem.specificationValueId;
                //   }
                // })
                for (var i = 0; i < item.specificationValueList.length; i++) {
                  if (
                    item.specificationValueList[0].specificationName.indexOf(
                      "单次服务时长"
                    ) !== -1
                  ) {
                    specValue =
                      item.specificationValueList[0].specificationValue;
                    specValueId =
                      item.specificationValueList[0].specificationValueId;
                    break;
                  }
                }
                this.productForm.productOrderSpecificationList.push({
                  productCode: item.productCode,
                  specificationId: item.specificationId,
                  specificationName: item.specificationName,
                  specificationValue: specValue,
                  isChosen: "",
                  valueSort: 1,
                  specificationValueId: specValueId
                });
              });

              this.productInfo.productPropertyList.forEach(item => {
                this.productForm.productOrderPropertyList.push({
                  productCode: item.productCode,
                  propertyId: item.propertyId,
                  propertyName: item.propertyName,
                  propertyType: item.propertyType,
                  propertyValue: "",
                  valueSort: "",
                  propertyValueId: ""
                });
              });
              this.initOrderInfo();
              //设置服务项
              this.$refs["serviceItemTable"].initSaveOrSelectTemplate(
                this.productForm.orgCode,
                this.productForm.productCode
              );
              this.$emit("changeProductListener", this.productForm);
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          })
          .catch(error => {
            this.$message.error(this.ConstantData.requestErrorMsg);
          });
        clearInterval(timer);
      }, 100);
    },
    updateInfos() {
      if (this.isEditInfo) {
        //调用保存接口
        this.$refs["productForm"].validate(valid => {
          if (valid) {
            //各个产品中的“服务项”改为非必填。
            // if(this.productForm.productOrderServiceList.length==0){
            //   this.$message.error("请选择服务项");
            //   return;
            // }
            this.updateProduct();
            return;
          } else {
            this.$message.error("请检查是否填写完整");
            return;
          }
        });
      } else {
        this.isEditInfo = !this.isEditInfo;
      }
    },
    initOrderInfo() {
      if (this.orderInfo) {
        this.productForm.productOrderSpecificationList.forEach(item => {
          if (this.orderInfo.productOrderSpecificationList) {
            this.orderInfo.productOrderSpecificationList.forEach(
              orderSpecItem => {
                if (orderSpecItem.specificationId == item.specificationId) {
                  item.specificationValue = orderSpecItem.specificationValue;
                  item.specificationValueId =
                    orderSpecItem.specificationValueId;
                }
              }
            );
          }
        });

        this.productForm.productOrderPropertyList.forEach(item => {
          if (this.orderInfo.productOrderPropertyList) {
            for (
              var i = 0;
              i < this.orderInfo.productOrderPropertyList.length;
              i++
            ) {
              if (
                this.orderInfo.productOrderPropertyList[i].propertyId ==
                item.propertyId
              ) {
                item.propertyValue = this.orderInfo.productOrderPropertyList[
                  i
                ].propertyValue;
                item.propertyValueId = this.orderInfo.productOrderPropertyList[
                  i
                ].propertyValueId;
                break;
              }
            }
          }
        });
      }
    },
    updateProduct() {
      //组装请求参数
      this.orderInfo.productOrderPropertyList = this.productForm.productOrderPropertyList;
      this.orderInfo.productOrderSpecificationList = this.productForm.productOrderSpecificationList;
      this.orderInfo.productOrderServiceList = this.productForm.productOrderServiceList;
      this.orderInfo.productCode = this.productForm.productCode;
      this.orderInfo.productName = this.productForm.productName;
      this.orderInfo.orgName = this.productForm.orgName;
      this.orderInfo.orgCode = this.productForm.orgCode;
      this.orderInfo.marketPrice = this.productForm.marketPrice;
      this.orderInfo.sellPrice = this.productForm.sellPrice;
      this.orderInfo.productType = this.productForm.productType;
      updateOrderInfoForProduct(this.orderInfo)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.isEditInfo = !this.isEditInfo;
            this.$message.success("修改产品信息成功");
            this.$emit("savedProductInfoListener");
            if (response.data.responseData) {
              this.orderInfo.serviceFrequencyTypeValue =
                response.data.responseData.serviceFrequencyTypeValue;
              this.orderInfo.serviceFrequency =
                response.data.responseData.serviceFrequency;
            }
          } else {
            this.$message.error(
              response.data.statusMsg
                ? response.data.statusMsg
                : "修改产品信息失败"
            );
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    updateServiceItems() {
      //组装请求参数
      this.orderInfo.productOrderServiceList = this.productForm.productOrderServiceList;
      updateOrderInfoForProduct(this.orderInfo)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.isEditServiceItems = false;
            this.savedProduct = true;
            this.$message.success("保存服务项成功");
          } else {
            this.$message.error(
              response.data.statusMsg
                ? response.data.statusMsg
                : "保存服务项失败"
            );
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    //获取选择组织信息
    getCurrentNode(data) {
      this.productForm.orgName = data.orgName;
      this.productForm.orgCode = data.orgCode;
      // this.productForm.orgUnitCode = data.orgUnitCode;
      this.productForm.productCode = "";
      this.productForm.productName = "";
      this.getProductRight(); //根据组织机构查询产品列表
      // this.getOrgDetail();
      this.handleClose();
    },
    handleClose() {
      this.dialogVisible = false;
    },
    //开启组织选择弹窗
    openDialog() {
      this.dialogVisible = true;
    },
    //获取产品列表前先查询产品权限
    getProductRight() {
      getProductAuthorityCode({ orgCode: this.productForm.orgCode })
        .then(response => {
          if (response.data.statusCode == "200") {
            this.productAuthorityOrgCode = response.data.responseData;
            this.findProductNamesList();
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    onSpecChangeListener(val) {
      if (this.productForm.productType == "10") {
        return;
      }
      let params = {
        productCode: this.productForm.productCode,
        specificationIds: val.specificationIds,
        specificationValueIds: val.specificationValueIds
      };
      getProductPriceDetail(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            if (response.data.responseData) {
              this.productForm.marketPrice =
                response.data.responseData.marketPrice;
              this.productForm.sellPrice = response.data.responseData.sellPrice;
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    /**
     *
     * 返回订单管理列表
     *
     */ returnOrderList() {
      this.$router.push({
        path: "/businessServiceManagement/orderManagementList"
      });
    },
    saveServiceItems() {
      this.savedProduct = false;
      //各个产品中的“服务项”改为非必填。
      // if(this.productForm.productOrderServiceList.length==0){
      //     this.$message.error("请选择服务项");
      //     return;
      // }
      this.updateServiceItems();
    },
    updateSpecs() {
      //修改规格
      if (this.isEditInfo) {
        //调用保存接口
        this.$refs["productForm"].validate(valid => {
          if (valid) {
            var params = {
              productOrderSpecificationList: this.productForm
                .productOrderSpecificationList,
              productCode: this.productForm.productCode,
              orgCode: this.productForm.orgCode,
              productType: this.productForm.productType,
              orderCode: this.orderInfo.orderCode
            };
            editAssessGradeByOrderCode(params)
              .then(response => {
                if (response.data.statusCode == "200") {
                  this.isEditInfo = !this.isEditInfo;
                  if (response.data.responseData) {
                    this.orderInfo.serviceFrequencyTypeValue =
                      response.data.responseData.serviceFrequencyTypeValue;
                    this.orderInfo.serviceFrequency =
                      response.data.responseData.serviceFrequency;
                  }
                  this.$message.success("修改产品信息成功");
                } else {
                  this.$message.error(
                    response.data.statusMsg
                      ? response.data.statusMsg
                      : "修改产品信息失败"
                  );
                }
              })
              .catch(error => {
                this.$message.error(this.ConstantData.requestErrorMsg);
                return false;
              });
            return;
          } else {
            this.$message.error("请检查是否填写完整");
            return;
          }
        });
      } else {
        this.isEditInfo = !this.isEditInfo;
      }
    },
    isInserviceWithCHXOrder() {
      //服务中的长护险类型订单:返回true
      return (
        (this.orderInfo &&
          this.orderInfo.orderStatus === "20" &&
          this.orderInfo.productType === "10") == true
      );
    },
    isCHXOrder() {
      //长护险类型订单:返回true,
      return this.orderInfo.productType === "10";
    },
    canEdit() {
      if (this.orderInfo) {
        //修改
        if (this.isInserviceWithCHXOrder()) {
          //服务中的长护险类型订单不能编辑
          return false;
        }
        return this.isEditInfo == true;
      } else {
        //新增
        return true;
      }
    },
    getOrgDetail() {
      //根据组织code查询Form数据
      var params = {
        orgCode: this.productForm.orgCode
      };
      getEhrOrgDetailByCode(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.productForm.orgUnitCode =
              response.data.responseData.orgUnitCode;
            this.findProductNamesList();
          } else {
            this.$message.error(
              response.data.statusMsg
                ? response.data.statusMsg
                : "获取组织详细信息失败"
            );
          }
        })
        .catch(error => {
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    }
  },
  created() {
    if (!this.isEditInfo) {
      if (this.orderInfo) {
        this.productForm.isCopy =
          this.orderInfo.isCopy === undefined ? false : true;
        this.productForm.orgName = this.orderInfo.orgName;
        this.productForm.orgCode = this.orderInfo.orgCode;
        this.productForm.marketPrice = this.orderInfo.marketPrice;
        this.productForm.sellPrice = this.orderInfo.sellPrice;
        this.productForm.productType = this.orderInfo.productType;
        this.getProductRight();
        // this.getOrgDetail();
        this.productForm.productOrderServiceList = this.orderInfo.productOrderServiceList;
      }
    }
  },
  mounted() {
    this.productForm.orgCode = this.$store.getters.userOrgCode;
    this.productForm.orgName = this.$store.getters.userOrgName;
    if (this.orderInfo) {
      this.productForm.productCode = this.orderInfo.productCode;
      this.productForm.orgName = this.orderInfo.orgName;
      this.productForm.orgCode = this.orderInfo.orgCode;
      this.productForm.marketPrice = this.orderInfo.marketPrice;
      this.productForm.sellPrice = this.orderInfo.sellPrice;
      this.productForm.productType = this.orderInfo.productType;
      this.changeProductName(this.orderInfo.productCode); //获取产品信息
    } else {
      if (this.productForm.orgCode) {
        this.getProductRight();
        // this.getOrgDetail();
      }
    }
    this.isEditInfo = this.isEdit;
    this.isEditServiceItems = this.isEdit;
  }
};
</script>
<style lang="scss" scoped>
.el-select {
  max-width: 200px;
  min-width: 100px;
}
.el-input {
  max-width: 200px;
  min-width: 100px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
  background-color: #f9f9f9;
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.form-item {
  width: 30%;
  min-width: 470px;
  padding-bottom: 5px;
  max-height: 50px;
}
.form-item-product {
  width: 100%;
}
.radioRight {
  margin-right: 10px;
}
.productForm {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin-top: 10px;
}
</style>
