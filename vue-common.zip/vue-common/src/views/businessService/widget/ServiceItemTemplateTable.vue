<!--服务项模板-->
<template>
  <div class="template-content">
      <el-row>
        <el-col>
          <div class="main-content">
            <el-row style="margin-top:10px;margin-bottom:10px;">
              <el-row type="flex">
                <span style="width:75px;margin-top:5px">模板名称：</span>
                <el-input placeholder="请输入模板名称搜索" v-model="searchInputValue" @input="searchTemplate" size="mini">
                  <el-button slot="prepend" icon="el-icon-search"></el-button>
                </el-input>
                <el-button type="primary" @click="searchTemplate" size="mini" style="margin-left:10px">查询</el-button>
              </el-row>
            <el-table
              :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266',padding:'3px',textAlign:'center'}"
              :data="tableData"
              style="width: 100%; margin-top: 20px"
              max-height="550"
              @row-dblclick="selectTemplateClick"
              ref="filterTable"
              stripe
              v-loading="listLoading"
            >
              <el-table-column prop="templateName" label="模板名称" width="150" align="center"></el-table-column>
              <el-table-column prop="templateContent" label="模板内容" width="400" align="align">
                <template slot-scope="scope">
                    <div v-for="(item,index) in scope.row.productServiceTemplateItems" :key="index">
                      <el-row type="flex" style="width:400px">
                        <div style="width:200px;text-align:left">{{productType=='10'?item.serviceCode:''}}{{item.serviceItem}}</div>
                        <div style="width:100px;text-align:right">{{item.serviceFrequency}}（次）</div>
                        <div style="width:100px;text-align:right;padding-right:10px">{{item.serviceDuration}}（{{item.serviceDurationUnit}}）</div>
                      </el-row>
                    </div>
                  </template>
                <!-- <el-table-column prop="serviceItem" label="服务项" min-width="80">
                  <template slot-scope="scope">
                    <span>{{scope.row.serviceCode+scope.row.serviceItem}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="serviceFrequency" label="服务总次数(次)" min-width="100" style="background-color:red">
                </el-table-column>
                <el-table-column prop="serviceDuration" :label="getTotalServiceDuration()" min-width="100">
                </el-table-column>   -->
              </el-table-column>
               <el-table-column prop="options" label="操作"  width="100" align="center">
                <template slot-scope="scope">
                  <el-button size="mini" type="text" @click="selectTemplate(scope.row)">选择</el-button>
                  <el-button size="mini" type="text" @click="deleteTemplate(scope.row)">删除</el-button>
                </template>
              </el-table-column>
            </el-table>
            </el-row>
          </div>
        </el-col>
      </el-row>
  </div>
</template>

<script>
import {
  findProductServiceTemplate,//查询
  deleteProductServiceTemplate//修改
} from "api/orderManagement";
export default {
  props: {
    selectedServiceItemList: {
      //已选服务项
      type: Array,
      default: function(){
        return [];
      }
    },
    productCode:{
      type:String,
      default:""
    },
    orgCode:{
      type:String,
      default:""
    },
    productType:{
      type:String,
      default:""
    }
  },
  components: {
  },
  data() {
    return {
      searchInputValue: "",
      templateList: [],
      templateSpanArr: [],
      tableData:[],
      serviceDurationUnit:"分钟",
      selectedTemplateList:[],
      listLoading:true
    };
  },
  methods: {
    sortCompare(){
      var compare = function (obj1, obj2) {
          var val1 = obj1.templateName;
          var val2 = obj2.templateName;
          if (val1 < val2) {
              return -1;
          } else if (val1 > val2) {
              return 1;
          } else {
              return 0;
          }            
        } 
        return compare;
    },
    deleteTemplate(item) {
      this.$confirm('是否确定删除当前模板?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          var params = {
          id:item.id
        }
      deleteProductServiceTemplate(params)
        .then(response => {
          this.listLoading = false;
          if (response.data.statusCode == "200") {
            this.$message.success("删除成功~")
            this.findProductServiceTemplate()
          } else {
            this.$message.error(response.data.statusMsg?response.data.statusMsg:"删除服务项模板失败");
          }
        })
        .catch(error => {
          this.listLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          });          
        });
      var obj = this.templateList.find(templateItem =>{
        return templateItem.templateName == item.templateName
      })
      if(obj){
        this.$set(obj,"isSelected",false)
      }
      this.templateList.splice(index,1);
      this.templateList.sort(this.sortCompare());
    },
    dealData() {
      this.tableData =[];
      this.tableData = this.templateList;
      this.updateServiceItems();
    },
    indexMethod(index) {
      return index;
    },
    setTemplateSpanArr() {
      this.templateSpanArr = []
      for (var i = 0; i < this.tableData.length; i++) {
        if (i === 0) {
          this.templateSpanArr.push(1);
          this.pos = 0;
        } else {
          // 判断当前元素与上一个元素是否相同
          if (
            this.tableData[i].templateName ===
            this.tableData[i - 1].templateName
          ) {
            this.templateSpanArr[this.pos] += 1;
            this.templateSpanArr.push(0);
          } else {
            this.templateSpanArr.push(1);
            this.pos = i;
          }
        }
      }
    },
    templateCellMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0||columnIndex == 4) {
        const _row = this.templateSpanArr[rowIndex];
        const _col = _row > 0 ? 1 : 0;
        return {
          rowspan: _row,
          colspan: _col
        };
      }
    },
    selectTemplateClick(val){
        for(var i =0;i<this.templateList.length;i++){
          if(this.templateList[i].serviceCode == val.serviceCode
          &&!this.templateList[i].isSelected){
            this.$set(this.templateList[i],"isSelected",true)
            val = JSON.parse(JSON.stringify(val));
            //清空次数与时长
            val.serviceDuration = "";
            val.serviceFrequency = "";
            val.serviceDurationUnit = "小时"
            this.selectedTemplateList.push(val)
            break;
          }
        }
    },
    updateServiceItems(){
      
    },
    setCellstyle(val){
      if(val.row.isSelected && (val.column.property == 'serviceDuration' ||
       val.column.property == 'serviceItem' ||
       val.column.property == 'frequency')){
        // return 'background-color:#398AF1;color:white'
        return 'background-color:white;color:#666666'
      }else{
        if(val.column.property =='templateName'){
          return 'background-color:white;color:#666666'
        }
        return 'background-color:white;color:#666666;cursor:pointer'
      }
},
    searchTemplate(){
       this.findProductServiceTemplate(); 
    },
    createFilter1(a) {
        return (tableData) => {
    //这里有一个坑，你如果更改value属性名称代码不报错，结果将无法筛选，永远为空，尝试了多次没有成功，用原生处理筛选，直接赋值cb的参数都不行，一定要属性值为value
          let v = false;
          if(tableData.templateName.indexOf(a) != -1){
          	v = true;
          }
          return v;
        };
      },
      getTotalServiceDuration(){
        return "服务总时长(小时)";
      },
      getServiceDurationUnit(){
        return "服务时长("+this.serviceDurationUnit+")"
      },
      selectTemplate(val){
        this.$confirm('是否确定选择当前模板?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$emit("selectedTemplageListener",val.productServiceTemplateItems);
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          });          
        });
      },
      findProductServiceTemplate(){
        this.listLoading = true;
        var params = {
          productCode:this.productCode,
          orgCode:this.orgCode,
          templateName:this.searchInputValue,
        }
        findProductServiceTemplate(params)
        .then(response => {
          this.listLoading = false;
          if (response.data.statusCode == "200") {
            this.templateList = response.data.responseData;
            this.dealData();
          } else {
            this.$message.error(response.data.statusMsg?response.data.statusMsg:"查询服务项模板失败");
          }
        })
        .catch(error => {
          this.listLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
      },
  },
  mounted() {
  },
  created() {
    this.findProductServiceTemplate();
  },
  activated(){
  }
};
</script>

<style lang="scss" scoped>
.main-content {
  background: #fff;
  padding: 0px 20px 20px 20px;
  height: 600px;
}
.el-table-empty-block{
  height: 410px;
}
.line-style {
  height: 1px;
  background: #F3F3F3;
}
.form-tag {
    font-size: 16px;
    padding-left: 10px;
    font-weight: 550;
  }
.template-content{
  margin-left: -20px;
  margin-right:-20px;
}
  .importToolbar {
  padding: 10px;
  .form-tag {
    font-size: 16px;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
  background-color: #f9f9f9
}
.el-input{
  width: 260px;
}
.el-dialog{
  padding: 10px;
}
</style>