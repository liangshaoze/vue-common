<template>
  <div class="productForm">
    <el-row class="importToolbar">
      <span class="form-tag">服务项</span>
      <!--服务项：除了“服务完成”、“服务关闭”状态以外，其他状态都能进行修改；-->
      <el-button
        type="primary"
        size="mini"
        style="float:right"
        @click="changeServiceItems"
        v-if="isEditServiceItem == false && showEditBtn()"
      >修改</el-button>
      <el-button
        v-if="isSaveServiceItem &&showEditBtn()"
        type="primary"
        size="mini"
        style="float:right"
        @click="saveServiceItems"
      >保存</el-button>
    </el-row>

    <!-- <el-form-item label="服务项" :rules="[{required: true, message: '服务项不能为空'}]"> -->
    <div v-if="isEditServiceItem == false" style="padding:10px 10px 10px 0px;">
      <div style="font-size:14px;line-height:25px;" v-if="serviceItems">
        <!-- <el-row v-for="item in serviceItems.split(',#')" :key="item" type="flex" justify="space-arround">
        <div style="font-style:bold;width:200px">{{item.split(':')[0]}}:</div><div> {{item.split(':')[1]}}</div>
        </el-row>-->
        <el-form>
          <el-form-item
            class="service-item-form-item"
            v-for="item in serviceItems.split(',#')"
            :key="item"
            :label="item.split(':')[0]"
            label-width="200px"
          >
            <div class="long-field">{{item.split(':')[1]}}</div>
          </el-form-item>
        </el-form>
      </div>
      <div
        style="font-size:14px;line-height:25px;color:#999;margin-left:50px"
        v-if="!serviceItems"
      >{{"暂无服务项"}}</div>
    </div>
    <el-row v-if="isEditServiceItem == true" :gutter="20" style="margin-top:10px;padding:10px;">
      <el-col :span="12">
        <div class="main-content">
          <el-row style="margin-top:10px;margin-bottom:10px;">
            <el-button @click="selectAll" type="primary" size="mini" style="float:right">全选</el-button>
            <span>
              选择服务项(
              <span style="color:red">*请单击选择服务项</span>)
            </span>
          </el-row>
          <div style="line-style"></div>
          <el-input placeholder="请输入服务项" v-model="searchInputValue" @input="searchService">
            <el-button slot="prepend" icon="el-icon-search"></el-button>
          </el-input>
          <el-table
            :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266',padding:'3px'}"
            :cell-style="setCellstyle"
            :data="tableData"
            :span-method="unselectCellMerge"
            border
            style="width: 100%; margin-top: 20px"
            max-height="350"
            @row-click="selectServiceClick"
            ref="filterTable"
          >
            <el-table-column prop="serviceClass" label="分类" min-width="60"></el-table-column>
            <el-table-column prop="serviceItem" label="服务项" min-width="80">
              <template slot-scope="scope">
                <span>{{productType=='10'?scope.row.serviceCode:''}}{{scope.row.serviceItem}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="frequency" label="频次" min-width="60"></el-table-column>
            <el-table-column
              prop="serviceDuration"
              :label="getServiceDurationUnit()"
              min-width="60"
            ></el-table-column>
            <el-table-column prop="serviceUnitPrice" label="服务单价（元）" min-width="60"></el-table-column>
          </el-table>
        </div>
      </el-col>
      <el-col :span="12">
        <div class="main-content">
          <el-row style="margin-top:10px;margin-bottom:10px" type="flex">
            <el-col :span="20">
              <span>已选服务项</span>
            </el-col>
            <el-button @click="deleteAll" type="primary" size="mini">全部删除</el-button>
            <el-button
              @click="toSaveTemplate"
              v-show="canSaveOrSelectTemplate"
              style="margin-left:10px"
              type="primary"
              size="mini"
            >保存模板</el-button>
            <el-button
              v-show="canSaveOrSelectTemplate"
              @click="dialogSelectTemplateVisible=true"
              style="margin-left:10px"
              type="primary"
              size="mini"
            >选择模板</el-button>
          </el-row>
          <div style="line-style"></div>
          <el-table
            :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266',padding:'3px'}"
            :data="productOrderServiceList"
            border
            style="width: 100%; margin-top: 10px"
            max-height="400"
          >
            <el-table-column label="序号" type="index" show-overflow-tooltip width="60"></el-table-column>
            <el-table-column prop="serviceItem" label="服务项" min-width="100">
              <template slot-scope="scope">
                <span>{{productType=='10'?scope.row.serviceCode:''}}{{scope.row.serviceItem}}</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="serviceFrequency"
              label="服务总次数(次)"
              min-width="100"
              style="background-color:red"
            >
              <template slot-scope="scope">
                <el-input
                  placeholder="请输入次数"
                  type="primary"
                  size="mini"
                  v-model="scope.row.serviceFrequency"
                  @input="setTotalTimeAndPrice()"
                ></el-input>
              </template>
            </el-table-column>
            <el-table-column
              prop="serviceDuration"
              :label="getTotalServiceDuration()"
              min-width="100"
            >
              <template slot-scope="scope">
                <el-input
                  placeholder="请输入小时"
                  type="primary"
                  size="mini"
                  v-model="scope.row.serviceDuration"
                  @input="setTotalServiceTime(scope.row)"
                ></el-input>
              </template>
            </el-table-column>
            <el-table-column label="操作" fixed="right" min-width="50">
              <template slot-scope="scope">
                <el-button size="mini" type="text" @click="deleteService(scope.$index,scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div
            style="float:right;color:#333;padding:10px"
          >总服务时长：{{totalServiceTime}}小时、总服务价格：{{totalPrice}}元</div>
        </div>
      </el-col>
    </el-row>
    <!-- </el-form-item> -->
    <el-dialog
      ref="selectDialog"
      title="选择模板"
      :visible.sync="dialogSelectTemplateVisible"
      :before-close="handleClose"
      width="700px"
    >
      <ServiceItemTemplateTable
        :selectedServiceItemList="productOrderServiceList"
        @selectedTemplageListener="selectedTemplageListener"
        :productCode="productCode"
        :orgCode="orgCode"
        :productType="productType"
        v-if="dialogSelectTemplateVisible"
      />
    </el-dialog>
    <el-dialog
      title="保存模板"
      :visible.sync="dialogSaveTemplateVisible"
      :before-close="handleClose"
      width="350px"
      center
    >
      <el-row type="flex" justify="center" v-if="dialogSaveTemplateVisible">
        <span style="width:80px;margin-top:5px">模板名称</span>
        <el-input
          placeholder="请输入模板名称"
          type="primary"
          size="mini"
          v-model="inputTemplateName"
          clearable
        ></el-input>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="handleClose">取消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="saveTemplateName"
          :disabled="disabledSave"
        >确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import ServiceItemTemplateTable from "@/views/businessService/widget/ServiceItemTemplateTable";
import {
  insertProductServiceTemplate //保存
} from "api/orderManagement";
export default {
  props: {
    isEdit: {
      type: Boolean,
      default: false
    },
    etProductServiceList: {
      //未选服务项
      type: Array,
      default: []
    },
    productOrderServiceList: {
      //已选服务项
      type: Array,
      default: []
    },
    savedProduct: {
      type: Boolean,
      default: false
    },
    orderStatus: {
      type: String,
      default: ""
    },
    productType: {
      type: String,
      default: ""
    }
  },
  components: {
    ServiceItemTemplateTable
  },
  data() {
    return {
      rowIndexList: [],
      searchInputValue: "",
      unselectServiceList: [],
      unselectSpanArr: [],
      selectedSpanArr: [],
      serviceCount: "",
      serviceItems: "", //服务项
      searchedServiceList: [], //搜索
      tableData: [],
      serviceDurationUnit: "分钟",
      isEditServiceItem: false,
      isSaveServiceItem: false,
      dialogSelectTemplateVisible: false,
      dialogSaveTemplateVisible: false,
      inputTemplateName: "",
      productCode: "",
      orgCode: "",
      canSaveOrSelectTemplate: false,
      disabledSave: false,
      totalServiceTime: 0,
      totalPrice: 0
    };
  },
  methods: {
    sortCompare() {
      var compare = function(obj1, obj2) {
        var val1 = parseInt(obj1.serviceCode);
        var val2 = parseInt(obj2.serviceCode);
        if (val1 < val2) {
          return -1;
        } else if (val1 > val2) {
          return 1;
        } else {
          return 0;
        }
      };
      return compare;
    },
    deleteService(index, item) {
      var obj = this.unselectServiceList.find(unSelectItem => {
        return unSelectItem.serviceItem == item.serviceItem;
      });
      if (obj) {
        this.$set(obj, "isSelected", false);
      }
      this.unselectServiceList.sort(this.sortCompare());
      this.productOrderServiceList.splice(index, 1);
      this.setTotalTimeAndPrice();
    },
    dealData() {
      this.unselectServiceList = [];
      this.tableData = [];
      //组装数据
      this.etProductServiceList.forEach(item => {
        item.childrenProductList.forEach(child => {
          if (child.serviceDurationUnit) {
            this.serviceDurationUnit = child.serviceDurationUnit;
          }
          this.unselectServiceList.push(child);
          let frequency = child.serviceFrequency
            ? child.serviceFrequency + "/" + child.serviceFrequencyUnit
            : "";
          this.$set(child, "frequency", frequency);
          this.tableData.push(child);
        });
      });
      this.unselectServiceList.sort(this.sortCompare());
      this.setUnselectSpanArr();
      this.updateServiceItems();
    },
    indexMethod(index) {
      return index;
    },
    setUnselectSpanArr() {
      this.unselectSpanArr = [];
      for (var i = 0; i < this.tableData.length; i++) {
        if (i === 0) {
          this.unselectSpanArr.push(1);
          this.pos = 0;
        } else {
          // 判断当前元素与上一个元素是否相同
          if (
            this.tableData[i].serviceClass ===
            this.tableData[i - 1].serviceClass
          ) {
            this.unselectSpanArr[this.pos] += 1;
            this.unselectSpanArr.push(0);
          } else {
            this.unselectSpanArr.push(1);
            this.pos = i;
          }
        }
      }
    },
    unselectCellMerge({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        const _row = this.unselectSpanArr[rowIndex];
        const _col = _row > 0 ? 1 : 0;
        return {
          rowspan: _row,
          colspan: _col
        };
      }
    },
    selectServiceClick(val) {
      for (var i = 0; i < this.unselectServiceList.length; i++) {
        if (
          this.unselectServiceList[i].serviceCode == val.serviceCode &&
          !this.unselectServiceList[i].isSelected
        ) {
          this.$set(this.unselectServiceList[i], "isSelected", true);
          val = JSON.parse(JSON.stringify(val));
          //清空次数与时长
          val.serviceDuration = "";
          val.serviceFrequency = "1";
          val.serviceDurationUnit = "小时";
          this.productOrderServiceList.push(val);
          break;
        }
      }
      this.productOrderServiceList.sort(this.sortCompare());
      this.setTotalTimeAndPrice();
    },
    updateServiceItems() {
      this.serviceItems = "";
      var serviceClassList = Array.from(
        new Set(
          this.productOrderServiceList.map(item => {
            return item.serviceClass;
          })
        )
      );
      serviceClassList.sort();
      serviceClassList.forEach((serviceClass, index) => {
        this.serviceItems += serviceClass + ":";
        //拼接服务项
        for (var i = 0; i < this.productOrderServiceList.length; i++) {
          if (serviceClass == this.productOrderServiceList[i].serviceClass) {
            this.serviceItems +=
              (this.productType == "10" ? this.productOrderServiceList[i].serviceCode : "") +
              this.productOrderServiceList[i].serviceItem +",";
          }
        }
        this.serviceItems += index != serviceClassList.length - 1 ? "#" : "";
      });
      this.serviceItems = this.serviceItems.substring(0,this.serviceItems.length - 1);
      this.unselectServiceList.forEach(item => {
        this.$set(item, "isSelected", false);
      });
      //已选颜色处理
      this.productOrderServiceList.forEach(item => {
        var obj = this.unselectServiceList.find(unselectItem => {
          return item.serviceItem == unselectItem.serviceItem;
        });
        if (obj) {
          this.$set(obj, "isSelected", true);
        }
      });
      this.setTotalTimeAndPrice();
    },
    selectAll() {
      this.productOrderServiceList.splice(0);
      for (var i = 0; i < this.unselectServiceList.length; i++) {
        this.$set(this.unselectServiceList[i], "isSelected", true);
        let val = JSON.parse(JSON.stringify(this.unselectServiceList[i]));
        //清空次数与时长
        val.serviceDuration = "";
        val.serviceFrequency = "1";
        val.serviceDurationUnit = "小时";
        this.productOrderServiceList.push(val);
      }
      this.setTotalTimeAndPrice();
    },
    deleteAll() {
      for (var i = this.productOrderServiceList.length - 1; i >= 0; i--) {
        this.productOrderServiceList.splice(i, 1);
      }
      this.unselectServiceList.forEach(item => {
        this.$set(item, "isSelected", false);
      });
      this.setTotalTimeAndPrice();
    },
    setCellstyle(val) {
      if (val.row.isSelected && val.column.property != "serviceClass") {
        return "background-color:#398AF1;color:white";
      } else {
        if (val.column.property == "serviceClass") {
          return "background-color:white;color:#666666";
        }
        return "background-color:white;color:#666666;cursor:pointer";
      }
    },
    searchService() {
      this.unselectServiceList.forEach(item => {
        if (item.serviceItem.indexOf(this.searchInputValue) != -1) {
          this.$set(item, "isSearched", true);
        } else {
          this.$set(item, "isSearched", false);
        }
      });
      if (this.searchInputValue !== "") {
        var filterData = this.unselectServiceList.filter(
          this.createFilter1(this.searchInputValue.trim())
        );
        this.tableData = filterData;
        this.tableData.sort(this.sortCompare());
        this.setUnselectSpanArr();
      } else {
        this.tableData = this.unselectServiceList;
        this.tableData.sort(this.sortCompare());
        this.setUnselectSpanArr();
      }
    },
    createFilter1(a) {
      return tableData => {
        //这里有一个坑，你如果更改value属性名称代码不报错，结果将无法筛选，永远为空，尝试了多次没有成功，用原生处理筛选，直接赋值cb的参数都不行，一定要属性值为value
        let v = false;
        if (
          tableData.serviceItem.indexOf(a) != -1 ||
          tableData.serviceCode == a ||
          (a.indexOf(tableData.serviceCode) != -1 &&
            (tableData.serviceCode + tableData.serviceItem).indexOf(a) != -1)
        ) {
          v = true;
        }
        return v;
      };
    },
    getTotalServiceDuration() {
      return "服务总时长(小时)";
    },
    getServiceDurationUnit() {
      return "服务时长(" + this.serviceDurationUnit + ")";
    },
    changeServiceItems() {
      this.isEditServiceItem = !this.isEditServiceItem;
      this.isSaveServiceItem = true;
    },
    saveServiceItems() {
      this.$emit("saveServiceItems");
    },
    showEditBtn() {
      return (
        this.orderStatus == "" ||
        this.orderStatus == "10" ||
        this.orderStatus == "20"
      );
    },
    handleClose() {
      this.dialogSelectTemplateVisible = false;
      this.dialogSaveTemplateVisible = false;
      this.inputTemplateName = "";
    },
    toSaveTemplate() {
      if (
        !this.productOrderServiceList ||
        this.productOrderServiceList.length == 0
      ) {
        this.$message.error("已选服务项不能为空");
        return;
      }
      this.dialogSaveTemplateVisible = true;
    },
    saveTemplateName() {
      if (this.inputTemplateName == "") {
        this.$message.error("模板名称不能为空");
        return;
      }
      this.disabledSave = true;
      var params = {
        productCode: this.productCode,
        orgCode: this.orgCode,
        templateName: this.inputTemplateName,
        productServiceTemplateItems: this.productOrderServiceList
      };
      insertProductServiceTemplate(params)
        .then(response => {
          this.disabledSave = false;
          if (response.data.statusCode == "200") {
            this.$message.success("保存服务项模板成功");
            this.handleClose();
          } else {
            this.$message.error(
              response.data.statusMsg
                ? response.data.statusMsg
                : "保存服务项模板失败"
            );
          }
        })
        .catch(error => {
          this.disabledSave = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
          return false;
        });
    },
    selectedTemplageListener(templateList) {
      this.productOrderServiceList.splice(0);
      templateList.forEach(item => {
        this.productOrderServiceList.push(item);
      });
      this.dialogSelectTemplateVisible = false;
      this.setTotalTimeAndPrice();
    },
    initSaveOrSelectTemplate(orgCode, productCode) {
      if (!orgCode || orgCode == "" || !productCode || productCode == "") {
        this.canSaveOrSelectTemplate = false;
      } else {
        this.canSaveOrSelectTemplate = true;
        this.orgCode = orgCode;
        this.productCode = productCode;
      }
    },
    setTotalServiceTime(serviceItem) {
      serviceItem.serviceDuration = serviceItem.serviceDuration.replace(
        /[^\d.]/g,
        ""
      );
      this.totalServiceTime = 0;
      this.productOrderServiceList.forEach(item => {
        if (item.serviceDuration) {
          this.totalServiceTime += parseFloat(item.serviceDuration);
        }
      });
      this.totalServiceTime = this.totalServiceTime.toFixed(2);
    },
    setTotalTimeAndPrice() {
      this.totalPrice = 0;
      this.totalServiceTime = 0;
      this.productOrderServiceList.forEach(item => {
        if (item.serviceUnitPrice) {
          item.serviceFrequency = item.serviceFrequency.replace(/[^\d.]/g, "");
          this.totalPrice +=
            parseFloat(item.serviceUnitPrice) *
            (item.serviceFrequency ? parseInt(item.serviceFrequency) : 0);
        }
        if (item.serviceDuration) {
          this.totalServiceTime += parseFloat(item.serviceDuration);
        }
      });
      this.totalPrice = this.totalPrice.toFixed(2);
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.isEditServiceItem = this.isEdit;
      this.dealData();
    });
  },
  created() {
    this.$watch("etProductServiceList", function() {
      this.dealData();
    });
    this.$watch("productOrderServiceList", function() {
      this.updateServiceItems();
    });
    this.$watch("savedProduct", function() {
      this.isEditServiceItem = this.isEdit;
      this.isSaveServiceItem = false;
    });
  }
};
</script>

<style lang="scss" scoped>
.main-content {
  border-radius: 10px;
  background: #fff;
  padding: 0px 20px 20px 20px;
  border-style: solid;
  border-color: #f3f3f3;
  border-width: 1px;
  height: 480px;
}
.el-table-empty-block {
  height: 410px;
}
.line-style {
  height: 1px;
  background: #f3f3f3;
}
.form-tag {
  font-size: 16px;
  border-left: 5px solid #f98c3c;
  padding-left: 10px;
  border-left: 5px solid #f98c3c;
  font-weight: 550;
}
.productForm {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin-top: 10px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
  background-color: #f9f9f9;
}
.service-item-form-item {
  margin: 0px;
}
</style>