<template>
  <div>
    <div>
    <el-row id="tableHeader" type="flex" style="overflow:hidden">
        <div  v-for="index in isWeekDay?7:32" :key="index">
          <ul class="header">
            <li class="headerItem">
              {{getTableHeadLableName(index)}}
            </li>
          </ul>
        </div>
    </el-row>
    <el-row id="tableRow" type="flex" style="overflow:scroll;height:576px" v-if="staffScheduleData&&staffScheduleData.length>0">
      <div  style="display:inline-block" v-for="index in isWeekDay?7:31" :key="index">
          <ul class="cellList" style="display:inline-block">
                <li v-for="(item,childIndex) in staffScheduleData[index-1]" :key="childIndex">
                  <div v-if="!item.planStartTime" :style="getEmptyItemStyle(item,childIndex)">
                  </div>
                  <el-popover
                        v-if="item.planStartTime"
                        placement="right-start"
                        trigger="click"
                        width="300"
                        @show="queryCarePerson(item)"
                        @hide="clearCarePerson"
                        v-model="item.showPop"
                    >
                        <!-- <Loading v-if="loadingOfPopover"/> -->
                        <div v-if="!loadingOfPopover" style="min-height:60px">
                          <div style="color:#333333;font-size:18px;margin-top:5px">
                              <span>{{careReceiverDetail.careReceiverName}}</span>
                              <span style="margin-left:10px;color:#666666">{{careReceiverDetail.careReceiverTel}}</span>
                          </div>
                          <el-row style="color:#666;font-size:16px;margin-top:15px;display:flex" v-if="careReceiverDetail.serviceItems">
                             <el-col style="width:70px">服务项:</el-col> <el-col>{{careReceiverDetail.serviceItems}}</el-col>
                          </el-row>
                          <div style="color:#999999;font-size:16px;margin-top:15px">
                              {{careReceiverDetail.liveDetailAddress}}
                          </div>
                        </div>
                         <div v-if="item.planStartTime" :style="getItemStyle(item,childIndex)" slot="reference">
                            <div>{{item.careReceiverName}}</div>
                            <div style="margin-top:6px;color:#ed9c62;">{{item.planStartTime+"~"+item.planEndTime}}</div>
                        </div>
                    </el-popover>
                </li>
                
            </ul>
        </div>
    </el-row>
    <div v-if="loadingOfTable" style="text-align:center;margin-top:100px">
      <div>
        <span>加载中...</span>
     <!-- <Loading/> -->
      </div>
    </div>
     <div v-if="!loadingOfTable&&staffScheduleData&&staffScheduleData.length==0" style="text-align:center;margin-top:100px" >
      <span>暂无数据</span>
    </div>
    
    </div>
  </div>
</template>
<script>
import {findWorkorderScheduleByCareGiverCode,getEtCareReceiver} from "@/api/businessService/workOrderSchedule";//查询员工排程
import Loading from "@/components/Loading"
// 引入ag-grid-vue
import { AgGridVue } from 'ag-grid-vue';
import { getWorkorderDetail } from "api/workOrderManagement";
 export default {
  props: {
    isWeekDay: {
      type: Boolean,
      default: true
    },
    staffCode:{
        type:String,
        default:""
    }
  },
  components:{
    Loading,
    AgGridVue,
  },
  beforeMount(){
  },

  data() {
    return {
      loadingOfPopover:true,
      careReceiverDetail:{},
      dialogCustomerInfo:false,
      gridOptions:null,
      staffScheduleData: [],
      columnDefs: [],
      rowData: [],
      loadingOfTable:false,
      showPopItem:{
        showPop:false
      }

    };
  },
  methods: {
    getTableHeadLableName(index) {
      if (this.isWeekDay) {
        if (index == 1) {
          return "周一";
        } else if (index == 2) {
          return "周二";
        } else if (index == 3) {
          return "周三";
        } else if (index == 4) {
          return "周四";
        } else if (index == 5) {
          return "周五";
        } else if (index == 6) {
          return "周六";
        } else if (index == 7) {
          return "周日";
        }
      } else {
        let dayName = "";
        let currentDate = new Date();
        currentDate.setDate(currentDate.getDate()+(index-1));
        var weekDay = currentDate.getDay();
        var weekDayStr = ""
        if (weekDay == 0) {
          weekDayStr =  "周日";
        } else if (weekDay == 1) {
          weekDayStr = "周一";
        } else if (weekDay == 2) {
          weekDayStr = "周二";
        } else if (weekDay == 3) {
          weekDayStr = "周三";
        } else if (weekDay == 4) {
          weekDayStr = "周四";
        } else if (weekDay == 5) {
          weekDayStr = "周五";
        } else if (weekDay == 6) {
          weekDayStr = "周六";
        }
        return ""+(currentDate.getMonth()+1)+"/"+currentDate.getDate()+weekDayStr;
      }
    },
    changeStrToMinutes(str) {
      if(!str){
        return 0;
      }
      var arrminutes = str.split(":");
      if (arrminutes.length == 2) {
        var minutes = parseInt(arrminutes[0]) * 60 + parseInt(arrminutes[1]);
        return minutes;
      } else {
        return 0;
      }
    },
    tableScrollEvent(){
      var timer = setInterval(()=>{
        var tableScroller = document.getElementById("tableRow");
        var tableHealderScroller = document.getElementById("tableHeader");
        if(tableScroller){
          tableScroller.addEventListener("scroll",()=>{
            var scrollTop = tableScroller.scrollTop;
            var scrollLeft = tableScroller.scrollLeft;
            tableHealderScroller.scrollLeft = scrollLeft;
            this.$emit("onTableScroll",scrollTop);
            if(this.showPopItem){
               this.showPopItem.showPop = false;
            }
          })
        }
      },1000)
    },
    resetScroll(){
       var tableScroller = document.getElementById("tableRow");
       var tableHealderScroller = document.getElementById("tableHeader");
       if(tableScroller){
         tableScroller.scrollTop = 5*45;
         tableScroller.scrollLeft = 0;
         this.$emit("onTableScroll",tableScroller.scrollTop);
       }
       if(tableHealderScroller){
         tableHealderScroller.scrollLeft= 0;
       }
       this.$forceUpdate()
    },
    getDayStringByIndex(index){
      //组装成2020-01-20 形式
      let date = new Date();
      date.setDate(date.getDate()+(index-1));
      let month = date.getMonth()+1;
      month = month<10?("0"+month):month;
      let day = date.getDate();
      day = day<10?("0"+date.getDate()):date.getDate();
      let result = date.getFullYear()+"-"+month+"-"+day;
      return result;
    }
    ,
    queryWorkorderScheduleByCareGiverCode(){
      let params={
        careGiverCode:this.staffCode,//员工代码
      }
      findWorkorderScheduleByCareGiverCode(params).then(response=>{
        if (response.data.statusCode == "200") {
            if (response.data.responseData) {
                this.staffScheduleData =[];
                this.customerList = response.data.responseData;
                if(this.customerList.length>0){
                  this.calculatData2(this.isWeekDay)
                }else{
                  this.loadingOfTable =false;
                }
                this.$emit("gotScheduleListener",this.customerList && this.customerList.length == 0,this.staffCode)
            }
          } else {
            this.loadingOfTable =false;
            this.$message.error(reponse.data.statusMsg);
          }

      }).catch(error=>{
        this.loadingOfTable =false;
         this.$message.error(this.ConstantData.requestErrorMsg);
      });
    },
    queryCarePerson(item){
      this.showPopItem =item;
      this.$set(item,'showPop',true);
      this.loadingOfPopover = true;
      // var params={careReceiverCode:item.careReceiverCode}
      // getEtCareReceiver(params).then(response =>{
      //   this.loadingOfPopover = false;
      //      if (response.data.statusCode == "200") {
      //       if (response.data.responseData) {
      //          this.careReceiverDetail = response.data.responseData;
      //       }
      //     } else {
      //       this.$message.error(reponse.data.statusMsg);
      //     }
      // }).catch(error=>{
      //   this.loadingOfPopover = false;
      //   console.log(error)
      //   this.$message.error(this.ConstantData.requestErrorMsg);
      // })
      //非今天未来工单，今天未完成工单
      var params={}
      var date=new Date()
      var today=date.getFullYear()+"-"+((date.getMonth()+1)<9?("0"+(date.getMonth()+1)):(date.getMonth()+1))+"-"+date.getDate();
      if(item.planStartDay===today){//今天未完成工单
        params={
          workorderCode:item.workorderCode,
          auditStatus: "20",
          distinguishStatus: "10",
          workorderStatus: "30"
        }
      }else{//未来工单
        params={
          workorderCode:item.workorderCode,
          auditStatus: "00",
          distinguishStatus: "30",
          workorderStatus: "10"
        }
      }
      
      getWorkorderDetail(params).then(response =>{
        this.loadingOfPopover = false;
           if (response.data.statusCode == "200") {
            if (response.data.responseData) {
               this.careReceiverDetail = response.data.responseData;
               if(this.careReceiverDetail.reportWorkorderServiceList){
                 var serviceItems = ""
                 this.careReceiverDetail.reportWorkorderServiceList.forEach((item,index)=>{
                   serviceItems+=item.serviceCode+(index!=this.careReceiverDetail.reportWorkorderServiceList.length-1?",":"")
                 })
                 this.careReceiverDetail.serviceItems = serviceItems;
               }
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
      }).catch(error=>{
        this.loadingOfPopover = false;
        console.log(error)
        this.$message.error(this.ConstantData.requestErrorMsg);
      })
    },
    refreshTable(val){
      this.staffCode = val;
      // this.gridOptions.localeText={noRowsToShow: '加载中...'}
      this.loadingOfTable = true;
      this.staffScheduleData = [];
      this.queryWorkorderScheduleByCareGiverCode();
    },
    calculatData2(isWeekDay){
      var startTime = new Date().getTime();
      var dataList = [];
      let dayCount = isWeekDay ? 7 : 31;
      //创建数组
      for(var i=0;i<dayCount;i++){
        dataList[i] = [];
        //创建行
        for(var j=0;j<24*60;j++){
          var rowObj = {time:j};
          dataList[i].push(rowObj)
        }
      }
      //填充对象
      this.customerList.forEach(item => {
        var startTime = this.changeStrToMinutes(item.planStartTime);
        var endTime = this.changeStrToMinutes(item.planEndTime);
        var rowCount = endTime - startTime;//对象需占的行数
        if(rowCount>0){
          this.$set(item,"rowCount",rowCount);//打标
          this.$set(item,"showPop",false);
          this.$set(item,"time",startTime);
        }
        var index = this.getIndexByDayString(item.planStartDay);
        if(dataList[index]){
          dataList[index][startTime] = item;
        }
        //60-startTime%60 startTime前面的需要标志needOnePxStyle
        for(var i=0;i<=startTime%60;i++){
          if(dataList[index]&&dataList[index][startTime-i]){
             this.$set(dataList[index][startTime-i],"needOnePxStyle",true);
              if((dataList[index][startTime-i].time+1)%60==0){
                this.$set(dataList[index][startTime-i],"needDashedBottom",true);
              }
          }
         
        }
        //60-endTime%60 endTime后面的需要标志needOnePxStyle
        for(var i=0;i<(60-endTime%60);i++){
          if(dataList[index]&&dataList[index][endTime+i]){
             this.$set(dataList[index][endTime+i],"needOnePxStyle",true);
              if((dataList[index][endTime+i].time+1)%60==0){
                this.$set(dataList[index][endTime+i],"needDashedBottom",true);
              }
          }
        }
      });
      //删减行
      for(let i=0;i<dayCount;i++){
        for(let j=0;j<dataList[i].length;j++){
          if(dataList[i][j].rowCount){//删区块内容
            dataList[i].splice(j+1,dataList[i][j].rowCount-1);
          }
        }
      }
      for(let i=0;i<dayCount;i++){
        for(let j=dataList[i].length;j>=0;j--){
          var item = dataList[i][j];
          if(item){
             if(item["needOnePxStyle"]||item.rowCount || (item.time+1)%60==0){
              
            }else{
              dataList[i].splice(j,1);
            }
          }
         
        }
      }

      this.staffScheduleData = dataList;
      this.$nextTick(()=>{
        this.loadingOfTable =false;
        this.resetScroll();
        var endTinme = new Date().getTime();
        console.log("time cost==="+(endTinme-startTime))
      });
    },
    getIndexByDayString(dayStr){
      var resultDate = this.stringToDate(dayStr);
      var index = this.dateMinus(resultDate);
      return index;
    },
    stringToDate : function(dateStr,separator){
     if(!separator){
            separator="-";
     }
     var dateArr = dateStr.split(separator);
     var year = parseInt(dateArr[0]);
     var month;
     //处理月份为04这样的情况                         
     if(dateArr[1].indexOf("0") == 0){
         month = parseInt(dateArr[1].substring(1));
     }else{
          month = parseInt(dateArr[1]);
     }
     var day = parseInt(dateArr[2]);
     var date = new Date(year,month -1,day);
     return date;
    },
    dateMinus(sDate){ 
  　　var now = new Date(); 
     now = this.stringToDate(now.getFullYear()+"-"+(now.getMonth()+1)+"-"+now.getDate());
  　　var days = sDate.getTime()-now.getTime(); 
      days = parseInt(days/(1000*60*60*24))
  　　return days; 
    },
    getItemStyle(item){
      return {
        height:item.rowCount*3/4+"px",
        backgroundColor:"#f9f3ef",
        textAlign:"center",
        paddingTop:((item.rowCount)*3/8-19)+'px',
        borderTop:'0.75px solid #e0e6eb',
        borderLeft:'1px solid #e0e6eb',
        borderBottom:'0.75px solid #e0e6eb',
        cursor:'pointer'
        }
    },
    getEmptyItemStyle(item,index){
        if(item["needOnePxStyle"]){
          if(item["needDashedBottom"]){
            return {height:'0.75px',borderLeft:'1px solid #e0e6eb',borderBottom:'0.75px dashed #e0e6eb'}
          }
          return {height:'0.75px',borderLeft:'1px solid #e0e6eb'}
        }
        return {height:'45px',borderLeft:'1px solid #e0e6eb',borderBottom:'0.75px dashed #e0e6eb'}
    },
    clearCarePerson(){
      this.careReceiverDetail = {};
    }
  },
  mounted() {
      this.tableScrollEvent();
    
  },
  created() {
      
  },
  updated() {
  }

};
</script>
<style>
.el-table .empty-row {
  background: #ffffff;
}
.el-table .empty-nomal-row {
  background-color: #fff909;
}
.el-table tr {
  background-color: #ffffff;
  border: none;
}
.table {
  width: 100%;
  height: 800px;
}
.show-cell {
    background: white;
    border-left: 1px solid #e0e6eb !important;
    border-top: 1px solid #e0e6eb !important;
    border-bottom: 1px solid #e0e6eb !important;
}
.unshow-cell{
   background: white;
   margin: 0px;
   padding: 0px;
   border-left: 1px solid #e0e6eb !important;
   border-bottom: 1px dashed #e0e6eb !important;
}
.noBottom-cell{
  background: white;
   margin: 0px;
   padding: 0px;
   border-left: 1px solid #e0e6eb !important;
}

.show-presenter {
    font-style:italic;
}
.ag-header-cell-label{ 
  justify-content: center; 
  padding: 0px;
  font-size:16px;
  font-style:bold;
  
}
.ag-header-cell{
  border-left: 1px solid #e0e6eb !important ;
  border-bottom: 1px solid #e0e6eb !important;
}
.ag-header{
  min-height: 40px;
  height: 40px;
}

.cellList {
  margin: 0;
  padding: 0;
  list-style: none;
  overflow:none;
  width: 100px;
  height: 576px;
}
.cellList li {
  margin: 0;
  padding: 0;
}
.header{
  margin: 0;
  padding: 0;
  list-style: none;
  overflow:none;
  width: 100px;
  display:inline-block;
}
.headerItem{
  padding-top:4.5px;
  padding-bottom: 4.5px;
  border-left: 1px solid #e0e6eb;
  border-bottom: 1px solid #e0e6eb;
  border-top: 1px solid #e0e6eb;
  text-align: center;
}



</style>