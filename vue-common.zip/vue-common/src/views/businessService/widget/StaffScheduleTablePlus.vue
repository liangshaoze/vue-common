<template>
  <div>
    <div>
    <!-- columnDefs表头  rowData表格数据-->
    <!-- ag-theme-balham 是ag-grid自带的表格样式类 -->
    <!--params.node.childIndex 行索引-->
    <ag-grid-vue
      ref="table"
      class="table ag-theme-fresh"
      :columnDefs="columnDefs"
      :rowData="staffScheduleData"
      :getRowHeight ="getRowHeight"
      :localeText="{noRowsToShow: '暂无数据'}"
      :suppressRowTransform="true"
    ></ag-grid-vue>
    </div>
     <el-dialog
        :visible.sync="dialogCustomerInfo"
        width="400px"
        :before-close="handleClose"
        :modal="false"
        title="被照护人信息"
      >
        <Loading v-if="loadingOfPopover"/>
        <div v-if="!loadingOfPopover" style="margin-left:10px">
            <div style="color:#333333;font-size:18px;margin-top:10px">
                <span>{{careReceiverDetail.careReceiverName}}</span>
                <span style="margin-left:10px;color:#666666">{{careReceiverDetail.careReceiverTel}}</span>
            </div>
            <div style="color:#999999;font-size:16px;margin-top:15px;padding-bottom:20px">
                {{careReceiverDetail.liveDetailAddress}}
            </div>
        </div>
      </el-dialog>
  </div>
</template>
<script>
import {findWorkorderScheduleByCareGiverCode,getEtCareReceiver} from "@/api/businessService/workOrderSchedule";//查询员工排程
import Loading from "@/components/Loading"
// 引入ag-grid-vue
import { AgGridVue } from 'ag-grid-vue';
 export default {
  props: {
    isWeekDay: {
      type: Boolean,
      default: true
    },
    staffCode:{
        type:String,
        default:""
    }
  },
  components:{
    Loading,
    AgGridVue,
  },
  beforeMount(){
  },

  data() {
    return {
      loadingOfPopover:true,
      careReceiverDetail:{},
      dialogCustomerInfo:false,
      gridOptions:null,
      staffScheduleData: [],
      columnDefs: [],
      rowData: [],
//       columnDefs:[
//     {field: '2020-02-29', 
//         rowSpan: function(params) {
//             if (params.data["2020-02-29"]) {
//                 return 9;
//             }else{
//               return 1;
//             } 
//         },
//         cellClassRules: {
//             'show-cell': 'value !== undefined'
//         },
//         width: 200
//     },
//     {field: '2020-03-01',
//         rowSpan: function(params) {
//             if (params.data["2020-03-01"]) {
//                 return 4;
//             } else {
//                 return 1;
//             }
//         },
//         cellClassRules: {
//             'show-cell': 'value !== undefined'
//         },
//         width: 200
//     },
//     {field: 'a'},
//     {field: 'b'},
//     {field: 'c'},
//     {field: 'd'},
//     {field: 'e'},
// ],
// rowData:[
//     { "2020-02-29": {name: 'Wake Up Dublin', presenter: 'Andrew Connell'},a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     { "2020-03-01": {name: 'Wake Up Dublin', presenter: 'Andrew Connell'},a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     {a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
    
//     // {localTime: '6:00am', show: {name: 'Pure Back In The Day', presenter: 'Kevin Flanagan'}, a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     // {localTime: '6:15am', a: 0.423, b: 0.452, c: 0.523, d: 0.543, e: 0.452},
//     // {localTime: '6:30am', a: 0.537, b: 0.246, c: 0.426, d: 0.421, e: 0.523},
//     // {localTime: '6:45am', a: 0.893, b: 0.083, c: 0.532, d: 0.983, e: 0.543},
//     // {localTime: '7:00am', show: {name: 'The Queens Breakfast', presenter: 'Tony Smith'}, a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     // {localTime: '7:15am', a: 0.423, b: 0.452, c: 0.523, d: 0.543, e: 0.452},
//     // {localTime: '7:30am', a: 0.537, b: 0.246, c: 0.426, d: 0.421, e: 0.523},
//     // {localTime: '7:45am', a: 0.893, b: 0.083, c: 0.532, d: 0.983, e: 0.543},
//     // {localTime: '8:00am', show: {name: 'Cosmetic Surgery', presenter: 'Niall Crosby'}, a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     // {localTime: '8:15am', a: 0.423, b: 0.452, c: 0.523, d: 0.543, e: 0.452},
//     // {localTime: '8:30am', a: 0.537, b: 0.246, c: 0.426, d: 0.421, e: 0.523},
//     // {localTime: '8:45am', a: 0.893, b: 0.083, c: 0.532, d: 0.983, e: 0.543},
//     // {localTime: '8:00am', show: {name: 'Brickfield Park Sessions', presenter: 'Bricker McGee'}, a: 0.231, b: 0.523, c: 0.423, d: 0.527, e: 0.342},
//     // {localTime: '8:15am', a: 0.423, b: 0.452, c: 0.523, d: 0.543, e: 0.452},
//     // {localTime: '8:30am', a: 0.537, b: 0.246, c: 0.426, d: 0.421, e: 0.523},
//     // {localTime: '8:45am', a: 0.893, b: 0.083, c: 0.532, d: 0.983, e: 0.543},
// ]
    };
  },
  methods: {
    doQueryCarePerson(params){
      this.dialogCustomerInfo = true;
      this.queryCarePerson(params.value.careReceiverCode)
    },
    handleClose() {
      this.dialogCustomerInfo = false;
    },
    getRowHeight(params){
      if(params.data.needOnePxStyle){
        return 3/4;
      }
      return 45;
    },
    initColumnDefs(){
      let dayCount = this.isWeekDay ? 7 : 31;
      this.columnDefs = [];
      for(let i=0;i<dayCount;i++){
         let that = this;
         let dayStr = "day"+(i+1);
        this.columnDefs.push({headerName: this.getTableHeadLableName(i+1), field: dayStr,cellRenderer:createShowCellRenderer(this),rowSpan:function(params){
          if(params.data[dayStr]){
            return params.data[dayStr].rowCount
          }else{
            return 1;
          }
          
        },
         cellStyle: function(params) {
            if(params.data["day"+(params.colId+1)] != undefined){
            return {margin:'0',padding:'0',borderLeft:'1px solid #e0e6eb',borderTop:'1px solid #e0e6eb',borderBottom:'1px solid #e0e6eb',background:'#f9f3ef'}
          }
          if(params.data["day"+(params.colId+1)] == undefined&&params.data["needOnePxStyle"]){
            if(params.data["needDashedBottom"]){
              return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'1px dashed #e0e6eb'}
            }
              return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'none'};
          }
           return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'1px dashed #e0e6eb'}
        },
        // cellStyle: function(params) {
        //     if(params.data["day"+(params.colId+1)] != undefined){
        //     return {margin:'0',padding:'0',borderLeft:'1px solid #e0e6eb',borderTop:'1px solid #e0e6eb',borderBottom:'1px solid #e0e6eb',background:'#f9f3ef'}
        //   }
        //   if(params.data["day"+(params.colId+1)] == undefined&&params.data["needOnePxStyle"]){
        //     if(params.data["needDashedBottom"]){
        //       return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'1px dashed #e0e6eb'}
        //     }
        //       return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'none'};
        //   }
        //    return {padding:'0',borderLeft:'1px solid #e0e6eb',borderBottom:'1px dashed #e0e6eb'}
        // },
        width: 95
        })
      }
    },
    calculatData(isWeekDay) {
     this.staffScheduleData=[];
     //按分钟创建对象
     let dayCount = isWeekDay ? 7 : 31;
      for (let i = 1; i <= 34 * 60; i++) {
        let rowObj = {}; //行对象
        for (let j = 1; j <= dayCount; j++) {
          let dayStr = this.getDayStringByIndex(j);
          for (let k = 0; this.customerList&&k < this.customerList.length; k++) {
            let customerItem = this.customerList[k];
            if (isWeekDay) {
              if (customerItem.planStartDay == dayStr &&
                  this.changeStrToMinutes(customerItem.planStartTime)<=i &&
                  this.changeStrToMinutes(customerItem.planEndTime)>=i) {
                  if(!customerItem.rowCount){
                        this.$set(rowObj,"day" + j,customerItem);
                        var rowCount = this.changeStrToMinutes(customerItem.planEndTime)-this.changeStrToMinutes(customerItem.planStartTime);
                        this.$set(customerItem,"rowCount",rowCount)
                    }
                  break;
              } 
            } else {
              if (customerItem.planStartDay == dayStr &&
                  this.changeStrToMinutes(customerItem.planStartTime)<=i &&
                  this.changeStrToMinutes(customerItem.planEndTime)>=i){
                    if(!customerItem.rowCount){
                        this.$set(rowObj,"day" + j,customerItem);
                        var rowCount = this.changeStrToMinutes(customerItem.planEndTime)-this.changeStrToMinutes(customerItem.planStartTime);
                        this.$set(customerItem,"rowCount",rowCount)
                        
                    }
                break;
              }
            }
          }
        }
        this.staffScheduleData.push(rowObj);
      }
      let currentIndex = 0;//当前索引
      let preIndex = 0;
      let isExitDataBetweenBlock = false;//区块间是否存在数据
      //移除行
      for(let i= this.staffScheduleData.length;i>=0;i--){
          if(i%60==0){
            currentIndex = i-1;
            preIndex = i-1-60;
            isExitDataBetweenBlock = false;
          }
          if(preIndex <0){
              preIndex = 0
          }
          for(let j=currentIndex;j>=preIndex+1;j--){
              for(let k=1;k<=dayCount;k++){
                if(this.staffScheduleData[j]&&this.staffScheduleData[j]["day"+k]!=undefined){
                    isExitDataBetweenBlock = true;
                    break;
                }
              }
          }
          if(isExitDataBetweenBlock){//有数据，给数据打上标，便于在设置样式时设置相应的样式
            if(i==0){
              this.$set(this.staffScheduleData[i],"needOnePxStyle",true);
            }else{
              this.$set(this.staffScheduleData[i-1],"needOnePxStyle",true);
              if(i%60==0){//底部需加分隔线
                this.$set(this.staffScheduleData[i-1],"needDashedBottom",true);
              }
            }
          }
          if(!isExitDataBetweenBlock && i%60!=0){
            this.staffScheduleData.splice(i-1,1)
          }
          currentIndex --;
      }
    },
    getTableHeadLableName(index) {
      if (this.isWeekDay) {
        if (index == 1) {
          return "周一";
        } else if (index == 2) {
          return "周二";
        } else if (index == 3) {
          return "周三";
        } else if (index == 4) {
          return "周四";
        } else if (index == 5) {
          return "周五";
        } else if (index == 6) {
          return "周六";
        } else if (index == 7) {
          return "周日";
        }
      } else {
        let dayName = "";
        let currentDate = new Date();
        currentDate.setDate(currentDate.getDate()+(index-1));
        var weekDay = currentDate.getDay();
        var weekDayStr = ""
        if (weekDay == 0) {
          weekDayStr =  "周日";
        } else if (weekDay == 1) {
          weekDayStr = "周一";
        } else if (weekDay == 2) {
          weekDayStr = "周二";
        } else if (weekDay == 3) {
          weekDayStr = "周三";
        } else if (weekDay == 4) {
          weekDayStr = "周四";
        } else if (weekDay == 5) {
          weekDayStr = "周五";
        } else if (weekDay == 6) {
          weekDayStr = "周六";
        }
        return ""+(currentDate.getMonth()+1)+"/"+currentDate.getDate()+weekDayStr;
      }
    },
    changeStrToMinutes(str) {
      if(!str){
        return 0;
      }
      var arrminutes = str.split(":");
      if (arrminutes.length == 2) {
        var minutes = parseInt(arrminutes[0]) * 60 + parseInt(arrminutes[1]);
        return minutes;
      } else {
        return 0;
      }
    },
    tableScrollEvent(){
        this.dom = this.$refs["table"]
        this.gridOptions = this.dom.gridOptions;
        var that = this;
        this.gridOptions.onBodyScroll = function(params){
          that.$emit("onTableScroll",params.top);
        }
    },
    getDayStringByIndex(index){
      //组装成2020-01-20 形式
      let date = new Date();
      date.setDate(date.getDate()+(index-1));
      let month = date.getMonth()+1;
      month = month<10?("0"+month):month;
      let day = date.getDate();
      day = day<10?("0"+date.getDate()):date.getDate();
      let result = date.getFullYear()+"-"+month+"-"+day;
      return result;
    }
    ,
    queryWorkorderScheduleByCareGiverCode(){
      let params={
        careGiverCode:this.staffCode,//员工代码
      }
      findWorkorderScheduleByCareGiverCode(params).then(response=>{
        if (response.data.statusCode == "200") {
            if (response.data.responseData) {
                this.staffScheduleData =[];
                this.customerList = response.data.responseData;
                var timer = setInterval(()=>{
                      this.calculatData2(this.isWeekDay)
                      clearInterval(timer);
                  },200);
                this.$emit("gotScheduleListener",this.customerList && this.customerList.length == 0,this.staffCode)
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }

      }).catch(error=>{
         this.$message.error(this.ConstantData.requestErrorMsg);
      });
    },
    queryCarePerson(code){
      this.loadingOfPopover = true;
      var params={careReceiverCode:code}
      getEtCareReceiver(params).then(response =>{
        this.loadingOfPopover = false;
           if (response.data.statusCode == "200") {
            if (response.data.responseData) {
               this.careReceiverDetail = response.data.responseData;
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
      }).catch(error=>{
        this.loadingOfPopover = false;
        console.log(error)
        this.$message.error(this.ConstantData.requestErrorMsg);
      })
    },
    refreshTable(val){
      this.staffCode = val;
      this.gridOptions.localeText={noRowsToShow: '加载中...'}
      this.queryWorkorderScheduleByCareGiverCode();
    },
    calculatData2(isWeekDay){
      var dataList = [];
      let dayCount = isWeekDay ? 7 : 31;
      //创建行
      for(var i =0;i<34*60;i++){
        var rowObj = {};
        dataList.push(rowObj)
      }
      //填充对象
      this.customerList.forEach(item => {
        var startTime = this.changeStrToMinutes(item.planStartTime);
        var endTime = this.changeStrToMinutes(item.planEndTime);
        var rowCount = endTime - startTime;//对象需占的行数
        if(rowCount>0){
          this.$set(item,"rowCount",rowCount);//打标
        }
          //取到行对象
          this.$set(dataList[startTime],'day'+(this.getIndexByDayString(item.planStartDay)+1),item)
      });
      let currentIndex = 0;//当前索引
      let preIndex = 0;
      let isExitDataBetweenBlock = false;//区块间是否存在数据
      //移除行
      for(let i= dataList.length;i>=0;i--){
          if(i%60==0){
            currentIndex = i-1;
            preIndex = i-1-60;
            isExitDataBetweenBlock = false;
          }
          if(preIndex <0){
              preIndex = -1
          }
          if(currentIndex <0){
              currentIndex = 0
          }
          for(let j=currentIndex;j>=preIndex+1;j--){
              for(let k=1;k<=dayCount;k++){
                var dayProperty = 'day'+k;
                if(dataList[j]&&dataList[j][dayProperty]&&dataList[j][dayProperty]!=undefined){
                    isExitDataBetweenBlock = true;
                    break;
                }
              }
          }
          if(isExitDataBetweenBlock){//有数据，给数据打上标，便于在设置样式时设置相应的样式
            if(i==0){
              this.$set(dataList[i],"needOnePxStyle",true);
            }else{
              this.$set(dataList[i-1],"needOnePxStyle",true);
              if(i%60==0){//底部需加分隔线
                this.$set(dataList[i-1],"needDashedBottom",true);
              }
            }
          }
          if(!isExitDataBetweenBlock && i%60!=0){
            dataList.splice(i-1,1)
          }
          // if(currentIndex ==0){
          //   for(let k=1;k<=dayCount;k++){
          //       var dayProperty = 'day'+k;
          //       if(dataList[0]&&dataList[0][dayProperty]&&dataList[0][dayProperty]!=undefined){
          //           isExitDataBetweenBlock = true;
          //           break;
          //       }
          //     }
          //   if(!isExitDataBetweenBlock){
          //     dataList.splice(0,1)
          //   }
          // }
          currentIndex --;
      }
      this.staffScheduleData = dataList;

    },
    calculatData3(isWeekDay){
      var dataList = [];
      let dayCount = isWeekDay ? 7 : 31;
      //创建行
      for(var i =0;i<34*60;i++){
        var rowObj = {};
        dataList.push(rowObj)
      }
      //填充对象
      this.customerList.forEach(item => {
        var startTime = this.changeStrToMinutes(item.planStartTime);
        var endTime = this.changeStrToMinutes(item.planEndTime);
        var rowCount = endTime - startTime;//对象需占的行数
        if(rowCount>0){
          this.$set(item,"rowCount",rowCount);//打标
        }
        if((this.getIndexByDayString(item.planStartDay)+1)>0){
          //取到行对象
          this.$set(dataList[startTime],'day'+(this.getIndexByDayString(item.planStartDay)+1),item)
          //如果endTime不为整点
            while(endTime%60!=0){
                endTime+=1;
            }
          for(var i=startTime;i<=endTime;i++){
            //区域内的行设置1px样式
            this.$set(dataList[i],"needOnePxStyle",true);
            if(i%60==0){//底部需加分隔线
                this.$set(dataList[i-1],"needDashedBottom",true);
              }
          }
          console.log("startTime=="+startTime+" endTime"+endTime)
        }
         
      });
      let currentIndex = 0;//当前索引
      let preIndex = 0;
      let isExitDataBetweenBlock = false;//区块间是否存在数据
      //移除行
      for(let i= dataList.length;i>=0;i--){
          if(i%60==0){
            currentIndex = i-1;
            preIndex = i-1-60;
            isExitDataBetweenBlock = false;
          }
          if(preIndex <0){
              preIndex = 0
          }
          for(let j=currentIndex;j>=preIndex+1;j--){
              for(let k=1;k<=dayCount;k++){
                var dayProperty = 'day'+k;
                if(dataList[j]&&dataList[j][dayProperty]&&dataList[j][dayProperty]!=undefined){
                    isExitDataBetweenBlock = true;
                    break;
                }
              }
          }
          if(isExitDataBetweenBlock){//有数据，给数据打上标，便于在设置样式时设置相应的样式
            if(i==0){
              this.$set(dataList[i],"needOnePxStyle",true);
            }else{
              this.$set(dataList[i-1],"needOnePxStyle",true);
              if(i%60==0){//底部需加分隔线
                this.$set(dataList[i-1],"needDashedBottom",true);
              }
            }
          }
          if(!isExitDataBetweenBlock && i%60!=0&&!dataList[i-1]["needOnePxStyle"]&&(i-1!=0)){
            dataList.splice(i-1,1)
          }
          currentIndex --;
      }
      this.staffScheduleData = dataList;
      console.log(JSON.stringify(dataList))

    },
    getIndexByDayString(dayStr){
      var resultDate = this.stringToDate(dayStr);
      var index = this.dateMinus(resultDate);
      return index;
    },
    stringToDate : function(dateStr,separator){
     if(!separator){
            separator="-";
     }
     var dateArr = dateStr.split(separator);
     var year = parseInt(dateArr[0]);
     var month;
     //处理月份为04这样的情况                         
     if(dateArr[1].indexOf("0") == 0){
         month = parseInt(dateArr[1].substring(1));
     }else{
          month = parseInt(dateArr[1]);
     }
     var day = parseInt(dateArr[2]);
     var date = new Date(year,month -1,day);
     return date;
    },
    dateMinus(sDate){ 
  　　var now = new Date(); 
     now = this.stringToDate(now.getFullYear()+"-"+(now.getMonth()+1)+"-"+now.getDate());
  　　var days = sDate.getTime()-now.getTime(); 
      days = parseInt(days/(1000*60*60*24))
  　　return days; 
    }
  },
  mounted() {
      this.initColumnDefs();
      this.tableScrollEvent();
      //表格样式
      var table=document.querySelector(".ag-theme-fresh")
      table.style.cssText="border:1px solid #e0e6eb;"
//      this.columnDefs = [
//     {field: '2020-02-29',cellRenderer:new createShowCellRenderer(this),
//         rowSpan: function(params) {
//             if (params.data["2020-02-29"]) {
//                 return 9;
//             }else{
//               return 1;
//             } 
//         },
//         cellClassRules: {
//             'show-cell': 'value !== undefined'
//         },
//         width: 200
//     },
//     {field: '2020-03-01',cellRenderer:new createShowCellRenderer(this),
//         rowSpan: function(params) {
//             if (params.data["2020-03-01"]) {
//                 return 4;
//             } else {
//                 return 1;
//             }
//         },
//         cellClassRules: {
//             'show-cell': 'value !== undefined'
//         },
//         width: 200
//     },
//     {field: 'a'},
//     {field: 'b'},
//     {field: 'c'},
//     {field: 'd'},
//     {field: 'e'},
// ]
    
  },
  created() {
      
  },
  updated() {
      
  }

};
function createShowCellRenderer(vm) {
    function ShowCellRenderer(){}

    ShowCellRenderer.prototype.init = function(params) {
        var cellBlank = !params.value;
        if (cellBlank) { return null; }
        this.ui = document.createElement('div');
        this.ui.innerHTML = 
            '<div style="text-align:center;background:#f9f3ef;height:'+params.value.rowCount*3/4+'px;border-top:1px solid #e0e6eb;border-bottom:1px solid #e0e6eb;cursor:pointer">'
            +'<div style="color:#666666;margin-top:5px;font-size:14px">'+params.value.careReceiverName+'</div>'
            +'<div style="color:#ed9c62;;font-size:14px">'+params.value.planStartTime+" ~ "+params.value.planEndTime+'</div>'
            '</div>'
            this.ui.onclick =function(){
              vm.doQueryCarePerson(params);
            };
            // this.ui.innerHTML ="hhh"
            // this.ui.style.cssText ="background-color:blue;height:250px"
    };
    ShowCellRenderer.prototype.getGui = function() {
        return this.ui;
    };
    return ShowCellRenderer;
}
</script>
<style>
.el-table .empty-row {
  background: #ffffff;
}
.el-table .empty-nomal-row {
  background-color: #fff909;
}
.el-table tr {
  background-color: #ffffff;
  border: none;
}
.table {
  width: 100%;
  height: 800px;
}
.show-cell {
    background: white;
    border-left: 1px solid #e0e6eb !important;
    border-top: 1px solid #e0e6eb !important;
    border-bottom: 1px solid #e0e6eb !important;
}
.unshow-cell{
   background: white;
   margin: 0px;
   padding: 0px;
   border-left: 1px solid #e0e6eb !important;
   border-bottom: 1px dashed #e0e6eb !important;
}
.noBottom-cell{
  background: white;
   margin: 0px;
   padding: 0px;
   border-left: 1px solid #e0e6eb !important;
}

.show-presenter {
    font-style:italic;
}
.ag-header-cell-label{ 
  justify-content: center; 
  padding: 0px;
  font-size:16px;
  font-style:bold;
  
}
.ag-header-cell{
  border-left: 1px solid #e0e6eb !important ;
  border-bottom: 1px solid #e0e6eb !important;
}
.ag-header{
  min-height: 40px;
  height: 40px;
}
</style>