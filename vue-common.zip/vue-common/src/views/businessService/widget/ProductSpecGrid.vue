<template>
 <div>
    <el-row v-for="index in rowIndexList" :key="index">
      <div v-for="colIndex in colNum" :key="colIndex">
      <el-col v-if="productSpecificationList[index*colNum+colIndex-1]" class="form-item">
        <el-form-item
          :label="productSpecificationList[index*colNum+colIndex-1].specificationName"
          :prop="'productOrderSpecificationList.'+[index*colNum+colIndex-1]+'.specificationValueId'"
          :rules="[{required: true, message: '请输入'+productSpecificationList[index*colNum+colIndex-1].specificationName}]"
        >
         <span v-if="isEdit == false" class="long-field">{{productOrderSpecificationList[index*colNum+colIndex-1].specificationValue }}</span>
         <span v-if="isEdit == true">
            <SpecSelect
              :fuzzyItem="productSpecificationList[index*colNum+colIndex-1]"
              :resultItem ="productOrderSpecificationList[index*colNum+colIndex-1]"
              :fuzzySelectedList="productOrderSpecificationList"
              @changeSpecSelect="changeSpecSelect"
            />
          </span>
        </el-form-item>
      </el-col>
      </div>
    </el-row>
  </div>
</template>

<script>
import SpecSelect from "components/CustomerSelect/SpecSelect";
import SpecInput from "components/CustomerSelect/SpecInput";
export default {
  props: {
    productSpecificationList: {
      type: Array,
      default: []
    },
    productOrderSpecificationList:{
      type:Array,
      default:[]
    },
    colNum:{
      type:Number,
      default:1
    },
    isEdit:{
      type:Boolean,
      default:false
    }
  },
  components: {
    SpecSelect,
    SpecInput
  },
  data() {
    return {
      rowIndexList: [],
    };
  },
  methods: {
    changeSpecSelect(){
          let ids = ""
          let valueIds = ""
          for(let i =0;i<this.productOrderSpecificationList.length;i++){
            ids += this.productOrderSpecificationList[i].specificationId+((i==this.productOrderSpecificationList.length-1)?"":",")
            valueIds += this.productOrderSpecificationList[i].specificationValueId+((i==this.productOrderSpecificationList.length-1)?"":",")
          }
          let val = {
            specificationIds:ids,
            specificationValueIds:valueIds
          }
          this.$emit("onSpecChangeListener",val)
    }
  },
  mounted() {
    this.$nextTick(()=>{
      this.rowIndexList = [];
      var count = 0;
      if(this.productSpecificationList.length%this.colNum == 0){
        count = this.productSpecificationList.length/this.colNum;
      }else{
        count = this.productSpecificationList.length/this.colNum +1;
      }
      for (var i = 0; i < count; i++) {
        this.rowIndexList.push(i);
      }
    })
  },
  created() {
    this.$watch("productSpecificationList", function() {
      this.rowIndexList = [];
      var count = 0;
      if(this.productSpecificationList.length%this.colNum == 0){
        count = this.productSpecificationList.length/this.colNum;
      }else{
        count = this.productSpecificationList.length/this.colNum +1;
      }
      for (var i = 0; i < count; i++) {
        this.rowIndexList.push(i);
      }
    });
  },
  updated(){
  }
};
</script>

<style lang="scss" scoped>
.form-item {
  width: 30%;
  min-width: 470px;
  padding-bottom: 5px;
  max-height: 50px;
}
</style>