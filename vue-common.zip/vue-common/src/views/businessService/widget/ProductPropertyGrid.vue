<template>
  <div>
    <!--索引(index+1)*colNum-(colNum-colIndex+1)-->
    <el-row v-for="index in rowIndexList" :key="index">
      <div v-for="colIndex in colNum" :key="colIndex">
        <el-col v-if="productPropertyList[index*colNum+colIndex-1]" class="form-item">
            <el-form-item
              v-if="productPropertyList[index*colNum+colIndex-1].propertyType == 10"
              :label="productPropertyList[index*colNum+colIndex-1].propertyName"
              :prop="'productOrderPropertyList.'+[index*colNum+colIndex-1]+'.propertyValue'"
              :rules="productPropertyList[index*colNum+colIndex-1].isInput == 1 ? [{required: true, message: productPropertyList[index*colNum+colIndex-1].propertyName+'不能为空'}] : null"
            >
            <span v-if="isEdit == false" class="long-field">{{productOrderPropertyList[index*colNum+colIndex-1].propertyValue }}</span>
            <span v-if="isEdit == true">
              <ProductPropertyInput
                :fuzzyItem="productPropertyList[index*colNum+colIndex-1]"
                :resultItem="productOrderPropertyList[index*colNum+colIndex-1]"
                :fuzzySelectedList="productOrderPropertyList"
              />
            </span>
            </el-form-item>
          <el-form-item
            v-if="productPropertyList[index*colNum+colIndex-1].propertyType != 10"
            :label="productPropertyList[index*colNum+colIndex-1].propertyName"
            :prop="'productOrderPropertyList.'+[index*colNum+colIndex-1]+'.propertyValueId'"
            :rules="productPropertyList[index*colNum+colIndex-1].isInput == 1 ? [{required: true, message: productPropertyList[index*colNum+colIndex-1].propertyName+'不能为空'}] : null"
            ref="propertyFormItem"
          >
          <span v-if="isEdit == false" class="long-field">{{productOrderPropertyList[index*colNum+colIndex-1].propertyValue }}</span>
            <span v-if="isEdit == true">
                <span v-if="productPropertyList[index*colNum+colIndex-1].propertyType == 20">
                  <ProductPropertySelect
                    :fuzzyItem="productPropertyList[index*colNum+colIndex-1]"
                    :resultItem="productOrderPropertyList[index*colNum+colIndex-1]"
                    :fuzzySelectedList="productOrderPropertyList"
                    :filterable="false"
                    :multiple="false"
                  />
                </span>
                <span v-if="productPropertyList[index*colNum+colIndex-1].propertyType == 30">
                  <ProductPropertySelect
                    :fuzzyItem="productPropertyList[index*colNum+colIndex-1]"
                    :resultItem="productOrderPropertyList[index*colNum+colIndex-1]"
                    :fuzzySelectedList="productOrderPropertyList"
                    :multiple="true"
                    :filterable="false"
                  />
                </span>
                <span v-if="productPropertyList[index*colNum+colIndex-1].propertyType == 40">
                  <ProductPropertyRadioGroup
                    :fuzzyItem="productPropertyList[index*colNum+colIndex-1]"
                    :resultItem="productOrderPropertyList[index*colNum+colIndex-1]"
                    :fuzzySelectedList="productOrderPropertyList"
                  />
                </span>
                <span v-if="productPropertyList[index*colNum+colIndex-1].propertyType == 50">
                  <ProductPropertyAutoComplete
                    :fuzzyItem="productPropertyList[index*colNum+colIndex-1]"
                    :resultItem="productOrderPropertyList[index*colNum+colIndex-1]"
                    :fuzzySelectedList="productOrderPropertyList"
                  />
                </span>
            </span>
          </el-form-item>
        </el-col>
      </div>
    </el-row>
  </div>
</template>

<script>
import ProductPropertySelect from "components/CustomerSelect/ProductPropertySelect";
import ProductPropertyRadioGroup from "components/CustomerSelect/ProductPropertyRadioGroup";
import ProductPropertyInput from "components/CustomerSelect/ProductPropertyInput";
import ProductPropertyAutoComplete from "components/CustomerSelect/ProductPropertyAutoComplete";
export default {
  props: {
    productPropertyList: {
      //已选择过的属性
      type: Array,
      default: []
    },
    productOrderPropertyList: {
      type: Array,
      default: []
    },
    colNum: {
      type: Number,
      default: 1
    },
    isEdit:{
      type:Boolean,
      default:false
    }
  },
  components: {
    ProductPropertySelect,
    ProductPropertyRadioGroup,
    ProductPropertyInput,
    ProductPropertyAutoComplete
  },
  data() {
    return {
      rowIndexList: [] //传进来的
    };
  },
  methods: {},
  mounted() {
    this.rowIndexList = [];
      var count = 0;
      if (this.productPropertyList.length % this.colNum == 0) {
        count = this.productPropertyList.length / this.colNum;
      } else {
        count = this.productPropertyList.length / this.colNum + 1;
      }
      for (var i = 0; i < count; i++) {
        this.rowIndexList.push(i);
      }
  },
  created() {
    this.$watch("productPropertyList",()=>{
      this.rowIndexList = [];
      var count = 0;
      if (this.productPropertyList.length % this.colNum == 0) {
        count = this.productPropertyList.length / this.colNum;
      } else {
        count = this.productPropertyList.length / this.colNum + 1;
      }
      for (var i = 0; i < count; i++) {
        this.rowIndexList.push(i);
      }
    })
  }
};
</script>

<style lang="scss" scoped>
.form-item {
  width: 30%;
  min-width: 470px;
  padding-bottom: 5px;
  max-height: 50px;
}
.el-autocomplete-suggestion__wrap {
  min-width: 300px;
}
</style>