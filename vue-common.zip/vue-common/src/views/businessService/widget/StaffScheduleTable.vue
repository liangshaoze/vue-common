<template>
    <div>
        <el-table
            ref="table"
            :data="staffScheduleData"
            :header-cell-style="{textAlign:'center',color:'#666666'}"
            element-loading-text="拼命加载中"
            size="mini"
            v-loading="listLoading"
            max-height="800"
            :span-method="cellMerge"
            :row-style="rowStyle"
            :cell-style="cellStyle"
            border
        >
            <el-table-column
                v-for="index in isWeekDay?7:31"
                :key="index"
                :property="'day'+index"
                :label="getTableHeadLableName(index)"
                :min-width="100"
            >
                <template slot-scope="{ row }" >
                    <el-popover
                        placement="top-start"
                        trigger="click"
                        width="200"
                        @show="queryCarePerson(row,index)"
                        @hide="clearCarePerson"
                    >
                        <Loading v-if="loadingOfPopover"/>
                        <div v-if="!loadingOfPopover">
                          <div style="color:#333333;font-size:18px">
                              <span>{{careReceiverDetail.careReceiverName}}</span>
                          </div>
                          <div style="color:#999999;font-size:16px;margin-top:15px">
                              {{careReceiverDetail.liveDetailAddress}}
                          </div>
                        </div>
                        <div v-if="row['day'+index]" slot="reference">
                            <div style="text-align:center;color:#666666">{{getNameValue(row,index)}}</div>
                            <div style="text-align:center;color:#ed9c62;white-space:nowrap;">{{getTimeValue(row,index)}}</div>
                        </div>
                    </el-popover>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
import {findWorkorderScheduleByCareGiverCode,getEtCareReceiver} from "@/api/businessService/workOrderSchedule";//查询员工排程
import Loading from "@/components/Loading"
 export default {
  props: {
    isWeekDay: {
      type: Boolean,
      default: true
    },
    staffCode:{
        type:String,
        default:""
    }
  },
  components:{
    Loading
  },

  data() {
    return {
      loadingOfPopover:true,
      careReceiverDetail:{},
    //   customerList: [],
        
      customerList: [
        // {
        //   careReceiverName: "张三",
        //   planStartTime: "08:25",
        //   planEndTime: "09:25",
        //   weekDay: "1",
        //   monthDay: "3"
        // },
        // {
        //   careReceiverName: "张三",
        //   planStartTime: "09:40",
        //   planEndTime: "11:00",
        //   weekDay: "1",
        //   monthDay: "4"
        // },
        {
          careReceiverName: "张三",
          planStartTime: "08:25",
          planEndTime: "09:25",
          weekDay: "2",
          monthDay: "3"
        },
        {
          careReceiverName: "张三",
          planStartTime: "09:40",
          planEndTime: "11:00",
          weekDay: "2",
          monthDay: "4"
        },
        {
          careReceiverName: "李四",
          planStartTime: "09:00",
          planEndTime: "10:25",
          weekDay: "3",
          monthDay: "5"
        },
        {
          careReceiverName: "李四",
          planStartTime: "11:40",
          planEndTime: "12:50",
          weekDay: "4",
          monthDay: "6"
        }
      ],
      staffScheduleData: [],
      spanArrList:[],//维护多个spanArr
      listLoading:false,
      isShowTable:true
      
    };
  },
  methods: {
      cellStyle({row, column, rowIndex, columnIndex}){
          if(this.staffScheduleData[rowIndex]["day"+(columnIndex+1)] != undefined){
            return {margin:'0',padding:'0',borderTop:'1px solid #e0e6eb',borderBottom:'1px solid #e0e6eb',background:'#f9f3ef'}
          }
          if(this.staffScheduleData[rowIndex]["day"+(columnIndex+1)] == undefined&&this.staffScheduleData[rowIndex]["needOnePxStyle"]){
            if(this.staffScheduleData[rowIndex]["needDashedBottom"]){
              return {padding:'0',borderBottom:'1px dashed #e0e6eb'}
            }
              return {padding:0,borderBottom:'none'};
          }
           return {padding:'0',borderBottom:'1px dashed #e0e6eb'}
      },
      rowStyle({row, column, rowIndex, columnIndex}){
           let dayCount = this.isWeekDay ? 7 : 31;
              if(this.staffScheduleData[rowIndex]["needOnePxStyle"]){
                return {height:'1px',padding:0,border:'none'};
              }
          return {height:'60px',padding:0};
      },
    calculatData(isWeekDay) {
     this.staffScheduleData=[];
     //按分钟创建对象
     let dayCount = isWeekDay ? 7 : 31;
      for (let i = 1; i <= 24 * 60; i++) {
        let rowObj = {}; //行对象
        for (let j = 1; j <= dayCount; j++) {
          let dayStr = this.getDayStringByIndex(j);
          for (let k = 0; this.customerList&&k < this.customerList.length; k++) {
            let customerItem = this.customerList[k];
            if (isWeekDay) {
              if (customerItem.planStartDay == dayStr &&
                  this.changeStrToMinutes(customerItem.planStartTime)<=i &&
                  this.changeStrToMinutes(customerItem.planEndTime)>=i) {
                  this.$set(rowObj,"day" + j,JSON.stringify(customerItem));
                  break;
              } 
            } else {
              if (customerItem.planStartDay == dayStr &&
                  this.changeStrToMinutes(customerItem.planStartTime)<=i &&
                  this.changeStrToMinutes(customerItem.planEndTime)>=i){
                  this.$set(rowObj,"day" + j,JSON.stringify(customerItem));
                break;
              }
            }
          }
        }
        this.staffScheduleData.push(rowObj);
      }
      let currentIndex = 0;//当前索引
      let preIndex = 0;
      let isExitDataBetweenBlock = false;//区块间是否存在数据
      //移除行
      for(let i= this.staffScheduleData.length;i>=0;i--){
          if(i==0){
            currentIndex= 0;
            preIndex = 0;
            isExitDataBetweenBlock = false;
            for(let k=1;k<=dayCount;k++){
                if(this.staffScheduleData[i]&&this.staffScheduleData[i]["day"+k]!=undefined){
                    isExitDataBetweenBlock = true;
                    break;
                }
              }
          }
          if(i%60==0){
            currentIndex = i-1;
            preIndex = i-1-60;
            isExitDataBetweenBlock = false;
          }
          if(preIndex <0){
              preIndex = 0
          }
          for(let j=currentIndex;j>=preIndex+1;j--){
              for(let k=1;k<=dayCount;k++){
                if(this.staffScheduleData[j]&&this.staffScheduleData[j]["day"+k]!=undefined){
                    isExitDataBetweenBlock = true;
                    break;
                }
              }
          }
          if(isExitDataBetweenBlock){//有数据，给数据打上标，便于在设置样式时设置相应的样式
            if(i==0){
              this.$set(this.staffScheduleData[i],"needOnePxStyle",true);
            }else{
              this.$set(this.staffScheduleData[i-1],"needOnePxStyle",true);
              if(i%60==0){//底部需加分隔线
                this.$set(this.staffScheduleData[i-1],"needDashedBottom",true);
              }
            }
          }
          if(!isExitDataBetweenBlock && i%60!=0){
            this.staffScheduleData.splice(i-1,1)
          }
          currentIndex --;
      }
      this.setSpanArr(isWeekDay);
      this.listLoading = false;
    },
    getTableHeadLableName(index) {
      if (this.isWeekDay) {
        if (index == 1) {
          return "周一";
        } else if (index == 2) {
          return "周二";
        } else if (index == 3) {
          return "周三";
        } else if (index == 4) {
          return "周四";
        } else if (index == 5) {
          return "周五";
        } else if (index == 6) {
          return "周六";
        } else if (index == 7) {
          return "周日";
        }
      } else {
        let dayName = "";
        let currentDate = new Date();
        currentDate.setDate(currentDate.getDate()+(index-1));
        return ""+(currentDate.getMonth()+1)+"/"+currentDate.getDate();
      }
    },
    changeStrToMinutes(str) {
      var arrminutes = str.split(":");
      if (arrminutes.length == 2) {
        var minutes = parseInt(arrminutes[0]) * 60 + parseInt(arrminutes[1]);
        return minutes;
      } else {
        return 0;
      }
    },
    cellMerge({ row, column, rowIndex, columnIndex }){
        if(this.spanArrList[columnIndex]){
            const _row = this.spanArrList[columnIndex].spanArr[rowIndex];
            const _col = _row > 0 ? 1 : 0;
            return {
            rowspan: _row,
            colspan: _col
            };
        }
    },
    setSpanArr(isWeekDay) {
      this.spanArrList = [];
      let count = isWeekDay?7:31;
      //创建count个spanArr；
      for(let i=1;i<=count;i++){
            var obj = {
                pos:0,
                spanArr:[]
            };
            this.spanArrList.push(obj);
        }
      for (let i = 0; i < this.staffScheduleData.length; i++) {
              for(let j=0;j<count;j++){
                if (i === 0) {
                    this.spanArrList[j].spanArr.push(1);
                    this.spanArrList[j].pos = 0;
                } else {
                    // 判断当前元素与上一个元素是否相同
                    if (this.staffScheduleData[i]["day"+(j+1)] && this.staffScheduleData[i-1]["day"+(j+1)]&&
                        this.staffScheduleData[i]["day"+(j+1)] === this.staffScheduleData[i-1]["day"+(j+1)] ) {
                        this.spanArrList[j].spanArr[this.spanArrList[j].pos] += 1;
                        this.spanArrList[j].spanArr.push(0);
                    } else {
                        this.spanArrList[j].spanArr.push(1);
                        this.spanArrList[j].pos = i;
                    }
                }
              }
      }
    },
    tableScrollEvent(){
        // 获取需要绑定的table
        this.dom = this.$refs.table.bodyWrapper
        this.dom.addEventListener('scroll', () => {
                // 滚动距离
                let scrollTop = this.dom.scrollTop
                // 变量windowHeight是可视区的高度
                let windowHeight = this.dom.clientHeight || this.dom.clientHeight
                // 变量scrollHeight是滚动条的总高度
                let scrollHeight = this.dom.scrollHeight || this.dom.scrollHeight
                if (scrollTop + windowHeight === scrollHeight) {
                    
                }
                this.$emit("onTableScroll",scrollTop);
        })
    },
    getNameValue(row,index){
        if(row['day'+index]){
            var obj = JSON.parse(row['day'+index]);
            return obj.careReceiverName;
        }else{
            return "";
        }
    },
    getTimeValue(row,index){
        if(row['day'+index]){
            var obj = JSON.parse(row['day'+index]);
            return obj.planStartTime+" ~ "+obj.planEndTime
        }else{
            return "";
        }
    },
    getDayStringByIndex(index){
      //组装成2020-01-20 形式
      let date = new Date();
      date.setDate(date.getDate()+(index-1));
      let month = date.getMonth()+1;
      month = month<10?("0"+month):month;
      let day = date.getDate();
      day = day<10?("0"+date.getDate()):date.getDate();
      let result = date.getFullYear()+"-"+month+"-"+day;
      return result;
    }
    ,
    queryWorkorderScheduleByCareGiverCode(){
      this.listLoading = true;
      let params={
        careGiverCode:this.staffCode,//员工代码
      }
      findWorkorderScheduleByCareGiverCode(params).then(response=>{
        if (response.data.statusCode == "200") {
            if (response.data.responseData) {
                this.staffScheduleData =[];
                this.customerList = response.data.responseData;
                var timer = setInterval(()=>{
                      this.calculatData(this.isWeekDay)
                      clearInterval(timer);
                  },500);
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }

      }).catch(error=>{
         this.listLoading = false;
         this.$message.error(this.ConstantData.requestErrorMsg);
      });
    },
    queryCarePerson(row,index){
      this.loadingOfPopover = true;
      var params={careReceiverCode:JSON.parse(row["day"+index]).careReceiverCode}
      getEtCareReceiver(params).then(response =>{
        this.loadingOfPopover = false;
           if (response.data.statusCode == "200") {
            if (response.data.responseData) {
               this.careReceiverDetail = response.data.responseData;
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
      }).catch(error=>{
        this.loadingOfPopover = false;
        console.log(error)
        this.$message.error(this.ConstantData.requestErrorMsg);
      })
    },
    clearCarePerson(){
      this.careReceiverDetail = {};
    }
  },
  mounted() {
      this.$watch("staffCode",()=>{
          this.listLoading = true;
          this.queryWorkorderScheduleByCareGiverCode();
      });
      //     if(this.staffCode == "2"){
      //     this.customerList=[
      //   {
      //     careReceiverName: "张三",
      //     planStartTime: "08:00",
      //     planEndTime: "09:00",
      //     weekDay: "1",
      //     monthDay: "1"
      //   },
      //   {
      //     careReceiverName: "张三",
      //     planStartTime: "09:40",
      //     planEndTime: "11:00",
      //     weekDay: "1",
      //     monthDay: "2"
      //   },
      //   {
      //     careReceiverName: "张三",
      //     planStartTime: "08:25",
      //     planEndTime: "09:25",
      //     weekDay: "2",
      //     monthDay: "3"
      //   },
      //   {
      //     careReceiverName: "张三",
      //     planStartTime: "09:40",
      //     planEndTime: "11:00",
      //     weekDay: "2",
      //     monthDay: "4"
      //   },
      //   {
      //     careReceiverName: "李四",
      //     planStartTime: "09:00",
      //     planEndTime: "10:25",
      //     weekDay: "3",
      //     monthDay: "5"
      //   },
      //   {
      //     careReceiverName: "李四",
      //     planStartTime: "11:40",
      //     planEndTime: "12:50",
      //     weekDay: "4",
      //     monthDay: "6"
      //   }
      // ];
      // }else{
      //     this.customerList=[
      //       {
      //     careReceiverName: "王五",
      //     planStartTime: "8:25",
      //     planEndTime: "10:35",
      //     weekDay: "5",
      //     monthDay: "3"
      //   },
      //   {
      //     careReceiverName: "王五",
      //     planStartTime: "10:40",
      //     planEndTime: "11:55",
      //     weekDay: "5",
      //     monthDay: "3"
      //   }];

      // }
   
    
  },
  created() {
      
  },
  updated() {
      this.tableScrollEvent();
  }

};
</script>
<style scoped>
.el-table .empty-row {
    background:#ffffff;

}
.el-table .empty-nomal-row {
    background-color:#fff909;
}
.el-table tr{
    background-color:#ffffff;
    border:none
}

</style>