<template>
  <div>
    <!-- <div style="background-color:#999;margin-left:10px;margin-right:10px"></div> -->
    <div class="line-style" style="margin-left:20px;margin-right:20px"></div>
    <el-row type="flex" style="padding:20px 20px 20px 10px" justify="space-between">
      <div style="display:flex;">
        <span style="color:#333;font-size:18px;margin:5px 10px 10px 10px">选择服务项</span>
        <el-input
          placeholder="请输入服务项序号或名称进行搜索"
          v-model="searchInputValue"
          @input="searchService"
          style="width:300px;margin-left:10px"
          size="mini"
        >
          <el-button slot="prepend" icon="el-icon-search"></el-button>
        </el-input>
      </div>
      <el-button type="primary" size="small" @click="doSelectAll()">{{!selectAll?"全选":"取消全选"}}</el-button>
    </el-row>
    <div class="service-item-container">
      <el-row v-for="(serviceList,index) in dataList" :key="index" type="flex">
        <el-col style="width:150px">
          <div class="type-name">{{serviceList[0].serviceClass+":"}}</div>
        </el-col>
        <el-row>
          <el-col v-for="(item,i) in serviceList" :key="i" class="service-item" >
            <div :class="getServiceItemClass(item)" @click="clickServiceItem(item)" :id="'item'+item.serviceCode">{{item.serviceCode+item.serviceItem}}</div>
          </el-col>
        </el-row>
      </el-row>
    </div>
    <el-row>
      <div style="color:#F37A7A;font-size:14px;margin:20px">(非必选，可为每天指定专门的服务项目)</div>
    </el-row>
  </div>
</template>

<script>
const cubic = value => Math.pow(value, 3);
const easeInOutCubic = value => value < 0.5
  ? cubic(value * 2) / 2
  : 1 - cubic((1 - value) * 2) / 2;
  import {selectProductOrderServiceList} from "api/workOrderManagement";
export default {
  props:{
    orderCode:{
      type:String,
      default:""
    }
  },
  data() {
    return {
      searchInputValue: "",
      selectAll:false,
      lastScrollTop:0,
      firstWillSelectItem:null,
      isAutoScrolling:false,
      serviceItemList: [],
      dataList: []
    };
  },
  mounted() {
    this.queryData();
    var container=document.querySelector('.service-item-container');
    container.addEventListener("scroll",this.handleScroll)
    
  },
  created(){
    
  },
  beforeDestroy(){
     document.querySelector('.service-item-container').removeEventListener("scroll",this.handleScroll)
  },
  methods: {
    queryData(){
      var params = {orderCode:this.orderCode};
      selectProductOrderServiceList(params).then(response=>{
        if (response.data.statusCode == 200) {
          this.serviceItemList=response.data.responseData;
          this.serviceItemList.forEach(item=>{
            item.isSelect=false;
            item.willSelect=false;
          });
          this.getTypeList().forEach(item => {
            this.dataList.push(
              this.serviceItemList.filter(serviceItem => {
                return serviceItem.serviceClass == item;
              })
            );
          });
        }
      }).catch(error=>{

      })
    },
    //服务项搜索
    searchService() {
      this.setItemTop();
      this.dataList.forEach(arr=>{
        arr.forEach(item=>{
          item.willSelect = false;
          if(item.serviceCode==this.searchInputValue||(this.searchInputValue&&item.serviceItem.indexOf(this.searchInputValue)!=-1)){
            item.willSelect = true;
            if(this.firstWillSelectItem==null){
              this.scrollToWillSelectItem(item);
            }
          }
        });
      });
      this.firstWillSelectItem=null;
    },
    //滚动以显示搜索项
    scrollToWillSelectItem(item){
      this.firstWillSelectItem=item;
      var willSelectElement = document.getElementById('item'+item.serviceCode);
      var beginTime = Date.now();
      var raf = window.requestAnimationFrame || (func=>setTimeout(func,16));
      var animationFunc=()=>{
        var progress = (Date.now()-beginTime)/500;
        var container = document.querySelector('.service-item-container');
        container.scrollTop = willSelectElement.myTop+(this.lastScrollTop-willSelectElement.myTop)*(1-easeInOutCubic(progress));
        if(progress<1){
          this.isAutoScrolling=true;
          raf(animationFunc)
        }else{
          container.scrollTop = willSelectElement.myTop;
          this.isAutoScrolling=false;
          this.lastScrollTop=container.scrollTop;
        }
      }
      raf(animationFunc)
    },
    handleScroll(){
      if(this.isAutoScrolling){
        return;
      }
      this.lastScrollTop= document.querySelector('.service-item-container').scrollTop;
    },
    //设置每项到容器顶部的距离
    setItemTop(){
      var containerScrollTop = document.querySelector('.service-item-container').scrollTop;
      var totalHeight=0;//项的总高度
      this.dataList.forEach((arr,i)=>{
        var heightArr=[];
        arr.forEach((item,j)=>{
          var id='item'+item.serviceCode
          var currentElement = document.getElementById(id);
          heightArr.push(currentElement.offsetTop)
          this.$set(currentElement,"myTop",totalHeight+currentElement.offsetTop);
        })
        heightArr=Array.from(new Set(heightArr));
        heightArr.forEach(item=>{
          totalHeight+=item;
        })
      })
    },
    getTypeList() {
      var typeNameList = this.serviceItemList.map(item => {
        return item.serviceClass;
      });
      return Array.from(new Set(typeNameList));
    },
    clickServiceItem(item){
      item.isSelect=!item.isSelect;
      this.$forceUpdate();
      this.setWorkorderScheduleServiceList();
      for(let i=0;i<this.dataList.length;i++){
        var arr = this.dataList[i];
        for(let j=0;j<arr.length;j++){
          if(!arr[j].isSelect){
            this.selectAll=false;
            return;
          }
        }
      }
      this.selectAll=true;
    },
    doSelectAll(){
      this.dataList.forEach(arr=>{
        arr.forEach(item=>{
          if(this.selectAll){
            item.isSelect=false;
          }else{
            item.isSelect=true;
          }
        });
      });
      this.selectAll=!this.selectAll;
      this.setWorkorderScheduleServiceList();
    },
    getServiceItemClass(item){
      if(item.isSelect){
        return 'service-item-select'
      }
      if(item.willSelect){
        return 'service-item-will-select';
      }
      return 'service-item-unselect';
    },
    setWorkorderScheduleServiceList(){
      var list=[];
      for(let i=0;i<this.dataList.length;i++){
        var arr = this.dataList[i];
        for(let j=0;j<arr.length;j++){
          if(arr[j].isSelect){
            list.push(arr[j])
          }
        }
      }
      this.$emit("setWorkorderScheduleServiceList",list);
    },
    clearSelect(){
      this.selectAll = false;
      for(let i=0;i<this.dataList.length;i++){
        var arr = this.dataList[i];
        for(let j=0;j<arr.length;j++){
          arr[j].isSelect = false;
        }
      }
      this.$forceUpdate()
    },
    doSelectByParent(list){
      if(!list){
        return
      }
      this.dataList.forEach(arr=>{
        arr.forEach(item1=>{
          item1.isSelect=false;
          this.selectAll=false;
          list.forEach(item2=>{
            if(item1.serviceCode==item2.serviceCode){
              item1.isSelect = true;
            }
          })
        })
      })
      this.$forceUpdate()
    }
  }
};
</script>

<style lang="scss" scoped>
.service-item-container {
  vertical-align:baseline;
  overflow-y: scroll;
  max-height: 200px;
  .type-name{
    width:125px;
    margin:20px 10px 0px 20px;
    color:#333;
    font-size:16px
  }
  @mixin base {
    width: 200px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    padding:5px;
    font-size: 14px;
  }
  .service-item{
   @include base; 
  }
  .service-item-select{
    @include base;
    height: 50px;
    margin: 5px;
    border: 1px dashed #398AF1;
    color: white;
    background-color: #398AF1;
  }
  .service-item-unselect{
    @include base;
    height: 50px;
    margin: 5px;
    border: 0.5px dashed #a5a5a5;
    color: #666;
    background-color: white;
  }
  .service-item-will-select{
     @include base;
    height: 50px;
    margin: 5px;
    border: 1px dashed #398AF1;
    color: #398AF1;
    background-color: white;
    font-size:16px;
  }
}
</style>