<template>
  <div id="productManagement">
    <p>待开发</p>
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
    return {
    };
  },
  watch: {},
  computed: {},
  methods: {},
  created() {},
  mounted() {}
};
</script>
<style lang="scss" scoped>
#productManagement{
 width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
</style>