<!--员工排程-->
<template>
  <div style="min-width:984px">
      <el-row type="flex" justify=”center“>
        <el-col style="max-width:280px">
          <el-form :model="searchForm" label-width="80px">
            <el-form-item label="组" >
              <el-radio-group v-model="searchForm.sideType">
                <el-radio :label="'10'">本组</el-radio>
                <el-radio :label="'20'">跨组</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="空闲时间" size="mini">
               <el-date-picker
               size="mini"
                  v-model="freeTime"
                  type="datetimerange"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  format="dd HH:mm"
                  >
                </el-date-picker>
              
            </el-form-item>
            <el-form-item label="员工岗位" prop="positionCode" size="mini">
              <el-select size="mini" v-model="searchForm.positionCode" clearable>
                <el-option label="护理员" value="GW1911270089" />
                <el-option label="护士" value="GW1911270063" />
              </el-select>
            </el-form-item>
            <el-form-item label="员工姓名" prop="staffFullName" size="mini">
              <el-input size="mini" v-model="searchForm.staffFullName" placeholder="请输入姓名" clearable/>
            </el-form-item>
            <el-row type="flex" justify="center">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="queryStaff(1)"
              >查询</el-button>
              <!-- <el-button
                size="mini"
                type="danger"
                icon="el-icon-delete"
                @click="showDeleteDialog"
                :disabled="btnDeleteDisabled"
              >删除排程</el-button> -->
            </el-row>
          </el-form>
          <div style="height:1px;background:#e0e6eb;width:95%;;margin-top:10px" />
           <div class="staffList">
          <ul  v-if="staffList&&staffList.length>0">
            <li v-for="(item,index) in staffList" :key="index" v-on:click="selectLi(item)" style="cursor:pointer;">
              <div class="itemClass" v-if="item.isSelect">
                  <div>
                  <!-- <el-checkbox v-model="item.isChecked" @change="checkStaff(item)">&nbsp;</el-checkbox> -->
                  <span style="color:#333333;font-size:16px">{{item.staffFullName}}</span>
                  <span style="margin-left:5px;color:#333333;font-size:16px">{{item.staffTel}}</span>
                  <span style="margin-left:5px;color:#333333;font-size:16px">{{item.staffGradeValue}}</span>
                  </div>
                  <div style="padding-top:5px">
                    <span style="color:#999999;margin-top:5px">{{item.orgName}}</span>
                  </div>
              </div>
              <div class="itemClassUnselect" v-if="!item.isSelect">
                  <div>
                  <!-- <el-checkbox v-model="item.isChecked" @change="checkStaff(item)">&nbsp;</el-checkbox> -->
                  <span style="color:#333333;font-size:16px">{{item.staffFullName}}</span>
                  <span style="margin-left:5px;color:#333333;font-size:16px">{{item.staffTel}}</span>
                  <span style="margin-left:5px;color:#333333;font-size:16px">{{item.staffGradeValue}}</span>
                  </div>
                  <div style="padding-top:5px">
                    <span style="color:#999999;margin-top:5px">{{item.orgName}}</span>
                  </div>
              </div>
            </li>
          </ul>
           <div v-if="!staffList || staffList.length == 0" class="no-data">
          <span >{{searchLoading?'加载中...':'暂无数据'}}</span>
          </div>
           </div>
         <!--工具条-->
              <div class="pageToolbar">
                <pagination
                  v-if="totalCount>0"
                  :total="totalCount"
                  :page.sync="searchForm.pageNum"
                  :limit.sync="searchForm.pageSize"
                  @pagination="pageChange"
                  :small="true"
                  :pagerCount="3"
                ></pagination>
              </div>
        </el-col>
        <el-col style="max-width:3px">
          <div style="width:1px;background:#e0e6eb;height:600px">&nbsp;</div>
        </el-col>
        <el-col :span="19">
          <el-row type="flex" justify="center">
            <el-col :span="2">
              <div class="timeLineClass">
                <div class="timeLineTitle">&nbsp;</div>
                <ul class="timeLineList" ref="timeLine">
                  <li v-for="(item,index) in timeLineList" :key="index" >
                    <div class="timeLineItemClass">
                      <div style="font-size:12px">{{item.name}}&nbsp;&nbsp;</div>
                      <div class="timeLineDot">&nbsp;</div>
                      <div class="timeLineVLine">&nbsp;</div>
                      <div class="timeLineDashedLine">&nbsp;</div>
                    </div>
                  </li>
                </ul>
              </div>
            </el-col>
            <el-col :span="22">
              <StaffScheduleTable
                ref="agridTable"
                :isWeekDay="isWeekDay"
                :staffCode="staffCode"
                @onTableScroll="onTableScroll"
                @gotScheduleListener ="gotScheduleListener"
              />
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-dialog
      title="删除员工排程"
      :visible.sync="deleteStaffScheduleVisible"
      :before-close="handleCloseDelete"
      center
      width="30%"
    >
      <el-row>
        <el-col>
        <el-form ref="deleteForm" :model="deleteForm" :rules="rules" >
          <el-form-item label="组织" prop="recommendOrgName">
            <el-autocomplete
              :trigger-on-focus="true"
              v-model="deleteForm.recommendOrgName"
              popper-class="my-autocomplete"
              size="mini"
              clearable
              :fetch-suggestions="queryRecommendOrgName"
              placeholder="请输入组织"
              @select="selectRecommendOrgName"
              @blur="removeRecommendOrgCode"
              @clear="removeRecommendOrgCode"
            >
              <template slot-scope="{ item }">
                <span class="name">{{ item.value }}</span>
              </template>
            </el-autocomplete>
          </el-form-item>
        </el-form>
        </el-col>
      </el-row>
      <el-row>
        <el-col><span>警告：此操作将删除该员工所有排程，</span><span style="color:red">请务必谨慎操作，是否继续？</span></el-col>
      </el-row>
       <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseDelete">取 消</el-button>
        <el-button type="primary" @click="deleteSchedule" :loading="deleteLoading">确 定</el-button>
      </span>
    </el-dialog>
    </div>
</template>

<script>
import StaffScheduleTable from "@/views/businessService/widget/StaffScheduleTableDiv";
import { selectGiverListForSchedule } from "@/api/businessService/workOrderSchedule"; //查询排程员工
import {parseTime} from "@/utils";
import {deleteByCareGiverCode} from "api/businessService/orderPaymentReview";
import { findEhrOrgList} from "api/orgStructure";
import Pagination from "components/Pagination/paginationPlus";
export default {
  props: {
    isWeekDay: {
      type: Boolean,
      default: true
    },
    staffScheduleVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      staffList: [],
      timeLineList: [],
      staffCode: "",
      checkedStaffCode:"",
      totalCount:0,
      searchForm: {
        serviceFrequencyType: "20", //服务频次类型（10：周，20：月）
        positionCode: "", //岗位CODE
        planStartDate: "", //开始时间
        planEndDate: "", //结束时间
        staffFullName: "", //照护人名字
        sideType: "10", //10本组，20跨组
        orgCode: this.$store.getters.userOrgCode, 
        pageSize: 20,
        pageNum: 1
      },
      searchLoading:false,
      filterSelect:"",
      timeRange:"",
      freeTime: [],
      btnDeleteDisabled:true,
      deleteLoading:false,
      deleteStaffScheduleVisible: false,
      rules: {
          recommendOrgName: [
            { required: true, message: "组织不能为空", trigger: "change" }
          ]
        },
      recommendOrg:[],
      deleteForm:{
        recommendOrgName:"",
        recommendOrgCode:""
      },
    };
  },
  methods: {
    handleClose() {
      this.$emit("onStaffScheduleClose");
    },
    handleCloseDelete() {
      this.deleteStaffScheduleVisible = false;
      this.deleteForm.recommendOrgName ="";
      this.deleteForm.recommendOrgCode = "";
    },
    selectLi(item) {
      this.btnDeleteDisabled = true;
      for (let i = 0; i < this.staffList.length; i++) {
        if (this.staffList[i].staffCode == item.staffCode) {
          this.staffList[i].isSelect = true;
        } else {
          this.staffList[i].isSelect = false;
        }
        this.staffList[i].isChecked = false;
      }
      this.staffCode = item.staffCode;
      this.$refs["agridTable"].refreshTable(this.staffCode)
    },
    onTableScroll(val) {
      if (this.$refs.timeLine) {
        this.$refs.timeLine.scrollTop = val;
      }
    },
    clickFn() {},
    queryStaff(pageNum) {
      this.searchForm.pageNum=pageNum
      this.searchLoading = true;
      this.btnDeleteDisabled = true;
      this.staffList = [];
      if(this.freeTime&&this.freeTime.length>0){
        let startTime = parseTime(this.freeTime[0]);
        let endTime = parseTime(this.freeTime[1]);
        this.searchForm.planStartDate = startTime;
        this.searchForm.planEndDate = endTime;
      }else{
        this.searchForm.planStartDate = "";
        this.searchForm.planEndDate = "";
      }
      this.searchForm.serviceFrequencyType = this.isWeekDay?"10":"20";
      selectGiverListForSchedule(this.searchForm)
        .then(response => {
          this.searchLoading = false;
          if (response.data.statusCode == "200") {
            if (response.data.responseData) {
              this.staffList = response.data.responseData;
               this.totalCount = response.data.totalCount;
              this.staffList.forEach(item => {
                item.isSelect = false;
                item.isChecked = false;
              });
            }
          } else {
            this.$message.error(reponse.data.statusMsg);
            this.staffList = [];
          }
        })
        .catch(error => {
          this.searchLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
          this.staffList = [];
        });
    },
    deleteSchedule(){
      this.$refs['deleteForm'].validate(valid => {
        if(valid){
          var params = { 
        careGiverCode: this.staffCode,
        orgCode:this.deleteForm.recommendOrgCode
         };
      deleteByCareGiverCode(params)
        .then(response => {
          this.deleteLoading = false;
          if (response.data.statusCode == "200") {
            this.$refs["agridTable"].refreshTable(this.staffCode);
            this.$message.success(response.data.statusMsg);
          } else {
            this.$message.error(reponse.data.statusMsg);
          }
          this.handleCloseDelete();
        })
        .catch(error => {
          this.deleteLoading = false;
          this.$message.error(this.ConstantData.requestErrorMsg);
        });
        }
      })
    },
    checkStaff(item){
      for (let i = 0; i < this.staffList.length; i++) {
        if (this.staffList[i].staffCode == item.staffCode) {
          this.staffList[i].isChecked = true;
        } else {
          this.staffList[i].isChecked = false;
        }
      }
      this.checkedStaffCode = item.staffCode;
    },
    gotScheduleListener(val,staffCode){
      var obj = this.staffList.find(item=>{
        return staffCode == item.staffCode
      });
      if(obj){
          if(obj.isChecked){
            this.btnDeleteDisabled = val;
          }
      }
    },
    selectRecommendOrgName(item) {
      if (item.value !== "无") {
        this.deleteForm.recommendOrgCode = item.code;
        this.deleteForm.recommendOrgName = item.value;
      } else {
        this.deleteForm.recommendOrgName = "";
      }
    },
    removeRecommendOrgCode() {
      this.deleteForm.recommendOrgName = "";
      this.deleteForm.recommendOrgCode = "";
    },
    queryRecommendOrgName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        orgName: queryString
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.recommendOrg = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.recommendOrg.push({
                value: data[i].orgName,
                code: data[i].orgCode
              });
            }
            var results = this.recommendOrg;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    queryOrgInit() {
      let params = {
        pageNum: 1,
        pageSize: 10,
        orgName: ""
      };
      findEhrOrgList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            var data = response.data.responseData;
            if(data && data.length == 1){
              this.deleteForm.recommendOrgCode = data[0].orgCode;
              this.deleteForm.recommendOrgName = data[0].orgName;
            }
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    showDeleteDialog(){
      this.deleteStaffScheduleVisible=!this.deleteStaffScheduleVisible
      this.queryOrgInit()
    },
    //父组件触发事件
    pageChange(val) {
      this.searchForm.pageNum = val.page;
      this.searchForm.pageSize = val.limit;
      this.queryStaff(val.page); 
    },
  },
  components: {
    StaffScheduleTable,
    Pagination
  },
  mounted() {
    for (let i = 0; i <= 24; i++) {
      let timePrefix = i < 10 ? "0" + i : i;
      if(i>24){
          this.timeLineList.push({ name:"" });
      }else{
          this.timeLineList.push({ name: timePrefix + ":00" });
      }
      
    }
    // this.searchForm.sideType = "10"
    // this.freeTime =[new Date(), new Date()];
  },
  created() {
    this.queryOrgInit()
  },
  updated() {}
};
</script>
<style scoped>
.el-input,
.el-select {
  width: 170px;
}
.staffList {
  margin: 0;
  padding: 0;
  list-style: none;
  height: 310px;
  overflow-y: auto;
}
.timeLineList {
  margin: 0.5px;
  padding: 0;
  list-style: none;
  height: 576px;
  overflow-y: hidden;
}

.staffList li {
  margin: 0;
  padding: 0;
  list-style: none;
}
.timeLineList li {
  margin: 0;
  padding: 0;
  list-style: none;
}
.skill li {
  font-size: 18px;
  line-height: 2rem;
  height: 2rem;
  padding-left: 5px;
  cursor: pointer;
}
.itemClass {
  background: #dae8fa;
  padding: 10px 20px 10px 20px;
  text-align: left;
  color: #666666;
  border-top: 1px dashed #f2f0f0;
  border-bottom: 1px dashed #f2f0f0;
}
.itemClassUnselect {
  background: #ffffff;
  padding: 10px 20px 10px 20px;
  text-align: left;
  color: #666666;
  border-top: 1px dashed #f2f0f0;
  border-bottom: 1px dashed #f2f0f0;
}
.timeLineTitle {
  text-align: right;
  height: 20px;
  margin-right: 10px;
  padding-top: 10px;
}
.timeLineClass {
  text-align: right;
}
.timeLineItemClass {
  height: 45px;
  display: flex;
  justify-content: flex-end;
}
.timeLineDot {
  width: 12px;
  height: 12px;
  background: #f9aa70;
  border-radius: 50%;
  margin-right: -7px;
}
.timeLineVLine {
  width: 2px;
  height: 60px;
  background-color: #f9aa70;
  margin-right: 6px;
}
.timeLineDashedLine {
  width: 20px;
  height: 2;
  border-top: 0.75px dashed #e6e8ea;
  margin-top: 6px;
}
.el-date-editor--datetimerange.el-input, .el-date-editor--datetimerange.el-input__inner{
  width: 170px;
  min-width: 170px;
}
.no-data{
  color:#999999;
  padding:20px;
  text-align:center;
}
.pageToolbar {
  padding: 0px;
  margin-right: -5px;
  text-align: right;
  background: #fff;
  float:right;
  margin-top: 5px;
}
</style>

