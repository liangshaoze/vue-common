<template>
  <div id="orderManage">
    <headTag :tagName="tagName"/>

    <div class="main-content">
      <el-form
        ref="orderForm"
        :inline="false"
        :model="orderForm"
        :rules="orderFormRules"
        label-width="180px"
        class="form-content"
      >
        <div class="panel-card">
          <el-row class="importToolbar">
            <el-col :span="24">
              <span class="form-tag">被照护人信息</span>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                style="margin-left:5px;"
                @click="returnOrderList"
              >返回</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="saveCareReceiver('orderForm')"
                :loading="loadingBtn"
                v-if="flag"
              >保存</el-button>
              <el-button
                type="primary"
                size="mini"
                class="rightBtn"
                @click="editStaff()"
                v-if="!flag"
              >修改</el-button>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item-org">
              <el-form-item label="组织" prop="orgName">
                <span v-if="isEdit == false">{{orderForm.orgName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    size="mini"
                    v-model.trim="orderForm.orgName"
                    placeholder="请选择组织"
                    @focus="dialogVisibleOrg=true"
                    @clear="clearOrgCode"
                    clearable
                  ></el-input>

                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身份证号" prop="careReceiverIdCard">
                <span v-if="isEdit == false">{{orderForm.careReceiverIdCard}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    id="idCard"
                    v-model="orderForm.careReceiverIdCard"
                    size="mini"
                    @blur="validatorIdCard(orderForm.careReceiverIdCard)"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请输入身份证号"
                    maxlength="18"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="姓名" prop="careReceiverName">
                <span v-if="isEdit == false">{{orderForm.careReceiverName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverName"
                    size="mini"
                    clearable
                    placeholder="请输入姓名"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="出生年月" prop="careReceiverBirthday">
                <span v-if="isEdit == false">{{orderForm.careReceiverBirthday}}</span>
                <span v-if="isEdit == true">
                  <el-input v-model="orderForm.careReceiverBirthday" size="mini" :disabled="true"></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="性别" prop="careReceiverGender">
                <span v-if="isEdit == false">{{orderForm.careReceiverGenderValue}}</span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverGender"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in genderOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="联系方式" prop="careReceiverTel">
                <span v-if="isEdit == false">{{orderForm.careReceiverTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住省市区" prop="liveDistrictName">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.liveDistrictName"
                    class="long-field"
                  >{{orderForm.liveProvinceName}}/{{orderForm.liveCityName}}/{{orderForm.liveDistrictName}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-cascader
                    v-model="live"
                    placeholder="请选择现居住省市区"
                    size="mini"
                    :options="liveOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeLive"
                    @change="addLiveToForm"
                    @visible-change="changeLive"
                    ref="liveList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住街道" prop="liveSubdistrictName">
                <span v-if="isEdit == false">{{orderForm.liveSubdistrictName}}</span>
                <span v-if="isEdit == true">
                  <el-select
                    size="mini"
                    v-model="orderForm.liveSubdistrictName"
                    placeholder="请选择街道"
                    @change="selectDistrict(orderForm.liveSubdistrictName)"
                  >
                    <el-option
                      v-for="item in subdistrict"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                <span v-if="isEdit == false" class="long-field">{{orderForm.liveDetailAddress}}</span>
                <span v-if="isEdit == true">
                  <el-tooltip
                    class="item"
                    effect="dark"
                    :disabled="orderForm.liveDetailAddress == '' ? true : false"
                    :content="orderForm.liveDetailAddress"
                    placement="top"
                  >
                    <el-input
                      v-model="orderForm.liveDetailAddress"
                      @focus="openMap"
                      size="mini"
                      clearable
                      placeholder="请输入现居住详细地址"
                      maxlength="50"
                    />
                  </el-tooltip>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="民族" prop="careReceiverNation">
                <span v-if="isEdit == false">{{orderForm.careReceiverNation}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverNation"
                    size="mini"
                    clearable
                    placeholder="请输入民族"
                    maxlength="20"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="籍贯" prop="nativePlace">
                <span v-if="isEdit == false" class="long-field">{{orderForm.nativePlace}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.nativePlace"
                    size="mini"
                    clearable
                    placeholder="籍贯"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍省市区" prop="houseDistrictName">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.houseDistrictName"
                    class="long-field"
                  >{{orderForm.houseProvinceName}}/{{orderForm.houseCityName}}/{{orderForm.houseDistrictName}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-cascader
                    v-model="house"
                    placeholder="请选择户籍省市区"
                    size="mini"
                    :options="houseOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeHouse"
                    @change="addHouseToForm"
                    @visible-change="changeHouse"
                    ref="houseList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                <span v-if="isEdit == false" class="long-field">{{orderForm.houseDetailAddress}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.houseDetailAddress"
                    size="mini"
                    clearable
                    placeholder="请输入户籍详细地址"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="政治面貌" prop="careReceiverPolitical">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.careReceiverPoliticalValue"
                  >{{orderForm.careReceiverPoliticalValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverPolitical"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in politicalOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="最高学历" prop="careReceiverEducation">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.careReceiverEducationValue"
                  >{{orderForm.careReceiverEducationValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverEducation"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in educationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="婚姻状况" prop="maritalStatus">
                <span v-if="isEdit == false">
                  <span v-if="orderForm.maritalStatusValue">{{orderForm.maritalStatusValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.maritalStatus"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in maritalStatusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="医保类型" prop="medicalType">
                <span v-if="isEdit == false">
                  <span v-if="orderForm.medicalTypeValue">{{orderForm.medicalTypeValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.medicalType"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in mediacalTypeOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="医保卡号">
                <span v-if="isEdit == false">
                  <span v-if="orderForm.medicalCardNo">{{orderForm.medicalCardNo}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.medicalCardNo"
                    size="mini"
                    clearable
                    placeholder="请输入医保卡号"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="宗教信仰" prop="careReceiverFaith">
                <span v-if="isEdit == false">
                  <span v-if="orderForm.careReceiverFaithValue">{{orderForm.careReceiverFaithValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverFaith"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in faithOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身体损伤" prop="physicalDamage">
                <span v-if="isEdit == false">
                  <span v-if="orderForm.physicalDamageValue">{{orderForm.physicalDamageValue}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.physicalDamage"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in physicalInjuryOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-product">
              <el-form-item label="身份证照片">
                <el-upload
                  ref="uploadBrief"
                  :class="{hideBriefImg:hideBriefUpload}"
                  :action="actionUrl"
                  list-type="picture-card"
                  :on-success="handleBriefChange"
                  accept="image/png, image/gif, image/jpg, image/jpeg"
                  multiple
                  :limit="2"
                  :file-list="idCardFileList"
                >
                  <i class="el-icon-plus"></i>
                  <div slot="file" slot-scope="{file}">
                    <img class="el-upload-list__item-thumbnail" :src="file.url" alt>
                    <span class="el-upload-list__item-actions">
                      <span
                        class="el-upload-list__item-preview"
                        @click="handlePictureCardPreview(file)"
                      >
                        <i class="el-icon-zoom-in"></i>
                      </span>
                      <span class="el-upload-list__item-delete" @click="handleDownload(file)">
                        <i class="el-icon-download"></i>
                      </span>
                      <span
                        v-if="!disabled"
                        class="el-upload-list__item-delete"
                        @click="handleRemove(file)"
                      >
                        <i class="el-icon-delete"></i>
                      </span>
                    </span>
                  </div>
                  <span v-if="!disabled">
                    <div class="el-upload__tip">仅限上传2张图片！</div>
                  </span>
                </el-upload>
                <el-dialog :visible.sync="dialogVisible">
                  <el-image style="width: 100%; height: 600px" :src="dialogImageUrl"></el-image>
                </el-dialog>
                <span v-if="idCardFileList.length > 0">
                  <div v-for="file in idCardFileList">
                    <el-tooltip
                      class="itemToptip"
                      effect="dark"
                      :content="file.name"
                      placement="bottom"
                    >
                      <div>{{file.name}}</div>
                    </el-tooltip>
                  </div>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-for="(item, index) in orderForm.careReceiverFamilyList" :key="item.key">
            <el-col class="form-item-table">
              <el-form-item
                label="紧急联系人"
                :prop="'careReceiverFamilyList.' + index + '.familyMemberName'"
                :rules="orderFormRules.familyMemberName"
              >
                <span v-if="isEdit == false">{{item.familyMemberName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="item.familyMemberName"
                    size="mini"
                    maxlength="20"
                    clearable
                    placeholder="请输入紧急联系人"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-table">
              <el-form-item
                label="联系方式"
                :prop="'careReceiverFamilyList.' + index + '.contactsTel'"
                :rules="orderFormRules.contactsTel"
              >
                <span v-if="isEdit == false">{{item.contactsTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="item.contactsTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-table">
              <el-form-item
                label="是联系人的谁"
                :prop="'careReceiverFamilyList.' + index + '.relationship'"
              >
                <span v-if="isEdit == false">{{item.relationshipValue}}</span>
                <span v-if="isEdit == true">
                  <el-select v-model="item.relationship" size="mini" clearable placeholder="请选择">
                    <el-option
                      v-for="item in relationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-tables">
              <el-form-item label="是否是监护人">
                <span v-if="isEdit == false">{{item.isGuardianValue}}</span>
                <span v-if="isEdit == true">
                  <el-select v-model="item.isGuardian" size="mini" clearable placeholder="请选择">
                    <el-option
                      v-for="item in isGuardianOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                  <span v-if="index > 0">
                    <el-button
                      type="danger"
                      size="mini"
                      icon="el-icon-delete"
                      style="margin-left:5px;"
                      circle
                      v-if="flag"
                      @click="removeContacts(item)"
                    ></el-button>
                  </span>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item>
                <el-button
                  type="primary"
                  icon="el-icon-circle-plus"
                  size="mini"
                  v-if="flag"
                  @click="addContacts('orderForm')"
                >新增紧急联系人</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <!-- <el-col class="form-item">
              <el-form-item label="推荐组织">
                <span v-if="isEdit == false">{{orderForm.recommendOrgName}}</span>
                <span v-if="isEdit == true">
                  <el-autocomplete
                    :trigger-on-focus="true"
                    v-model="orderForm.recommendOrgName"
                    popper-class="my-autocomplete"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryRecommendOrgName"
                    placeholder="请输入组织"
                    @select="selectRecommendOrgName"
                    @blur="removeRecommendOrgCode"
                    @clear="removeRecommendOrgCode"
                  >
                    <template slot-scope="{ item }">
                      <span class="name">{{ item.value }}</span>
                    </template>
                  </el-autocomplete>
                </span>
              </el-form-item>
            </el-col> -->
            <el-col class="form-item">
              <el-form-item label="推荐人">
                <span v-if="isEdit == false">{{orderForm.recommendName}}</span>
                <span v-if="isEdit == true">
                  <el-autocomplete
                    :trigger-on-focus="true"
                    v-model="orderForm.recommendName"
                    popper-class="my-autocomplete"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryStaffName"
                    placeholder="请输入员工姓名"
                    @select="selectStaffName"
                    @blur="removeStaffCode"
                  >
                    <template slot-scope="{ item }">
                      <span class="name">
                        {{ item.value }}
                        <span v-if="item.value != '无'">({{ item.staffTel }})</span>
                      </span>
                    </template>
                  </el-autocomplete>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="推荐时间" prop="recommendDate">
                <span v-if="isEdit == false">{{orderForm.recommendDate}}</span>
                <span v-if="isEdit == true">
                  <el-date-picker
                    v-model="orderForm.recommendDate"
                    size="mini"
                    type="date"
                    value-format="yyyy-MM-dd"
                    clearable
                    placeholder="请选择推荐时间"
                  ></el-date-picker>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="提供人" prop="provideName">
                <span v-if="isEdit == false">{{orderForm.provideName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.provideName"
                    size="mini"
                    clearable
                    placeholder="请输入提供人"
                    maxlength="20"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </el-form>

      <!-- 组织架构-弹窗-->
      <el-dialog
        title="组织架构"
        :visible.sync="dialogVisibleOrg"
        width="500px"
        :before-close="handleClose"
      >
        <org-select v-on:listenTochildEvent="getCurrentNode"/>
      </el-dialog>

      <map-point
        v-if="this.showMap"
        @GetMapPoint="getAddressDetail"
        @closeDialog="closeDialog"
        :placeholder="'请输入现居住详细地址'"
        :maxLength="50"
        :address="orderForm.liveDetailAddress"
        :provinceAddress="orderForm.liveProvinceName"
        :cityAddress="orderForm.liveCityName"
        :districtAddress="orderForm.liveDistrictName"
        :liveLongitude="orderForm.liveLongitude"
        :liveLatitude="orderForm.liveLatitude"
      ></map-point>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import FileUpload from "components/FileUpload";
import MapPoint from "components/MapPoint";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { findStaffList, findStaffAll } from "api/customerManagement";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail
} from "@/utils/validate";
import {
  insertEtCareReceiverAll,
  editEtCareReceiverAll,
  findCareReceiver
} from "api/businessService/careReceiver";
import {
getCareReceiverAuthority
} from "api/orderManagement";
import { findEhrOrgAll } from "api/orgStructure";
export default {
  data() {
    return {
      tagName: "新增被照护人",
      //控制修改/保存
      flag: true,
      //是否可编辑
      isEdit: true,
      //修改禁用项
      isDisabled: false,
      //控制地图弹窗
      showMap: false,
      //产品名称加载
      loading: false,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      //身份证上传
      idCardFileList: [],
      hideBriefUpload: true,
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: true,
      //选择组织弹窗
      dialogVisibleOrg: false,
      //保存/修改加载控制
      loadingBtn: false,
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      orderForm: {
        careReceiverNation: "汉",
        orgName: this.$store.getters.userOrgName ? this.$store.getters.userOrgName : '',
        orgCode: this.$store.getters.userOrgCode ? this.$store.getters.userOrgCode : '',
        careReceiverCode: "",
        careReceiverName: "",
        careReceiverGender: "",
        careReceiverGenderValue: "",
        careReceiverBirthday: "",
        careReceiverIdCard: "",
        careReceiverIdCardPhoto: "",
        careReceiverTel: "",
        nativePlace: "",
        houseProvinceCode: "",
        houseProvinceName: "",
        houseCityCode: "",
        houseCityName: "",
        houseDistrictCode: "",
        houseDistrictName: "",
        houseDetailAddress: "",
        liveProvinceCode: "",
        liveProvinceName: "",
        liveCityCode: "",
        liveCityName: "",
        liveDistrictCode: "",
        liveDistrictName: "",
        liveSubdistrictCode: "",
        liveSubdistrictName: "",
        liveDetailAddress: "",
        liveLongitude: "",
        liveLatitude: "",
        careReceiverPolitical: "",
        careReceiverPoliticalValue: "",
        careReceiverEducation: "",
        careReceiverEducationValue: "",
        maritalStatus: "",
        maritalStatusValue: "",
        medicalType: "",
        medicalTypeValue: "",
        medicalCardNo: "",
        careReceiverFaith: "",
        careReceiverFaithValue: "",
        physicalDamage: "",
        physicalDamageValue: "",
        careReceiverFamilyList: [
          {
            careReceiverCode: "",
            familyMemberName: "",
            contactsTel: "",
            relationship: "",
            relationshipValue: "",
            isGuardian: "0"
          }
        ],
        recommendDate: "",
        recommendCode: "",
        recommendName: "",
        recommendTel: "",
        recommendOrgName: "",
        recommendOrgCode: "",
        careProviderGender: "",
        careProviderGenderValue: "",
        serviceStartDate: "",
        serviceEndDate: "",
        serviceLongTime: "",
        provideName: "",
        remark: ""
      },
      //验证
      orderFormRules: {
        orgName: [
          {
            required: true,
            message: "请输入组织",
            trigger: "change"
          }
        ],
        careReceiverName: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        careReceiverIdCard: [
          {
            required: true,
            message: "请输入身份证号",
            trigger: "blur"
          },
          {
            required: true, 
            trigger: 'blur',
            validator: validateIdCard
          }
        ],
        careReceiverBirthday: [
          {
            required: true,
            message: "请输入出生年月",
            trigger: "change"
          }
        ],
        careReceiverGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        careReceiverTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          }
        ],
        houseDistrictName: [
          {
            required: true,
            message: "请选择户籍省市区",
            trigger: "change"
          }
        ],
        houseDetailAddress: [
          {
            required: true,
            message: "请输入户籍详细地址",
            trigger: "blur"
          }
        ],
        liveDistrictName: [
          {
            required: true,
            message: "请选择现居住省市区",
            trigger: "change"
          }
        ],
        liveSubdistrictName: [
          {
            required: true,
            message: "请选择现居住街道",
            trigger: "change"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "change"
          }
        ]
      },
      //推荐人
      recommend: [],
      //推荐组织
      recommendOrg: [],
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载现居住省市区
      liveOptions: [],
      live: [],
      liveName: [],
      //动态加载街道
      subdistrict: [],
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      genderOptions: [],
      //政治面貌
      politicalOptions: [],
      //最高学历
      educationOptions: [],
      //婚姻状况
      maritalStatusOptions: [],
      //医保类型
      mediacalTypeOptions: [],
      //宗教信仰
      faithOptions: [],
      //身体损伤
      physicalInjuryOptions: [],
      //联系人关系
      relationOptions: [],
      //是否是监护人
      isGuardianOptions: [],
      /**
       *
       * 页面传参
       *
       */
      careReceiverCode: ""
    };
  },
  components: {
    HeadTag,
    FileUpload,
    MapPoint,
    OrgSelect
  },
  methods: {
    /**
     *
     * 新增被照护人信息
     *
     *
     */
    saveCareReceiver(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loadingBtn = true;
          //紧急联系人如果三项都没有填写直接移除
          if (this.orderForm.careReceiverFamilyList.length > 0) {
            var list = this.orderForm.careReceiverFamilyList;
            for (let i = 0; i < list.length; i++) {
              if (
                list[i].familyMemberName == "" &&
                list[i].contactsTel == "" &&
                list[i].relationship == "" &&
                list[i].isGuardian
              ) {
                this.orderForm.careReceiverFamilyList.splice(i, 1);
                i = 0;
              }
            }
          }
          var params = {
            //组织和服务信息
            orgCode: this.orderForm.orgCode,
            orgName: this.orderForm.orgName,
            careReceiverName: this.orderForm.careReceiverName,
            careReceiverGender: this.orderForm.careReceiverGender,
            careReceiverBirthday: this.orderForm.careReceiverBirthday,
            careReceiverIdCard: this.orderForm.careReceiverIdCard,
            careReceiverIdCardPhoto: this.orderForm.careReceiverIdCardPhoto,
            careReceiverTel: this.orderForm.careReceiverTel,
            careReceiverNation: this.orderForm.careReceiverNation,
            nativePlace: this.orderForm.nativePlace,
            houseProvinceCode: this.orderForm.houseProvinceCode,
            houseProvinceName: this.orderForm.houseProvinceName,
            houseCityCode: this.orderForm.houseCityCode,
            houseCityName: this.orderForm.houseCityName,
            houseDistrictCode: this.orderForm.houseDistrictCode,
            houseDistrictName: this.orderForm.houseDistrictName,
            houseDetailAddress: this.orderForm.houseDetailAddress,
            liveProvinceCode: this.orderForm.liveProvinceCode,
            liveProvinceName: this.orderForm.liveProvinceName,
            liveCityCode: this.orderForm.liveCityCode,
            liveCityName: this.orderForm.liveCityName,
            liveDistrictCode: this.orderForm.liveDistrictCode,
            liveDistrictName: this.orderForm.liveDistrictName,
            liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
            liveSubdistrictName: this.orderForm.liveSubdistrictName,
            liveDetailAddress: this.orderForm.liveDetailAddress,
            liveLongitude: this.orderForm.liveLongitude,
            liveLatitude: this.orderForm.liveLatitude,
            careReceiverPolitical: this.orderForm.careReceiverPolitical,
            careReceiverEducation: this.orderForm.careReceiverEducation,
            maritalStatus: this.orderForm.maritalStatus,
            medicalType: this.orderForm.medicalType,
            medicalCardNo: this.orderForm.medicalCardNo,
            careReceiverFaith: this.orderForm.careReceiverFaith,
            physicalDamage: this.orderForm.physicalDamage,
            serviceStartDate: this.orderForm.serviceStartDate,
            serviceEndDate: this.orderForm.serviceEndDate,
            careProviderGender: this.orderForm.careProviderGender,
            recommendDate: this.orderForm.recommendDate,
            recommendCode: this.orderForm.recommendCode,
            recommendName: this.orderForm.recommendName,
            recommendOrgCode: this.orderForm.recommendOrgCode,
            recommendOrgName: this.orderForm.recommendOrgName,
            provideName: this.orderForm.provideName,
            remark: this.orderForm.remark,
            //紧急联系人
            familyInDtoList: this.orderForm.careReceiverFamilyList
          };
          if(this.careReceiverCode) {
              params.careReceiverCode = this.careReceiverCode;
              editEtCareReceiverAll(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("修改成功");
                    this.loadingBtn = false;
                    this.isEdit = false;
                    this.flag = false;
                    this.disabled = true;
                    this.hideBriefUpload = true;
                    this.getOrderDetail();
                } else {
                    this.$message.error(response.data.statusMsg);
                    this.loadingBtn = false;
                    return false;
                }
                })
                .catch(error => {
                  console.log("editEtCareReceiverAll:" + error);
                  this.loadingBtn = false;
                  return false;
                });
          } else {
            insertEtCareReceiverAll(params)
                .then(response => {
                if (
                    response.data.statusCode == "200" ||
                    response.data.statusCode == 200
                ) {
                    this.$message.success("新增成功");
                    this.$router.push({
                    path: "/businessServiceManagement/careReceiverList"
                    });
                } else {
                    this.$message.error(response.data.statusMsg);
                    return false;
                }
                })
                .catch(error => {
                console.log("insertEtCareReceiverAll:" + error);
                return false;
                });
          }
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 查询被照护人信息
     *
     */
    getOrderDetail() {
      var param = {
        careReceiverCode: this.careReceiverCode
      }; //TODO
      findCareReceiver(param)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.orderInfo = response.data.responseData;
            //组织和服务信息
            if (this.orderInfo.careReceiverIdCardPhoto) {
              let photoUrl = this.orderInfo.careReceiverIdCardPhoto;
              this.idCardFileList = [];
              let photos = photoUrl.split(",");
              if (photos.length == 2) {
                this.hideBriefUpload = true;
              }
              for (let i = 0; i < photos.length; i++) {
                this.idCardFileList.push({
                  name: decodeURI(photos[i])
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18),
                  url: photos[i]
                });
              }
            }
            this.orderForm.orgCode = this.orderInfo.orgUnitCode;
            this.orderForm.orgName = this.orderInfo.orgUnitName;
            this.orderForm.careReceiverCode = this.orderInfo.careReceiverCode;
            this.orderForm.careReceiverName = this.orderInfo.careReceiverName;
            this.orderForm.careReceiverGender = this.orderInfo.careReceiverGender;
            this.orderForm.careReceiverGenderValue = this.orderInfo.careReceiverGenderValue;
            this.orderForm.careReceiverBirthday = this.orderInfo.careReceiverBirthday;
            this.orderForm.careReceiverIdCard = this.orderInfo.careReceiverIdCard;
            this.orderForm.careReceiverIdCardPhoto = this.orderInfo.careReceiverIdCardPhoto;
            this.orderForm.careReceiverTel = this.orderInfo.careReceiverTel;
            this.orderForm.careReceiverNation = this.orderInfo.careReceiverNation;
            this.orderForm.nativePlace = this.orderInfo.nativePlace;
            this.orderForm.houseProvinceCode = this.orderInfo.houseProvinceCode;
            this.orderForm.houseProvinceName = this.orderInfo.houseProvinceName;
            this.orderForm.houseCityCode = this.orderInfo.houseCityCode;
            this.orderForm.houseCityName = this.orderInfo.houseCityName;
            this.orderForm.houseDistrictCode = this.orderInfo.houseDistrictCode;
            this.orderForm.houseDistrictName = this.orderInfo.houseDistrictName;
            this.orderForm.houseDetailAddress = this.orderInfo.houseDetailAddress;
            this.orderForm.liveProvinceCode = this.orderInfo.liveProvinceCode;
            this.orderForm.liveProvinceName = this.orderInfo.liveProvinceName;
            this.orderForm.liveCityCode = this.orderInfo.liveCityCode;
            this.orderForm.liveCityName = this.orderInfo.liveCityName;
            this.orderForm.liveDistrictCode = this.orderInfo.liveDistrictCode;
            this.orderForm.liveDistrictName = this.orderInfo.liveDistrictName;
            this.orderForm.liveSubdistrictCode = this.orderInfo.liveSubdistrictCode;
            this.orderForm.liveSubdistrictName = this.orderInfo.liveSubdistrictName;
            this.orderForm.liveDetailAddress = this.orderInfo.liveDetailAddress;
            this.orderForm.liveLongitude = this.orderInfo.liveLongitude;
            this.orderForm.liveLatitude = this.orderInfo.liveLatitude;
            this.orderForm.careReceiverPolitical = this.orderInfo.careReceiverPolitical;
            this.orderForm.careReceiverPoliticalValue = this.orderInfo.careReceiverPoliticalValue;
            this.orderForm.careReceiverEducation = this.orderInfo.careReceiverEducation;
            this.orderForm.careReceiverEducationValue = this.orderInfo.careReceiverEducationValue;
            this.orderForm.maritalStatus = this.orderInfo.maritalStatus;
            this.orderForm.maritalStatusValue = this.orderInfo.maritalStatusValue;
            this.orderForm.medicalType = this.orderInfo.medicalType;
            this.orderForm.medicalTypeValue = this.orderInfo.medicalTypeValue;
            this.orderForm.medicalCardNo = this.orderInfo.medicalCardNo;
            this.orderForm.careReceiverFaith = this.orderInfo.careReceiverFaith;
            this.orderForm.careReceiverFaithValue = this.orderInfo.careReceiverFaithValue;
            this.orderForm.physicalDamage = this.orderInfo.physicalDamage;
            this.orderForm.physicalDamageValue = this.orderInfo.physicalDamageValue;
            //组织和服务信息
            this.orderForm.visitDate = this.orderInfo.visitDate;
            this.orderForm.careProviderGender = this.orderInfo.careProviderGender;
            this.orderForm.recommendDate = this.orderInfo.recommendDate;
            this.orderForm.recommendCode = this.orderInfo.recommendCode;
            this.orderForm.recommendName = this.orderInfo.recommendName;
            // this.orderForm.recommendOrgCode = this.orderInfo.recommendOrgCode;
            // this.orderForm.recommendOrgName = this.orderInfo.recommendOrgName;
            this.orderForm.provideName = this.orderInfo.provideName;
            this.orderForm.remark = this.orderInfo.remark;
            this.orderForm.liveLongitude = this.orderInfo.liveLongitude;
            this.orderForm.liveLatitude = this.orderInfo.liveLatitude;
            var familyList = this.orderInfo.careReceiverFamilyList;
            var list = [];
            if (familyList.length > 0) {
              for (let i = 0; i < familyList.length; i++) {
                list.push({
                  careReceiverCode: familyList[i].careReceiverCode,
                  contactsTel: familyList[i].contactsTel,
                  familyMemberName: familyList[i].familyMemberName,
                  relationship: familyList[i].relationship,
                  relationshipValue: familyList[i].relationshipValue,
                  isGuardian: familyList[i].isGuardian,
                  isGuardianValue: familyList[i].isGuardianValue
                });
              }
            } else {
              list.push({
                careReceiverCode: "",
                contactsTel: "",
                familyMemberName: "",
                relationship: "",
                relationshipValue: "",
                isGuardian: "0",
                isGuardianValue: ""
              });
            }
            this.orderForm.careReceiverFamilyList = list;
            this.$nextTick(() => {
              if (this.flag == true) {
                this.$refs[
                  "houseList"
                ].inputValue = this.orderForm.houseDistrictName;
                this.$refs[
                  "liveList"
                ].inputValue = this.orderForm.liveSubdistrictName;
              }
            });
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findCareReceiver:" + error);
        });
    },
    //加载户籍省市区
    getHouseNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.houseOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //户籍选择下拉框
    handleExpandChangeHouse(val) {
      this.getHouseNodes(val);
    },
    //将户籍省市区注入到Form中
    addHouseToForm(val) {
      this.house = val;
      this.houseName = this.$refs["houseList"].getCheckedNodes();
      this.orderForm.houseProvinceCode = this.house[0];
      this.orderForm.houseProvinceName = this.houseName[0].pathLabels[0];
      this.orderForm.houseCityCode = this.house[1];
      this.orderForm.houseCityName = this.houseName[0].pathLabels[1];
      this.orderForm.houseDistrictCode = this.house[2];
      this.orderForm.houseDistrictName = this.houseName[0].pathLabels[2];
    },
    changeHouse(val) {
      this.$refs["houseList"].presentText = "";
      if (!val) {
        this.$refs["houseList"].inputValue = this.orderForm.houseDistrictName;
        this.$refs["houseList"].presentText = this.orderForm.houseDistrictName;
      }
    },
    //加载本市地址
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      } else if (val.length === 3) {
        idArea = val[2];
        sizeArea = val.length; //三级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.orderForm.liveProvinceCode = this.live[0];
      this.orderForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.orderForm.liveCityCode = this.live[1];
      this.orderForm.liveCityName = this.liveName[0].pathLabels[1];
      this.orderForm.liveDistrictCode = this.live[2];
      this.orderForm.liveDistrictName = this.liveName[0].pathLabels[2];
      this.getAddressDictListByPid(this.orderForm.liveDistrictCode);
      this.$nextTick(() => {
        this.orderForm.liveSubdistrictCode = "";
        this.orderForm.liveSubdistrictName = "";
      });
    },
    getAddressDictListByPid(pid) {
      let params = { pid: pid };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          this.subdistrict = response.data.responseData;
        }
      });
    },
    selectDistrict(val) {
      var obj = {};
      obj = this.subdistrict.find(item => {
        return item.id === val;
      });
      this.orderForm.liveSubdistrictCode = obj.id;
      this.orderForm.liveSubdistrictName = obj.name;
      this.$refs["orderForm"].validateField("liveSubdistrictName");
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs["liveList"].inputValue = this.orderForm.liveDistrictName;
        this.$refs["liveList"].presentText = this.orderForm.liveDistrictName;
      }
    },
    //获取服务开始时间
    changeServiceStartDate(data) {
      if (data) {
        this.orderForm.serviceStartDate = data;
        this.$refs.orderForm.validateField("serviceStartDate");
        if (this.orderForm.serviceLongTime) {
          this.computeEndTime();
        }
      } else {
        this.orderForm.serviceStartDate = "";
        this.$refs.orderForm.validateField("serviceStartDate");
      }
    },
    //获取服务开结束时间
    changeServiceEndDate(data) {
      if (data) {
        this.$nextTick(() => {
          this.orderForm.serviceEndDate = data;
          this.orderForm.serviceLongTime = "";
          this.$refs.orderForm.validateField("serviceEndDate");
        });
      } else {
        this.orderForm.serviceEndDate = "";
        this.orderForm.serviceLongTime = "";
        this.$refs.orderForm.validateField("serviceEndDate");
      }
    },
    //获取服务时长
    computedServiceEndDate() {
      if (this.orderForm.serviceStartDate) {
        this.computeEndTime();
      }
    },
    //计算结束时间
    computeEndTime() {
      if (
        this.orderForm.serviceStartDate != "" &&
        this.orderForm.serviceLongTime != ""
      ) {
        var date = new Date(this.orderForm.serviceStartDate);
        date.setMonth(
          date.getMonth() + parseInt(this.orderForm.serviceLongTime)
        );
        this.orderForm.serviceEndDate = date;
      }
    },
    //身份证上传成功时的钩子
    handleBriefChange(response, file, fileList) {
      if (response) {
        let urls = [];
        this.idCardFileList = [];
        if (fileList.length == 2) {
          this.hideBriefUpload = true;
        }
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
            this.idCardFileList.push({
              name: item.name,
              status: item.status,
              type: item.type,
              uid: item.uid,
              url: item.response.responseData
            });
          } else {
            urls.push(item.url);
            this.idCardFileList.push(item);
          }
        });
        let checkoutPhotos = "";
        urls.forEach(items => {
          checkoutPhotos += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (checkoutPhotos.length > 0) {
          checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
        }
        this.orderForm.careReceiverIdCardPhoto = checkoutPhotos;
      }
    },
    handleRemove(file) {
      let fileList = this.idCardFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1); //删除选中的元素,this.idCardFileList返回剩余的元素;
      let checkoutPhotos = "";
      this.idCardFileList.map(items => {
        checkoutPhotos += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (checkoutPhotos.length > 0) {
        checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
      }
      this.hideBriefUpload = false;
      this.orderForm.careReceiverIdCardPhoto = checkoutPhotos;
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      window.open(file.url, "_blank");
    },
    //验证身份证关联组织
    validatorIdCard(query) {
      if (!this.orderForm.orgName) {
        this.orderForm.careReceiverIdCard = "";
        this.$message.error("请先选择组织");
        return false;
      }
      let params = {
        careReceiverIdCard: query,
        orgCode: this.orderForm.orgCode
      };
      getCareReceiverAuthority(params)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.$message.error('该被照护人身份证已存在');
            this.orderForm.careReceiverIdCard = "";
            return false;            
          } else if (response.data.statusCode == "221") {
            this.blurChangeBirthday();
            this.blurChangeGender();
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getCareReceiverAuthority:" + error);
        });
    },
    openMap() {
      this.showMap = true;
    },
    closeDialog(flag) {
      this.showMap = flag;
    },
    getAddressDetail(data) {
      this.orderForm.liveDetailAddress = data[0];
      this.orderForm.liveLongitude = data[1].lng;
      this.orderForm.liveLatitude = data[1].lat;
    },
    //新增删除联系人操作
    removeContacts(item) {
      var index = this.orderForm.careReceiverFamilyList.indexOf(item);
      if (index !== -1) {
        this.orderForm.careReceiverFamilyList.splice(index, 1);
      }
      //强制手动渲染页面
      this.$forceUpdate();
    },
    addContacts(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.orderForm.careReceiverFamilyList.push({
            careReceiverCode: "",
            familyMemberName: "",
            contactsTel: "",
            relationship: "",
            isGuardian: "0",
            key: Date.now()
          });
          //强制手动渲染页面
          this.$forceUpdate();
        } else {
          this.$message.error("请检查是否填写完整");
          this.loadingBtn = false;
          return false;
        }
      });
    },
    //推荐组织模糊查询
    selectRecommendOrgName(item) {
      if (item.value !== "无") {
        this.orderForm.recommendOrgCode = item.code;
        this.orderForm.recommendOrgName = item.value;
      } else {
        this.orderForm.recommendOrgName = "";
      }
    },
    removeRecommendOrgCode() {
      this.orderForm.recommendOrgName = "";
      this.orderForm.recommendOrgCode = "";
    },
    queryRecommendOrgName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        orgName: queryString
      };
      findEhrOrgAll(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.recommendOrg = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.recommendOrg.push({
                value: data[i].orgName,
                code: data[i].orgCode
              });
            }
            var results = this.recommendOrg;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //推荐人模糊查询
    selectStaffName(item) {
      if (item.value !== "无") {
        this.orderForm.recommendCode = item.code;
        this.orderForm.recommendName = item.value;
      } else {
        this.orderForm.recommendName = "";
      }
    },
    removeStaffCode() {
      this.orderForm.recommendCode = "";
      this.orderForm.recommendName = "";
    },
    queryStaffName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        staffFullName: queryString,
        isDataAuthority: 1
      };
      findStaffAll(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.recommend = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.recommend.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel
              });
            }
            var results = this.recommend;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //根据身份证计算出生年月
    blurChangeBirthday() {
      this.$refs.orderForm.validateField("careReceiverIdCard", cardError => {
        if (!cardError) {
          //当校验通过时，这里面写逻辑代码
          let card = this.orderForm.careReceiverIdCard;
          if (card.length == 15) {
            //第一代身份证
            this.orderForm.careReceiverBirthday =
              "19" +
              card.substring(6, 8) +
              "-" +
              card.substring(8, 10) +
              "-" +
              card.substring(10, 12);
          } else {
            this.orderForm.careReceiverBirthday =
              card.substring(6, 10) +
              "-" +
              card.substring(10, 12) +
              "-" +
              card.substring(12, 14);
          }
        } else {
          this.orderForm.careReceiverBirthday = "";
        }
      });
    },
    //根据身份证识别性别
    blurChangeGender() {
      this.$refs.orderForm.validateField("careReceiverIdCard", cardError => {
        if (!cardError) {
          //当校验通过时，这里面写逻辑代码
          let card = this.orderForm.careReceiverIdCard;
          let char = card.substring(16, 17);
          if (char % 2 == 0) {
            this.orderForm.careReceiverGender = "0";
          } else {
            this.orderForm.careReceiverGender = "1";
          }
        } else {
          this.orderForm.careReceiverGender = "";
        }
      });
    },
    //获取选择组织信息
    getCurrentNode(data) {
      this.orderForm.orgName = data.orgName;
      this.orderForm.orgCode = data.orgCode;
      this.handleClose();
    },
    handleClose() {
      this.dialogVisibleOrg = false;
    },
    //清空组织过滤
    clearOrgCode() {
      this.orderForm.orgName = "";
      this.orderForm.orgCode = "";
      this.orderForm.orgUnitName = "";
      this.orderForm.orgUnitCode = "";
    },
    /**
     *
     * 返回订单管理列表
     *
     */
    returnOrderList() {
      this.$router.push({
        path: "/businessServiceManagement/careReceiverlist"
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaff() {
      this.isEdit = true;
      this.flag = true;
      this.disabled = false;
      this.hideBriefUpload = false;
      this.getOrderDetail();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //政治面貌
      findValueBySetCode({ valueSetCode: "STAFF_POLITICAL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.politicalOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //婚姻状况
      findValueBySetCode({ valueSetCode: "RECRUIT_MARITAL_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.maritalStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //医保类型
      findValueBySetCode({ valueSetCode: "HEALTH_INSURANCE_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.mediacalTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //宗教信仰
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //身体损伤
      findValueBySetCode({ valueSetCode: "PHYSICAL_INJURY" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.physicalInjuryOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //联系人关系
      findValueBySetCode({ valueSetCode: "CARE_RECEIVER_RELATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.relationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否是监护人
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isGuardianOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    if (param.type == "update") {
      this.tagName = "查看被照护人";
      this.careReceiverCode = param.careReceiverCode;
      this.isEdit = false;
      this.flag = false;
      this.isDisabled = true;
    } else  {
      this.hideBriefUpload = false;
      this.disabled = false;
    }
    if(this.isDisabled == true) {
      this.$router.currentRoute.meta.title = "查看被照护人"
    } else {
      this.$router.currentRoute.meta.title = "新增被照护人"
    }
    if (this.careReceiverCode == undefined) {
      this.careReceiverCode = JSON.parse(sessionStorage.getItem("crCode"));
    } else {
      sessionStorage.setItem("crCode", JSON.stringify(this.careReceiverCode));
    }
    //查询订单详情
    this.getOrderDetail();
    //初始化数据字典
    this.initDataDictionary();
    //加载户籍省市区
    this.getHouseNodes();
    //加载现居住省市区
    this.getLiveNodes();
  },
  destroyed() {
    sessionStorage.removeItem("crCode");
  }
};
</script>

<style lang="scss" scoped>
#orderManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 20px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  margin-bottom: 20px;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.remark-style {
  display: block;
  width: 300px;
  margin-top: 5px;
}
.form-item {
  width: 30%;
  min-width: 500px;
  height: 50px;
}
.form-item-org {
  width: 100%;
  min-width: 400px;
  height: 50px;
}
.form-item-product {
  margin: 20px auto;
  width: 100%;
}
.form-item-table {
  width: 20%;
  min-width: 300px;
  height: 50px;
}
.form-item-tables {
  width: 30%;
  min-width: 450px;
  height: 50px;
}
.radioRight {
  margin-right: 10px;
}
.footerBtn {
  margin: 50px 0px 20px 200px;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
.itemToptip {
  position: relative;
  font-size: 12px;
  width: 108px;
  height: 30px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  float: left;
  margin-top: -25px;
  line-height: 30px;
  padding-right: 10px;
}
.el-upload__tip {
  width: 120px;
  line-height: 15px;
}

</style>
<style lang="scss">
#orderManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .el-dialog__header {
    padding-bottom: 30px;
  }
  .hideBriefImg .el-upload--picture-card {
    display: none;
  }
  .el-upload--picture-card {
    width: 100px;
    height: 100px;
    line-height: 100px;
  }
  .el-upload-list--picture-card .el-upload-list__item-actions:hover span {
    display: contents;
  }
  .el-upload-list--picture-card .el-upload-list__item {
    width: 100px;
    height: 100px;
  }

}
.el-autocomplete-suggestion__wrap {
  max-height: 380px;
}
</style>