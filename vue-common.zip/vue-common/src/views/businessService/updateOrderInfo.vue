<template>
  <div id="orderManage">
    <headTag :tagName="tagName"/>
    <div class="main-content">
      <div v-if="orderInfo">
        <OrderProductForm
          ref="OrderProductFormParams"
          v-on:changeProductListener="getProductForm"
          :orderInfo="orderInfo"
          :isEdit="false"
        />
      </div>
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">被照护人信息</span>
          </el-col>
        </el-row>
        <el-form
          ref="orderForm"
          :inline="false"
          :model="orderForm"
          :rules="orderFormRules"
          label-width="200px"
          class="form-content"
        >
          <el-row class="importToolbar_title">
            <el-col :span="24">
              <span class="form-tag-title">订单相关</span>
              <span v-if="dataList.orderStatus === '10' || dataList.orderStatus === '20'">
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="saveStaff('orderForm')"
                  :loading="loadingBtn"
                  v-if="flag"
                >保存</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="editStaff()"
                  :loading="loadingBtn"
                  v-if="!flag"
                >修改</el-button>
              </span>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="身份证号" prop="careReceiverIdCard">
                <span v-if="isEdit == false">{{orderForm.careReceiverIdCard}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    id="idCard"
                    v-model="orderForm.careReceiverIdCard"
                    size="mini"
                    clearable
                    :disabled="true"
                    placeholder="请输入身份证号"
                    maxlength="18"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="姓名" prop="careReceiverName">
                <span v-if="isEdit == false">{{orderForm.careReceiverName}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverName"
                    size="mini"
                    clearable
                    :disabled="isDisabled"
                    placeholder="请输入姓名"
                    maxlength="10"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="出生年月" prop="careReceiverBirthday">
                <span v-if="isEdit == false">{{orderForm.careReceiverBirthday}}</span>
                <span v-if="isEdit == true">
                  <el-input v-model="orderForm.careReceiverBirthday" size="mini" :disabled="true"></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="性别" prop="careReceiverGender">
                <span v-if="isEdit == false">{{orderForm.careReceiverGenderValue}}</span>
                <span v-if="isEdit == true">
                  <el-select
                    v-model="orderForm.careReceiverGender"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in genderOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="联系方式" prop="careReceiverTel">
                <span v-if="isEdit == false">{{orderForm.careReceiverTel}}</span>
                <span v-if="isEdit == true">
                  <el-input
                    v-model="orderForm.careReceiverTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住省市区" prop="liveSubdistrictName">
                <span v-if="isEdit == false">
                  <span
                    v-if="orderForm.liveSubdistrictName"
                    class="long-field"
                  >{{orderForm.liveProvinceName}}/{{orderForm.liveCityName}}/{{orderForm.liveDistrictName}}/{{orderForm.liveSubdistrictName}}</span>
                </span>
                <span v-if="isEdit == true">
                  <el-cascader
                    v-model="live"
                    placeholder="请选择现居住省市区"
                    size="mini"
                    :options="liveOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeLive"
                    @change="addLiveToForm"
                    @visible-change="changeLive"
                    ref="liveList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="现居住详细地址" prop="liveDetailAddress">
                <span v-if="isEdit == false" class="long-field">{{orderForm.liveDetailAddress}}</span>
                <span v-if="isEdit == true">
                  <el-tooltip
                    class="item"
                    effect="dark"
                    :disabled="orderForm.liveDetailAddress == '' ? true : false"
                    :content="orderForm.liveDetailAddress"
                    placement="top"
                  >
                    <el-input
                      v-model="orderForm.liveDetailAddress"
                      @focus="openMap"
                      size="mini"
                      clearable
                      placeholder="请输入现居住详细地址"
                      maxlength="50"
                    />
                  </el-tooltip>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-product">
              <el-form-item label="身份证照片">
                <el-upload
                  ref="uploadBrief"
                  :class="{hideBriefImg:hideBriefUpload}"
                  :action="actionUrl"
                  list-type="picture-card"
                  :on-success="handleBriefChange"
                  accept="image/png, image/gif, image/jpg, image/jpeg"
                  multiple
                  :limit="2"
                  :file-list="idCardFileList"
                >
                  <i class="el-icon-plus"></i>
                  <div slot="file" slot-scope="{file}">
                    <img class="el-upload-list__item-thumbnail" :src="file.url" alt>
                    <span class="el-upload-list__item-actions">
                      <span
                        class="el-upload-list__item-preview"
                        @click="handlePictureCardPreview(file)"
                      >
                        <i class="el-icon-zoom-in"></i>
                      </span>
                      <span class="el-upload-list__item-delete" @click="handleDownload(file)">
                        <i class="el-icon-download"></i>
                      </span>
                      <span
                        v-if="!disabled"
                        class="el-upload-list__item-delete"
                        @click="handleRemove(file)"
                      >
                        <i class="el-icon-delete"></i>
                      </span>
                    </span>
                  </div>
                  <span v-if="!disabled">
                    <div class="el-upload__tip">仅限上传2张图片！</div>
                  </span>
                </el-upload>
                <el-dialog :visible.sync="dialogVisible">
                  <el-image style="width: 100%; height: 600px" :src="dialogImageUrl"></el-image>
                </el-dialog>
                <span v-if="idCardFileList.length > 0">
                  <div v-for="file in idCardFileList">
                    <el-tooltip
                      class="itemToptip"
                      effect="dark"
                      :content="file.name"
                      placement="bottom"
                    >
                      <div>{{file.name}}</div>
                    </el-tooltip>
                  </div>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <hr color="#eeeeee">
        <el-form
          ref="orderOtherForm"
          :inline="false"
          :model="orderOtherForm"
          :rules="orderOtherFormRules"
          label-width="200px"
          class="form-content"
        >
          <el-row class="importToolbar_title">
            <el-col :span="24">
              <span class="form-tag-title">其他</span>
              <span v-if="dataList.orderStatus === '10' || dataList.orderStatus === '20'">
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="saveStaffOther('orderOtherForm')"
                  :loading="loadingBtn"
                  v-if="flagOther"
                >保存</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="editStaffOther()"
                  :loading="loadingBtn"
                  v-if="!flagOther"
                >修改</el-button>
              </span>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item label="民族" prop="careReceiverNation">
                <span v-if="isEditOther == false">{{orderOtherForm.careReceiverNation}}</span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="orderOtherForm.careReceiverNation"
                    size="mini"
                    clearable
                    placeholder="请输入民族"
                    maxlength="20"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="籍贯" prop="nativePlace">
                <span v-if="isEditOther == false" class="long-field">{{orderOtherForm.nativePlace}}</span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="orderOtherForm.nativePlace"
                    size="mini"
                    clearable
                    placeholder="籍贯"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍省市区" prop="houseDistrictName">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.houseDistrictName"
                    class="long-field"
                  >{{orderOtherForm.houseProvinceName}}/{{orderOtherForm.houseCityName}}/{{orderOtherForm.houseDistrictName}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-cascader
                    v-model="house"
                    placeholder="请选择户籍省市区"
                    size="mini"
                    :options="houseOptions"
                    :show-all-levels="false"
                    @active-item-change="handleExpandChangeHouse"
                    @change="addHouseToForm"
                    @visible-change="changeHouse"
                    ref="houseList"
                    :props="{
                  value: 'id',
                  label: 'name',
                  children: 'cities'
                }"
                  ></el-cascader>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="户籍详细地址" prop="houseDetailAddress">
                <span
                  v-if="isEditOther == false"
                  class="long-field"
                >{{orderOtherForm.houseDetailAddress}}</span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="orderOtherForm.houseDetailAddress"
                    size="mini"
                    clearable
                    placeholder="请输入户籍详细地址"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="政治面貌" prop="careReceiverPolitical">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.careReceiverPoliticalValue"
                  >{{orderOtherForm.careReceiverPoliticalValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.careReceiverPolitical"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in politicalOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="最高学历" prop="careReceiverEducation">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.careReceiverEducationValue"
                  >{{orderOtherForm.careReceiverEducationValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.careReceiverEducation"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in educationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="婚姻状况" prop="maritalStatus">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.maritalStatusValue"
                  >{{orderOtherForm.maritalStatusValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.maritalStatus"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in maritalStatusOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="医保类型" prop="medicalType">
                <span v-if="isEditOther == false">
                  <span v-if="orderOtherForm.medicalTypeValue">{{orderOtherForm.medicalTypeValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.medicalType"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in mediacalTypeOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="医保卡号">
                <span v-if="isEditOther == false">
                  <span v-if="orderOtherForm.medicalCardNo">{{orderOtherForm.medicalCardNo}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="orderOtherForm.medicalCardNo"
                    size="mini"
                    clearable
                    placeholder="请输入医保卡号"
                    maxlength="50"
                  />
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="宗教信仰" prop="careReceiverFaith">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.careReceiverFaithValue"
                  >{{orderOtherForm.careReceiverFaithValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.careReceiverFaith"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in faithOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="身体损伤" prop="physicalDamage">
                <span v-if="isEditOther == false">
                  <span
                    v-if="orderOtherForm.physicalDamageValue"
                  >{{orderOtherForm.physicalDamageValue}}</span>
                </span>
                <span v-if="isEditOther == true">
                  <el-select
                    v-model="orderOtherForm.physicalDamage"
                    size="mini"
                    clearable
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in physicalInjuryOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-for="(item, index) in orderOtherForm.careReceiverFamilyList" :key="item.key">
            {{item.index}}
            <el-col class="form-item-table">
              <!-- 
                :prop="'careReceiverFamilyList.' + index + '.familyMemberName'" 
                :rules="orderFormRules.familyMemberName"
              -->
              <el-form-item label="紧急联系人">
                <span v-if="isEditOther == false">{{item.familyMemberName}}</span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="item.familyMemberName"
                    size="mini"
                    maxlength="20"
                    clearable
                    placeholder="请输入紧急联系人"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-table">
              <!-- 
                :prop="'careReceiverFamilyList.' + index + '.contactsTel'"
                :rules="orderFormRules.contactsTel"
              -->
              <el-form-item label="联系方式">
                <span v-if="isEditOther == false">{{item.contactsTel}}</span>
                <span v-if="isEditOther == true">
                  <el-input
                    v-model="item.contactsTel"
                    size="mini"
                    clearable
                    placeholder="请输入联系方式"
                    maxlength="11"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-table">
              <el-form-item
                label="是联系人的谁"
                :prop="'careReceiverFamilyList.' + index + '.relationship'"
              >
                <span v-if="isEditOther == false">{{item.relationshipValue}}</span>
                <span v-if="isEditOther == true">
                  <el-select v-model="item.relationship" size="mini" clearable placeholder="请选择">
                    <el-option
                      v-for="item in relationOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-tables">
              <el-form-item label="是否是监护人">
                <span v-if="isEditOther == false">{{item.isGuardianValue}}</span>
                <span v-if="isEditOther == true">
                  <el-select v-model="item.isGuardian" size="mini" clearable placeholder="请选择">
                    <el-option
                      v-for="item in isGuardianOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </span>
                <span v-if="index > 0">
                  <el-button
                    type="danger"
                    size="mini"
                    icon="el-icon-delete"
                    circle
                    style="margin-left:5px;"
                    v-if="flagOther"
                    @click="removeContacts(item)"
                  ></el-button>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col class="form-item">
              <el-form-item>
                <el-button
                  type="primary"
                  icon="el-icon-circle-plus"
                  size="mini"
                  v-if="flagOther"
                  @click="addContacts('orderForm')"
                >新增紧急联系人</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="panel-card">
        <el-row class="importToolbar">
          <el-col :span="24">
            <span class="form-tag">服务信息</span>
            <span v-if="dataList.orderStatus === '10'">
              <span v-if="dataList.payStatus === undefined">
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="saveService('serviceForm')"
                  :loading="serviceLoadingBtn"
                  v-if="serviceFlag"
                >保存</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  class="rightBtn"
                  @click="editService()"
                  :loading="serviceLoadingBtn"
                  v-if="!serviceFlag"
                >修改</el-button>
              </span>
            </span>
          </el-col>
        </el-row>
        <el-form
          ref="serviceForm"
          :inline="false"
          :model="serviceForm"
          :rules="serviceFormRules"
          label-width="200px"
          class="form-content"
        >
          <el-row>
            <el-col class="form-item">
              <el-form-item label="是否关联订单" required prop="isRelation">
                <span v-if="serviceIsEdit == false">
                  <span v-if="serviceForm.isRelation == '0'">否</span>
                  <span v-if="serviceForm.isRelation == '1'">是 {{serviceForm.relationOrderCode}}</span>
                </span>
                <span v-if="serviceIsEdit == true">
                  <el-select
                    size="mini"
                    v-model="serviceForm.isRelation"
                    style="width:68px;"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in isRelatedOptions"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                  <el-autocomplete
                    v-if="serviceForm.isRelation == '1'"
                    :trigger-on-focus="true"
                    v-model="serviceForm.relationOrderCode"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryOrderCode"
                    placeholder="请输入关联订单号"
                    @select="selectOrderCode"
                    @blur="removeOrderCode"
                  ></el-autocomplete>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="订单号">
                <span>{{serviceForm.orderCode}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="订单来源">
                <span>{{serviceForm.orderSourceValue}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="付款时间">
                <span v-if="serviceForm.payDate">{{serviceForm.payDate}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="订单状态">
                <span>{{serviceForm.orderStatusValue}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="付款状态">
                <span>{{serviceForm.payStatusValue}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="创建时间">
                <span>{{serviceForm.createDate}}</span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="推荐组织">
                <span v-if="serviceIsEdit == false">{{serviceForm.recommendOrgName}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-autocomplete
                    :trigger-on-focus="true"
                    v-model="serviceForm.recommendOrgName"
                    popper-class="my-autocomplete"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryRecommendOrgName"
                    placeholder="请输入组织"
                    @select="selectRecommendOrgName"
                    @blur="removeRecommendOrgCode"
                    @clear="removeRecommendOrgCode"
                  >
                    <template slot-scope="{ item }">
                      <span class="name">{{ item.value }}</span>
                    </template>
                  </el-autocomplete>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="推荐人">
                <span v-if="serviceIsEdit == false">{{serviceForm.recommendName}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-autocomplete
                    :trigger-on-focus="true"
                    v-model="serviceForm.recommendName"
                    popper-class="my-autocomplete"
                    size="mini"
                    clearable
                    :fetch-suggestions="queryStaffName"
                    placeholder="请输入员工姓名"
                    @select="selectStaffName"
                    @blur="removeStaffCode"
                  >
                    <template slot-scope="{ item }">
                      <span class="name">
                        {{ item.value }}
                        <span v-if="item.value != '无'">({{ item.staffTel }})</span>
                      </span>
                    </template>
                  </el-autocomplete>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="推荐时间" prop="recommendDate">
                <span v-if="serviceIsEdit == false">{{serviceForm.recommendDate}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-date-picker
                    v-model="serviceForm.recommendDate"
                    size="mini"
                    clearable
                    value-format="yyyy-MM-dd"
                    type="date"
                    placeholder="选择推荐时间"
                  ></el-date-picker>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务开始日期" prop="serviceStartDate">
                <span v-if="serviceIsEdit == false">{{serviceForm.serviceStartDate}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-date-picker
                    v-model="serviceForm.serviceStartDate"
                    size="mini"
                    clearable
                    value-format="yyyy-MM-dd"
                    format="yyyy-MM-dd"
                    type="date"
                    placeholder="选择开始日期"
                    @change="changeServiceStartDate"
                    :picker-options="pickerOptionsStart"
                  ></el-date-picker>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务时长">
                <span v-if="serviceIsEdit == false"></span>
                <span v-if="serviceIsEdit == true">
                  <el-input
                    v-model="serviceForm.serviceLongTime"
                    size="mini"
                    clearable
                    placeholder="请输入时长"
                    onkeyup="this.value = this.value.replace(/[^\d]/g,'');"
                    @blur="computedServiceEndDate"
                    maxlength="4"
                  >
                    <template slot="append">月</template>
                  </el-input>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-items">
              <el-form-item label="服务结束日期" prop="serviceEndDate">
                <span v-if="serviceIsEdit == false">{{serviceForm.serviceEndDate}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-date-picker
                    v-model="serviceForm.serviceEndDate"
                    size="mini"
                    clearable
                    value-format="yyyy-MM-dd"
                    format="yyyy-MM-dd"
                    type="date"
                    placeholder="选择结束日期"
                    @change="changeServiceEndDate"
                    :picker-options="pickerOptionsEnd"
                  ></el-date-picker>
                </span>
              </el-form-item>
            </el-col>
            <el-col class="form-item-product">
              <el-form-item label="资料上传">
                <upload
                  :multiple="false"
                  :limit="10"
                  :action="actionUrl"
                  :file-list="serviceFileList"
                  :hideUpload="hideUpload"
                  :disabled="disabledFile"
                  :accept="'image/jpeg,image/gif,image/png,video/mp4,video/avi,video/rmvb,video/flv'"
                  @handleGetUrl="getUrl"
                  @handleRemoveList="removeList"
                ></upload>
              </el-form-item>
            </el-col>
            <el-col class="form-item-product">
              <el-form-item label="备注">
                <span v-if="serviceIsEdit == false">{{serviceForm.remark}}</span>
                <span v-if="serviceIsEdit == true">
                  <el-input
                    type="textarea"
                    class="remark-style"
                    v-model="serviceForm.remark"
                    size="mini"
                    clearable
                    placeholder="请输入备注"
                    maxlength="100"
                    show-word-limit
                    resize="none"
                    rows="4"
                  ></el-input>
                </span>
              </el-form-item>
            </el-col>
            <span v-if="serviceForm.assessList.length > 0">
              <span v-for="(item,i) in serviceForm.assessList" :key="i">
                <el-col class="form-item">
                  <el-form-item label="评估版本">
                    <span>{{item.assessName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="评估人">
                    <span>{{item.assessorName}}</span>
                  </el-form-item>
                </el-col>
                <el-col class="form-item">
                  <el-form-item label="评估时间">
                    <span>{{item.assessEndDate}}</span>
                  </el-form-item>
                </el-col>
              </span>
            </span>
          </el-row>
        </el-form>
      </div>

      <map-point
        v-if="this.showMap"
        @GetMapPoint="getAddressDetail"
        @closeDialog="closeDialog"
        :placeholder="'请输入现居住详细地址'"
        :maxLength="50"
        :address="orderForm.liveDetailAddress"
        :provinceAddress="orderForm.liveProvinceName"
        :cityAddress="orderForm.liveCityName"
        :districtAddress="orderForm.liveDistrictName"
        :liveLongitude="orderForm.liveLongitude"
        :liveLatitude="orderForm.liveLatitude"
      ></map-point>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import FileUpload from "components/FileUpload";
import Upload from "components/FileUpload/upload";
import MapPoint from "components/MapPoint";
import { findValueBySetCode, findAddressDictList } from "api/common";
import { findStaffList, findStaffAll } from "api/customerManagement";
import OrderProductForm from "@/views/businessService/OrderProductForm";
import { changeYMD } from "utils";
import {
  validateTel,
  validateIdCard,
  isNumber,
  isMoney,
  validateEmail
} from "@/utils/validate";
import {
  findEtProductListForWebQuickSearch,
  findProductByCodeForOrder,
  getCareReceiverAuthority,
  insertCareReceiverAuthority,
  insertEtOffLineProductOrder,
  getOrderDetail, //订单详情
  updateOrderInfoForService, //服务信息
  updateOrderInfoForCareReceiver, //被照护人订单相关信息
  updateCareReceiver, //被照护人其他信息
  findRelationEtProductOrder //查询关联订单
} from "api/orderManagement";
import { findEhrOrgAll } from "api/orgStructure";
export default {
  components: {
    OrderProductForm,
    HeadTag
  },
  data() {
    return {
      tagName: "查看线下订单",
      orderInfo: undefined,
      dataList: {},
      //是否可编辑
      isEdit: false,
      //是否可编辑其他
      isEditOther: false,
      //服务信息是否可编辑
      serviceIsEdit: false,
      //是否可禁用
      isDisabled: true,
      //按钮加载状态
      loadingBtn: false,
      //服务信息按钮加载
      serviceLoadingBtn: false,
      //控制修改/保存
      flag: false,
      flagOther: false,
      //服务信息控制修改/保存
      serviceFlag: false,
      //控制地图弹窗
      showMap: false,
      //产品名称加载
      loading: false,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      //身份证上传
      idCardFileList: [],
      hideBriefUpload: true,
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: true,
      //资料上传
      serviceFileList: [],
      hideUpload: true,
      disabledFile: true,
      /**
       *
       * 动态产品信息Form
       *
       */
      productForm: {
        specificationId: [],
        textInput: [],
        selectOptions: [],
        selectMoreOptions: [],
        radioGroup: [],
        selectVague: [],
        productOrderPropertyList: [],
        //验证
        rules: {}
      },
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      orderForm: {
        orgName: "",
        orgCode: "",
        orgUnitCode: "",
        orgUnitName: "",
        careReceiverIdCard: "",
        careReceiverName: "",
        careReceiverCode: "",
        careReceiverBirthday: "",
        careReceiverGenderValue: "",
        careReceiverGender: "",
        careReceiverTel: "",
        liveSubdistrictName: "",
        liveDetailAddress: "",
        liveLongitude: "",
        liveLatitude: "",
        customerCode: "",
        customerName: "",
        customerTel: "",
        careReceiverIdCardPhoto: ""
      },
      //验证
      orderFormRules: {
        productName: [
          {
            required: true,
            message: "请输入产品名称",
            trigger: "change"
          }
        ],
        careReceiverName: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        careReceiverIdCard: [
          {
            required: true,
            message: "请输入身份证号",
            trigger: "blur"
          },
          {
            required: true,
            trigger: "blur",
            validator: validateIdCard
          }
        ],
        careReceiverGender: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        careReceiverTel: [
          {
            required: true,
            message: "请输入联系方式",
            trigger: "blur"
          }
        ],
        liveSubdistrictName: [
          {
            required: true,
            message: "请选择现居住省市区",
            trigger: "input"
          }
        ],
        liveDetailAddress: [
          {
            required: true,
            message: "请输入现居住详细地址",
            trigger: "input"
          }
        ],
        orgName: [
          {
            required: true,
            message: "请选择组织",
            trigger: "change"
          }
        ]
      },
      /*
       *
       * 订单信息Form
       * 验证
       *
       */
      orderOtherForm: {
        careReceiverNation: "汉",
        nativePlace: "",
        houseDistrictName: "",
        houseDetailAddress: "",
        careReceiverPolitical: "",
        careReceiverEducation: "",
        maritalStatus: "",
        medicalType: "",
        medicalCardNo: "",
        careReceiverFaith: "",
        physicalDamage: "",
        careReceiverFamilyList: []
      },
      //验证
      orderOtherFormRules: {
        houseDistrictName: [
          {
            required: true,
            message: "请选择户籍省市区",
            trigger: "input"
          }
        ],
        houseDetailAddress: [
          {
            required: true,
            message: "请输入户籍详细地址",
            trigger: "blur"
          }
        ]
      },
      serviceForm: {
        orderCode: "",
        orderSourceValue: "",
        orderStatusValue: "",
        payStatusValue: "",
        createDate: "",
        payDate: "",
        isRelation: "0",
        relationOrderCode: "",
        relationOrderName: "",
        recommendDate: "",
        recommendCode: "",
        recommendName: "",
        recommendTel: "",
        recommendOrgName: "",
        recommendOrgCode: "",
        // assessorCode: "",
        // assessorName: "",
        // assessDate: "",
        assessList: [],
        visitDate: "",
        careProviderGender: "",
        careProviderGenderValue: "",
        serviceStartDate: "",
        serviceEndDate: "",
        serviceLongTime: "",
        serviceFileUrls: "",
        remark: ""
      },
      //验证
      serviceFormRules: {
        serviceStartDate: [
          {
            required: true,
            message: "请选择服务开始日期",
            trigger: "blur"
          }
        ],
        serviceEndDate: [
          {
            required: true,
            message: "请选择服务结束日期",
            trigger: "blur"
          }
        ]
      },
      //服务开始时间
      pickerOptionsStart: {
        disabledDate: time => {
          let endDateVal = this.serviceForm.serviceEndDate;
          if (endDateVal) {
            return time.getTime() > new Date(endDateVal).getTime();
          }
        }
      },
      //服务结束时间
      pickerOptionsEnd: {
        disabledDate: time => {
          let beginDateVal = this.serviceForm.serviceStartDate;
          if (beginDateVal) {
            return time.getTime() < new Date(beginDateVal).getTime() - 86400000;
          }
        }
      },
      //推荐人
      recommend: [],
      //推荐组织
      recommendOrg: [],
      //关联订单
      relationOrder: [],
      //动态加载户籍省市区
      houseOptions: [],
      house: [],
      houseName: [],
      //动态加载现居住省市区
      liveOptions: [],
      live: [],
      liveName: [],
      /*
       *
       * 模糊匹配下拉框
       *
       */
      //产品名称
      productNames: [],
      productNamesList: [],
      productNamesOptions: [],
      //产品名称动态组件
      productNameProperty: {
        productPropertyList: {},
        productSpecificationList: {}
      },
      /*
       *
       * 选择下拉框
       *
       */
      //性别
      genderOptions: [],
      //政治面貌
      politicalOptions: [],
      //最高学历
      educationOptions: [],
      //婚姻状况
      maritalStatusOptions: [],
      //医保类型
      mediacalTypeOptions: [],
      //宗教信仰
      faithOptions: [],
      //身体损伤
      physicalInjuryOptions: [],
      //服务者性别
      careProviderGenderOptions: [],
      //联系人关系
      relationOptions: [],
      //是否关联订单
      isRelatedOptions: [],
      //是否是监护人
      isGuardianOptions: [],
      /**
       *
       * 页面传参
       *
       */
      orderCode: ""
    };
  },
  components: {
    HeadTag,
    FileUpload,
    Upload,
    MapPoint,
    OrgSelect,
    OrderProductForm
  },
  methods: {
    /**
     *
     * 选择产品获取产品信息
     *
     */
    getProductForm(obj) {},
    /**
     *
     * 获取订单详情
     *
     */
    getOrderDetail() {
      var param = {
        orderCode: this.orderCode
      }; //TODO
      getOrderDetail(param)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.orderInfo = response.data.responseData;
            this.dataList = response.data.responseData;
            //组织和服务信息
            //订单相关
            this.orderForm.orgUnitCode = this.orderInfo.etCareReceiverOutDto.orgUnitCode;
            this.orderForm.orgUnitName = this.orderInfo.etCareReceiverOutDto.orgUnitName;
            this.orderForm.careReceiverBirthday = this.orderInfo.etCareReceiverOutDto.careReceiverBirthday;
            this.orderForm.careReceiverIdCard = this.orderInfo.etCareReceiverOutDto.careReceiverIdCard;
            this.orderForm.careReceiverTel = this.orderInfo.etCareReceiverOutDto.careReceiverTel;
            this.orderForm.liveProvinceCode = this.orderInfo.etCareReceiverOutDto.liveProvinceCode;
            this.orderForm.liveProvinceName = this.orderInfo.etCareReceiverOutDto.liveProvinceName;
            this.orderForm.liveCityCode = this.orderInfo.etCareReceiverOutDto.liveCityCode;
            this.orderForm.liveCityName = this.orderInfo.etCareReceiverOutDto.liveCityName;
            this.orderForm.liveDistrictCode = this.orderInfo.etCareReceiverOutDto.liveDistrictCode;
            this.orderForm.liveDistrictName = this.orderInfo.etCareReceiverOutDto.liveDistrictName;
            this.orderForm.liveSubdistrictCode = this.orderInfo.etCareReceiverOutDto.liveSubdistrictCode;
            this.orderForm.liveSubdistrictName = this.orderInfo.etCareReceiverOutDto.liveSubdistrictName;
            this.orderForm.liveDetailAddress = this.orderInfo.etCareReceiverOutDto.liveDetailAddress;
            this.orderForm.careReceiverCode = this.orderInfo.careReceiverCode;
            this.orderForm.careReceiverName = this.orderInfo.careReceiverName;
            this.orderForm.customerCode = this.orderInfo.customerCode;
            this.orderForm.customerName = this.orderInfo.customerName;
            this.orderForm.customerTel = this.orderInfo.customerTel;
            this.orderForm.liveLongitude = this.orderInfo.liveLongitude;
            this.orderForm.liveLatitude = this.orderInfo.liveLatitude;
            this.orderForm.careReceiverGender = this.orderInfo.careReceiverGender;
            this.orderForm.careReceiverGenderValue = this.orderInfo.careReceiverGenderValue;
            this.orderForm.careReceiverIdCardPhoto = this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto;
            //其他
            this.orderOtherForm.careReceiverFamilyList = this.orderInfo.careReceiverFamilyList;
            this.orderOtherForm.careReceiverNation = this.orderInfo.etCareReceiverOutDto.careReceiverNation;
            this.orderOtherForm.nativePlace = this.orderInfo.etCareReceiverOutDto.nativePlace;
            this.orderOtherForm.houseProvinceCode = this.orderInfo.etCareReceiverOutDto.houseProvinceCode;
            this.orderOtherForm.houseProvinceName = this.orderInfo.etCareReceiverOutDto.houseProvinceName;
            this.orderOtherForm.houseCityCode = this.orderInfo.etCareReceiverOutDto.houseCityCode;
            this.orderOtherForm.houseCityName = this.orderInfo.etCareReceiverOutDto.houseCityName;
            this.orderOtherForm.houseDistrictCode = this.orderInfo.etCareReceiverOutDto.houseDistrictCode;
            this.orderOtherForm.houseDistrictName = this.orderInfo.etCareReceiverOutDto.houseDistrictName;
            this.orderOtherForm.houseDetailAddress = this.orderInfo.etCareReceiverOutDto.houseDetailAddress;
            this.orderOtherForm.careReceiverPolitical = this.orderInfo.etCareReceiverOutDto.careReceiverPolitical;
            this.orderOtherForm.careReceiverPoliticalValue = this.orderInfo.etCareReceiverOutDto.careReceiverPoliticalValue;
            this.orderOtherForm.careReceiverEducation = this.orderInfo.etCareReceiverOutDto.careReceiverEducation;
            this.orderOtherForm.careReceiverEducationValue = this.orderInfo.etCareReceiverOutDto.careReceiverEducationValue;
            this.orderOtherForm.maritalStatus = this.orderInfo.etCareReceiverOutDto.maritalStatus;
            this.orderOtherForm.maritalStatusValue = this.orderInfo.etCareReceiverOutDto.maritalStatusValue;
            this.orderOtherForm.medicalType = this.orderInfo.etCareReceiverOutDto.medicalType;
            this.orderOtherForm.medicalTypeValue = this.orderInfo.etCareReceiverOutDto.medicalTypeValue;
            this.orderOtherForm.medicalCardNo = this.orderInfo.etCareReceiverOutDto.medicalCardNo;
            this.orderOtherForm.careReceiverFaith = this.orderInfo.etCareReceiverOutDto.careReceiverFaith;
            this.orderOtherForm.careReceiverFaithValue = this.orderInfo.etCareReceiverOutDto.careReceiverFaithValue;
            this.orderOtherForm.physicalDamage = this.orderInfo.etCareReceiverOutDto.physicalDamage;
            this.orderOtherForm.physicalDamageValue = this.orderInfo.etCareReceiverOutDto.physicalDamageValue;
            //服务信息
            this.serviceForm.serviceStartDate = changeYMD(
              this.orderInfo.serviceStartDate
            );
            this.serviceForm.serviceEndDate = changeYMD(
              this.orderInfo.serviceEndDate
            );
            this.serviceForm.orderCode = this.orderInfo.orderCode;
            this.serviceForm.orderSourceValue = this.orderInfo.orderSourceValue;
            this.serviceForm.orderStatusValue = this.orderInfo.orderStatusValue;
            this.serviceForm.payStatusValue = this.orderInfo.payStatusValue;
            this.serviceForm.createDate = this.orderInfo.createDate;
            this.serviceForm.payDate = this.orderInfo.payDate;
            this.serviceForm.visitDate = this.orderInfo.visitDate;
            this.serviceForm.careProviderGender = this.orderInfo.careProviderGender;
            this.serviceForm.careProviderGenderValue = this.orderInfo.careProviderGenderValue;
            this.serviceForm.recommendDate = this.orderInfo.recommendDate ? changeYMD(this.orderInfo.recommendDate) : '';
            this.serviceForm.recommendCode = this.orderInfo.recommendCode;
            this.serviceForm.recommendName = this.orderInfo.recommendName;
            this.serviceForm.recommendOrgCode = this.orderInfo.recommendOrgCode;
            this.serviceForm.recommendOrgName = this.orderInfo.recommendOrgName;
            // this.serviceForm.assessorCode = this.orderInfo.assessorCode;
            // this.serviceForm.assessorName = this.orderInfo.assessorName;
            // this.serviceForm.assessDate = this.orderInfo.assessDate;
            this.serviceForm.serviceFileUrls = this.orderInfo.serviceFileUrls;
            this.serviceForm.assessList = this.orderInfo.assessOrderOutDtoList;
            this.serviceForm.remark = this.orderInfo.remark;
            this.serviceForm.isRelation = this.orderInfo.isRelation;
            this.serviceForm.relationOrderCode = this.orderInfo.relationOrderCode;
            if (this.orderInfo.orderStatus == "10") {
              this.isDisabled = false;
            }
            this.blurChangeBirthday();
            this.$nextTick(() => {
              if (this.flagOther == true) {
                this.$refs[
                  "houseList"
                ].inputValue = this.orderOtherForm.houseDistrictName;
              }
              if (this.flag == true) {
                this.$refs[
                  "liveList"
                ].inputValue = this.orderForm.liveSubdistrictName;
              }
            });
            if (
              this.orderInfo.serviceFileUrls !== undefined &&
              this.orderInfo.serviceFileUrls !== "undefined" &&
              this.orderInfo.serviceFileUrls
            ) {
              let files = this.orderInfo.serviceFileUrls;
              this.serviceFileList = [];
              let serviceFiles = files.split(",");
              if (serviceFiles.length == 10) {
                this.hideUpload = true;
              }
              for (let i = 0; i < serviceFiles.length; i++) {
                this.serviceFileList.push({
                  url: serviceFiles[i],
                  name: decodeURI(serviceFiles[i])
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18)
                });
              }
              if(this.serviceFileList.length > 0) {
                for (let i = 0; i < this.serviceFileList.length; i++) {
                  var n = this.serviceFileList[i].name.substring(this.serviceFileList[i].name.indexOf(".") + 1, this.serviceFileList[i].name.length);
                  if ('mp4'.indexOf(n) !== -1) {
                    this.serviceFileList[i].type = "vedio"
                    this.findvideocover(this.serviceFileList[i].url);
                  } else {
                    this.serviceFileList[i].type = "img"
                  }
                }
              }
            }
            if (
              this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto !==
                undefined &&
              this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto !==
                "undefined" &&
              this.orderInfo.etCareReceiverOutDto.careReceiverIdCardPhoto
            ) {
              let photoUrl = this.orderInfo.etCareReceiverOutDto
                .careReceiverIdCardPhoto;
              this.idCardFileList = [];
              let photos = photoUrl.split(",");
              if (photos.length == 2) {
                this.hideBriefUpload = true;
              }
              for (let i = 0; i < photos.length; i++) {
                this.idCardFileList.push({
                  name: decodeURI(photos[i])
                    .toString()
                    .split("com/")[1]
                    .split("?Expires")[0]
                    .substr(18),
                  url: photos[i]
                });
              }
            }
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getOrderDetail:" + error);
        });
    },
    findvideocover(url) {
      this.$nextTick(() => {
        setTimeout(()=> {
          let video = document.getElementById("upvideo");
          let source = document.createElement("source");
          source.src = url;
          source.type = "video/mp4";
          video.appendChild(source);
          video.addEventListener("loadeddata", function() {
            var canvas = document.createElement("canvas");
            canvas.width = "320";
            canvas.height = "320";
            canvas
              .getContext("2d")
              .drawImage(video, 0, 0, canvas.width, canvas.width);
          });
        },3000)
      });
    },
    /**
     *
     * 订单相关信息保存
     *
     *
     */
    saveStaff(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //紧急联系人如果三项都没有填写直接移除
          if (this.orderOtherForm.careReceiverFamilyList.length > 0) {
            var list = this.orderOtherForm.careReceiverFamilyList;
            for (let i = 0; i < list.length; i++) {
              if (
                list[i].familyMemberName == "" &&
                list[i].contactsTel == "" &&
                list[i].relationship == "" &&
                list[i].isGuardian
              ) {
                this.orderOtherForm.careReceiverFamilyList.splice(i, 1);
                i = 0;
              }
            }
          }
          var params = {
            orderCode: this.orderCode,
            //被照护人信息
            etCareReceiverInDto: {
              //订单相关
              orgUnitCode: this.orderForm.orgUnitCode,
              orgUnitName: this.orderForm.orgUnitName,
              careReceiverCode: this.orderForm.careReceiverCode,
              careReceiverName: this.orderForm.careReceiverName,
              careReceiverGender: this.orderForm.careReceiverGender,
              careReceiverBirthday: this.orderForm.careReceiverBirthday,
              careReceiverIdCard: this.orderForm.careReceiverIdCard,
              careReceiverTel: this.orderForm.careReceiverTel,
              liveProvinceCode: this.orderForm.liveProvinceCode,
              liveProvinceName: this.orderForm.liveProvinceName,
              liveCityCode: this.orderForm.liveCityCode,
              liveCityName: this.orderForm.liveCityName,
              liveDistrictCode: this.orderForm.liveDistrictCode,
              liveDistrictName: this.orderForm.liveDistrictName,
              liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
              liveSubdistrictName: this.orderForm.liveSubdistrictName,
              liveDetailAddress: this.orderForm.liveDetailAddress,
              liveLongitude: this.orderForm.liveLongitude,
              liveLatitude: this.orderForm.liveLatitude,
              careReceiverIdCardPhoto: this.orderForm.careReceiverIdCardPhoto,
              //其他
              careReceiverNation: this.orderOtherForm.careReceiverNation,
              nativePlace: this.orderOtherForm.nativePlace,
              houseProvinceCode: this.orderOtherForm.houseProvinceCode,
              houseProvinceName: this.orderOtherForm.houseProvinceName,
              houseCityCode: this.orderOtherForm.houseCityCode,
              houseCityName: this.orderOtherForm.houseCityName,
              houseDistrictCode: this.orderOtherForm.houseDistrictCode,
              houseDistrictName: this.orderOtherForm.houseDistrictName,
              houseDetailAddress: this.orderOtherForm.houseDetailAddress,
              careReceiverPolitical: this.orderOtherForm.careReceiverPolitical,
              careReceiverEducation: this.orderOtherForm.careReceiverEducation,
              maritalStatus: this.orderOtherForm.maritalStatus,
              medicalType: this.orderOtherForm.medicalType,
              medicalCardNo: this.orderOtherForm.medicalCardNo,
              careReceiverFaith: this.orderOtherForm.careReceiverFaith,
              physicalDamage: this.orderOtherForm.physicalDamage
            },
            //紧急联系人
            careReceiverFamilyList: this.orderOtherForm.careReceiverFamilyList
          };
          updateOrderInfoForCareReceiver(params)
            .then(response => {
              if (
                response.data.statusCode == "200" ||
                response.data.statusCode == 200
              ) {
                this.$message.success("修改成功");
                this.loadingBtn = false;
                this.isEdit = false;
                this.flag = false;
                this.disabled = true;
                this.hideBriefUpload = true;
                this.getOrderDetail();
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("updateOrderInfoForCareReceiver:" + error);
            });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 其他信息保存
     *
     *
     */
    saveStaffOther(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var params = {
            orderCode: this.orderCode,
            //被照护人信息
            etCareReceiverInDto: {
              //订单相关
              orgUnitCode: this.orderForm.orgUnitCode,
              orgUnitName: this.orderForm.orgUnitName,
              careReceiverCode: this.orderForm.careReceiverCode,
              careReceiverName: this.orderForm.careReceiverName,
              careReceiverGender: this.orderForm.careReceiverGender,
              careReceiverBirthday: this.orderForm.careReceiverBirthday,
              careReceiverIdCard: this.orderForm.careReceiverIdCard,
              careReceiverTel: this.orderForm.careReceiverTel,
              liveProvinceCode: this.orderForm.liveProvinceCode,
              liveProvinceName: this.orderForm.liveProvinceName,
              liveCityCode: this.orderForm.liveCityCode,
              liveCityName: this.orderForm.liveCityName,
              liveDistrictCode: this.orderForm.liveDistrictCode,
              liveDistrictName: this.orderForm.liveDistrictName,
              liveSubdistrictCode: this.orderForm.liveSubdistrictCode,
              liveSubdistrictName: this.orderForm.liveSubdistrictName,
              liveDetailAddress: this.orderForm.liveDetailAddress,
              liveLongitude: this.orderForm.liveLongitude,
              liveLatitude: this.orderForm.liveLatitude,
              careReceiverIdCardPhoto: this.orderForm.careReceiverIdCardPhoto,
              //其他
              careReceiverNation: this.orderOtherForm.careReceiverNation,
              nativePlace: this.orderOtherForm.nativePlace,
              houseProvinceCode: this.orderOtherForm.houseProvinceCode,
              houseProvinceName: this.orderOtherForm.houseProvinceName,
              houseCityCode: this.orderOtherForm.houseCityCode,
              houseCityName: this.orderOtherForm.houseCityName,
              houseDistrictCode: this.orderOtherForm.houseDistrictCode,
              houseDistrictName: this.orderOtherForm.houseDistrictName,
              houseDetailAddress: this.orderOtherForm.houseDetailAddress,
              careReceiverPolitical: this.orderOtherForm.careReceiverPolitical,
              careReceiverEducation: this.orderOtherForm.careReceiverEducation,
              maritalStatus: this.orderOtherForm.maritalStatus,
              medicalType: this.orderOtherForm.medicalType,
              medicalCardNo: this.orderOtherForm.medicalCardNo,
              careReceiverFaith: this.orderOtherForm.careReceiverFaith,
              physicalDamage: this.orderOtherForm.physicalDamage
            },
            //紧急联系人
            careReceiverFamilyList: this.orderOtherForm.careReceiverFamilyList
          };
          updateCareReceiver(params)
            .then(response => {
              if (
                response.data.statusCode == "200" ||
                response.data.statusCode == 200
              ) {
                this.$message.success("修改成功");
                this.loadingBtn = false;
                this.isEditOther = false;
                this.flagOther = false;
                this.getOrderDetail();
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("updateOrderInfoForCareReceiver:" + error);
            });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     *
     * 服务信息保存
     *
     *
     */
    saveService(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var params = {
            //服务信息
            orderCode: this.orderCode,
            serviceStartDate: this.serviceForm.serviceStartDate,
            serviceEndDate: this.serviceForm.serviceEndDate,
            visitDate:
              this.serviceForm.visitDate == null
                ? ""
                : this.serviceForm.visitDate,
            careProviderGender: this.serviceForm.careProviderGender,
            recommendDate: this.serviceForm.recommendDate,
            recommendCode: this.serviceForm.recommendCode,
            recommendName: this.serviceForm.recommendName,
            recommendOrgCode: this.serviceForm.recommendOrgCode,
            recommendOrgName: this.serviceForm.recommendOrgName,
            assessorCode: this.serviceForm.assessorCode,
            assessorName: this.serviceForm.assessorName,
            evaluationTime:
              this.serviceForm.assessDate == null
                ? ""
                : this.serviceForm.assessDate,
            remark: this.serviceForm.remark,
            //是否关联订单
            isRelation: this.serviceForm.isRelation == "0" ? "0" : "1",
            relationOrderCode:
              this.serviceForm.isRelation == "1"
                ? this.serviceForm.relationOrderCode
                : "",
            serviceFileUrls: this.serviceForm.serviceFileUrls
          };
          updateOrderInfoForService(params)
            .then(response => {
              if (
                response.data.statusCode == "200" ||
                response.data.statusCode == 200
              ) {
                this.$message.success("修改成功");
                this.serviceLoadingBtn = false;
                this.serviceIsEdit = false;
                this.serviceFlag = false;
                this.disabledFile = true;
                this.hideUpload = true;
                this.getOrderDetail();
              } else {
                this.$message.error(response.data.statusMsg);
                return false;
              }
            })
            .catch(error => {
              console.log("updateOrderInfoForService:" + error);
            });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    //加载户籍省市区
    getHouseNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.houseOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.houseOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name
                        };
                      });
                    }
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //户籍选择下拉框
    handleExpandChangeHouse(val) {
      this.getHouseNodes(val);
    },
    //将户籍省市区注入到Form中
    addHouseToForm(val) {
      this.house = val;
      this.houseName = this.$refs["houseList"].getCheckedNodes();
      this.orderOtherForm.houseProvinceCode = this.house[0];
      this.orderOtherForm.houseProvinceName = this.houseName[0].pathLabels[0];
      this.orderOtherForm.houseCityCode = this.house[1];
      this.orderOtherForm.houseCityName = this.houseName[0].pathLabels[1];
      this.orderOtherForm.houseDistrictCode = this.house[2];
      this.orderOtherForm.houseDistrictName = this.houseName[0].pathLabels[2];
    },
    changeHouse(val) {
      this.$refs["houseList"].presentText = "";
      if (!val) {
        this.$refs[
          "houseList"
        ].inputValue = this.orderOtherForm.houseDistrictName;
        this.$refs[
          "houseList"
        ].presentText = this.orderOtherForm.houseDistrictName;
      }
    },
    //加载本市地址
    getLiveNodes(val) {
      let idArea;
      let sizeArea;
      if (!val) {
        idArea = 0;
        sizeArea = 0;
      } else if (val.length === 1) {
        idArea = val[0];
        sizeArea = val.length; //一级
      } else if (val.length === 2) {
        idArea = val[1];
        sizeArea = val.length; //二级
      } else if (val.length === 3) {
        idArea = val[2];
        sizeArea = val.length; //三级
      }
      let params = {
        pid: idArea
      };
      findAddressDictList(params).then(
        response => {
          let Items = response.data.responseData;
          if (sizeArea === 0) {
            this.liveOptions = Items.map((value, i) => {
              return {
                id: value.id,
                name: value.name,
                cities: []
              };
            });
          } else if (sizeArea === 1) {
            // 点击一级 加载二级 市
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                if (!value.cities.length) {
                  value.cities = Items.map((value, i) => {
                    return {
                      id: value.id,
                      name: value.name,
                      cities: []
                    };
                  });
                }
              }
            });
          } else if (sizeArea === 2) {
            // 点击二级 加载三级 区
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    if (!value.cities.length) {
                      // Items.pop();  //移除最后一个数组元素
                      value.cities = Items.map((value, i) => {
                        return {
                          id: value.id,
                          name: value.name,
                          cities: []
                        };
                      });
                    }
                  }
                });
              }
            });
          } else if (sizeArea === 3) {
            // 点击三级 加载四级 街道
            this.liveOptions.map((value, i) => {
              if (value.id === val[0]) {
                value.cities.map((value, i) => {
                  if (value.id === val[1]) {
                    value.cities.map((value, i) => {
                      if (value.id === val[2]) {
                        if (!value.cities.length) {
                          // Items.pop();  //移除最后一个数组元素
                          value.cities = Items.map((value, i) => {
                            return {
                              id: value.id,
                              name: value.name
                            };
                          });
                        }
                      }
                    });
                  }
                });
              }
            });
          }
        },
        error => {
          console.log(error);
        }
      );
    },
    //本市地址选择下拉框
    handleExpandChangeLive(val) {
      this.getLiveNodes(val);
    },
    //将本市地址省市区注入到Form中
    addLiveToForm(val) {
      this.live = val;
      this.liveName = this.$refs["liveList"].getCheckedNodes();
      this.orderForm.liveProvinceCode = this.live[0];
      this.orderForm.liveProvinceName = this.liveName[0].pathLabels[0];
      this.orderForm.liveCityCode = this.live[1];
      this.orderForm.liveCityName = this.liveName[0].pathLabels[1];
      this.orderForm.liveDistrictCode = this.live[2];
      this.orderForm.liveDistrictName = this.liveName[0].pathLabels[2];
      this.orderForm.liveSubdistrictCode = this.live[3];
      this.orderForm.liveSubdistrictName = this.liveName[0].pathLabels[3];
    },
    changeLive(val) {
      this.$refs["liveList"].presentText = "";
      if (!val) {
        this.$refs["liveList"].inputValue = this.orderForm.liveSubdistrictName;
        this.$refs["liveList"].presentText = this.orderForm.liveSubdistrictName;
      }
    },
    //获取服务开始时间
    changeServiceStartDate(data) {
      if (data) {
        this.serviceForm.serviceStartDate = data;
        this.$refs.serviceForm.validateField("serviceStartDate");
        if (this.serviceForm.serviceLongTime) {
          this.computeEndTime();
        }
      } else {
        this.serviceForm.serviceStartDate = "";
        this.$refs.serviceForm.validateField("serviceStartDate");
      }
    },
    //获取服务开结束时间
    changeServiceEndDate(data) {
      if (data) {
        this.$nextTick(() => {
          this.serviceForm.serviceEndDate = data;
          this.serviceForm.serviceLongTime = "";
          this.$refs.serviceForm.validateField("serviceEndDate");
        });
      } else {
        this.serviceForm.serviceEndDate = "";
        this.serviceForm.serviceLongTime = "";
        this.$refs.serviceForm.validateField("serviceEndDate");
      }
    },
    //获取服务时长
    computedServiceEndDate() {
      if (this.serviceForm.serviceStartDate) {
        this.computeEndTime();
      }
    },
    //计算结束时间
    computeEndTime() {
      if (
        this.serviceForm.serviceStartDate != "" &&
        this.serviceForm.serviceLongTime != ""
      ) {
        var date = new Date(this.serviceForm.serviceStartDate);
        date.setMonth(
          date.getMonth() + parseInt(this.serviceForm.serviceLongTime)
        );
        this.serviceForm.serviceEndDate = date;
      }
    },
    //身份证上传成功时的钩子
    handleBriefChange(response, file, fileList) {
      if (response) {
        let urls = [];
        this.idCardFileList = [];
        if (fileList.length == 2) {
          this.hideBriefUpload = true;
        }
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
            this.idCardFileList.push({
              name: item.name,
              status: item.status,
              type: item.type,
              uid: item.uid,
              url: item.response.responseData
            });
          } else {
            urls.push(item.url);
            this.idCardFileList.push(item);
          }
        });
        let checkoutPhotos = "";
        urls.forEach(items => {
          checkoutPhotos += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (checkoutPhotos.length > 0) {
          checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
        }
        this.orderForm.careReceiverIdCardPhoto = checkoutPhotos;
      }
    },
    handleRemove(file) {
      let fileList = this.idCardFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1); //删除选中的元素,this.idCardFileList返回剩余的元素;
      let checkoutPhotos = "";
      this.idCardFileList.map(items => {
        checkoutPhotos += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (checkoutPhotos.length > 0) {
        checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
      }
      this.hideBriefUpload = false;
      this.orderForm.careReceiverIdCardPhoto = checkoutPhotos;
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      window.open(file.url, "_blank");
    },
    /**
     *
     * 资料上传
     *
     */
    //资料上传限制
    getUrl(response, file, fileList) {
      if (response) {
        let urls = [];
        this.serviceFileList = [];
        if (fileList.length == 10) {
          this.hideUpload = true;
        }
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
            this.serviceFileList.push({
              name: item.name,
              status: item.status,
              type: item.type,
              uid: item.uid,
              url: item.response.responseData
            });
          } else {
            urls.push(item.url);
            this.serviceFileList.push(item);
          }
        });
        let fileUrl = "";
        urls.forEach(items => {
          fileUrl += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (fileUrl.length > 0) {
          fileUrl = fileUrl.substr(0, fileUrl.length - 1);
        }
        this.serviceForm.serviceFileUrls = fileUrl;
        if(this.serviceFileList.length > 0) {
          for (let i = 0; i < this.serviceFileList.length; i++) {
            var n = this.serviceFileList[i].name.substring(this.serviceFileList[i].name.indexOf(".") + 1, this.serviceFileList[i].name.length);
            if ('mp4'.indexOf(n) !== -1) {
              this.serviceFileList[i].type = "vedio"
              this.findvideocover(this.serviceFileList[i].url);
            } else {
              this.serviceFileList[i].type = "img"
            }
          }
        }
      }
    },
    //删除文件
    removeList(file, cfileList) {
      let fileList = this.serviceFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      if (index > -1) {
        let deletArr = fileList.splice(index, 1);
        let fileUrl = "";
        this.serviceFileList.map(items => {
          fileUrl += items.url + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (fileUrl.length > 0) {
          fileUrl = fileUrl.substr(0, fileUrl.length - 1);
        }
        this.hideUpload = false;
        this.serviceForm.serviceFileUrls = fileUrl;
      }
    },
    //获取现居住详细地址
    openMap() {
      this.showMap = true;
    },
    closeDialog(flag) {
      this.showMap = flag;
    },
    getAddressDetail(data) {
      this.orderForm.liveDetailAddress = data[0];
      this.orderForm.liveLongitude = data[1].lng;
      this.orderForm.liveLatitude = data[1].lat;
    },
    //新增删除联系人操作
    removeContacts(item) {
      var index = this.orderOtherForm.careReceiverFamilyList.indexOf(item);
      if (index !== -1) {
        this.orderOtherForm.careReceiverFamilyList.splice(index, 1);
      }
      //强制手动渲染页面
      this.$forceUpdate();
    },
    addContacts(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.orderOtherForm.careReceiverFamilyList.push({
            careReceiverCode: "",
            familyMemberName: "",
            contactsTel: "",
            relationship: "",
            relationshipValue: "",
            isGuardian: "0",
            isGuardianValue: ""
          });
          //强制手动渲染页面
          this.$forceUpdate();
        } else {
          this.$message.error("请检查是否填写完整");
          this.loadingBtn = false;
          return false;
        }
      });
    },
    //关联订单模糊查询
    selectOrderCode(item) {
      if (item.value !== "无") {
        this.serviceForm.relationOrderName = item.code;
        this.serviceForm.relationOrderCode = item.value;
      } else {
        this.serviceForm.relationOrderCode = "";
      }
    },
    removeOrderCode() {
      this.serviceForm.relationOrderCode = "";
      this.serviceForm.relationOrderName = "";
    },
    queryOrderCode(queryString, cb) {
      let params = {};
      if (queryString) {
        params = {
          pageNum: 1,
          pageSize: 10,
          selectOrderCode: queryString,
          orderCode: this.orderCode
        };
      } else {
        params = {
          pageNum: 1,
          pageSize: 10,
          selectOrderCode: queryString,
          orderCode: this.orderCode
        };
      }
      findRelationEtProductOrder(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.relationOrder = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.relationOrder.push({
                value: data[i].orderCode,
                code: "订单号:" + data[i].orderCode
              });
            }
            var results = this.relationOrder;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findRelationEtProductOrder:" + error);
          return false;
        });
    },
    //推荐组织模糊查询
    selectRecommendOrgName(item) {
      if (item.value !== "无") {
        this.serviceForm.recommendOrgCode = item.code;
        this.serviceForm.recommendOrgName = item.value;
      } else {
        this.serviceForm.recommendOrgName = "";
      }
    },
    removeRecommendOrgCode() {
      this.serviceForm.recommendOrgName = "";
      this.serviceForm.recommendOrgCode = "";
    },
    queryRecommendOrgName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        orgName: queryString
      };
      findEhrOrgAll(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.recommendOrg = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.recommendOrg.push({
                value: data[i].orgName,
                code: data[i].orgCode
              });
            }
            var results = this.recommendOrg;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //推荐人模糊查询
    selectStaffName(item) {
      if (item.value !== "无") {
        this.serviceForm.recommendCode = item.code;
        this.serviceForm.recommendName = item.value;
      } else {
        this.serviceForm.recommendCode = "";
        this.serviceForm.recommendName = "";
      }
    },
    removeStaffCode() {
      this.serviceForm.recommendCode = "";
      this.serviceForm.recommendName = "";
    },
    queryStaffName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        staffFullName: queryString,
        isDataAuthority: 1
      };
      findStaffAll(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.recommend = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.recommend.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel
              });
            }
            var results = this.recommend;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //评估人模糊查询
    selectAssessorName(item) {
      if (item.value !== "无") {
        this.serviceForm.assessorCode = item.code;
        this.serviceForm.assessorName = item.value;
      } else {
        this.serviceForm.assessorName = "";
      }
    },
    removeAssessorCode() {
      this.serviceForm.assessorCode = "";
      this.serviceForm.assessorName = "";
    },
    queryAssessorName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        staffFullName: queryString
      };
      findStaffList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.assessor = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.assessor.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel
              });
            }
            var results = this.assessor;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    //根据身份证计算出生年月
    blurChangeBirthday() {
      this.$refs.orderForm.validateField("careReceiverIdCard", cardError => {
        if (!cardError) {
          //当校验通过时，这里面写逻辑代码
          let card = this.orderForm.careReceiverIdCard;
          if (card.length == 15) {
            //第一代身份证
            this.orderForm.careReceiverBirthday =
              "19" +
              card.substring(6, 8) +
              "-" +
              card.substring(8, 10) +
              "-" +
              card.substring(10, 12);
          } else {
            this.orderForm.careReceiverBirthday =
              card.substring(6, 10) +
              "-" +
              card.substring(10, 12) +
              "-" +
              card.substring(12, 14);
          }
        } else {
          this.orderForm.careReceiverBirthday = "";
        }
      });
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaff() {
      this.isEdit = true;
      this.flag = true;
      this.disabled = false;
      this.hideBriefUpload = false;
      this.getOrderDetail();
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editStaffOther() {
      this.isEditOther = true;
      this.flagOther = true;
      this.getOrderDetail();
    },
    /**
     *
     * 保存/修改切换
     *
     */
    editService() {
      this.serviceIsEdit = true;
      this.serviceFlag = true;
      this.disabledFile = false;
      this.hideUpload = false;
      this.getOrderDetail();
    },
    /**
     *
     * 数据字典
     *
     */
    initDataDictionary() {
      //性别
      findValueBySetCode({ valueSetCode: "GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.genderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //政治面貌
      findValueBySetCode({ valueSetCode: "STAFF_POLITICAL" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.politicalOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //最高学历
      findValueBySetCode({ valueSetCode: "EDUCATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.educationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //婚姻状况
      findValueBySetCode({ valueSetCode: "RECRUIT_MARITAL_STATUS" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.maritalStatusOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //医保类型
      findValueBySetCode({ valueSetCode: "HEALTH_INSURANCE_TYPE" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.mediacalTypeOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //宗教信仰
      findValueBySetCode({ valueSetCode: "FAITH" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.faithOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //身体损伤
      findValueBySetCode({ valueSetCode: "PHYSICAL_INJURY" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.physicalInjuryOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //服务者性别
      findValueBySetCode({ valueSetCode: "CARE_PROVIDER_GENDER" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.careProviderGenderOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //联系人关系
      findValueBySetCode({ valueSetCode: "CARE_RECEIVER_RELATION" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.relationOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否关联订单
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isRelatedOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
      //是否是监护人
      findValueBySetCode({ valueSetCode: "YES_OR_NO" })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.isGuardianOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:" + error);
          return false;
        });
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.orderCode = param.orderCode;
    if (this.orderCode == undefined) {
      this.orderCode = JSON.parse(sessionStorage.getItem("editOrderCode"));
    } else {
      sessionStorage.setItem("editOrderCode", JSON.stringify(this.orderCode));
    }
    //查询订单详情
    this.getOrderDetail();
    //初始化数据字典
    this.initDataDictionary();
    //加载户籍省市区
    this.getHouseNodes();
    //加载现居住省市区
    this.getLiveNodes();
  },
  destroyed() {
    sessionStorage.removeItem("editOrderCode");
  }
};
</script>

<style lang="scss" scoped>
#orderManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}
.main-content {
  border-radius: 10px;
  background: #fff;
  margin: 0px 20px 20px 20px;
  padding: 0px 20px 20px 20px;
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-cascader {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.importToolbar {
  padding: 10px;
  border: 0.1px solid #e0e6eb;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9f9f9;
  .form-tag {
    font-size: 16px;
    border-left: 5px solid #f98c3c;
    padding-left: 10px;
    font-weight: 550;
  }
  .rightBtn {
    float: right;
  }
}
.importToolbar_title {
  padding: 10px;
  line-height: 30px;
  .form-tag-title {
    font-size: 15px;
    margin-left: 50px;
    font-weight: 800;
  }
  .rightBtn {
    float: right;
  }
}
.form-content {
  font-size: 16px;
  margin: 0px auto;
}
.remark-style {
  display: block;
  width: 300px;
  margin-top: 5px;
}
.form-item {
  width: 30%;
  min-width: 500px;
  padding-bottom: 5px;
  max-height: 50px;
}
.form-items {
  width: 100%;
  min-width: 500px;
}
.form-item-product {
  margin: 10px 0px;
  width: 100%;
}
.form-item-table {
  width: 20%;
  min-width: 300px;
}
.form-item-tables {
  width: 30%;
  min-width: 450px;
  height: 50px;
}
.radioRight {
  margin-right: 10px;
}
.panel-card {
  border: 1px solid #e0e6eb;
  border-radius: 8px;
  margin: 0px 10px 10px 10px;
}
.itemToptip {
  position: relative;
  font-size: 12px;
  width: 108px;
  height: 30px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  float: left;
  margin-top: -25px;
  line-height: 30px;
  padding-right: 10px;
}
.el-upload__tip {
  width: 120px;
  line-height: 15px;
}
</style>
<style lang="scss">
#orderManage {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
  .el-dialog__header {
    padding-bottom: 30px;
  }
  .hideBriefImg .el-upload--picture-card {
    display: none;
  }
  .el-upload--picture-card {
    width: 100px;
    height: 100px;
    line-height: 100px;
  }
  .el-upload-list--picture-card .el-upload-list__item-actions:hover span {
    display: contents;
  }
  .el-upload-list--picture-card .el-upload-list__item {
    width: 100px;
    height: 100px;
  }
}
</style>
