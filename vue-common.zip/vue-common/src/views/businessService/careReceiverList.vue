<template>
  <div id="orderManage">
    <headTag :tagName="tagName"/>

    <!-- 搜索筛选 -->
    <div class="filter_wrap">
      <el-form ref="filterForm" :inline="true" :model="filters" label-width="100px">
        <el-row>
          <el-col class="form-item">
            <el-form-item label="组织" prop="orgName">
              <el-input
                size="mini"
                v-model.trim="filters.orgName"
                placeholder="请选择组织"
                @focus="dialogVisible=true"
                @clear="clearOrgCode"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="姓名" prop="careReceiverName">
              <el-input
                size="mini"
                v-model.trim="filters.careReceiverName"
                clearable
                placeholder="请输入姓名"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="身份证号" prop="careReceiverIdCard">
              <el-input
                size="mini"
                v-model.trim="filters.careReceiverIdCard"
                clearable
                placeholder="请输入身份证号"
                maxlength="18"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="联系电话" prop="careReceiverTel">
              <el-input
                size="mini"
                v-model.trim="filters.careReceiverTel"
                placeholder="请输入联系电话"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="被照护人地址" prop="liveDetailAddress">
              <el-input
                size="mini"
                v-model.trim="filters.liveDetailAddress"
                placeholder="请输入被照护人地址"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-item">
            <el-form-item label="推荐人" prop="recommendName">
              <el-input
                size="mini"
                v-model.trim="filters.recommendName"
                placeholder="请输入推荐人"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col class="form-item">
            <el-form-item label="提供人" prop="provideName">
              <el-input
                size="mini"
                v-model.trim="filters.provideName"
                placeholder="请输入提供人"
                clearable
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item label="创建时间" prop="createDate">
              <el-date-picker
                v-model.trim="filters.createDate"
                clearable
                size="mini"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="form-items">
            <el-form-item class="search_btn">
              <el-button
                size="mini"
                type="primary"
                icon="el-icon-search"
                :loading="searchLoading"
                @click="getList(1)"
              >查询</el-button>
              <el-button size="mini" type="primary" icon="el-icon-refresh" @click="resetForm">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="tableToolbar">
      <el-row class="tableTopBtn">
        <el-col :span="24">
          <el-button size="mini" type="primary" icon="el-icon-plus" @click="insertOrders(1)">新增</el-button>
        </el-col>
      </el-row>
      <!--列表-->
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        size="mini"
        :data="dataList"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
      >
        <el-table-column label="组织" min-width="150" prop="orgUnitName"></el-table-column>
        <el-table-column label="姓名" min-width="80" prop="careReceiverName"></el-table-column>
        <el-table-column label="性别" min-width="80" prop="careReceiverGenderValue"></el-table-column>
        <el-table-column label="身份证号" min-width="120" prop="careReceiverIdCard"></el-table-column>
        <el-table-column label="联系电话" min-width="80" prop="careReceiverTel"></el-table-column>
        <el-table-column label="被照护人地址" min-width="200" prop="liveProvinceName">
          <template slot-scope="scope">
            {{scope.row.liveProvinceName}}
            {{scope.row.liveCityName}}
            {{scope.row.liveDistrictName}}
            {{scope.row.liveSubdistrictName}}
            {{scope.row.liveDetailAddress}}
          </template>
        </el-table-column>
        <!-- <el-table-column label="推荐组织" min-width="120" prop="recommendOrgName"></el-table-column> -->
        <el-table-column label="推荐人" min-width="80" prop="recommendName"></el-table-column>
        <el-table-column label="提供人" min-width="80" prop="provideName"></el-table-column>
        <el-table-column label="创建时间" min-width="120" prop="createDate"></el-table-column>
        <el-table-column label="创建人" min-width="80" prop="createName"></el-table-column>
        <el-table-column fixed="right" min-width="100" label="操作">
          <template slot-scope="scope">
            <span>
              <el-button size="mini" type="text" @click="handleEdit(scope.row)">查看</el-button>
            </span>
          </template>
        </el-table-column>
      </el-table>
      <!--工具条-->
      <el-row class="pageToolbar">
        <pagination
          v-if="totalCount>0"
          :total="totalCount"
          :page.sync="filters.page"
          :limit.sync="filters.pageSize"
          @pagination="pageChange"
        ></pagination>
      </el-row>

      <el-dialog
        title="组织架构"
        :visible.sync="dialogVisible"
        width="500px"
        :before-close="handleCloseOrg"
      >
        <org-select v-on:listenTochildEvent="getCurrentNode"/>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { findEhrOrgList } from "api/orgStructure";
import HeadTag from "components/HeadTag";
import Pagination from "components/Pagination/pagination";
import { findValueBySetCode, selectGiverListForSchedule } from "api/common";
import { findEtCareReceiverList } from "api/businessService/careReceiver";
import { changeYMD } from "utils";
import OrgSelect from "components/OrgSelect";
export default {
  data() {
    return {
      tagName: "被照护人管理",
      //组织弹窗
      dialogVisible: false,
      dataList: [],
      listLoading: false,
      //条件查询
      filters: {
        orgCode: "",
        orgName: "",
        careReceiverName: "",
        careReceiverIdCard: "",
        careReceiverTel: "",
        liveDetailAddress:"",
        recommendOrgName: "",
        recommendName: "",
        provideName: "",
        createDate: [],
        page: 1,
        pageSize: 10
      },
      totalCount: 0,
      searchLoading: false
    };
  },
  components: {
    HeadTag,
    Pagination,
    OrgSelect
  },
  methods: {
    //父组件触发事件
    pageChange(val) {
      this.filters.page = val.page;
      this.filters.pageSize = val.limit;
      this.getList(val.page); //改变页码，重新渲染页面
    },
    getList(page) {
      this.filters.page = page;
      var params = {
        pageNum: page,
        pageSize: this.filters.pageSize,
        orgCode: this.filters.orgCode,
        careReceiverName: this.filters.careReceiverName,
        careReceiverIdCard: this.filters.careReceiverIdCard,
        careReceiverTel: this.filters.careReceiverTel,
        liveDetailAddress: this.filters.liveDetailAddress,
        recommendName: this.filters.recommendName,
        provideName: this.filters.provideName,
        createDateB: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[0]+" 00:00:00") : null,
				createDateE: (this.filters.createDate && this.filters.createDate.length > 0) ? (this.filters.createDate[1]+" 23:59:59") : null
      };
      this.listLoading = true;
      this.searchLoading = true;
      findEtCareReceiverList(params)
        .then(response => {
          if (response.data.responseData != undefined) {
            if (
              response.data.statusCode == 200 ||
              response.data.statusCode == "200"
            ) {
              this.dataList = response.data.responseData;
              this.totalCount = response.data.totalCount;
              this.listLoading = false;
              this.searchLoading = false;
            } else {
              this.$message.error(response.data.statusMsg);
              this.listLoading = false;
              this.searchLoading = false;
              return false;
            }
          } else {
            this.listLoading = false;
            this.searchLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log("findStaffList:" + error);
          this.listLoading = false;
          this.searchLoading = false;
          return false;
        });
    },
    handleCloseOrg() {
      this.dialogVisible = false;
    },
    //获取组织
    getCurrentNode(data) {
      this.filters.orgName = data.orgName;
      this.filters.orgCode = data.orgCode;
      this.handleCloseOrg();
    },
    //清空组织过滤
    clearOrgCode() {
      this.filters.orgName = "";
      this.filters.orgCode = "";
    },
    //跳转新增订单页面
    insertOrders(page) {
      this.$router.push({
        path: "/businessServiceManagement/addCareReceiver",
        query: {
          type: "insert"
        }
      });
    },
    //查看订单详情
    handleEdit(row) {
      this.$router.push({
        path: "/businessServiceManagement/addCareReceiver",
        query: {
          type: "update",
          careReceiverCode: row.careReceiverCode
        }
      });
    },
    resetForm() {
      this.$refs.filterForm.resetFields();
      this.getList(1);
    }
  },
  created() {},
  mounted() {},
  activated() {
    this.getList(1);
  }
};
</script>

<style lang="scss" scoped>
#orgSelect {
  height: 500px;
  overflow-y: auto;
}
#orderManage {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}
.el-input {
  width: 200px;
}
.el-select {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 305px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.form-itemss {
  width: 30%;
  min-width: 250px;
}
.search_btn {
  min-width: 250px;
  margin-left: 20px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 20px 20px 20px 0px;
}
.pic_icon {
  width: 20px;
  height: 20px;
}
.fund-order {
  margin: 20px 0;
}
.orderNumber {
  font-size: 20px;
  color: #000;
  margin: 30px 0 30px 0;
}
.el-autocomplete {
  width: 200px;
}
.order_title {
  margin: 20px 0;
  text-align: center;
  font-size: 16px;
  color: #000;
}
</style>
<style lang="scss">
#orderManage {
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }
}
.el-dialog__body {
  padding: 0px 20px;
}
.filter-input {
  width: 100%;
}
#orgSelect .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#orgSelect .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#orgSelect .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content {
  color: #f98c3c;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content i {
  background-color: #f98c3c;
  width: 8px;
  height: 8px;
  display: -webkit-inline-box;
  border-radius: 50%;
  margin-right: 5px;
}
.el-autocomplete-suggestion {
  min-width: 220px;
}
</style>
