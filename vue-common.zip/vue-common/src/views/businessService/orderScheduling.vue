<template>
  <div id="scheduling">
    <headTag :tagName="tagName"/>

    <div class="container">
      <el-row class="importToolbar" type="flex">
        <el-col style="width:60px;text-align:center;height:80px">
           <el-avatar
                  size="large"
                  src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
                  style="height:60px;width:60px;margin-top:10px;"
                ></el-avatar>
        </el-col>
        <el-col>
              <el-row style="padding:5px 10px 10px 10px;">
                <el-row>
                  <el-col class="form-item">
                    <span style="font-size:16px">{{orderInfo.careReceiverName}}</span>
                    <span style="margin-left:10px;font-size:16px">{{orderInfo.assessGrade}}</span>
                    <el-tag type="warning" style="margin-left:10px;font-size:16px">{{orderInfo.serviceStatusValue}}</el-tag>
                  </el-col>
                </el-row>
                <el-row style="margin-top:15px">
                  <el-col class="form-item">
                     <span class="info-style">性别：{{orderInfo.careReceiverGenderValue}}</span>
                     <span class="info-style">年龄：{{orderInfo.careReceiverAge}}</span>
                     <span class="info-style">身份证号：{{orderInfo.careReceiverIdCard}}</span>
                     <span class="info-style">联系电话：{{orderInfo.careReceiverTel}}</span>
                     <span class="info-style long-field">街道：{{orderInfo.etCareReceiverOutDto.liveProvinceName}}{{orderInfo.etCareReceiverOutDto.liveCityName}}{{orderInfo.etCareReceiverOutDto.liveDistrictName}}{{orderInfo.etCareReceiverOutDto.liveSubdistrictName}}</span>
                     <span class="info-style long-field">详细地址：{{orderInfo.etCareReceiverOutDto.liveDetailAddress}}</span>
                  </el-col>
                  
                </el-row>
              </el-row>
        </el-col>
        <el-col :span="2" style="float:right">
          <span v-if="orderInfo.serviceFrequencyType == 10">
            <el-button @click="deleteAll" class="rightBtn" type="danger" size="mini">批量删除</el-button>
          </span>
          <span v-if="orderInfo.serviceFrequencyType == 20">
            <el-button @click="deleteAllMonth" class="rightBtn" type="danger" size="mini">批量删除</el-button>
          </span>
        </el-col>
      </el-row>

      <span v-if="orderInfo.serviceFrequencyType == 10">
        <scheduling-week ref="schedulingWeek" :orderInfo="orderInfo"></scheduling-week>
      </span>
  
      <span v-if="orderInfo.serviceFrequencyType == 20">
        <scheduling-month ref="schedulingMonth" :orderInfo="orderInfo"></scheduling-month>
      </span>

      <div class="staff-schedule-container">
        <StaffSchedule
          v-if="staffScheduleVisible"
          :staffScheduleVisible="staffScheduleVisible"
          :isWeekDay="isWeekDay"
          @onStaffScheduleClose="onStaffScheduleClose"
        />
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import SchedulingWeek from "components/SchedulingWeek";
import SchedulingMonth from "components/SchedulingMonth";
import StaffSchedule from "@/views/businessService/staffScheduleForPage";
import { getOrderDetail } from "api/orderManagement";
import { deleteByCareReceiverCode } from "api/businessService/orderPaymentReview";

export default {
  data() {
    return {
      tagName: "排程",
      staffScheduleVisible: true,
      isWeekDay: false,
      orderInfo: {},
      //页面传参
      orderCode: ""
    };
  },
  components: {
    HeadTag,
    SchedulingWeek,
    SchedulingMonth,
    StaffSchedule
  },
  methods: {
    getOrderDetail() {
      var param = {
        orderCode: this.orderCode
      }; //TODO
      getOrderDetail(param)
        .then(response => {
          if (response.data.statusCode == "200") {
            this.orderInfo = response.data.responseData;
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("getOrderDetail:" + error);
        });
    },
    //员工排程
    staffOrders() {
      this.staffScheduleVisible = true;
      this.isWeekDay = false; //TODO 根据工单的排程类型是否为周传值
    },
    onStaffScheduleClose() {
      this.staffScheduleVisible = false;
    },
    //批量删除所有员工排程和工单排程
    deleteAll() {
      const h = this.$createElement;
      this.$msgbox({
        title: "警告",
        message: h("p", null, [
          h("span", null, "此操作将删除该照护人所有排程, "),
          h("i", { style: "color: red" }, "请务必谨慎操作！是否继续？")
        ]),
        showCancelButton: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            var param = {
              careReceiverCode: this.orderInfo.careReceiverCode,
              orderCode: this.orderInfo.orderCode
            };
            deleteByCareReceiverCode(param)
              .then(response => {
                if (response.data.statusCode == "200") {
                  this.$message.success("操作成功");
                  this.$refs.schedulingWeek.resetForm();
                  this.$refs.schedulingWeek.findWorkorderSchedule();
                } else {
                  this.$message.success(response.data.statusMsg);
                  this.$refs.schedulingWeek.resetForm();
                  this.$refs.schedulingWeek.findWorkorderSchedule();
                  return false;
                }
                done();
              })
              .catch(error => {
                console.log("getOrderDetail:" + error);
              });
              done();
          } else {
            done();
          }
        }
      }).then(action => {});
    },
    //批量删除所有员工排程和工单排程
    deleteAllMonth() {
      const h = this.$createElement;
      this.$msgbox({
        title: "警告",
        message: h("p", null, [
          h("span", null, "此操作将删除该照护人所有排程, "),
          h("i", { style: "color: red" }, "请务必谨慎操作！是否继续？")
        ]),
        showCancelButton: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            var param = {
              careReceiverCode: this.orderInfo.careReceiverCode,
              orderCode: this.orderInfo.orderCode
            };
            deleteByCareReceiverCode(param)
              .then(response => {
                if (response.data.statusCode == "200") {
                  this.$message.success("操作成功");
                  this.$refs.schedulingMonth.resetForm();
                  this.$refs.schedulingMonth.findWorkorderSchedule();
                } else {
                  this.$message.success(response.data.statusMsg);
                  this.$refs.schedulingMonth.resetForm();
                  this.$refs.schedulingMonth.findWorkorderSchedule();
                  return false;
                }
                done();
              })
              .catch(error => {
                console.log("getOrderDetail:" + error);
              });
              done();
          } else {
            done();
          }
        }
      }).then(action => {});
    }
  },
  created() {
    //获取传入的参数
    var param = this.$route.query;
    this.orderCode = param.code;
    //初始化被照护人信息
    this.getOrderDetail();
  },
  mounted() {
    
  }
};
</script>

<style lang="scss" scoped>
#scheduling {
  width: 100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 0px;
  }
}

.form-item {
  min-width: 80px;
  font-weight: 800;
  margin-left: 10px;
  height: 20px;
}

.form-item-service {
  width: 80px;
  min-width: 80px;
  margin-top: -3px;
  .font-style {
    height: 20px;
    line-height: 20px;
  }
}

.importToolbar {
  margin-left: 10px;
  margin-right: 10px;
  .rightBtn {
    float: right;
    margin-top: 10px;
  }
}

.form-item-top {
  width: 120px;
  min-width: 120px;
  height:20px
}

.form-item-top-two {
  width: 280px;
  min-width: 280px;
  height:20px
}
.staff-schedule-container {
  border: 1px solid #e0e6eb;
  margin-left: 10px;
  margin-right: 10px;
  border-radius: 8px;
  margin-top: 10px;
}
.container {
  background-color: #fff;
  border-radius: 10px;
  padding: 0px 10px 20px 10px;
  margin: 0px 20px 20px 20px;
}
.info-style{
  margin-right: 30px;
  color:#666666;
  padding-top: 2px;
}
</style>