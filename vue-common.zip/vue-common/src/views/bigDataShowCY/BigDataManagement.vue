<template>
  <div id="bigDataSettings">
    <headTag :tagName="tagName" />
    <div class="main-content">
      <div class="panel-card">
        <span class="form-tag">大屏设置</span>
      </div>
      <div class="main-box">
        <div class="main-left">
          <ul class="equipment-box">
            <li v-for="(item,index) in settingNameList" :key="index">
              <div class="left-title" @click="showToggle(item,index)">
                <div class="setting_title" :id="'jump'+index">
                  <img :src="item.isSubShow==true ? imgRight:imgLeft" />
                  <span class="scroll-item">{{item.name}}</span>
                </div>
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='1'">
                <!--机构信息-->
                <BigDataOrgInformation />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='2'">
                <!--机构介绍-->
                <BigDataOrgIntroduction />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='3'">
                <!--机构风采-->
                <BigDataOrgAppearance />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='4'">
                <!--员工信息-->
                <BigDataStaffInformation />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='5'">
                <!--入住老人信息-->
                <BigDataOlderInformation />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='6'">
                <!--康养-->
                <BigDataHealthCare />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='7'">
                <!--辅具-->
                <BigDataAssistiveDevice />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='8'">
                <!--文化娱乐-->
                <BigDataActivitiesInformation />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='9'">
                <!--居家服务-->
                <BigDataHomeCare />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='10'">
                <!--食堂-->
                <BigDataCanteenInformation />
              </div>
              <div class="settingForm" v-if="item.isSubShow&&item.type=='11'">
                <!--门诊-->
                <BigDataTreatment />
              </div>
            </li>
          </ul>
        </div>
        <div class="main-right" id="nav-fixed" :class="{nav_fixed : isFixed}">
          <ul class="menu-right">
            <li
              v-for="(item,index) in settingNameList"
              :key="index"
              :class="activeStep === index ? 'colorClass':''"
              @click="jump(index)"
            >{{item.name}}</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeadTag from "components/HeadTag";
import OrgSelect from "components/OrgSelect";
import Pagination from "components/Pagination/pagination";
import { findSysUserList } from "api/systemManagement/index.js";
import BigDataOrgIntroduction from "./BigDataOrgIntroduction";
import BigDataActivitiesInformation from "./BigDataActivitiesInformation";
import BigDataAssistiveDevice from "./BigDataAssistiveDevice";
import BigDataCanteenInformation from "./BigDataCanteenInformation";
import BigDataHealthCare from "./BigDataHealthCare";
import BigDataHomeCare from "./BigDataHomeCare";
import BigDataOlderInformation from "./BigDataOlderInformation";
import BigDataOrgAppearance from "./BigDataOrgAppearance";
import BigDataStaffInformation from "./BigDataStaffInformation";
import BigDataTreatment from "./BigDataTreatment";
import BigDataOrgInformation from "./BigDataOrgInformation";
const cubic = value => Math.pow(value, 3);
const easyInOutCubic = value =>
  value < 0.5 
  ? cubic(value * 2) / 2 
  : 1 - cubic((1 - value) * 2) / 2;
export default {
  components: {
    HeadTag,
    OrgSelect,
    Pagination,
    BigDataOrgIntroduction,
    BigDataActivitiesInformation,
    BigDataAssistiveDevice,
    BigDataCanteenInformation,
    BigDataHealthCare,
    BigDataHomeCare,
    BigDataOlderInformation,
    BigDataOrgAppearance,
    BigDataStaffInformation,
    BigDataTreatment,
    BigDataOrgInformation
  },
  props: {},
  data() {
    return {
      tagName: "大屏信息设置",
      activeStep: 0,
      lastOffsetTop: 0,
      isJump: false,
      keyWords: {
        orgName: "",
        eventStatus: "",
        alarmTime: "",
        careReceiverName: "",
        userStatus: "",
        pageNum: 1,
        pageSize: 10
      },
      settingNameList: [
        {
          name: "机构信息",
          isSubShow: true,
          type: 1
        },
        {
          name: "机构介绍",
          isSubShow: true,
          type: 2
        },
        {
          name: "机构风采",
          isSubShow: true,
          type: 3
        },
        {
          name: "员工信息",
          isSubShow: true,
          type: 4
        },
        {
          name: "入住老人信息",
          isSubShow: true,
          type: 5
        },
        {
          name: "康养",
          isSubShow: true,
          type: 6
        },
        {
          name: "辅具",
          isSubShow: true,
          type: 7
        },
        {
          name: "文化娱乐",
          isSubShow: true,
          type: 8
        },
        {
          name: "居家服务",
          isSubShow: true,
          type: 9
        },
        {
          name: "食堂",
          isSubShow: true,
          type: 10
        },
        {
          name: "门诊",
          isSubShow: true,
          type: 11
        }
      ],
      imgLeft:
        process.env.NODE_ENV === "development"
          ? "/static/img/up-icon.png"
          : "/fsk/static/img/up-icon.png",
      imgRight:
        process.env.NODE_ENV === "development"
          ? "/static/img/down-icon.png"
          : "/fsk/static/img/down-icon.png",
      totalCount: 0,
      eventOptions: [],
      tableData: [],
      statusOptions: [],
      dialogVisible: false,
      listLoading: false,
      isFixed: true,
      offsetTop: 0,
      monitorForm: {
        url:
          "  http://hls01open.ys7.com/openlive/b21aegafasfsgfrewgtyrejhty2da8bc6e9cb5f90.m3u8"
      },
      mattressForm: {
        createDate: "",
        orderCode: ""
      }
    };
  },
  watch: {},
  computed: {},
  methods: {
    showToggle(item, index) {
      // console.log(item, index, '999999')
      this.settingNameList.forEach(i => {
        // 判断如果数据中的reportList[i]的show属性不等于当前数据的isSubShow属性那么reportList[i]等于false
        if (i.isSubShow !== this.settingNameList[index].isSubShow) {
          // i.isSubShow = true;
          i.isSubShow = !this.settingNameList[index].isSubShow;
        }
      });
      item.isSubShow = !item.isSubShow;
      this.$forceUpdate();
    },
    jump(domId) {
      this.isJump = true;
      this.activeStep = domId;
      //获取头部是否固定
      let headerFlag = this.$store.state.settings.fixedHeader;
      // 当前窗口正中心位置到指定dom位置的距离
      //页面滚动了的距离
      let height =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      //指定dom到页面顶端的距离
      let dom = document.getElementById("jump" + domId);
      let domHeight;

      if (headerFlag) {
        domHeight = dom.offsetTop - 60;
      } else {
        domHeight = dom.offsetTop + 40;
      }

      const container = document.querySelector(".main-left");
      var raf = window.requestAnimationFrame || (func => setTimeout(func, 16));
      const beginTime = Date.now();
      var animationFunc = (timeStample) => {
        const progress = (Date.now() - beginTime) / 500;
        window.scrollTo({
          top:
            domHeight +
            (this.lastOffsetTop - domHeight) * (1 - easyInOutCubic(progress)),
        });
        if (progress < 1) {
          this.isJump = true;
          raf(animationFunc);
        } else {
          this.lastOffsetTop = domHeight;
          setTimeout(() => {
            this.isJump = false;
          }, 16);
        }
      };
      raf(animationFunc);
    },
    // 滚动监听  滚动触发的效果写在这里
    handleScroll() {
      if (this.isJump) {
        return;
      }
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop >= this.offsetTop) {
        this.isFixed = true;
      } else {
        this.isFixed = false;
      }
      if (scrollTop) {
        for (let i = 0; i < this.settingNameList.length; i++) {
          let currentItem = document.querySelector("#jump" + i);
          let nextItem = document.querySelector("#jump" + (i + 1));
          if (
            nextItem &&
            scrollTop > currentItem.offsetTop - 60 &&
            scrollTop < nextItem.offsetTop - 60
          ) {
            this.activeStep = i;
            this.lastOffsetTop = currentItem.offsetTop - 60;
          }
        }
      }
    },
    // 列表数据
    getList(page) {
      this.listLoading = true;
      this.keyWords.pageNum = page;
      findSysUserList(this.keyWords)
        .then(response => {
          if (
            response.data.statusCode === 200 ||
            response.data.statusCode === "200"
          ) {
            this.tableData = response.data.responseData;
            this.totalCount = response.data.totalCount;
            this.listLoading = false;
          } else {
            this.$message.error(response.data.statusMsg);
            this.listLoading = false;
            return false;
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
    //父组件触发事件
    pageChange(val) {
      this.keyWords.page = val.page;
      this.keyWords.pageSize = val.limit;
      this.getList(val.page);
    }
  },
  destroyed() {
    // 设置bar浮动阈值为 #fixedBar 至页面顶部的距离
    this.offsetTop = document.querySelector("#nav-fixed").offsetTop;
    // 离开页面 关闭监听 不然会报错
    window.removeEventListener("scroll", this.handleScroll);
  },
  created() {},
  mounted() {
    // 开启滚动监听
    window.addEventListener("scroll", this.handleScroll);
  }
};
</script>
<style lang="scss" scoped>
#bigDataSettings {
  width: 100%;
  min-width: 1200px;
  .settingTop {
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 3px 9px 0px rgba(51, 51, 51, 0.1);
    border-radius: 6px;
    height: 270px;
    margin: 0px 20px 20px 20px;
    display: flex;
    .info-left {
      // float: left;
      padding: 30px 55px 0 55px;
      display: flex;
      .person-detail {
        flex: 1;
        .info-news {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          color: rgba(51, 51, 51, 1);
          font-size: 16px;
        }
      }
    }
    .info-right {
      // float: left;
      .basic-info {
      }
    }
  }
  .main-content {
    border-radius: 10px;
    background: #fff;
    margin: 0px 20px 20px 20px;
    border-radius: 10px;
    .panel-card {
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      padding: 24px 0 24px 17px;
      background-color: #f9f9f9;
      border-bottom: 1px solid #e6e6e6;
      .form-tag {
        font-size: 20px;
        border-left: 5px solid #f98c3c;
        padding-left: 10px;
      }
    }
    .main-box {
      display: flex;
      .main-left {
        background: #ffffff;
        width: 90%;
        .equipment-box {
          list-style: none;
          li {
            padding: 30px 25px 30px 30px;
            .left-title {
              cursor: pointer;
              .setting_title {
                vertical-align: middle;
                img {
                  width: 12px;
                  height: 12px;
                  color: #666666;
                  display: inline-block;
                  margin: 0 4px;
                  vertical-align: middle;
                  transition: 0.5s;
                  transform-origin: center;
                  transform: rotateZ(360deg);
                }
                img:active {
                  width: 12px;
                  height: 12px;
                  color: #666666;
                  display: inline-block;
                  margin: 0 4px;
                  vertical-align: middle;
                  transition: transform 0.3s;
                  transform-origin: center;
                  transform: rotateX(-45deg);
                }
                .scroll-item {
                  color: #333333;
                  font-size: 16px;
                  font-family: "Adobe Heiti Std R";
                  vertical-align: middle;
                }
              }
            }
          }
          .settingForm {
            border-bottom: 1px solid #ededed;
            margin-left: 30px;
            margin-right: 24px;
            font-family: Adobe Heiti Std R;
            .titleName {
              color: #333333;
              font-size: 16px;
              margin: 25px 0 20px 0;
            }
            .settIngBox {
              margin-bottom: 20px;
              span {
                color: #666666;
                font-size: 16px;
                margin-right: 30px;
              }
            }
            .equipment-info {
              margin-bottom: 20px;
              span {
                color: #666666;
                font-size: 16px;
                margin-right: 150px;
              }
            }
            .period-time {
              display: flex;
              .period-left {
                margin-bottom: 18px;
                .periodName {
                  color: #333333;
                  font-size: 16px;
                }
                .timeClass {
                  width: 260px;
                }
              }
              .period-right {
                margin-bottom: 18px;
                margin-left: 300px;
                .periodName {
                  color: #333333;
                  font-size: 16px;
                }
                .periodinput {
                  display: flex;
                  div {
                    color: #333333;
                    font-size: 16px;
                  }
                }
                .inputClass {
                  width: 160px;
                }
              }
            }
            .period-breath {
              display: flex;
              .period-left {
                color: #333333;
                font-size: 16px;
                .periodinput {
                  display: flex;
                  // margin-bottom: 18px;
                  color: #333333;
                  font-size: 16px;
                  div {
                    .inputClass {
                      width: 160px;
                    }
                  }
                }
              }
              .period-right {
                color: #333333;
                font-size: 16px;
                margin-left: 105px;
                .periodinput {
                  display: flex;
                  // margin-bottom: 18px;
                  color: #333333;
                  font-size: 16px;
                }
                .inputClass {
                  width: 160px;
                }
                .timeClass {
                  width: 260px;
                }
              }
            }
            .period-frequency {
              margin-bottom: 18px;
              .periodName {
                color: #333333;
                font-size: 16px;
              }
              .periodinput {
                display: flex;
                div {
                  color: #333333;
                  font-size: 16px;
                }
                .timeClass {
                  width: 260px;
                }
                .inputClass {
                  width: 160px;
                }
              }
            }
          }
        }

        .margin-left-form {
          border-radius: 10px;
          margin-bottom: 10px;
          padding-bottom: 20px;
          background: #fff;
        }
      }
      .main-right {
        background: #ffffff;
        position: fixed; /*fixed总是以body为定位时的对象，总是根据浏览器的窗口来进行元素的定位，通过"left"、 "top"、 "right"、 "bottom" 属性进行定位。*/
        right: 18px; /*设置与右侧的距离*/
        top: 176px; /*设置与顶部的距离*/
        width: 10%;
        height: 600px;
        border: 1px solid #e4e5e6;
        .menu-right {
          background: #ffffffff;
          line-height: 34px;
          overflow-y: scroll;
          list-style: none;
          height: 595px;
          li {
            padding: 0 0 14px 15px;
            font-size: 14px;
            font-family: "Adobe Heiti Std";
            // font-weight: 600;
            color: #333333;
            cursor: pointer;
          }
          .colorClass {
            font-size: 14px;
            color: #398af1;
            font-family: "Adobe Heiti Std";
            font-weight: 600;
            border-left: 1px solid #398af1;
            cursor: pointer;
          }
        }
      }
    }
  }
}
.info-text {
  margin-top: 25px;
  font-size: 16px;
  color: #666666;
  font-family: Adobe Heiti Std;
}
.titleFormName {
  margin: 20px 0 20px 35px;
}
// .timeClass {
// 	width: 230px;
// }
.inputClass {
  width: 150px;
}

.el-select {
  width: 200px;
}

.form-item {
  width: 30%;
  min-width: 295px;
}
.form-items {
  width: 35%;
  min-width: 350px;
}
.search_btn {
  width: 30%;
  min-width: 295px;
  margin-left: 90px;
}
.tableTopBtn {
  background-color: white;
  text-align: right;
  padding: 10px 20px 10px 0px;
}
</style>
