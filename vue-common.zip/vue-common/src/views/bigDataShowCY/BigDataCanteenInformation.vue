<!--食堂-->
<template>
  <div>
    <el-button @click="dialogAddDish=true" size="small" primary>新增</el-button>
    <el-form ref="propertyForm" :inline="true" :model="dishForm" label-width="125px">
        <CommonTableWidget
            @queryMethod="queryMethod"
            :propertyList="colConfig"
            :formModel="dishForm"
            :tableDataName="'dataList'"
            ref="CommonTableWidget"
            :optWidth="200"
            :showTableIndex="false"
            :pageChange="pageChange"
        />
    </el-form>
    <el-button @click="dialogAddRun=true" size="small" primary>新增</el-button>
    <el-form :inline="true" :model="dishForm" label-width="125px">
        <CommonTableWidget
            @queryMethod="queryMethod"
            :propertyList="colConfig2"
            :formModel="dishForm2"
            :tableDataName="'dataList'"
            ref="CommonTableWidget"
            :optWidth="200"
            :showTableIndex="false"
            :pageChange="pageChange"
        />
    </el-form>
    <el-dialog
      title="菜谱"
      :visible.sync="dialogAddDish"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form ref="addForm" :model="addForm" label-width="100px">
        <el-row>
          <el-form-item label="菜名" prop="title">
            <el-input placeholder="请输入菜名"></el-input>
          </el-form-item>
           <el-form-item label="价格（元）" prop="title">
            <el-input placeholder="请输入价格"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="运营数据"
      :visible.sync="dialogAddRun"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form ref="addForm" :model="addForm" label-width="80px">
        <el-row>
          <el-form-item label="客户类型" prop="title">
            <el-input placeholder="请输入客户类型"></el-input>
          </el-form-item>
           <el-form-item label="就餐方式" prop="title">
            <el-input placeholder="请输入就餐方式"></el-input>
          </el-form-item>
           <el-form-item label="人数" prop="title">
            <el-input placeholder="请输入人数"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
export default {
  data() {
    return {
      dialogAddDish:false,
      dialogAddRun:false,
      dishForm: {
        dataList: [
          {
            dishName: "宫爆鸡丁",
            price: "12",
            status: "出院",
            updateTime: "2020-5-18 16:01:23"
          }
        ],
        page:1,
        pageSize:10
      },
       dishForm2: {
        dataList: [
          {
            dishName: "宫爆鸡丁",
            price: "12",
            status: "出院",
            updateTime: "2020-5-18 16:01:23"
          }
        ],
        page:1,
        pageSize:10
      },
      colConfig: [
        {
          propertyName: "菜名",
          propertyFieldName: "dishName",
          propertyType: "10",
        },
        {
          propertyName: "价格",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "状态",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        },
      ],
      colConfig2: [
        {
          propertyName: "客户类型",
          propertyFieldName: "dishName",
          propertyType: "10",
        },
        {
          propertyName: "就餐方式",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "人数",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        },
      ],
    };
  },
  components:{
      CommonTableWidget
  },
  methods: {
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    pageChange(val){
        alert("pageChange咯")
    }
  }
};
</script>
<style scoped>
</style>