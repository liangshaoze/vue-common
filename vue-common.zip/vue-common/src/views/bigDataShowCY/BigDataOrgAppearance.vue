<template>
  <div>
    <el-button @click="dialogAdd=true" size="small" primary>新增</el-button>
    <el-form ref="propertyForm" :inline="true" :model="orgAppearanceForm" label-width="125px">
      <CommonTableWidget
        @queryMethod="queryMethod"
        :propertyList="colConfig"
        :formModel="orgAppearanceForm"
        :tableDataName="'dataList'"
        ref="CommonTableWidget"
        :optWidth="200"
        :showTableIndex="false"
        :pageChange="pageChange"
      />
    </el-form>
    <el-dialog
      title="机构风采"
      :visible.sync="dialogAdd"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form :model="addForm" label-width="60px">
        <el-row>
          <el-form-item label="标题" prop="title">
            <el-input placeholder="请输入标题"></el-input>
          </el-form-item>
         <el-form-item label="图片:">
                <el-upload
                  ref="uploadBrief"
                  :class="{hideBrief:hideBriefUpload}"
                  :action="actionUrl"
                  list-type="picture-card"
                  :on-remove="removeBriefList"
                  :on-success="handleBriefChange"
                  accept="image/png, image/gif, image/jpg, image/jpeg"
                  multiple
                  :limit="2"
                  :file-list="idCardFileList"
                >
                  <i class="el-icon-plus"></i>
                  <div
                    slot="tip"
                    style="font-size: 16px;color: #606266;"
                    class="el-upload__tip"
                  >仅能上传二张图片！</div>
                </el-upload>
              </el-form-item>
          <el-form-item label="内容" prop="title">
            <el-input placeholder="请输入图片" type="textarea" rows="3"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
export default {
  data() {
    return {
      dialogAdd: false,
      addStatus: [],
      disabledAddBtn:false,
      addForm:{},
       //图片上传
      hideBriefUpload: false,
      //上传阿里云地址
      actionUrl: process.env.BASE_API + "fsk-system/common/fileUpload",
      idCardFileList:[],//图片文件列表
      orgAppearanceForm: {
        dataList: [
          {
            title: "标题一",
            picUrl: "https://zhaohu365.com/asdff",
            content: "暗示法gas发大水",
            status: "sdfsdfdasfewe",
            updateTime: "2020-5-18 16:01:23",
          }
        ],
        picUrls:"",
        page: 1,
        pageSize: 10
      },
      colConfig: [
        {
          propertyName: "标题",
          propertyFieldName: "title",
          propertyType: "10"
        },
        {
          propertyName: "图片",
          propertyFieldName: "picUrl",
          propertyType: "10",
          width: "250"
        },
        {
          propertyName: "内容",
          propertyFieldName: "content",
          propertyType: "10",
          width: "200"
        },
        {
          propertyName: "状态",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        }
      ]
    };
  },
  components: {
    CommonTableWidget
  },
  methods: {
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    pageChange(val) {
      alert("pageChange咯");
    },
    handleCloseDialog() {
      this.dialogAdd = false;
    },
    removeBriefList(file, inputFileMainList) {
      let fileList = this.idCardFileList;
      let index = fileList.findIndex(fileItem => {
        return fileItem.uid === file.uid;
      });
      let deletArr = fileList.splice(index, 1); //删除选中的元素,this.idCardFileList返回剩余的元素;
      let checkoutPhotos = "";
      this.idCardFileList.map(items => {
        checkoutPhotos += items.url + ",";
      });
      //去掉最后一个逗号(如果不需要去掉，就不用写)
      if (checkoutPhotos.length > 0) {
        checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
      }
      this.hideBriefUpload = false;
      this.orgAppearanceForm.picUrls = checkoutPhotos;
    },
    //身份证上传成功时的钩子
    handleBriefChange(response, file, fileList) {
      if (response) {
        let urls = [];
        this.idCardFileList = [];
        if (fileList.length == 2) {
          this.hideBriefUpload = true;
        }
        fileList.forEach(item => {
          if (item.response) {
            urls.push(item.response.responseData);
          } else {
            urls.push(item.url);
          }
          this.idCardFileList.push(item);
        });
        let checkoutPhotos = "";
        urls.forEach(items => {
          checkoutPhotos += items + ",";
        });
        //去掉最后一个逗号(如果不需要去掉，就不用写)
        if (checkoutPhotos.length > 0) {
          checkoutPhotos = checkoutPhotos.substr(0, checkoutPhotos.length - 1);
        }
        this.orgAppearanceForm.picUrls = checkoutPhotos;
      }
    },
  }
};
</script>
<style scoped>
</style>