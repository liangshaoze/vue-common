<!--机构信息-->
<template>
  <div>
    <el-form label-width="135px" :rules="rules" v-model="infoForm">
      <el-row>
        <el-col class="form-item">
          <el-form-item label="机构名称" prop="orgName">
            <span>**长照</span>
          </el-form-item>
        </el-col>
        <el-col  class="form-item">
          <el-form-item label="地址" prop="address">
            <span>水电路1388号</span>
          </el-form-item>
        </el-col>
        <el-col  class="form-item">
          <el-form-item label="院长" prop="name">
            <el-input placeholder="请输入院长名字"></el-input>
          </el-form-item>
        </el-col>
        <el-col  class="form-item">
          <el-form-item label="院长信箱" prop="email">
             <el-input placeholder="请输入院长信箱"></el-input>
          </el-form-item>
        </el-col>
         <el-col  class="form-item">
          <el-form-item label="今日值班负责人" prop="onDuty">
             <el-input placeholder="请输入今日值班负责人"></el-input>
          </el-form-item>
        </el-col>
        <el-col  class="form-item">
          <el-form-item label="值班电话" prop="telphone">
             <el-input placeholder="请输入值班电话"></el-input>
          </el-form-item>
        </el-col>
        <el-col  class="form-item">
          <el-form-item label="床位数" prop="bedCount">
             <el-input placeholder="请输入床位数"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      infoForm:{
        orgName:"",
        address:"",
      },
      rules:{
        name:[{required:true,message:"请输入院长名字"}],
        email:[{required:true,message:"请输入院长邮箱"}],
        onDuty:[{required:true,message:"请输入今日值班负责人"}],
        telphone:[{required:true,message:"请输入值班电话"}],
        bedCount:[{required:true,message:"请输入床位数"}]
      }
    };
  }
};
</script>
<style scoped>
.form-item {
  width: 30%;
  min-width: 470px;
  padding-bottom: 5px;
  max-height: 60px;
}
</style>