<template>
	<div id="visit">
		<div id="content" style="width:450px; height:200px;"></div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {

		};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("content"));
			var xArr = ['方式一', '方式二', '方式三', '方式四', '方式五', '方式六'];
			var yArr = [10000, 15000, 20000, 25000, 30000, 35000];
			var option = {
				title: {
					text: '就诊方式',
					textStyle: {
						fontSize: 12,
						color: "white"
					},
					left: "2%",
					top: "2%"
				},
				tooltip: {
					trigger: "item",
					formatter: "{a} <br/>{b}: {c}"
				},
				// legend: {
				// 	left: 'right',
				// 	top: '30',
				// 	data: xArr,
				// 	icon: 'rect',
				// 	itemWidth: 10,
				// 	itemHeight: 10,
				// },
				grid: {
					left: '3%',
					right: '4%',
					bottom: '5%',
					containLabel: true
				},
				xAxis: {
					data: xArr,
					axisTick: {
						lineStyle:{color:'RGB(255, 255, 255, 0.2)'}  
					},
					nameTextStyle: {
						"color": "#fff"
					},
					axisLine: {
						lineStyle: {
							color: "RGB(255, 255, 255, 0.6)"
						}
					},
					axisLabel: {
						textStyle: {
							color: "RGB(255, 255, 255, 0.6)"
						},
					}
				},
				yAxis: {
					axisLabel: {
						textStyle: {
							color: "RGB(255, 255, 255, 0.6)"
						},
						formatter: "{value}"
					},
					splitLine: {
						lineStyle: {
							type: "dashed",
							color:'RGB(255, 255, 255, 0.2)'
						}
					},
					axisLine: {
						show: false,
						// lineStyle: {
						// 	color: "RGB(47,68,114)"
						// }
					},
					axisTick: {
						show: false,
					}
				},
				series: [{
					name: '方式',
					type: 'bar',
					barWidth: '15%',
					barGap: '-100%',
					itemStyle: {
						normal: {
							barBorderRadius: 30,
							color: new this.$echarts.graphic.LinearGradient(
								0, 0, 0, 1, [{
									offset: 0,
									color: '#00feff'
								},
								{
									offset: 0.5,
									color: '#027eff'
								},
								{
									offset: 1,
									color: '#0286ff'
								}
							]
							)
						}
					},
					data: yArr
				}]
			};
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#visit {
}
</style>