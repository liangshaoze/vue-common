<template>
	<div id="healthCare">
		<div id="homeCare" style="width:450px; height:200px;"></div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("homeCare"));
			var option = {
				title: [
					{
						text: "居家服务项统计",
						textStyle: {
							fontSize: 12,
							color: "white"
						},
						left: "2%",
						top: "2%"
					}
				],
				tooltip: {
					trigger: "axis",
					show: true
				},
				radar: {
					indicator: [
						{
							name: "服务项一",
							max: 100,
							color: 'rgba(255,255,255,0.6)',
							fontSize: 12
						},
						{
							name: "服务" + "\n" + "项二",
							max: 100,
							color: 'rgba(255,255,255,0.6)',
							fontSize: 12
						},
						{
							name: "服务" + "\n" + "项三",
							max: 100,
							color: 'rgba(255,255,255,0.6)',
							fontSize: 12
						},
						{
							name: "服务" + "\n" + "项四",
							max: 100,
							color: 'rgba(255,255,255,0.6)',
							fontSize: 12
						},
						{
							name: "服务" + "\n" + "项五",
							max: 100,
							color: 'rgba(255,255,255,0.6)',
							fontSize: 12
						}
					],
					radius: "60%",
					center: ["50%", "55%"],
					shape: "circle",
					splitNumber: 4,
					name: {
						textStyle: {
							color: "#ffffff",
							fontSize: 12
						}
					},
					splitArea: {
						areaStyle: {
							color: [
								"rgba(255,255,255,0.1)",
								"rgba(255,255,255,0.03)",
								"rgba(255,255,255,0.1)",
								"rgba(255,255,255,0.03)"
							]
						}
					},
					splitLine: {
						lineStyle: {
							color: [
								"#197CF7",
								"#197CF7",
								"#197CF7",
								"#197CF7",
								"#197CF7",
								"#197CF7"
							].reverse(),
							width: 1,
							opacity: 0.3
						}
					},
					axisLine: {
						show: false
					}
				},
				series: {
					name: "居家服务项统计",
					type: "radar",
					tooltip: {
						trigger: "item"
					},
					data: [
						{
							value: [100, 90, 80, 66, 90],
							//在拐点处显示数值
							label: {
								normal: {
									show: true,
									position: "bottom",
									fontSize:10,
									color: "rgba(255,255,255,1)",
									formatter: params => {
										return params.value;
									}
								}
							}
						}
					],
					symbol: "circle",
					symbolSize: 10,
					itemStyle: {
						normal: {
							color: "rgba(24,243,235,0.8)",
							borderColor: "rgba(24,243,235,0.2)",
							borderWidth: 1
						}
					},
					areaStyle: {
						normal: {
							color: "rgba(25,124,247,0.3)"
						}
					},
					lineStyle: {
						normal: {
							color: "rgba(13, 178, 255, 1)",
							width: 0.1
						}
					}
				}
			};
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#healthCare {
}
</style>