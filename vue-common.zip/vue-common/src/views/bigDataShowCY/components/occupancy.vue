<template>
	<div id="box">
		<div class="text">
			<span class="textColor">
				总床位
				<span>&nbsp;&nbsp;200</span>
			</span>
			<span class="textColor">
				未入住
				<span>&nbsp;&nbsp;80</span>
			</span>
		</div>
		<div id="occupancy" style="width:300px; height:200px;"></div>
		<div class="bottom">
			<p>
				已入住
				<span>&nbsp;&nbsp;200</span>
			</p>
			<p>
				男
				<span>&nbsp;&nbsp;150</span>
			</p>
			<p>
				女
				<span>&nbsp;&nbsp;50</span>
			</p>
		</div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {

		};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("occupancy"));
			var option = {
				backgroundColor: '',
				title: {
					text: '入住统计',
					textStyle: {
						fontSize: 12,
						color: "white"
					},
					left: "2%",
					top: "2%"
				},
				tooltip: {
					trigger: 'item',
					// formatter: '{a} <br/>{b} : {c} ({d}%)'
				},
				// legend: {
				// 	left: 'center',
				// 	top: 'bottom',
				// 	textStyle: {
				// 		color: '#fff',   //修改标识字体颜色
				// 	},
				// 	data: ['紧急', '主要', '次要', '提示']
				// },
				color: ['#17D582', '#1948F7'], //修改饼图颜色
				series: [
					{
						name: '入住统计',
						type: 'pie',
						radius: '60%',  //调整饼图大小
						avoidLabelOverlap: true,    //是否启用防止标签重叠策略
						center: ['30%', '50%'],  //调整饼图整体位置
						label: {
							normal: {
								show: true,
								position: 'inner',      //显示在扇形上
								// formatter: ' {c}',  //显示内容
								formatter: function (parms) {
									return parms.data.legendname
								},
								textStyle: {
									color: 'white',    // 改变标示文字的颜色
									fontSize: 12,  //文字大小
									fontWeight: 'bold'
								},
							},
						},
						data: [
							{ value: 25, name: '未入住' },
							{ value: 20, name: '已入住' },
						],
						emphasis: {
							itemStyle: {
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							}
						}
					}
				],

			};
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#box {
}
.text {
	position: absolute;
	left: 590px;
	top: 17px;
	.textColor {
		color: rgba(255, 255, 255, 0.6);
		font-size: 12px;
		span {
			color: rgba(255, 255, 255, 1);
			font-size: 12px;
			margin: 0 4px;
		}
	}
}
.bottom {
	position: absolute;
	top: 65px;
	left: 665px;
	p {
		color: rgba(255, 255, 255, 0.6);
		font-size: 12px;
		margin-bottom: 20px;
		span {
			color: rgba(243, 117, 24, 1);
			font-size: 16px;
		}
	}
}
</style>