<template>
	<div id="ageGroup">
		<div id="age" style="width:450px; height:200px;"></div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {

		};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("age"));
			var option = {
				title: {
					text: '年龄段统计',
					textStyle: {
						fontSize: 12,
						color: "white"
					},
					left: "2%",
					top: "2%"
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: { // 坐标轴指示器，坐标轴触发有效
						type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
					}
				},
				grid: {
					left: '2%',
					right: '4%',
					bottom: '10%',
					top: '25%',
					containLabel: true
				},
				legend: {
					data: ['男', '女'],
					right: 150,
					top: 12,
					textStyle: {
						color: "RGB(255, 255, 255, 0.6)"
					},
					itemWidth: 10,
					itemHeight: 10,
					// itemGap: 35
				},
				xAxis: {
					data: ['60岁以下', '60-70', '70-80', '80-90', '90-100', '100以上'],
					axisTick: {
						lineStyle: { color: 'RGB(255, 255, 255, 0.2)' }
					},
					nameTextStyle: {
						"color": "#fff",
						
					},
					axisLine: {
						lineStyle: {
							color: "RGB(255, 255, 255, 0.6)"
						}
					},
					axisLabel: {
						fontSize: 10,
						textStyle: {
							color: "RGB(255, 255, 255, 0.6)",
							
						},
					},
					
				},

				yAxis: {
					type: 'value',
					// max: '1200',
					axisLine: {
						show: false,
						// lineStyle: {
						// 	color: 'white'
						// }
					},
					splitLine: {
						show: true,
						lineStyle: {
							type: "dashed",
							color: 'RGB(255, 255, 255, 0.2)'
						}
					},
					axisTick: {
						show: false,
					},
					axisLabel: {
						textStyle: {
							color: "RGB(255, 255, 255, 0.6)"
						},
					}
				},

				series: [{
					name: '男',
					type: 'bar',
					barWidth: '15%',
					itemStyle: {
						normal: {
							color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
								{
								offset: 0,
								color:  'rgba(25,124,247,1)'
							}, 
							{
								offset: 0.5,
								color: 'rgba(24,223,236,0.6)'
							}, 
							{
								offset: 1,
								color: 'rgba(24,223,236,1)'
							}]),
							barBorderRadius: 12,
						},
					},
					data: [4000, 5000, 6000, 7000, 10000, 15000,]
				},
				{
					name: '女',
					type: 'bar',
					barWidth: '15%',
					itemStyle: {
						normal: {
							color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [{
								offset: 0,
								color: 'rgba(243,24,111,1)'
							},
							{
								offset: 0,
								color: 'rgba(241,67,67,0.6)'
							}, 
							 {
								offset: 1,
								color: 'rgba(241,67,67,1)'
							}]),
							barBorderRadius: 11,
						}
					},
					data: [10000, 15000, 20000, 25000, 30000, 18000, ]
				}
				]
			};

			// var app = {
			// 	currentIndex: -1,
			// };
			// setInterval(function () {
			// 	var dataLen = option.series[0].data.length;

			// 	// 取消之前高亮的图形
			// 	myChart.dispatchAction({
			// 		type: 'downplay',
			// 		seriesIndex: 0,
			// 		dataIndex: app.currentIndex
			// 	});
			// 	app.currentIndex = (app.currentIndex + 1) % dataLen;
			// 	//console.log(app.currentIndex);
			// 	// 高亮当前图形
			// 	myChart.dispatchAction({
			// 		type: 'highlight',
			// 		seriesIndex: 0,
			// 		dataIndex: app.currentIndex,
			// 	});
			// 	// 显示 tooltip
			// 	myChart.dispatchAction({
			// 		type: 'showTip',
			// 		seriesIndex: 0,
			// 		dataIndex: app.currentIndex
			// 	});


			// }, 1000);
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#ageGroup {
}
</style>