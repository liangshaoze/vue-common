<!--员工年龄统计-->
<template>
	<div>
		<div class="chartContainer">
			<div style="margin:8px 0 0 8px;font-size:12px;">客户等级统计</div>
		</div>
		<div id="staffAge"></div>
	</div>
</template>
<script>
export default {
	data () {
		return {
			data: [
				{
					country: "一级",
					type: "男",
					value: 13
				},
				{
					country: "一级",
					type: "女",
					value: 30
				},
				{
					country: "二级",
					type: "男",
					value: 51
				},
				{
					country: "二级",
					type: "女",
					value: 30
				},
				{
					country: "三级",
					type: "男",
					value: 51
				},
				{
					country: "三级",
					type: "女",
					value: 30
				},
			]
		};
	},
	methods: {
		createChart () {
			var chart = new G2.Chart({
				container: "staffAge",
				width: 260,
				height: 160,
				padding: [0, 0, 0, 40]
			});
			chart.data(this.data);
			chart.scale("value", {
				alias: "客户数（位）"
			});
			chart.legend({
				items: [
					{ name: '男', value: '男', marker: { symbol: 'square', style: { fill: '#F38418', r: 5 } } },
					{ name: '女', value: '女', marker: { symbol: 'square', style: { fill: '#9E18F3', r: 5 } } },
				],
				position: 'top',
			});
			chart.axis("value", false);
			chart.coordinate().transpose();
			chart.facet("mirror", {

				fields: ["type"],
				autoSetAxis: false,
				transpose: true,
				showTitle: false,
				eachView: (view, facet) => {
					const facetIndex = facet.columnIndex;
					if (facetIndex === 0) {
						view.axis("country", {
							position: "top",
							label: {
								style: {
									fill: "#C3D9D7FF",
									fontSize: 12
								}
							},
							tickLine: {
								alignWithLabel: false,
								length: 0
							},
							line: null
						});
					} else {
						view.axis("country", false);
					}
					const color = facetIndex === 0 ? "#F38418" : "#9E18F3";
					view
						.interval()
						.position("country*value")
						// .color(color)
						.color('type', (type) => {
							if (type === '男') {
								return '#F38418';
							}
							return '#9E18F3';
						})
						.size(17)
						.label("value", val => {
							let offset = facetIndex === 1 ? -4 : 4;
							let shadowBlur = 2;
							let textAlign = facetIndex === 1 ? "end" : "start";
							let fill = "black";
							if (val < 57) {
								offset = facetIndex === 1 ? 4 : -4;
								textAlign = facetIndex === 1 ? "start" : "end";
								fill = "white";
								shadowBlur = 0;
							}
							return {
								offset,
								style: {
									fill,
									shadowBlur,
									shadowColor: "rgba(0, 0, 0, .45)",
									textAlign
								}
							};
						});
				}
			});

			chart.render();
		}
	},
	mounted () {
		this.createChart();
	},
	created () { }
};
</script>
<style>
.screen-img {
	height: 100%;
	background: rgb(7, 7, 39);
}
.screen-img img {
	width: 30px;
	height: 30px;
}
.chartContainer {
	display: flex;
	justify-content: stretch;
	height: 30px;
}
</style>