<template>
	<div>
		<div id="certificate" style="width:450px; height:200px;"></div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {
		};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("certificate"));
			var m2R2Data = [{
				value: 335,
				legendname: '证书一',
				name: "证书一",
				itemStyle: {
					color: "#F3186F"
				}
			},
			{
				value: 335,
				legendname: '证书二',
				name: "证书二",
				itemStyle: {
					color: "#9E18F3"
				}
			},
			{
				value: 335,
				legendname: '证书三',
				name: "证书三",
				itemStyle: {
					color: "#197CF7"
				}
			},
			{
				value: 335,
				legendname: '证书四',
				name: "证书四",
				itemStyle: {
					color: "#F3E118"
				}
			},
			{
				value: 200,
				legendname: '证书五',
				name: "证书五",
				itemStyle: {
					color: "#F38418"
				}
			},
			];
			var option = {
				title: [{
					text: '证书统计',
					textStyle: {
						fontSize: 12,
						color: "white"
					},
					left: "2%",
					top: "2%"
				},
					// {
					// 	text: '合计',
					// 	subtext: 12312 + '个',
					// 	textStyle: {
					// 		fontSize: 20,
					// 		color: "black"
					// 	},
					// 	subtextStyle: {
					// 		fontSize: 20,
					// 		color: 'black'
					// 	},
					// 	textAlign: "center",
					// 	x: '34.5%',
					// 	y: '44%',
					// }
				],
				tooltip: {
					trigger: 'item',
					formatter: function (parms) {
						var str = parms.seriesName + "</br>" +
							parms.marker + "" + parms.data.legendname + "</br>" +
							"数量：" + parms.data.value + "</br>" +
							"占比：" + parms.percent + "%";
						return str;
					}
				},
				legend: {
					orient: 'vertical',
					x: '350px',      //可设定图例在左、右、居中
					y: 'center',     //可设定图例在上、下、居中
					// padding: [0, 100, 0, 0],
					textStyle: {
						color: "RGB(255,255,255,0.6)"
					},
					icon: 'circle',
					itemWidth: 10,
					itemHeight: 10,
				},
				series: [{
					name: '证书统计',
					type: 'pie',
					center: ['35%', '50%'],
					radius: ['40%', '65%'],
					clockwise: false, //饼图的扇区是否是顺时针排布
					avoidLabelOverlap: false,
					label: {
						normal: {
							show: true,
							position: 'outter',
							formatter: function (parms) {
								return parms.data.legendname
							}
						}
					},
					labelLine: {
						normal: {
							show: true,
							length: 10,
							length2: 20,
							lineStyle: {
								color: 'RGB(255,255,255,0.5)',
								type: 'dashed',
								// width:0.5,
							},
						}
					},
					data: m2R2Data
				}]
			};
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#certificate {
}
</style>