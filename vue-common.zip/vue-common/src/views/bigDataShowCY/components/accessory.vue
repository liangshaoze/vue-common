<template>
	<div>
		<div id="accessory" style="width:450px; height:200px;"></div>
	</div>
</template>

<script>
export default {
	components: {},
	props: {},
	data () {
		return {
			seriesData: {}
		};
	},
	watch: {},
	computed: {},
	methods: {
		createChart () {
			var myChart = this.$echarts.init(document.getElementById("accessory"));
			var option = {
				title: {
					text: '辅具统计',
					textStyle: {
						fontSize: 12,
						color: "white"
					},
					left: "2%",
					top: "2%"
				},
				grid: {
					left: '5%',
					right: '5%',
					bottom: '5%',
					top: '15%',
					containLabel: true
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'none'
					},
					formatter: function (params) {
						return params[0].name + '<br/>' +
							"<span style='display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:rgba(36,207,233,0.9)'></span>" +
							params[0].seriesName + ' : ' + Number((params[0].value.toFixed(4) / 10000).toFixed(2)).toLocaleString() + ' 个<br/>'
					}
				},
				xAxis: {
					show: false,
					type: 'value'
				},
				yAxis: [{
					type: 'category',
					inverse: true,
					axisLabel: {
						show: true,
						textStyle: {
							color: '#fff'
						},
					},
					splitLine: {
						show: false
					},
					axisTick: {
						show: false
					},
					axisLine: {
						show: false
					},
					data: ['辅具一', '辅具二', '辅具三', '辅具四', '辅具五'],
				}, {
					type: 'category',
					inverse: true,
					axisTick: 'none',
					axisLine: 'none',
					show: true,
					axisLabel: {
						textStyle: {
							color: '#ffffff',
							fontSize: '12'
						},
						formatter: function (value) {
							if (value >= 10000) {
								return (value / 10000).toLocaleString() + '个';
							} else {
								return value.toLocaleString();
							}
						},
					},
					data: [40, 80, 120, 140, 200]
				}],
				series: [{
					name: '金额',
					type: 'bar',
					zlevel: 1,
					itemStyle: {
						normal: {
							barBorderRadius: 10,
							color: new this.$echarts.graphic.LinearGradient(0, 0, 1, 0, [
								{
									offset: 0,
									color: '#00feff'
								},
								{
									offset: 0.5,
									color: '#027eff'
								},
								{
									offset: 1,
									color: '#0286ff'
								}
							]),
						},
					},
					barWidth: 10,
					data: [40, 80, 120, 140, 200],

				},
				{
					name: '背景',
					type: 'bar',
					barWidth: 10,
					barGap: '-100%',
					data: [40, 80, 120, 140, 200],
					itemStyle: {
						normal: {
							color: 'rgba(24,31,68,1)',
							barBorderRadius: 30,
						}
					},
				},
				]
			};
			myChart.setOption(option);
		}
	},
	created () { },
	mounted () {
		this.createChart();
	}
};
</script>
<style lang="scss" scoped>
#accessory {
}
</style>