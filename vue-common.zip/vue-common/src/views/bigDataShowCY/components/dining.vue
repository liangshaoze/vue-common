<template>
  <div>
    <div id="dining" style="width:450px; height:200px;"></div>
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {
    createChart() {
      var myChart = this.$echarts.init(document.getElementById("dining"));
      var option = {
        title: {
          text: "就餐统计",
          textStyle: {
            fontSize: 12,
            color: "white"
          },
          left: "2%",
          top: "2%"
        },
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            type: "pie",
            name: "套餐",
            data: [
              {
                name: "普餐",
                value: 40,
                itemStyle: {
                  color: "#F35118"
                }
              },
              {
                name: "助餐",
                value: 60,
                itemStyle: {
                  color: "#F38418"
                }
              }
            ],
            label: {
              position: "inside"
            },
            radius: [0, 55],
            itemStyle: {
              borderWidth: 0.5,
              borderColor: "#FFFFFF"
            },
            clockwise: true,
            animation: false
          },
          {
            type: "pie",
            name: "方式",
            data: [
              //普餐
              {
                name: "外送",
                value: 15,
                itemStyle: {
                  color: "#F2BDAA"
                }
              },
              {
                name: "堂吃",
                value: 25,
                itemStyle: {
                  color: "#F28861"
                }
              },
              //助餐
              {
                name: "外送",
                value: 40,
                itemStyle: {
                  color: "#E8AE74"
                }
              },
              {
                name: "堂吃",
                value: 20,
                itemStyle: {
                  color: "#F38418"
                }
              }
            ],
            label: {
              position: "outside"
            },
            labelLine: {
              normal: {
                show: true,
                length: 10,
                length2: 20,
                lineStyle: {
                  color: "RGB(255,255,255,0.5)",
                  type: "dashed"
                  // width:0.5,
                }
              }
            },
            radius: [55, 80],
            itemStyle: {
              borderWidth: 0.5,
              borderColor: "#FFFFFF"
            },
            animation: false
          }
        ]
      };
      myChart.setOption(option);
    }
  },
  created() {},
  mounted() {
    this.createChart();
  }
};
</script>
<style lang="scss" scoped>
#visit {
}
</style>