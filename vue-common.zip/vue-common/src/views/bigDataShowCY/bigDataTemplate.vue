<template>
  <div id="bdTemplate">
    <el-container>
      <el-header class="headStyle" style="height:70px;">
        <div id="weather-float-he" class="weather"></div>
        <span class="headTitle">***长者照护之家</span>
      </el-header>
      <div class="head">
        <div class="headDate">
          <el-row>
            <span class="mR5">{{nowDate}}</span>
            <span class="mR5">{{nowWeek}}</span>
          </el-row>
          <el-row>
            <span class="times">{{nowTime}}</span>
          </el-row>
        </div>
        <div class="headInfo">
          <span class="mR5">今日值班负责人: XXX</span>
          <span class="mR5">电话:xxxxxxxxxxxxxx</span>
        </div>
      </div>
      <el-main class="mainStyle">
        <bigDataHomePage/>
      </el-main>
      <el-footer class="footerStyle" style="height:40px;">
        <div class="footer">
          <div class="footerLeft">
            <el-row>
              <span class="mR5">院长:XXX</span>
              <span class="mR5">邮箱:XXXXXXX@XXX.com</span>
            </el-row>
          </div>
          <div class="footerCenter">
            <span>版权@ xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</span>
          </div>
          <div class="footerRight">
            <span class="mR5">今日值班负责人: XXX</span>
            <span class="mR5">电话:xxxxxxxxxxxxxx</span>
          </div>
        </div>
      </el-footer>
    </el-container>
  </div>
</template>

<script>
import bigDataHomePage from "./bigDataHomePage";
export default {
  data() {
    return {
      activeName: "homePage",
      //计时器
      timer: null,
      nowWeek: "",
      nowDate: "",
      nowTime: ""
    };
  },
  components: {
    bigDataHomePage
  },
  methods: {
    //时间表
    setNowTimes() {
      let myDate = new Date();
      let wk = myDate.getDay();
      let yy = String(myDate.getFullYear());
      let mm = myDate.getMonth() + 1;
      let dd = String(
        myDate.getDate() < 10 ? "0" + myDate.getDate() : myDate.getDate()
      );
      let hou = String(
        myDate.getHours() < 10 ? "0" + myDate.getHours() : myDate.getHours()
      );
      let min = String(
        myDate.getMinutes() < 10
          ? "0" + myDate.getMinutes()
          : myDate.getMinutes()
      );
      let sec = String(
        myDate.getSeconds() < 10
          ? "0" + myDate.getSeconds()
          : myDate.getSeconds()
      );
      let weeks = [
        "星期日",
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六"
      ];
      let week = weeks[wk];
      this.nowDate = yy + "年" + mm + "月" + dd + "日";
      this.nowTime = hou + ":" + min + ":" + sec;
      this.nowWeek = week;
    }
  },
  created() {},
  mounted() {
    this.setNowTimes();
    this.timer = setInterval(() => {
      this.setNowTimes();
    }, 1000);

    const oScript = document.createElement("script");
    oScript.id = "weatherFID";
    oScript.type = "text/javascript";
    oScript.innerHTML = 'WIDGET = {FID: "sm58zuQWZN" }';
    document.body.appendChild(oScript);
    const oScript1 = document.createElement("script");
    oScript1.id = "weatherJS";
    oScript1.type = "text/javascript";
    oScript1.src = "https://apip.weatherdt.com/float/static/js/r.js?v=1111";
    document.body.appendChild(oScript1);
  },
  destroyed() {
    document.getElementById("weather-float-he").remove();
  }
};
</script>

<style scoped lang="scss">
#bdTemplate {
color: white;
background-color: #060715;
height: 100%;
float: left;
}
.mR5 {
margin-right: 5px;
}
.headTitle {
display: block;
line-height: 100px;
font-size: 28px;
font-weight: 560;
text-align: center;
background: linear-gradient(
0deg,
rgb(187, 102, 22) 0%,
rgb(162, 252, 120) 100%
);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
}
.head {
width: 100%;
}
.headDate {
float: left;
width: 50%;
text-align: left;
margin: -80px 0px 0px 50px;
.times {
display: block;
text-align: left;
font-size: 25px;
padding-left: 20px;
}
}
.headInfo {
float: right;
width: 50%;
text-align: right;
font-size: 14px;
margin: -70px 50px 0px 0px;
}
.headStyle {
background-image: url("/fsk/static/img/bigData.png");
background-repeat: no-repeat;
background-size: 100% 70px;
margin: 10px;
// border: 1px solid white;
}
.mainStyle {
height: 100%;
}
.footerStyle {
line-height: 40px;
margin: 10px;
}
.footer {
width: 100%;
}
.footerLeft {
float: left;
width: 30%;
text-align: left;
}
.footerCenter {
float: left;
width: 40%;
text-align: center;
}
.footerRight {
float: right;
width: 30%;
text-align: right;
}
</style>
<style lang="scss">
#bdTemplate {
.el-main {
padding: 10px;
}
}
</style>