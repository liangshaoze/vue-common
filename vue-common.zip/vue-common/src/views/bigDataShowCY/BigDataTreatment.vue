<!--门诊-->
<template>
  <div>
    <el-button @click="dialogAddExpert=true" size="small" primary>新增</el-button>
    <el-form ref="propertyForm" :inline="true" :model="dishForm" label-width="125px">
        <CommonTableWidget
            @queryMethod="queryMethod"
            :propertyList="colConfig"
            :formModel="dishForm"
            :tableDataName="'dataList'"
            ref="CommonTableWidget"
            :optWidth="200"
            :showTableIndex="false"
            :pageChange="pageChange"
        />
    </el-form>
    <el-button @click="dialogAddTreatment=true" size="small" primary>新增</el-button>
    <el-form :inline="true" :model="dishForm" label-width="125px">
        <CommonTableWidget
            @queryMethod="queryMethod"
            :propertyList="colConfig2"
            :formModel="dishForm2"
            :tableDataName="'dataList'"
            ref="CommonTableWidget"
            :optWidth="200"
            :showTableIndex="false"
            :pageChange="pageChange"
        />
    </el-form>
    <el-dialog
      title="门诊专家"
      :visible.sync="dialogAddExpert"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form ref="addForm" :model="addForm" label-width="100px">
        <el-row>
          <el-form-item label="科室" prop="title">
            <el-input placeholder="请输入科室"></el-input>
          </el-form-item>
           <el-form-item label="职称" prop="title">
            <el-input placeholder="请输入职称"></el-input>
          </el-form-item>
           <el-form-item label="姓名" prop="title">
            <el-input placeholder="请输入姓名"></el-input>
          </el-form-item>
           <el-form-item label="挂号人数" prop="title">
            <el-input placeholder="请输入挂号人数"></el-input>
          </el-form-item>
           <el-form-item label="就诊人数" prop="title">
            <el-input placeholder="请输入就诊人数"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="就诊方式"
      :visible.sync="dialogAddTreatment"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form ref="addForm" :model="addForm" label-width="100px">
        <el-row>
          <el-form-item label="就诊方式" prop="title">
            <el-input placeholder="请输入就诊方式"></el-input>
          </el-form-item>
           <el-form-item label="就诊人数" prop="title">
            <el-input placeholder="请输入就诊人数"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
export default {
  data() {
    return {
      dialogAddExpert:false,
      dialogAddTreatment:false,
      dishForm: {
        dataList: [
          {
            dishName: "宫爆鸡丁",
            price: "12",
            status: "出院",
            updateTime: "2020-5-18 16:01:23"
          }
        ],
        page:1,
        pageSize:10
      },
       dishForm2: {
        dataList: [
          {
            dishName: "宫爆鸡丁",
            price: "12",
            status: "出院",
            updateTime: "2020-5-18 16:01:23"
          }
        ],
        page:1,
        pageSize:10
      },
      colConfig: [
        {
          propertyName: "专家姓名",
          propertyFieldName: "dishName",
          propertyType: "10",
        },
        {
          propertyName: "介绍",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "照片",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "挂号人数",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "就诊人数",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "状态",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        },
      ],
      colConfig2: [
        {
          propertyName: "就诊方式",
          propertyFieldName: "dishName",
          propertyType: "10",
        },
        {
          propertyName: "就诊人次",
          propertyFieldName: "price",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "状态",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        },
      ],
    };
  },
  components:{
      CommonTableWidget
  },
  methods: {
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    pageChange(val){
        alert("pageChange咯")
    }
  }
};
</script>
<style scoped>
</style>