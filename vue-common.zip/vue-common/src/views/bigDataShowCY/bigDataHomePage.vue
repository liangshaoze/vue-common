<template>
	<div id="bdHomePage">
		<el-row>
			<el-col :span="8">
				<div class="screen_panel row1">
					<el-col :span="16">
						<p class="orgName">机构介绍</p>
						<div>
							<el-image class="orgImg" :src="src"></el-image>
						</div>
					</el-col>
					<el-col :span="8">
						<p class="orgText">
							这是机构的介绍的介构的绍的介绍的构的
							介绍的介绍的构的介绍的介绍的构的介绍的介
							绍的构的介绍的介绍的构的介绍的介绍的。
						</p>
					</el-col>
				</div>
			</el-col>
			<el-col :span="8">
				<div class="screen_panel row1">
					<el-col>
						<div style="height:150px;">
							<el-carousel :interval="4000" trigger="click" height="150px">
								<el-carousel-item v-for="item in 4" :key="item">
									<h3 class="small">{{ item }}</h3>
								</el-carousel-item>
							</el-carousel>
						</div>
						<div style="height:50px;background:#FFFFCC;"></div>
					</el-col>
				</div>
			</el-col>
			<el-col :span="8">
				<div class="screen_panel row1">
					<el-col :span="12">
						<el-col :span="14">
							<p class="hospitalName">医生介绍</p>
							<el-image class="hospitalImg" :src="src1"></el-image>
							<p style="margin-left:35px;">张三&nbsp;外科主任</p>
						</el-col>
						<el-col :span="10">
							<p class="hospitalText">
								这是机构的介绍的介构的绍的介绍的构的
								介绍的介绍的构的介绍的介绍的构的介绍的介
								绍的构的介绍的介绍的构的介绍的介绍的。
							</p>
						</el-col>
					</el-col>
					<el-col :span="12">
						<div style="height:200px;margin-left:20px;">
							<realTimeInfo :dataList="hospitalDataList" :columnList="hospitalColumnList" :isRota="false" />
						</div>
					</el-col>
				</div>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="6">
				<div class="screen_panel row3">
					<certificate />
				</div>
			</el-col>
			<el-col :span="12">
				<row>
					<el-col :span="8">
						<div class="screen_panel row2">
							<occupancy />
						</div>
					</el-col>
					<el-col :span="8">
						<div class="screen_panel row2">
							<!--不需要滚动-->
							<realTimeInfo
								:dataList="streetDataList"
								:columnList="streetColumnList"
								:titleName="'客户街道统计'"
								:isRota="false"
							/>
						</div>
					</el-col>
					<el-col :span="8">
						<div class="screen_panel row2">
							<customerLevel />
						</div>
					</el-col>
				</row>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row3">
					<visit />
				</div>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="6">
				<div class="screen_panel row3">
					<ageGroup />
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row3">
					<healthCare />
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row3">
					<homeCare />
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row3">
					<dining />
				</div>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="6">
				<div class="screen_panel row4">
					<el-col>
						<!--滚屏-->
						<realTimeInfo
							:dataList="dutyInfoDataList"
							:columnList="dutyInfoColumnList"
							:titleName="'今日值班信息'"
						/>
					</el-col>
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row4">
					<accessory />
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row4">
					<entertainment />
				</div>
			</el-col>
			<el-col :span="6">
				<div class="screen_panel row4">
					<el-col>
						<!--滚屏-->
						<realTimeInfo
							:dataList="recipesDataList"
							:columnList="recipesColumnList"
							:titleName="'健康食谱'"
						/>
					</el-col>
				</div>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import realTimeInfo from "./realTimeInfo";
import certificate from "./components/certificate";
import accessory from "./components/accessory";
import ageGroup from "./components/ageGroup";
import visit from "./components/visit";
import healthCare from "./components/healthCare";
import homeCare from "./components/homeCare";
import occupancy from "./components/occupancy";
import customerLevel from "./components/customerLevel";
import entertainment from "./components/entertainment";
import dining from "./components/dining";

export default {
	name: "spectaculars",
	data () {
		return {
			src: 'https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg',
			src1: 'https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg',
			dutyInfoDataList: [
				{
					staffName: "张三1",
					nurse: "李四1",
					dutying: "王五1"
				},
				{
					staffName: "张三2",
					nurse: "李四2",
					dutying: "王五2"
				},
				{
					staffName: "张三3",
					nurse: "李四3",
					dutying: "王五3"
				},
				{
					staffName: "张三4",
					nurse: "李四4",
					dutying: "王五4"
				},
				{
					staffName: "张三5",
					nurse: "李四5",
					dutying: "王五5"
				},
				{
					staffName: "张三6",
					nurse: "李四6",
					dutying: "王五6"
				},
				{
					staffName: "张三7",
					nurse: "李四7",
					dutying: "王五7"
				}
			],
			dutyInfoColumnList: [
				{
					prop: "dutying",
					label: "值班中"
				},
				{
					prop: "staffName",
					label: "员工姓名"
				},
				{
					prop: "nurse",
					label: "护理员"
				}
			],
			recipesDataList: [
				{
					num: "1",
					dishName: "土豆",
					price: "2.34"
				},
				{
					num: "2",
					dishName: "茄子",
					price: "1.22"
				},
				{
					num: "3",
					dishName: "芹菜",
					price: "5.61"
				},
				{
					num: "4",
					dishName: "豆腐",
					price: "0.56"
				},
				{
					num: "5",
					dishName: "菠菜",
					price: "1.88"
				},
				{
					num: "6",
					dishName: "西红柿",
					price: "7.56"
				}
			],
			recipesColumnList: [
				{
					prop: "price",
					label: "价格"
				},
				{
					prop: "num",
					label: "序号"
				},
				{
					prop: "dishName",
					label: "菜名"
				}
			],
			streetDataList: [
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				}
			],
			streetColumnList: [
				{
					prop: "women",
					label: "女"
				},
				{
					prop: "street",
					label: "街道"
				},
				{
					prop: "man",
					label: "男"
				}
			],
			hospitalDataList: [
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				},
				{
					street: "街道一",
					man: "236",
					women: "523"
				}
			],
			hospitalColumnList: [
				{
					prop: "women",
					label: "姓名"
				},
				{
					prop: "street",
					label: "挂号人数"
				},
				{
					prop: "man",
					label: "就诊人数"
				}
			]
		};
	},
	components: {
		realTimeInfo,
		certificate,
		accessory,
		ageGroup,
		visit,
		healthCare,
		homeCare,
		occupancy,
		customerLevel,
		entertainment,
		dining
	},
	methods: {},
	created () { },
	mounted () { },
	beforeDestroy () { }
};
</script>

<style scoped lang="scss">
.screen_panel {
	margin: 10px;
	display: flex;
	justify-content: space-between;
	border: 1px solid #154b81;
}
.row1 {
	height: 200px;
	width: 610px;
}
.row2 {
	height: 200px;
	width: 300px;
}
.row3 {
	height: 200px;
	width: 450px;
}
.row4 {
	height: 200px;
	width: 450px;
}
.orgName {
	font-size: 12px;
	font-weight: bold;
	color: rgba(255, 255, 255, 1);
	margin: 15px 0 11px 12px;
}
.orgImg {
	width: 310px;
	height: 145px;
	margin: 0 0 15px 12px;
}
.orgText {
	margin: 40px 15px 0 15px;
	color: rgba(255, 255, 255, 0.6);
	line-height: 22px;
	font-size: 12px;
	height: 200px;
}
.hospitalName {
	font-size: 12px;
	font-weight: bold;
	color: rgba(255, 255, 255, 1);
	margin: 15px 0 11px 23px;
}
.hospitalImg {
	width: 120px;
	height: 120px;
	margin-left: 23px;
	margin-bottom: 8px;
	margin-right: 20px;
}
.hospitalText {
	margin: 36px 0 0 0;
	color: rgba(255, 255, 255, 0.6);
	line-height: 22px;
	font-size: 12px;
	height: 200px;
}
</style>
