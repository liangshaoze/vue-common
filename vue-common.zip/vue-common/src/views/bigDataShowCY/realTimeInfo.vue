<template>
  <div id="realTimeInfo">
    <span v-if="isRota === true">
      <div id="nwwestroll"></div>
    </span>
    <!--滚屏-->
    <div class="staffType">
      <el-row>
        <el-col class="titleStyle">{{titleName}}</el-col>
        <el-col>
          <el-table
            :data="list"
            :header-cell-style="{background:'#0A0C59',color:'#FFFFFF',borderColor:'rgba(7, 7, 39, 1)'}"
            :cell-style="{borderColor:'rgba(7, 7, 39, 1)'}"
            row-class-name="rowStyle"
            border
            size="mini"
            class="tableStyle"
          >
            <!-- <el-table-column prop="content" :label="columnName"></el-table-column> -->
            <span v-if="cList.length > 0">
              <span v-for="column in cList">
                <el-table-column align="center" :prop="column.prop" :label="column.label"></el-table-column>
              </span>
            </span>
          </el-table>
          <span v-if="isRota === true">
            <ul class="rankFont">
              <li
                v-for="(item, i) in list"
                ref="rollul"
                :key="i"
                class="rankFont"
                style="list-style: none"
              ></li>
            </ul>
          </span>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  name: "realTimeInfo",
  props: {
    //内容
    dataList: {
      type: Array,
      default: []
    },
    //列名
    columnList: {
      type: Array,
      default: []
    },
    //标题
    titleName: {
      type: String,
      default: ""
    },
    //是否需要轮播滚动
    isRota: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      flag: false,
      list: [],
      cList: [],
      animate: false,
      timer: null,
      timer1: null
    };
  },
  methods: {
    //滚屏获取数据
    findCurrentWorkorderRoll() {
      this.list = this.dataList;
      this.flag = true;
    },
    //滚屏展示
    showMarquee() {
      if (this.flag) {
        this.nwwestroll = this.$echarts.init(
          document.getElementById("nwwestroll")
        );
        this.animate = !this.animate;
        var that = this; // 在异步函数中会出现this的偏移问题，此处一定要先保存好this的指向
        setTimeout(function() {
          that.list.push(that.list[0]);
          that.list.shift();
          that.animate = !that.animate; // 这个地方如果不把animate 取反会出现消息回滚的现象，此时把ul 元素的过渡属性取消掉就可以完美实现无缝滚动的效果了
        }, 0);
      }
    }
  },
  created() {
    this.cList = this.columnList;
  },
  mounted() {
    this.findCurrentWorkorderRoll();
    this.timer = setInterval(this.findCurrentWorkorderRoll, 45000);
    this.timer1 = setInterval(this.showMarquee, 2000);
  },
  beforeDestroy() {
    if (this.timer) {
      //如果定时器还在运行 或者直接关闭，不用判断
      clearInterval(this.timer); //关闭
    }
    if (this.timer1) {
      //如果定时器还在运行 或者直接关闭，不用判断
      clearInterval(this.timer1); //关闭
    }
  }
};
</script>

<style scoped lang="scss">
.divPanel {
  height: 200px;
}
.rankFont {
  color: #ccc;
}
.tableStyle {
  border: 0px;
  width: 95%;
  margin:0px auto;
  height: 165px;
}
.staffType {
  display: flex;
  justify-content: space-between;
  height: 200px;
}
.titleStyle {
  height: 28px;
  line-height: 28px;
  font-size: 12px;
  font-weight: 600;
  padding-left: 10px;
  background: rgba(7, 7, 39, 1);
}
</style>
<style lang="scss">
#realTimeInfo {
  .el-table .rowStyle {
    background: #060715;
    color: #606266;
  }
  .el-table th.is-leaf,
  .el-table td {
    border-bottom: 0px;
  }
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background-color: transparent;
  }
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: rgba(18, 18, 100, 0.4);
    color: white;
  }
}
</style>