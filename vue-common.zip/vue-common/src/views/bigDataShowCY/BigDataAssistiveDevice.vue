<!--辅具-->
<template>
  <div>
    <el-button @click="dialogAdd=true" size="small" primary>新增</el-button>
    <el-form ref="propertyForm" :inline="true" :model="orgIntroductionForm" label-width="125px">
        <CommonTableWidget
            @queryMethod="queryMethod"
            :propertyList="colConfig"
            :formModel="orgIntroductionForm"
            :tableDataName="'dataList'"
            ref="CommonTableWidget"
            :optWidth="200"
            :showTableIndex="false"
            :pageChange="pageChange"
        />
    </el-form>
    <el-dialog
      title="辅具"
      :visible.sync="dialogAdd"
      width="500px"
      :before-close="handleCloseDialog"
    >
      <el-form ref="addForm" :model="addForm" label-width="80px">
        <el-row>
          <el-form-item label="辅具" prop="title">
            <el-input placeholder="请输入辅具名称"></el-input>
          </el-form-item>
           <el-form-item label="接待人数" prop="title">
            <el-input placeholder="请输入接待人数"></el-input>
          </el-form-item>
           <el-form-item label="租赁人数" prop="title">
            <el-input placeholder="请输入租赁人数"></el-input>
          </el-form-item>
           <el-form-item label="购买人数" prop="title">
            <el-input placeholder="请输入购买人数"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="title">
            <el-radio-group v-model="addStatus">
              <el-radio>主界面</el-radio>
              <el-radio>显示</el-radio>
              <el-radio>不显示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="deleteBatchCancel()">取 消</el-button>
        <el-button
          size="mini"
          style="margin-left:40px;"
          type="primary"
          @click="submitBatchOrder()"
          :disabled="disabledAddBtn"
        >确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import CommonTableWidget from "@/components/widget/CommonTableWidget";
export default {
  data() {
    return {
      dialogAdd:false,
       addForm:{
        birthday:"",
        gradeId:"2"
      },
      orgIntroductionForm: {
        dataList: [
          {
            assistiveDevice: "标题一",
            receptionCount: "44",
            rentCount: "22",
            salesCount:"12",
            status: "显示",
            updateTime: "2020-5-18 16:01:23"
          }
        ],
        page:1,
        pageSize:10
      },
      colConfig: [
        {
          propertyName: "辅具",
          propertyFieldName: "assistiveDevice",
          propertyType: "10",
        },
        {
          propertyName: "接待人数",
          propertyFieldName: "receptionCount",
          propertyType: "10",
          width:"250"
        },
        {
          propertyName: "租赁（人数）",
          propertyFieldName: "rentCount",
          propertyType: "10",
          width:"200"
        },
        {
          propertyName: "出售（人数）",
          propertyFieldName: "salesCount",
          propertyType: "10"
        },
        {
          propertyName: "状态",
          propertyFieldName: "status",
          propertyType: "10"
        },
        {
          propertyName: "更新时间",
          propertyFieldName: "updateTime",
          propertyType: "10"
        },
      ]
    };
  },
  components:{
      CommonTableWidget
  },
  methods: {
    queryMethod(obj, query, cb) {
      if (typeof obj.queryMethod == "function") {
        obj.queryMethod(query, cb);
      } else {
        this[obj.queryMethod](query, cb);
      }
    },
    pageChange(val){
        alert("pageChange咯")
    }
  }
};
</script>
<style scoped>
</style>