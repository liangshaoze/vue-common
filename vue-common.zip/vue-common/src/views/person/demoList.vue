<template>
  <div id="demoList">
    <!-- 地址标签 -->
    <headTag :tagName="tagName" />

    <el-form
      ref="orgForm"
      :inline="false"
      :model="orgForm"
      label-width="100px"
    >
    <el-form-item label="组织简称">
      <el-input
        v-model="orgForm.orgName"
        @focus="dialogVisible = true"
        clearable
      ></el-input>
    </el-form-item>
    </el-form>

    <el-dialog
      title="组织架构"
      :visible.sync="dialogVisible"
      width="50%"
      :before-close="handleClose">
      <org-select v-on:listenTochildEvent="getCurrentNode" />
    </el-dialog>
  </div>
</template>

<script>
import OrgSelect from "components/OrgSelect";
import HeadTag from "components/HeadTag";

export default {
  data() {
    return {
      tagName: "公用树结构",
      orgForm: {
        orgName: "",
        orgCode: ""
      },
      dialogVisible: false
    };
  },
  components: {
    OrgSelect,
    HeadTag
  },
  methods: {
    handleClose() {
      this.dialogVisible = false;
    },
    getCurrentNode(data) {
      this.orgForm.orgName = data.orgName;
      this.orgForm.orgCode = data.orgCode;
      this.handleClose();
    }
  }
};
</script>

<style lang="scss" scoped>
#demoList {
  margin: 20px;
}
</style>