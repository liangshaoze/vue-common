<template>
  <div id="person">
    <headTag :tagName="tagName"  @click="multiClick"/>

    <div class="tableToolbar">
      <div class="form-content">
        <el-form
          :inline="false"
          :model="ruleForm"
          ref="ruleForm"
          label-width="100px"
          :rules="rules"
          class="formMain"
        >
          <el-form-item label="员工姓名">
            <el-input size="mini" v-model.trim="userFullName" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="员工编号">
            <el-input size="mini" v-model.trim="userCode" :disabled="true"></el-input>
          </el-form-item>
          <span v-if="false">
            <el-input size="mini" v-model.trim="userTel" :disabled="true"></el-input>
          </span>
          <span v-if="false">
            <el-input size="mini" v-model.trim="userGender" :disabled="true"></el-input>
          </span>
          <span v-if="false">
            <el-input size="mini" v-model.trim="userIdCard" :disabled="true"></el-input>
          </span>
          <span v-if="false">
            <el-input size="mini" v-model.trim="userStatus" :disabled="true"></el-input>
          </span>
          <el-form-item label="密码" prop="password">
            <el-input
            size="mini"
              v-model.trim="ruleForm.password"
              type="password"
              clearable
              placeholder="请输入密码"
            ></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="confirmPassword">
            <el-input
            size="mini"
              v-model.trim="ruleForm.confirmPassword"
              type="password"
              clearable
              placeholder="请输入确认密码"
            ></el-input>
          </el-form-item>
          <el-form-item class="search_btn">
            <el-button size="mini" @click="resetForm('ruleForm')">重置</el-button>
            <el-button size="mini" type="primary" @click="editPassword('ruleForm')">保存</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog 
      title="环境切换"
      :visible.sync="dialogEnvironment"
      width="600px"
    >
    <div style="padding:20px">
    <el-row>
      切换至：<el-button type="primary" size="mini" @click="develop">测试环境</el-button>
    </el-row>
    <el-row type="flex"  style="display:flex;justify-content:space_between;align-items:center;margin-top:10px">
      访问地址：<el-input placeholder="请输入IP地址+端口号或域名" v-model="ipUrl" size="mini" style="width:300px"></el-input>
      <el-button type="primary" size="mini" @click="submit" style="margin-left:10px">确定</el-button>
    </el-row>
    </div>
    </el-dialog>
  </div>
</template>

<script>
import { editSysUser } from "api/systemManagement/index.js";
import { validatePassword } from "utils/validate";
import { mapGetters } from "vuex";
import HeadTag from "components/HeadTag";
import { getUserInfo } from 'utils/userMgr'
import EnvironmentUtils from "utils/EnvironmentUtils"

export default {
  data() {
    return {
      tagName: "个人中心",
      userFullName:"",
      ruleForm: {
        userCode: "",
        userFullName: "",
        password: "",
        confirmPassword: "",
        userTel: "",
        userGender: "",
        userIdCard: "",
        userStatus: ""
      },
      rules: {
        password: [
          { required: true, message: "密码不能为空" },
          { validator: validatePassword }
        ],
        confirmPassword: [
          { required: true, message: "确认密码不能为空" },
          { validator: validatePassword }
        ]
      },
      clickCount:0,
      dialogEnvironment:false,
      ipUrl:"",
    };
  },
  components: {
    HeadTag
  },
  methods: {
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    editPassword(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          debugger;
          if (this.ruleForm.password != this.ruleForm.confirmPassword) {
            this.$message.error("两次密码输入不一致");
            return false;
          }
          var params = {
            userCode: this.userCode,
            userFullName: this.userFullName,
            password: this.ruleForm.password,
            confirmPassword: this.ruleForm.password,
            userTel: this.userTel,
            userGender: this.userGender,
            userIdCard: this.userIdCard,
            userStatus: this.userStatus
          };
          editSysUser(params)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$message.success("操作成功");
                this.$store.dispatch("LogOut").then(() => {
                  location.reload(); // 为了重新实例化vue-router对象 避免bug
                });
              } else {
                this.$message.error("操作失败");
                return false;
              }
            })
            .catch(error => {
              console.log(error);
            });
        } else {
          this.$message.error("请检查输入是否都已完成");
          return false;
        }
      });
    },
    multiClick(){
      this.clickCount++;
      if(this.clickCount>=10){
        this.dialogEnvironment=true;
        this.ipUrl = EnvironmentUtils.getEnvironment().lastUrl;
      }
    },
    develop(){
      EnvironmentUtils.dev();
      this.dialogEnvironment=false;
    },
    submit(){
      if(!this.ipUrl){
        alert("请输入访问地址")
        return;
      }
      if(this.ipUrl.indexOf("www.zhaohu365.com") != -1){
        alert("想试试正式环境??,noway,为了正式环境数据安全，暂不支持切换:)")
        return;
      }
      EnvironmentUtils.changeEnvironment(this.ipUrl);
      this.dialogEnvironment=false;
    }
  },
  computed: {
    ...mapGetters([
      "userCode",
      "userFullName",
      "userTel",
      "userGender",
      "userIdCard",
      "userStatus"
    ])
  },
  mounted(){
    this.userFullName = getUserInfo().userFullName;
  }
};
</script>

<style lang="scss" scoped>
#person {
  width: 100%;
  height:100%;
  min-width: 1024px;
  .el-form-item {
    margin-bottom: 15px;
  }
}

.form-content {
  padding: 20px 0px;
}

.el-input {
  width: 200px;
}
</style>