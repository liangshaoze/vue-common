
<template>
  <div id="demoList3">
    <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>

    <el-tree
      class="filter-tree"
      :data="data"
      :props="defaultProps"
      :default-expand-all="false"
      :filter-node-method="filterNode"
      :render-content="renderContent"
      :highlight-current="true"
      :expand-on-click-node="false"
      ref="tree"
    ></el-tree>
  </div>
</template>

<script>
export default {
  data() {
    return {
      filterText: "",
      data: [
        {
          id: 1,
          label: "上海总部",
          children: [
            {
              id: 4,
              label: "虹口分公司",
              children: [
                {
                  id: 9,
                  label: "护理站1"
                },
                {
                  id: 10,
                  label: "护理站2"
                }
              ]
            },
            {
              id: 11,
              label: "浦东分公司",
              children: [
                {
                  id: 12,
                  label: "护理站1"
                },
                {
                  id: 13,
                  label: "护理站2"
                },
                {
                  id: 14,
                  label: "浦东子公司",
                  children: [
                    {
                      id: 15,
                      label: "护理站1",
                      children: [
                        {
                          id: 17,
                          label: "组1"
                        },
                        {
                          id: 18,
                          label: "组2"
                        }
                      ]
                    },
                    {
                      id: 16,
                      label: "护理站2"
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          id: 2,
          label: "深圳总部",
          children: [
            {
              id: 5,
              label: "龙华分公司"
            },
            {
              id: 6,
              label: "沙岗子公司"
            }
          ]
        },
        {
          id: 3,
          label: "北京总部",
          children: [
            {
              id: 7,
              label: "后海护理站"
            },
            {
              id: 8,
              label: "三里屯护理站"
            }
          ]
        }
      ],
      defaultProps: {
        children: "children",
        label: "label"
      }
    };
  },
  watch: {
    filterText(val) {
      this.$refs.tree.filter(val);
    }
  },
  methods: {
    filterNode(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    renderContent(h, { node, data, store }) {
      return (
        <span>
          <i></i>
          <span>{node.label}</span>
        </span>
      );
    }
  }
};
</script>
<style lang="scss">
#demoList3 {
  margin: 20px;
}
#demoList3 .el-tree-node__expand-icon.expanded {
  -webkit-transform: rotate(0deg);
  transform: rotate(0deg);
}
#demoList3 .el-icon-caret-right:before {
  content: "\e723";
  font-size: 18px;
}
#demoList3 .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
  content: "\e722";
  font-size: 18px;
}
#demoList3 .el-tree-node.is-current > .el-tree-node__content{
  color: #F98C3C;
}
#demoList3 .el-tree-node.is-current > .el-tree-node__content i{
  background-color: #F98C3C;
  width:8px;
  height:8px;
  display: -webkit-inline-box;
  border-radius: 50%;
  margin-right:5px;
}
</style>