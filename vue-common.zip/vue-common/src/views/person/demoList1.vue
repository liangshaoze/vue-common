<template>
  <div id="demoList1">
    <!-- 地址标签 -->
    <headTag :tagName="tagName" />

    <div class="temp-title">
      <el-button
        size="middle"
        type="primary"
        icon="el-icon-plus"
        @click="addTemp"
      >新增模板</el-button>
      <el-button
        size="middle"
        type="primary"
        icon="el-icon-folder-checked"
        @click="addTemp"
      >保存</el-button>
    </div>
    <div class="temp-list">
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        stripe
        :data="tempList"
        v-loading="listLoading"
        highlight-current-row
        element-loading-text="拼命加载中"
        class="tableMain"
      >
        <el-table-column label="姓名" min-width="200px">
          <template slot-scope="scope">
            <div v-if="!scope.row.editing">
              <span>{{ scope.row.name }}</span>
            </div>
            <div v-else>
              <el-input v-model="scope.row.name" placeholder="请输入姓名" clearable></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="年龄" min-width="200px">
          <template slot-scope="scope">
            <div v-if="!scope.row.editing">
              <span>{{ scope.row.age }}</span>
            </div>
            <div v-else>
              <el-input v-model="scope.row.age" placeholder="请输入年龄" clearable></el-input>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="性别" min-width="200px">
          <template slot-scope="scope">
            <div v-if="!scope.row.editing">
              <span v-if="scope.row.sex != '' ">
                {{scope.row.sex == 0 ? '男' : '女'}}
              </span>
            </div>
            <div v-else>
              <el-select v-model="scope.row.sex" placeholder="请选择" clearable>
                <el-option
                  v-for="item in sexOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </div>
          </template>
        </el-table-column>
        <el-table-column fixed="right" min-width="200px" label="操作">
          <template slot-scope="scope">
            <div class="operate-groups">
              <el-button
                type="primary"
                size="mini"
                v-if="!scope.row.editing"
                icon="el-icon-edit-outline"
                @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button>
              <el-button
                type="primary"
                size="mini"
                v-if="scope.row.editing"
                icon="el-icon-success"
                @click="handleSave(scope.$index, scope.row)"
              >保存</el-button>
              <el-button
                size="mini"
                type="danger"
                v-if="!scope.row.editing"
                icon="el-icon-delete"
                @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button>
              <el-button
                size="mini"
                type="warning"
                v-if="scope.row.editing"
                icon="el-icon-warning"
                @click="handleCancel(scope.$index, scope.row)"
              >取消</el-button>
              <!-- <div class="upAndDown">
                <el-button
                  plain
                  class="up"
                  type="primary"
                  size="mini"
                  icon="el-icon-arrow-up"
                  @click="handleUp(scope.$index, scope.row)"
                ></el-button>
                <el-button
                  plain
                  class="down"
                  type="primary"
                  size="mini"
                  icon="el-icon-arrow-down"
                  @click="handleDown(scope.$index, scope.row)"
                ></el-button>
              </div> -->
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import SearchForm from "components/queryForm/searchComponent";
import HeadTag from "components/HeadTag";

export default {
  data() {
    return {
      tagName: "table动态增删改",
      listLoading: false,
      sexOptions: [
        {
          label: "男",
          value: "0"
        },
        {
          label: "女",
          value: "1"
        }
      ],
    }
  },
  components: {
    HeadTag
  },
  created() {
    this.tempList = JSON.parse(localStorage.getItem("tempList"));
  },
  methods: {
    // 上下自由调整表格数据
    // swapItems(arr, index1, index2) {
    //   arr[index1] = arr.splice(index2, 1, arr[index1])[0];
    //   return arr;
    // },
    handleUp($index, row) {
      if ($index === 0) {
        return;
      }
      this.swapItems(this.tempList, $index, $index - 1);
    },
    handleDown($index, row) {
      if ($index === this.tempList.length - 1) {
        return;
      }
      this.swapItems(this.tempList, $index, $index + 1);
    },
    // 编辑
    handleEdit($index, row) {
      this.$set(this.tempList[$index], "editing", true);
    },
    // 保存
    handleSave($index, row) {
      this.$set(this.tempList[$index], "editing", false);
      localStorage.setItem("tempList", JSON.stringify(this.tempList));
    },
    // 取消
    handleCancel($index, row) {
      this.tempList.splice($index, 1);
      localStorage.setItem("tempList", JSON.stringify(this.tempList));
    },
    // 新增一条模板数据
    addTemp() {
      this.tempList = this.tempList || [];
      this.tempList.push({
        name: "",
        age: "",
        sex: "",
        editing: true
      });
    },
    // 删除
    handleDelete($index, row) {
      this.$confirm("此操作将永久删除该条模板, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.tempList.splice($index, 1);
          localStorage.setItem("tempList", JSON.stringify(this.tempList));
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(err => {
          this.$message({
            type: "error",
            message: err
          });
        });
    }
  }
};
</script>

<style lang="scss" scoped>
#demoList1 {
  margin: 20px;
  .temp-title {
    width: 100%;
    background: #FFF;
    text-align: right;
    padding: 20px 20px 0px 0px;
  }
  .operate-groups {
    display: flex;
    justify-content: flex-start;
    .upAndDown {
      display: flex;
      flex-direction: column;
      margin-left: 10px;
      .el-button--mini {
        padding: 0;
        width: 30px;
        margin-left: 0;
      }
      .down {
        margin-top: 2px;
      }
    }
  }
}
</style>