<template>
  <div id="demoList2">
    <!-- 地址标签 -->
    <headTag :tagName="tagName" />

    <div class="temp-title">
      <el-button size="middle" type="primary" icon="el-icon-plus" @click="addTemp">新增模板</el-button>
      <el-button
        size="middle"
        type="primary"
        icon="el-icon-folder-checked"
        @click="save('formDom')"
      >保存</el-button>
    </div>
    <div>
      <el-form :rules="formData.rules" :model="formData" ref="formDom">
        <el-table
          :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
          stripe
          :data="formData.tableData"
          v-loading="listLoading"
          highlight-current-row
          element-loading-text="拼命加载中"
          class="tableMain"
        >
          <el-table-column prop="name" label="姓名" min-width="200px">
            <template slot-scope="scope">
              <div v-if="!scope.row.editing">
                <span>{{ scope.row.name }}</span>
              </div>
              <div v-else>
                <el-form-item
                  :prop="'tableData.' + scope.$index + '.name'"
                  :rules="formData.rules.name"
                >
                  <el-input v-model="scope.row.name" placeholder="请输入姓名"></el-input>
                </el-form-item>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="age" label="年龄" min-width="200px">
            <template slot-scope="scope">
              <div v-if="!scope.row.editing">
                <span>{{ scope.row.age }}</span>
              </div>
              <div v-else>
                <el-form-item
                  :prop="'tableData.' + scope.$index + '.age'"
                  :rules="formData.rules.age"
                >
                  <el-input v-model.number="scope.row.age" placeholder="请输入年龄"></el-input>
                </el-form-item>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="sex" label="性别" min-width="200px">
            <template slot-scope="scope">
              <div v-if="!scope.row.editing">
                <span v-if="scope.row.sex != '' ">{{scope.row.sex == 0 ? '男' : '女'}}</span>
              </div>
              <div v-else>
                <el-form-item
                  :prop="'tableData.' + scope.$index + '.sex'"
                  :rules="formData.rules.sex"
                >
                  <el-select v-model="scope.row.sex" placeholder="请选择" clearable>
                    <el-option
                      v-for="item in sexOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </div>
            </template>
          </el-table-column>
          <el-table-column fixed="right" min-width="200px" label="操作">
            <template slot-scope="scope">
              <div class="operate-groups">
                <el-button
                  type="primary"
                  size="mini"
                  v-if="!scope.row.editing"
                  icon="el-icon-edit-outline"
                  @click="handleEdit(scope.$index, scope.row)"
                >编辑</el-button>
                <el-button
                  type="primary"
                  size="mini"
                  v-if="scope.row.editing"
                  icon="el-icon-success"
                  @click="handleSave(scope.$index, scope.row, 'formDom')"
                >保存</el-button>
                <el-button
                  size="mini"
                  type="danger"
                  v-if="!scope.row.editing"
                  icon="el-icon-delete"
                  @click="handleDelete(scope.$index, scope.row)"
                >删除</el-button>
                <el-button
                  size="mini"
                  type="warning"
                  v-if="scope.row.editing"
                  icon="el-icon-warning"
                  @click="handleCancel(scope.$index, scope.row)"
                >取消</el-button>
                <!-- <div class="upAndDown">
                    <el-button
                    plain
                    class="up"
                    type="primary"
                    size="mini"
                    icon="el-icon-arrow-up"
                    @click="handleUp(scope.$index, scope.row)"
                    ></el-button>
                    <el-button
                    plain
                    class="down"
                    type="primary"
                    size="mini"
                    icon="el-icon-arrow-down"
                    @click="handleDown(scope.$index, scope.row)"
                    ></el-button>
                </div>-->
              </div>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
    </div>
  </div>
</template>

<script>
import SearchForm from "components/queryForm/searchComponent";
import HeadTag from "components/HeadTag";

export default {
  data() {
    return {
      tagName: "table-Form验证",
      listLoading: false,
      tempList: [],
      sexOptions: [
        {
          label: "男",
          value: "0"
        },
        {
          label: "女",
          value: "1"
        }
      ],
      formData: {
        rules: {
          name: {
            type: "string",
            required: true,
            message: "必填字段",
            trigger: "change"
          },
          age: {
            type: "number",
            required: true,
            min: 1,
            max: 130,
            message: "年龄必须为数字值",
            trigger: "change"
          },
          sex: {
            required: true,
            message: "请选择年龄",
            trigger: "change"
          }
        },
        tableData: [
          {
            name: null,
            age: null,
            sex: null
          }
        ]
      }
    };
  },
  components: {
    HeadTag
  },
  created() {
    this.formData.tableData = JSON.parse(localStorage.getItem("tempList"));
  },
  methods: {
    // 上下自由调整表格数据
    // swapItems(arr, index1, index2) {
    //   arr[index1] = arr.splice(index2, 1, arr[index1])[0];
    //   return arr;
    // },
    // handleUp($index, row) {
    //   if ($index === 0) {
    //     return;
    //   }
    //   this.swapItems(this.formData.tableData, $index, $index - 1);
    // },
    // handleDown($index, row) {
    //   if ($index === this.formData.tableData.length - 1) {
    //     return;
    //   }
    //   this.swapItems(this.formData.tableData, $index, $index + 1);
    // },
    //保存
    save(formName) {
      this.$refs[formName].validate((valid, model) => {
        console.log(valid);
        console.log(JSON.stringify(model));
        if (valid) {
          alert("submit!");
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 编辑
    handleEdit($index, row) {
      this.$set(this.formData.tableData[$index], "editing", true);
    },
    // 保存
    handleSave($index, row, formName) {
      this.$refs[formName].validate((valid, model) => {
          console.log(this.formData.tableData);
        console.log(JSON.stringify(model));
        if (valid) {
          this.$set(this.formData.tableData[$index], "editing", false);
          localStorage.setItem("tempList", JSON.stringify(this.formData.tableData));
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 取消
    handleCancel($index, row) {
      this.formData.tableData.splice($index, 1);
      localStorage.setItem("tempList", JSON.stringify(this.formData.tableData));
    },
    // 新增一条模板数据
    addTemp() {
      this.formData.tableData = this.formData.tableData || [];
      this.formData.tableData.push({
        name: null,
        age: null,
        sex: null,
        editing: true
      });
    },
    // 删除
    handleDelete($index, row) {
      this.$confirm("此操作将永久删除该条模板, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.formData.tableData.splice($index, 1);
          localStorage.setItem("tempList", JSON.stringify(this.formData.tableData));
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(err => {
          this.$message({
            type: "error",
            message: err
          });
        });
    }
  }
};
</script>

<style lang="scss" scoped>
#demoList2 {
  margin: 20px;
  .temp-title {
    width: 100%;
    background: #fff;
    text-align: right;
    padding: 20px 20px 0px 0px;
  }
  .operate-groups {
    display: flex;
    justify-content: flex-start;
    .upAndDown {
      display: flex;
      flex-direction: column;
      margin-left: 10px;
      .el-button--mini {
        padding: 0;
        width: 30px;
        margin-left: 0;
      }
      .down {
        margin-top: 2px;
      }
    }
  }
}
</style>