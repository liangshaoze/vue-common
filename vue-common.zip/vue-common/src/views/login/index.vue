<template>
  <div id="login">
    <div class="login-wrap">
      <div class="login-container">
        <h1 class="title">福寿康管理平台</h1>

        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="账号登录" name="first">
            <el-form
              label-position="left"
              :model="accountForm"
              :rules="rules"
              ref="accountForm"
              label-width="0px"
            >
              <el-form-item prop="username">
                <el-input
                  type="text"
                  prefix-icon="el-icon-user"
                  v-model="accountForm.username"
                  placeholder="账号/手机号/身份证号"
                ></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <el-input
                  type="password"
                  prefix-icon="el-icon-lock"
                  v-model="accountForm.password"
                  placeholder="密码"
                ></el-input>
              </el-form-item>
              <el-row class="innerBlock">
                <el-col :span="12">
                  <el-form-item prop="imageCode">
                    <el-input
                      class="verifycode"
                      type="text"
                      prefix-icon="el-icon-view"
                      v-model="accountForm.imageCode"
                      auto-complete="off"
                      @keyup.enter.native="submitForm('accountForm')"
                      placeholder="验证码"
                      minlength="4"
                      maxlength="4"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12" class="code-box">
                  <img id="imgId" :src="accountForm.codeimg" alt class="codeimg" @click="drawPic()" />
                </el-col>
              </el-row>
              <el-form-item>
                <el-button
                  type="primary"
                  class="loginBtn"
                  @click="submitForm('accountForm')"
                  :loading="logining"
                >登录</el-button>
              </el-form-item>
            </el-form>
          </el-tab-pane>

          <el-tab-pane label="验证码登录" name="second">
            <el-form
              label-position="left"
              :model="phoneForm"
              :rules="phoneRules"
              ref="phoneForm"
              label-width="0px"
            >
              <el-form-item prop="userTel">
                <el-input
                  type="text"
                  placeholder="手机号"
                  v-model="phoneForm.userTel"
                  prefix-icon="el-icon-mobile-phone"
                ></el-input>
              </el-form-item>
              <el-form-item prop="imageCode">
                <el-input
                  type="text"
                  placeholder="验证码"
                  v-model="phoneForm.imageCode"
                  prefix-icon="el-icon-news"
                >
                  <el-button
                    type="text"
                    slot="suffix"
                    @click="getNewsVerifyCode('phoneForm')"
                    :disabled="disabled"
                  >{{btnTitle}}</el-button>
                </el-input>
              </el-form-item>
              <el-form-item class="form-place"></el-form-item>
              <el-form-item>
                <el-button
                  type="primary"
                  class="loginBtn"
                  @click="handleLogin('phoneForm')"
                  :loading="logining"
                >登录</el-button>
              </el-form-item>
            </el-form>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <div class="bootom-font">
      Copyright &copy;2020 福寿康（上海）医疗养老服务有限公司  版权所有 |
      <a
        href="http://www.beian.miit.gov.cn"
        target="_blank"
      >沪ICP备16050235号</a>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import SIdentify from "./identify";
import { verifyCode } from "api/login.js";
import { validateTel } from "utils/validate";
import { getVerificationCode } from "api/common";
import {
  getUserName,
  setUserName,
  getUserPhone,
  setUserPhone,
  getUserLoginType,
  setUserLoginType
  } from "utils/auth"

export default {
  components: {
    SIdentify
  },
  name: "login",
  data() {
    return {
      activeName: "first",
      /**
       * 账号登录
       */
      //定义loading默认为false
      logining: false,
      // 记住密码
      rememberpwd: false,
      verifyCode: null,
      accountForm: {
        //username和password默认为空
        username: "",
        password: "",
        loginType: "10",
        imageCode: "",
        randomStr: "",
        codeimg: "",
        verifyCodeKey: ""
      },
      identifyCode: {
        //默认注册码
        type: String,
        default: "1234"
      },
      //rules前端验证
      rules: {
        username: [{ required: true, message: "请输入账号", trigger: "blur" }],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        imageCode: [
          { required: true, message: "请输入验证码", trigger: "blur" }
        ]
      },
      /**
       * 验证码登录
       */
      phoneForm: {
        userTel: "", //手机号
        imageCode: "", //验证码
        verifyCodeKey: "pcLogin",
        loginType: "20"
      },
      //rules前端验证
      phoneRules: {
        userTel: [
          { required: true, message: "请输入手机号", trigger: "blur" },
          { 
            required: true,
            trigger: "blur",
            validator: validateTel 
          }
        ],
        imageCode: [
          { required: true, message: "请输入验证码", trigger: "blur" }
        ]
      },
      btnTitle: "获取验证码",
      disabled: false //是否可点击
    };
  },
  // 创建完毕状态(里面是操作)
  created() {
    // 获取图形验证码
    this.drawPic();

    let time = "2020-03-13T13:58:02.220Z"
    let newHour;
    let hour = time.substring(11,13);
    if(hour.indexOf('0') != -1) {
      var data = hour.split('0')
      newHour = "0"+(parseInt(data[1])+1).toString();
    } else {
      newHour = (parseInt(hour)+1).toString();
    }
		time.append(time.substring(0,10))
		    .append(newHour)
		    .append(time.substring(13,time.length));
    time = time.toString();
    console.log(newHour);
  },
  mounted(){
    this.accountForm.username = getUserName()?getUserName():"";
    this.phoneForm.userTel = getUserPhone()?getUserPhone():"";
    this.activeName = getUserLoginType()?getUserLoginType():"first";
    if(this.activeName && this.activeName != "first"){
      this.activeName = "second";
    }

  },
  watch: {
    identifyCode() {
      this.drawPic();
    }
  },
  // 里面的函数只有调用才会执行
  methods: {
    handleClick(tab, event) {},
    drawPic() {
      verifyCode()
        .then(response => {
          const data = response.data.responseData;
          // this.accountForm.imageCode = data.code
          this.accountForm.codeimg = data.path;
          this.accountForm.verifyCodeKey = data.key;
        })
        .catch(error => {
          console.log(error);
        });
    },
    // 账号登录
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          this.$store
            .dispatch("Login", this.accountForm)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$router.push({ path: this.redirect || "/" });
                this.errorMsg = false;
                this.loading = false;
                setUserName(this.accountForm.username)
                setUserLoginType("first");
                console.log("login success!!");
              } else {
                this.errorMsg = true;
                this.loading = false;
                this.$refs.accountForm.validateField("password");
                this.drawPic();
                this.$message.error(response.data.statusMsg);
                console.log("login failure!!");
              }
            })
            .catch(error => {
              this.loading = false;
              this.drawPic();
              console.log(error);
              console.log("login error!!");
            });
        } else {
          // 获取图形验证码
          this.drawPic();
          this.$message.error("请输入账号密码！");
          this.logining = false;
          return false;
        }
      });
    },
    // 验证码登录
    handleLogin(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.loading = true;
          this.$store
            .dispatch("Login", this.phoneForm)
            .then(response => {
              if (response.data.statusCode == 200) {
                this.$router.push({ path: this.redirect || "/" });
                this.errorMsg = false;
                this.loading = false;
                setUserPhone(this.phoneForm.userTel);
                setUserLoginType("second");
                console.log("login success!!");
              } else {
                this.errorMsg = true;
                this.loading = false;
                this.$message.error(response.data.statusMsg);
                console.log("login failure!!");
              }
            })
            .catch(error => {
              this.loading = false;
              console.log(error);
              console.log("login error!!");
            });
        } else {
        }
      });
    },
    //获取验证码的方法
    getNewsVerifyCode(formName) {
      this.disabled = true;
      this.$refs[formName].validateField("userTel", valid => {
        if (valid == "") {
          var params = {
            phone: this.phoneForm.userTel,
            type: "pcLogin"
          };
          getVerificationCode(params).then(response => {
            if (response.data.statusCode == 200) {
              this.validateBtn();
              this.$message.success("验证码已发送！");
            } else {
              this.$message.error(response.data.statusMsg);
              return false;
            }
          });
        } else {
          return false;
        }
      });
    },
    validateBtn() {
      //倒计时
      let time = 60;
      let timer = setInterval(() => {
        if (time == 0) {
          clearInterval(timer);
          this.disabled = false;
          this.btnTitle = "获取验证码";
        } else {
          this.btnTitle = time + "秒后重试";
          this.disabled = true;
          time--;
        }
      }, 1000);
    }
  }
};
</script>

<style scoped>
.login-wrap {
  background: url("/fsk/static/img/loginBack.png") no-repeat center center fixed;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  width: 100%;
  height: calc(100vh - 0px);
  background-repeat: no-repeat;
  background-position: center;
  margin-bottom: -40px;
}

.login-container {
  border-radius: 6px;
  margin: 0px 0px 10px 0px;
  width: 360px;
  padding: 40px 55px 30px 55px;
  filter: progid:DXImageTransform.Microsoft.gradient(enabled='true', startColorstr='#E518515F', endColorstr='#E518515F');
  background: rgba(255, 255, 255, 0.1);
  text-align: left;
  margin-right: 15%;
}

.title {
  font-size: 24px;
  font-weight: 500;
  text-align: center;
  color: #fff;
}
.code-box {
  text-align: right;
  padding-left: 10px;
}
.codeimg {
  height: 40px;
  width: 100px;
}
.innerBlock {
  display: inline-block;
}
.verifycode {
  width: 140px !important;
}
.el-input {
  width: 250px;
}
.loginBtn {
  width: 100%;
  background-color: #30e9e2;
}
.bootom-font {
  height: 40px;
  width: 100%;
  text-align: center;
  line-height: 40px;
  color: #fff;
  font-size: 15px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background: rgba(30, 53, 115, 0.1);
}
.form-place {
  height: 43px;
}
</style>

<style>
#login .el-tabs__header {
  margin: 0 0 15px 40px;
}

#login .el-tabs__item {
  color: #fff;
}

#login .el-tabs__item.is-active {
  color: #fff;
}

#login .el-tabs__item:hover {
  color: #fff;
}

#login .el-tabs__active-bar {
  background-color: #fff;
}

#login .el-tabs__nav-wrap::after {
  background-color: transparent;
}
</style>