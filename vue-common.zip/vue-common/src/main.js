import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locale from 'element-ui/lib/locale/lang/zh-CN'

import '@/styles/index.scss' // global css

import App from './App'
import router from './router'
import store from './store'

import '@/icons' // icon
import '@/permission' // permission control


import echarts from "echarts";
import 'echarts-gl'
Vue.prototype.$echarts = echarts //引入组件

// import './mock/index.js' // simulation data

import 'font-awesome/scss/font-awesome.scss' // font-awesome
import 'animate.css/animate.min.css'
import animated from 'animate.css'
import global from "@/utils/global"
import eventBus from "@/utils/eventBus"
import screenFitter from "@/utils/ScreenFitter"
Vue.use(animated)
// 网络请求库
import axios from 'axios'

import Qs from 'qs'
import { setTime } from "@/utils/index";

// 引入ag-grid的样式文件
import '../node_modules/ag-grid-community/dist/styles/ag-grid.css';
import '../node_modules/ag-grid-community/dist/styles/ag-theme-balham.css';

import '@/utils/jquery/css/style.css'
//引入工具类
import webSocketHelper from "@/utils/WebSocketHelper";//websocket工具
import userMgr from "@/utils/userMgr"
import utils from '@/utils'

Vue.use(ElementUI, {
  locale
})
Vue.config.productionTip = false
Vue.prototype.axios = axios
Vue.prototype.qs = Qs
Vue.prototype.ConstantData = global
Vue.prototype.EventBus = eventBus;
Vue.prototype.ScreenFitter = screenFitter
Vue.prototype.WebSocketHelper = webSocketHelper
Vue.prototype.UserMgr = userMgr
Vue.prototype.setTime = setTime

Vue.prototype.Utils = utils

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
