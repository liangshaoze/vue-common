<!--通用表格控件，可编辑-->
<template>
  <div v-if="tableVisiable">
    <el-form-item
      :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.relationFilled'"
      :rules="{required: true ,message: '结果不能为空'}"
    >
      <el-col>{{baseItem.titleName}}</el-col>
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        :data="tableData"
        v-loading="loading"
        highlight-current-row
        element-loading-text="拼命加载中"
        class="tableMain"
        stripe
        width="600px"
      >
        <el-table-column label="序号" type="index" show-overflow-tooltip width="50" align="center"></el-table-column>
        <el-table-column
          v-for="(item,index) in tableColumn"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          width="200"
        >
          <template slot-scope="scope">
            <el-input v-model="scope.row[item.prop]" size="mini" @change="changeInput(scope.row)"></el-input>
          </template>
        </el-table-column>
        <el-table-column :fixed="right" width="100" label="操作">
          <template slot-scope="scope">
            <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
              <span v-if="scope.$index != 0">
                <el-button
                  size="mini"
                  type="danger"
                  icon="el-icon-delete"
                  @click="handleDeleteRow(scope.$index, scope.row)"
                >删除</el-button>
              </span>
              <span v-else></span>
            </div>
            <div v-else></div>
          </template>
        </el-table-column>
      </el-table>
      <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
        <el-button type="primary" size="mini" icon="el-icon-circle-plus" @click="handleAddRow()">新增</el-button>
      </div>
    </el-form-item>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      tableColumn: [],
      tableData: [],
      tableVisiable: false,
      filledList: []
    };
  },
  methods: {
    //创建表格结构
    createTable(needAddRow) {
      var array = [];
      var str = this.baseItem.titleName.split("|");
      var s = "";
      for (let i = 0; i < str.length; i++) {
        s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
      }
      if (s) {
        var s1 = s.split("|");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        this.tableColumn = array;
      }
      if (this.tableData.length == 0 && needAddRow) {
        this.handleAddRow();
      }
    },
    // 新增
    handleAddRow() {
      var objlist = {};
      var array = [];
      var str = "";
      if (this.baseItem.remark) {
        str = this.baseItem.remark.split("|");
      } else {
        str = this.baseItem.titleName.split("|");
      }
      var s = "";
      if (this.baseItem.remark) {
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": "' + str[i] + '"},';
        }
      } else {
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": ""},';
        }
      }
      if (s) {
        var s1 = s.split(",");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        array.forEach(item => {
          for (var k in item) {
            objlist[k] = item[k];
          }
        });
        array = [];
        array.push(objlist);
        //获取filledList tableItemId的最大值
        var maxId = 0;
        if (this.filledList.length > 0) {
          var maxId = this.filledList.sort(function(obj1, obj2) {
            var val1 = parseInt(obj1.tableItemId);
            var val2 = parseInt(obj2.tableItemId);
            if (val1 > val2) {
              return -1;
            } else if (val1 < val2) {
              return 1;
            } else {
              return 0;
            }
          })[0].tableItemId;
        }
        var obj = {
          titleId: this.baseItem.id || "", //题目ID",
          titleType: this.baseItem.titleType || "", //"题目类型",
          titleName: this.baseItem.titleName || "", //"题目名称",
          titleClass: this.baseItem.titleClass || "", //"题目分类",
          titleScore: this.baseItem.titleScore || "", //"题目分值",
          titleSort: this.baseItem.titleSort || "", //"题目顺序",
          titleRelationType: this.baseItem.relationType || "", //"题关联类型"
          titleRelationId: this.baseItem.relationId || "", //"题关联ID",
          titleValueId: "", // "题目值ID",
          titleValue: "", //"题目值",
          titleValueClass: "", //"题目值分类",
          valueScore: "0", //"题目值分值",
          valueSort: "", //"顺序",
          valueRelationType: "10", //"值关联类型",
          valueRelationId: "", //"值关联ID",
          remark: "" //"remark"
        };
        objlist.tableItemId = maxId + 1;
        obj.tableItemId = maxId + 1;
        this.filledList.push(obj);
        this.tableData.push(array[0]);
      }
    },
    // 删除
    handleDeleteRow($index, row) {
      this.tableData.splice($index, 1);
      for (var i = this.filledList.length - 1; i >= 0; i--) {
        if (this.filledList[i].tableItemId == row.tableItemId) {
          this.filledList.splice(i, 1);
        }
      }
      this.EventBus.post("relationCKItemChanged", this.filledList);
    },
    changeInput(row) {
      var titleValue = "";
      for (var field in row) {
        if (field != "tableItemId") {
          titleValue += row[field] + "|";
        }
      }

      var existItem = this.filledList.find(item => {
        return item.tableItemId == row.tableItemId;
      });
      if (existItem) {
        existItem.titleValue = titleValue.substring(0, titleValue.length - 1);
        for (var field in row) {
          if (field != "tableItemId") {
            if (row[field] == "") {
              this.titleItem.relationFilled = "";
              return;
            }
          }
        }
        this.titleItem.relationFilled = existItem.titleValue;
        this.EventBus.post("relationCKItemChanged", this.filledList);
      }
    }
  },
  mounted() {
    if (!this.tableVisiable) {
      this.titleItem.relationFilled = "default";
    } else {
      this.titleItem.relationFilled = "";
    }
    var hasRelationItem = this.titleItem.assessOrderTitleValues.find(item => {
      return item.titleRelationId == this.baseItem.relationId;
    });
    this.createTable(!hasRelationItem);
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      for (let j = 0; j < this.titleItem.assessOrderTitleValues.length; j++) {
        if (
          this.titleItem.assessOrderTitleValues[j].titleRelationId ==
          this.baseItem.relationId
        ) {
          this.filledList.push(this.titleItem.assessOrderTitleValues[j]);
          this.tableVisiable = true;
        }
      }
      //为结果设置唯一tableItemId
      for (var i = 0; i < this.filledList.length; i++) {
        this.filledList[i].tableItemId = i;
      }
      this.tableData = [];
      for (let i = 0; i < this.filledList.length; i++) {
        var objlist = {};
        var array = [];
        var str = this.filledList[i].titleValue.split("|");
        var s = "";
        for (let j = 0; j < str.length; j++) {
          s += '{"property' + [j] + '": "' + str[j] + '"},';
        }
        if (s) {
          var s1 = s.split(",");
          for (let m = 0; m < s1.length - 1; m++) {
            s1[m]=s1[m].replace(/\n/g, "");
            array.push(JSON.parse(s1[m]));
          }
        }
        if (array.length > 0) {
          array.forEach(item => {
            for (var k in item) {
              objlist[k] = item[k];
            }
          });
          array = [];
          objlist.tableItemId = this.filledList[i].tableItemId;
          array.push(objlist);
          this.tableData.push(array[0]);
        }
      }
    }
  },
  created() {
    var that = this;
    this.EventBus.handleEvent("showCKRelationItem", function(val) {
      if (val.valueRelationId == that.baseItem.id) {
        that.tableVisiable = val.showCKRelationItem;
      }
    });
    this.EventBus.handleEvent("clearCKRelationItem", function(val) {
      if (val == that.baseItem.id) {
        that.tableData.splice(0);
        that.filledList = [];
        that.createTable(true);
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 180px;
}
</style>