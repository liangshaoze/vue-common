<template>
  <div>
    <div v-if="baseItem.isDisabled == true">
      <span v-if="titleItem.assessOrderTitleValues.length > 0">
        <el-tag
          v-for="item in titleItem.assessOrderTitleValues"
          :key="item.id"
          :type="item.id"
          class="tagMargin"
        >{{ item.titleValue }}</el-tag>
      </span>
    </div>
    <div v-else>
      <el-select
        size="mini"
        multiple
        collapse-tags
        placeholder="请选择"
        v-model="titleItem.filled"
        @change="changeSelectMulti"
        class="multi-select"
      >
        <el-option
          v-for="(item,index) in baseItem.assessTitleValueOutDtos"
          :key="index"
          :label="item.titleValue"
          :value="item.id"
          :disabled="groupList.length == 0 || (groupList.length > 0 && groupList[0] == item.valueGroup) ? false : true"
        ></el-option>
      </el-select>
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      selectOptions: [],
      groupList: []
    };
  },
  methods: {
    changeSelectMulti(val) {
      this.groupList = [];
      this.titleItem.assessOrderTitleValues = [];
      this.titleItem.filled.forEach(item => {
        var optionObj = this.baseItem.assessTitleValueOutDtos.find(option => {
          return item == option.id;
        });
        if (optionObj) {
          this.groupList.push(optionObj.valueGroup)

          //拷贝第一项
          var obj = {};
          obj.titleId = this.baseItem.id || ""; //题目ID",
          obj.titleType = this.baseItem.titleType || ""; //"题目类型",
          obj.titleName = this.baseItem.titleName || ""; //"题目名称",
          obj.titleClass = this.baseItem.titleClass || ""; //"题目分类",
          obj.titleScore = this.baseItem.titleScore || ""; //"题目分值",
          obj.titleSort = this.baseItem.titleSort || ""; //"题目顺序",
          obj.titleRelationType = this.baseItem.relationType || ""; //"题关联类型"
          obj.titleRelationId = this.baseItem.relationId || ""; //"题关联ID",
          obj.titleValue = optionObj.titleValue || "";
          obj.titleValueId = optionObj.id || "";
          obj.titleValueClass = optionObj.valueClass || ""; //"题目值分类",
          obj.valueScore = optionObj.valueScore || ""; //"题目值分值",
          obj.valueSort = optionObj.valueSort || ""; //"顺序",
          obj.valueRelationType = optionObj.relationType || ""; //"值关联类型",
          obj.valueRelationId = optionObj.relationId || ""; //"值关联ID",
          obj.remark = optionObj.remark || ""; //"remark"
          this.titleItem.assessOrderTitleValues.push(obj);
        }
      });
    }
  },
  mounted() {
    //数据回填
    this.titleItem.filled = [];
    this.titleItem.assessOrderTitleValues.forEach(item => {
      if (item.titleValueId) {
        this.titleItem.filled.push(item.titleValueId);
        //获取当前选择关联的答案集
        var optionObj = this.baseItem.assessTitleValueOutDtos.find(option => {
          return option.titleValue == item.titleValue;
        });
        if(optionObj){
          this.groupList.push(optionObj.valueGroup); //当前选项组
        }
      }
    });
  },
  created() {
    if(this.titleItem.assessOrderTitleValues[0].titleValue == "") {
      var titleList = this.baseItem.assessTitleValueOutDtos;
      for (let i = 0; i < titleList.length; i++) {
        if (titleList[i].isDefault == "1") {
          this.titleItem.filled.push(titleList[i].id);
          this.changeSelectMulti(titleList[i].id);
          this.groupList.push(titleList[i].valueGroup);
        }
      }
    }
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.tagMargin {
  margin: 0px 10px;
}
</style>