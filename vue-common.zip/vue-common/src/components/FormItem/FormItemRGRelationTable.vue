<!--通用表格控件，可编辑-->
<template>
  <div>
    <el-form-item
      :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.relationFilled'"
      :rules="{required: true ,message: '结果不能为空'}"
    >
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        :data="tableData"
        v-loading="loading"
        highlight-current-row
        element-loading-text="拼命加载中"
        class="tableMain"
        stripe
        width="600px"
      >
        <el-table-column label="序号" type="index" show-overflow-tooltip width="50" align="center"></el-table-column>
        <el-table-column
          v-for="(item,index) in tableColumn"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          width="150"
        >
          <template slot-scope="scope">
            <FormItemTableInput
              :baseItem="propertyList[index]"
              :resultItem="scope.row"
              @changeProperty="changeInput"
              @queryMethod="queryMethod"
              v-if="propertyList[index].propertyType==10"
            />
            <FormItemTableSelect
              :baseItem="propertyList[index]"
              :resultItem="scope.row"
              @changeProperty="changeInput"
              @queryMethod="queryMethod"
              v-if="propertyList[index].propertyType==20"
            />
            <FormItemTableAutoComplete
              :baseItem="propertyList[index]"
              :resultItem="scope.row"
              @changeProperty="changeInput"
              @queryMethod="queryMethod"
              v-if="propertyList[index].propertyType==50"
            />
            <!-- <el-input v-model="scope.row[item.prop]" size="mini" @change="changeInput"></el-input> -->
          </template>
        </el-table-column>
        <el-table-column :fixed="right" width="100" label="操作">
          <template slot-scope="scope">
            <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
              <span v-if="scope.$index != 0">
                <el-button
                  size="mini"
                  type="danger"
                  icon="el-icon-delete"
                  @click="handleDeleteRow(scope.$index, scope.row)"
                >删除</el-button>
              </span>
              <span v-else></span>
            </div>
            <div v-else></div>
          </template>
        </el-table-column>
      </el-table>
      <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
        <el-button type="primary" size="mini" icon="el-icon-circle-plus" @click="handleAddRow()">新增</el-button>
      </div>
    </el-form-item>
  </div>
</template>

<script>
import FormItemTableInput from './components/FormItemTableInput'
import FormItemTableSelect from './components/FormItemTableSelect'
import FormItemTableAutoComplete from './components/FormItemTableAutoComplete'
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  components: {
    FormItemTableInput,
    FormItemTableSelect,
    FormItemTableAutoComplete
  },
  data() {
    return {
      loading: false,
      tableColumn: [],
      tableData: [],
      propertyList: []
    };
  },
  methods: {
    //创建表格结构
    createTable() {
      var array = [];
      var str = this.baseItem.titleName.split("|");
      var s = "";
      for (let i = 0; i < str.length; i++) {
        s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
      }
      if (s) {
        var s1 = s.split("|");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        this.tableColumn = array;
      }
      if (this.tableData.length == 0) {
        this.handleProperty();
        this.handleAddRow();
      }
    },
    // 新增
    handleProperty() {
      var str = "";
      var strRemark = "";
      if (this.baseItem.remark) {
        strRemark = this.baseItem.remark.split("|");
      }
      str = this.baseItem.titleName.split("|");

      for (let i = 0; i < str.length; i++) {
        if (this.baseItem.remark) {
          if(strRemark[i].indexOf('url') != -1) {
            if(JSON.parse(strRemark[i]).url == 'findMedicine') {
              this.propertyList.push({
                propertyName: str[i],
                propertyFieldName: 'property' + i,
                propertyType: 50,
                defaultValue: "property4"
              })
            } else if(JSON.parse(strRemark[i]).url == 'findValueBySetCode') {
              this.propertyList.push({
                propertyName: str[i],
                propertyFieldName: 'property' + i,
                propertyType: 20,
                defaultValue: "",
                optionKeyFieldName: "name",
                optionValueFieldName: "value"
              })
            }
          } else {
            this.propertyList.push({
              propertyName: str[i],
              propertyFieldName: 'property' + i,
              propertyType: 10,
              defaultValue: ""
            })
          }
        } else {
          this.propertyList.push({
            propertyName: str[i],
            propertyFieldName: 'property' + i,
            propertyType: 10,
            defaultValue: ""
          })
        }
      }
    },
    handleAddRow() {
      var objlist = {};
      var array = [];
      var str = this.baseItem.titleName.split("|");
      var s = "";
      for (let i = 0; i < str.length; i++) {
        s += '{"property' + [i] + '": ""},';
      }
      if (s) {
        var s1 = s.split(",");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        array.forEach(item => {
          for (var k in item) {
            objlist[k] = item[k];
          }
        });
        array = [];
        array.push(objlist);

        this.tableData.push(array[0]);
      }
    },
    // 删除
    handleDeleteRow($index, row) {
      // this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
      //   confirmButtonText: "确定",
      //   cancelButtonText: "取消",
      //   type: "warning"
      // })
      //   .then(() => {
      this.tableData.splice($index, 1);
      this.titleItem.assessOrderTitleValues.splice($index + 1, 1);
      // })
      // .catch(err => {
      //   return false;
      // });
    },
    changeInput() {
      var list = this.titleItem.assessOrderTitleValues;
      this.titleItem.relationFilled = [];
      var array = [];
      for (let j = 0; j < list.length; j++) {
        if (list[j].valueRelationId) {
          array.push(list[j]);
        }
      }
      this.titleItem.assessOrderTitleValues = array;
      var data = this.tableData;
      for (let i = 0; i < data.length; i++) {
        debugger
        var str = this.baseItem.titleName.split("|");
        var val = "";
        for (let d in data[i]) {
          val += data[i][d] + "|";
        }
        var relationObj = this.titleItem.assessTitleValueOutDtos.find(title => {
          return (
            title.titleValue ==
            this.titleItem.assessOrderTitleValues[0].titleValue
          );
        });
        var obj = {
          titleId: relationObj.relationTitle.id || "", //题目ID",
          titleType: relationObj.relationTitle.titleType || "", //"题目类型",
          titleName: relationObj.relationTitle.titleName || "", //"题目名称",
          titleClass: relationObj.relationTitle.titleClass || "", //"题目分类",
          titleScore: relationObj.relationTitle.titleScore || "", //"题目分值",
          titleSort: relationObj.relationTitle.titleSort || "", //"题目顺序",
          titleRelationType: relationObj.relationTitle.relationType || "", //"题关联类型"
          titleRelationId: relationObj.relationTitle.relationId || "", //"题关联ID",
          titleValueId: relationObj.relationTitle.id || "", // "题目值ID",
          titleValue: val.substring(0, val.length - 1), //"题目值",
          titleValueClass: "", //"题目值分类",
          valueScore: "0", //"题目值分值",
          valueSort: "", //"顺序",
          valueRelationType: "10", //"值关联类型",
          valueRelationId: "", //"值关联ID",
          remark: "" //"remark"
        };
        this.titleItem.relationFilled.push(val.substring(0, val.length - 1));
        this.titleItem.assessOrderTitleValues.push(obj);
      }
    },
    queryMethod(obj, query, cb) {
      this.$emit("queryMethod", obj, query, cb);
    }
  },
  mounted() {
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      var list = this.titleItem.assessOrderTitleValues;
      var array = [];
      for (let j = 0; j < list.length; j++) {
        if (list[j].titleRelationId) {
          array.push(list[j]);
        }
      }
      list = array;
      if (list[0].titleValue == "") {
        return false;
      } else {
        this.tableData = [];
      }
      for (let i = 0; i < list.length; i++) {
        var objlist = {};
        var array = [];
        var str = list[i].titleValue.split("|");
        var s = "";
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": "' + str[i] + '"},';
        }
        if (s) {
          var s1 = s.split(",");
          for (let i = 0; i < s1.length - 1; i++) {
            s1[i]=s1[i].replace(/\n/g, "");
            array.push(JSON.parse(s1[i]));
          }
        }
        if (array.length > 0) {
          array.forEach(item => {
            for (var k in item) {
              objlist[k] = item[k];
            }
          });
          array = [];
          array.push(objlist);
          this.tableData.push(array[0]);
        }
      }
    }
  },
  created() {
    this.createTable();
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 140px;
}
</style>
