<!--通用表格控件，可编辑-->
<template>
  <div id="content">
    <div v-for="(item,index) in propertyList" :key="index">
      <span v-if="item.isInput == '1'" class="TitleClassRequired">
        <nobr class="requiredClass">*</nobr>
        {{index+1}}、{{item.titleName}}
        <span v-if="item.titleType == '101'">(单选)</span>
        <span v-else-if="item.titleType == '102'">(多选)</span>
      </span>
      <span v-else class="TitleClass">
        {{index+1}}、{{item.titleName}}
        <span v-if="item.titleType == '101'">(单选)</span>
        <span v-else-if="item.titleType == '102'">(多选)</span>
      </span>
      <el-form-item
        :ref="'formItem'+index"
        :prop="'assessTitleInDtos.'+index+'.filled'"
        :rules="{required: item.isInput == '1',message: '结果不能为空'}"
      >
        <!-- 输入框/多文本 -->
        <FormItemInput
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '100'"
        />
        <!-- 单选组 -->
        <FormItemRadioGroup
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '101'"
        >
          <template slot-scope="{relationItem}">
             <div
              v-for="(optionItem, relationIndex) in item.assessTitleValueOutDtos"
              :key="relationIndex"
            >
              <div v-if="getRGRelationVisable(optionItem,index)">
                <FormItemRGRelationTemplate
                  :relationTitleList="optionItem.relationTitle"
                  :titleItem="queryFormItem.assessTitleInDtos[index]"
                />
              </div>
            </div>
          </template>
        </FormItemRadioGroup>
        <!-- 多选组 -->
        <FormItemCheckboxGroup
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '102'"
        >
          <div
            v-for="(optionItem, relationIndex) in item.assessTitleValueOutDtos"
            :key="relationIndex"
          >
            <div v-if="getRelationVisable(optionItem,index,relationIndex,item)">
              <FormItemCKRelationTemplate
                :relationTitleList="optionItem.relationTitle"
                :titleItem="queryFormItem.assessTitleInDtos[index]"
              />
            </div>
          </div>
        </FormItemCheckboxGroup>
        <!-- 单选下拉框 -->
        <FormItemSelect
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '103'"
        />
        <!-- 多选下拉框 -->
        <FormItemMultipleSelect
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '104'"
        />
        <!-- 表格自增 -->
        <FormItemTable
          :id="'jump'+index"
          :baseItem="getItem(item,index)"
          :titleItem="queryFormItem.assessTitleInDtos[index]"
          v-if="item.titleType == '105'"
        />
      </el-form-item>
    </div>
  </div>
</template>

<script>
import FormItemCKRelationTemplate from "./FormItemCKRelationTemplate";
import FormItemRGRelationTemplate from "./FormItemRGRelationTemplate";
import FormItemTable from "./FormItemTable";
import FormItemInput from "./FormItemInput";
import FormItemSelect from "./FormItemSelect";
import FormItemRadioGroup from "./FormItemRadioGroup";
import FormItemCheckboxGroup from "./FormItemCheckboxGroup";
import FormItemMultipleSelect from "./FormItemMultipleSelect";

export default {
  props: {
    propertyList: {
      type: Array,
      default: function() {
        return [];
      }
    },
    queryFormItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  components: {
    FormItemCKRelationTemplate,
    FormItemRGRelationTemplate,
    FormItemTable,
    FormItemInput,
    FormItemSelect,
    FormItemRadioGroup,
    FormItemCheckboxGroup,
    FormItemMultipleSelect
  },
  data() {
    return {};
  },
  methods: {
    getItem(item, i) {
      item.titleIndex = i;
      return item;
    },
    getRelationVisable(optionItem, titleIndex, relationIndex, item) {
      if (optionItem.relationTitle) {
        optionItem.relationTitle.isDisabled = item.isDisabled;
        this.$set(optionItem.relationTitle, "titleIndex", titleIndex);
        this.$set(optionItem.relationTitle, "relationIndex", relationIndex);
        return true;
      }
      return false;
    },
    getRGRelationVisable(optionItem, titleIndex) {
      if (optionItem.relationTitle) {
        this.$set(optionItem.relationTitle, "titleIndex", titleIndex);
        return true;
      }
      return false;
    },
    //必填项未填时，跳转
    jump(domId) {
      var element = document.getElementById("content");
      let headerFlag = this.$store.state.settings.fixedHeader;
      //指定dom到页面顶端的距离
      let dom = document.getElementById(domId);
      let domHeight;
      if (headerFlag) {
        domHeight = dom.offsetParent.offsetTop - 60;
      } else {
        domHeight = dom.offsetParent.offsetTop + 40;
      }
      element.offsetParent.scrollTop = domHeight;
    }
  },
  mounted() {},
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.requiredClass {
  color: red;
  vertical-align: middle;
  padding-right: 5px;
}
.TitleClass {
  display: block;
  padding: 10px 0px 10px 30px;
  font-size: 15px;
  font-weight: bold;
}
.TitleClassRequired {
  display: block;
  padding: 10px 0px 10px 20px;
  font-size: 15px;
  font-weight: bold;
}
.el-form-item {
  margin-bottom: 10px;
}
</style>