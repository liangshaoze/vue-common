<!--通用输入框-->
<template>
  <div>
    <span v-if="baseItem.maxLen">
      <el-input
        size="mini"
        :type="inputType"
        clearable
        v-model="titleItem.filled"
        :placeholder="'请输入'+baseItem.titleName+'(最大长度'+baseItem.maxLen+')'"
        :maxlength="baseItem.maxLen"
        :disabled="isReadOnly"
        :onKeypress="keyPress"
        rows="4"
        resize="none"
        :show-word-limit="showWorldLimit"
        style="width: 300px;"
        @change="changeInput"
      ></el-input>
    </span>
    <span v-else>
      <el-input
        size="mini"
        :type="inputType"
        clearable
        v-model="titleItem.filled"
        :placeholder="'请输入'+baseItem.titleName"
        :disabled="isReadOnly"
        :onKeypress="keyPress"
        rows="4"
        resize="none"
        style="width: 300px;"
        @change="changeInput"
      ></el-input>
    </span>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      isReadOnly: false,
      isRelation: false,
      relationList: [],
      inputType: "text",
      showWorldLimit: false,
      height: "",
      weight: "",
      computeBMI: "",
      keyPress: ""
    };
  },
  mounted() {
    if (this.baseItem) {
      if (this.baseItem.maxLen >= 200) {
        this.inputType = "textarea";
        this.showWorldLimit = true;
      }
    }
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      if(this.titleItem.assessOrderTitleValues[0].titleName == "BMI（体重/身高的平方）") {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.isReadOnly = true;
        this.keyPress = "";
      } else if (this.titleItem.assessOrderTitleValues[0].titleName == "身高（cm）") {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.height = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.EventBus.post("computeBMI", { height: this.height });
        this.keyPress = "return (/[0-9.]/.test(String.fromCharCode(event.keyCode)))"
        this.$forceUpdate();
      } else if (this.titleItem.assessOrderTitleValues[0].titleName == "体重(kg)") {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.weight = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.EventBus.post("computeBMI", { weight: this.weight });
        this.keyPress = "return (/[0-9.]/.test(String.fromCharCode(event.keyCode)))"
        this.$forceUpdate();
      } else {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.keyPress = "";
      }
    }
  },
  methods: {
    changeInput() {
      if (this.titleItem.assessOrderTitleValues[0].titleName == "身高（cm）") {
        this.titleItem.assessOrderTitleValues[0].titleValue = this.titleItem.filled;
        this.height = this.titleItem.filled;
        this.EventBus.post("computeBMI", { height: this.height });
      } else if (this.titleItem.assessOrderTitleValues[0].titleName == "体重(kg)") {
        this.titleItem.assessOrderTitleValues[0].titleValue = this.titleItem.filled;
        this.weight = this.titleItem.filled;
        this.EventBus.post("computeBMI", { weight: this.weight });
      } else {
        this.titleItem.assessOrderTitleValues[0].titleValue = this.titleItem.filled;
      }
    }, // 根据身高、体重计算BMI值
    caculateBMI(height, weight) {
      var bmi = "";
      if (height && weight) {
        height = height * 0.01;
        bmi = (weight / (height * height)).toFixed(1);
      }
      return bmi;
    }
  },
  created() {
    var that = this;
    this.EventBus.handleEvent("computeBMI", function(event) {
      //通知处理结果集
      if (event.height) {
        that.height = event.height;
        that.computeBMI = that.caculateBMI(that.height, that.weight);
      }
      if (event.weight) {
        that.weight = event.weight;
        that.computeBMI = that.caculateBMI(that.height, that.weight);
      }
      if (that.titleItem.assessOrderTitleValues[0].titleName == "BMI（体重/身高的平方）") {
        that.titleItem.filled = that.computeBMI;
        that.titleItem.assessOrderTitleValues[0].titleValue = that.computeBMI;
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
</style>