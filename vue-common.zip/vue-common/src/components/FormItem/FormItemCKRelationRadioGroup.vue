<!--通用单选组-->
<template>
  <div>
    <div v-if="tableVisiable">
      <el-form-item
        :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.assessTitleValueOutDtos.'+baseItem.relationIndex+'.relationTitle.relationFilled'"
        :rules="{required: true,message: '结果不能为空'}"
      > 
        <el-col>{{baseItem.titleName}}</el-col>
        <el-radio-group size="mini" v-model="titleItem.assessTitleValueOutDtos[baseItem.relationIndex].relationTitle.relationFilled">
          <span v-for="(item,index) in baseItem.assessTitleValueOutDtos" :key="index">
            <el-radio
              class="radioLeft"
              :label="item.titleValue"
              @change="setValue"
            >{{item.titleValue}}</el-radio>
          </span>
        </el-radio-group>
      </el-form-item>
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      tableVisiable: false
    };
  },
  methods: {
    //选择答案项
    setValue(val) {
      var obj = this.baseItem.assessTitleValueOutDtos.find(item => {
        return item.titleValue == val;
      });
      if(obj) {
        var newObj = {
          titleId: this.baseItem.id || "", //题目ID",
          titleType: this.baseItem.titleType || "", //"题目类型",
          titleName: this.baseItem.titleName || "", //"题目名称",
          titleClass: this.baseItem.titleClass || "", //"题目分类",
          titleScore: this.baseItem.titleScore || "", //"题目分值",
          titleSort: this.baseItem.titleSort || "", //"题目顺序",
          titleRelationType: this.baseItem.relationType || "", //"题关联类型"
          titleRelationId: this.baseItem.relationId || "", //"题关联ID",
          titleValueId: obj.id || "", // "题目值ID",
          titleValue: val, //"题目值",
          titleValueClass: "", //"题目值分类",
          valueScore: obj.valueScore || "0", //"题目值分值",
          valueSort: obj.valueSort || "", //"顺序",
          valueRelationType: "10", //"值关联类型",
          valueRelationId: "", //"值关联ID",
          remark: obj.remark //"remark"
        };
        this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled = val;
        this.EventBus.post("relationCKItemChanged", [newObj]);
      }
    }
  },
  mounted() {
    this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled = "";
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      var list = this.titleItem.assessOrderTitleValues;
      for (let i = 0; i < list.length; i++) {
        var obj = this.baseItem.assessTitleValueOutDtos.find(item => {
          return item.id == list[i].titleValueId;
        });
        if(obj) {
          this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled = list[i].titleValue;
          this.tableVisiable = true;
        }
      }
    }
  },
  created() {
    var that = this;
    this.EventBus.handleEvent("showCKRelationItem", function(val) {
      if (val.valueRelationId == that.baseItem.id) {
        that.tableVisiable = val.showCKRelationItem;
        that.titleItem.assessTitleValueOutDtos[that.baseItem.relationIndex].relationTitle.relationFilled = "";
      }
    });
    this.EventBus.handleEvent("clearCKRelationItem", function(val) {
      if (val == that.baseItem.id) {
        that.radioValue = "";
        that.titleItem.assessTitleValueOutDtos[that.baseItem.relationIndex].relationTitle.relationFilled = "";
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.radioLeft {
  margin: 10px;
}
</style>
