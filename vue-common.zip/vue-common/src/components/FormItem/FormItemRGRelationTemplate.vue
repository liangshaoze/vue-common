<!--通用表格控件，可编辑-->
<template>
  <div>
    <!-- 输入框/多文本 -->
    <FormItemRGRelationInput
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '100'"
    />
    <!-- 多选下拉框 -->
    <FormItemRGRelationMultipleSelect
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '104'"
    />
    <!-- 表格自增 -->
    <FormItemRGRelationTable
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '105'"
    />
  </div>
</template>

<script>
import FormItemRGRelationInput from "./FormItemRGRelationInput";
import FormItemRGRelationTable from "./FormItemRGRelationTable";
import FormItemRGRelationMultipleSelect from "./FormItemRGRelationMultipleSelect";

export default {
  props: {
    relationTitleList: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
  },
  components: {
    FormItemRGRelationInput,
    FormItemRGRelationTable,
    FormItemRGRelationMultipleSelect
  },
  data() {
    return {};
  },
  methods: {},
  mounted() {},
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.requiredClass {
  color: red;
  vertical-align: middle;
  padding-right: 5px;
}
.TitleClass {
  display: block;
  padding: 30px 0px 30px 60px;
  font-size: 15px;
  font-weight: bold;
}
.TitleClassRequired {
  display: block;
  padding: 30px 0px 30px 50px;
  font-size: 15px;
  font-weight: bold;
}
.el-form-item {
  margin-bottom: 0px;
}
</style>