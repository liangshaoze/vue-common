<!--通用输入框-->
<template>
  <div>
    <div v-if="tableVisiable">
      <el-form-item
        :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.assessTitleValueOutDtos.'+baseItem.relationIndex+'.relationTitle.relationFilled'"
        :rules="{required: true,message: '结果不能为空'}"
      >
        <el-col>{{baseItem.titleName}}</el-col>
        <span v-if="baseItem.maxLen">
          <el-input
            size="mini"
            :type="inputType"
            clearable
            v-model="titleItem.assessTitleValueOutDtos[baseItem.relationIndex].relationTitle.relationFilled"
            :placeholder="'请输入'+baseItem.titleName+'(最大长度'+baseItem.maxLen+')'"
            :maxlength="baseItem.maxLen"
            rows="4"
            resize="none"
            :show-word-limit="showWorldLimit"
            style="width: 300px;"
            @change="changeInput"
          ></el-input>
        </span>
        <span v-else>
          <el-input
            size="mini"
            :type="inputType"
            clearable
            v-model="titleItem.assessTitleValueOutDtos[baseItem.relationIndex].relationTitle.relationFilled"
            :placeholder="'请输入'+baseItem.titleName"
            rows="4"
            resize="none"
            style="width: 300px;"
            @change="changeInput"
          ></el-input>
        </span>
      </el-form-item>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      inputType: "text",
      showWorldLimit: false,
      tableVisiable: false
    };
  },
  methods: {
    changeInput() {
      var obj = {
        titleId: this.baseItem.id || "", //题目ID",
        titleType: this.baseItem.titleType || "", //"题目类型",
        titleName: this.baseItem.titleName || "", //"题目名称",
        titleClass: this.baseItem.titleClass || "", //"题目分类",
        titleScore: this.baseItem.titleScore || "", //"题目分值",
        titleSort: this.baseItem.titleSort || "", //"题目顺序",
        titleRelationType: this.baseItem.relationType || "", //"题关联类型"
        titleRelationId: this.baseItem.relationId || "", //"题关联ID",
        titleValueId: "", // "题目值ID",
        titleValue: this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled, //"题目值",
        titleValueClass: "", //"题目值分类",
        valueScore: "0", //"题目值分值",
        valueSort: "", //"顺序",
        valueRelationType: "10", //"值关联类型",
        valueRelationId: "", //"值关联ID",
        remark: "" //"remark"
      };
      this.EventBus.post("relationCKItemChanged", [obj]);
    }
  },
  mounted() {
    if (this.baseItem) {
      if (this.baseItem.maxLen >= 200) {
        this.inputType = "textarea";
        this.showWorldLimit = true;
      }
    }
    this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled = "";
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      var list = this.titleItem.assessOrderTitleValues;
      for (let i = 0; i < list.length; i++) {
        if (list[i].titleRelationId == this.baseItem.relationId) {
          this.titleItem.assessTitleValueOutDtos[this.baseItem.relationIndex].relationTitle.relationFilled = list[i].titleValue;
          this.tableVisiable = true;
        }
      }
    }
  },
  created() {
    var that = this;
    this.EventBus.handleEvent("showCKRelationItem", function(val) {
      if (val.valueRelationId == that.baseItem.id) {
        that.tableVisiable = val.showCKRelationItem;
        that.titleItem.assessTitleValueOutDtos[that.baseItem.relationIndex].relationTitle.relationFilled = "";
      }
    });
    this.EventBus.handleEvent("clearCKRelationItem", function(val) {
      if (val == that.baseItem.id) {
        that.titleItem.assessTitleValueOutDtos[that.baseItem.relationIndex].relationTitle.relationFilled = "";
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
</style>