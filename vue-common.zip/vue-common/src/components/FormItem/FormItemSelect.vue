<template>
  <div>
    <div v-if="baseItem.isDisabled == true">
      <el-tag
        v-for="item in titleItem.assessOrderTitleValues"
        :key="item.id"
        :type="item.id"
        class="tagMargin"
      >{{ item.titleValue }}</el-tag>
    </div>
    <div v-else>
      <el-select
        size="mini"
        placeholder="请选择"
        v-model="titleItem.filled"
        @change="changeSelect"
        @clear="clearSelect"
        class="multi-select"
        clearable
      >
        <el-option
          v-for="(item,index) in baseItem.assessTitleValueOutDtos"
          :key="index"
          :label="item.titleValue"
          :value="item.id"
        ></el-option>
      </el-select>
    </div>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },

  data() {
    return {
      selectOptions: []
    };
  },
  methods: {
    changeSelect(val) {
      var optionObj = this.baseItem.assessTitleValueOutDtos.find(item => {
        return item.id == val;
      });
      if (optionObj) {
        var obj = this.titleItem.assessOrderTitleValues[0];
        obj.titleValue = optionObj.titleValue || "";
        obj.titleValueId = optionObj.id || "";
        obj.titleValueClass = optionObj.valueClass || ""; //"题目值分类",
        obj.valueScore = optionObj.valueScore || ""; //"题目值分值",
        obj.valueSort = optionObj.valueSort || ""; //"顺序",
        obj.valueRelationType = optionObj.relationType || ""; //"值关联类型",
        obj.valueRelationId = optionObj.relationId || ""; //"值关联ID",
        obj.remark = optionObj.remark || ""; //"remark"
        this.titleItem.filled = obj.titleValueId;
      }

    },
    clearSelect(val) {
      this.titleItem.assessOrderTitleValues[0].titleValue = "";
      this.titleItem.assessOrderTitleValues[0].id = "";
      this.titleItem.filled = "";
    }
  },
  mounted() {
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValueId;
    }
  },
  created() {
    if(this.titleItem.assessOrderTitleValues[0].titleValue == "") {
      var titleList = this.baseItem.assessTitleValueOutDtos;
      for (let i = 0; i < titleList.length; i++) {
        if(titleList[i].isDefault == '1') {
          this.titleItem.filled == titleList[i].id;
          this.changeSelect(titleList[i].id);
        }
      }
    }
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.tagMargin {
  margin:0px 10px;
}
</style>