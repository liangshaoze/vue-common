<template>
  <div>
    <el-form-item
      :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.relationFilled'"
      :rules="{required: true ,message: '结果不能为空'}"
    >
      <div v-if="baseItem.isDisabled == true">
        <el-tag
          v-for="item in selectOptions"
          :key="item.id"
          :type="item.id"
          class="tagMargin"
          >
          {{ item.titleValue }}
        </el-tag>
      </div>
      <div v-else>
        <el-select
          size="mini"
          multiple
          collapse-tags
          placeholder="请选择"
          v-model="titleItem.relationFilled"
          @change="changeSelectMulti"
          class="multi-select"
        >
          <el-option
            v-for="(item,index) in baseItem.assessTitleValueOutDtos"
            :key="index"
            :label="item.titleValue"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
    </el-form-item>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      selectOptions: []
    };
  },
  methods: {
    changeSelectMulti(val) {
      var list = this.titleItem.assessOrderTitleValues;
      var array = [];
      for (let j = 0; j < list.length; j++) {
        if (list[j].valueRelationId) {
          array.push(list[j]);
        }
      }
      this.titleItem.assessOrderTitleValues = array;
      this.titleItem.relationFilled.forEach(item => {
        var optionObj = this.baseItem.assessTitleValueOutDtos.find(option => {
          return item == option.id;
        });
        if (optionObj) {
          var obj ={
            titleId : this.baseItem.id || "", //题目ID",
            titleType : this.baseItem.titleType || "", //"题目类型",
            titleName : this.baseItem.titleName || "", //"题目名称",
            titleClass : this.baseItem.titleClass || "", //"题目分类",
            titleScore : this.baseItem.titleScore || "", //"题目分值",
            titleSort : this.baseItem.titleSort || "", //"题目顺序",
            titleRelationType : this.baseItem.relationType || "", //"题关联类型"
            titleRelationId : this.baseItem.relationId || "", //"题关联ID",
            titleValue : optionObj.titleValue || "",
            titleValueId : optionObj.id || "",
            titleValueClass : "", //"题目值分类",
            valueScore : "0", //"题目值分值",
            valueSort : optionObj.valueSort || "", //"顺序",
            valueRelationType : "10", //"值关联类型",
            valueRelationId : "", //"值关联ID",
            remark : "" //"remark"
          }
          this.titleItem.assessOrderTitleValues.push(obj);
        }
      });
    }
  },
  mounted() {
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      //数据回填
      this.titleItem.relationFilled = [];
      var list = this.titleItem.assessOrderTitleValues;
      var array = [];
      var newList = []
      for (let j = 0; j < list.length; j++) {
        if (!list[j].valueRelationId) {
          array.push(list[j]);
        } else {
          newList.push(list[j]);
        }
      }
      this.selectOptions = array;
      for (let i = 0; i < array.length; i++) {
        if (array[i].titleValue) {
          this.titleItem.relationFilled.push(array[i].titleValueId);
        }
      }
    }
  },
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.tagMargin {
  margin:0px 10px;
}
</style>
