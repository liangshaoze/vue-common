<!--通用表格控件，可编辑-->
<template>
  <div>
    <el-table
      :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
      size="mini"
      :data="tableData"
      v-loading="loading"
      highlight-current-row
      element-loading-text="拼命加载中"
      class="tableMain"
      stripe
      width="600px"
    >
      <el-table-column label="序号" type="index" show-overflow-tooltip width="50" align="center"></el-table-column>
      <el-table-column
        v-for="(item,index) in tableColumn"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        width="200"
      >
        <template slot-scope="scope">
          <el-input v-model="scope.row[item.prop]" size="mini" @change="changeInput"></el-input>
        </template>
      </el-table-column>
      <el-table-column :fixed="right" width="100" label="操作">
        <template slot-scope="scope">
          <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
            <span v-if="scope.$index != 0">
              <el-button
                size="mini"
                type="danger"
                icon="el-icon-delete"
                @click="handleDeleteRow(scope.$index, scope.row)"
              >删除</el-button>
            </span>
            <span v-else></span>
          </div>
          <div v-else></div>
        </template>
      </el-table-column>
    </el-table>
    <div v-if="baseItem.isDisabled !== true && baseItem.isDisabled !== 'true'">
      <el-button type="primary" size="mini" icon="el-icon-circle-plus" @click="handleAddRow()">新增</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      tableColumn: [],
      tableData: []
    };
  },
  methods: {
    //创建表格结构
    createTable() {
      var array = [];
      var str = this.baseItem.titleName.split("|");
      var s = "";
      for (let i = 0; i < str.length; i++) {
        s += '{"prop":"property' + i + '","label": "' + str[i] + '"}|';
      }
      if (s) {
        var s1 = s.split("|");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        this.tableColumn = array;
      }
      if (this.tableData.length == 0) {
        this.handleAddRow();
      }
    },
    // 新增
    handleAddRow() {
      var objlist = {};
      var array = [];
      var str = "";
      if (this.baseItem.remark) {
        str = this.baseItem.remark.split("|");
      } else {
        str = this.baseItem.titleName.split("|");
      }
      var s = "";
      if (this.baseItem.remark) {
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": "' + str[i] + '"},';
        }
      } else {
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": ""},';
        }
      }
      if (s) {
        var s1 = s.split(",");
        for (let i = 0; i < s1.length - 1; i++) {
          s1[i]=s1[i].replace(/\n/g, "");
          array.push(JSON.parse(s1[i]));
        }
      }
      if (array.length > 0) {
        array.forEach(item => {
          for (var k in item) {
            objlist[k] = item[k];
          }
        });
        array = [];
        array.push(objlist);

        this.tableData.push(array[0]);
      }
    },
    // 删除
    handleDeleteRow($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.tableData.splice($index, 1);
          this.titleItem.assessOrderTitleValues.splice($index, 1);
        })
        .catch(err => {
          return false;
        });
    },
    changeInput() {
      this.titleItem.assessOrderTitleValues = [];
      var data = this.tableData;
      for (let i = 0; i < data.length; i++) {
        var str = this.baseItem.titleName.split("|");
        var val = "";
        for (let d in data[i]) {
          val += data[i][d] + "|";
        }
        var obj = {
          titleId: this.titleItem.id || "", //题目ID",
          titleType: this.titleItem.titleType || "", //"题目类型",
          titleName: this.titleItem.titleName || "", //"题目名称",
          titleClass: this.titleItem.titleClass || "", //"题目分类",
          titleScore: this.titleItem.titleScore || "", //"题目分值",
          titleSort: this.titleItem.titleSort || "", //"题目顺序",
          titleRelationType: this.titleItem.relationType || "", //"题关联类型"
          titleRelationId: this.titleItem.relationId || "", //"题关联ID",
          titleValueId: this.titleItem.id || "", // "题目值ID",
          titleValue: val.substring(0, val.length - 1), //"题目值",
          titleValueClass: "", //"题目值分类",
          valueScore: "0", //"题目值分值",
          valueSort: "", //"顺序",
          valueRelationType: "10", //"值关联类型",
          valueRelationId: "", //"值关联ID",
          remark: "" //"remark"
        };
        this.titleItem.assessOrderTitleValues.push(obj);
      }
    }
  },
  mounted() {
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      var list = this.titleItem.assessOrderTitleValues;
      if (list[0].titleValue == "") {
        return false;
      } else {
        this.tableData = [];
      }
      for (let i = 0; i < list.length; i++) {
        var objlist = {};
        var array = [];
        var str = list[i].titleValue.split("|");
        var s = "";
        for (let i = 0; i < str.length; i++) {
          s += '{"property' + [i] + '": "' + str[i] + '"},';
        }
        if (s) {
          var s1 = s.split(",");
          for (let i = 0; i < s1.length - 1; i++) {
            s1[i]=s1[i].replace(/\n/g, "");
            array.push(JSON.parse(s1[i]));
          }
        }
        if (array.length > 0) {
          array.forEach(item => {
            for (var k in item) {
              objlist[k] = item[k];
            }
          });
          array = [];
          array.push(objlist);
          this.tableData.push(array[0]);
        }
      }
    }
  },
  created() {
    this.createTable();
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 180px;
}
</style>