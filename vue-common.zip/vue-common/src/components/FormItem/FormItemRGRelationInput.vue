<!--通用输入框-->
<template>
  <div>
    <el-form-item
      :prop="'assessTitleInDtos.'+baseItem.titleIndex+'.relationFilled'"
      :rules="{required: isRequired ,message: '结果不能为空'}"
    >
      <el-col>{{baseItem.titleName}}</el-col>
      <span v-if="baseItem.maxLen">
        <el-input
          size="mini"
          :type="inputType"
          clearable
          v-model="titleItem.relationFilled"
          :placeholder="'请输入'+baseItem.titleName+'(最大长度'+baseItem.maxLen+')'"
          :maxlength="baseItem.maxLen"
          rows="4"
          resize="none"
          :show-word-limit="showWorldLimit"
          style="width: 300px;"
          @change="changeInput"
        ></el-input>
      </span>
      <span v-else>
        <el-input
          size="mini"
          :type="inputType"
          clearable
          v-model="titleItem.relationFilled"
          :placeholder="'请输入'+baseItem.titleName"
          rows="4"
          resize="none"
          style="width: 300px;"
          @change="changeInput"
        ></el-input>
      </span>
    </el-form-item>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      inputType: "text",
      showWorldLimit: false,
      isRequired: true
    };
  },
  mounted() {
    if (this.baseItem) {
      if (this.baseItem.maxLen >= 200) {
        this.inputType = "textarea";
        this.showWorldLimit = true;
      }
    }
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      this.titleItem.relationFilled = this.titleItem.assessOrderTitleValues[1].titleValue;
    }
  },
  methods: {
    changeInput() {
      if (
        this.titleItem.assessOrderTitleValues &&
        this.titleItem.assessOrderTitleValues.length > 0
      ) {
        this.titleItem.assessOrderTitleValues[1].titleValue = this.titleItem.relationFilled;
      }
    }
  },
  created() {
    if(this.baseItem.titleName == '下降体重（kg）') {
      this.isRequired = false;
    }
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
</style>
