<!--通用单选组-->
<template>
  <div>
    <el-checkbox-group size="mini" v-model="titleItem.filled">
      <el-checkbox
        @change="checkItem"
        v-for="(item,index) in baseItem.assessTitleValueOutDtos"
        :key="index"
        :disabled="groupList.length == 0 || (groupList.length > 0 && groupList[0] == item.valueGroup) ? false : true"
        :label="item.titleValue"
      >{{item.titleValue}}</el-checkbox>
    </el-checkbox-group>
    <!-- 关联项插槽 -->
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      groupList: []
    };
  },
  methods: {
    checkItem(val, event) {
      var _value = '';
      var flag = false;
      if(event.target) {
        _value = event.target._value;;
      } else {
        flag = true;
        _value = event;
      }
      //获取当前选择关联的答案集
      var optionObj = this.baseItem.assessTitleValueOutDtos.find(option => {
        return option.titleValue == _value;
      });
      if (val) { //开启关联项
        if (optionObj) {
          if(!flag) {
            this.groupList.push(optionObj.valueGroup); //当前选项组
          }

          var obj = {};
          obj.titleId = this.baseItem.id || ""; //题目ID",
          obj.titleType = this.baseItem.titleType || ""; //"题目类型",
          obj.titleName = this.baseItem.titleName || ""; //"题目名称",
          obj.titleClass = this.baseItem.titleClass || ""; //"题目分类",
          obj.titleScore = this.baseItem.titleScore || ""; //"题目分值",
          obj.titleSort = this.baseItem.titleSort || ""; //"题目顺序",
          obj.titleRelationType = this.baseItem.relationType || ""; //"题关联类型"
          obj.titleRelationId = this.baseItem.relationId || ""; //"题关联ID",
          obj.titleValue = optionObj.titleValue || "";
          obj.titleValueId = optionObj.id || "";
          obj.titleValueClass = ""; //"题目值分类",
          obj.valueScore = optionObj.valueScore || ""; //"题目值分值",
          obj.valueSort = optionObj.valueSort || ""; //"顺序",
          obj.valueRelationType = optionObj.relationType || ""; //"值关联类型",
          obj.valueRelationId = optionObj.relationId || ""; //"值关联ID",
          obj.remark = optionObj.remark || ""; //"remark"
          obj.showCKRelationItem = true;
          this.titleItem.assessOrderTitleValues.push(obj); //外层答案放入结果集
          this.EventBus.post("showCKRelationItem", obj); //通知关联项处理
        }
      } else { //关闭关联项
        if (optionObj) {
          //获取关联项的id
          var valueRelationId = "";
          for (var i = this.titleItem.assessOrderTitleValues.length - 1; i >= 0; i--) {
            if (optionObj.titleValue == this.titleItem.assessOrderTitleValues[i].titleValue) {
              this.titleItem.assessOrderTitleValues[i].showCKRelationItem = false;
              this.EventBus.post("showCKRelationItem",this.titleItem.assessOrderTitleValues[i]);
              this.EventBus.post("clearCKRelationItem",this.titleItem.assessOrderTitleValues[i].valueRelationId);
              valueRelationId = this.titleItem.assessOrderTitleValues[i].valueRelationId;
              this.titleItem.assessOrderTitleValues.splice(i, 1);
              this.groupList.splice(i-1,1); //删除当前组选项
            }
          }
          //删除关联项
          for (var i = this.titleItem.assessOrderTitleValues.length - 1; i >= 0; i--) {
            if (valueRelationId == this.titleItem.assessOrderTitleValues[i].titleId) {
              this.titleItem.assessOrderTitleValues.splice(i, 1);
            }
          }
        }
      }
    }
  },
  mounted() {
    //移除项
    if ( this.titleItem.assessOrderTitleValues.length == 1 && this.titleItem.assessOrderTitleValues[0].titleValue == "") {
      this.titleItem.assessOrderTitleValues.splice(0);
    }
    if (this.titleItem.filled.length > 0) {
      this.titleItem.filled.splice(0);
    }
    if (this.titleItem.assessOrderTitleValues) {
      this.titleItem.assessOrderTitleValues.forEach(item => {
        this.titleItem.filled.push(item.titleValue);
        //获取当前选择关联的答案集
        var optionObj = this.baseItem.assessTitleValueOutDtos.find(option => {
          return option.titleValue == item.titleValue;
        });
        if(optionObj){
          this.groupList.push(optionObj.valueGroup); //当前选项组
        }
      });
    }
  },
  created() {
    //处理默认项
    if (this.titleItem.assessOrderTitleValues[0].titleValue == "") {
      this.titleItem.assessOrderTitleValues = [];
      var titleList = this.baseItem.assessTitleValueOutDtos;
      for (let i = 0; i < titleList.length; i++) {
        if (titleList[i].isDefault == "1") {
          this.titleItem.filled.push(titleList[i].titleValue);
          this.checkItem(true,titleList[i].titleValue);
        }
      }
    }
    var that = this;
    this.EventBus.handleEvent("relationCKItemChanged", function(val) { //通知处理结果集
      if (val && val.length > 0) {
        if (JSON.stringify(that.baseItem).indexOf(val[0].titleId) !== -1) {
          //先删后新增
          for (var i = that.titleItem.assessOrderTitleValues.length - 1; i >= 0; i--) {
            if (
              that.titleItem.assessOrderTitleValues[i].titleId == val[0].titleId
            ) {
              that.titleItem.assessOrderTitleValues.splice(i, 1);
            }
          }
          that.titleItem.assessOrderTitleValues = that.titleItem.assessOrderTitleValues.concat(val);
        }
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss">
.multi-select {
  width: 200px;
}
.nomal-select {
  width: 200px;
}
.el-select__tags-text {
  font-size: 11px;
}
</style>
