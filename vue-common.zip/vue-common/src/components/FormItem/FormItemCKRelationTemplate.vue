<!--通用表格控件，可编辑-->
<template>
  <div>
    <!-- 输入框/多文本 -->
    <FormItemCKRelationInput
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '100'"
    />
    <!-- 单选组 -->
    <FormItemCKRelationRadioGroup
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '101'"
    />
    <!-- 表格自增 -->
    <FormItemCKRelationTable
      :baseItem="relationTitleList"
      :titleItem="titleItem"
      v-if="relationTitleList.titleType == '105'"
    />
  </div>
</template>

<script>
import FormItemCKRelationInput from "./FormItemCKRelationInput";
import FormItemCKRelationTable from "./FormItemCKRelationTable";
import FormItemCKRelationRadioGroup from "./FormItemCKRelationRadioGroup";

export default {
  props: {
    relationTitleList: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  components: {
    FormItemCKRelationInput,
    FormItemCKRelationTable,
    FormItemCKRelationRadioGroup
  },
  data() {
    return {};
  },
  methods: {},
  mounted() {},
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.requiredClass {
  color: red;
  vertical-align: middle;
  padding-right: 5px;
}
.TitleClass {
  display: block;
  padding: 30px 0px 30px 60px;
  font-size: 15px;
  font-weight: bold;
}
.TitleClassRequired {
  display: block;
  padding: 30px 0px 30px 50px;
  font-size: 15px;
  font-weight: bold;
}
.el-form-item {
  margin-bottom: 0px;
}
</style>