<!--通用单选组-->
<template>
  <div>
    <el-radio-group size="mini" v-model="titleItem.filled">
      <span v-for="(item,index) in baseItem.assessTitleValueOutDtos" :key="index">
        <el-radio
          class="radioLeft"
          :label="item.titleValue"
          @change="setValue"
        >{{item.titleValue}}</el-radio>
      </span>
    </el-radio-group>
    <span v-if="isRelation">
      <slot v-bind:relationItem="relationItem"></slot>
    </span>
  </div>
</template>


<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    titleItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      isRelation: false,
      relationItem: []
    };
  },
  methods: {
    //选择答案项
    setValue(val) {
      var obj = {};
      obj = this.baseItem.assessTitleValueOutDtos.find(item => {
        return item.titleValue === val;
      });

      var newObj = {
        titleId: this.baseItem.id || "", //题目ID",
        titleType: this.baseItem.titleType || "", //"题目类型",
        titleName: this.baseItem.titleName || "", //"题目名称",
        titleClass: this.baseItem.titleClass || "", //"题目分类",
        titleScore: this.baseItem.titleScore || "", //"题目分值",
        titleSort: this.baseItem.titleSort || "", //"题目顺序",
        titleRelationType: this.baseItem.relationType || "", //"题关联类型"
        titleRelationId: this.baseItem.relationId || "", //"题关联ID",
        titleValueId: obj.id, // "题目值ID",
        titleValue: obj.titleValue, //"题目值",
        titleValueClass: obj.valueClass, //"题目值分类",
        valueScore: obj.valueScore || "0", //"题目值分值",
        valueSort: obj.valueSort || "", //"顺序",
        valueRelationType: obj.relationType || "", //"值关联类型",
        valueRelationId: obj.relationId || "", //"值关联ID",
        remark: obj.remark || "" //"remark"
      };
      this.titleItem.assessOrderTitleValues = [];
      this.titleItem.assessOrderTitleValues.push(newObj);
      this.titleItem.filled = newObj.titleValue;

      if (obj.relationId) {
        var newObj = {
          titleId: obj.relationTitle.id || "", //题目ID",
          titleType: obj.relationTitle.titleType || "", //"题目类型",
          titleName: obj.relationTitle.titleName || "", //"题目名称",
          titleClass: obj.relationTitle.titleClass || "", //"题目分类",
          titleScore: obj.relationTitle.titleScore || "", //"题目分值",
          titleSort: obj.relationTitle.titleSort || "", //"题目顺序",
          titleRelationType: obj.relationTitle.relationType || "", //"题关联类型"
          titleRelationId: obj.relationTitle.relationId || "", //"题关联ID",
          titleValueId: "", // "题目值ID",
          titleValue: "", //"题目值",
          titleValueClass: "", //"题目值分类",
          valueScore: "0", //"题目值分值",
          valueSort: "", //"顺序",
          valueRelationType: "10", //"值关联类型",
          valueRelationId: "", //"值关联ID",
          remark: "" //"remark"
        };
        this.titleItem.assessOrderTitleValues.push(newObj);
        obj.relationTitle.titleIndex = this.baseItem.titleIndex;
        obj.relationTitle.isDisabled = this.baseItem.isDisabled;
        this.relationItem = obj.relationTitle;
        this.isRelation = true;
      } else {
        this.relationItem = [];
        this.isRelation = false;
      }
    }
  },
  mounted() {
    if (
      this.titleItem.assessOrderTitleValues &&
      this.titleItem.assessOrderTitleValues.length > 0
    ) {
      if (this.titleItem.assessOrderTitleValues[0].valueRelationId) {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
        this.titleItem.relationFilled = this.titleItem.assessOrderTitleValues[1].titleValue;
        var obj = this.baseItem.assessTitleValueOutDtos.find((title)=>{
          return title.titleValue==this.titleItem.filled;
        })
        obj.relationTitle.titleIndex = this.baseItem.titleIndex;
        obj.relationTitle.isDisabled = this.baseItem.isDisabled;
        this.relationItem = obj.relationTitle;
        this.isRelation = true;
      } else {
        this.titleItem.filled = this.titleItem.assessOrderTitleValues[0].titleValue;
      }
    }
  },
  created() {
    if(this.titleItem.assessOrderTitleValues[0].titleValue == "") {
      var titleList = this.baseItem.assessTitleValueOutDtos;
      for (let i = 0; i < titleList.length; i++) {
        if(titleList[i].isDefault == '1') {
          this.titleItem.filled = titleList[i].titleValue;
        }
      }
      if(this.titleItem.filled.length > 0) {
        this.setValue(this.titleItem.filled);
      }
    }
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.radioLeft {
  margin: 10px;
}
</style>
