<!--通用自动远程搜索-->
<template>
    <div id="auto_complete">
      <el-autocomplete
        :trigger-on-focus="true"
        v-model="resultItem[baseItem.propertyFieldName]"
        size="mini"
        clearable
        :fetch-suggestions="remoteMethodCommon"
        :placeholder="'请输入'+baseItem.propertyName"
        @select="selectedPropertyValue"
        @clear="clearPropertyValue"
      ></el-autocomplete>
  </div>
</template>

<script>
import { findMedicine } from 'api/assessment'
export default {
  props: {
    baseItem: {
      type: Object,
      default: function(){
        return {
          propertyFieldName: "",//属性字段名
          propertyName: "",//属性名称
          propertyValue:"",//属性值
          options: [],//可选项的集合
          optionKeyFieldName:"",//可选项值对应的key的字段名
          optionValueFieldName:"",//可选项值对应的value的字段名
          valueSetCode:"",//值集代码
          propertyType:"",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框
          queryMethod:""//获取选项值列表的方法名称
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },

  data() {
    return {
      drugsNameOptions: []
    };
  },
  methods: {
    remoteMethodCommon(query,cb) {
      var params = {
        firstType: "",
        secondType: "",
        name: query,
      };
      findMedicine(params).then(response => {
        if (response.data.statusCode == "200") {
          this.drugsNameOptions = [];
          let data = response.data.responseData;
          for (let i = 0; data && i < data.length; i++) {
              this.drugsNameOptions.push({
                value: data[i].name,
                code: data[i].renPing,
                attentions: data[i].attentions
              });
            }
            if (this.drugsNameOptions.length === 0) {
              this.drugsNameOptions = [{ value: "无", code: "-1" }];
            }
          cb(this.drugsNameOptions)
        }
      });
    },
    selectedPropertyValue(item) {
      debugger
      if (item.value !== "无") {
        this.resultItem[this.baseItem.propertyFieldName]=item.value;
        this.resultItem[this.baseItem.defaultValue]=item.attentions;
      } else {
        this.resultItem[this.baseItem.propertyFieldName]= "";
        this.resultItem[this.baseItem.defaultValue]="";
      }
      this.$emit("changeProperty",this.resultItem[this.baseItem.propertyFieldName]);
    },
    clearPropertyValue(){
      this.resultItem[this.baseItem.propertyFieldName]= "";
      this.resultItem[this.baseItem.defaultValue]="";
      this.$emit("changeProperty", "");
    }
  },
  created(){
  },
  mounted() {
  }
};
</script>

<style lang="scss">
// .multi-select{
//   width: 200px;
// }
// .nomal-select{
//   width: 200px;
// }
// .el-select__tags-text{
//   font-size: 11px;
// }
// #auto_complete .el-autocomplete {
//   width: 200px;
// }
</style>