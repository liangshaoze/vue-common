<!-- 
省市区三级联动封装 
新增用法
    <Address 
        @selectChange="selectChange">
    </Address>
    监听选中的值 
编辑用法
<Address 
          @selectChange="selectChange"
          :edit=true
          :provinceId="'130000'"//省id
          :cityId="'130200'"//市id
          :areaId="'130205'"//区id
          ></Address>
监听选中的值
selectChange(val) {
      console.log(val.pName);//省名称
      console.log(val.pCode);//省ID
      console.log(val.cName);//市名称
      console.log(val.cCode);//市ID
      console.log(val.aName);//区名称
      console.log(val.aCode);//区ID
    },
   源码 不要乱改 有问题找小程 --> 

<template>
  <div class="area_wrap">
    <el-select @change="provinceSelectChange" v-model="provinceCode" placeholder="请选择" class="area">
      <el-option v-for="item in provinceOptions" :key="item.id" :label="item.name" :value="item.id"></el-option>
    </el-select>
    <span class="areaText">省</span>
    <el-select @change="citySelectChange" v-model="cityCode" placeholder="请选择" class="area">
      <el-option v-for="item in cityOptions" :key="item.id" :label="item.name" :value="item.id"></el-option>
    </el-select>
    <span class="areaText">市</span>
    <el-select @change="areaSelectChange" v-model="areaCode" placeholder="请选择" class="area">
      <el-option v-for="item in areaOptions" :key="item.id" :label="item.name" :value="item.id"></el-option>
    </el-select>
    <span class="areaText">区</span>
  </div>
</template>

<script>
import { findAddressDictList } from "api/common/index.js";
export default {
  props: {
    edit: {
      type: Boolean,
      default: false
    },
    provinceId: {
      type: String,
      default: ""
    },

    cityId: {
      type: String,
      default: ""
    },
    areaId: {
      type: String,
      default: ""
    },
    pName: {
      type: String,
      default: ""
    },
    pCode: {
      type: String,
      default: ""
    },
    cName: {
      type: String,
      default: ""
    },
    cCode: {
      type: String,
      default: ""
    },
    aName: {
      type: String,
      default: ""
    },
    aCode: {
      type: String,
      default: ""
    }
  },

  data() {
    return {
      provinceCode: "",
      provinceName: "",
      cityCode: "",
      cityName: "",
      areaCode: "",
      areaName: "",
      provinceOptions: [],
      cityOptions: [],
      areaOptions: [],
      provinceType: 1,
      cityType: 2,
      areaType: 3,
      pid: 0
    };
  },
  methods: {
    //获取省市区数据
    findAddressDictList(type) {
      const params = {
        pid: this.pid
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            if (type == this.provinceType) {
              this.provinceOptions = response.data.responseData;
            } else if (type == this.cityType) {
              this.cityOptions = response.data.responseData;
            } else {
              this.areaOptions = response.data.responseData;
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error("服务端异常，请稍后再试");
        });
    },
    //设置省市区数据
    setAddressDictList(currPid, type) {
      const params = {
        pid: currPid
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            if (type == this.provinceType) {
              this.provinceCode = this.provinceId;
              this.provinceOptions = response.data.responseData;
            } else if (type == this.cityType) {
              this.cityOptions = response.data.responseData;
              this.cityCode = this.cityId;
            } else {
              this.areaOptions = response.data.responseData;
              this.areaCode = this.areaId;
            }
          } else {
            this.$message.error(response.data.statusMsg);
          }
        })
        .catch(error => {
          this.$message.error("服务端异常，请稍后再试");
        });
    },
    provinceSelectChange(value) {
      //第一步选中省后清空城市和区域数据
      this.cityOptions = [];
      this.cityCode = "";
      this.cityName = "";
      this.areaOptions = [];
      this.areaCode = "";
      this.areaName = "";
      //第二步 根据当前的选中code 获取选中的name 后端需要这个字段
      this.provinceName = this.getNameById(this.provinceOptions, value);
      //pid是全局变量  这里选中省后 获取的是城市的pid也就是当前省的id 根据省查询下面市的数据（下面逻辑一个样就不备注了）
      this.pid = value;
      this.findAddressDictList(this.cityType);
      this.$emit("selectChange", {
        pName: this.provinceName,
        pCode: this.provinceCode,
        cName: this.cityName,
        cCode: this.cityCode,
        aName: this.areaName,
        aCode: this.areaCode
      });
    },
    citySelectChange(value) {
      this.areaOptions = [];
      this.areaCode = "";
      this.areaName = "";
      this.cityName = this.getNameById(this.cityOptions, value);
      this.pid = value;
      this.findAddressDictList(this.areaType);
      this.$emit("selectChange", {
        pName: this.provinceName,
        pCode: this.provinceCode,
        cName: this.cityName,
        cCode: this.cityCode,
        aName: this.areaName,
        aCode: this.areaCode
      });
    },
    areaSelectChange(value) {
      this.areaName = this.getNameById(this.areaOptions, value);
      this.$emit("selectChange", {
        pName: this.provinceName,
        pCode: this.provinceCode,
        cName: this.cityName,
        cCode: this.cityCode,
        aName: this.areaName,
        aCode: this.areaCode
      });
    },
    getNameById(options, value) {
      let option = options.find(v => v.id == value);
      return option.name;
    }
  },
  created() {
    
  },
  mounted () {
    //如果是编辑状态下
    if (this.edit) {
      new Promise(resolve => {
        this.setAddressDictList(this.pid, this.provinceType);
        resolve("success");
      })
      .then(value => {
          this.setAddressDictList(this.provinceId, this.cityType);
          return value;
      })
      .then(value => {
          this.setAddressDictList(this.cityId, this.areaType);
      });
    } else {
      //默认获取省的数据
      this.findAddressDictList(this.provinceType);
    }
  },

};
</script>

<style lang="scss" scoped>
.area_wrap {
  display: flex;
  width: 600px;
  align-items: center;
}
.area_wrap .area {
  width: 180px;
}
.area_wrap .areaText {
  padding: 0 10px;
}
</style>