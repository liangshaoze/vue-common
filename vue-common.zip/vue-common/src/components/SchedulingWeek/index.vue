<template>
  <div id="tableScheduling">
    <el-table
      :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
      :data="schedulingData"
      border
      :row-class-name="tableRowClassName"
      :show-header="false"
    >
      <el-table-column
        v-for="(item,index) in weekLabel"
        :prop="'week'+index"
        :label="item.label"
        :key="index"
        min-width="100px"
        align="center"
        header-align="center"
      >
        <template slot-scope="scope">
          <span v-if="changeName(scope.row,index) !== ''">
            <el-row>
              <el-col style="text-align:left;">
                {{ changeNum(scope,index) }}
                <span
                  style="color:#F98C3C"
                >{{changeDate(scope.row,index)}}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col style="text-align:left;">
                <span>{{changePositionName(scope.row,index)}}:{{changeName(scope.row,index)}}</span>
              </el-col>
              <el-col style="text-align:left;min-width: 100px;max-width:200px">
                <el-popover
                  v-if="getServiceItems(scope.row,index)!=''"
                  placement="right-start"
                  trigger="hover"
                  width="300"
                >
                  <div>{{getServiceItems(scope.row,index)}}</div>
                  <div
                    slot="reference"
                    style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;"
                  >{{getServiceItems(scope.row,index)}}</div>
                </el-popover>
                <div v-else>&nbsp;</div>
              </el-col>
              <el-col style="text-align:left;">
                <span v-if="changeDateScheduleCode(scope,index) !== '-1'">
                  <span v-if="copyBtn === false">
                    <el-button size="mini" @click="findSchedulingInfo(scope,index,1)">复制</el-button>
                  </span>
                  <el-button size="mini" @click="findSchedulingInfo(scope,index,2)">修改</el-button>
                  <el-button size="mini" @click="delDayScheduling(scope,index)">删除</el-button>
                </span>
              </el-col>
            </el-row>
          </span>
          <span v-else>
            <el-row>
              <el-col style="text-align:left;">{{ changeNum(scope,index) }}</el-col>
            </el-row>
            <el-row>
              <el-col>
                <br />
              </el-col>
              <el-col>
                <br />
              </el-col>
            </el-row>
          </span>
        </template>
      </el-table-column>
    </el-table>
    <div class="opt-area">
      <el-row class="importToolbar">
        <el-col>
          <el-form
            ref="schedulingForm"
            :inline="true"
            :model="schedulingForm"
            :rules="schedulingFormRules"
            label-width="100px"
          >
            <el-col class="form-item">
              <el-form-item label="日期" prop="schedlingWeek">
                <el-select
                  v-model="schedulingForm.schedlingWeek"
                  size="mini"
                  clearable
                  multiple
                  collapse-tags
                  :disabled="isSchedlingWeek"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in schedlingWeekOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务人员" prop="careGiverName">
                <el-autocomplete
                  :trigger-on-focus="true"
                  v-model="schedulingForm.careGiverName"
                  size="mini"
                  clearable
                  :fetch-suggestions="queryCareGiverName"
                  placeholder="请输入服务人员"
                  @select="selectCareGiverName"
                  @blur="removeCareGiverCode"
                  @clear="removeCareGiverCode"
                  style="width:250px"
                >
                  <template slot-scope="{ item }">
                    <span class="name">
                      {{ item.value }}
                      <span v-if="item.value != '无'">({{ item.staffTel }})({{ item.positionName }})</span>
                    </span>
                  </template>
                  <el-select
                    v-model="filterSelect"
                    slot="append"
                    @change="resetName"
                    style="width:75px;"
                    placeholder="请选择"
                  >
                    <el-option label="本组" value="10"></el-option>
                    <el-option label="跨组" value="20"></el-option>
                  </el-select>
                </el-autocomplete>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务岗位" prop="servicePositionCode">
                <el-radio-group v-model="schedulingForm.servicePositionCode">
                  <el-radio label="GW1911270089">护理员</el-radio>
                  <el-radio label="GW1911270063">护士</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col class="form-item" prop="planStartTime">
              <el-form-item label="开始时间" prop="planStartTime">
                <date-input ref="dateInputForm" :len="5" v-on:listenToChangeTime="changeTime"></date-input>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="服务时长" prop="planServiceDuration">
                <el-input
                  size="mini"
                  placeholder="请输入服务时长"
                  v-model="schedulingForm.planServiceDuration"
                  @blur="computeEndTime"
                >
                  <template slot="append">小时</template>
                </el-input>
              </el-form-item>
            </el-col>
            <el-col class="form-item">
              <el-form-item label="结束时间" prop="planEndTime">
                <el-time-picker
                  v-model="schedulingForm.planEndTime"
                  size="mini"
                  format="HH:mm"
                  value-format="HH:mm"
                  placeholder="根据开始时间计算"
                  :disabled="true"
                ></el-time-picker>
              </el-form-item>
            </el-col>
          </el-form>
          <el-col>
            <ScheduleServiceItemView
              ref="ScheduleServiceItemView"
              :orderCode="orderInfo.orderCode"
              @setWorkorderScheduleServiceList="setWorkorderScheduleServiceList"
            />
          </el-col>
          <el-col>
            <span class="footerBtn">
              <el-button @click="resetForm" size="mini">重 置</el-button>
              <el-button
                type="primary"
                style="margin-left:10px;"
                :disabled="saveDisabled"
                @click="setDayScheduling('schedulingForm')"
                size="mini"
              >保 存</el-button>
            </span>
          </el-col>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { selectGiverListForSchedule } from "api/common";
import DateInput from "components/DateInput";
import { validateServiceTime } from "utils/validate";
import {
  findWorkorderSchedule,
  addWorkorderSchedule,
  editWorkorderSchedule,
  deleteWorkorderSchedule
} from "api/businessService/orderPaymentReview";
import {
  batchAddWorkorderSchedule,
  editWorkorderScheduleDetail
} from "api/workOrderManagement";
import ScheduleServiceItemView from "@/views/businessService/widget/ScheduleServiceItemView";

export default {
  data() {
    return {
      //排程计划
      schedulingData: [],
      //周label
      weekLabel: [],
      //数据源
      data: [],
      //保存按钮是否禁用
      saveDisabled: false,
      //状态
      status: "",
      //查询条件
      filterSelect: "10",
      //当前已排程天数
      currentSchedulingCount: 0,
      //当期客户服务频次
      serviceFrequency: "",
      //排程计划
      schedulingForm: {
        orderCode: "",
        orgCode: "",
        orgName: "",
        careReceiverCode: "",
        careReceiverName: "",
        servicePositionCode: "GW1911270089",
        servicePositionName: "护理员",
        careGiverCode: "",
        careGiverName: "",
        CareGiverTel: "",
        serviceFrequencyType: "",
        planDay: "",
        planStartTime: "",
        planEndTime: "",
        planServiceDuration: "",
        isSign: "1",
        scheduleCode: "",
        schedlingWeek: []
      },
      schedulingFormRules: {
        schedlingWeek: [
          {
            required: true,
            message: "请选择日期",
            trigger: "change"
          }
        ],
        careGiverName: [
          {
            required: true,
            message: "请输入服务人员",
            trigger: "change"
          }
        ],
        planStartTime: [
          {
            required: true,
            message: "请选填开始时间",
            trigger: "input"
          }
        ],
        planServiceDuration: [
          {
            required: true,
            message: "请输入服务时长",
            trigger: "blur"
          },
          {
            validator: validateServiceTime
          }
        ]
      },
      //dialogTitle
      dialogTitle: "",
      //是否达到护理等级条数
      isAdd: true,
      //隐藏复制按钮
      copyBtn: false,
      //是否禁用日期
      isSchedlingWeek: false,
      //单次服务时长
      oneServiceTime: "",
      //姓名模糊
      careGiverFullNameList: [],
      //排班周期
      schedlingWeekOptions: [],
      workorderScheduleServiceList: [],
      showServiceItems: false
    };
  },
  props: {
    orderInfo: {
      type: Object,
      default: {}
    }
  },
  components: {
    DateInput,
    ScheduleServiceItemView
  },
  methods: {
    getServiceItems(row, index) {
      var item = JSON.parse(row["week" + index]);
      var serviceItems = "";
      if (item.workorderScheduleServiceList) {
        item.workorderScheduleServiceList.forEach((serviceItem, index) => {
          serviceItems +=
            serviceItem.serviceCode +
            (index != item.workorderScheduleServiceList.length - 1 ? "," : "");
        });
        if ("" == serviceItems) {
          return "";
        }
        return "服务项:" + serviceItems;
      }
      return serviceItems;
    },
    /**
     * 查询排程列表
     *
     */
    findWorkorderSchedule() {
      this.initWeekOptions();
      this.schedulingForm.planServiceDuration = this.$props.orderInfo.serviceDuration;
      this.serviceFrequency = parseInt(this.$props.orderInfo.serviceFrequency);
      this.data = [];
      let params = {
        orderCode: this.$props.orderInfo.orderCode,
        careReceiverCode: this.$props.orderInfo.careReceiverCode
      };
      findWorkorderSchedule(params)
        .then(response => {
          if (response.data.statusCode == 200) {
            this.data = response.data.responseData;
            //获取当前排程的条数
            this.currentSchedulingCount = this.data.length;
            var weekRecord = [];
            this.showServiceItems = false;
            for (let i = 0; i < this.data.length; i++) {
              this.data[i].planDay = this.data[i].planDay - 1;
              weekRecord[i] = this.data[i].planDay;
              if (
                this.data[i].workorderScheduleServiceList &&
                this.data[i].workorderScheduleServiceList.length > 0
              ) {
                this.showServiceItems = true;
              }
            }
            this.initWeekData(1);
            if (this.data.length >= this.serviceFrequency) {
              this.isAdd = false;
              this.copyBtn = true;
              this.schedlingWeekOptions = [];
            } else {
              this.isAdd = true;
              this.copyBtn = false;
              if (weekRecord.length > 0) {
                for (let i = 0; i < weekRecord.length; i++) {
                  for (let j = 0; j < this.schedlingWeekOptions.length; j++) {
                    if (weekRecord[i] == this.schedlingWeekOptions[j].value) {
                      this.schedlingWeekOptions.splice(j, 1);
                      continue;
                    }
                  }
                }
              }
            }
            this.$nextTick(() => {
              this.$refs["schedulingForm"].clearValidate();
            });
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findWorkorderSchedule:" + error);
          this.searchLoading = false;
        });
    },
    /*
     * 获取排班日期
     * @param weekCount:排班周数，int型
     */
    initWeekData(weekCount) {
      this.weekLabel = [];
      for (var i = 0; i < weekCount * 7; i++) {
        //日期转换星期
        this.weekLabel.push({
          label: "" //this.dateToDay(this.getDateData(i))
        });
      }

      this.schedulingData = [
        {
          week0: "",
          week1: "",
          week2: "",
          week3: "",
          week4: "",
          week5: "",
          week6: ""
        }
      ];

      for (let j = 0; j < 7; j++) {
        for (let k = 0; k < this.data.length; k++) {
          if (j == this.data[k].planDay) {
            this.schedulingData[0]["week" + j] = JSON.stringify(this.data[k]);
            break;
          }
        }
      }
    },
    /**
     * 获取排程信息
     */
    findSchedulingInfo(scope, index, status) {
      this.status = status;
      if (status == 2) {
        this.findWorkorderSchedule();
        var options = [];
        if (scope.row["week" + index]) {
          var item = JSON.parse(scope.row["week" + index]);
          if (item.workorderScheduleServiceList) {
            this.workorderScheduleServiceList =
              item.workorderScheduleServiceList;
            if (this.$refs["ScheduleServiceItemView"]) {
              this.$refs["ScheduleServiceItemView"].doSelectByParent(
                this.workorderScheduleServiceList
              );
            }
          }
          this.initWeekOptions();
          for (let i = 0; i < this.schedlingWeekOptions.length; i++) {
            if (this.schedlingWeekOptions[i].value == item.planDay.toString()) {
              options.push(this.schedlingWeekOptions[i]);
            }
          }
          this.schedlingWeekOptions = options;
          this.schedulingForm = {
            schedlingWeek: [item.planDay.toString()],
            orderCode: item.orderCode,
            orgCode: item.orgCode,
            orgName: item.orgName,
            careReceiverCode: item.careReceiverCode,
            careReceiverName: item.careReceiverName,
            servicePositionCode: item.servicePositionCode,
            servicePositionName: item.servicePositionName,
            careGiverCode: item.careGiverCode,
            careGiverName: item.careGiverName,
            CareGiverTel: "",
            serviceFrequencyType: item.serviceFrequencyType,
            planDay: item.planDay,
            planStartTime: item.planStartTime,
            planEndTime: item.planEndTime,
            planServiceDuration: item.planServiceDuration,
            scheduleCode: item.scheduleCode,
            isSign: item.isSign
          };
          this.$refs.dateInputForm.timeForm.startTime = this.schedulingForm.planStartTime;
          this.isSchedlingWeek = true;
          //强制手动渲染页面
          this.$forceUpdate();
        }
      } else {
        this.findWorkorderSchedule();
        if (scope.row["week" + index]) {
          var item = JSON.parse(scope.row["week" + index]);
          if (item.workorderScheduleServiceList) {
            this.workorderScheduleServiceList =
              item.workorderScheduleServiceList;
            if (this.$refs["ScheduleServiceItemView"]) {
              this.$refs["ScheduleServiceItemView"].doSelectByParent(
                this.workorderScheduleServiceList
              );
            }
          }
          this.schedulingForm = {
            schedlingWeek: [],
            orderCode: item.orderCode,
            orgCode: item.orgCode,
            orgName: item.orgName,
            careReceiverCode: item.careReceiverCode,
            careReceiverName: item.careReceiverName,
            servicePositionCode: item.servicePositionCode,
            servicePositionName: item.servicePositionName,
            careGiverCode: item.careGiverCode,
            careGiverName: item.careGiverName,
            CareGiverTel: "",
            serviceFrequencyType: item.serviceFrequencyType,
            planDay: "",
            planStartTime: item.planStartTime,
            planEndTime: item.planEndTime,
            planServiceDuration: item.planServiceDuration,
            scheduleCode: item.scheduleCode,
            isSign: item.isSign
          };
          this.$refs.dateInputForm.timeForm.startTime = this.schedulingForm.planStartTime;
          this.isSchedlingWeek = false;
        }
        this.$nextTick(() => {
          this.$refs["schedulingForm"].clearValidate();
        });
      }
    },
    /**
     * 新增/修改日排程
     */
    setDayScheduling(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$refs.dateInputForm.$refs.TimeForm.validate(valid => {
            if (valid) {
              if (this.saveDisabled == false) {
                this.saveDisabled = true;
                if (this.status == 2) {
                  var params = {
                    scheduleCode: this.schedulingForm.scheduleCode,
                    orderCode: this.schedulingForm.orderCode,
                    orgCode: this.schedulingForm.orgCode,
                    orgName: this.schedulingForm.orgName,
                    careReceiverCode: this.schedulingForm.careReceiverCode,
                    careReceiverName: this.schedulingForm.careReceiverName,
                    servicePositionCode: this.schedulingForm
                      .servicePositionCode,
                    servicePositionName:
                      this.schedulingForm.servicePositionCode == "GW1911270089"
                        ? "护理员"
                        : "护士",
                    careGiverCode: this.schedulingForm.careGiverCode,
                    careGiverName: this.schedulingForm.careGiverName,
                    careGiverTel: this.schedulingForm.careGiverTel,
                    serviceFrequencyType: this.schedulingForm
                      .serviceFrequencyType,
                    planDay: parseInt(this.schedulingForm.schedlingWeek) + 1,
                    planStartTime: this.schedulingForm.planStartTime,
                    planEndTime: this.schedulingForm.planEndTime,
                    planServiceDuration: this.schedulingForm
                      .planServiceDuration,
                    isSign: this.schedulingForm.isSign,
                    workorderScheduleServiceList: this
                      .workorderScheduleServiceList
                  };
                  editWorkorderScheduleDetail(params)
                    .then(response => {
                      if (response.data.statusCode == 200) {
                        this.$message.success("保存成功");
                        setTimeout(() => {
                          this.saveDisabled = false;
                        }, 500 * Math.random());
                        this.resetForm();
                        if (this.$refs["ScheduleServiceItemView"]) {
                          this.$refs["ScheduleServiceItemView"].clearSelect();
                          this.findWorkorderSchedule();
                        }
                      } else {
                        this.$message.error(response.data.statusMsg);
                        this.saveDisabled = false;
                        return false;
                      }
                    })
                    .catch(error => {
                      console.log("editWorkorderScheduleDetail:" + error);
                      this.saveDisabled = false;
                      this.searchLoading = false;
                    });
                } else {
                  var list = [];
                  var week = this.schedulingForm.schedlingWeek;
                  if (
                    parseInt(this.currentSchedulingCount) +
                      parseInt(week.length) >
                    this.serviceFrequency
                  ) {
                    this.$message.error("超出每周服务天数");
                    this.saveDisabled = false;
                    return false;
                  }
                  for (let i = 0; i < week.length; i++) {
                    list.push({
                      orderCode: this.$props.orderInfo.orderCode,
                      orgCode: this.$props.orderInfo.orgCode,
                      orgName: this.$props.orderInfo.orgName,
                      careReceiverCode: this.$props.orderInfo.careReceiverCode,
                      careReceiverName: this.$props.orderInfo.careReceiverName,
                      servicePositionCode: this.schedulingForm
                        .servicePositionCode,
                      servicePositionName:
                        this.schedulingForm.servicePositionCode ==
                        "GW1911270089"
                          ? "护理员"
                          : "护士",
                      careGiverCode: this.schedulingForm.careGiverCode,
                      careGiverName: this.schedulingForm.careGiverName,
                      careGiverTel: this.schedulingForm.careGiverTel,
                      serviceFrequencyType: this.$props.orderInfo
                        .serviceFrequencyType,
                      planDay: parseInt(week[i]) + 1,
                      planStartTime: this.schedulingForm.planStartTime,
                      planEndTime: this.schedulingForm.planEndTime,
                      planServiceDuration: this.schedulingForm
                        .planServiceDuration,
                      workorderScheduleServiceList: this
                        .workorderScheduleServiceList
                    });
                  }
                  var params = {
                    serviceFrequencyType: "10",
                    careReceiverCode: this.$props.orderInfo.careReceiverCode,
                    careGiverCode: this.schedulingForm.careGiverCode,
                    workorderScheduleInDtoList: list
                  };
                  batchAddWorkorderSchedule(params)
                    .then(response => {
                      if (response.data.statusCode == 200) {
                        this.$message.success("保存成功");
                        setTimeout(() => {
                          this.saveDisabled = false;
                        }, 500 * Math.random());
                        this.resetForm();
                        if (this.$refs["ScheduleServiceItemView"]) {
                          this.$refs["ScheduleServiceItemView"].clearSelect();
                          this.findWorkorderSchedule();
                        }
                      } else {
                        this.$message.error(response.data.statusMsg);
                        this.saveDisabled = false;
                        return false;
                      }
                    })
                    .catch(error => {
                      console.log("batchAddWorkorderSchedule:" + error);
                      this.saveDisabled = false;
                      this.searchLoading = false;
                    });
                }
              }
            } else {
              this.$message.error("请检查是否填写完整");
              return false;
            }
          });
        } else {
          this.$message.error("请检查是否填写完整");
          return false;
        }
      });
    },
    /**
     * 删除日排程
     */
    delDayScheduling(scope, index) {
      this.$confirm("确定要删除当前排程?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          if (scope.row["week" + index]) {
            var item = JSON.parse(scope.row["week" + index]);
            let params = {
              scheduleCode: item.scheduleCode
            };
            deleteWorkorderSchedule(params)
              .then(response => {
                if (response.data.statusCode == 200) {
                  this.$message.success("删除成功");
                  this.resetForm();
                  if (this.$refs["ScheduleServiceItemView"]) {
                    this.$refs["ScheduleServiceItemView"].clearSelect();
                  }
                } else {
                  this.$message.error(response.data.statusMsg);
                  return false;
                }
              })
              .catch(error => {
                console.log("deleteWorkorderSchedule:" + error);
                this.searchLoading = false;
              });
          }
        })
        .catch(() => {
          console.log("已取消删除");
        });
    },
    /**
     * 重置表单
     */
    resetForm() {
      this.isSchedlingWeek = false;
      this.schedulingForm = {
        orderCode: "",
        orgCode: "",
        orgName: "",
        careReceiverCode: "",
        careReceiverName: "",
        servicePositionCode: "GW1911270089",
        servicePositionName: "护理员",
        careGiverCode: "",
        careGiverName: "",
        CareGiverTel: "",
        serviceFrequencyType: "",
        planDay: "",
        planStartTime: "",
        planEndTime: "",
        planServiceDuration: "",
        scheduleCode: "",
        schedlingWeek: []
      };
      this.status = 1;
      this.$refs.dateInputForm.timeForm.startTime = "";
      this.findWorkorderSchedule();
      if (this.$refs["ScheduleServiceItemView"]) {
        this.$refs["ScheduleServiceItemView"].clearSelect();
      }
    },
    /**
     * 设置列表样式
     */
    tableRowClassName({ row, rowIndex }) {
      return "table-row";
    },
    //员工模糊查询
    selectCareGiverName(item) {
      if (item.value !== "无") {
        this.schedulingForm.careGiverCode = item.code;
        this.schedulingForm.careGiverName = item.value;
        this.schedulingForm.careGiverTel = item.staffTel;
      } else {
        this.schedulingForm.careGiverCode = "";
        this.schedulingForm.careGiverName = "";
      }
    },
    removeCareGiverCode() {
      this.schedulingForm.careGiverCode = "";
      this.schedulingForm.careGiverName = "";
    },
    queryCareGiverName(queryString, cb) {
      let params = {
        pageNum: 1,
        pageSize: 10,
        sideType: this.filterSelect,
        orgCode: this.$props.orderInfo.orgCode,
        staffFullName: queryString
      };
      selectGiverListForSchedule(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.careGiverFullNameList = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.careGiverFullNameList.push({
                value: data[i].staffFullName,
                code: data[i].staffCode,
                staffTel: data[i].staffTel,
                positionName: data[i].positionName
              });
            }
            var results = this.careGiverFullNameList;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findStaff:" + error);
          return false;
        });
    },
    //修改开始时间计算结束时间
    changeTime(sTime) {
      this.schedulingForm.planStartTime = sTime;
      if (
        this.schedulingForm.planServiceDuration != "" &&
        this.schedulingForm.planServiceDuration > 0
      ) {
        this.computeEndTime();
      } else {
        this.schedulingForm.planServiceDuration = "";
        return false;
      }
    },
    //计算结束时间
    computeEndTime() {
      if (parseFloat(this.schedulingForm.planServiceDuration) == 0) {
      }
      var pad = function(n, c) {
        if ((n = n + "").length < c) {
          return new Array(++c - n.length).join("0") + n;
        } else {
          return n;
        }
      };
      var startTime =
        parseInt(this.schedulingForm.planStartTime.split(":")[0]) * 60 +
        parseInt(this.schedulingForm.planStartTime.split(":")[1]);
      if (parseFloat(this.schedulingForm.planServiceDuration) >= 0) {
        var t = parseFloat(this.schedulingForm.planServiceDuration);
        t = t.toFixed(2);
        var time = t * 60;
        if (startTime + time > 1440) {
          // var newTime = startTime + time - 1440;
          // var h = Math.floor(newTime / 60);
          // var m = newTime % 60;
          // this.schedulingForm.planEndTime = pad(h, 2) + ":" + pad(m, 2);
          this.$message.error("请填选正确的时长，服务结束时间不能跨天");
          this.schedulingForm.planServiceDuration = "";
          this.schedulingForm.planEndTime = "";
          return false;
        } else {
          var h = Math.floor((startTime + time) / 60);
          var m = Math.floor((startTime + time) % 60);
          this.schedulingForm.planEndTime = pad(h, 2) + ":" + pad(m, 2);
          if (this.schedulingForm.planEndTime == "24:00") {
            this.schedulingForm.planEndTime = "23:59";
          }
          this.$refs["schedulingForm"].validateField("planStartTime");
        }
      } else {
        this.$message.error("请输入正确的时长");
        this.schedulingForm.planServiceDuration = "";
        return false;
      }
    },
    isShowImg(data, prop) {
      if (data[0][prop]) {
        var item = JSON.parse(data[0][prop]);
        if (item) {
          return "";
        }
      } else {
        return "tableBackImg";
      }
    },
    changeName(row, index) {
      if (row["week" + index]) {
        var data = JSON.parse(row["week" + index]);
        return data.careGiverName;
      } else {
        return "";
      }
    },
    changePositionName(row, index) {
      if (row["week" + index]) {
        var data = JSON.parse(row["week" + index]);
        return data.servicePositionName;
      } else {
        return "";
      }
    },
    changeDate(row, index) {
      if (row["week" + index]) {
        var data = JSON.parse(row["week" + index]);
        return data.planStartTime + "-" + data.planEndTime;
      }
    },
    changeNum(scope, index) {
      if (scope.$index * 7 + index + 1 == 1) {
        return "周一";
      } else if (scope.$index * 7 + index + 1 == 2) {
        return "周二";
      } else if (scope.$index * 7 + index + 1 == 3) {
        return "周三";
      } else if (scope.$index * 7 + index + 1 == 4) {
        return "周四";
      } else if (scope.$index * 7 + index + 1 == 5) {
        return "周五";
      } else if (scope.$index * 7 + index + 1 == 6) {
        return "周六";
      } else if (scope.$index * 7 + index + 1 == 7) {
        return "周日";
      }
    },
    changeDateScheduleCode(scope, index) {
      if (scope.row["week" + index]) {
        var data = JSON.parse(scope.row["week" + index]);
        return data.scheduleCode;
      } else {
        return "-1";
      }
    },
    resetName() {
      this.schedulingForm.careGiverName = "";
    },
    initWeekOptions() {
      this.schedlingWeekOptions = [
        {
          label: "周一",
          value: "0"
        },
        {
          label: "周二",
          value: "1"
        },
        {
          label: "周三",
          value: "2"
        },
        {
          label: "周四",
          value: "3"
        },
        {
          label: "周五",
          value: "4"
        },
        {
          label: "周六",
          value: "5"
        },
        {
          label: "周日",
          value: "6"
        }
      ];
    },
    setWorkorderScheduleServiceList(list) {
      this.workorderScheduleServiceList = list;
    }
  },
  mounted() {
    this.findWorkorderSchedule();
  }
};
</script>

<style lang="scss" scoped>
#tableScheduling {
  padding: 10px 10px;
}

.el-time-picker {
  width: 200px;
}
.el-select {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.el-input {
  width: 200px;
}
.importToolbar {
  padding: 20px 0px 10px 0px;
}
.form-item {
  width: 30%;
  min-width: 400px;
}
.footerBtn {
  display: table;
  margin: 0px auto;
}
</style>

<style lang="scss">
#tableScheduling {
  .el-form-item__error {
    padding-top: 0px;
  }
  .el-date-editor--daterange.el-input__inner {
    width: 250px;
  }

  .el-table .table-row {
    height: 100px;
  }

  .el-form-item__content .el-input-group {
    vertical-align: unset;
  }

  .el-button + .el-button {
    margin-left: 0px;
  }
}

.form-item {
  height: 50px;
}

.el-autocomplete-suggestion {
  min-width: 250px;
}

.el-autocomplete-suggestion__wrap {
  min-width: 250px;
}
.opt-area {
  border-left: 1px solid #e0e6eb;
  border-right: 1px solid #e0e6eb;
  border-bottom: 1px solid #e0e6eb;
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}
</style>