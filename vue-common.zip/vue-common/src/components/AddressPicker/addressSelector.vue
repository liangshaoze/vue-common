<template>
  <div>
    <el-row class="mainContainer">
      <el-col :span="8" class="address_select">
        <el-select size="mini" v-model="provinceName" placeholder="请选择省" @change="selectProvince">
          <el-option
            v-for="item in provinces"
            :key="item.id"
            :label="item.name"
            :value="item.name"
          />
        </el-select>
      </el-col>
      <el-col :span="8" class="address_select">
        <el-select
          size="mini"
          v-model="cityName"
          placeholder="请选择市"
          @change="selectCity"
          :disabled="cityDisable"
        >
          <el-option v-for="item in cities" :key="item.id" :label="item.name" :value="item.name" />
        </el-select>
      </el-col>
      <el-col :span="8" class="address_select">
        <el-select
          size="mini"
          v-model="districtName"
          placeholder="请选择区"
          @change="selectDistrict"
          :disabled="districtDisable"
        >
          <el-option v-for="item in districts" :key="item.id" :label="item.name" :value="item.name"></el-option>
        </el-select>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { findAddressDictList } from "@/api/common/index.js";
export default {
  data() {
    return {
      provinces: [],
      cities: [],
      districts: [],
      provinceName: "",
      cityName: "",
      cityDisable: true,
      districtName: "",
      districtDisable: true,
      flag: false
    };
  },
  props: {
    address: {
      type: Object,
      default: {
        pCode: "",
        cCode: "",
        dCode: ""
      }
    }
  },
  methods: {
    selectProvince(val) {
      var obj = {};
      obj = this.provinces.find(item => {
        return item.name === val;
      });
      this.provinceName = obj.name;
      this.cityName = "";
      this.districtName = "";
      this.cities = [];
      this.districts = [];
      this.cityDisable = false;
      this.$emit("selectedProvinceListener", obj);
      this.getAddressDictListByPid(obj.id, 1);
    },
    selectCity(val) {
      var obj = {};
      obj = this.cities.find(item => {
        return item.name === val;
      });
      this.cityName = obj.name;
      this.districtName = "";
      this.districts = [];
      this.districtDisable = false;
      this.$emit("selectedCityListener", obj);
      this.getAddressDictListByPid(obj.id, 2);
    },
    selectDistrict(val) {
      var obj = {};
      obj = this.districts.find(item => {
        return item.name === val;
      });
      this.districtName = obj.name;
      this.$emit("selectedDistrictListener", obj);
    },
    getAddressDictListByPid(pid, dictType) {
      let params = { pid: pid };
      findAddressDictList(params).then(response => {
        if (response.data.statusCode == 200) {
          switch (dictType) {
            case 0: //省
              this.provinces = response.data.responseData;
              var findResult = this.provinces.find(item => {
                return item.id === this.address.pCode;
              });
              if (findResult != undefined) {
                this.provinceName = findResult.name;
                this.cityDisable = false;
              }
              break;
            case 1: //市
              this.cities = response.data.responseData;
              var findResult = this.cities.find(item => {
                return item.id === this.address.cCode;
              });
              if (findResult != undefined) {
                this.cityName = findResult.name;
                this.districtDisable = false;
              }
              break;
            case 2: //区
              this.districts = response.data.responseData;
              var findResult = this.districts.find(item => {
                return item.id === this.address.dCode;
              });
              if (findResult != undefined) {
                this.districtName = findResult.name;
              }
              break;
          }
        }
      });
    }
  },
  created() {
    this.$watch("address", function() {
      if (this.flag == false) {
        this.getAddressDictListByPid(0, 0);
        if (this.address !== undefined) {
          if (this.address.pCode !== undefined) {
            this.getAddressDictListByPid(this.address.pCode, 1);
          }
        }
        if (this.address !== undefined) {
          if (this.address.cCode !== undefined) {
            this.getAddressDictListByPid(this.address.cCode, 2);
          }
        }
        this.flag = true
      }
    });
  }
};
</script>
<style>
.address_select {
  display: flex;
  justify-content: center;
}

.mainContainer {
  display: block;
  line-height: 40px;
}
</style>