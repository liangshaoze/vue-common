<template>
  <div>
    <el-form ref="TimeForm" :rules="timeFormRules" :model="timeForm" v-if="needValidForm">
      <el-form-item>
        <el-input
          id="dateinput"
          v-model="timeForm.startTime"
          size="mini"
          :maxlength="len"
          clearable
          @clear="clearInput"
          @change="computedTime"
          @click.native="focueInput"
          :placeholder="placeholder"
        ></el-input>
      </el-form-item>
    </el-form>
    <el-input
          id="dateinput"
          v-model="timeForm.startTime"
          size="mini"
          :maxlength="len"
          @change="computedTime"
          @click.native="focueInput"
          :placeholder="placeholder"
          v-if="!needValidForm"
        ></el-input>
  </div>
</template>

<script>
//引入jquery
import '@/utils/jquery/js/jquery.min.js'
import timePacker from 'utils/jquery/js/timePacker.js'
export default {
  data() {
    return {
      timeForm: {
        startTime: ""
      },
      timeFormRules: {
        startTime: [
          {
            required: true,
            message: "请输入开始时间",
            trigger: "blur"
          }
        ]
      }
    };
  },
  props: {
    //提示语
    placeholder: {
      type: String,
      default: "请输入开始时间"
    },
    //限制长度
    len: {
      type: Number,
      default: 5
    },
    initValue:{
      type:String,
      default:""
    },
    needValidForm:{
      type:Boolean,
      default:true
    }
  },
  methods: {
    computedTime() {
      this.timeForm.startTime = $("#dateinput").val();
      let reg = /^(0[0-9]|1[0-9]|2[0-3])(\:?)(0[0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])$/; //时间格式
      if (reg.test(this.timeForm.startTime)) {
        if(this.needValidForm){
          this.$refs.TimeForm.validateField("startTime");
        }
        if (this.timeForm.startTime.indexOf(":") != -1) {
          //包含冒号的
          this.$emit("listenToChangeTime", this.timeForm.startTime);
        } else {
          //不包含冒号的
          var time = this.timeForm.startTime.toString();
          time = time.substring(0, 2) + ":" + time.substring(2, time.length);
          this.timeForm.startTime = time;
          this.$emit("listenToChangeTime", this.timeForm.startTime);
        }
      } else {
        //提示输入格式不正确
        this.$message.error(
          "请输入正确的时间格式，例如（0930、09:30、1330、13:30）"
        );
        this.timeForm.startTime = "";
        return false;
      }
    },
    focueInput(event) {
      var el = document.getElementById("dateinput")
      timePacker($("#dateinput"),event,el)
    },
    clearInput(){
      this.timeForm.startTime = "";
      this.$emit("listenToChangeTime", this.timeForm.startTime);
    }
  },
  mounted(){
    this.$nextTick(()=>{
      this.timeForm.startTime = this.$props.initValue;
    })
  },
  created() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
</style>
