<template>
  <div id="tableUpload">
    <el-upload
      :class="{showUl:hideUpload}"
      :action="action"
      :limit="limit"
      :multiple="multiple"
      :on-exceed="handleExceed"
      :on-success="handleSuccess"
      :on-error="handleError"
      :on-remove="handleRemove"
      :before-upload="beforeUpload"
      :before-remove="beforeRemove"
      :on-change="handleChange"
      :file-list="fileList"
      :accept="accept"
    >
      <el-button size="small" type="primary">点击上传</el-button>
      <div slot="tip" class="el-upload__tip">只能上传<span>{{acceptDesc}}</span>文件，且不超过10M</div>
    </el-upload>
  </div>
</template>

<script>
export default {
  name: "tableUpload",
  data() {
    return {
      hideUpload: false
    };
  },
  props: {
    //是否多文件上传
    multiple: {
      type: Boolean,
      default: false
    },
    //文件限制数量
    limit: {
      type: Number,
      default: 10
    },
    //上传地址
    action: {
      type: String,
      default: ""
    },
    //文件
    fileList: {
      type: Array,
      default: []
    },
    //当前行操作的下标值
     indexLine:{
      type: Number,
      default: 0
    },
    //上传文件限制
    accept: {
      type: String,
      default: "image/jpeg,image/gif,image/png"
    },
    //上传描述
    acceptDesc: {
      type: String,
      default: "jpeg/gif/png"
    }
  },
  methods: {
    //上传限制
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 1 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    //上传文件之前
    beforeUpload(file) {
      var isType = this.accept.indexOf(file.type);
      var flag = false;
      if (isType == -1) {
        flag = true;
      }
      var isLt10M = file.size / 1024 / 1024 < 10;

      if (flag) {
        console.log(this.fileList);
        this.$message.error("上传文件格式有误!");
        return false;
      } else {
        if (!isLt10M) {
          this.$message.error("上传文件大小不能超过 10MB!");
          return false;
        } else {
          return true;
        }
      }
    },
    //上传成功
    handleSuccess(res, file, fileList,indexLine) {
      if (res.responseData != null) {
        console.log(this.$props.indexLine)
        this.$emit("handleGetUrl", res.responseData, file, fileList,this.$props.indexLine);
        this.$message.success("上传成功");
      }
    },
    //上传变更
    handleChange(file, fileList) {
      this.hideUpload = fileList.length >= this.limit;
    },
    //上传失败
    handleError(res, file, fileList) {
      this.$message.error("上传服务器请求失败");
    },
    //文件删除
    handleRemove(file, fileList,indexLine) {
      this.$emit("handleRemoveList",file, fileList,this.$props.indexLine);
      this.hideUpload = fileList.length >= this.limit;
    },
    //文件删除前
    beforeRemove(file, fileList) {
      var isType = null;
      var flag = false;
      if (file.raw) {
        isType = this.accept.indexOf(file.raw.type);
        if (isType == -1) {
          flag = true;
        }
      }
      if (flag) {
        fileList.splice(fileList.length - 1, 1);
        return false;
      } else {
        return this.$confirm(`确定移除 ${file.name}？`, "提示");
      }
    }
  },
  watch :{
    // fileList(){
    //   this.hideUpload = this.fileList.length == 0?false : true
    // }
  }
};
</script>

<style lang="scss">
#tableUpload .hideUl {
  display: none;
}
#tableUpload .showUl {
  margin-top: -40px;
  width: 200px;
}
</style>