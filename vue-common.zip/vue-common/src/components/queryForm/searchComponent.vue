<!-- 搜索表单 -->
<template>
  <div class="queryToolbar">
    <el-form :size="size" inline :label-width="labelWidth">
      <el-form-item v-for="item in searchForm" :label="item.label" :key="item.prop">
        <!-- 输入框 -->
        <el-input
          v-if="item.type==='Input'"
          v-model="searchData[item.prop]"
          :placeholder="item.placeholder"
          :clearable="item.clearable"
        ></el-input>
        <!-- 下拉框 -->
        <el-select
          v-if="item.type==='Select'"
          v-model="searchData[item.prop]"
          @visible-change="item.load()"
          @change="item.change(searchData[item.prop])"
          :placeholder="item.placeholder"
          :clearable="item.clearable"
        >
          <el-option v-for="op in item.options" :label="op.label" :value="op.value" :key="op.value"></el-option>
        </el-select>
        <!-- 日期 -->
        <el-date-picker
          v-if="item.type==='Date'"
          v-model="searchData[item.prop]"
          :clearable="item.clearable"
        ></el-date-picker>
        <!-- 日期时间 -->
        <el-date-picker
          v-if="item.type==='Daterange'"
          type="daterange"
          v-model="searchData[item.prop]"
          :value-format="item.valueFormat"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :clearable="item.clearable"
        ></el-date-picker>
      </el-form-item>
      <el-form-item v-for="item in searchHandle" :key="item.label">
        <el-button
          :style="{marginLeft:item.marginLeft}"
          :type="item.type"
          :icon="item.icon"
          :size="item.size || size"
          @click="item.handle()"
        >{{item.label}}</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  props: {
    //laebl宽度
    labelWidth: {
      type: String,
      default: "100px"
    },
    //按钮大小
    size: {
      type: String,
      default: "middle"
    },
    //Form字段
    searchData: {
      type: Object,
      default: {}
    },
    //Form字段属性
    searchForm: {
      type: Array,
      default: []
    },
    //Form按钮
    searchHandle: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {};
  }
};
</script>