<template>
  <div id="fileUpload">
    <el-upload
      :class="{hideBrief:hideUpload}"
      list-type="picture-card"
      :action="action"
      :http-request="myUpload"
      :limit="limit"
      :multiple="multiple"
      :on-exceed="handleExceed"
      :on-success="handleSuccess"
      :on-error="handleError"
      :before-upload="beforeUpload"
      :before-remove="beforeRemove"
      :file-list="fileList"
      :accept="accept"
      :on-change="onChange"
      :on-remove="handleRemove"
    >
      <div class="add-file">
        <i class="el-icon-plus"></i>
        <div style="margin-top:5px">仅限上传{{limit}}个图片或视频!</div>
      </div>
      <div slot="file" slot-scope="{file}">
        <span v-if="file.type == 'img'">
          <img class="el-upload-list__item-thumbnail" :src="file.url" alt />
        </span>
        <span v-else-if="file.type == 'vedio'">
          <video width="100" height="100" id="upvideo"></video>
        </span>
        <span v-else>
          <img class="el-upload-list__item-thumbnail" :src="file.url" alt />
        </span>
        <span class="el-upload-list__item-actions">
          <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
            <i class="el-icon-zoom-in"></i>
          </span>
          <span class="el-upload-list__item-delete" @click="handleDownload(file)">
            <i class="el-icon-download"></i>
          </span>
          <span v-if="isEdit" class="el-upload-list__item-delete" @click="handleRemove(file)">
            <i class="el-icon-delete"></i>
          </span>
        </span>
      </div>
    </el-upload>
    <el-dialog :visible.sync="visible">
      <span v-if="dialogImageUrl">
        <el-image style="width: 100%; height: 600px" :src="dialogImageUrl"></el-image>
      </span>
      <span v-if="dialogVedioUrl">
        <video
          width="100%"
          height="600"
          :src="dialogVedioUrl"
          class="avatar"
          controls="controls"
        >您的浏览器不支持视频播放</video>
      </span>
    </el-dialog>
    <span v-if="fileList.length > 0">
      <div v-for="file in fileList">
        <el-tooltip class="itemToptip" effect="dark" :content="file.name" placement="bottom">
          <div>{{file.name}}</div>
        </el-tooltip>
      </div>
    </span>
  </div>
</template>

<script>
import axios from "axios";
import { getImageUploadParams } from "api/common";

export default {
  name: "fileUpload",
  data() {
    return {
      //指定图片格式
      imgFormat: "image/jpeg,image/gif,image/png",
      vedioFormat: "video/mp4,video/avi,video/rmvb,video/flv",
      //文件类型
      imgType: "jpg,jpeg,png,gif",
      vedioType: "mp4,avi,rmvb,flv",
      //图片上传
      dialogImageUrl: "",
      dialogVedioUrl: "",
      visible: false,
      fileUploadParams: null,
      uploadSuccessUrl:"",
      fileListInView:[],
    };
  },
  props: {
    //是否多文件上传
    multiple: {
      type: Boolean,
      default: false,
    },
    //文件限制数量
    limit: {
      type: Number,
      default: 10,
    },
    //上传地址
    action: {
      type: String,
      default: "",
    },
    //文件
    fileList: {
      type: Array,
      default: [],
    },
    //上传文件限制
    accept: {
      type: String,
      default: "image/jpeg,image/gif,image/png",
    },
    //是否隐藏上传
    hideUpload: {
      type: Boolean,
      default: true,
    },
    //是否编辑
    isEdit: {
      type: Boolean,
      default: true,
    },
  },
  mounted(){
    this.getOSSParams();
  },
  methods: {
    myUpload(content) {
      if (!this.fileUploadParams) {
        content.onError("文件上传失败，无效上传路径");
        return;
      }
      this.uploadSuccessUrl = this.fileUploadParams.dir + "/"+this.getFileName(content.file.name);
      let formData = new FormData();
      formData.append("key", this.uploadSuccessUrl);
      formData.append("policy", this.fileUploadParams.policy);
      formData.append("signature", this.fileUploadParams.signature);
      formData.append("OSSAccessKeyId", this.fileUploadParams.accessid);
      formData.append("file", content.file);
      this.axios({
        method: "post",
        url: this.fileUploadParams.host,
        timeout: 60000,
        data: formData,
      })
        .then((res) => {
          const url = this.fileUploadParams.host + '/'+this.uploadSuccessUrl;
          this.fileList.push({
            name:this.getFileNameWithUrl(this.uploadSuccessUrl),
            url :url,
          })
          if (res.status) {
            content.onSuccess(url);
          } else {
            content.onError("文件上传失败，请求异常");
          }
          this.$forceUpdate();
        })
        .catch((error) => {
          debugger
          if (error.response) {
            content.onError(
              "文件上传失败(" +
                error.response.status +
                ")，" +
                error.response.data
            );
          } else if (error.request) {
            content.onError("文件上传失败，服务器端无响应");
          } else {
            content.onError("文件上传失败，请求异常");
          }
        });
    },
    //上传文件之前
    beforeUpload(file) {
      //是否是指定格式的文件
      var isType = this.accept.indexOf(file.type);
      var flag = false;
      if (isType == -1) {
        flag = true;
      }
      var isLt10M = file.size / 1024 / 1024 < 10; //限制大小10M
      var isLt30M = file.size / 1024 / 1024 < 30; //限制大小30M

      if (flag) {
        this.$message.error("上传文件格式有误!");
        return false;
      } else {
        if (this.imgFormat.indexOf(file.type) !== -1) {
          if (!isLt10M) {
            this.$message.error("上传文件大小不能超过 10MB!");
            return false;
          } else {
            return true;
          }
        } else if (this.vedioFormat.indexOf(file.type) !== -1) {
          if (!isLt30M) {
            this.$message.error("上传文件大小不能超过 30MB!");
            return false;
          } else {
            return true;
          }
        }
      }
    },
    //上传限制
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 ` +
          this.$props.limit +
          ` 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
            files.length + fileList.length
          } 个文件`
      );
    },
    //上传成功
    handleSuccess(res, file, fileList) {
      this.fileListInView = fileList;
      if (res != null) {
        this.$message.success("文件上传成功");
      }
    },
    //上传失败
    handleError(res, file, fileList) {
      this.$message.error(res);
      return false;
    },
    //文件删除
    handleRemove(file, fileList) {
      for(var i=0;i<this.fileList.length;i++){
        if(this.fileList[i].url == file.response){
          this.fileList.splice(i,1);
          this.fileListInView.splice(this.fileListInView.indexOf(file),1);
          this.$forceUpdate()
          break;
        }
      }
    },
    //文件删除前
    beforeRemove(file, fileList) {
      debugger
      var isType = null;
      var flag = false;
      if (file.raw) {
        isType = this.accept.indexOf(file.raw.type);
        if (isType == -1) {
          flag = true;
        }
      }
      if (flag) {
        fileList.splice(fileList.length - 1, 1);
        return false;
        // } else {
        //   return this.$confirm(`确定移除 ${file.name}？`, "提示");
      }
    },
    onChange(file,fileList){
      console.log(file)
      debugger
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = "";
      this.dialogVedioUrl = "";
      var f = file.name.substring(file.name.indexOf(".") + 1, file.name.length);
      if (this.imgType.indexOf(f) !== -1) {
        this.dialogImageUrl = file.url;
      } else if (this.vedioType.indexOf(f) !== -1) {
        this.dialogVedioUrl = file.url;
      }
      this.visible = true;
    },
    handleDownload(file) {
      window.open(file.url, "_blank");
    },
    // 查询图片上传参数
    getOSSParams() {
      getImageUploadParams({
        dir: "20",
      })
        .then((res) => {
          if (res.data.statusCode == 200) {
            this.fileUploadParams = res.data.responseData || null;
          }
        })
        .catch((error) => {});
    },
    //  图片文件名称
    getFileName(name) {
      //去掉文件后缀
      var fileName = name||"file"
      fileName=fileName.substring(0,fileName.indexOf("."))
      return fileName +"_"+new Date().getTime();
    },
     //  图片文件名称
    getFileNameWithUrl(url) {
      let temp = url.split('/')
      return temp[temp.length - 1]
    },
  },
};
</script>

<style lang="scss" scoped>
.el-upload__tip {
  text-align: left;
  width: 130px;
  line-height: 15px;
}
.itemToptip {
  position: relative;
  font-size: 12px;
  width: 135px;
  height: 30px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  float: left;
  margin-top: -15px;
  line-height: 30px;
  padding: 5px;
}
</style>
<style lang="scss">
#fileUpload {
  .hideBrief .el-upload--picture-card {
    display: none;
  }
  // .el-upload--picture-card {
  //   width: 100px;
  //   height: 100px;
  //   line-height: 100px;
  // }
  // .el-upload-list--picture-card .el-upload-list__item-actions:hover span {
  //   display: contents;
  // }
  // .el-upload-list--picture-card .el-upload-list__item {
  //   width: 100px;
  //   height: 100px;
  // }
  .add-file{
    height:130px;
    line-height:1.5;
    align-items: center;
    padding-top: 30px;
  }
}
</style>