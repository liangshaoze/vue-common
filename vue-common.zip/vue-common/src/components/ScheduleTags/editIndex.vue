<template>
	<div>
		<!-- <span style="color:#5ea8fa;cursor:pointer" @click="showAddPanel=true" v-if="addEnable==true">添加排程时间>></span>
		<span style="color:#999999;" v-if="addEnable==false">添加排程时间>></span>-->
		<div>
			<el-form label-width="150px">
				<el-form-item class="workOrderClass" label="服务开始时间" :rules="[{required:true}]">
					<el-row type="flex" justify="center">
						<!-- 新增服务时间 -->
						<el-select
							v-if="isEdit==false"
							v-model="addTag.planDays"
							size="mini"
							multiple
							collapse-tags
							clearable
							placeholder="请选择日期"
							style="width:130px;margin-right:5px;margin-top:1px"
							@change="selectTag"
						>
							<el-option
								v-for="item in schedlingDayOptions"
								:key="item.planDay"
								:label="item.planDayStr"
								:value="item.planDay"
								:disabled="item.disabled"
							></el-option>
						</el-select>
						<!-- 编辑服务时间 -->
						<el-select
							v-if="isEdit==true"
							v-model="addTag.planDay"
							size="mini"
							collapse-tags
							clearable
							placeholder="请选择日期"
							style="width:130px;margin-right:5px;;margin-top:1px"
						>
							<el-option
								v-for="item in schedlingDayOptions"
								:key="item.planDay"
								:label="item.planDayStr"
								:value="item.planDay"
								:disabled="item.disabled"
							></el-option>
						</el-select>
						<date-input
							ref="dateInputForm"
							:len="5"
							@listenToChangeTime="changeEndTime"
							:initValue="addTag.planStartTime"
							:needValidForm="false"
						></date-input>
						<!-- <el-time-picker
                  v-model="addTag.planStartTime"
                  size="mini"
                  format="HH:mm"
                  value-format="HH:mm"
                  :picker-options="{
                    start: '00:00',
                    step: '00:01',
                    end: '24:00'
                  }"
                  @blur="changeEndTime(addTag)"
                  placeholder="开始时间"
                  style="width:120px"
						></el-time-picker>-->
					</el-row>
				</el-form-item>
				<el-form-item class="workOrderClass" label="服务时长" :rules="[{required:true}]">
					<el-input
						size="mini"
						v-model="addTag.planServiceDuration"
						@input="computeEndTime(addTag)"
						placeholder="请输入服务时长"
						clearable
						style="margin-top:5px"
					>
						<template slot="append">小时</template>
					</el-input>
				</el-form-item>
				<el-form-item class="workOrderClass" label="服务结束时间" :rules="[{required:true}]">
					<el-input size="mini" v-model="addTag.planEndTime" :disabled="true" placeholder="根据开始时间计算"></el-input>
					<!-- <el-button
						v-if="!isEdit"
						size="small"
						@click="confirmAdd"
						type="primary"
						style="margin-left:5px"
					>添加</el-button>-->
				</el-form-item>
				<el-form-item class="workOrderClass" label="服务项" :rules="[{required:false}]">
					<el-select
						v-model="addTag.serviceItems"
						multiple
						filterable
						remote
						size="mini"
						placeholder="请输入服务项关键词"
						:remote-method="remoteMethod"
						:loading="loading"
						@focus="selectService"
					>
						<el-option
							v-for="item in serviceOptions"
							:key="item.value"
							:label="item.label"
							:value="item.value"
						></el-option>
					</el-select>
					<el-button
						size="small"
						v-if="!isEdit"
						@click="confirmAdd"
						type="primary"
						style="margin-left:5px"
					>添加</el-button>
				</el-form-item>
			</el-form>
			<div>
				<el-tag
					v-for="(tag,index) in dynamicTags"
					:key="index"
					style="margin-top:10px;margin-left:10px;width:120px;height:60px;"
					closable
					:disable-transitions="false"
					@close="handleClose(tag)"
				>
					<span
						style="font-weight:bold;display: block"
					>{{getDayStr(tag)}}{{tag.planStartTime}}~{{tag.planEndTime}}</span>
					<span style="font-weight:bold;">{{getServices(tag.serviceItems)}}</span>
				</el-tag>
			</div>
		</div>
	</div>
</template>
<script>
import { getServiceCountByGrade } from 'utils/AssessGradeUtils'
import {
	findWorkorderSchedule,
	selectProductOrderServiceList
} from "api/businessService/orderPaymentReview";
import DateInput from "components/DateInput";
export default {
	components: {
		DateInput
	},
	props: {
		careReceiver: {
			type: Object,
			default: function () {
				return {
					value: "",//careReceiverName
					code: "",//careReceiverCode
					careReceiverTel: "",
					orderCode: "",
					orgCode: "",
					orgName: "",
					serviceFrequencyType: ""
				}
			}
		},
		formStaffWorkOrder: {
			type: Object,
			default: function () {
				return {
					productCode: "",
					careReceiverCode: "",
					productName: "", //产品名称
					careReceiverName: "", //客户姓名
					orgCode: "",
					orgName: "",
					orderCode: "",
					planDay: "",
					planServiceDuration: "",
					planEndDate: "",
					servicePositionCode: "GW1911270089",
					servicePositionName: "护理员",
					careGiverCode: "",
					careGiverName: "",
					workorderScheduleServiceList: []
				}
			}
		},
		isEdit: {
			type: Boolean,
			default: false
		},
		serviceDuration: {
			type: String,
			default: ""
		}
	},
	data () {
		return {
			dynamicTags: [],
			inputVisible: false,
			inputValue: "",
			multiSelectValues: [],
			addTag: {
				planDay: "",
				planDays: [],
				planServiceDuration: "",
				planStartTime: "",
				planEndTime: "",
				serviceItems: [],//服务项
			},
			//排班周期
			schedlingDayOptions: [],
			addPopVisible: true,//排程时间添加是否可见
			isWeek: true,
			showAddPanel: true,
			addEnable: false,
			dayRecord: [],
			serviceOptions: [
			],
			serviceList: [],
			serviceInDtoList: [],
			loading: false,

		};
	},
	methods: {
		handleClose (tag) {
			this.schedlingDayOptions.push({ planDay: tag.planDay, planDayStr: this.isWeek ? this.getWeekStrWithIndex(tag.planDay) : tag.planDay })
			this.schedlingDayOptions.sort(this.sortCompare())
			this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1);
			this.schedlingDayOptions.forEach(item => {
				item.disabled = false;
			})
		},

		showInput () {
			this.inputVisible = true;
			this.$nextTick(_ => {
				this.$refs.saveTagInput.$refs.input.focus();
			});
		},

		handleInputConfirm () {
			let inputValue = this.inputValue;
			if (inputValue) {
				this.dynamicTags.push(inputValue);
			}
			this.inputVisible = false;
			this.inputValue = "";
		},
		//修改开始时间计算结束时间
		changeEndTime (sTime) {
			this.addTag.planStartTime = sTime;
			if (
				this.addTag.planServiceDuration != "" &&
				this.addTag.planServiceDuration > 0
			) {
				this.computeEndTime(this.addTag);
			} else {
				this.addTag.planServiceDuration = "";
				return false;
			}
		},
		//计算结束时间
		computeEndTime (tag) {
			tag.planEndTime = "";
			if (!tag.planStartTime) {
				return;
			}
			if (tag.planServiceDuration == "") {
				return;
			}
			var pad = function (n, c) {
				if ((n = n + "").length < c) {
					return new Array(++c - n.length).join("0") + n;
				} else {
					return n;
				}
			};
			var startTime =
				parseInt(tag.planStartTime.split(":")[0]) * 60 +
				parseInt(tag.planStartTime.split(":")[1]);
			if (parseFloat(tag.planServiceDuration) >= 0) {
				var t = parseFloat(tag.planServiceDuration);
				t = t.toFixed(2);
				var time = t * 60;
				if (startTime + time > 1440) {
					this.$message.error("请输入正确的时长，服务结束时间不能跨天");
					tag.planServiceDuration = "";
					tag.planEndTime = "";
					return false;
				} else {
					var h = Math.floor((startTime + time) / 60);
					var m = Math.floor((startTime + time) % 60);
					tag.planEndTime = pad(h, 2) + ":" + pad(m, 2);
					if (tag.planEndTime == "24:00") {
						tag.planEndTime = "23:59"
					}
				}
			} else {
				this.$message.error("请输入正确的时长");
				tag.planServiceDuration = "";
				return false;
			}
		},
		confirmAdd () {
			if (this.addTag.planDays.length == 0) {
				this.$message.error("请选择日期")
				return
			}
			if (this.addTag.planStartTime == 0) {
				this.$message.error("请选择开始时间")
				return
			}
			if (this.addTag.planServiceDuration == 0) {
				this.$message.error("请输入服务时长")
				return
			}
			this.addPopVisible = false;
			this.addTag.planDays.forEach(item => {
				var tempTag = JSON.parse(JSON.stringify(this.addTag));
				tempTag.planDayStr = this.isWeek ? this.getWeekStrWithIndex(item) : item;
				tempTag.planDay = item;
				this.schedlingDayOptions.forEach(day => {
					if (day.planDay == item) {
						this.schedlingDayOptions.splice(this.schedlingDayOptions.indexOf(day), 1);
					}
				})
				this.dynamicTags.push(tempTag);
			})
			this.dynamicTags.sort(this.sortCompare())//排序
			this.addTag.planDays = [];
			this.addTag.planStartTime = "";
			this.addTag.planEndTime = "";
			this.addTag.serviceItems = [];
			this.$refs["dateInputForm"].clearInput();
		},
		getWeekStrWithIndex (index) {
			if (index == 1) {
				return "周一";
			} else if (index == 2) {
				return "周二";
			} else if (index == 3) {
				return "周三";
			} else if (index == 4) {
				return "周四";
			} else if (index == 5) {
				return "周五";
			} else if (index == 6) {
				return "周六";
			} else if (index == 7) {
				return "周日";
			}
		},
		findWorkorderSchedule () {
			let params = {
				orderCode: this.$props.careReceiver.orderCode,
				careReceiverCode: this.$props.careReceiver.code
			};
			findWorkorderSchedule(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.data = response.data.responseData;
						this.dayRecord = [];
						var dayCount = this.isWeek ? 7 : 31;
						var dayArr = [];
						for (let i = 1; i <= dayCount; i++) {
							dayArr.push({
								planDayStr: this.isWeek ? this.getWeekStrWithIndex(i) : i + '日',
								planDay: i,
								disabled: false
							})
						}
						for (let i = 0; i < this.data.length; i++) {
							this.data[i].planDay = this.data[i].planDay;
							this.dayRecord[i] = this.data[i].planDay;
							var day = dayArr.find((item) => {
								return item.planDay == this.data[i].planDay;
							})
							if (day) {
								dayArr.splice(dayArr.indexOf(day), 1);
							}
							// if (this.isEdit) {
							// 	if (this.data[i].workorderScheduleServiceList) {
							// 		for (let j = 0; j < this.data[i].workorderScheduleServiceList.length; i++) {
							// 			this.addTag.serviceItems.push(
							// 				this.data[i].workorderScheduleServiceList[j].serviceCode 

							// 				// this.data[i].workorderScheduleServiceList[j].serviceItem
							// 			)
							// 		}
							// 	}
							// }

						}
						if (!this.isEdit) {
							if (this.dayRecord.length >= this.$props.careReceiver.serviceFrequency) {
								this.addEnable = false;
								this.schedlingDayOptions = [];
								this.$message.error(this.$props.careReceiver.value + "排程已排满，不需再新增排程哦~");
							} else {
								this.addEnable = true;
								this.schedlingDayOptions = dayArr;
							}
						} else {
							this.schedlingDayOptions = dayArr;
							this.schedlingDayOptions.push({
								planDayStr: this.isWeek ? this.getWeekStrWithIndex(this.addTag.planDay) : this.addTag.planDay + '日',
								planDay: this.addTag.planDay,
								disabled: false
							})//添加当天
							this.schedlingDayOptions.sort(this.sortCompare())
						}

						if (this.addEnable) {
							this.dynamicTags = [];
						} else {
							this.showAddPanel = true;
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					// this.$message.error(this.ConstantData.requestErrorMsg)
					this.searchLoading = false;
				});
		},
		getAddSchedules () {
			var workorderScheduleInDtoList = [];
			this.dynamicTags.forEach(item => {
				//服务项组装
				this.$props.formStaffWorkOrder.servicePositionName = this.$props.formStaffWorkOrder.servicePositionCode == "GW1911270089" ? "护理员" : "护士";
				this.$props.formStaffWorkOrder.planDay = item.planDay,
					this.$props.formStaffWorkOrder.planStartTime = item.planStartTime,
					this.$props.formStaffWorkOrder.planEndTime = item.planEndTime,
					this.$props.formStaffWorkOrder.planServiceDuration = item.planServiceDuration
				if (item.serviceItems.length > 0) {
					this.$props.formStaffWorkOrder.workorderScheduleServiceList = []
					let list = item.serviceItems
					for (let i = 0; i < list.length; i++) {
						for (let k = 0; k < this.serviceInDtoList.length; k++) {
							if (list[i] === this.serviceInDtoList[k].serviceCode) {
								this.$props.formStaffWorkOrder.workorderScheduleServiceList.push({
									serviceClass: this.serviceInDtoList[k].serviceClass,
									serviceFrequency: this.serviceInDtoList[k].serviceFrequency,
									serviceFrequencyUnit: this.serviceInDtoList[k].serviceFrequencyUnit,
									serviceDuration: this.serviceInDtoList[k].serviceDuration,
									serviceDurationUnit: this.serviceInDtoList[k].serviceDurationUnit,
									serviceContent: this.serviceInDtoList[k].serviceContent,
									serviceSort: this.serviceInDtoList[k].serviceSort,
									orderCode: this.serviceInDtoList[k].orderCode,
									serviceCode: this.serviceInDtoList[k].serviceCode,
									serviceItem: this.serviceInDtoList[k].serviceItem,
								})
								break;
							}
						}
					}
				}
				workorderScheduleInDtoList.push(
					JSON.parse(JSON.stringify(this.$props.formStaffWorkOrder)),
				);
			})
			return workorderScheduleInDtoList;
		},
		sortCompare () {
			var compare = function (obj1, obj2) {
				var val1 = obj1.planDay;
				var val2 = obj2.planDay;
				if (val1 < val2) {
					return -1;
				} else if (val1 > val2) {
					return 1;
				} else {
					return 0;
				}
			}
			return compare;
		},
		resetData () {
			this.dynamicTags = [];
			this.showAddPanel = false;
			this.addEnable = false;
		},
		getDayStr (tag) {
			if (this.isWeek) {
				return tag.planDayStr;
			} else {
				return tag.planDayStr > 9 ? tag.planDayStr : ('0' + tag.planDayStr);
			}
		},
		getServices (tag) {
			let serviceStr = ''
			if (tag.length > 0) {
				for (let i = 0; i < tag.length; i++) {
					serviceStr += tag[i] + ","
				}
				if (serviceStr.length > 0) {
					serviceStr = serviceStr.substr(0, serviceStr.length - 1);
				}
				return "服务项:" + serviceStr
			}
		},
		selectTag () {
			var selectedCount = this.addTag.planDays.length + this.dynamicTags.length + this.dayRecord.length;
			if (selectedCount == this.$props.careReceiver.serviceFrequency) {
				for (let i = 0; i < this.schedlingDayOptions.length; i++) {
					this.schedlingDayOptions[i].disabled = true;
					for (let k = 0; k < this.addTag.planDays.length; k++) {
						if (this.addTag.planDays[k] == this.schedlingDayOptions[i].planDay) {
							this.schedlingDayOptions[i].disabled = false;
						}
					}
				}
			} else {
				this.schedlingDayOptions.forEach(item => {
					item.disabled = false;
				})
			}
		},
		getUpdatedData () {
			return this.addTag;
		},
		setServiceDuration (serviceDuration) {
			this.resetData();
			this.addTag.planServiceDuration = serviceDuration;
			this.addTag.planDays = [];
			this.computeEndTime(this.addTag)
		},
		/* 服务项 */
		selectProductOrderServiceList () {
			let params = {
				orderCode: this.$props.careReceiver.orderCode,
			};
			selectProductOrderServiceList(params)
				.then(response => {
					if (
						response.data.statusCode === 200 ||
						response.data.statusCode === "200"
					) {
						if (response.data.responseData) {
							this.serviceInDtoList = response.data.responseData
							let list = response.data.responseData
							if (list.length > 0) {
								this.serviceList = list.map(item => {
									return {
										value: `${item.serviceCode}`,
										label: `${item.serviceCode}${item.serviceItem}`,
									}
								})
							}
						}
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {

					return false;
				});

		},
		/* 服务项 */
		selectService () {
			if (this.serviceList.length == 0) {
				this.$message.error('请先选择被照护人')
				return false
			} else {
				this.serviceOptions = this.serviceList
			}
		},
		remoteMethod (queryString) {
			if (queryString !== '') {
				this.loading = true;
				setTimeout(() => {
					this.loading = false;
					this.serviceOptions = this.serviceList.filter(item => {
						return item.label.toLowerCase()
							.indexOf(queryString.toLowerCase()) > -1;
					});
				}, 200);
			} else {
				this.serviceOptions = [];
			}
		},
	},
	created () { },
	mounted () {
		this.$watch("careReceiver", function () {
			if (this.careReceiver && !this.isEdit) {
				this.isWeek = this.careReceiver.serviceFrequencyType == "10";
				this.findWorkorderSchedule();
				this.selectProductOrderServiceList()//获取服务项
			}
		})
		if (this.isEdit) {
			this.isWeek = this.careReceiver.serviceFrequencyType == "10";
			this.addTag.planDay = this.careReceiver.planDay;
			this.addTag.planStartTime = this.careReceiver.planStartTime;
			this.addTag.planServiceDuration = this.careReceiver.planServiceDuration;
			this.addTag.planEndTime = this.careReceiver.planEndTime;
			this.findWorkorderSchedule();
		}
		//开始时间设置宽度
		document.getElementById("dateinput").style.cssText = "width:120px"
	},
	activated () {

	}
};
</script>
<style scoped>
.el-tag + .el-tag {
	margin-left: 10px;
}
.button-new-tag {
	margin-left: 10px;
	height: 32px;
	line-height: 30px;
	padding-top: 0;
	padding-bottom: 0;
}
.input-new-tag {
	width: 90px;
	margin-left: 10px;
	vertical-align: bottom;
}
.workOrderClass {
	margin-bottom: 0;
	padding-top: 5px;
}
.el-input {
	width: 200px;
}
.el-select {
	width: 200px;
}
.el-autocomplete {
	width: 200px;
}
.el-select__input {
	vertical-align: baseline;
}
</style>
