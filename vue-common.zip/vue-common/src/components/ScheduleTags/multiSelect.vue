<template>
  <div style="height:300px">
    <el-row type="flow">
      <el-col v-for="(tag,index) in tagList" :key="index" style="margin:5px;width:125px">
        <el-tag 
        :color="tag.isSelect?'#7ee':'#fff'"
        :closable ="tag.doneAdd"
        style="width:125px;cursor:pointer"
         @click="selectTag(tag)"
         @close="handleClose(tag)"
         >
         {{tag.planStartDate}} {{tag.planStartTime}}{{tag.planEndTime!=""?"~":""}}{{tag.planEndTime}}
         </el-tag>
      </el-col>
    </el-row>
    <el-form
        label-width="150px"
      >
        <el-form-item class="workOrderClass" label="服务开始时间">
                <el-time-picker
                  v-model="currentSelectTag.planStartTime"
                  size="mini"
                  format="HH:mm"
                  value-format="HH:mm"
                  :picker-options="{
                    start: '00:00',
                    step: '00:01',
                    end: '24:00'
                  }"
                  @blur="changeEndTime"
                  placeholder="请选择开始时间"
                  @change="changeStartTime"
                ></el-time-picker>
        </el-form-item>
        <el-form-item class="workOrderClass" label="服务时长" prop="planServiceDuration">
          <el-input
            size="mini"
            v-model="currentSelectTag.planServiceDuration"
            @input="computeEndTime"
            placeholder="请输入服务时长"
            clearable
          >
            <template slot="append">小时</template>
          </el-input>
        </el-form-item>
        <el-form-item class="workOrderClass" label="服务结束时间">
          <el-input
            size="mini"
            v-model="currentSelectTag.planEndTime"
            :disabled="true"
            placeholder="根据开始时间计算"
          ></el-input>
        </el-form-item>
      </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      dayCount:7,
      dynamicTags: [{
        planStartDate: "周一",
        planServiceDuration: "2",
        planEndDate: "周一",
        planStartTime:"08:35",
        planEndTime:"09:30"
      },
      {
        planStartDate: "周二",
        planServiceDuration: "2",
        planEndDate: "周二",
        planStartTime:"08:35",
        planEndTime:"09:30"
      }],
      inputVisible: false,
      inputValue: "",
      multiSelectValues:[],
      //排班周期
      schedlingWeekOptions: [
        {
          label: "周一",
          value: "0"
        },
        {
          label: "周二",
          value: "1"
        },
        {
          label: "周三",
          value: "2"
        },
        {
          label: "周四",
          value: "3"
        },
        {
          label: "周五",
          value: "4"
        },
        {
          label: "周六",
          value: "5"
        },
        {
          label: "周日",
          value: "6"
        }
      ],
      addPopVisible:true,//排程时间添加是否可见
      tagList:[],
      currentSelectTag:{
        planStartDate: "",
        planServiceDuration: "",
        planStartTime:"",
        planEndTime:"",
        isSelect:false
      }
    };
  },
  methods: {
    setTagList(){
      for(let i = 0;i<this.dayCount;i++){
        var tag ={
          planStartDate: this.dayCount==7?this.getWeekStrWithIndex(i):(i+1),
          planServiceDuration: "",
          planStartTime:"",
          planEndTime:"",
          isSelect:false,
          doneAdd:false
        }
        this.tagList[i]=tag;
      }
    },
    handleClose(tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1);
    },

    showInput() {
      this.inputVisible = true;
      this.$nextTick(_ => {
        this.$refs.saveTagInput.$refs.input.focus();
      });
    },

    handleInputConfirm() {
      let inputValue = this.inputValue;
      if (inputValue) {
        this.dynamicTags.push(inputValue);
      }
      this.inputVisible = false;
      this.inputValue = "";
    },
    //修改开始时间计算结束时间
    changeEndTime() {
      if (
        this.currentSelectTag.planServiceDuration != "" &&
        this.currentSelectTag.planServiceDuration > 0
      ) {
        this.computeEndTime();
      } else {
        this.currentSelectTag.planServiceDuration = "";
        return false;
      }
    },
    //计算结束时间
    computeEndTime() {
      if (parseFloat(this.currentSelectTag.planServiceDuration) == 0) {
      }
      var pad = function(n, c) {
        if ((n = n + "").length < c) {
          return new Array(++c - n.length).join("0") + n;
        } else {
          return n;
        }
      };
      var startTime =
        parseInt(this.currentSelectTag.planStartTime.split(":")[0]) * 60 +
        parseInt(this.currentSelectTag.planStartTime.split(":")[1]);
      if (parseFloat(this.currentSelectTag.planServiceDuration) >= 0) {
        var t = parseFloat(this.currentSelectTag.planServiceDuration);
        t = t.toFixed(2);
        var time = t * 60;
        if (startTime + time > 1440) {
          var newTime = startTime + time - 1440;
          var h = Math.floor(newTime / 60);
          var m = newTime % 60;
          this.currentSelectTag.planEndTime = pad(h, 2) + ":" + pad(m, 2);
        } else {
          var h = Math.floor((startTime + time) / 60);
          var m = Math.floor((startTime + time) % 60);
          this.currentSelectTag.planEndTime = pad(h, 2) + ":" + pad(m, 2);
        }
         this.tagList.forEach(item=>{
          if(item.isSelect){//被选中且未设置时间
            item.planStartTime = this.currentSelectTag.planStartTime;
            item.planEndTime =  this.currentSelectTag.planEndTime;
            item.planServiceDuration = this.currentSelectTag.planServiceDuration;
            item.doneAdd = true;
          }
        })
        this.$forceUpdate();
      } else {
        this.$message.error("请输入正确的时长");
        this.currentSelectTag.planServiceDuration = "";
        this.currentSelectTag.planEndTime = "";
        this.currentSelectTag.doneAdd = false;
        this.$forceUpdate();
        return false;
      }
    },
    getWeekStrWithIndex(index) {
      if (index == 0) {
        return "周一";
      } else if (index == 1) {
        return "周二";
      } else if (index == 2) {
        return "周三";
      } else if (index == 3) {
        return "周四";
      } else if (index == 4) {
        return "周五";
      } else if (index == 5) {
        return "周六";
      } else if (index == 6) {
        return "周日";
      }
    },
    selectTag(tag){
      if(tag.doneAdd){//修改
        this.currentSelectTag = tag;
        //取消选择
        this.tagList.forEach(item=>{
            item.isSelect = false;
        })
        tag.isSelect = true;
        this.$forceUpdate()
        return;
      }
        this.tagList.forEach(item=>{
            if(item.doneAdd){//已设置了的取消选择
              item.isSelect = false;
            }
        })
      tag.isSelect = !tag.isSelect;
      this.currentSelectTag = JSON.parse(JSON.stringify(tag));
      this.$forceUpdate()
    },
    changeStartTime(val){
      this.currentSelectTag.planStartTime = val;
      this.tagList.forEach(item=>{
        if(item.isSelect&&!item.doneAdd){//被选中且未设置时间
          item.planStartTime = val;
        }
      })
      this.$forceUpdate();
    },
    handleClose(tag){
      tag.planStartTime = "";
      tag.planServiceDuration ="";
      tag.isSelect = false;
      tag.doneAdd = false;
      tag.planEndTime = "";
      this.$forceUpdate();
    }
  },
  created() {
    this.dayCount = 31;
    this.setTagList();
  },
  mounted() {}
};
</script>
<style scoped>
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
.workOrderClass {
  margin-top: 15px;
  margin-bottom: 0;
}
.el-input {
		width: 200px;
	}
	.el-select {
		width: 200px;
	}
	.el-autocomplete {
		width: 200px;
	}
</style>
