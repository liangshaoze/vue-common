<!--通用选择，支持模糊查询-->
<template>
  <div>
    <!-- <el-form-item
          :label="fuzzyItem.propertyName"
          :prop="productPropertyList[(index+1)*2-2].propertyName"
          :rules="fuzzyItem.isInput == 1 ? [{required: true, message: fuzzyItem.propertyName+'不能为空'}] : null"
        > -->
    <el-select
      filterable
      size="mini"
      clearable
      remote
      :placeholder="'请输入'+fuzzyItem.propertyName"
      :remote-method="remoteMethodCommon"
      v-model="resultItem.propertyValueId"
      @change="changeFuzzySearchValue"
      v-if="filterable"
      class="nomal-select"
    >
      <el-option
        v-for="item in searchedNameOptions"
        :key="item.propertyValueId"
        :label="item.propertyValue"
        :value="item.propertyValueId"
      ></el-option>
    </el-select>
    <el-select
      size="mini"
      clearable
      :placeholder="'请选择'+fuzzyItem.propertyName"
      v-model="resultItem.propertyValueId"
      @change="changeFuzzyName"
      v-if="!filterable&&!multiple"
      class="nomal-select"
    >
      <el-option
        v-for="item in searchedNameOptions"
        :key="item.propertyValueId"
        :label="item.propertyValue"
        :value="item.propertyValueId"
      ></el-option>
    </el-select>
    <el-select
      size="mini"
      multiple
      collapse-tags
      :placeholder="'请选择' + fuzzyItem.propertyName"
      v-model="multiSelectValues"
      @change="changeFuzzyNameMulti"
      v-if ="multiple"
      class = "multi-select"
    >
      <el-option
        v-for="item in searchedNameOptions"
        :key="item.propertyValueId"
        :label="item.propertyValue"
        :value="item.propertyValueId"
      ></el-option>
    </el-select>
    <!-- </el-form-item> -->
  </div>
</template>

<script>
import { findEtProductPropertyValueList } from "api/common/index.js";
export default {
  props: {
    fuzzyItem: {
      type: Object,
      default: function(){
        return {
          productCode: "",
          propertyType: "",
          propertyName: "",
          propertySort: "",
          displayType: "",
          isInput: "",
          productPropertyValueList: [],
          propertyId: ""
        }
      }
    },
    fuzzySelectedList: {
      //已选择过的属性
      type: Array,
      default: function(){
        return [];
      }
    },
    filterable: {
      type: Boolean,
      default: false
    },
    multiple:{
      type:Boolean,
      default:false
    },
    resultItem:{
      type:Object,
      default:function(){
        return {
          productCode: "",
          propertyId: "",
          propertyName: "",
          propertyValue: "",
          valueSort: 1,
          propertyValueId: ""
        };
      }
    }
  },

  data() {
    return {
      searchedNameOptions: [],
      multiSelectValues:[]
    };
  },
  methods: {
    remoteMethodCommon(query) {
      var params = {
        productCode: this.fuzzyItem.productCode,
        propertyId: this.fuzzyItem.propertyId,
        propertyValue: query,
        pageSize: "100",
        pageNum: "1"
      };
      findEtProductPropertyValueList(params).then(response => {
        if (response.data.statusCode == "200") {
          this.searchedNameOptions = response.data.responseData;
        }
      });
    },
    changeFuzzyName(val) {
      var obj = {}
      obj = this.searchedNameOptions.find(item =>{
        return item.propertyValueId == val;
      });
      for(var i=0;i<this.fuzzySelectedList.length;i++){
        if(obj){
          if(obj.propertyId == this.fuzzySelectedList[i].propertyId){
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].propertyValueId = obj.propertyValueId;
            this.fuzzySelectedList[i].propertyValue =  obj.propertyValue;
            break;
          }
        }else if(val == "" || val == undefined){
          if(this.fuzzyItem.propertyId == this.fuzzySelectedList[i].propertyId){
            this.fuzzySelectedList[i].propertyValueId = "";
            this.fuzzySelectedList[i].propertyValue = "";
            break;
          }
        }
        }
    },
    changeFuzzyNameMulti(val) {
      //由多个id筛选出名称的集合
      var names = "";
      val.forEach(idItem =>{
      var obj = this.searchedNameOptions.find(item => {
        return item.propertyValueId == idItem;
      });
      if(obj){
        names+=obj.propertyValue+",";//拼接
      }
      })
      if(this.searchedNameOptions.length>0){
        names = names.substr(0,names.length-1)//去除最后的逗号
        var tempObj = JSON.parse(JSON.stringify(this.searchedNameOptions[0]));//取第一个
        tempObj.propertyValue = names;//改变名字
          for (var i = 0; i < this.fuzzySelectedList.length; i++) {
            if (tempObj.propertyId == this.fuzzySelectedList[i].propertyId) {
              this.fuzzySelectedList[i].propertyValueId = ""+val;
              this.fuzzySelectedList[i].propertyValue =  names;
              break;
            }
          }
      }
    },
    changeFuzzySearchValue(val) {
      var obj = {}
      obj = this.searchedNameOptions.find(item =>{
        return item.propertyValueId == val;
      });
        for(var i=0;i<this.fuzzySelectedList.length;i++){
        if(obj){
          if(obj.propertyId == this.fuzzySelectedList[i].propertyId){
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].propertyValueId = obj.propertyValueId;
            this.fuzzySelectedList[i].propertyValue =  obj.propertyValue;
            break;
          }
        }else if(val == "" || val == undefined){
          if(this.fuzzyItem.propertyId == this.fuzzySelectedList[i].propertyId){
            this.fuzzySelectedList[i].propertyValueId = "";
            this.fuzzySelectedList[i].propertyValue = "";
            break;
          }
        }
        }
    },
    updateUI(){
      this.searchedNameOptions = [];
      if (!this.filterable && !this.multiple) {
        this.searchedNameOptions = this.fuzzyItem.productPropertyValueList;
        this.changeFuzzyName(this.resultItem.propertyValueId);
      }
    if(this.filterable){
      this.resultItem.propertyValueId = this.resultItem.propertyValue;
      // this.changeFuzzySearchValue(this.resultItem.propertyValueId)
    }
    if(this.multiple){
      this.multiSelectValues = []
      this.searchedNameOptions = this.fuzzyItem.productPropertyValueList;
      var values = this.resultItem.propertyValue;
      var names = [];
      if(values){
         names = values.split(",");
         names.forEach(nameItem=>{
           var idObj = this.searchedNameOptions.find(item =>{
             return nameItem == item.propertyValue;
           })
           if(idObj){
              this.multiSelectValues.push(idObj.propertyValueId)
            }
         })
         this.changeFuzzyNameMulti(this.multiSelectValues);
      }
    }
    }
  },
  mounted() {
    
  },created(){
    this.$nextTick(()=>{
        this.updateUI();
    })
    this.$watch("fuzzyItem",()=>{
      this.updateUI();
    })
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss">
.multi-select{
  width: 200px;
}
.nomal-select{
  width: 200px;
}
.el-select__tags-text{
  font-size: 11px;
}
</style>