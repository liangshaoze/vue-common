<!--通用单选组-->
<template>
  <div>
        <el-radio-group size="mini" v-model="resultItem[baseItem.propertyFieldName]">
          <el-radio v-for="item in selectOptions" 
          :key="item[baseItem.optionKeyFieldName]" 
          :label="item[baseItem.optionKeyFieldName]">{{item[baseItem.optionValueFieldName]}}</el-radio>
        </el-radio-group>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function(){
        return {
          propertyFieldName: "",//属性字段名
          propertyName: "",//属性名称
          propertyValue:"",//属性值
          options: [],//可选项的集合
          optionKeyFieldName:"",//可选项值对应的key的字段名
          optionValueFieldName:"",//可选项值对应的value的字段名
          valueSetCode:"",//值集代码
          propertyType:"",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框
          queryMethod:""//获取选项值列表的方法名称
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },

  data() {
    return {
      selectOptions: [],
    };
  },
  methods: {
    updateUI(){
      this.selectOptions = [];
        if(this.baseItem.options&&this.baseItem.options.length>0){
          this.selectOptions = this.baseItem.options;
        }
      this.initOptions();
    },
    initOptions(){
      if(this.baseItem.queryMethod){
          this.$emit("queryMethod",this.baseItem)
        return;
      }
      if(this.baseItem.valueSetCode){
        findValueBySetCode({ valueSetCode: this.baseItem.valueSetCode })
        .then(response => {
          if (response.data.statusCode == 200) {
            this.selectOptions = response.data.responseData;
          }
        })
        .catch(error => {
          console.log("findValueBySetCode:"+this.baseItem.valueSetCode+":" + error);
          return false;
        });
      }
    }
  },
  mounted() {
    
  },created(){
    this.$nextTick(()=>{
        this.updateUI();
    })
    this.$watch("baseItem",()=>{
      this.updateUI();
    })
    this.$watch("baseItem.options",()=>{
      this.selectOptions = [];
      if (!this.filterable && !this.multiple) {
        if(this.baseItem.options&&this.baseItem.options.length>0){
          this.selectOptions = this.baseItem.options;
        }
      }
    })
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss">
.multi-select{
  width: 200px;
}
.nomal-select{
  width: 200px;
}
.el-select__tags-text{
  font-size: 11px;
}
</style>