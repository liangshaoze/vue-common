<template>
  <div>
    <el-radio-group v-model="resultItem.propertyValueId">
    <span v-for="r in searchedNameOptions" :key="r.propertyValueId">
    <el-radio style="margin-right: 10px" :label="r.propertyValueId" @change="changeFuzzyName">{{r.propertyValue}}</el-radio>
    </span>
  </el-radio-group>
  </div>
</template>

<script>
export default {
  props: {
    fuzzyItem:{
      type:Object,
      default:function(){
        return {
          productCode: "",
          propertyType: "",
          propertyName: "",
          propertySort: "",
          displayType: "",
          isInput: "",
          productPropertyValueList: [],
          propertyId: ""
        };
      }
    },
    fuzzySelectedList:{//已选择过的属性
      type:Array,
      default:function(){
        return []
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {
          productCode: "",
          propertyId: "",
          propertyName: "",
          propertyValue: "",
          valueSort: 1,
          propertyValueId: ""
        };
      }
    }
  },

  data() {
    return {
      searchedNameOptions: [],
    };
  },
  methods: {
    changeFuzzyName(val) {
      var obj = {}
      obj = this.searchedNameOptions.find(item =>{
        return item.propertyValueId == val;
      });
      for(var i=0;i<this.fuzzySelectedList.length;i++){
        if(obj){
          if(obj.propertyId == this.fuzzySelectedList[i].propertyId){
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].propertyValueId = obj.propertyValueId;
            this.fuzzySelectedList[i].propertyValue =  obj.propertyValue;
            break;
          }
        }else if(val == "" || val == undefined){
          if(this.fuzzyItem.propertyId == this.fuzzySelectedList[i].propertyId){
            this.fuzzySelectedList[i].propertyValueId = "";
            this.fuzzySelectedList[i].propertyValue = "";
            break;
          }
        }
        }
    }
  },
  mounted() {
     this.$nextTick(()=>{
        this.searchedNameOptions = this.fuzzyItem.productPropertyValueList;
        this.changeFuzzyName(this.resultItem.propertyValueId)
    })
  },
  created(){
    this.$watch("fuzzyItem",()=>{
      this.searchedNameOptions = this.fuzzyItem.productPropertyValueList;
      this.changeFuzzyName(this.resultItem.propertyValueId)
    })
  }
};
</script>

<style lang="scss" scoped>
.el-radio-group{
  width: 300px;
}
</style>