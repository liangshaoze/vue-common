<!--通用多选自动远程搜索-->
<template>
    <div id="auto_complete">
      <el-select
								v-model="resultItem[baseItem.propertyFieldName]"
								multiple
								filterable
								remote
								:placeholder="'请输入'+baseItem.propertyName"
								:remote-method="remoteMethodCommon"
								collapse-tags
								@change="selectedPropertyValue"
								size="mini"
                clearable
                @focus="focusChange"
                :style="baseItem.style"
							>
								<el-option
									v-for="item in selectOptions"
									:key="item.value"
									:label="item.label"
									:value="item.value"
								></el-option>
							</el-select>

  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function(){
        return {
          propertyFieldName: "",//属性字段名
          propertyName: "",//属性名称
          propertyValue:"",//属性值
          options: [],//可选项的集合
          optionKeyFieldName:"",//可选项值对应的key的字段名
          optionValueFieldName:"",//可选项值对应的value的字段名
          valueSetCode:"",//值集代码
          propertyType:"",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框
          queryMethod:""//获取选项值列表的方法名称
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },

  data() {
    return {
      selectOptions: [],
    };
  },
  methods: {
    remoteMethodCommon(query,cb) {
      if(this.baseItem.queryMethod){
          this.$emit("queryMethod",this.baseItem,query,cb)
      }
    },
    selectedPropertyValue(list) {
      if(list.length>0){
        this.resultItem[this.baseItem.propertyFieldName] = list;
      }else{
        this.resultItem[this.baseItem.propertyFieldName]= [];
      }
      this.$forceUpdate()
    },
    clearPropertyValue(){
     this.resultItem[this.baseItem.propertyFieldName]= [];
    this.$forceUpdate()
    },
    updateUI(){
      this.selectOptions = [];
        if(this.baseItem.options&&this.baseItem.options.length>0){
          this.selectOptions = this.baseItem.options;
        }
      this.initOptions();
    },
    initOptions(){
      if(this.baseItem.queryMethod){
          this.$emit("queryMethod",this.baseItem)
        return;
      }
    },
    focusChange(){
      if(this.resultItem[this.baseItem.propertyFieldName].length==0){
        this.remoteMethodCommon("");
      }
    }
  },
  mounted() {
    
  },created(){
    this.$nextTick(()=>{
        this.updateUI();
    })
    this.$watch("baseItem",()=>{
      this.updateUI();
    })
    this.$watch("baseItem.options",()=>{
      this.selectOptions = [];
        if(this.baseItem.options&&this.baseItem.options.length>0){
          this.selectOptions = this.baseItem.options;
        }
    })
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss">
// .multi-select{
//   width: 200px;
// }
// .nomal-select{
//   width: 200px;
// }
// .el-select__tags-text{
//   font-size: 11px;
// }
// #auto_complete .el-autocomplete {
//   width: 200px;
// }
</style>