<!--通用选择，支持模糊查询-->
<template>
  <div id="auto_complete">
    <el-autocomplete
      :trigger-on-focus="true"
      v-model="resultItem.propertyValue"
      size="mini"
      clearable
      :fetch-suggestions="remoteMethodCommon"
      :placeholder="'请输入'+fuzzyItem.propertyName"
      @select="changeFuzzySearchValue"
      @blur="clearPropertyValueId"
    ></el-autocomplete>
  </div>
</template>

<script>
import { findEtProductPropertyValueList } from "api/common/index.js";
export default {
  props: {
    fuzzyItem: {
      type: Object,
      default: function(){
        return {
        productCode: "",
        propertyType: "",
        propertyName: "",
        propertySort: "",
        displayType: "",
        isInput: "",
        productPropertyValueList: [],
        propertyId: ""
        };
      }
     
    },
    fuzzySelectedList: {
      //已选择过的属性
      type: Array,
      default: function(){
        return [];
      }
    },
    resultItem: {
      type: Object,
      default:function(){
        return {
          productCode: "",
          propertyId: "",
          propertyName: "",
          propertyValue: "",
          valueSort: 1,
          propertyValueId: ""
        };
      } 
    }
  },

  data() {
    return {
      searchedNameOptions: [],
    };
  },
  methods: {
    remoteMethodCommon(query,cb) {
      var params = {
        productCode: this.fuzzyItem.productCode,
        propertyId: this.fuzzyItem.propertyId,
        propertyValue: query,
        pageSize: "10",
        pageNum: "1"
      };
      findEtProductPropertyValueList(params).then(response => {
        if (response.data.statusCode == "200") {
          this.searchedNameOptions = [];
          let data = response.data.responseData;
          for (let i = 0; data && i < data.length; i++) {
              this.searchedNameOptions.push({
                value: data[i].propertyValue,
                code: data[i].propertyValueId
              });
            }
            if (this.searchedNameOptions.length === 0) {
              this.searchedNameOptions = [{ value: "无", code: "-1" }];
            }
          cb(this.searchedNameOptions)
        }
      });
    },
    changeFuzzySearchValue(val) {
      if (val.value == "无") {
        return;
      }
      for (var i = 0; i < this.fuzzySelectedList.length; i++) {
        if (val) {
          if (this.fuzzyItem.propertyId == this.fuzzySelectedList[i].propertyId) {
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].propertyValueId = val.code;
            this.fuzzySelectedList[i].propertyValue = val.value;
            break;
          }
        } else if (val == "" || val == undefined) {
          if (this.fuzzyItem.propertyId == this.fuzzySelectedList[i].propertyId) {
            this.fuzzySelectedList[i].propertyValueId = "";
            this.fuzzySelectedList[i].propertyValue = "";
            break;
          }
        }
      }
    },
    updateUI() {
    },
    clearPropertyValueId(val){
      this.resultItem.propertyValueId = ""
      this.resultItem.propertyValue = "";
    }
  },
  mounted() {
    this.updateUI();
  },
  created() {
  },
  destroyed() {},
  updated() {
    // this.updateUI();
  }
};
</script>

<style >
.el-autocomplete-suggestion{
  min-width: 300px;
}
#auto_complete .el-autocomplete {
  width: 200px;
}

</style>