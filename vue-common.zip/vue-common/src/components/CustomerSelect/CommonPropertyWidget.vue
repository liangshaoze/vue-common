<!--通用搜索条件 属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框,60选组织，70选日期-->
<template>
  <div>
    <el-row>
          <el-col class="form-item" v-for="(item,index) in propertyList" :key="index">
            <el-form-item :label="item.propertyName" :prop="item.propertyFieldName" style="display:flex">
              <CommonPropertyInput
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==10"
              />
              <CommonPropertySelect
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==20"
              >
                <slot :name="item.propertyFieldName" :slot="item.propertyFieldName"></slot>
              </CommonPropertySelect>
              <CommonPropertyRadioGroup
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==40"
              />
              <CommonPropertyAutoComplete
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                @clearEvent="clearEvent"
                v-if="item.propertyType==50"
              >
               <slot :name="item.propertyFieldName" :slot="item.propertyFieldName"></slot>
              </CommonPropertyAutoComplete>
               <CommonOrgNameInput
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==60"
              />
              <CommonPropertyDatePicker
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==70"
              />
              <CommonPropertyDatePicker
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod ="queryMethod"
                v-if="item.propertyType==71"
              />

            </el-form-item>
          </el-col>
            <slot name="append"></slot>
        </el-row>
        <el-row>
          <slot name="newLine"></slot>
        </el-row>
  </div>
</template>

<script>
import CommonPropertySelect from "components/CustomerSelect/CommonPropertySelect"
import CommonPropertyInput from "components/CustomerSelect/CommonPropertyInput"
import CommonPropertyAutoComplete from "components/CustomerSelect/CommonPropertyAutoComplete"
import CommonOrgNameInput from "components/CustomerSelect/CommonOrgNameInput"
import CommonPropertyDatePicker from "components/CustomerSelect/CommonPropertyDatePicker"
import CommonPropertyRadioGroup from "components/CustomerSelect/CommonPropertyRadioGroup"
export default {
  props: {
    propertyList:{
      type:Array,
      default:function(){
        return [];
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },
  components:{
    CommonPropertySelect,
    CommonPropertyInput,
    CommonPropertyAutoComplete,
    CommonOrgNameInput,
    CommonPropertyDatePicker,
    CommonPropertyRadioGroup
  },
  methods:{
    queryMethod(obj,query,cb){
      this.$emit("queryMethod",obj,query,cb)
    },
    clearEvent(obj){
      this.$emit("clearEvent",obj)
    }
  },
  mounted() {
    
  },created(){
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss" scoped>
.el-input{
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
  height: 40px;
}
</style>