<!--选组织输入框-->
<template>
  <div>
   <el-input 
   size="mini"
   v-model.trim="resultItem[baseItem.propertyFieldName]" 
   clearable 
   :placeholder="'请选择'+baseItem.propertyName"
   @focus="dialogVisible=true"
   @clear="clearOrgCode" 
   ></el-input>
   <el-dialog title="组织架构" :visible.sync="dialogVisible" width="500px" :before-close="handleCloseOrg">
				<org-select v-on:listenTochildEvent="getCurrentNode" />
			</el-dialog>
  </div>
</template>

<script>
import OrgSelect from "components/OrgSelect";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function(){
        return {
          propertyFieldName: "",//属性字段名
          propertyName: "",//属性名称
          propertyValue:"",//属性值
          propertyValueList: [],//属性值的集合
          optionKeyFieldName:"",//可选项值对应的key的字段名
          optionValueFieldName:"",//可选项值对应的value的字段名
          valueSetCode:"",//值集代码
          propertyType:"",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框,60选组织
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },
  components: {
    OrgSelect
  },
  data(){
    return {
      dialogVisible:false
    }
  },
  methods:{
     //获取组织
    getCurrentNode(data) {
         this.resultItem.orgName = data.orgName;
         this.resultItem.orgCode = data.orgCode;
         this.handleCloseOrg(); 
    },
     handleCloseOrg() {
      this.dialogVisible = false;
    },
    //清空组织过滤
    clearOrgCode() {
      this.resultItem.orgName = "";
      this.resultItem.orgCode = "";
      this.$forceUpdate()
    },
  },
  mounted() {
    
  },created(){
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss" scoped>
// .el-input{
//   width: 200px;
// }
</style>