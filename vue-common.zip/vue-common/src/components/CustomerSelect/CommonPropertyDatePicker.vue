<!--通用输入框-->
<template>
  <div>
    <el-date-picker
      v-model.trim="resultItem[baseItem.propertyFieldName]"
      clearable
      size="mini"
      value-format="yyyy-MM-dd"
      type="daterange"
      range-separator="至"
      start-placeholder="开始时间"
      end-placeholder="结束时间"
      v-if="baseItem.propertyType=='70'"
    ></el-date-picker>
    <el-date-picker
      v-model.trim="resultItem[baseItem.propertyFieldName]"
      clearable
      size="mini"
      value-format="yyyy-MM-dd hh:mm:ss"
      type="datetimerange"
      range-separator="至"
      start-placeholder="开始时间"
      end-placeholder="结束时间"
      v-if="baseItem.propertyType=='71'"
    ></el-date-picker>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {
          propertyFieldName: "", //属性字段名
          propertyName: "", //属性名称
          propertyValue: "", //属性值
          propertyValueList: [], //属性值的集合
          optionKeyFieldName: "", //可选项值对应的key的字段名
          optionValueFieldName: "", //可选项值对应的value的字段名
          valueSetCode: "", //值集代码
          propertyType: "" //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框,60选组织，70日期选择，71时间选择
        };
      }
    },
    resultItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  mounted() {},
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style>
.el-date-editor--datetimerange.el-input,
.el-date-editor--datetimerange.el-input__inner {
  width: 170px;
  min-width: 170px;
}
.el-date-editor.el-range-editor.el-input__inner.el-date-editor--daterange.el-range-editor--mini{
  width: 200px;
}
</style>