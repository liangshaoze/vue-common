<template>
  <div>
    <el-input
      v-model="resultItem.specificationValue"
      size="mini"
      :placeholder="'请输入'+fuzzyItem.specificationName"
      clearable
      @change="changeInputValue"
    ></el-input>
  </div>
</template>

<script>
export default {
  props: {
    fuzzyItem: {
      type: Object,
      default: function(){
        return {
          productCode: "",
          propertyType: "",
          specificationName: "",
          propertySort: "",
          displayType: "",
          isInput: "",
          isChosen:"",
          specificationValueList: [],
          specificationId: ""
        };
      }
    },
    fuzzySelectedList: {
      //已选择过的属性
      type: Array,
      default: function(){
        return [];
      }
    },
    resultItem:{
      type:Object,
      default: function(){
        return {
          productCode: "",
          specificationId: "",
          specificationName: "",
          specificationValue: "",
          isChosen: "",
          valueSort: 1,
          specificationValueId: ""
        }
      }
    }
  },

  data() {
    return {};
  },
  methods: {
    changeInputValue(val) {
      for(var i=0;i<this.fuzzySelectedList.length;i++){
          if(this.fuzzyItem.specificationId == this.fuzzySelectedList[i].specificationId){
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].specificationValue =  val;
            break;
        }
        }
    }
  },
  mounted() {
    this.$nextTick(()=>{
      this.changeInputValue(this.resultItem.specificationValue);
    })
  },
  created(){
    this.$watch("fuzzyItem",()=>{
     this.changeInputValue(this.resultItem.specificationValue);
    })
  }
};
</script>

<style lang="scss" scoped>
.el-input{
  width: 200px;
}
</style>