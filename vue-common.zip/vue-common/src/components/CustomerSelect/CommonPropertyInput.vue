<!--通用输入框-->
<template>
  <div>
   <el-input size="mini" v-model.trim="resultItem[baseItem.propertyFieldName]" clearable :placeholder="'请输入'+baseItem.propertyName"></el-input>
  </div>
</template>

<script>
export default {
  props: {
    baseItem: {
      type: Object,
      default: function(){
        return {
          propertyFieldName: "",//属性字段名
          propertyName: "",//属性名称
          propertyValue:"",//属性值
          propertyValueList: [],//属性值的集合
          optionKeyFieldName:"",//可选项值对应的key的字段名
          optionValueFieldName:"",//可选项值对应的value的字段名
          valueSetCode:"",//值集代码
          propertyType:"",//属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {};
      }
    }
  },
  mounted() {
    
  },created(){
  },
  destroyed() {
   
  },
  updated(){
  }
};
</script>

<style lang="scss" scoped>
// .el-input{
//   width: 200px;
// }
</style>