<!--通用自动远程搜索-->
<template>
  <div id="auto_complete" style="display:flex;justify-content:space-between;align-items:center">
    <el-autocomplete
      :trigger-on-focus="true"
      v-model="resultItem[baseItem.propertyFieldName]"
      size="mini"
      clearable
      :fetch-suggestions="remoteMethodCommon"
      :placeholder="'请输入'+baseItem.propertyName"
      @select="selectedPropertyValue"
      @clear="clearPropertyValue"
      :style="baseItem.style"
    ></el-autocomplete>
    <slot :name="baseItem.propertyFieldName"></slot>
  </div>
</template>

<script>
import { findValueBySetCode } from "api/common";
export default {
  props: {
    baseItem: {
      type: Object,
      default: function() {
        return {
          propertyFieldName: "", //属性字段名
          propertyName: "", //属性名称
          propertyValue: "", //属性值
          options: [], //可选项的集合
          optionKeyFieldName: "", //可选项值对应的key的字段名
          optionValueFieldName: "", //可选项值对应的value的字段名
          valueSetCode: "", //值集代码
          propertyType: "", //属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框
          queryMethod: "" //获取选项值列表的方法名称
        };
      }
    },
    resultItem: {
      type: Object,
      default: function() {
        return {};
      }
    },
    layoutIndex:{//布局中的索引
      type:Number,
      default:-1
    }
  },

  data() {
    return {
      selectOptions: []
    };
  },
  methods: {
    remoteMethodCommon(query, cb) {
      if (this.baseItem.valueSetCode) {
        findValueBySetCode({
          valueSetCode: this.baseItem.valueSetCode,
          name: query
        })
          .then(response => {
            if (response.data.statusCode == 200) {
              this.selectOptions = [];
              var data = response.data.responseData;
              for (let i = 0; i < data.length; i++) {
                this.selectOptions.push({
                  value: data[i].name,
                  code: data[i].value
                });
              }
              var results = this.selectOptions;
              if (results.length === 0) {
                results = [{ value: "无", code: "-1" }];
              }
              cb(results);
            }
          })
          .catch(error => {
            console.log(
              "findValueBySetCode:" + this.baseItem.valueSetCode + ":" + error
            );
            return false;
          });
        return;
      }
      if (this.baseItem.queryMethod) {
        this.$emit("queryMethod", this.baseItem, query, cb);
      }
    },
    selectedPropertyValue(item) {
      if (item.value !== "无") {
        this.resultItem[this.baseItem.propertyFieldName] = item.value;
        this.resultItem[this.baseItem.propertyCodeFieldName]=item.code;
        if (this.baseItem.queryMethod) {
          this.resultItem[this.baseItem.additionFieldName] = item.code;
          this.$emit("queryMethod", this.baseItem);
        }
        if(this.layoutIndex != -1){//控件所在的位置
          //第一个参数为选择结果，第二个参数为控件所在父组件的位置（例：表格中为行索引），第三个参数为控件对应的字段名
          this.$emit("changeEvent",item.code,this.layoutIndex,this.baseItem.propertyFieldName)//控件事件
        }
      } else {
        this.resultItem[this.baseItem.propertyFieldName] = "";
        this.resultItem[this.baseItem.propertyCodeFieldName]="";
      }
      this.$forceUpdate();
    },
    clearPropertyValue() {
      this.resultItem[this.baseItem.propertyFieldName] = "";
      this.resultItem[this.baseItem.additionFieldName] = "";
      this.resultItem[this.baseItem.propertyCodeFieldName]="";
      if(this.baseItem.clearEvent){
        this.$emit("clearEvent",this.baseItem);
      }
      if(this.layoutIndex != -1){//控件所在的位置
          //第一个参数为选择结果，第二个参数为控件所在父组件的位置（例：表格中为行索引），第三个参数为控件对应的字段名
          this.$emit("changeEvent","",this.layoutIndex,this.baseItem.propertyFieldName)//控件事件
      }
      this.$forceUpdate();
    },
    updateUI() {
      this.selectOptions = [];
      if (this.baseItem.options && this.baseItem.options.length > 0) {
        this.selectOptions = this.baseItem.options;
      }
      this.initOptions();
    },
    initOptions() {
      if (this.baseItem.queryMethod) {
        this.$emit("queryMethod", this.baseItem);
        return;
      }
    }
  },
  mounted() {},
  created() {
    this.$nextTick(() => {
      this.updateUI();
    });
    this.$watch("baseItem", () => {
      this.updateUI();
    });
    this.$watch("baseItem.options", () => {
      this.selectOptions = [];
      if (this.baseItem.options && this.baseItem.options.length > 0) {
        this.selectOptions = this.baseItem.options;
      }
    });
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss">
.multi-select {
  width: 200px;
}
.el-autocomplete {
  width: 200px;
}
.nomal-select {
  width: 200px;
}
.el-select__tags-text {
  font-size: 11px;
}
</style>