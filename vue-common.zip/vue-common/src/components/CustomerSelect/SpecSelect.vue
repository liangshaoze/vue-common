<!--通用选择，支持模糊查询-->
<template>
  <div>
    <el-select
      filterable
      size="mini"
      clearable
      remote
      :placeholder="'请输入'+fuzzyItem.specificationName"
      :remote-method="remoteMethodCommon"
      v-model="resultItem.specificationValueId"
      @change="changeFuzzyName"
      v-if="filterable"
    >
      <el-option
        v-for="item in searchedNameOptions"
        :key="item.specificationValueId"
        :label="item.specificationValue"
        :value="item.specificationValueId"
      ></el-option>
    </el-select>
    <el-select
      size="mini"
      clearable
      :placeholder="'请选择'+fuzzyItem.specificationName"
      v-model="resultItem.specificationValueId"
      @change="changeFuzzyName"
      v-if="!filterable"
    >
      <el-option
        v-for="item in searchedNameOptions"
        :key="item.specificationValueId"
        :label="item.specificationValue"
        :value="item.specificationValueId"
      ></el-option>
    </el-select>
  </div>
</template>

<script>
import { findEtProductPropertyValueList } from "api/common/index.js";
export default {
  props: {
    fuzzyItem:{
      type:Object,
      default:function(){
        return {
          productCode: "",
          propertyType: "",
          specificationName: "",
          propertySort: "",
          displayType: "",
          isInput: "",
          isChosen:"",
          specificationValueList: [],
          specificationId: ""
        }
      }
    },
    resultItem:{
      type:Object,
      default:function(){
        return {
          productCode: "",
          specificationId: "",
          specificationName: "",
          specificationValue: "",
          isChosen: "",
          valueSort: 1,
          specificationValueId: ""
        }
      }
    },
    fuzzySelectedList:{//已选择过的属性
      type:Array,
      default:function(){
        return []
      }
    },
    filterable:{
      type:Boolean,
      default:false
    }
  },

  data() {
    return {
      searchedNameOptions: [],
    };
  },
  methods: {
    remoteMethodCommon(query) {
        var params={
            productCode: this.fuzzyItem.productCode,
            propertyId: this.fuzzyItem.propertyId,
            propertyValue: query,
            pageSize: "100",
            pageNum: "1"
            }
        findEtProductPropertyValueList(params).then(response=>{
          if(response.data.statusCode == "200"){
            this.searchedNameOptions = response.data.responseData;
          }
        });
    },
    changeFuzzyName(val){
      var obj = {}
      obj = this.searchedNameOptions.find(item =>{
        return item.specificationValueId == val;
      });
      for(var i=0;i<this.fuzzySelectedList.length;i++){
        if(obj){
          if(obj.specificationId == this.fuzzySelectedList[i].specificationId){
            // this.fuzzySelectedList.splice(i,1);//移除 小贴士：form表单的绑定顺序不能随意更改，因此移除元素后在列表后面添加元素是错误滴
            // this.fuzzySelectedList[i] = JSON.parse(JSON.stringify(obj)) 小贴士：form表单验证元素对象也不能随意更改，因此对应元素不能重新指向另一对象，
            //应改变对应元素的属性
            this.fuzzySelectedList[i].specificationValueId = obj.specificationValueId;
            this.fuzzySelectedList[i].specificationValue =  obj.specificationValue;
            break;
          }
        }else if(val == "" || val == undefined){
          if(this.fuzzyItem.specificationId == this.fuzzySelectedList[i].specificationId){
            this.fuzzySelectedList[i].specificationValueId = "";
            this.fuzzySelectedList[i].specificationValue = "";
            break;
          }
        }
        }
        this.$emit("changeSpecSelect")
    }
  },
  mounted() {
    if(!this.filterable){
        this.searchedNameOptions = this.fuzzyItem.specificationValueList;
      }
  },
  created(){
  },
  updated(){
    if(!this.filterable){
      this.searchedNameOptions = this.fuzzyItem.specificationValueList;
    }
    
  }
};
</script>

<style lang="scss" scoped>
.el-select {
  width: 200px;
}
</style>