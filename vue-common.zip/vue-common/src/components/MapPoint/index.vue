
<template>
  <div id="mapPoint">
    <el-dialog
      :visible.sync="visible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      @close="closeDialog"
      width="70%"
    >
      <span slot="title">地图查询</span>
      <div class="height:600px">
        <el-row type="flex" justify="center" style="margin:10px">
          <el-input
            id="suggestId"
            v-model="address_detail"
            :size="size"
            clearable
            :placeholder="placeholder"
            :maxlength="maxlength"
            @keyup.enter.native="searchAddress"
          />
          <el-button
            id="searchBtn"
            @click="searchAddress"
            type="primary"
            icon="el-icon-search"
            size="mini"
            style="margin-left:10px"
          >搜索</el-button>
          <el-button
            @click="searchAddress3"
            type="primary"
            icon="el-icon-search"
            size="mini"
            style="margin-left:10px;"
          >搜推荐</el-button>
        </el-row>
        <div id="allmap" v-bind:style="mapStyle"></div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="openAddMarker">{{openFlag?"关闭手动定位":"打开手动定位"}}</el-button>
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="selectLocation">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
 
<script>
import icon_location from "@/assets/img/icon_location.png";
import icon_location_ from "@/assets/img/icon_location_.png";
export default {
  props: {
    size: {
      type: String,
      default: "mini"
    },
    placeholder: {
      type: String,
      default: ""
    },
    maxlength: {
      type: Number,
      defalut: 20
    },
    address: {
      type: String,
      default: ""
    },
    provinceAddress: {
      type: String,
      default: ""
    },
    cityAddress: {
      type: String,
      default: ""
    },
    districtAddress: {
      type: String,
      default: ""
    },
    liveLongitude: {
      type: String,
      default: ""
    },
    liveLatitude: {
      type: String,
      default: ""
    },
    checkinLatitude:{
      type: String,
      default: ""
    },
    checkinLongitude:{
      type: String,
      default: ""
    }
  },
  data() {
    return {
      address_detail: "",
      userlocation: { lng: "", lat: "" },
      mapStyle: {
        position: "relative",
        width: "100%",
        height: "500px"
      },
      map: {},
      ac: {},
      visible: true,
      openFlag: false,
      markerList: [],
      initPoint:"",
      pointList:[],
    };
  },
  mounted() {
    // 初始化地图
    this.$nextTick(() => {
      document.getElementById("suggestId").focus();
      var _this = this;
      // 创建Map实例
      this.map = new BMap.Map("allmap");
      // 初始化地图,设置中心点坐标，
      this.initPoint = new BMap.Point(121.48256831198465, 31.301439122519064); // 创建点坐标，公司坐标
      this.map.centerAndZoom(this.initPoint, 18);
      this.map.enableScrollWheelZoom(true);
      var opts = {type: BMAP_NAVIGATION_CONTROL_SMALL}    
      this.map.addControl(new BMap.NavigationControl(opts));
      var bottom_right_control = new BMap.ScaleControl({anchor: BMAP_ANCHOR_BOTTOM_RIGHT});// 右下角，添加比例尺
      this.map.addControl(bottom_right_control);
      this.ac = new BMap.Autocomplete({
        //建立一个自动完成的对象
        input: "suggestId",
        location: this.map
      });
      var myValue;
      this.ac.addEventListener("onconfirm", function(e) {
        //鼠标点击下拉列表后的事件
        var _value = e.item.value;
        myValue =
          _value.city +
          _value.district +
          _value.street +
          _value.business;
        setPlace();
      });

      function setPlace() {
        _this.map.clearOverlays(); //清除地图上所有覆盖物
        function myFun() {
          _this.userlocation = local.getResults().getPoi(0).point; //获取第一个智能搜索的结果
          _this.map.centerAndZoom(_this.userlocation, 20);
          _this.map.addOverlay(
            _this.createMarker(_this.userlocation, icon_location)
          ); //添加标注
        }

        var local = new BMap.LocalSearch(_this.map, {
          //智能搜索
          onSearchComplete: myFun
        });
        local.search(myValue);
      }
      var geoc = new BMap.Geocoder();

      _this.map.addEventListener("click", function(e) {
        if (!_this.openFlag) {
          return;
        }
        _this.map.clearOverlays(); //清除地图上所有覆盖物
        var pt = e.point;
        geoc.getLocation(pt, function(rs) {
          var addComp = rs.addressComponents;
          console.log("addComp===",rs)
          var marker = _this.createMarker(rs.point, icon_location);
          marker.addEventListener("click", attribute);
          _this.map.addOverlay(marker); //增加点
          var detailAddress =
            addComp.province+
            addComp.city +
            addComp.district +
            addComp.street +
            addComp.streetNumber;
          marker.setLabel(_this.createLabel(detailAddress));
          if (_this.address_detail == "") {
            _this.address_detail = detailAddress;
          }
          _this.userlocation = rs.point;
          function attribute() {}
        });
      });
      if (this.liveLatitude && this.liveLongitude) {
        this.markerList=[];
        var timer = setInterval(() => {
          var point = new BMap.Point(
            this.liveLongitude,
            this.liveLatitude
          );
          this.pointList.push(point)
          this.userlocation = point;
          // this.map.centerAndZoom(point, 20);
          var marker = this.createMarker(point, icon_location);
          if (this.checkinLatitude && this.checkinLongitude) {
            marker.setLabel(_this.createLabel("老人地址",{x:25,y:-15}));
            marker.labelName="老人地址"
          }
          this.markerList.push(marker);
          this.map.addOverlay(marker);
           if (this.checkinLatitude && this.checkinLongitude) {
              let point = new BMap.Point(
                this.checkinLongitude,
                this.checkinLatitude
              );
              this.pointList.push(point)
               var marker=this.createMarker(point, icon_location);
                marker.setLabel(_this.createLabel("评估签到",{x:20,y:-20}));
                marker.labelName="评估签到"
              this.markerList.push(marker);
              this.map.addOverlay(marker);
              this.setMarkersWithEventListener()
           }
           
           //根据多个经纬度点设置中心点及缩放级别
           var view = this.map.getViewport(eval(this.pointList));
           var mapZoom = view.zoom; 
           var centerPoint = view.center; 
           this.map.centerAndZoom(centerPoint,mapZoom);


          clearInterval(timer);
        }, 100);
      }
      var userAgent = window.navigator.userAgent;
      if(userAgent.indexOf('Chrome')!=-1||userAgent.indexOf('chrome')!=-1){
        //谷歌浏览器
      }else{
        if (this.$props.address != "") {
          this.address_detail = this.$props.address;
        }
      }

      if (this.checkinLatitude && this.checkinLongitude) {
        //浏览器定位
        var that = this;
        var geolocation = new BMap.Geolocation();
        geolocation.getCurrentPosition(function(r){
          if(this.getStatus() == BMAP_STATUS_SUCCESS){
            that.pointList.push(r.point)
            var marker=that.createMarker(r.point, icon_location);
                  marker.setLabel(that.createLabel("您所在的位置"));
                  marker.labelName="您所在的位置"
                  that.markerList.push(marker);
                that.map.addOverlay(marker);
                that.setMarkersWithEventListener()
            //根据多个经纬度点设置中心点及缩放级别
            var view = that.map.getViewport(eval(that.pointList));
            var mapZoom = view.zoom; 
            var centerPoint = view.center; 
            that.map.centerAndZoom(centerPoint,mapZoom);
          }
          else {
            console.log("获取您的位置信息失败");

          }        
        },{enableHighAccuracy: true})
      }
    });
  },
  created(){
    this.$watch("address",()=>{
      console.log("liveLongitude==="+this.liveLongitude)
    })
    var timer = setInterval(() => {
        if (this.$props.address != "") {
          this.address_detail = JSON.parse(JSON.stringify(this.$props.address));
        }
          clearInterval(timer);
        }, 500);
  },
  methods: {
    closeDialog() {
      this.visible = false;
      this.$emit("closeDialog", false);
    },
    selectLocation() {
      if (
        this.address_detail.trim().length > 0 &&
        this.userlocation.lng != "" &&
        this.userlocation.lat != ""
      ) {
        this.visible = false;
        this.$emit("GetMapPoint", [this.address_detail, this.userlocation]);
      } else {
        this.$message.error("请搜索地址定位后再进行确认");
        return false;
      }
    },
    searchAddress() {
      var _this = this;
      _this.map.clearOverlays();
      // 创建地址解析器实例
      var myGeo = new BMap.Geocoder();
      // 将地址解析结果显示在地图上,并调整地图视野
      myGeo.getPoint(
        this.$props.provinceAddress +
          this.$props.cityAddress +
          this.$props.districtAddress +
          this.address_detail,
        function(point) {
          if (point) {
            _this.map.centerAndZoom(point, 20);
            var marker = _this.createMarker(point, icon_location)
            _this.map.addOverlay(marker);
            _this.userlocation = point;
            // myGeo.getLocation(point, function(rs){
            //   marker.setLabel(_this.createLabel(rs.address));
		        // })
          } else {
            alert("您选择地址没有解析到结果!");
          }
        },
        this.$props.cityAddress == "" ? "上海市" : this.$props.cityAddress
      );
    },
    searchAddress2() {
      this.map.clearOverlays(); //清除地图上所有覆盖物
      this.markerList = [];
      var _this = this;
      var options = {
        onSearchComplete: function(results) {
          // 判断状态是否正确
          if (local.getStatus() == BMAP_STATUS_SUCCESS) {
            var s = [];
            var adds = [];
            for (var i = 0; i < results.getCurrentNumPois(); i++) {
              adds.push(results.getPoi(i).address);
            }
            // 创建地址解析器实例
            var myGeo = new BMap.Geocoder();
            for (var i = 0; i < adds.length; i++) {
              // 将地址解析结果显示在地图上,并调整地图视野
              let dIndex =i;
              myGeo.getPoint(
                adds[i],
                function(point) {
                  if (point) {
                    _this.map.centerAndZoom(adds[0], 20);
                    var marker = _this.createMarker(point, icon_location);
                    marker.addEventListener("click", () => {
                      _this.userlocation = point;
                      _this.map.clearOverlays();
                      marker = _this.createMarker(point, icon_location_);
                      marker.setLabel(_this.createLabel(addsItem));
                      _this.$set(marker,"isSelect",true)
                      _this.markerList.push(marker);
                      for(var j=_this.markerList.length-2;j>=0;j--){
                          if(_this.markerList[j]["isSelect"]){
                            _this.markerList.splice(j,1);
                          }
                      }
                       _this.markerList.forEach(item => {
                       _this.map.addOverlay(item);
                      });
                    });
                    _this.$set(marker,"isSelect",false)
                    _this.map.addOverlay(marker);
                    _this.markerList.push(marker);
                  }
                },
                _this.$props.cityAddress == ""
                  ? "上海市"
                  : _this.$props.cityAddress
              );
              let addsItem = adds[i];
            }
          }
        }
      };

      var local = new BMap.LocalSearch(this.map, options);
      local.search(this.address_detail);
    },
    searchAddress3(){
      this.map.clearOverlays(); //清除地图上所有覆盖物
      this.markerList = [];
      var _this = this;
      var address = this.$props.provinceAddress +
          this.$props.cityAddress +
          this.$props.districtAddress +
          this.address_detail;
      // 创建地址解析器实例
      var myGeo = new BMap.Geocoder();
      // 将地址解析结果显示在地图上,并调整地图视野
      myGeo.getPoint(
        address,
        function(point) {
          if (point) {
            _this.map.centerAndZoom(point, 11);
            _this.searchInBounds([address])
          } else {
            alert("您选择地址没有解析到结果!");
          }
        },
        this.$props.cityAddress == "" ? "上海市" : this.$props.cityAddress);
      
	    
    },
    openAddMarker() {
      this.map.clearOverlays(); //清除地图上所有覆盖物
      this.openFlag = !this.openFlag;
      this.clearUserLocation();
    },
    createMarker(point, icon) {
      return new BMap.Marker(point, {
        icon: new BMap.Icon(icon, new BMap.Size(30, 30))
      });
    },
    clearUserLocation() {
      this.userlocation = { lng: "", lat: "" };
    },
    createLabel(detailAddress,offsetObj){
      var label = new BMap.Label(detailAddress, {
            offset: new BMap.Size(20, -10)
          });
          if(offsetObj){
            label = new BMap.Label(detailAddress, {
            offset: new BMap.Size(offsetObj.x, offsetObj.y)
          });
          }
          label.setStyle({
            color: "#333333",
            border: "1px solid #eee",
            margin: "5px"
          });
          return label;
    },
    searchInBounds(myKeys){
      var _this = this;
      var local = new BMap.LocalSearch(this.map, {
        renderOptions:{map: this.map},
        pageCapacity:5,
         onMarkersSet:function (array) {
           _this.map.clearOverlays(); //清除地图上所有覆盖物
           array.forEach(item=>{
             var marker = _this.createMarker(item.point, icon_location);
                    marker.addEventListener("click", () => {
                      _this.map.centerAndZoom(item.point, 20);
                      _this.userlocation = item.point;
                      _this.map.clearOverlays();
                      marker = _this.createMarker(item.point, icon_location_);
                      marker.setLabel(_this.createLabel(item.address));
                      _this.$set(marker,"isSelect",true)
                      _this.markerList.push(marker);
                      for(var j=_this.markerList.length-2;j>=0;j--){
                          if(_this.markerList[j]["isSelect"]){
                            _this.markerList.splice(j,1);
                          }
                      }
                       _this.markerList.forEach(item => {
                       _this.map.addOverlay(item);
                      });
                    });
                    _this.$set(marker,"isSelect",false)
                    _this.map.addOverlay(marker);
                    _this.markerList.push(marker);
           })
          }
      });
      local.searchInBounds(myKeys, this.map.getBounds());
    },
    //marker设置监听
    setMarkersWithEventListener(){
      var that=this;
       this.markerList.forEach(marker=>{
          marker.addEventListener("click", () => {
                that.map.centerAndZoom(marker.point, 20);
                that.userlocation = marker.point;
                that.map.clearOverlays();
                var newMarker = that.createMarker(marker.point, icon_location_);
                newMarker.labelName=marker.labelName;
                that.$set(newMarker,"isSelect",true)
                that.markerList.push(newMarker);
                for(var j=that.markerList.length-2;j>=0;j--){
                  if(that.markerList[j]["isSelect"]){
                      that.markerList.splice(j,1);
                    }
                }
                that.markerList.forEach(item => {
                  item.setLabel(that.createLabel(item.labelName))
                  that.map.addOverlay(item);
                });
                that.setMarkersWithEventListener();
            });
       })
    }
  }
};
</script>

<style lang="scss">
.tangram-suggestion-main {
  z-index: 99999999999;
}
#mapPoint {
  .el-dialog__body {
    padding: 0px 20px;
  }
}

.anchorBL {
  display: none;
}
</style>