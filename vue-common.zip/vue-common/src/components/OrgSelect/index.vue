<template>
	<div id="orgSelect">
		<el-input
			class="filter-input"
			suffix-icon="el-icon-search"
			placeholder="请输入想查找的部门"
			v-model="filterOrgName"
		></el-input>
		<el-tree
			class="filter-tree"
			:data="data"
			node-key="orgCode"
			:filter-node-method="filterNode"
			:render-content="renderContent"
			:highlight-current="true"
			:expand-on-click-node="false"
			:props="defaultProps"
			:default-expanded-keys="['1']"
			@node-click="nodeClick"
			ref="tree"
		></el-tree>
	</div>
</template>

<script>
import { findEhrOrgList } from "api/orgStructure";
export default {
	data () {
		return {
			filterOrgName: "",
			data: [],
			defaultProps: {
				children: "childrenOrgList",
				label: "orgName",
				id: "orgCode"
			}
		};
	},
	watch: {
		//监听搜索框
		filterOrgName (val) {
			this.loadTree();
		}
	},
	methods: {
		//加载树结构数据
		loadTree () {
			var params = {
				orgName: this.filterOrgName
			};
			findEhrOrgList(params)
				.then(response => {
					if (response.data.statusCode == 200) {
						this.data = response.data.responseData;
					} else {
						this.$message.error(response.data.statusMsg);
						return false;
					}
				})
				.catch(error => {
					console.log("findEhrOrgList:" + error);
					return false;
				});
		},
		//触发搜索框
		filterNode (value, data) {
			this.loadTree();
			return true;
		},
		//当前选择节点
		nodeClick (data, node, self) {
			//触发父组件的事件
			this.$emit("listenTochildEvent", data);
		},
		//渲染样式
		renderContent (h, { node, data, store }) {
			return (
				<span>
					<i></i>
					<span>{node.label}</span>
				</span>
			);
		}
	},
	created () {
		//初始化加载
		this.loadTree();
	}
};
</script>

<style lang="scss" scoped>
#orgSelect {
	height: 500px;
	overflow-y: auto;
}
</style>
<style lang="scss">
#orgSelect .el-tree-node__expand-icon.expanded {
	-webkit-transform: rotate(0deg);
	transform: rotate(0deg);
}
#orgSelect .el-icon-caret-right:before {
	content: '\e723';
	font-size: 18px;
}
#orgSelect .el-tree-node__expand-icon.expanded.el-icon-caret-right:before {
	content: '\e722';
	font-size: 18px;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content {
	color: #f98c3c;
}
#orgSelect .el-tree-node.is-current > .el-tree-node__content i {
	background-color: #f98c3c;
	width: 8px;
	height: 8px;
	display: -webkit-inline-box;
	border-radius: 50%;
	margin-right: 5px;
}
</style>