//为避免与其他混入项冲突，变量名统一search开头
export default {
    data(){
        return {
            searchModel: {},//查询对象
            searchItems:[],//查询项,
            searchLoading:false,
            searcher:{},//搜索控件对象，需初始化
            searchRefName: "",//组件引用名称
        }
    },
    methods:{
        queryMethod(obj, query, cb) {//固定写法，不可覆盖
            if (typeof obj.queryMethod == "function") {
              obj.queryMethod(query, cb);
            } else {
              this[obj.queryMethod](query, cb);
            }
        },
        resetForm() {
            this.searcher.resetForm();
            this.queryData();
        },
        queryData(){
        },
        //设置组件引用名称
        setSearchRef(refName) {
            this.searchRefName = refName;
            return this.searchRefName;
        }

    },
    mounted(){
        this.searcher = this.$refs[`${this.searchRefName}`];
    }
}