//为避免与其他混入项冲突，变量名统一edit开头
export default {
    data() {
        return {
            editFormModel: {//编辑formModel
               
            },
            editRefName: "",//组件引用名称
            editer:{},
            editItems:{//编辑项

            }
        }
    },
    methods: {
        queryMethod(obj, query, cb) {//固定写法，不可覆盖
            if (typeof obj.queryMethod == "function") {
                obj.queryMethod(query, cb);
            } else {
                this[obj.queryMethod](query, cb);
            }
        },
        
        //设置组件引用名称
        setEditerRef(refName) {
            this.editRefName = refName;
            return this.editRefName;
        },
        //提交信息
        submit(){
            throw new Error("请重写 submit")
        },
        //去修改信息
        toUpdate(){
            throw new Error("请重写 toUpdate")
        }

    },
    mounted() {
        this.editer = this.$refs[`${this.editRefName}`];
    }
}