<!--通用新增、修改组件 属性类别，10输入框，20单项选择框，30多项选择框，40单选组，50远程模糊搜索框,60选组织，70选日期-->
<template>
  <div>
    <el-form ref="editForm" :inline="true" :model="resultItem" label-width="130px">
      <el-row>
        <el-col class="form-item" v-for="(item,index) in propertyList" :key="index">
          <el-form-item
            :label="item.propertyName"
            :prop="item.propertyFieldName"
            :rules="item.required == true ? [{required: true, message: item.propertyName+'不能为空'}] : null"
          >
            <div v-if="item.canEdit==false||!resultItem.isEdit">
              <span>{{ resultItem[item.propertyFieldName] }}</span>
            </div>
            <div v-else>
              <span v-if="!item.propertyType">{{resultItem[item.propertyFieldName]}}</span><!--不传控件类型-->
              <CommonPropertyInput
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==10"
              />
              <CommonPropertySelect
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==20"
              >
                <slot :name="item.propertyFieldName" :slot="item.propertyFieldName"></slot>
              </CommonPropertySelect>
              <CommonPropertyRadioGroup
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==40"
              />
              <CommonPropertyAutoComplete
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                @clearEvent="clearEvent"
                v-if="item.propertyType==50"
              >
                <slot :name="item.propertyFieldName" :slot="item.propertyFieldName"></slot>
              </CommonPropertyAutoComplete>
              <CommonOrgNameInput
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==60"
              />
              <CommonPropertyDatePicker
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==70"
              />
              <CommonPropertyDatePicker
                :baseItem="item"
                :resultItem="resultItem"
                @queryMethod="queryMethod"
                v-if="item.propertyType==71"
              />
            </div>
          </el-form-item>
        </el-col>
        <slot name="append"></slot>
      </el-row>
      <el-row>
        <slot>
          <div style="display:flex;justify-content:center;align-items:center">
            <el-button v-if="resultItem.isEdit" type="primary" size="mini" @click="submit">保存</el-button>
            <el-button v-else type="primary" size="mini" @click="toUpdate">修改</el-button>
          </div>
        </slot>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import CommonPropertySelect from "components/CustomerSelect/CommonPropertySelect";
import CommonPropertyInput from "components/CustomerSelect/CommonPropertyInput";
import CommonPropertyAutoComplete from "components/CustomerSelect/CommonPropertyAutoComplete";
import CommonOrgNameInput from "components/CustomerSelect/CommonOrgNameInput";
import CommonPropertyDatePicker from "components/CustomerSelect/CommonPropertyDatePicker";
import CommonPropertyRadioGroup from "components/CustomerSelect/CommonPropertyRadioGroup";
export default {
  props: {
    propertyList: {
      type: Array,
      default: function() {
        return [];
      }
    },
    resultItem: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  components: {
    CommonPropertySelect,
    CommonPropertyInput,
    CommonPropertyAutoComplete,
    CommonOrgNameInput,
    CommonPropertyDatePicker,
    CommonPropertyRadioGroup
  },
  methods: {
    queryMethod(obj, query, cb) {
      this.$emit("queryMethod", obj, query, cb);
    },
    clearEvent(obj) {
      this.$emit("clearEvent", obj);
    },
    resetForm() {
      this.$refs["editForm"].resetFields();
    },
    submit(){
      if(this.$parent.submit){
        this.$parent.submit();
      }
    },
    toUpdate(){
      this.$parent.toUpdate();
    },
    getEditForm(){
      return this.$refs["editForm"];
    }
  },
  mounted() {},
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
.el-select{
  width: 200px;
}
.form-item {
  width: 100%;
  min-width: 295px;
  height: 55px;
}
</style>