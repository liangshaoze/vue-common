//为避免与其他混入项冲突，变量名统一table开头
export default {
    data() {
        return {
            tableFormModel: {
                dataList: [],
                totalCount: 0,
                pageNum: 1,
                pageSize: 10
            },
            tableLoading: false,
            table: {},//表格对象，需初始化
            tableRefName: "",//组件引用名称
        }
    },
    methods: {
        queryMethod(obj, query, cb) {//固定写法，不可覆盖
            if (typeof obj.queryMethod == "function") {
                obj.queryMethod(query, cb);
            } else {
                this[obj.queryMethod](query, cb);
            }
        },
        //分页切换下一页上一页或跳转指定页面或切换每页显示条数
        pageChange(val) {
            throw Error("请重写 pageChange")
        },
        //保存行
        saveRow(index, row, table) {
            throw Error("请重写 saveRow")
        },
        //删除行
        deleteRow(index, row, table) {
            throw Error("请重写 deleteRow")
        },
        //表格合并
        spanMethod({ row, column, rowIndex, columnIndex }) {

        },
        //表格中控件事件
        changeEvent(val, layoutIndex, fieldName, table) {

        },
        //设置组件引用名称
        setTableRef(refName) {
            this.tableRefName = refName;
            return this.tableRefName;
        }

    },
    mounted() {
        this.table = this.$refs[`${this.tableRefName}`];
    }
}