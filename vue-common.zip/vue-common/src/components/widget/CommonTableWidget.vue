<!--通用表格控件，可编辑-->
<template>
  <div>
    <el-form ref="tForm" :inline="true" :model="formModel" label-width="125px">
      <el-table
        :header-cell-style="{background:'rgba(57, 138, 241, 0.1)',color:'#606266'}"
        size="mini"
        :data="formModel[tableDataName]"
        v-loading="loading"
        highlight-current-row
        element-loading-text="拼命加载中"
        class="tableMain"
        stripe
        :border="border"
        :span-method="spanMethod"
      >
        <el-table-column v-if="showTableIndex==true" label="序号" type="index" show-overflow-tooltip width="60"></el-table-column>
        <el-table-column
          v-for="(item,index) in propertyList" 
          :key="index"
          :prop="item.propertyFieldName"
          :label="item.propertyName"
          :min-width="item.minWidth"
          :width="item.width"
        >
          <template slot-scope="scope">
            <el-form-item
                :prop="tableDataName+'.'+scope.$index+'.'+item.propertyFieldName"
                :rules="item.required == true ? [{required: true, message: item.propertyName+'不能为空'}] : null"
                style="padding:0px;margin:0px"
              >
            <div v-if="item.canEdit==false||!scope.row.isEdit">
              <div style="line-height:1.5">{{ scope.row[item.propertyFieldName] }}</div>
            </div>
            <div v-else>
              <div style="line-height:1.5" v-if="!item.propertyType">{{scope.row[item.propertyFieldName]}}</div><!--不传控件类型-->
                <CommonPropertyInput
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==10"
                />
                <CommonPropertySelect
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==20"
                />
                <CommonPropertyAutoComplete
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==50"
                  :layoutIndex="scope.$index"
                  @changeEvent ="changeEvent"
                />
                <CommonOrgNameInput
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==60"
                />
                <CommonPropertyDatePicker
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==70"
                />
                <CommonPropertyDatePicker
                  :baseItem="item"
                  :resultItem="scope.row"
                  @queryMethod="queryMethod"
                  v-if="item.propertyType==71"
                />
            </div>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column fixed="right" :width="optWidth" label="操作" v-if="hasOptColumn==true">
          <template slot-scope="scope">
            <div class="operate-groups">
              <slot v-bind:row="scope">
              <el-button
                type="primary"
                size="mini"
                v-if="!scope.row.isEdit"
                icon="el-icon-edit-outline"
                @click="handleEditRow(scope.$index, scope.row)"
              >编辑</el-button>
              <el-button
                type="primary"
                size="mini"
                v-if="scope.row.isEdit"
                icon="el-icon-success"
                @click="handleSaveRow(scope.$index, scope.row)"
              >保存</el-button>
              <el-button
                size="mini"
                type="danger"
                icon="el-icon-delete"
                @click="handleDeleteRow(scope.$index, scope.row)"
              >删除</el-button>
              </slot>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <!--表格footer-->
    <slot name="footer"></slot>
    <!--工具条-->
		<el-row class="pageToolbar" v-if="formModel[tableDataName].length>0 && showPagination">
				<pagination
					:total="formModel.totalCount"
					:page.sync="formModel.pageNum"
					:limit.sync="formModel.pageSize"
					@pagination="pageChange"
				></pagination>
			</el-row>
  </div>
</template>

<script>
import CommonPropertySelect from "components/CustomerSelect/CommonPropertySelect";
import CommonPropertyInput from "components/CustomerSelect/CommonPropertyInput";
import CommonPropertyAutoComplete from "components/CustomerSelect/CommonPropertyAutoComplete";
import CommonOrgNameInput from "components/CustomerSelect/CommonOrgNameInput";
import CommonPropertyDatePicker from "components/CustomerSelect/CommonPropertyDatePicker";
import Pagination from "components/Pagination/pagination";
export default {
  props: {
    propertyList: {
      type: Array,
      default: function() {
        return [];
      }
    },
    formModel: {
      type: Object,
      default: function() {
        return {};
      }
    },
    tableDataName:{//formModel中的列表名
      type:String,
      default:""
    },
    optWidth:{
      type:Number,
      default:200
    },
    showTableIndex:{//显示序号
      type:Boolean,
      default:false
    },
    showPagination:{
      type:Boolean,
      default:true
    },
    hasOptColumn:{
      type:Boolean,
      default:true
    },
    loading:{
      type:Boolean,
      default:false
    },
    border:{
      type:Boolean,
      default:false
    },
    canSpan:{
      type:Boolean,
      default:false
    }
  },
  components: {
    CommonPropertySelect,
    CommonPropertyInput,
    CommonPropertyAutoComplete,
    CommonOrgNameInput,
    CommonPropertyDatePicker,
    Pagination
  },
  data() {
    return {
      tForm:{},
    };
  },
  methods: {
    queryMethod(obj, query, cb) {
      this.$emit("queryMethod", obj, query, cb);
    },
    // 编辑
    handleEditRow($index, row) {
      this.canSpan = false;//编辑状态，取消单元格合并
      this.$set(this.formModel[this.tableDataName][$index], "isEdit", true);
      this.$forceUpdate();
    },
    //保存
    handleSaveRow($index, row) {
      this.tForm.validate(valid => {
        if (valid) {
          this.$parent.saveRow($index,row,this)
        }else{
          this.$message.error("请检查是否填写完整");
          return false;
        }
      })
    },
    saveSuccess(row){
      this.$set(row, "isEdit", false);
    },
    // 删除
    handleDeleteRow($index, row) {
      this.$confirm("此操作将永久删除该条数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$parent.deleteRow($index,row,this);
        })
        .catch(err => {
          return false;
        });
    },
    //父组件触发事件
		pageChange (val) {
      this.formModel.pageNum = val.page;
      this.formModel.pageSize = val.limit;
      this.$emit("pageChange",val);
    },
    spanMethod({ row, column, rowIndex, columnIndex }){
      if(this.canSpan){
        return this.$parent.spanMethod({ row, column, rowIndex, columnIndex });
      }
    },
    changeEvent(val,layoutIndex,fieldName){//控件事件
      this.$parent.changeEvent(val,layoutIndex,fieldName,this);
    },
  },
  mounted() {
    this.tForm = this.$refs["tForm"];
  },
  created() {},
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
.el-input {
  width: 200px;
}
.form-item {
  width: 30%;
  min-width: 295px;
}
</style>