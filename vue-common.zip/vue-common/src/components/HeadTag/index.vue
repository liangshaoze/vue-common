<template>
  <div class="main_container" @click="tagNameClick">
      <el-image :src="iconSrc" class="img" />
      <span>{{tagName}}</span>
  </div>
</template>
<script>
export default {
  name: "HeadTag",
  data() {
    return {
      iconSrc: "/fsk/static/img/tagIcon.png"
    };
  },
  props: {
    tagName: {
      type: String,
      default: ""
    }
  },
  methods:{
    tagNameClick(){
      this.$emit("click")
    }
  }
};
</script>

<style scoped>
.main_container{
  height: 55px;
  display:flex;
  align-items: center;
  padding-left: 20px;

}
.main_container span{
  font-size: 18px;
  color: #000;
  padding-left: 10px;
}
.main_container .img{
  width: 20px;
  height: 20px;
}

</style>