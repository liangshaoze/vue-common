<template>
  <div>
    <el-form ref="addressForm" :model="addressForm">
      <el-row class="mainContainer">
        <el-col :span="8" class="address_select">
          <el-form-item prop="provinceName">
            <el-autocomplete
              v-model="addressForm.provinceName"
              size="mini"
              clearable
              :fetch-suggestions="queryProvinceName"
              placeholder="请选择省"
              @select="selectProvinceName"
              @blur="removeProvinceCode"
              @clear="removeProvinceCode"
            >
              <template slot-scope="{ item }">
                <el-tooltip
                  class="tooltip-item"
                  effect="dark"
                  :content="item.value"
                  placement="right"
                >
                  <span>{{item.value}}</span>
                </el-tooltip>
              </template>
            </el-autocomplete>
          </el-form-item>
        </el-col>
        <el-col :span="8" class="address_select">
          <el-form-item prop="cityName">
            <el-autocomplete
              v-model="addressForm.cityName"
              size="mini"
              clearable
              :disabled="cityDisable"
              :fetch-suggestions="queryCityName"
              placeholder="请选择市"
              @select="selectCityName"
              @blur="removeCityCode"
              @clear="removeCityCode"
            >
              <template slot-scope="{ item }">
                <el-tooltip
                  class="tooltip-item"
                  effect="dark"
                  :content="item.value"
                  placement="right"
                >
                  <span>{{item.value}}</span>
                </el-tooltip>
              </template>
            </el-autocomplete>
          </el-form-item>
        </el-col>
        <el-col :span="8" class="address_select">
          <el-form-item>
            <el-autocomplete
              v-model="addressForm.districtName"
              size="mini"
              clearable
              :disabled="districtDisable"
              :fetch-suggestions="queryDistrictName"
              placeholder="请选择区"
              @select="selectDistrictName"
              @blur="removeDistrictCode"
              @clear="removeDistrictCode"
            >
              <template slot-scope="{ item }">
                <el-tooltip
                  class="tooltip-item"
                  effect="dark"
                  :content="item.value"
                  placement="right"
                >
                  <span>{{item.value}}</span>
                </el-tooltip>
              </template>
            </el-autocomplete>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
import { findAddressDictList } from "@/api/common/index.js";
export default {
  data() {
    return {
      provinces: [],
      cities: [],
      districts: [],
      addressForm: {
        provinceCode: "",
        provinceName: "",
        cityCode: "",
        cityName: "",
        districtCode: "",
        districtName: ""
      },
      addressFormRules: {
        provinceName: [
          {
            required: true,
            message: "请选择省",
            trigger: "change"
          }
        ],
        cityName: [
          {
            required: true,
            message: "请选择市",
            trigger: "change"
          }
        ]
      },
      cityDisable: true,
      districtDisable: true,
      flag: false
    };
  },
  props: {
    address: {
      type: Object,
      default: {
        provinceCode: "",
        provinceName: "",
        cityCode: "",
        cityName: "",
        districtCode: "",
        districtName: ""
      }
    }
  },
  methods: {
    /**
     *
     * 模糊查询
     *
     */
    //省模糊查询
    selectProvinceName(item) {
      if (item.value !== "无") {
        this.addressForm.provinceName = item.value;
        this.addressForm.provinceCode = item.code;
        this.addressForm.cityCode = "";
        this.addressForm.cityName = "";
        this.addressForm.districtName = "";
        this.addressForm.districtCode = "";
        this.$emit("selectedProvinceListener", this.addressForm);
        this.cityDisable = false;
      } else {
        this.addressForm.provinceName = "";
        this.addressForm.provinceCode = "";
        this.addressForm.cityCode = "";
        this.addressForm.cityName = "";
        this.addressForm.districtName = "";
        this.addressForm.districtCode = "";
        this.$emit("selectedProvinceListener", this.addressForm);
        this.cityDisable = true;
      }
    },
    removeProvinceCode() {
      this.addressForm.provinceCode = "";
      this.addressForm.provinceName = "";
      this.addressForm.cityCode = "";
      this.addressForm.cityName = "";
      this.addressForm.districtName = "";
      this.addressForm.districtCode = "";
      this.$emit("selectedProvinceListener", this.addressForm);
      this.cityDisable = true;
      this.districtDisable = true;
    },
    queryProvinceName(queryString, cb) {
      // debugger;
      var params = {
        pageNum: 1,
        pageSize: 10,
        pid: 0,
        name: queryString
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.provinces = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.provinces.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.provinces;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 模糊查询
     *
     */
    //市模糊查询
    selectCityName(item) {
      if (item.value !== "无") {
        this.addressForm.cityName = item.value;
        this.addressForm.cityCode = item.code;
        this.addressForm.districtName = "";
        this.addressForm.districtCode = "";
        this.$emit("selectedCityListener", this.addressForm);
        this.districtDisable = false;
      } else {
        this.addressForm.cityName = "";
        this.addressForm.cityCode = "";
        this.addressForm.districtName = "";
        this.addressForm.districtCode = "";
        this.$emit("selectedCityListener", this.addressForm);
        this.districtDisable = true;
      }
    },
    removeCityCode() {
      this.addressForm.cityCode = "";
      this.addressForm.cityName = "";
      this.addressForm.districtName = "";
      this.addressForm.districtCode = "";
      this.$emit("selectedCityListener", this.addressForm);
      this.districtDisable = true;
    },
    queryCityName(queryString, cb) {
      var params = {
        pageNum: 1,
        pageSize: 10,
        pid: this.addressForm.provinceCode,
        name: queryString
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.cities = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.cities.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.cities;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    },
    /**
     *
     * 模糊查询
     *
     */
    //区模糊查询
    selectDistrictName(item) {
      if (item.value !== "无") {
        this.addressForm.districtName = item.value;
        this.addressForm.districtCode = item.code;
        this.$emit("selectedDistrictListener", this.addressForm);
      } else {
        this.addressForm.districtName = "";
        this.addressForm.districtCode = "";
        this.$emit("selectedDistrictListener", this.addressForm);
      }
    },
    removeDistrictCode() {
      this.addressForm.districtCode = "";
      this.addressForm.districtName = "";
      this.$emit("selectedDistrictListener", this.addressForm);
    },
    queryDistrictName(queryString, cb) {
      var params = {
        pageNum: 1,
        pageSize: 10,
        pid: this.addressForm.cityCode,
        name: queryString
      };
      findAddressDictList(params)
        .then(response => {
          if (response.data.statusCode === "200") {
            this.districts = [];
            var data = response.data.responseData;
            for (let i = 0; i < data.length; i++) {
              this.districts.push({
                value: data[i].name,
                code: data[i].id
              });
            }
            var results = this.districts;
            if (results.length === 0) {
              results = [{ value: "无", code: "-1" }];
            }
            cb(results);
          } else {
            this.$message.error(response.data.statusMsg);
            return false;
          }
        })
        .catch(error => {
          console.log("findEhrPositionList:" + error);
          return false;
        });
    }
  },
  created() {
    this.$watch("address", function() {
      if (this.flag == false) {
        if (this.address.provinceCode) {
          this.addressForm.provinceCode = this.address.provinceCode;
          this.addressForm.provinceName = this.address.provinceName;
          this.cityDisable = false;
          if (this.address.cityCode) {
            this.addressForm.cityCode = this.address.cityCode;
            this.addressForm.cityName = this.address.cityName;
            this.districtDisable = false;
            if (this.address.districtCode) {
              this.addressForm.districtCode = this.address.districtCode;
              this.addressForm.districtName = this.address.districtName;
            }
          }
        }
        this.flag = true;
      } else {
        if (this.address.provinceCode) {
          this.addressForm.provinceCode = this.address.provinceCode;
          this.addressForm.provinceName = this.address.provinceName;
          this.cityDisable = false;
          if (this.address.cityCode) {
            this.addressForm.cityCode = this.address.cityCode;
            this.addressForm.cityName = this.address.cityName;
            this.districtDisable = false;
            if (this.address.districtCode) {
              this.addressForm.districtCode = this.address.districtCode;
              this.addressForm.districtName = this.address.districtName;
            }
          }
        }
      }
    });
  }
};
</script>
<style>
.el-autocomplete-suggestion {
  min-width: 200px;
}

.el-autocomplete-suggestion__wrap {
  min-width: 200px;
}

.address_select {
  display: flex;
  justify-content: center;
}

.mainContainer {
  display: block;
  line-height: 40px;
}
</style>