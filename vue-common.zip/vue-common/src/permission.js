import router from './router'
import store from './store'
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css'// Progress 进度条样式
import { getToken } from 'utils/auth' // 验权
import { getUserInfo } from 'utils/userMgr'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

// register global progress.
const whiteList = ['/#', '/login','/addMaskOrder','/maskOrderResult','/assessReportNoToken']// 不重定向白名单

router.beforeEach(async(to, from, next) => {
  NProgress.start() // 开启Progress

  const hasToken = getUserInfo().token // 获取token

  if (hasToken) { // 判断是否有token
    if (to.path === '/login') {
      next({ path: '/' })
      NProgress.done() // router在hash模式下 手动改变hash 重定向回来 不会触发afterEach 暂时hack方案 ps：history模式下无问题，可删除该行！
    } else {
      const hasRoles = store.getters.roles && store.getters.roles.length > 0
      if (hasRoles) {
        next()
      } else {
        try {
          // get menu info
          // note: roles must be a object array! such as: ['admin'] or ,['developer','editor']
          const { privilegeNames } = await store.dispatch('MenuInfo')

          // generate accessible routes map based on roles
          const accessRoutes = await store.dispatch('GenerateRoutes', privilegeNames)

          // dynamically add accessible routes
          router.addRoutes(accessRoutes)

          // hack method to ensure that addRoutes is complete
          // set the replace: true, so the navigation will not leave a history record
          next({ ...to, replace: true })
        } catch (error) {
          // remove token and go to login page to re-login
          await store.dispatch('FedLogOut')
          next(`/login`)
          NProgress.done()
        }
      }
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      // other pages that do not have permission to access are redirected to the login page.
      next(`/login`)
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  NProgress.done() // 结束Progress
})
