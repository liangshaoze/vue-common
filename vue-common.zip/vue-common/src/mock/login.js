import { param2Obj } from 'utils'

const tokens = {
  admin: {
    statusCode: '200', statusMsg: '成功', responseData: {
      token: 'adminToken'
    }
  },
  editor: {
    statusCode: '200', statusMsg: '成功', responseData: {
      token: 'editorToken'
    }
  }
}

const users = {
  adminToken: {
    statusCode: '200', statusMsg: '成功', responseData: {
      roles: ['admin'],
      introduction: '我是系统管理员',
      avatar: '/static/img/logo.png',
      name: '管理员'
    }
  },
  editorToken: {
    statusCode: '200', statusMsg: '成功', responseData: {
      roles: ['editor'],
      introduction: '我是普通用户',
      avatar: '/static/img/clientApp.png',
      name: '普通用户'
    }
  }
}

export default {
  loginByUsername: config => {
    const username = config.body
    return tokens[username]
  },
  getUserInfo: config => {
    const token = param2Obj(config.url)
    return users[token.token]
  },
  logout: () => 'success'
}
