import { findAddressDictList } from "api/common/index.js";
// 获取省市区级联数据
export const getNodes = ({val,options})=> {
    return new Promise((resolve,reject)=>{
        let pid;
        let sizeArea;
        if (val.length === 0) {
            pid = 0;
            sizeArea = 0;
        } else if (val.length === 1) {
            pid = val[0];
            sizeArea = val.length;
        } else if (val.length === 2) {
            pid = val[1];
            sizeArea = val.length;
        }
        const params = {
            pid: pid
        };
        findAddressDictList(params).then(
            response => {
                if (response.data && response.data.statusCode == "200") {
                    let Items = response.data.responseData;
                    if (sizeArea === 0) {
                        // 初始化 加载一级 省
                        options = Items.map((value, i) => {
                            return {
                                id: value.id,
                                name: value.name,
                                cities: []
                            };
                        });
                        resolve(options);
                    } else if (sizeArea === 1) {
                        // 点击一级 加载二级 市
                        options.map((value, i) => {
                            if (value.id === val[0]) {
                                if (!value.cities.length) {
                                    value.cities = Items.map((value, i) => {
                                        return {
                                            id: value.id,
                                            name: value.name,
                                            cities: []
                                        };
                                    });
                                }
                            }
                        });
                        resolve(options);
                    } else if (sizeArea === 2) {
                        // 点击二级 加载三级 区
                        options.map((value, i) => {
                            if (value.id === val[0]) {
                                value.cities.map((value, i) => {
                                    if (value.id === val[1]) {
                                        if (!value.cities.length) {
                                            value.cities = Items.map((value, i) => {
                                                return {
                                                    id: value.id,
                                                    name: value.name
                                                };
                                            });
                                        }
                                    }
                                });
                            }
                        });
                        resolve(options);
                    }
    
                } else {
                    console.log(response.data.statusMsg);
                }
            },
            error => {
                console.log(error);
                reject(error);
            }
        );



    })
    
}


