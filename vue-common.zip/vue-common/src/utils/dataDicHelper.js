// 该文件处理一些数据结构,对用提供公用方法,参数功能
import request from 'utils/request'
// 根据code查询数据字典信息: code：101 所有字典名称
export function findDictionaryByType(code) {
  return request({
    url: '/common/findDictionaryByType?type=' + code,
    method: 'post'
  })
}

export function findStaffInfoSelect(data) {
  return request({
    url: '/common/findStaffInfoSelect',
    method: 'post',
    data
  })
}

export function findCityAreaList(data) {
  return request({
    url: '/common/findCityAreaList',
    method: 'post',
    data
  })
}

export function findSysOrgList(data) {
  return request({
    url: '/common/findSysOrgList',
    method: 'post',
    data
  })
}

export function findClientInfoSelect(data) {
  return request({
    url: '/common/findClientInfoSelect',
    method: 'post',
    data
  })
}
