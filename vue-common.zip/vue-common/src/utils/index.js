/**
 * Created by jiachenpan on 16/11/18.
 */

export function parseTime (time, cFormat) {
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if (('' + time).length === 10) time = parseInt(time) * 1000
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') { return ['日', '一', '二', '三', '四', '五', '六'][value] }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}

export function formatTime (time, option) {
  time = +time * 1000
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return (
      d.getMonth() +
      1 +
      '月' +
      d.getDate() +
      '日' +
      d.getHours() +
      '时' +
      d.getMinutes() +
      '分'
    )
  }
}

export function isExternal (path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

export function param2Obj (url) {
  const search = url.split('?')[1]
  if (!search) {
    return {}
  }
  return JSON.parse(
    '{"' +
    decodeURIComponent(search)
      .replace(/"/g, '\\"')
      .replace(/&/g, '","')
      .replace(/=/g, '":"') +
    '"}'
  )
}

export function debounce (func, wait, immediate) {
  let timeout, args, context, timestamp, result

  const later = function () {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp

    // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }

  return function (...args) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }

    return result
  }
}
export const pickerOptions = [
  {
    text: '最近一周',
    onClick (picker) {
      const end = new Date(new Date().toDateString())
      const start = new Date()
      start.setTime(end.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  },
  {
    text: '最近一个月',
    onClick (picker) {
      const end = new Date(new Date().toDateString())
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }
]

export function timestampChangeDate (timestamp) {
  var pad = function (n, c) {
    if ((n = n + '').length < c) {
      return new Array(++c - n.length).join('0') + n
    } else {
      return n
    }
  }
  var d = new Date(timestamp) // 根据时间戳生成的时间对象
  var date =
    d.getFullYear() +
    '-' +
    pad((d.getMonth() + 1), 2) +
    '-' +
    pad(d.getDate(), 2) +
    ' ' +
    pad(d.getHours(), 2) +
    ':' +
    pad(d.getMinutes(), 2) +
    ':' +
    pad(d.getSeconds(), 2)
  return date
}

export function changeYMDHMS (d) {
  var pad = function (n, c) {
    if ((n = n + '').length < c) {
      return new Array(++c - n.length).join('0') + n
    } else {
      return n
    }
  }
  var date =
    d.getFullYear() +
    '-' +
    pad((d.getMonth() + 1), 2) +
    '-' +
    pad(d.getDate(), 2) +
    ' ' +
    pad(d.getHours(), 2) +
    ':' +
    pad(d.getMinutes(), 2) +
    ':' +
    pad(d.getSeconds(), 2)
  return date
}
export function setTime (time) {
  if (time) {
    var timearr = time.replace(" ", ":")
      .replace(/\:/g, "-")
      .split("-");
    var timestr =
      "" +
      timearr[0] +
      ":" +
      timearr[1]
  }
  return timestr
}
export function changeYMD (d) {
  if (d == undefined || d == 'Invalid Date') {
    return ''
  }
  if (d.length > 10) {
    return d.substr(0, 10)
  }
  d = new Date(d)
  var pad = function (n, c) {
    if ((n = n + '').length < c) {
      return new Array(++c - n.length).join('0') + n
    } else {
      return n
    }
  }
  var date =
    d.getFullYear() +
    '-' +
    pad((d.getMonth() + 1), 2) +
    '-' +
    pad(d.getDate(), 2)
  return date
}
/**
 * Check if an element has a class
 * @param {HTMLElement} elm
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass (ele, cls) {
  return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'))
}

/**
 * Add class to element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function addClass (ele, cls) {
  if (!hasClass(ele, cls)) ele.className += ' ' + cls
}

/**
 * Remove class from element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function removeClass (ele, cls) {
  if (hasClass(ele, cls)) {
    const reg = new RegExp('(\\s|^)' + cls + '(\\s|$)')
    ele.className = ele.className.replace(reg, ' ')
  }
}

/**
 * 保留小数
 * @param {HTMLElement} num 当前输入的值
 * @param {string} several 保留几位小数
 */
export function keepDecimalFull (num, several) {
  try {
    several++
    const numStr = num.toString()
    const index = numStr.indexOf('.')
    const result = numStr.slice(0, index + several)
    return result
  } catch (err) {
    return num
  }
}
//根据身份证获取年龄信息
export function getAgeFromIdentityCard (identityCard) {
  var len = (identityCard + "").length;
  if (len == 0) {
    return 0;
  } else {
    if (len != 15 && len != 18) {
      //身份证号码只能为15位或18位其它不合法
      return 0;
    }
  }
  var strBirthday = "";
  if (len == 18) {
    //处理18位的身份证号码从号码中得到生日和性别代码
    strBirthday =
      identityCard.substr(6, 4) +
      "/" +
      identityCard.substr(10, 2) +
      "/" +
      identityCard.substr(12, 2);
  }
  if (len == 15) {
    strBirthday =
      "19" +
      identityCard.substr(6, 2) +
      "/" +
      identityCard.substr(8, 2) +
      "/" +
      identityCard.substr(10, 2);
  }
  //时间字符串里，必须是“/”
  var birthDate = new Date(strBirthday);
  var nowDateTime = new Date();
  var age = nowDateTime.getFullYear() - birthDate.getFullYear();
  //再考虑月、天的因素;.getMonth()获取的是从0开始的，这里进行比较，不需要加1
  if (
    nowDateTime.getMonth() < birthDate.getMonth() ||
    (nowDateTime.getMonth() == birthDate.getMonth() &&
      nowDateTime.getDate() < birthDate.getDate())
  ) {
    age--;
  }
  return age;
}
export function getBirthdayFromIdentityCard (identityCard) {
  var birthday = "";
  if (identityCard != null && identityCard != "") {
    if (identityCard.length == 15) {
      birthday = "19" + identityCard.substr(6, 6);
    } else if (identityCard.length == 18) {
      birthday = identityCard.substr(6, 8);
    }

    birthday = birthday.replace(/(.{4})(.{2})/, "$1-$2-");
  }

  return birthday;
}
//获取元素绝对位置  
export function getAbsPosition (element) {
  var abs = { x: 0, y: 0 }
  //如果浏览器兼容此方法  
  if (document.documentElement.getBoundingClientRect) {
    //注意，getBoundingClientRect()是jQuery对象的方法  
    //如果不用jQuery对象，可以使用else分支。  
    abs.x = element.getBoundingClientRect().left;
    abs.y = element.getBoundingClientRect().top;

    abs.x += window.screenLeft +
      document.documentElement.scrollLeft -
      document.documentElement.clientLeft;
    abs.y += window.screenTop +
      document.documentElement.scrollTop -
      document.documentElement.clientTop;

  }
  //如果浏览器不兼容此方法  
  else {
    while (element != document.body) {
      abs.x += element.offsetLeft;
      abs.y += element.offsetTop;
      element = element.offsetParent;
    }

    //计算想对位置  
    abs.x += window.screenLeft +
      document.body.clientLeft - document.body.scrollLeft;
    abs.y += window.screenTop +
      document.body.clientTop - document.body.scrollTop;

  }
  return abs;
}
// 兼容IE浏览器
export function getStyleProperty (obj, attr) {
  if (obj.currentStyle) {
    return obj.currentStyle[attr];
  } else {
    return document.defaultView.getComputedStyle(obj, null)[attr];
  }
}
// 兼容IE浏览器
export function getStyle (obj) {
  if (obj.currentStyle) {
    return obj.currentStyle;
  } else {
    return document.defaultView.getComputedStyle(obj, null);
  }
}
// 兼容IE浏览器
export function setStyle (obj, style) {
  if (obj.currentStyle) {
    obj.currentStyle = style;
  } else {
    for (let property in style) {
      obj.style[property] = style[property];
    }
  }
}
//获取当前时间
export function getNow() {
  let myDate = new Date();
  let wk = myDate.getDay();
  let yy = String(myDate.getFullYear());
  let mm = myDate.getMonth() + 1;
  let dd = String(
    myDate.getDate() < 10 ? "0" + myDate.getDate() : myDate.getDate()
  );
  let hou = String(
    myDate.getHours() < 10 ? "0" + myDate.getHours() : myDate.getHours()
  );
  let min = String(
    myDate.getMinutes() < 10
      ? "0" + myDate.getMinutes()
      : myDate.getMinutes()
  );
  let sec = String(
    myDate.getSeconds() < 10
      ? "0" + myDate.getSeconds()
      : myDate.getSeconds()
  );
  let weeks = [
    "星期日",
    "星期一",
    "星期二",
    "星期三",
    "星期四",
    "星期五",
    "星期六"
  ];
  let week = weeks[wk];
  let nowDate = yy + "/" + mm + "/" + dd;
  let nowTime = hou + ":" + min + ":" + sec;
  let nowWeek = week;
  return {
    day:nowDate,
    time:nowTime,
    week:nowWeek,
  }
}
//按时间打印
export function log(val){
  console.log(getNow().time+" "+val);
}
//获取浏览器窗口大小
function getWindowWidth(){
  // 获取窗口宽度
    if (window.innerWidth){
      return window.innerWidth;
    }
    if ((document.body) && (document.body.clientWidth)){
      return document.body.clientWidth;
    }
    throw new Error("getWindowWidth error")
}
function getWindowHeight(){
    // 获取窗口宽度
    if (window.innerHeight){
      return window.innerHeight;
    }
    if ((document.body) && (document.body.clientHeight)){
      return document.body.clientHeight;
    }
    throw new Error("getWindowHeight error")
}
export default {
  getWindowWidth,getWindowHeight
}

