// import SockJS from  'sockjs-client';
// import Stomp from 'stompjs';
var ws = null
var timerList = [];
// const websocketUrl = "ws://192.168.6.217:8088/"
import EnvironmentUtils from "utils/EnvironmentUtils"
import {getNow,log} from "utils"
function initWebSocket(pageContext) {
    //打开一个websocket链接
    if ("WebSocket" in window) {
        // 建立连接对象
        // var socket = new SockJS('ws://192.168.8.89:8041/message/message/websocket/deviceOrderData?user=u001');//连接服务端提供的通信接口，连接以后才可以订阅广播消息和个人消息
        // var socket = new SockJS('http://192.168.8.108:8041/message/message/websocket/deviceOrderData');//连接服务端提供的通信接口，连接以后才可以订阅广播消息和个人消息
        stompClient = Stomp.client(websocketUrl + "message/websocket/deviceOrderData?user=" + param);

        // 获取STOMP子协议的客户端对象
        var stompClient = null;
        var url = null;
        if (isSmart) {
            var paramJson = ["u001"];
            var param = encodeURI(JSON.stringify(paramJson));
            url = "deviceOrderData"
            stompClient = Stomp.client(websocketUrl + "message/websocket/deviceOrderData?user=" + param);
        } else {
            var paramJson = ["u002"];
            var param = encodeURI(JSON.stringify(paramJson));
            url = "deviceOrderAlarm"
            stompClient = Stomp.client(websocketUrl + "message/websocket/deviceOrderAlarm?user=" + param);
        }


        // var stompClient = Stomp.client(socket);
        // stompClient = Stomp.overWS('http://192.168.8.108:8041/message/message/sock-js')
        // 定义客户端的认证信息,按需求配置
        // stompClient.connect({},(frame)=>{
        //     log(frame)
        // })
        // var headers = {
        //     login: 'mylogin',
        //     passcode: 'mypasscode',
        //     'token':pageContext.UserMgr.getUserInfo().token,
        // //     // additional header
        // //   'client-id': 'my-client-id'
        // };
        // 向服务器发起websocket连接
        // stompClient.connect({},() => {
        //     log("frame====")
        //     stompClient.subscribe('/websocket/deviceOrderData', (msg) => { // 订阅服务端提供的某个topic
        //         log("frame===="+msg.body)
        //         log(msg.body); // msg.body存放的是服务端发送给我们的信息
        //     });
        // }, (err) => {
        //     log("err===",err)
        // });
        // try{
        //     stompClient.connect(headers)
        //     log("aaaaa==")
        // }catch(error){
        //     log("aaaaa==",error)
        // }
        stompClient.ws.onmessage = function (event) {

            var receivedMsg = event.data;
            log("receivedMsg==" + receivedMsg + " isSmart=" + isSmart + " url==" + url)
            if (pageContext) {
                if (isSmart) {
                    pageContext.EventBus.post("receivedMsg", receivedMsg);
                } else {
                    pageContext.EventBus.post("receivedMsgAll", receivedMsg);
                }

            } else {
                alert("初始化websocket请传入pageContext")
            }
        }
        stompClient.ws.onopen = function () {
            log("onopen")
            stompClient.ws.send("给服务端的msg")

        }

        //打开一个websocket
        // ws = new WebSocket("ws://localhost:9999/echo");
        // var sendMsg = {headers:{token:pageContext.UserMgr.getUserInfo().token}};
        // var headers = "{headers:{token:"+pageContext.UserMgr.getUserInfo().token+"}}"
        // log("headers==="+headers)
        // ws = new WebSocket("ws://192.168.8.89:8041/message/message/websocket/deviceOrderData?user=u001","Sec-WebSocket-Protocol",headers);//TODO
        // ws.onopen = function () {
        //     //websocket已连接，使用send()方法发送数据
        //     log("onopen")
        //     // var sendMsg = {headers:{token:pageContext.UserMgr.getUserInfo().token}};
        //     // ws.send(JSON.stringify(sendMsg));
        //     log("onopen sendMsg==="+JSON.stringify(sendMsg))
        // }
        // ws.onmessage = function (event) {
        //     var receivedMsg = event.data;
        //     if (pageContext) {
        //         pageContext.EventBus.post("receivedMsg", receivedMsg);
        //     } else {
        //         alert("初始化websocket请传入pageContext")
        //     }
        // }
        // ws.onclose = function () {
        //     //关闭链接
        //     // alert("连接已关闭")
        //     log("ws.onclose")
        // }


    } else {
        alert("抱歉，您的浏览器不支持Websocket，无法接收服务器发过来的推送消息")
    }
}
//智能监护socket
function initWebSocketBySmart(pageContext, careReceiverIds) {
    closeWebSocket();
    clearTimers();
    openWebSocketBySmart(pageContext,careReceiverIds);
}
function openWebSocketBySmart(pageContext,careReceiverIds){
    //打开一个websocket链接
    if ("WebSocket" in window) {
        var websocketUrl = EnvironmentUtils.getEnvironment().WEBSOCKET_URL + (EnvironmentUtils.getEnvironment().isIpUrl ? "" : "message/");
        // websocketUrl="ws://192.168.6.217:8088/"
        // 建立连接对象
        var param = encodeURI(JSON.stringify(careReceiverIds));
        var token = pageContext.UserMgr.getUserInfo().token;
        ws = new WebSocket(websocketUrl + "websocket/deviceOrderData?user=" + param + "&token=" + token);
        log(websocketUrl+"websocket/deviceOrderData")
        ws.onmessage = function (event) {
            var receivedMsg = event.data;
            log("WebSocketByOrderData receivedMsg==" + receivedMsg)
            if (pageContext) {
                pageContext.EventBus.post("receivedMsg", receivedMsg);
            } else {
                alert("初始化websocket请传入pageContext")
            }
        }
        ws.onopen = function () {
            log("WebSocketByOrderData onopen")
        }
        ws.onclose = function(){
            log("WebSocketByOrderData onclose")
        }
        var timer = setInterval(()=>{
            log("WebSocketOrderData keep alive")
            ws.send("心跳数据");
            
        },50*1000)
        timerList.push(timer);
    } else {
        alert("抱歉，您的浏览器不支持Websocket，无法接收服务器发过来的推送消息")
    }
}
//全局告警websocket
function initWebSocketByAll(pageContext) {
    var websocketUrl = EnvironmentUtils.getEnvironment().WEBSOCKET_URL + (EnvironmentUtils.getEnvironment().isIpUrl ? "" : "message/");
    // websocketUrl="ws://192.168.6.217:8088/"
    //打开一个websocket链接
    if ("WebSocket" in window) {
        var userCode = pageContext.UserMgr.getUserInfo().userCode;
        var token = pageContext.UserMgr.getUserInfo().token;
        var ws = new WebSocket(websocketUrl + "websocket/deviceOrderAlarm?userCode=" + userCode + "&token=" + token)
        log(websocketUrl+"websocket/deviceOrderAlarm")
        ws.onmessage = function (event) {
            var receivedMsg = event.data;
            log("initWebSocketByOrderAlarm receivedMsgAll==" + receivedMsg)
            if (pageContext) {
                pageContext.EventBus.post("receivedMsgAll", receivedMsg);
            } else {
                alert("初始化websocket请传入pageContext")
            }
        }
        ws.onopen = function () {
            log("initWebSocketByOrderAlarm onopen")
        }
        ws.onclose = function(){
            // setTimeout(()=>{
            //     initWebSocketByAll(pageContext);
            // },50*1000)
            log("OrderAlarm onclose")
        }
        setInterval(()=>{
            log("WebSocketOrderAlarm keep alive")
            ws.send("心跳数据");
        },50*1000)
    } else {
        alert("抱歉，您的浏览器不支持Websocket，无法接收服务器发过来的推送消息")
    }
}
function closeWebSocket(){
    if(ws){
        ws.close();
        ws = null;
    }
}
function clearTimers(){
    timerList.forEach(timer=>{
        clearInterval(timer);
    })
    timerList = [];
}
function send(msg) {
    if (ws) {
        ws.send(msg)
    }

}
function close() {
    if (ws) {
        ws.close();
    }
}
export default {
    initWebSocket, initWebSocketBySmart, initWebSocketByAll,closeWebSocket
}