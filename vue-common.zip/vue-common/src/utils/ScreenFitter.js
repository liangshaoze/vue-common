import Vue from 'vue'
export function isPC () {
    let flag = window.navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i)
    if(flag){
        return false;
    }
    return true;
}
export function className(pcStyle,otherStyle){
   var obj={}
   var pc=isPC();
   obj[pcStyle]=pc;
   obj[otherStyle]=!pc
   return obj;
}
export function style(val){
    var styleObj={}
    var rate=window.innerWidth/1024;
    for(var field in val){
        if(val[field]&&(typeof val[field] == 'number')){
            styleObj[field]=val[field]*rate+"px";
        }else{
            styleObj[field]=val[field];
        }
    }
    return styleObj;
}

export default {isPC,className,style}