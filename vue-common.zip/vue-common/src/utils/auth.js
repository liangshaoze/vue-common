const TokenKey = 'Admin-Token'
const UserCode = 'UserCode'
const UserName = "UserName"
const UserPhone = "UserPhone"
const UserLoginType = "UserLoginType"

export function getToken() {
  let userCode = "";
  if(getUserCode()){
    userCode = getUserCode()
  }
  return localStorage.getItem(TokenKey+userCode)
}

export function setToken(token,userCode) {
  return localStorage.setItem(TokenKey+userCode, token)
}

export function removeToken() {
  return localStorage.removeItem(TokenKey)
}

export function getUserCode() {
  return localStorage.getItem(UserCode)
}

export function setUserCode(code) {
  sessionStorage.setItem(UserCode,code)
  return localStorage.setItem(UserCode, code)
}

export function removeUserCode() {
  return localStorage.removeItem(UserCode)
}
export function getUserName() {
  return localStorage.getItem(UserName)
}

export function setUserName(userName) {
  return localStorage.setItem(UserName, userName)
}
export function getUserPhone() {
  return localStorage.getItem(UserPhone)
}

export function setUserPhone(userPhone) {
  return localStorage.setItem(UserPhone, userPhone)
}
export function getUserLoginType() {
  return localStorage.getItem(UserLoginType)
}

export function setUserLoginType(userLoginType) {
  return localStorage.setItem(UserLoginType, userLoginType)
}