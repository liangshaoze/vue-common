<!--页面间通信-->
<script>
import Vue from 'vue'
const EventBus = new Vue();
window.EventBus = EventBus;
const post= function(eventName,params){
  EventBus.$emit(eventName,params)
}
const handleEvent=function(eventName,callBack){
  EventBus.$on(eventName,function(val){
    callBack(val);
  })
}
const off=function(eventName){
  EventBus.$off(eventName);
}
export default {EventBus,handleEvent,post,off}
</script>