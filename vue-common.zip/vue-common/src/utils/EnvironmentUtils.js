import request from 'utils/request'
const LATEST_ENVIRONMENT = "latest_environment"
const LAST_URL = "last_url"//上一次填写的url
const enviromentConfig = {
    dev: {
        NODE_ENV: '"development"',
        ENV_CONFIG: '"dev"',
        BASE_API: 'http://localhost:9528',
        UPLOAD_API: 'http://localhost:9528"',
        WEBSOCKET_URL: 'wss://test.zhaohu365.com/api/',
        isIpUrl:false,
    },
    pre: {
        NODE_ENV: '"pre"',
        ENV_CONFIG: '"pre"',
        BASE_API: 'http://test.zhaohu365.com/api/',
        UPLOAD_API: 'http://test.zhaohu365.com/api/',
        WEBSOCKET_URL: 'wss://test.zhaohu365.com/api/',
        isIpUrl:false,
    },
    prod: {
        NODE_ENV: '"production"',
        ENV_CONFIG: '"prod"',
        BASE_API: 'https://www.zhaohu365.com/api/',
        UPLOAD_API: 'https://www.zhaohu365.com/api/',
        WEBSOCKET_URL: 'wss://www.zhaohu365.com/api/',
        isIpUrl:false,
    }
}
function initEnvironment(){
    var environment={};
    var env = sessionStorage.getItem(LATEST_ENVIRONMENT);
    if(env){
        return;
    }
    if(process.env.NODE_ENV === 'development'){
        environment = enviromentConfig.dev;
    }else if(process.env.NODE_ENV === 'pre'){
        environment = enviromentConfig.pre;
    }else if(process.env.NODE_ENV === 'production'){
        environment = enviromentConfig.prod;
    }
    sessionStorage.setItem(LATEST_ENVIRONMENT,JSON.stringify(environment));
    
}
function getEnvironment(){
    var environment = {};
    var env = sessionStorage.getItem(LATEST_ENVIRONMENT);
    if(env){
        environment = JSON.parse(env);
    }else{
        environment.BASE_API = process.env.NODE_ENV === 'development' ? '/apis' : process.env.BASE_API;
        environment.WEBSOCKET_URL = process.env.WEBSOCKET_URL;
        environment.isIpUrl = false;
    }
    var lastUrl = localStorage.getItem(LAST_URL)
    if(lastUrl){
        environment.lastUrl= lastUrl;
    }
    return environment;
}
function changeEnvironment(url){
    var environment = JSON.parse(JSON.stringify(enviromentConfig.dev));
    environment.BASE_API = "http://"+url+"/";
    environment.WEBSOCKET_URL = "wss://"+url+"/";
    environment.isIpUrl = true;
    sessionStorage.setItem(LATEST_ENVIRONMENT,JSON.stringify(environment));
    localStorage.setItem(LAST_URL,url);
    request.defaults.baseURL=environment.BASE_API;
    alert("环境已切换至："+environment.BASE_API)
}
function dev(){
    var environment = JSON.parse(JSON.stringify(enviromentConfig.dev)); 
    environment.BASE_API = process.env.NODE_ENV === 'development' ? '/apis' : process.env.BASE_API;
    sessionStorage.setItem(LATEST_ENVIRONMENT,JSON.stringify(environment));
    request.defaults.baseURL=environment.BASE_API;
    alert("环境已切换至："+environment.BASE_API+" websocket:"+environment.WEBSOCKET_URL)
}
function pre(){
    var environment = enviromentConfig.pre; 
    sessionStorage.setItem(LATEST_ENVIRONMENT,JSON.stringify(environment));
}
function prod(){
    var environment = enviromentConfig.prod; 
    sessionStorage.setItem(LATEST_ENVIRONMENT,JSON.stringify(environment));
}

export default {
    initEnvironment,
    getEnvironment,
    changeEnvironment,
    dev,
    pre,
    prod,
}