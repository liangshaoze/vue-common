/**
 * Created by jiachenpan on 16/11/18.
 */
/**
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

/* 是否手机号码*/
export function validateTel(rule, value, callback) {
  const reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
  const telReg = /^(0\d{2,3}-\d{7,8})$/;//固定电话
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if (value != '' && (reg.test(value) || telReg.test(value))) {
      callback()
    } else {
      callback(new Error('号码格式不正确或者位数不正确'))
    }
  }
}
/* 是否手机号码*/
export function validateCellPhone(rule, value, callback) {
  const reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if (value != '' && (reg.test(value))) {
      callback()
    } else {
      callback(new Error('号码格式不正确或者位数不正确'))
    }
  }
}

/* 是否身份证号码*/
// export function validateIdCard(rule, value, callback) {
//   const reg = /^[1-9][0-9]{5}([1][9][0-9]{2}|[2][0][0|1][0-9])([0][1-9]|[1][0|1|2])([0][1-9]|[1|2][0-9]|[3][0|1])[0-9]{3}([0-9]|[X]|[x])$/
//   // eslint-disable-next-line eqeqeq
//   if (value == '' || value == undefined || value == null) {
//     callback()
//   } else {
//     // eslint-disable-next-line eqeqeq
//     if ((!reg.test(value)) && value != '') {
//       callback(new Error('请输入正确的身份证号码'))
//     } else {
//       callback()
//     }
//   }
// }
/* 是否身份证号码 带X*/

export function validateIdNo(rule, value, callback) {
  const reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    if ((!reg.test(value)) && value != '') {
      callback(new Error('请输入正确的身份证号码'))
    } else {
      callback()
    }
  }
}
/* 校验输入是否是数字 */
export function isNumber(rule, value, callback) {
  const reg = /^(0|-?[1-9]\d*)\b/gm
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('请输入数字'))
    } else {
      callback()
    }
  }
}

/* 校验输入中文 */
export function chineseName(rule, value, callback) {
  const reg = /^[\u4E00-\u9FA5]{1,}$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('请输入中文'))
    } else {
      callback()
    }
  }
}

/* 校验输入金额 */
export function isMoney(rule, value, callback) {
  const reg = /^([1-9]\d{0,11}|0)([.]?|(\.\d{1,2})?)$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      if (value.length > 12) {
        console.log(value.length)
        callback(new Error('输入的金额过大'))
      } else {
        callback(new Error('请输入正确的金额'))
      }
    } else {
      callback()
    }
  }
}

/* 校验输入注册资本 */
export function isRegisterCapital(rule, value, callback) {
  const reg = /^([1-9]\d{0,6}|0)([.]?|(\.\d{1,4})?)$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      if (value.length > 11) {
        console.log(value.length)
        callback(new Error('输入的金额过大'))
      } else {
        callback(new Error('请输入正确的金额'))
      }
    } else {
      callback()
    }
  }
}

/* 密码至少包含 数字和英文，长度6-20*/
export function validatePassword(rule, value, callback) {
  const reg = /^[0-9A-Za-z]{6,20}$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if (!reg.test(value) && value != '') {
      if (value.length > 20 || value.length < 6) {
        callback(new Error('请输入至少包含数字或英文，长度6-20位的密码'))
      } else {
        callback(new Error('请输入正确的密码'))
      }
    } else {
      callback()
    }
  }
}

/* 校验输入邮箱 */
export function validateEmail(rule, value, callback) {
  const reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('邮箱格式不正确'))
    } else {
      callback()
    }
  }
}

/* 校验输入服务时长 */
export function validateServiceTime(rule, value, callback) {
  const reg = /^(([0-9]|1[0-9]|2[0-3])(\.\d{1,2})?|24)$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('服务时长不正确'))
    } else {
      callback()
    }
  }
}
/* 校验输入工单服(务时长 */
export function validateOrderTime(rule, value, callback) {
  const reg = /^(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,2})))$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('服务时长不正确'))
    } else {
      callback()
    }
  }
}
/* 校验输入生出年月日 */
export function validateBirthDay(rule, value, callback) {
  const reg = /^((19[2-9]\d{1})|(20(([0-9][0-9]))))\-((0?[1-9])|(1[0-2]))\-((0?[1-9])|([1-2][0-9])|30|31)$/
  // eslint-disable-next-line eqeqeq
  if (value == '' || value == undefined || value == null) {
    callback()
  } else {
    // eslint-disable-next-line eqeqeq
    if ((!reg.test(value)) && value != '') {
      callback(new Error('日期格式不正确'))
    } else {
      callback()
    }
  }
}

/* 年龄校验 */

export function validateAge(rule, value, callback) {
  let reg = /^(?:[1-9][0-9]?|1[01][0-9]|120)$/;//年龄是1-120之间有效
  if (value == '' || value == undefined || value == null) {
    callback();
  } else {
    if (!reg.test(value)) {
      callback([new Error('年龄输入不合法')]);
    } else {
      callback();
    }
  }
}


/*
根据〖中华人民共和国国家标准 GB 11643-1999〗中有关公民身份号码的规定，公民身份号码是特征组合码，由十七位数字本体码和一位数字校验码组成。排列顺序从左至右依次为：六位数字地址码，八位数字出生日期码，三位数字顺序码和一位数字校验码。
    地址码表示编码对象常住户口所在县(市、旗、区)的行政区划代码。
    出生日期码表示编码对象出生的年、月、日，其中年份用四位数字表示，年、月、日之间不用分隔符。
    顺序码表示同一地址码所标识的区域范围内，对同年、月、日出生的人员编定的顺序号。顺序码的奇数分给男性，偶数分给女性。
    校验码是根据前面十七位数字码，按照ISO 7064:1983.MOD 11-2校验码计算出来的检验码。
出生日期计算方法。
    15位的身份证编码首先把出生年扩展为4位，简单的就是增加一个19或18,这样就包含了所有1800-1999年出生的人;
    2000年后出生的肯定都是18位的了没有这个烦恼，至于1800年前出生的,那啥那时应该还没身份证号这个东东，⊙﹏⊙b汗...
下面是正则表达式:
 出生日期1800-2099  (18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])
 身份证正则表达式 /^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i            
 15位校验规则 6位地址编码+6位出生日期+3位顺序号
 18位校验规则 6位地址编码+8位出生日期+3位顺序号+1位校验位
 
 校验位规则     公式:∑(ai×Wi)(mod 11)……………………………………(1)
                公式(1)中： 
                i----表示号码字符从由至左包括校验码在内的位置序号； 
                ai----表示第i位置上的号码字符值； 
                Wi----示第i位置上的加权因子，其数值依据公式Wi=2^(n-1）(mod 11)计算得出。
                i 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
                Wi 7 9 10 5 8 4 2 1 6 3 7 9 10 5 8 4 2 1
*/
//身份证号合法性验证 
//支持15位和18位身份证号
//支持地址编码、出生日期、校验位验证
export function validateIdCard(rule, value, callback) { 
  var city={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江 ",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北 ",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏 ",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外 "};
  var tip="";
  var pass= true;
  
  if(!value || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(value)){
      tip = "身份证号格式错误";
      pass = false;
  }
  
 else if(!city[value.substr(0,2)]){
      tip = "身份证号格式错误";
      pass = false;
  }
  else{
      //18位身份证需要验证最后一位校验位
      if(value.length == 18){
        value = value.split('');
          //∑(ai×Wi)(mod 11)
          //加权因子
          var factor = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
          //校验位
          var parity = [ 1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2 ];
          var sum = 0;
          var ai = 0;
          var wi = 0;
          for (var i = 0; i < 17; i++)
          {
              ai = value[i];
              wi = factor[i];
              sum += ai * wi;
          }
          var last = parity[sum % 11];
          if(parity[sum % 11] != value[17]){
              tip = "身份证号格式错误";
              pass =false;
          }
      }
  }
  if(!pass) {
    callback([new Error(tip)]);
  } else {
    callback()
  }
}