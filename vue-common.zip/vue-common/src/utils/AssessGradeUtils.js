/**
 * 
 *评估等级计算服务次数
  目前只有上海长护险的
 */
export function getServiceCountByGrade(assessGrade) {
    if (assessGrade === "二级" ||assessGrade === "三级") {
        return 3;
    }else if(assessGrade === "四级"){
        return 5;
    }else if(assessGrade === "五级" ||assessGrade === "六级"){
        return 7;
    }
  }