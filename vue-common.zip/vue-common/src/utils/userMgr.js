import Vue from 'vue'
const TokenKey = 'Admin-Token'
const LAST_LOGIN_USERINFO = 'LAST_LOGIN_USERINFO'
const UserLoginType = "UserLoginType"
const LOGGED_USERS = "logged_users"
const USERINFO = {
    "source": "",
    "token": "",
    "userCode": "",
    "userFullName": "",
    "userGender": "0",
    "password": "",
    "userTel": "",
    "userIdCard": "",
    "userStatus": "",
    "userOrgCode": "",
    "userOrgName": "",
    "dataAuthoritySql": "",
    "allottedTime": 0
}
export function loginIn(userInfo,loginName){
    let usersItemName = LOGGED_USERS+process.env.NODE_ENV;
    Vue.set(userInfo,"isLogin",true);
    Vue.set(userInfo,"loginName",loginName);
    sessionStorage.setItem(LAST_LOGIN_USERINFO,JSON.stringify(userInfo));
    let users = JSON.parse(localStorage.getItem(usersItemName));
    if(!users){
        users = [];
        users.push(userInfo);
    }else{
        //重置登录状态
        users.forEach(item=>{
            item.isLogin = false;
        })
        let user = users.find(item => {
            return item.userCode == userInfo.userCode;
        });
        if(user){
            user.isLogin = true;
            user.loginName = loginName;
            user.token = userInfo.token;
        }else{
            users.push(userInfo);
        }
    }
    localStorage.setItem(usersItemName,JSON.stringify(users));
}
export function logOut(){
    let usersItemName = LOGGED_USERS+process.env.NODE_ENV;
    let users = JSON.parse(localStorage.getItem(usersItemName));
    users.forEach(item =>{
        item.isLogin = false;
    })
    localStorage.setItem(usersItemName,JSON.stringify(users));
}

export function getUserInfo() {
    let usersItemName = LOGGED_USERS+process.env.NODE_ENV;
    let sessionUserInfo = JSON.parse(sessionStorage.getItem(LAST_LOGIN_USERINFO))
    let users = JSON.parse(localStorage.getItem(usersItemName));
    if(users instanceof Array){
        let userInfo =users.find((item)=>{//已登录用户
            return item.isLogin == true;
        })
        if(userInfo){
            if(sessionUserInfo&&sessionUserInfo.userCode!=userInfo.userCode){
                return USERINFO
            }
            return userInfo;
        }
       
    }
  return USERINFO
}
export default{
    getUserInfo
}