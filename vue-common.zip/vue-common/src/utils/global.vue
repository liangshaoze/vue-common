<script>
const requestErrorMsg = "访问网络错误"
export default
  {
    requestErrorMsg
  }
</script>