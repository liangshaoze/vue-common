import request from 'utils/request'
/**
 * 查询评估版本
 * @param {*} data 请求参数
 */
export function findEtAssessList(data) {
  return request({
    url: '/fsk-erp-trade/assess/findEtAssessList',
    method: 'post',
    data
  })
}

/**
 * 评估指派
 * @param {*} data 请求参数
 */
export function batchInsertAssessOrder(data) {
    return request({
      url: '/fsk-erp-trade/order/batchInsertAssessOrder',
      method: 'post',
      data
    })
  }
  
