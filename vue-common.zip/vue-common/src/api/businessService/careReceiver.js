import request from 'utils/request'
/**
 * 查询被照护人列表
 * @param {*} data 请求参数
 */
export function findEtCareReceiverList(data) {
    return request({
        url: '/fsk-erp-trade/careReceiver/findEtCareReceiverList',
        method: 'post',
        data
    })
}

/**
 * 新增被照护人
 * @param {*} data 请求参数
 */
export function insertEtCareReceiverAll(data) {
    return request({
        url: '/fsk-erp-trade/careReceiver/insertEtCareReceiverAll',
        method: 'post',
        data
    })
} 

/**
 * 修改被照护人
 * @param {*} data 请求参数
 */
export function editEtCareReceiverAll(data) {
    return request({
        url: '/fsk-erp-trade/careReceiver/editEtCareReceiverAll',
        method: 'post',
        data
    })
} 

/**
 * 查询被照护人详情
 * @param {*} data 请求参数
 */
export function findCareReceiver(data) {
    return request({
        url: '/fsk-erp-trade/careReceiver/findCareReceiver',
        method: 'post',
        data
    })
}

/**
 * 查询我的被照护人列表
 * @param {*} data 请求参数
 */
export function findEtCareReceiverListByCreateCode(data) {
    return request({
        url: '/fsk-erp-trade/careReceiver/findEtCareReceiverListByCreateCode',
        method: 'post',
        data
    })
}
