import request from 'utils/request'
/**
 * 查询员工排程
 * @param {*} data 请求参数
 */
export function findWorkorderScheduleByCareGiverCode(data) {
    return request({
      url: '/fsk-workorder/workorderScheduleResult/findWorkorderScheduleByCareGiverCode',
      method: 'post',
      data
    })
  }
  /**
 * 获取排程员工
 * @param {*} data 请求参数
 */
export function selectGiverListForSchedule(data) {
    return request({
      url: '/fsk-ehr/staff/selectGiverListForSchedule',
      method: 'post',
      data
    })
  }
  /**
 * 获取被照护人信息
 * @param {*} data 请求参数
 */
export function getEtCareReceiver(data) {
  return request({
    url: '/fsk-erp-trade/careReceiver/getEtCareReceiver',
    method: 'post',
    data
  })
}