
import request from 'utils/request'
/**
 * 订单支付审核列表
 * @param {*} data 请求参数
 */
export function findProductOrderFeeAuditList(data) {
  return request({
    url: '/fsk-erp-trade/productOrderFee/findProductOrderFeeAuditList',
    method: 'post',
    data
  })
}
/**
 * 订单支付审核
 * @param {*} data 请求参数
 */
export function updateMsProductOrderFeeForAudit(data) {
  return request({
    url: '/fsk-erp-trade/productOrderFee/updateMsProductOrderFeeForAudit ',
    method: 'post',
    data
  })
}

/**
 * 订单列表
 * @param {*} data 请求参数
 */
export function findProductOrderList(data) {
  return request({
    url: '/fsk-erp-trade/order/findProductOrderList',
    method: 'post',
    data
  })
}

/**
 * 取消订单
 * @param {*} data 请求参数
 */
export function updateProductOrderForCancel(data) {
  return request({
    url: '/fsk-erp-trade/order/updateProductOrderForCancel',
    method: 'post',
    data
  })
}
/**
 * 服务确认
 * @param {*} data 请求参数
 */
export function updateProductOrderForPay(data) {
  return request({
    url: '/fsk-erp-trade/order/updateProductOrderForPay',
    method: 'post',
    data
  })
}

/**
 * 查看退款单/查看差价单
 * @param {*} data 请求参数
 */
export function findFeeListByOrderCode(data) {
  return request({
    url: '/fsk-erp-trade/order/findFeeListByOrderCode',
    method: 'post',
    data
  })
}
/**
 * 退款/补差价
 * @param {*} data 请求参数
 */
export function insertOrderFee(data) {
  return request({
    url: '/fsk-erp-trade/order/insertOrderFee',
    method: 'post',
    data
  })
}
/**
 * 服务完成
 * @param {*} data 请求参数
 */
export function updateProductOrderForOverord(data) {
  return request({
    url: '/fsk-erp-trade/order/updateProductOrderForOver',
    method: 'post',
    data
  })
}

/**
 * 线下订单审核
 * @param {*} data 请求参数
 */
export function updateEtProductOrderFeeForAudit(data) {
  return request({
    url: '/fsk-erp-trade/productOrderFee/updateEtProductOrderFeeForAudit',
    method: 'post',
    data
  })
}


/**
 * 服务开启
 * @param {*} data 请求参数
 */
export function updateServiceOn(data) {
  return request({
    url: '/fsk-erp-trade/order/updateServiceOn',
    method: 'post',
    data
  })
}


/**
 * 服务暂停
 * @param {*} data 请求参数
 */
export function updateServiceSuspension(data) {
  return request({
    url: '/fsk-erp-trade/order/updateServiceSuspension',
    method: 'post',
    data
  })
}
/**
 * 服务完成
 * @param {*} data 请求参数
 */
export function updateServiceComplete(data) {
  return request({
    url: '/fsk-erp-trade/order/updateServiceComplete',
    method: 'post',
    data
  })
}
/**
 * 批量导入
 * @param {*} data 请求参数
 */
export function importWorkOrder(data) {
  return request({
    url: 'fsk-erp-trade/order/importOrder',
    method: 'post',
    data
  })
}
/**
 * 订单生效
 * @param {*} data 请求参数
 */
export function updateServiceStatusEffective(data) {
  return request({
    url: '/fsk-erp-trade/order/updateServiceStatusEffective',
    method: 'post',
    data
  })
}

/**
 * 获取被照护人排程列表
 * @param {*} data 请求参数
 */
export function findWorkorderSchedule(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/findWorkorderScheduleByCareReceiverCode',
    method: 'post',
    data
  })
}

/**
 * 新增排程
 * @param {*} data 请求参数
 */
export function addWorkorderSchedule(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/addWorkorderSchedule',
    method: 'post',
    data
  })
}

/**
 * 修改排程
 * @param {*} data 请求参数
 */
export function editWorkorderSchedule(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/editWorkorderSchedule',
    method: 'post',
    data
  })
}

/**
 * 删除排程
 * @param {*} data 请求参数
 */
export function deleteWorkorderSchedule(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/deleteWorkorderSchedule',
    method: 'post',
    data
  })
}


/**
 * 批量删除护理员排程
 * @param {*} data 请求参数
 */
export function deleteByCareGiverCode(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/deleteWorkorderScheduleByCareGiverCode',
    method: 'post',
    data
  })
}

/**
 * 批量删除被照护人排程
 * @param {*} data 请求参数
 */
export function deleteByCareReceiverCode(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/deleteWorkorderScheduleByCareReceiverCode',
    method: 'post',
    data
  })
}

/**
 * 更换订单组织
 * @param {*} data 请求参数
 */
export function editOrderOrgByOrderCode(data) {
  return request({
    url: '/fsk-erp-trade/order/editOrderOrgByOrderCode',
    method: 'post',
    data
  })
}
/**
 * 修改评估等级
 * @param {*} data 请求参数
 */
export function editAssessGradeByOrderCode(data) {
  return request({
    url: '/fsk-erp-trade/order/editAssessGradeByOrderCode',
    method: 'post',
    data
  })
}

/**
 * 根据组织查产品
 * @param {*} data 请求参数
 */
export function findEtProductByDataAuthority(data) {
  return request({
    url: 'fsk-erp-trade/etProduct/findEtProductByDataAuthority',
    method: 'post',
    data
  })
}
 /**
 * 服务项查询
 * @param {*} data
 */
export function selectProductOrderServiceList(data) {
  return request({
    url: 'fsk-erp-trade/order/selectProductOrderServiceList',
    method: 'post',
    data
  })
}
