import request from 'utils/request'
/**
 * 智慧监护
 * 查询订单列表
 * @param {*} data 请求参数
 */
export function findDeviceOrderList(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/findDeviceOrderList',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 新增设备订单
 * @param {*} data 请求参数
 */
export function insertDeviceOrder(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/insertDeviceOrder',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 修改设备订单
 * @param {*} data 请求参数
 */
export function editDeviceOrder(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/editDeviceOrder',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单详情
 * @param {*} data 请求参数
 */
export function getDeviceOrderDetail(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/getDeviceOrderDetail',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-取消订单
 * @param {*} data 请求参数
 */
export function cancelDeviceOrder(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/cancelDeviceOrder',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-订单生效
 * @param {*} data 请求参数
 */
export function editDeviceOrderTakesEffect(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/editDeviceOrderTakesEffect',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-订单确认
 * @param {*} data 请求参数
 */
export function editDeviceOrderCompleted(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/editDeviceOrderCompleted',
    method: 'post',
    data
  })
}
/**
 * 智慧监护
 * 智能监护列表
 * @param {*} data 请求参数
 */
export function findIotList(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/findDeviceList',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-新增设备
 * @param {*} data 请求参数
 */
export function insertDeviceOrderItem(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/insertDeviceOrderItem',
    method: 'post',
    data
  })
}
/**
 * 智慧监护
 * 通过设备分类获取订单设备
 * @param {*} data 请求参数
 */
export function findOrderDeviceByClass(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/findOrderDeviceByClass',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-修改设备
 * @param {*} data 请求参数
 */
export function editDeviceOrderItem(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/editDeviceOrderItem',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-绑定设备
 * @param {*} data 请求参数
 */
export function bindDeviceInfo(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/bindDeviceInfo',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-解绑设备
 * @param {*} data 请求参数
 */
export function unBindDeviceInfo(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/unBindDeviceInfo',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 获取设备消息类型
 * @param {*} data 请求参数
 */
export function getDeviceMessageType(data) {
  return request({
    url: 'iot/deviceModel/getDeviceMessageType',
    method: 'post',
    data
  })
}

/**
 * 智慧监护
 * 设备订单列表-修改设备
 * @param {*} data 请求参数
 */
export function deleteDeviceOrderItem(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/deleteDeviceOrderItem',
    method: 'post',
    data
  })
}
/**
 * 智慧监护
 * 设备数据列表（药箱，烟感，燃气，跌倒）
 * @param {*} data 请求参数
 */
export function findDeviceOrderDataByNo(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrderData/findDeviceOrderDataByNo',
    method: 'post',
    data
  })
}
/**
 * 智慧监护
 * 设备订单列表-设置接口
 * @param {*} data 请求参数
 */
export function findDeviceSettingByOrderCode(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrder/findDeviceSettingByOrderCode',
    method: 'post',
    data
  })
}

/**
 * 药箱服药信息
 * 设备订单列表-设置接口
 * @param {*} data 请求参数
 */
export function getMedicineInfo(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrderData/getMedicineInfo',
    method: 'post',
    data
  })
}
/**
 * 查询未解决的告警信息数量
 * @param {*} data 请求参数
 */
export function selectAlarmCountByUer(data) {
  return request({
    url: 'fsk-erp-trade/deviceOrderAlarm/selectAlarmCountByUer',
    method: 'post',
    data
  })
}





