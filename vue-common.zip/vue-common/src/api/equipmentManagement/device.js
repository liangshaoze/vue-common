import request from 'utils/request'
/**
 * 智慧监护
 * 设备列表
 * @param {*} data 请求参数
 */
export function findDevice (data) {
    return request({
        url: 'iot/device/findDevice',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 设备新增
 * @param {*} data 请求参数
 */
export function addDevice (data) {
    return request({
        url: 'iot/device/addDevice',
        method: 'post',
        data
    })
}
/**
 * 
 * 查询所有设备设置接口
 * @param {*} data 请求参数
 */
export function findDeviceSettingByOrderCode (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrder/findDeviceSettingByOrderCode',
        method: 'post',
        data
    })
}
/**
 * 
 * 编辑所有设备设置接口
 * @param {*} data 请求参数
 */
export function editDeviceConfig (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrder/editDeviceConfig',
        method: 'post',
        data
    })
}
/**
 * 智慧监护
 * 设备修改
 * @param {*} data 请求参数
 */
export function updateDevice (data) {
    return request({
        url: 'iot/device/updateDevice',
        method: 'post',
        data
    })
}

/**
* 智慧监护
* 设备删除
* @param {*} data 请求参数
*/
export function delDeviceByDeviceCode (data) {
    return request({
        url: 'iot/device/delDeviceByDeviceCode',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 设备历史记录
 * @param {*} data 请求参数
 */
export function findDeviceRecord (data) {
    return request({
        url: 'iot/device/findDeviceRecord',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 设备原始数据
 * @param {*} data 请求参数
 */
export function findDeviceData (data) {
    return request({
        url: 'iot/device/findDeviceData',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 根据类型查询设备code
 * @param {*} data 请求参数
 */
export function getDeviceCodeByModelId (data) {
    return request({
        url: 'iot/device/getDeviceCodeByModelId',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 设备类型查询
 * @param {*} data 请求参数
 */
export function findDeviceModel (data) {
    return request({
        url: 'iot/device/findDeviceModel',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 根据设备id查询设备详情
 * @param {*} data 请求参数
 */
export function findDeviceByPrimarykey (data) {
    return request({
        url: 'iot/device/findDeviceByPrimarykey',
        method: 'post',
        data
    })
}

/**
 * 智慧监护
 * 获取跃杨床垫参数
 * @param {*} data 请求参数
 */
export function getYueYangAccountInfo (data) {
    return request({
        url: 'iot/device/getYueYangAccountInfo',
        method: 'post',
        data
    })
}


/**
 * 新增查房记录
 * @param {*} data 请求参数
 */
export function insertDeviceOrderRound (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrder/insertDeviceOrderRound',
        method: 'post',
        data
    })
}
/**
 * 发送查房记录
 * @param {*} data 请求参数
 */
export function addMessage (data) {
    return request({
        url: '/fsk-erp-trade/deviceOrder/addMessage',
        method: 'post',
        data
    })
}
/**
 * 查房列表
 * @param {*} data 请求参数
 */
export function findDeviceOrderRoundList (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrder/findDeviceOrderRoundList',
        method: 'post',
        data
    })
}
/**
 * 查房记录
 * @param {*} data 请求参数
 */
export function getDeviceOrderRound (data) {
    return request({
        url: '/fsk-erp-trade/deviceOrder/getDeviceOrderRound',
        method: 'post',
        data
    })
}

/**
 * 全局告警列表查询
 * @param {*} data 请求参数
 */
export function findDeviceOrderAlarmList (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrderAlarm/findDeviceOrderAlarmList',
        method: 'post',
        data
    })
}
/**
 * 查询告警处理记录详情
 * @param {*} data 请求参数
 */
export function getDeviceOrderAlarm (data) {
    return request({
        url: '/fsk-erp-trade/deviceOrderAlarm/getDeviceOrderAlarm',
        method: 'post',
        data
    })
}
/**
 *添加告警处理
 * @param {*} data 请求参数
 */
export function insertDeviceOrderAlarmRecord (data) {
    return request({
        url: 'fsk-erp-trade/deviceOrderAlarm/insertDeviceOrderAlarmRecord',
        method: 'post',
        data
    })
}


export function findCareReceiverForDevice(data) {
    return request({
      url: 'fsk-erp-trade/deviceOrder/findCareReceiverForDevice',
      method: 'post',
      data
    })
  }