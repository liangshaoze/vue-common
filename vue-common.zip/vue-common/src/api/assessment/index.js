import request from 'utils/request'
/**
 * 查询评估版本
 * @param {*} data 请求参数
 */
export function findEtAssessList(data) {
  return request({
    url: '/fsk-erp-trade/assess/findEtAssessList',
    method: 'post',
    data
  })
}

/**
 * 评估报告列表
 * @param {*} data 请求参数
 */
export function findAssessOrderList(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/findAssessOrderList',
    method: 'post',
    data
  })
}

/**
 * 我的评估列表
 * @param {*} data 请求参数
 */
export function findMyAssessOrder(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/findMyAssessOrder',
    method: 'post',
    data
  })
}
/**
 * 列表去评估
 * @param {*} data 请求参数
 */
export function startAssessByCode(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/startAssessByCode',
    method: 'post',
    data
  })
}

/**
 * 评估基本信息保存
 * @param {*} data 请求参数
 */
export function editAssessOrder(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/editAssessOrder',
    method: 'post',
    data
  })
}

/**
 * 获取评估表信息
 * @param {*} data 请求参数
 */
export function getAssessOrderForm(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/getAssessOrderForm',
    method: 'post',
    data
  })
}

/**
 * 获取评估订单表信息
 * @param {*} data 请求参数
 */
export function getFormInfoByFormId(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/getFormInfoByFormId',
    method: 'post',
    data
  })
}

/**
 * 提交评估信息
 * @param {*} data 请求参数3
 */
export function saveAssessOrderTitle(data) {
  return request({
    url: '/fsk-erp-trade/assessOrderTitle/saveAssessOrderTitle',
    method: 'post',
    data
  })
}

/**
 * 获取评估报告信息
 * @param {*} data 请求参数
 */
export function getAssessReport(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/getAssessReport',
    method: 'post',
    data
  })
}
/**
 * 提交评估建议
 * @param {*} data 请求参数
 */
export function addSuggest(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/addSuggest',
    method: 'post',
    data
  })
}
/**
 * 评估完成生成报告
 * @param {*} data 请求参数
 */
export function addAssessReport(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/addAssessReport',
    method: 'post',
    data
  })
}
/**
 * 评估完成底部
 * @param {*} data 请求参数
 */
export function getAssessOrderByCode(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/getAssessOrderByCode',
    method: 'post',
    data
  })
}
/**
 * 同步定位信息
 * @param {*} data 请求参数
 */
export function editPositioningInfo(data) {
  return request({
    url: '/fsk-erp-trade/assessOrder/editPositioningInfo',
    method: 'post',
    data
  })
}

/**
 * 评估-药品搜索
 * @param {*} data 请求参数
 */
export function findMedicine(data) {
  return request({
    url: '/fsk-system/medicineWarehouse/findMedicine',
    method: 'post',
    data
  })
}
/**
 * 评估-修改评估报告信息
 * @param {*} data 请求参数
 */
export function editAssessTitleOrder(data) {
  return request({
    url: '/fsk-erp-trade/assessTitleOrder/editAssessTitleOrder',
    method: 'post',
    data
  })
}
/**
 * 评估-删除评估报告信息
 * @param {*} data 请求参数
 */
export function delAssessTitleOrder(data) {
  return request({
    url: '/fsk-erp-trade/assessTitleOrder/delAssessTitleOrder',
    method: 'post',
    data
  })
}
/**
 * 评估-评估服务项搜索
 * @param {*} data 请求参数
 */
export function findAssessService(data) {
  return request({
    url: '/fsk-erp-trade/assessService/findAssessService',
    method: 'post',
    data
  })
}

