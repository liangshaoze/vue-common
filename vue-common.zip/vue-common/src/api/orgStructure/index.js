import request from 'utils/request'

/**
 * 获取组织架构
 * @param {*} token
 */
export function findEhrOrgList(data) {
  return request({
    url: '/fsk-ehr/org/findEhrOrgList',
    method: 'post',
    data
  })
}

/**
 * 根据orgCode查询节点详情
 * @param {*} orgCode
 */
export function getEhrOrgDetailByCode(data) {
  return request({
    url: '/fsk-ehr/org/getEhrOrgDetailByCode',
    method: 'post',
    data
  })
}

/**
 * 新增下级组织架构
 * @param {*}
 */
export function insertEhrOrg(data) {
  return request({
    url: '/fsk-ehr/org/insertEhrOrg',
    method: 'post',
    data
  })
}

/**
 * 修改当前组织架构
 * @param {*}
 */
export function editEhrOrg(data) {
  return request({
    url: '/fsk-ehr/org/editEhrOrg',
    method: 'post',
    data
  })
}

/**
 * 查询当前组织变更信息
 * @param {*}
 */
export function findEhrOrgChangeRecordList(data) {
  return request({
    url: '/fsk-ehr/orgChangeRecord/findEhrOrgChangeRecordList',
    method: 'post',
    data
  })
}

/**
 * 新增当前组织变更信息
 * @param {*}
 */
export function insertEhrOrgChangeRecord(data) {
  return request({
    url: '/fsk-ehr/orgChangeRecord/insertEhrOrgChangeRecord',
    method: 'post',
    data
  })
}

/**
 * 修改当前组织变更信息
 * @param {*}
 */
export function editEhrOrgChangeRecord(data) {
  return request({
    url: '/fsk-ehr/orgChangeRecord/editEhrOrgChangeRecord',
    method: 'post',
    data
  })
}

/**
 * 删除当前组织变更信息
 * @param {*}
 */
export function deleteEhrOrgChangeRecord(data) {
  return request({
    url: '/fsk-ehr/orgChangeRecord/deleteEhrOrgChangeRecord',
    method: 'post',
    data
  })
}

/**
 * 获取组织架构
 * @param {*} token
 */
export function findEhrOrgAll(data) {
  return request({
    url: '/fsk-ehr/org/findEhrOrgAll',
    method: 'post',
    data
  })
}
