import request from 'utils/request'

/**
 * 登录
 * @param {*} userCode
 * @param {*} password
 * @param {*} loginType
 * @param {*} userTel
 * @param {*} verifyCodeKey
 * @param {*} imageCode
 */
export function login(userCode, password, loginType, userTel, verifyCodeKey, imageCode) {
  const data = {
    userCode,
    password,
    loginType,
    userTel,
    verifyCodeKey,
    imageCode
  }
  return request({
    url: '/fsk-system/sysUser/login',
    method: 'post',
    data
  })
}

/**
 * 获取用户菜单
 * @param {*} userCode
 */
export function getMenu(userCode) {
  const data = {
    userCode
  }
  return request({
    // url: '/fsk-system/sysUserMenu/findSysUserMenusByUserCode',
    url: '/fsk-system/sysUserMenu/findMenusByUser',
    method: 'post',
    data
  })
}

/**
 * 登出
 * @param {*}
 */
export function logout() {
  return request({
    url: '/fsk-system/sysUser/logout',
    method: 'post'
  })
}

/**
 * 获取验证码
 */
export function verifyCode() {
  return request({
    url: '/fsk-system/common/verifyCode',
    method: 'post'
  })
}

