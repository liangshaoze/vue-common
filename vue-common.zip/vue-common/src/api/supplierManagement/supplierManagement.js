import request from 'utils/request'
/**
 * 新增供应商
 * @param {*} data 请求参数
 */
export function saveSupplier(data) {
  return request({
    url: '/fsk-ehr/supplier/insertSupplier',
    method: 'post',
    data
  })
}
/**
 * 修改供应商
 * @param {*} data 请求参数
 */
export function updateSupplier(data) {
  return request({
    url: '/fsk-ehr/supplier/editSupplier',
    method: 'post',
    data
  })
}
/**
 * 查询供应商列表
 * @param {*} data 请求参数
 */
export function querySupplier(data) {
  return request({
    url: '/fsk-ehr/supplier/findSupplierList',
    method: 'post',
    data
  })
}
/**
 * 查询供应商详情
 * @param {*} data 请求参数
 */
export function getSupplierDetail(data) {
  return request({
    url: '/fsk-ehr/supplier/getSupplierDetail',
    method: 'post',
    data
  })
}

