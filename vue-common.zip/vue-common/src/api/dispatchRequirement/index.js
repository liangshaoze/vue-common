import request from 'utils/request'
/**
 *查询派单
 * @param {*} data 请求参数
 */
export function findRecruitNeedList(data) {
  return request({
    url: 'fsk-ehr/recruitNeed/findRecruitNeedList',
    method: 'post',
    data
  })
}

/**
 *新增派单
 * @param {*} data 请求参数
 */
export function addRecruitNeed(data) {
  return request({
    url: 'fsk-ehr/recruitNeed/insertRecruitNeed',
    method: 'post',
    data
  })
}

/**
 *修改派单
 * @param {*} data 请求参数
 */
export function updateRecruitNeed(data) {
  return request({
    url: 'fsk-ehr/recruitNeed/editRecruitNeed',
    method: 'post',
    data
  })
}

/**
 *查询派单详情
 * @param {*} data 请求参数
 */
export function findDispatchDetail(data) {
  return request({
    url: 'fsk-ehr/recruitNeed/getRecruitNeedById',
    method: 'post',
    data
  })
}