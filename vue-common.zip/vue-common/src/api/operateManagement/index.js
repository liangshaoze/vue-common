import request from 'utils/request'
/**
 * 意见反馈列表
 * @param {*} data
 */
export function findCustValueSetList(data) {
  return request({
    url: 'fsk-system-cust/custFeedback/findCustValueSetList',
    method: 'post',
    data
  })
}
/**
 * 处理意见反馈
 * @param {*} data
 */
export function handleCustFeedback(data) {
    return request({
      url: 'fsk-system-cust/custFeedback/handleCustFeedback',
      method: 'post',
      data
    })
  }
  /**
 * 长护险列表
 * @param {*} data
 */
export function findProductApplyList(data) {
  return request({
    url: 'fsk-erp-trade/productApply/findProductApplyList',
    method: 'post',
    data
  })
}
  /**
 * 根据ID查询长护险申请详情
 * @param {*} data
 */
export function getProductApplyById(data) {
  return request({
    url: 'fsk-erp-trade/productApply/getProductApplyById',
    method: 'post',
    data
  })
}
  /**
 * 处理长护险信息
 * @param {*} data
 */
export function editProductApply(data) {
  return request({
    url: 'fsk-erp-trade/productApply/editProductApply',
    method: 'post',
    data
  })
}