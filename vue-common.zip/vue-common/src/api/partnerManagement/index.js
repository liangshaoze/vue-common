import request from 'utils/request'

/**
 * 获取合作商管理列表
 * @param {*} data
 */
export function getPartnerManagementList(data) {
  return request({
    url: '/fsk-ehr/cooperation/findCooperationList',
    method: 'post',
    data
  })
}

/**
 * 新增合作商管理列表
 * @param {*} data
 */
export function addPartnerManagement(data) {
  return request({
    url: '/fsk-ehr/cooperation/insertCooperation',
    method: 'post',
    data
  })
}

/**
 * 编辑合作商管理列表
 * @param {*} data
 */
export function editPartnerManagement(data) {
  return request({
    url: '/fsk-ehr/cooperation/editCooperation',
    method: 'post',
    data
  })
}

/**
 * 查看合作商管理列表
 * @param {*} data
 */
export function getPartnerManagementDetail(data) {
  return request({
    url: '/fsk-ehr/cooperation/getCooperationDetail',
    method: 'post',
    data
  })
}