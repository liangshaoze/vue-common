import request from 'utils/request'
/**
 * 查询所有上架产品
 * @param {*} data
 */
export function findEtProductListForWebQuickSearch(data) {
  return request({
    url: '/fsk-erp-trade/etProduct/findEtProductListForWebQuickSearch',
    method: 'post',
    data
  })
}

/**
 * 查询上架产品详情和规格
 * @param {*} data
 */
export function findProductByCodeForOrder(data) {
    return request({
      url: '/fsk-erp-trade/etProduct/findProductByCodeForOrder',
      method: 'post',
      data
    })
  }

/**
 * 通过身份证查询被照护人信息
 * @param {*} data
 */
export function getCareReceiverAuthority(data) {
  return request({
    url: '/fsk-erp-trade/careReceiver/getCareReceiverAuthority',
    method: 'post',
    data
  })
}

/**
 * 关注被照护人
 * @param {*} data
 */
export function insertCareReceiverAuthority(data) {
  return request({
    url: '/fsk-erp-trade/careReceiverAuthority/insertCareReceiverAuthority',
    method: 'post',
    data
  })
}
/**
 * 查看订单
 * @param {*} data
 */
export function getOrderDetail(data) {
  return request({
    url: '/fsk-erp-trade/order/getOrderDetail',
    method: 'post',
    data
  })
}
/**
 * 修改订单详情的服务信息
 * @param {*} data
 */
export function updateOrderInfoForService(data) {
  return request({
    url: '/fsk-erp-trade/order/updateProductOrder',
    method: 'post',
    data
  })
}
/**
 * 修改订单详情的产品信息
 * @param {*} data
 */
export function updateOrderInfoForProduct(data) {
  return request({
    url: '/fsk-erp-trade/order/updateOrderProduct',
    method: 'post',
    data
  })
}
/**
 * 修改订单详情的被照护人信息
 * @param {*} data
 */
export function updateOrderInfoForCareReceiver(data) {
  return request({
    url: '/fsk-erp-trade/order/updateOrderCareReceiver',
    method: 'post',
    data
  })
}
/**
 * 修改被照护人基本信息
 * @param {*} data
 */
export function updateCareReceiver(data) {
  return request({
    url: '/fsk-erp-trade/order/updateCareReceiver',
    method: 'post',
    data
  })
}
/**
 * 产品查看权限
 * @param {*} data
 */
export function getProductAuthorityCode(data) {
  return request({
    url: '/fsk-ehr/org/getProductAuthorityCode',
    method: 'post',
    data
  })
}

/**
 * 新增线下订单
 * @param {*} data
 */
export function insertEtOffLineProductOrder(data) {
  return request({
    url: '/fsk-erp-trade/order/insertEtOffLineProductOrder',
    method: 'post',
    data
  })
}
/**
 * 根据所选规格获取市场价
 * @param {*} data
 */
export function getProductPriceDetail(data) {
  return request({
    url: '/fsk-erp-trade/productPrice/getProductPriceDetail',
    method: 'post',
    data
  })
}


/**
 * 查询关联订单
 * @param {*} data
 */
export function findRelationEtProductOrder(data) {
  return request({
    url: '/fsk-erp-trade/order/findRelationEtProductOrder',
    method: 'post',
    data
  })
}
/**
 * 修改评估等级(产品规格，’长护险‘类型订单)
 * @param {*} data
 */
export function editAssessGradeByOrderCode(data) {
  return request({
    url: '/fsk-erp-trade/order/editAssessGradeByOrderCode',
    method: 'post',
    data
  })
}
/**
 * 保存产品服务项模板
 * @param {*} data
 */
export function insertProductServiceTemplate(data) {
  return request({
    url: '/fsk-erp-trade/productServiceTemplate/insertProductServiceTemplate',
    method: 'post',
    data
  })
}
/**
 * 查询产品服务项模板
 * @param {*} data
 */
export function findProductServiceTemplate(data) {
  return request({
    url: '/fsk-erp-trade/productServiceTemplate/findProductServiceTemplate',
    method: 'post',
    data
  })
}
/**
 * 删除产品服务项模板
 * @param {*} data
 */
export function deleteProductServiceTemplate(data) {
  return request({
    url: '/fsk-erp-trade/productServiceTemplate/deleteProductServiceTemplate',
    method: 'post',
    data
  })
}
