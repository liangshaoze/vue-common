import request from 'utils/request'

/**
 * 获取省市区接口
 * @param {*} data
 */
export function findAddressDictList(data) {
  return request({
    url: 'fsk-system/common/findAddressDictList',
    method: 'post',
    data
  })
}

/**
 * 获取数据字典接口
 * @param {*} data
 */
export function findValueBySetCode(data) {
  return request({
    url: 'fsk-system/sysValueSet/findValueBySetCode',
    method: 'post',
    data
  })
}
/**
 * 获取数据字典
 * @param {} data 
 */
export function getKeyValuesBySetCode(code, callback) {
  //在职状态
  findValueBySetCode({ valueSetCode: code })
    .then(response => {
      if (response.data.statusCode == "200") {
        callback(response.data.responseData);
      }
    })
    .catch(error => {
      console.log("findValueBySetCode:" + code + "===" + error);
      return false;
    });
}

/**
 * 短信登录接口
 * @param {*} data
 * phone  type(pcLogin)
 */
export function getVerificationCode(data) {
  return request({
    url: 'fsk-system/common/getVerificationCode',
    method: 'post',
    data
  })
}
/**
* 商品属性模糊查询
* @param {*} data
*/
export function findEtProductPropertyValueList(data) {
  return request({
    url: '/fsk-erp-trade/etProductPropertyValue/findEtProductPropertyValueList',
    method: 'post',
    data
  })
}

/**
 * 本组/跨组查询员工
 * @param {*} data 请求参数
 * sideType ( 10本组、20跨组 )
 * pageNum、pageSize、orgCode、staffFullName
 * 
 */
export function selectGiverListForSchedule(data) {
  return request({
    url: '/fsk-ehr/staff/selectGiverListForSchedule',
    method: 'post',
    data
  })
}
/**
* 获取当前服务器时间
* @param {*} data
*/
export function getNow(data) {
  return request({
    url: 'fsk-system/common/getNow',
    method: 'post',
    data
  })
}
// 图片上传到阿里云oss，获取需要的参数3
export function getImageUploadParams(data) {
  return request({
    url: 'fsk-system/oss/getAliOssPolicy',
    method: 'POST',
    data
  })
}