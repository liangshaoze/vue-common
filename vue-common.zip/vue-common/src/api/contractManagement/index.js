import request from 'utils/request'

/**
 * 获取合同管理列表
 * @param {*} data
 */
export function findContractManagementList(data) {
  return request({
    url: 'fsk-ehr/staff/findStaffContractList',
    method: 'post',
    data
  })
}
