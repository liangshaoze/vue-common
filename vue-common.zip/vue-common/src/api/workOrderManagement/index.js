import request from 'utils/request'
/**
 * 工单列表
 * @param {*} data 请求参数
 */
export function findWorkorderListForWeb(data) {
  return request({
    url: 'fsk-workorder/workorder/findWorkorderListForWeb',
    method: 'post',
    data
  })
}

/**
 * 工单详情
 * @param {*} data 请求参数
 */
export function getWorkorderDetail(data) {
    return request({
      url: 'fsk-workorder/workorder/getWorkorderDetail',
      method: 'post',
      data
    })
  }

    /**
 * ：产品列表
 * @param {*} data 请求参数
 */
export function findEtProductByDataAuthority(data) {
  return request({
    url: 'fsk-erp-trade/etProduct/findEtProductByDataAuthority',
    method: 'post',
    data
  })
}
    /**
 * ：
 * @param {*} data 请求参数
 */
export function findInServiceOrderList(data) {
  return request({
    url: 'fsk-erp-trade/order/findInServiceOrderList',
    method: 'post',
    data
  })
}
 /**
 * 服务人员
 * @param {*} data 请求参数
 */
export function selectGiverListForSchedule(data) {
  return request({
    url: 'fsk-ehr/staff/selectGiverListForSchedule',
    method: 'post',
    data
  })
}

  /**
 * 根据产品CODE 客户CODE查询订单信息：
 * @param {*} data 请求参数
 */
export function getOrderByParam(data) {
  return request({
    url: 'fsk-erp-trade/order/getOrderByParam',
    method: 'post',
    data
  })
}
 /**
 * 判断排程时间
 * @param {*} data 请求参数
 */
export function checkWorkOrderEffectiveness(data) {
  return request({
    url: 'fsk-workorder/workorderIn/checkWorkOrderEffectiveness',
    method: 'post',
    data
  })
}
/**
 * 新增工单保存接口
 * @param {*} data 请求参数
 */
export function insertWorkorder(data) {
  return request({
    url: 'fsk-workorder/workorder/insertWorkorder',
    method: 'post',
    data
  })
}
/**
 *删除工单
 * @param {*} data 请求参数
 */
export function deleteWorkorderByCode(data) {
  return request({
    url: 'fsk-workorder/workorder/deleteWorkorderByCode',
    method: 'post',
    data
  })
}
/**
 *工单审核
 * @param {*} data 请求参数
 */
export function editWorkOrderForAudit(data) {
  return request({
    url: 'fsk-workorder/workorder/editWorkOrderForAudit',
    method: 'post',
    data
  })
}

/**
 *工单结算
 * @param {*} data 请求参数
 */
export function editWorkOrderForSettle(data) {
  return request({
    url: 'fsk-workorder/workorder/editWorkOrderForSettle',
    method: 'post',
    data
  })
}
/**
 *工单修改
 * @param {*} data 请求参数
 */
export function editWorkorder(data) {
  return request({
    url: 'fsk-workorder/workorder/editWorkorder',
    method: 'post',
    data
  })
}

/**
 *工单详情修改
 * @param {*} data 请求参数
 */
export function editWorkorderDetail(data) {
  return request({
    url: 'fsk-workorder/workorder/editWorkorderDetail',
    method: 'post',
    data
  })
}


/**
 *批量删除工单
 * @param {*} data 请求参数
 */
export function batchDeleteWorkorderByCode(data) {
  return request({
    url: 'fsk-workorder/workorder/batchDeleteWorkorderByCode',
    method: 'post',
    data
  })
}


/**
 *批量修改护理员
 * @param {*} data 请求参数
 */
export function updateCareGiverByWorkorder(data) {
  return request({
    url: 'fsk-workorder/workorder/updateCareGiverByWorkorder',
    method: 'post',
    data
  })
}

/**
 *排程信息列表
 * @param {*} data 请求参数
 */
export function findWorkorderScheduleList(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/findWorkorderScheduleList',
    method: 'post',
    data
  })
}


/**
 *批量新增排程
 * @param {*} data 请求参数
 */
export function batchAddWorkorderSchedule(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/batchAddWorkorderSchedule',
    method: 'post',
    data
  })
}


/**
 *批量删除排程
 * @param {*} data 请求参数
 */
export function deleteWorkorderScheduleByCheckBox(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/deleteWorkorderScheduleByCheckBox',
    method: 'post',
    data
  })
}


/**
 *批量更换排程
 * @param {*} data 请求参数
 */
export function updateCareGiverBySchedule(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/updateCareGiverBySchedule',
    method: 'post',
    data
  })
}

/**
 *排程详情
 * @param {*} data 请求参数
 */
export function findWorkorderScheduleByScheduleCode(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/findWorkorderScheduleByScheduleCode',
    method: 'post',
    data
  })
}
/**
 * 查看订单查产品
 * @param {*} data
 */
export function getOrderDetail(data) {
  return request({
    url: '/fsk-erp-trade/order/getOrderDetail',
    method: 'post',
    data
  })
}

/**
 *修改排程
 * @param {*} data 请求参数
 */
export function editWorkorderScheduleDetail(data) {
  return request({
    url: 'fsk-workorder/workorderSchedule/editWorkorderScheduleDetail',
    method: 'post',
    data
  })
}
 /**
 * 工单评价列表
 * @param {*} data
 */
export function selectWorkorderEvaluationList(data) {
  return request({
    url: 'fsk-workorder/workorderEvaluation/selectWorkorderEvaluationList',
    method: 'post',
    data
  })
}

 /**
 * 工单评价详情
 * @param {*} data
 */
export function selectWoWorkorderEvaluationById(data) {
  return request({
    url: 'fsk-workorder/workorderEvaluation/selectWoWorkorderEvaluationById',
    method: 'post',
    data
  })
}
/**
 * 获取订单服务项
 */
export function selectProductOrderServiceList(data) {
  return request({
    url: '/fsk-erp-trade/order/selectProductOrderServiceList',
    method: 'post',
    data
  })
}
/**
 * 工单统计
 */
export function queryWorkorderCount(data) {
  return request({
    url: '/fsk-workorder/workorderOut/queryWorkorderCount',
    method: 'post',
    data
  })
}
/**
 * 考勤统计
 */
export function attendanceStatistics(data) {
  return request({
    url: '/fsk-workorder/workorderOut/attendanceStatistics',
    method: 'post',
    data
  })
}
/**
 * 员工排程
 */
export function queryWorkOrderSchedule(data) {
  return request({
    url: '/fsk-workorder/workorderSchedule/queryWorkOrderScheduleForOrganization',
    method: 'post',
    data
  })
}
