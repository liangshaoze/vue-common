import request from 'utils/request'
/**
 * 员工信息数据
 * @param {*} data
 */
export function findEhrStaffHomeCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffHomeCount',
    method: 'post',
    data
  })
}
/**
 * 在职员工类型统计
 * @param {*} data
 */
export function findEhrStaffEmployeesTypeCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesTypeCount',
    method: 'post',
    data
  })
}
/**
 * 员工学历统计
 * @param {*} data
 */
export function findEhrStaffEmployeesCardCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesCardCount',
    method: 'post',
    data
  })
}
/**
 * 员工年龄统计
 * @param {*} data
 */
export function findEhrStaffEmployeesAgeCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesAgeCount',
    method: 'post',
    data
  })
}
/**
 * 员工性别统计
 * @param {*} data
 */
export function findEhrStaffEmployeesGenderCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesGenderCount',
    method: 'post',
    data
  })
}
/**
 * 员工户籍统计
 * @param {*} data
 */
export function findEhrStaffEmployeesHouseProvinceCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesHouseProvinceCount',
    method: 'post',
    data
  })
}
/**
 * 员工关怀统计
 * @param {*} data
 */
export function findEhrStaffEmployeesCareCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffEmployeesCareCount',
    method: 'post',
    data
  })
}
/**
 * 简历展示
 * @param {*} data
 */
export function findEhrStaffResumeCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffResumeCount',
    method: 'post',
    data
  })
}
/**
 * 本月待处理
 * @param {*} data
 */
export function findEhrStaffTobeProcessCount(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffTobeProcessCount',
    method: 'post',
    data
  })
}
/**
 * 员工岗位统计
 * @param {*} data
 */
export function findEhrStaffPositionTotal(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findEhrStaffPositionTotal',
    method: 'post',
    data
  })
}
/**
 * 客户等级/性别
 * @param {*} data
 */
export function findEtProductOrderCustomerGenderCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderCustomerGenderCount',
    method: 'post',
    data
  })
}
/**
 * 客户年龄统计
 * @param {*} data
 */
export function findEtProductOrderCustomerAgeCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderCustomerAgeCount',
    method: 'post',
    data
  })
}
/**
 * 本月新增客户
 * @param {*} data
 */
export function findEtProductOrderMonthAddCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderMonthAddCount',
    method: 'post',
    data
  })
}
/**
 * 历史服务客户总数
 * @param {*} data
 */
export function findEtProductOrderHistoryServiceCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderHistoryServiceCount',
    method: 'post',
    data
  })
}
/**
 * 客户关怀
 * @param {*} data
 */
export function findEtProductOrderCustomerCareCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderCustomerCareCount',
    method: 'post',
    data
  })
}
/**
 * 客户实时信息
 * @param {*} data
 */
export function findEtProductOrderCustomerRealInfoCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderCustomerRealInfoCount',
    method: 'post',
    data
  })
}
/**
 * 今日服务时间段统计
 * @param {*} data
 */
export function findEtProductOrderTodayTimeTjCount(data) {
  return request({
    url: '/fsk-workorder/wobigdata/findEtProductOrderTodayTimeTjCount',
    method: 'post',
    data
  })
}
/**
 * 获取前6个月的数据(服务次数/时长)
 * @param {*} data
 */
export function findEtDataTotalOutDtoMonthCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtDataTotalOutDtoMonthCount',
    method: 'post',
    data
  })
}
/**
 * 获取前3年的数据(服务次数/服务时长)
 * @param {*} data
 */
export function findEtDataTotalOutDtoThreeYearCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtDataTotalOutDtoThreeYearCount',
    method: 'post',
    data
  })
}
/**
 * 获取前6季度的数据(服务次数/服务时长)
 * @param {*} data
 */
export function findEtDataTotalOutDtoSixQuarterCount(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtDataTotalOutDtoSixQuarterCount',
    method: 'post',
    data
  })
}
/**
 * 获取所有的服务人次/服务时长统计
 * @param {*} data
 */
export function findEtProductOrderServiceTotal(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderServiceTotal',
    method: 'post',
    data
  })
}
/**
 * 今日服务
 * @param {*} data
 */
export function findWoWorkOrderTodayServiceCount(data) {
  return request({
    url: '/fsk-workorder/wobigdata/findWoWorkOrderTodayServiceCount',
    method: 'post',
    data
  })
}
/**
 * 实时工单
 * @param {*} data
 */
export function findWoWorkOrderRealTimeJob(data) {
  return request({
    url: '/fsk-workorder/wobigdata/findWoWorkOrderRealTimeJob',
    method: 'post',
    data
  })
}
/**
 * 统计各组织在服务客户人数
 * @param {*} data
 */
export function findEtProductOrderCustomerServicePeopleNum(data) {
  return request({
    url: '/fsk-erp-trade/etbigdata/findEtProductOrderCustomerServicePeopleNum',
    method: 'post',
    data
  })
}
/**
 * 根据城市Code编码查询天气
 * @param {*} data
 */
export function findCityWeather(data) {
  return request({
    url: '/fsk-ehr/ehrbigdata/findCityWeather',
    method: 'post',
    data
  })
}
/**
 * 获取当前组织及下属组织
 * @param {*} data
 */
export function findEhrOrgList(data) {
  return request({
    url: '/fsk-ehr/org/findEhrOrgList',
    method: 'post',
    data
  })
}
