import request from 'utils/request'
/**
 * 查找主页所有统计数据
 * @param {*} data
 */
export function findFirstPageData(data) {
  return request({
    url: '/client/findFirstPageData',
    method: 'post',
    data
  })
}
