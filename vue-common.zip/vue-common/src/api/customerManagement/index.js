import request from 'utils/request'

/**
 * 获取员工列表
 * @param {*}
 */
export function findStaffList(data) {
  return request({
    url: '/fsk-ehr/staff/findStaffList',
    method: 'post',
    data
  })
}

/**
 * 新增员工
 * @param {*} staffCode
 */
export function insertEhrStaff(data) {
  return request({
    url: '/fsk-ehr/staff/insertEhrStaff',
    method: 'post',
    data
  })
}

/**
 * 修改员工
 * @param {*} staffCode
 */
export function editEhrStaff(data) {
  return request({
    url: '/fsk-ehr/staff/editEhrStaff',
    method: 'post',
    data
  })
}

/**
 * 查看员工详情
 * @param {*} staffCode
 */
export function findEhrStaffByCode(data) {
  return request({
    url: '/fsk-ehr/staff/findEhrStaffByCode',
    method: 'post',
    data
  })
}

/**
 * 模糊查询岗位
 * @param {*} staffCode
 */
export function findEhrPositionList(data) {
  return request({
    url: '/fsk-ehr/position/findEhrPositionList',
    method: 'post',
    data
  })
}

/**
 * 查询岗位列表
 * @param {*} staffCode
 */
export function findEhrStaffPositionList(data) {
  return request({
    url: '/fsk-ehr/staffPosition/findEhrStaffPositionList',
    method: 'post',
    data
  })
}

/**
 * 新增岗位列表
 * @param {*} staffCode
 */
export function insertEhrStaffPosition(data) {
  return request({
    url: '/fsk-ehr/staffPosition/insertEhrStaffPosition',
    method: 'post',
    data
  })
}

/**
 * 修改岗位列表
 * @param {*} staffCode
 */
export function editEhrStaffPosition(data) {
  return request({
    url: '/fsk-ehr/staffPosition/editEhrStaffPosition',
    method: 'post',
    data
  })
}

/**
 * 修改岗位列表当前行组织权限
 * @param {*} data 
 */
export function editEhrStaffPositionManageStatus(data) {
  return request({
    url: '/fsk-ehr/staffPosition/editEhrStaffPositionManageStatus',
    method: 'post',
    data
  })
}

/**
 * 删掉岗位列表当前行
 * @param {*} data 
 */
export function deleteEhrStaffPosition(data) {
  return request({
    url: '/fsk-ehr/staffPosition/deleteEhrStaffPosition',
    method: 'post',
    data
  })
}

/**
 * 查询合同列表
 * @param {*} staffCode
 */
export function getStaffContractList(data) {
  return request({
    url: '/fsk-ehr/staff/getStaffContractList',
    method: 'post',
    data
  })
}

/**
 * 新增合同列表
 * @param {*} staffCode
 */
export function insertStaffContract(data) {
  return request({
    url: '/fsk-ehr/staff/insertStaffContract',
    method: 'post',
    data
  })
}

/**
 * 修改合同列表
 * @param {*} staffCode
 */
export function editStaffContract(data) {
  return request({
    url: '/fsk-ehr/staff/editStaffContract',
    method: 'post',
    data
  })
}

/**
 * 查询教育情况列表
 * @param {*} staffCode
 */
export function findStaffEducationList(data) {
  return request({
    url: '/fsk-ehr/staff/findStaffEducationList',
    method: 'post',
    data
  })
}

/**
 * 新增教育情况
 * @param {*} staffCode
 */
export function insertStaffEducation(data) {
  return request({
    url: '/fsk-ehr/staff/insertStaffEducation',
    method: 'post',
    data
  })
}

/**
 * 修改教育情况
 * @param {*} staffCode
 */
export function editStaffEducation(data) {
  return request({
    url: '/fsk-ehr/staff/editStaffEducation',
    method: 'post',
    data
  })
}

/**
 * 删除教育情况
 * @param {*} staffCode
 */
export function deleteStaffEducation(data) {
  return request({
    url: '/fsk-ehr/staff/deleteStaffEducation',
    method: 'post',
    data
  })
}

/**
 * 查询工作经历列表
 * @param {*} staffCode
 */
export function findStaffWorkExperienceList(data) {
  return request({
    url: '/fsk-ehr/staff/findStaffWorkExperienceList',
    method: 'post',
    data
  })
}

/**
 * 新增工作经历
 * @param {*} staffCode
 */
export function insertStaffWorkExperience(data) {
  return request({
    url: '/fsk-ehr/staff/insertStaffWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 修改工作经历
 * @param {*} staffCode
 */
export function editStaffWorkExperience(data) {
  return request({
    url: '/fsk-ehr/staff/editStaffWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 删除工作经历
 * @param {*} staffCode
 */
export function deleteStaffWorkExperience(data) {
  return request({
    url: '/fsk-ehr/staff/deleteStaffWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 查询专业资格列表
 * @param {*} staffCode
 */
export function findStaffProfessionalQualificationList(data) {
  return request({
    url: '/fsk-ehr/staff/findProfessionalQualificationList',
    method: 'post',
    data
  })
}

/**
 * 新增专业资格
 * @param {*} staffCode
 */
export function insertStaffProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/staff/insertProfessionalQualification',
    method: 'post',
    data
  })
}

/**
 * 修改专业资格
 * @param {*} staffCode
 */
export function editStaffProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/staff/editProfessionalQualification',
    method: 'post',
    data
  })
}

/**
 * 删除专业资格
 * @param {*} staffCode
 */
export function deleteStaffProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/staff/deleteProfessionalQualification',
    method: 'post',
    data
  })
}

/**
 * 查询家庭关系列表
 * @param {*} staffCode
 */
export function findStaffFamilyList(data) {
  return request({
    url: '/fsk-ehr/staff/findStaffFamilyList',
    method: 'post',
    data
  })
}

/**
 * 新增家庭关系
 * @param {*} staffCode
 */
export function insertStaffFamily(data) {
  return request({
    url: '/fsk-ehr/staff/insertStaffFamily',
    method: 'post',
    data
  })
}

/**
 * 修改家庭关系
 * @param {*} staffCode
 */
export function editStaffFamily(data) {
  return request({
    url: '/fsk-ehr/staff/editStaffFamily',
    method: 'post',
    data
  })
}

/**
 * 删除家庭关系
 * @param {*} staffCode
 */
export function deleteStaffFamily(data) {
  return request({
    url: '/fsk-ehr/staff/deleteStaffFamily',
    method: 'post',
    data
  })
}

/**
 * 员工导出
 * @param {*}
 */
export function exportStaffList(data) {
  return request({
    url: '/fsk-ehr/staff/exportStaffList',
    method: 'post',
    data
  })
}

/**
 * 查询所有员工
 * @param {*}
 */
export function findStaffAll(data) {
  return request({
    url: '/fsk-ehr/staff/findStaffAll',
    method: 'post',
    data
  })
}

/**
 * 导入招聘信息判断身份证是否已增加员工
 * @param {*}
 */
export function checkRecruitIdCardExist(data) {
  return request({
    url: '/fsk-ehr/staff/checkIdCardExist',
    method: 'post',
    data
  })
}

/**
 * 组织架构-查看员工-修改员工
 * @param {*} staffCode
 */
export function editEhrStaffForOrgModule(data) {
  return request({
    url: '/fsk-ehr/staff/editEhrStaffForOrgModule',
    method: 'post',
    data
  })
}

/**
 * 新增员工星级
 * @param {*} staffCode
 */
export function addStaffGradeChangeRecord(data) {
  return request({
    url: '/fsk-ehr/staffGrade/addStaffGradeChangeRecord',
    method: 'post',
    data
  })
}

/**
 * 查询员工星级
 * @param {*}
 */
export function findStaffGradeChangeRecordList(data) {
  return request({
    url: '/fsk-ehr/staffGrade/findStaffGradeChangeRecordList',
    method: 'post',
    data
  })
}

/**
 * 删除员工星级
 * @param {*}
 */
export function deleteStaffGradeChangeRecord(data) {
  return request({
    url: '/fsk-ehr/staffGrade/deleteStaffGradeChangeRecord',
    method: 'post',
    data
  })
}