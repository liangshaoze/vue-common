import request from 'utils/request'
/**
 * 新增招聘基本信息
 * @param {*} data
 */
export function insertRecruit(data) {
  return request({
    url: '/fsk-ehr/recruit/insertRecruit',
    method: 'post',
    data
  })
}
/**
 * 修改招聘基本信息
 * @param {*} data
 */
export function editRecruit(data) {
  return request({
    url: '/fsk-ehr/recruit/editRecruit',
    method: 'post',
    data
  })
}
/**
 * 审核招聘基本信息
 * @param {*} data
 */
export function editRecruitReview(data) {
  return request({
    url: '/fsk-ehr/recruit/editRecruitReview',
    method: 'post',
    data
  })
}
/**
 * 获取招聘管理列表
 * @param {*} data
 */
export function findRecruitInfoList(data) {
  return request({
    url: '/fsk-ehr/recruit/findRecruitInfoList',
    method: 'post',
    data
  })
}

/**
 * 根据身份证查询背调详情
 * @param {*} data
 */
export function getSurveyDetailByIdCard(data) {
  return request({
    url: '/fsk-external/survey/getSurveyDetailByIdCard',
    method: 'post',
    data
  })
}
/**
 * 查询背调列表
 * @param {*} data
 */
export function findSurveyList(data) {
  return request({
    url: '/fsk-external/survey/findSurveyList',
    method: 'post',
    data
  })
}
/**
 * 详情信息
 * @param {*} data
 */
export function getRecruitDetailByCode(data) {
  return request({
    url: '/fsk-ehr/recruit/getRecruitDetailByCode',
    method: 'post',
    data
  })
}
/**
 * 发送自定义短信
 * @param {*} data
 */
export function sendMessage(data) {
  return request({
    url: '/fsk-system/common/sendMessage',
    method: 'post',
    data
  })
}
/**
 *教育情况返回列表
 * @param {*} data
 */
export function findRecruitEducationList(data) {
  return request({
    url: '/fsk-ehr/recruit/findRecruitEducationList',
    method: 'post',
    data
  })
}
/**
 * 新增招聘教育情况
 * @param {*} data
 */

export function insertRecruitEducation(data) {
  return request({
    url: '/fsk-ehr/recruit/insertRecruitEducation',
    method: 'post',
    data
  })
}
/**
 * 修改招聘教育情况
 * @param {*} data
 */

export function editRecruitEducation(data) {
  return request({
    url: '/fsk-ehr/recruit/editRecruitEducation',
    method: 'post',
    data
  })
}
/**
 * 删除招聘教育情况
 * @param {*} data
 */

export function deleteRecruitEducation(data) {
  return request({
    url: '/fsk-ehr/recruit/deleteRecruitEducation',
    method: 'post',
    data
  })
}

/**
 * 查询工作经历列表
 * @param {*} data
 */

export function findRecruitWorkExperienceList(data) {
  return request({
    url: '/fsk-ehr/recruit/findRecruitWorkExperienceList',
    method: 'post',
    data
  })
}

/**
 * 新增招聘工作经历
 * @param {*} data
 */

export function insertRecruitWorkExperience(data) {
  return request({
    url: '/fsk-ehr/recruit/insertRecruitWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 修改招聘工作经历
 * @param {*} data
 */

export function editRecruitWorkExperience(data) {
  return request({
    url: '/fsk-ehr/recruit/editRecruitWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 删除招聘工作经历
 * @param {*} data
 */

export function deleteRecruitWorkExperience(data) {
  return request({
    url: '/fsk-ehr/recruit/deleteRecruitWorkExperience',
    method: 'post',
    data
  })
}

/**
 * 查询专业资格列表
 * @param {*} data
 */

export function findProfessionalQualificationList(data) {
  return request({
    url: '/fsk-ehr/recruit/findProfessionalQualificationList',
    method: 'post',
    data
  })
}

/**
 * 新增招聘专业资格
 * @param {*} data
 */

export function insertProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/recruit/insertProfessionalQualification',
    method: 'post',
    data
  })
}

/**
 * 修改招聘专业资格
 * @param {*} data
 */

export function editProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/recruit/editProfessionalQualification',
    method: 'post',
    data
  })
}

/**
 * 删除招聘专业资格
 * @param {*} data
 */

export function deleteProfessionalQualification(data) {
  return request({
    url: '/fsk-ehr/recruit/deleteProfessionalQualification',
    method: 'post',
    data
  })
}
/**
 * 删除招聘招聘家庭关系
 * @param {*} data
 */

export function deleteRecruitFamily(data) {
  return request({
    url: '/fsk-ehr/recruit/deleteRecruitFamily',
    method: 'post',
    data
  })
}

/**
 * 新增招聘招聘家庭关系
 * @param {*} data
 */

export function insertRecruitFamily(data) {
  return request({
    url: '/fsk-ehr/recruit/insertRecruitFamily',
    method: 'post',
    data
  })
}

/**
 * 修改招聘招聘家庭关系
 * @param {*} data
 */

export function editRecruitFamily(data) {
  return request({
    url: '/fsk-ehr/recruit/editRecruitFamily',
    method: 'post',
    data
  })
}

/**
 * 招聘Code查询家庭关系
 * @param {*} data
 */

export function findRecruitFamilyList(data) {
  return request({
    url: '/fsk-ehr/recruit/findRecruitFamilyList',
    method: 'post',
    data
  })
}
/**
 * 导出
 * @param {*} data
 */

export function exportRecruit(data) {
  return request({
    url: '/fsk-ehr/recruit/exportRecruit',
    method: 'post',
    data
  })
}


/**
 * 模糊搜索组织
 * @param {*} data
 */

export function findEhrOrg(data) {
  return request({
    url: '/fsk-ehr/org/findEhrOrg',
    method: 'post',
    data
  })
}

/**
 * 获取员工列表
 * @param {*}
 */
export function findStaff(data) {
  return request({
    url: '/fsk-ehr/staff/findStaff',
    method: 'post',
    data
  })
}
