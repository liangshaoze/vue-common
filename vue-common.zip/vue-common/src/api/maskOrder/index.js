import request from 'utils/request'
/**
 * 新增口罩预约
 * @param {*} data
 */
export function insertMaskOrder(data) {
  return request({
    url: '/fsk-erp-trade/maskOrder/insertMaskOrder',
    method: 'post',
    data
  })
}

/**
 * 口罩预约查询列表
 * @param {*} data
 */
export function findMaskOrderList(data) {
  return request({
    url: '/fsk-erp-trade/maskOrder/findMaskOrderList',
    method: 'post',
    data
  })
}

/**
 * 口罩预约批量失效
 * @param {*} data
 */
export function updateMaskOrderForOff(data) {
  return request({
    url: '/fsk-erp-trade/maskOrder/updateMaskOrderForOff',
    method: 'post',
    data
  })
}
