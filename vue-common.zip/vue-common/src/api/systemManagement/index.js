import request from 'utils/request'
/**
 * 用户管理列表
 * @param {*} data 请求参数
 */
export function findSysUserList(data) {
  return request({
    url: '/fsk-system/sysUser/findSysUserList',
    method: 'post',
    data
  })
}
/**
 * 根据userCode查询信息
 * @param {*} data 请求参数
 */
export function getSysUserByCode(data) {
  return request({
    url: '/fsk-system/sysUser/getSysUserByCode',
    method: 'post',
    data
  })
}
/**
 * 修改用户管理
 * @param {*} data 请求参数
 */
export function editSysUser(data) {
  return request({
    url: '/fsk-system/sysUser/editSysUser',
    method: 'post',
    data
  })
}

/**
 * 修改用户菜单前获取菜单
 * @param {*} data 请求参数
 */
export function findSysUserMenus(data) {
  return request({
    url: '/fsk-system/sysUserMenu/findSysUserMenus',
    method: 'post',
    data
  })
}

/**
 * 修改用户菜单
 * @param {*} data 请求参数
 */
export function editSysUserMenusByUserCode(data) {
  return request({
    url: '/fsk-system/sysUserMenu/editSysUserMenusByUserCode',
    method: 'post',
    data
  })
}

