<template>
	<div id="app">
		<transition name="fade" mode="out-in">
			<router-view></router-view>
		</transition>
	</div>
</template>

<script>
export default {
	name: "App",
	created () {
		// 在页面加载时读取sessionStorage里的状态信息
		if (sessionStorage.getItem('store')) {
			this.$store.replaceState(Object.assign({}, this.$store.state, JSON.parse(sessionStorage.getItem('store'))))
		}

		// 在页面刷新时将vuex里的信息保存到sessionStorage里
		window.addEventListener('beforeunload', () => {
			sessionStorage.setItem('store', JSON.stringify(this.$store.state))
		})
	}
};
</script>
<style lang="scss">
body {
	margin: 0px;
	padding: 0px;
	font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
		Microsoft YaHei, SimSun, sans-serif;
	font-size: 14px;
	-webkit-font-smoothing: antialiased;
}
#app {
	position: absolute;
	top: 0px;
	bottom: 0px;
	width: 100%;
}

//全局条件查询样式
.queryToolbar {
	margin: 0px 20px 10px 20px;
	padding: 10px;
	border-radius: 10px;
	background: #fff;
	display: -webkit-box;
	.el-form-item {
		margin: 5px;
	}
}
.el-image-viewer__close {
	top: 40px;
	right: 40px;
	width: 40px;
	height: 40px;
	background: red;
	font-size: 40px;
}
//全局form样式
.formToolbar {
	margin: 0px 20px 10px 20px;
	padding: 10px;
	border-radius: 10px;
	background: #fff;
	display: flex;
}

//全局table外侧样式
.tableToolbar {
	background: #fff;
	border-radius: 10px;
	margin: 0px 20px 20px 20px;
	padding: 0px 20px;
}

//全局表格分页样式
.pageToolbar {
	padding: 10px;
	text-align: right;
	background: #fff;
}

//列表卡片样式
.filter_wrap {
	background-color: #fff;
	padding: 20px;
	border-radius: 10px;
	margin: 0px 20px 10px 20px;
}

//全局时间级联控件
.el-date-editor .el-range-separator {
	width: 8% !important;
}

//全局滚动条样式
/*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
::-webkit-scrollbar {
	width: 10px; /*滚动条宽度*/
	height: 10px; /*滚动条高度*/
}

/*定义滚动条轨道 内阴影+圆角*/
::-webkit-scrollbar-track {
	border-radius: 10px; /*滚动条的背景区域的圆角*/
	background-color: rgba(224, 224, 224, 0.1); /*滚动条的背景颜色*/
}

/*定义滑块 内阴影+圆角*/
::-webkit-scrollbar-thumb {
	border-radius: 10px; /*滚动条的圆角*/
	background-color: rgba(224, 224, 224, 1); /*滚动条的背景颜色*/
}
/*较长字段*/
.long-field {
	font-size: 14px;
	line-height: 20px;
	display: inline-block;
}
/* 弹窗下边框 */
.el-dialog__header {
	padding: 20px;
	padding-bottom: 10px;
	margin: 0 15px;
	border-bottom: 1px solid #edeff2;
}

/* 全局下拉多选样式 */
.el-select__tags-text {
	display: inline-block;
	width: 50px;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
	vertical-align: middle;
}
/* 修改全局label样式 */
label {
	font-weight: normal;
}
.el-form-item__label {
	text-align: right;
	vertical-align: middle;
	float: left;
	font-size: 14px;
	color: #666666 !important;
	line-height: 40px;
	padding: 0 12px 0 0;
}
.el-form-item__content {
	font-size: 14px;
	color: #666666;
}

.line-style {
	height: 1px;
	background: #e0e6eb;
}
</style>
