const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  visitedViews: state => state.tagsView.visitedViews,
  cachedViews: state => state.tagsView.cachedViews,
  token: state => state.user.token,
  userCode: state => state.user.userCode,
  password: state => state.user.password,
  userFullName: state => state.user.userFullName,
  userGender: state => state.user.userGender,
  userTel: state => state.user.userTel,
  userIdCard: state => state.user.userIdCard,
  userStatus: state => state.user.userStatus,
  userOrgCode: state => state.user.userOrgCode,
  userOrgName: state => state.user.userOrgName,
  roles: state => state.user.roles,
  permission_routes: state => state.permission.routes
}
export default getters
