import { asyncRoutes, constantRoutes } from '@/router'

/**
 * Use meta.role to determine if the current user has permission
 * @param roles
 * @param route
 */
function hasPermission(roles, route) {
  if (route.children) {
    // eslint-disable-next-line no-empty
    if(route.meta.privilege.indexOf('test') >= 0){
      return true;
    }
    var result=false;
    for (var i = 0; i < roles.length; i++) {
      // eslint-disable-next-line no-empty
      for(var j=0;j<route.children.length;j++){
        if (route.children[j].meta && route.children[j].meta.privilege) {
          if(roles[i]==route.children[j].meta.privilege){
            result=true;
            break;
          }
        }
      }
    }
    return result;
  }
  if (route.meta && route.meta.privilege) {
    return roles.some(role => route.meta.privilege === role || route.meta.privilege.indexOf('admin') >= 0)
  }
  return false
}

/**
 * Filter asynchronous routing tables by recursion
 * @param routes asyncRoutes
 * @param roles
 */
export function filterAsyncRoutes(routes, roles) {
  const res = []

  routes.forEach(route => {
    const tmp = { ...route }
    if (hasPermission(roles, tmp)) {
      if (tmp.children) {
        tmp.children = filterAsyncRoutes(tmp.children, roles)
      }
      res.push(tmp)
    }
  })

  return res
}

const permission = {
  state: {
    routes: [],
    addRoutes: []
  },
  mutations: {
    SET_ROUTES: (state, routes) => {
      state.addRoutes = routes
      state.routes = constantRoutes.concat(routes)
    }
  },
  actions: {
    GenerateRoutes({ commit }, roles) {
      return new Promise(resolve => {
        let accessedRoutes
        if (roles.includes('admin')) {
          accessedRoutes = asyncRoutes || []
        } else {
          accessedRoutes = filterAsyncRoutes(asyncRoutes, roles)
        }
        commit('SET_ROUTES', accessedRoutes)
        resolve(accessedRoutes)
      })
    }
  }
}

export default permission
