import { login, logout, getMenu } from 'api/login'
import { getToken, setToken, removeToken, getUserCode, setUserCode, removeUserCode } from 'utils/auth'
import {loginIn,logOut,getUserInfo} from 'utils/userMgr'

const user = {
  state: {
    token: getUserInfo().token,
    userCode: getUserInfo().userCode,
    userFullName: '',
    userGender: '',
    password: '',
    userTel: '',
    userIdCard: '',
    userStatus: '',
    userOrgCode: '',
    userOrgName: '',
    roles: []
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_USERCODE: (state, userCode) => {
      state.userCode = userCode
    },
    SET_PASSWORD: (state, password) => {
      state.password = password
    },
    SET_USERFULLNAME: (state, userFullName) => {
      state.userFullName = userFullName
    },
    SET_GENDER: (state, userGender) => {
      state.userGender = userGender
    },
    SET_USERTEL: (state, userTel) => {
      state.userTel = userTel
    },
    SET_USERIDCARD: (state, userIdCard) => {
      state.userIdCard = userIdCard
    },
    SET_USERSTATUS: (state, userStatus) => {
      state.userStatus = userStatus
    },
    SET_USERORGCODE: (state, userOrgCode) => {
      state.userOrgCode = userOrgCode
    },
    SET_USERORGNAME: (state, userOrgName) => {
      state.userOrgName = userOrgName
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    }
  },

  actions: {
    // 登录并获取用户信息
    Login({ commit }, userInfo) {
      const username = userInfo.username
      return new Promise((resolve, reject) => {
        login(username, userInfo.password, userInfo.loginType, userInfo.userTel, userInfo.verifyCodeKey, userInfo.imageCode).then(response => {
          const data = response.data.responseData
          if (response.data.statusCode === '200') {
            commit('SET_TOKEN', data.token)
            commit('SET_USERCODE', data.userCode)
            commit('SET_PASSWORD', data.password)
            commit('SET_USERFULLNAME', data.userFullName)
            commit('SET_GENDER', data.userGender)
            commit('SET_USERTEL', data.userTel)
            commit('SET_USERIDCARD', data.userIdCard)
            commit('SET_USERSTATUS', data.userStatus)
            commit('SET_USERORGCODE', data.userOrgCode)
            commit('SET_USERORGNAME', data.userOrgName)
            // setUserCode(data.userCode)
            // setToken(data.token,data.userCode)
            loginIn(data,username)
          }
          resolve(response)
        }).catch(error => {
          console.log(error)
          reject(error)
        })
      })
    },

    // 获取菜单权限
    MenuInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        getMenu(state.userCode).then(response => {
          const data = response.data.responseData
          if (!data.privilegeNames) {
            data.privilegeNames = ['system', 'system_editPassword']
          }
          const { privilegeNames } = data
          commit('SET_ROLES', privilegeNames)
          resolve(data)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout().then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken()
          removeUserCode()
          resolve()
          logOut()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        commit('SET_ROLES', [])
        removeToken()
        removeUserCode()
        resolve()
        logOut()
      })
    }
  }
}

export default user
