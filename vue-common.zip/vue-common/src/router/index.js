
import Vue from 'vue'
import Router from 'vue-router'

// in development-env not use lazy-loading, because lazy-loading too many pages will cause webpack hot update too slow. so only in production use lazy-loading;
// detail: https://panjiachen.github.io/vue-element-admin-site/#/lazy-loading

Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             该名称由<keep alive>使用（必须设置！!!)
 * meta : {
    roles: ['admin','editor']    控制页面角色（您可以设置多个角色）
    title: 'title'               侧边栏和面包屑中显示的名称
    icon: 'svg-name'             侧边栏显示的图标
    noCache: true                如果设置为true，则不会缓存该页（默认为false）
    affix: true                  如果设置为true，标签将附加在标签视图中
    breadcrumb: false            如果设置为false，则该项将隐藏在breadcrumb中（默认为true）
    activeMenu: '/example/list'  如果设置路径，侧边栏将突出显示您设置的路径
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * 没有权限要求的基页
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/errorPage/404'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/personal/personalCenter'
  },
  {
    path: '/personal',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'personalCenter',
        name: 'PersonalCenter',
        component: () => import('@/views/person/index'),
        meta: { title: '个人中心', privilege: 'admin' }
      }
    ]
  },
  {
    path: '/addMaskOrder',
    component: () => import('@/views/maskOrder/addMaskOrder'),
    hidden: true
  },
  {
    path: '/maskOrderResult',
    component: () => import('@/views/maskOrder/maskOrderResult'),
    hidden: true
  },
  {
    path: '/bigDataHomePage',
    component: () => import('@/views/bigDataShow/bigDataHomePage'),
    hidden: true
  },
  {
    path: '/bigDataCustomer',
    component: () => import('@/views/bigDataShow/bigDataCustomer'),
    hidden: true
  },
  {
    path: '/bigDataStaff',
    component: () => import('@/views/bigDataShow/bigDataStaff'),
    hidden: true
  },
  {
    path: '/bigDataService',
    component: () => import('@/views/bigDataShow/bigDataService'),
    hidden: true
  },
  {
    path: '/bigDataPage',
    component: () => import('@/views/bigDataShow/bigDataTemplate'),
    hidden: true
  },
  {
    path: '/bigDataPageCY',
    component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
    hidden: true
  },
  {
    path: '/assessMobile',
    component: () => import('@/views/evaluationManagement/assessInformation/mobile/assessInformationList'),
    hidden: true
  },
  {
    path: '/assessMobileReport',
    component: () => import('@/views/evaluationManagement/assessInformation/mobile/assessReport'),
    hidden: true,
  },
  {
    path: '/assessMobileInsertAssess',
    component: () => import('@/views/evaluationManagement/assessInformation/mobile/insertAssess'),
    hidden: true
  },
  {
    path: '/assessReportNoToken',
    component: () => import('@/views/evaluationManagement/assessInformation/assessReport'),
    hidden: true,
  },
]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 * 需要根据用户角色动态加载的路由
 */
export const asyncRoutes = [
  {
    path: '/personnelManagement',
    component: Layout,
    redirect: 'noRedirect',
    meta: { title: '人事模块', icon: 'personnel', privilege: 'personnel' },
    children: [
      {
        path: 'dispatchRequirementList',
        name: 'DispatchRequirementList',
        component: () => import('@/views/dispatchrequirement/dispatchRequirementList'),
        meta: { title: '派单需求', privilege: 'dispatch_requirement_list', noCache: true }
      },
      {
        path: 'recruitManagement',
        name: 'RecruitManagement',
        component: () => import('@/views/recruitManagement/recruitManagement'),
        meta: { title: '招聘管理', privilege: 'personnel_recruit_list', noCache: true }
      },
      {
        path: 'addRecruit',
        name: 'AddRecruit',
        component: () => import('@/views/recruitManagement/addRecruit'),
        meta: { title: '新增招聘信息', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'viewRecruit',
        name: 'ViewRecruit',
        component: () => import('@/views/recruitManagement/viewRecruit'),
        meta: { title: '修改招聘信息', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'customerManagementList',
        name: 'CustomerManagementList',
        component: () => import('@/views/customerManagement/customerManagementList'),
        meta: { title: '员工管理', privilege: 'personnel_staff_list', noCache: true }
      },
      {
        path: 'addCustomerManagement',
        name: 'AddCustomerManagement',
        component: () => import('@/views/customerManagement/addCustomerManagement'),
        meta: { title: '新增员工', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'updateCustomerManagement',
        name: 'UpdateCustomerManagement',
        component: () => import('@/views/customerManagement/updateCustomerManagement'),
        meta: { title: '修改员工', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'contractManagementList',
        name: 'ContractManagementList',
        component: () => import('@/views/contractManagement/contractManagementList'),
        meta: { title: '合同管理', privilege: 'personnel_contract_list', noCache: true }
      },
      {
        path: 'supplierManagementList',
        name: 'SupplierManagementList',
        component: () => import('@/views/supplierManagement/supplierManagementList'),
        meta: { title: '供应商管理', privilege: 'personnel_supplier_list', noCache: true }
      },

      {
        path: 'updateDispatch',
        name: 'UpdateDispatch',
        component: () => import('@/views/dispatchrequirement/updateDispatch'),
        meta: { title: '查看派单需求', privilege: 'dispatch_requirement_list', noCache: true },
        hidden: true
      },
      {
        path: 'addDispatch',
        name: 'AddDispatch',
        component: () => import('@/views/dispatchrequirement/addDispatch'),
        meta: { title: '新增派单需求', privilege: 'dispatch_requirement_list', noCache: true },
        hidden: true
      },
      {
        path: 'copyDispatch',
        name: 'CopyDispatch',
        component: () => import('@/views/dispatchrequirement/copyDispatch'),
        meta: { title: '复制派单需求', privilege: 'dispatch_requirement_list', noCache: true },
        hidden: true
      },
      {
        path: 'supplierManagementEdit',
        name: 'SupplierManagementEdit',
        component: () => import('@/views/supplierManagement/supplierManagementEdit'),
        meta: { title: '修改供应商', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'supplierManagementAdd',
        name: 'SupplierManagementAdd',
        component: () => import('@/views/supplierManagement/supplierManagementEdit'),
        meta: { title: '新增供应商', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'supplierManagementDetail',
        name: 'SupplierManagementDetail',
        component: () => import('@/views/supplierManagement/supplierManagementDetail'),
        meta: { title: '查看供应商', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'partnerManagementList',
        name: 'PartnerManagementList',
        component: () => import('@/views/partnerManagement/partnerManagementList'),
        meta: { title: '合作商管理', privilege: 'personnel_partner_list', noCache: true }
      },
      {
        path: 'addPartnerManagement',
        name: 'AddPartnerManagement',
        component: () => import('@/views/partnerManagement/addPartnerManagement'),
        meta: { title: '新增合作商', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'editPartnerManagement',
        name: 'EditPartnerManagement',
        component: () => import('@/views/partnerManagement/addPartnerManagement'),
        meta: { title: '修改合作商', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'partnerManagementDetail',
        name: 'PartnerManagementDetail',
        component: () => import('@/views/partnerManagement/partnerManagementDetail'),
        meta: { title: '合作商管理详情', privilege: 'admin' },
        hidden: true
      }
    ]
  },
  {
    path: '/systemManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '系统管理', icon: 'system', privilege: 'system' },
    children: [
      {
        path: 'userManagementList',
        name: 'UserManagementList',
        component: () => import('@/views/systemManagement/userManagementList'),
        meta: { title: '用户管理', privilege: 'system_user_manage_list', noCache: true }
      },
    ]
  },
  {
    path: '/bigDataShowCY',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '数据统计', icon: 'bigDataCy', privilege: 'bigData_Cy' },
    children: [
      {
        path: 'bigDataManagement',
        name: 'BigDataManagement',
        component: () => import('@/views/bigDataShowCY/BigDataManagement'),
        meta: { title: '数据录入', privilege: 'bigData_Entry', noCache: true }
      },
      {
        path: 'bigDataPageCY',
        name: 'BigDataPageCY',
        component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
        meta: { title: '机构大屏', privilege: 'bigData_Screen' }
      },
    ]
  },
  {
    path: '/operateManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '运营管理', icon: 'operate', privilege: 'operate' },
    children: [
      {
        path: 'labelManagementList',
        name: 'LabelManagementList',
        component: () => import('@/views/operateManagement/labelManagementList'),
        meta: { title: '标签管理', privilege: 'operate_label_list', noCache: true },
        hidden:true,
      },
      {
        path: 'contentManagementList',
        name: 'ContentManagementList',
        component: () => import('@/views/operateManagement/contentManagementList'),
        meta: { title: '内容管理', privilege: 'operate_content_list', noCache: true },
        hidden:true,
      },
      {
        path: 'applyManagementList',
        name: 'ApplyManagementList',
        component: () => import('@/views/operateManagement/applyManagementList'),
        meta: { title: '长护险申请', privilege: 'operate_chx_apply_list', noCache: true }
      },
      {
        path: 'updateApply',
        name: 'UpdateApply',
        component: () => import('@/views/operateManagement/updateApply'),
        meta: { title: '查看申请', privilege: 'admin', noCache: true },
        hidden:true,
      },
      {
        path: 'suggestManagementList',
        name: 'SuggestManagementList',
        component: () => import('@/views/operateManagement/suggestManagementList'),
        meta: { title: '意见反馈', privilege: 'operate_feedback_list', noCache: true }
      },
      {
        path: 'productClassList',
        name: 'ProductClassList',
        component: () => import('@/views/operateManagement/productClassList'),
        meta: { title: '产品分类', privilege: 'operate_product_class_list', noCache: true },
        hidden:true,
      },
      {
        path: 'exchangeMallList',
        name: 'ExchangeMallList',
        component: () => import('@/views/operateManagement/exchangeMallList'),
        meta: { title: '兑换商城', privilege: 'operate_exchange_mall_list', noCache: true },
        hidden:true,
      }
    ]
  },
  // {
  //   path: '/bigDataShowCY',
  //   component: Layout,
  //   redirect: 'noRedirect',
  //   alwaysShow: true,
  //   meta: { title: '数据统计', icon: 'bigDataCy', privilege: 'bigData_Cy' },
  //   children: [
  //     {
  //       path: 'bigDataManagement',
  //       name: 'BigDataManagement',
  //       component: () => import('@/views/bigDataShowCY/BigDataManagement'),
  //       meta: { title: '数据录入', privilege: 'bigData_Entry', noCache: true }
  //     },
  //     {
  //       path: 'bigDataPageCY',
  //       name: 'BigDataPageCY',
  //       component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
  //       meta: { title: '机构大屏', privilege: 'bigData_Screen' }
  //     },
  //   ]
  // },
  {
    path: '/orgManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '组织管理', icon: 'structure', privilege: 'orgStructure' },
    children: [
      {
        path: 'orgStructureList',
        name: 'OrgStructureList',
        component: () => import('@/views/orgStructure/orgStructureList'),
        meta: { title: '组织架构', privilege: 'orgStructure_list' }
      },
      {
        path: 'staffInfoList',
        name: 'StaffInfoList',
        component: () => import('@/views/orgStructure/StaffInfoList'),
        meta: { title: '员工信息', privilege: 'orgStructure_staffInfo', noCache: true }
      },
      {
        path: 'addOrgStructure',
        name: 'AddOrgStructure',
        component: () => import('@/views/orgStructure/addOrgStructure'),
        meta: { title: '新增下级', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'editStaff',
        name: 'EditStaff',
        component: () => import('@/views/orgStructure/editStaff'),
        meta: { title: '修改员工', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'editStaffInfo',
        name: 'EditStaffInfo',
        component: () => import('@/views/orgStructure/editStaffInfo'),
        meta: { title: '查看员工', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'seeStaffList',
        name: 'SeeStaffList',
        component: () => import('@/views/orgStructure/seeStaffList'),
        meta: { title: '查看员工', privilege: 'admin', noCache: true },
        hidden: true
      },
      {
        path: 'workOrderDetails',
        name: 'WorkOrderDetails',
        component: () => import('@/views/workOrderManagement/WorkOrderDetails'),
        meta: { title: '工单明细', privilege: 'admin'},
        hidden: true
      },
      {
        path: 'staffScheduling',
        name: 'StaffScheduling',
        component: () => import('@/views/orgStructure/staffScheduling'),
        meta: { title: '排程', privilege: 'admin'},
        hidden: true
      },
    ]
  },
  {
    path: '/businessServiceManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '服务管理', icon: 'order', privilege: 'businessService', noCache: true },
    children: [
      {
        path: 'orderManagementList',
        name: 'OrderManagementList',
        component: () => import('@/views/businessService/orderManagementList'),
        meta: { title: '订单管理', privilege: 'businessService_order_manage_list', noCache: true }
      },
      {
        path: 'addOrderInfo',
        name: 'AddOrderInfo',
        component: () => import('@/views/businessService/addOrderInfo'),
        meta: { title: '新增订单', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'updateOrderInfo',
        name: 'UpdateOrderInfo',
        component: () => import('@/views/businessService/updateOrderInfo'),
        meta: { title: '查看线下订单', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'updateOnlineOrderInfo',
        name: 'UpdateOnlineOrderInfo',
        component: () => import('@/views/businessService/updateOnlineOrderInfo'),
        meta: { title: '查看线上订单', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'copyOrderInfo',
        name: 'CopyOrderInfo',
        component: () => import('@/views/businessService/copyOrderInfo'),
        meta: { title: '复制订单', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'productManagementList',
        name: 'ProductManagementList',
        component: () => import('@/views/businessService/productManagementList'),
        meta: { title: '产品管理', privilege: 'businessService_product_manage_list' }
      },
      {
        path: 'evaluationManagementList',
        name: 'EvaluationManagementList',
        component: () => import('@/views/businessService/evaluationManagementList'),
        meta: { title: '客户评价', privilege: 'evaluation_Manage_List', noCache: true }
      },
      {
        path: 'evaluationInfo',
        name: 'EvaluationInfo',
        component: () => import('@/views/businessService/evaluationInfo'),
        meta: { title: '评价详情', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'orderScheduling',
        name: 'OrderScheduling',
        component: () => import('@/views/businessService/orderScheduling'),
        meta: { title: '排程', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'careReceiverList',
        name: 'CareReceiverList',
        component: () => import('@/views/businessService/careReceiverList'),
        meta: { title: '被照护人管理', privilege: 'careReceiver_list', noCache: true }
      },
      {
        path: 'addCareReceiver',
        name: 'AddCareReceiver',
        component: () => import('@/views/businessService/addCareReceiver'),
        meta: { title: '新增被照护人', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'myCareReceiverList',
        name: 'MyCareReceiverList',
        component: () => import('@/views/businessService/myCareReceiverList'),
        meta: { title: '我的被照护人', privilege: 'myCareReceiver_list', noCache: true }
      },
      {
        path: 'addMyCareReceiver',
        name: 'AddMyCareReceiver',
        component: () => import('@/views/businessService/addMyCareReceiver'),
        meta: { title: '新增被照护人', privilege: 'admin' },
        hidden: true
      }
    ]
  },
  {
    path: '/financialManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '财务管理', icon: 'financial', privilege: 'financial', },
    children: [
      {
        path: 'orderPaymentReviewList',
        name: 'orderPaymentReviewList',
        component: () => import('@/views/financialManagement/orderPaymentReviewList'),
        meta: { title: '订单支付审核', privilege: 'financial_order_payment_review_list', noCache: true }
      },
    ]
  },
  {
    path: '/workOrderManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '工单管理', icon: 'workOrder', privilege: 'workOrd' },
    children: [
      {
        path: 'staffschedulingList',
        name: 'staffschedulingList',
        component: () => import('@/views/workOrderManagement/staffschedulingList'),
        meta: { title: '排程信息', privilege: 'staff_scheduling_manage_list', noCache: true }
      },
      {
        path: 'workOrderManagementList',
        name: 'workOrderManagementList',
        component: () => import('@/views/workOrderManagement/workOrderManagementList'),
        meta: { title: '工单信息', privilege: 'work_order_manage_list', noCache: true }
      },
      {


        path: 'detailOrder',
        name: 'detailOrder',
        component: () => import('@/views/workOrderManagement/detailOrder'),
        meta: { title: '工单详情', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'updateOrder',
        name: 'updateOrder',
        component: () => import('@/views/workOrderManagement/updateOrder'),
        meta: { title: '工单单号', privilege: 'admin' },
        hidden: true
      },
      // {
      //   path: 'equipmentList',
      //   name: 'EquipmentList',
      //   component: () => import('@/views/equipmentManagement/equipmentList'),
      //   meta: { title: '设备列表', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'orderEquipment',
      //   name: 'OrderEquipment',
      //   component: () => import('@/views/equipmentManagement/orderEquipment'),
      //   meta: { title: '订单设备信息', privilege: 'admin' }
      // },
      // {
      //   path: 'orderEquipmentAdd',
      //   name: 'OrderEquipmentAdd',
      //   component: () => import('@/views/equipmentManagement/orderEquipmentAdd'),
      //   meta: { title: '订单设备新增', privilege: 'admin' },
      //   hidden: true
      // },
      // {
      //   path: 'equipmentIndex',
      //   name: 'EquipmentIndex',
      //   component: () => import('@/views/equipmentManagement/EquipmentIndex'),
      //   meta: { title: '智能监护', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'bigDataManagement',
      //   name: 'BigDataManagement',
      //   component: () => import('@/views/bigDataShowCY/BigDataManagement'),
      //   meta: { title: '翠苑大屏维护', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'bigDataPageCY',
      //   name: 'BigDataPageCY',
      //   component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
      //   meta: { title: '翠苑大屏', privilege: 'admin' }
      // },
      // {
      //   path: 'smokeSensationList',
      //   name: 'SmokeSensationList',
      //   component: () => import('@/views/equipmentManagement/SmokeSensationList'),
      //   meta: { title: '烟感', privilege: 'admin' }
      // },
      // {
      //   path: 'gasDevicesList',
      //   name: 'GasDevicesList',
      //   component: () => import('@/views/equipmentManagement/GasDevicesList'),
      //   meta: { title: '燃气', privilege: 'admin' }
      // },
      // {
      //   path: 'equipmentTest',
      //   name: 'EquipmentTest',
      //   component: () => import('@/views/equipmentManagement/test'),
      //   meta: { title: '测试页面', privilege: 'admin' },
      // },
      // {
      //   path: 'alarmList',
      //   name: 'AlarmList',
      //   component: () => import('@/views/equipmentManagement/AlarmList'),
      //   meta: { title: '报警', privilege: 'admin',noCache: true }
      // },
      // {
      //   path: 'medicineChestList',
      //   name: 'MedicineChestList',
      //   component: () => import('@/views/equipmentManagement/MedicineChestList'),
      //   meta: { title: '药箱', privilege: 'admin',noCache: true }
      // },
      // {
      //   path: 'equipSettings',
      //   name: 'EquipSettings',
      //   component: () => import('@/views/equipmentManagement/EquipSettings'),
      //   meta: { title: '设置', privilege: 'admin' }
      // },
      // {
      //   path: 'roundsList',
      //   name: 'RoundsList',
      //   component: () => import('@/views/equipmentManagement/RoundsList'),
      //   meta: { title: '查房', privilege: 'admin',noCache: true }
      // }
    ]
  },
  {
    path: '/maskOrderManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '口罩预约管理', icon: 'maskOrder', privilege: 'maskOrder' },
    children: [
      {
        path: 'maskOrderManagementList',
        name: 'MaskOrderManagementList',
        component: () => import('@/views/maskOrder/maskOrderManagementList'),
        meta: { title: '预约列表', privilege: 'mask_order_manage_list', noCache: true }
      }
    ]
  },
  {
    path: '/evaluationManagement',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '评估管理', icon: 'evaluation', privilege: 'evaluation' },
    children: [
      // {
      //   path: 'evaluationTemplate',
      //   name: 'EvaluationTemplate',
      //   component: () => import('@/views/evaluationManagement/evaluationTemplate/evaluationTemplateList'),
      //   meta: { title: '评估模板', privilege: 'evaluation_template_list', noCache: true }
      // },
      // {
      //   path: 'assessmentSettings',
      //   name: 'AssessmentSettings',
      //   component: () => import('@/views/evaluationManagement/evaluationTemplate/assessmentSettingsList'),
      //   meta: { title: '评估模板表设置', privilege: 'admin'},
      //   hidden:true,
      // },
      // {
      //   path: 'editAssessTemplate',
      //   name: 'EditAssessTemplate',
      //   component: () => import('@/views/evaluationManagement/evaluationTemplate/editAssessTemplate'),
      //   meta: { title: '评估报告模板', privilege: 'admin'},
      //   hidden:true
      // },
      // {
      //   path: 'assessmentHistory',
      //   name: 'AssessmentHistory',
      //   component: () => import('@/views/evaluationManagement/evaluationTemplate/assessmentHistoryList'),
      //   meta: { title: '评估模板历史', privilege: 'admin'},
      //   hidden:true,
      // },
      // {
      //   path: 'addEvaluationForms',
      //   name: 'AddEvaluationForms',
      //   component: () => import('@/views/evaluationManagement/evaluationTemplate/addEvaluationForms'),
      //   meta: { title: '新增评估表', privilege: 'admin'},
      //   hidden:true,
      // },
      // {
      //   path: 'topicManagement',
      //   name: 'TopicManagement',
      //   component: () => import('@/views/evaluationManagement/topicManagement/topicManagementList'),
      //   meta: { title: '题目管理', privilege: 'topic_ment_list', noCache: true }
      // },
      // {
      //   path: 'painManagement',
      //   name: 'PainManagement',
      //   component: () => import('@/views/evaluationManagement/painManagement/painManagementList'),
      //   meta: { title: '痛点管理', privilege: 'pain_ment_list', noCache: true }
      // },
      // {
      //   path: 'serviceManagement',
      //   name: 'ServiceManagement',
      //   component: () => import('@/views/evaluationManagement/serviceManagement/serviceManagementList'),
      //   meta: { title: '服务管理', privilege: 'service_ment_list', noCache: true }
      // },
      {
        path: 'assessInformation',
        name: 'AssessInformation',
        component: () => import('@/views/evaluationManagement/assessInformation/assessInformationList'),
        meta: { title: '评估信息', privilege: 'assess_information_list', noCache: true }
      },
      {
        path: 'assessHome',
        name: 'AssessHome',
        component: () => import('@/views/evaluationManagement/assessInformation/assessHome'),
        meta: { title: '我的评估', privilege: 'assess_home', noCache: true }
      },
      {
        path: 'assessReport',
        name: 'AssessReport',
        component: () => import('@/views/evaluationManagement/assessInformation/assessReport'),
        meta: { title: '评估报告', privilege: 'admin' },
        hidden: true,
      },
      {
        path: 'insertAssess',
        name: 'InsertAssess',
        component: () => import('@/views/evaluationManagement/assessInformation/insertAssess'),
        meta: { title: '新增评估', privilege: 'admin' },
        hidden: true
      },
      // {
      //   path: 'labelManagementList',
      //   name: 'LabelManagementList',
      //   component: () => import('@/views/operate/labelManagementList'),
      //   meta: { title: '标签管理', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'contentManagementList',
      //   name: 'ContentManagementList',
      //   component: () => import('@/views/operate/contentManagementList'),
      //   meta: { title: '内容管理', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'addContent',
      //   name: 'AddContent',
      //   component: () => import('@/views/operate/addContent'),
      //   meta: { title: '新增', privilege: 'admin', noCache: true }
      // }
    ]
  },
  {
    path: '/wisdomCustody',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '智慧监护', icon: 'equipment', privilege: 'custody' },
    children: [
      {
        path: 'equipmentList',
        name: 'EquipmentList',
        component: () => import('@/views/equipmentManagement/equipmentList'),
        meta: { title: '设备管理', privilege: 'equip-management-list', noCache: true }
      },
      {
        path: 'orderEquipment',
        name: 'OrderEquipment',
        component: () => import('@/views/equipmentManagement/orderEquipment'),
        meta: { title: '订单管理', privilege: 'equip-order-management', noCache: true }
      },
      {
        path: 'orderEquipmentAdd',
        name: 'OrderEquipmentAdd',
        component: () => import('@/views/equipmentManagement/orderEquipmentAdd'),
        meta: { title: '订单设备新增', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'equipmentIndex',
        name: 'EquipmentIndex',
        component: () => import('@/views/equipmentManagement/equipmentIndex'),
        meta: { title: '智能监护', privilege: 'equip-smart-monitoring', noCache: true }
      },
      {
        path: 'bigDataManagement',
        name: 'BigDataManagement',
        component: () => import('@/views/bigDataShowCY/BigDataManagement'),
        meta: { title: '翠苑大屏维护', privilege: 'admin', noCache: true },
        hidden: true
      },
      {
        path: 'bigDataPageCY',
        name: 'BigDataPageCY',
        component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
        meta: { title: '翠苑大屏', privilege: 'admin' },
        hidden: true
      },
      // {
      //   path: 'bigDataManagement',
      //   name: 'BigDataManagement',
      //   component: () => import('@/views/bigDataShowCY/BigDataManagement'),
      //   meta: { title: '翠苑大屏维护', privilege: 'admin', noCache: true }
      // },
      // {
      //   path: 'bigDataPageCY',
      //   name: 'BigDataPageCY',
      //   component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
      //   meta: { title: '翠苑大屏', privilege: 'admin' }
      // },
      {
        path: 'smokeSensationList',
        name: 'SmokeSensationList',
        component: () => import('@/views/equipmentManagement/SmokeSensationList'),
        meta: { title: '烟感', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'gasDevicesList',
        name: 'GasDevicesList',
        component: () => import('@/views/equipmentManagement/GasDevicesList'),
        meta: { title: '燃气', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'equipmentTest',
        name: 'EquipmentTest',
        component: () => import('@/views/equipmentManagement/test'),
        meta: { title: '测试页面', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'alarmList',
        name: 'AlarmList',
        component: () => import('@/views/equipmentManagement/alarmList'),
        meta: { title: '报警', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'medicineChestList',
        name: 'MedicineChestList',
        component: () => import('@/views/equipmentManagement/medicineChestList'),
        meta: { title: '药箱', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'equipSettings',
        name: 'EquipSettings',
        component: () => import('@/views/equipmentManagement/equipSettings'),
        meta: { title: '设置', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'roundsList',
        name: 'RoundsList',
        component: () => import('@/views/equipmentManagement/roundsList'),
        meta: { title: '查房', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'smartBedList',
        name: 'SmartBedList',
        component: () => import('@/views/equipmentManagement/SmartBedList'),
        meta: { title: '智能床垫', privilege: 'admin' },
        hidden: true
      },
      {
        path: 'accessControlList',
        name: 'AccessControlList',
        component: () => import('@/views/equipmentManagement/AccessControlList'),
        meta: { title: '门磁感应器', privilege: 'admin' },
        hidden: true
      },
    ]
  },
  {
    path: '/statistics',
    component: Layout,
    redirect: 'noRedirect',
    alwaysShow: true,
    meta: { title: '数据统计', icon: 'statistics', privilege: 'statistics' },
    children: [
      {
        path: 'attendanceStatistics',
        name: 'AttendanceStatistics',
        component: () => import('@/views/Statistics/AttendanceStatisticsPlus'),
        meta: { title: '考勤统计', privilege: 'statistics_attendance'},
      },
      // {
      //   path: 'bigDataManagement',
      //   name: 'BigDataManagement',
      //   component: () => import('@/views/bigDataShowCY/BigDataManagement'),
      //   meta: { title: '数据录入', privilege: 'bigData_Entry', noCache: true },
      //   hidden:true,
      // },
      // {
      //   path: 'bigDataPageCY',
      //   name: 'BigDataPageCY',
      //   component: () => import('@/views/bigDataShowCY/bigDataTemplate'),
      //   meta: { title: '机构大屏', privilege: 'bigData_Screen' },
      //   hidden:true,
      // },
      {
        path: 'serviceForCustomer',
        name: 'ServiceForCustomer',
        component: () => import('@/views/Statistics/ServiceForCustomer'),
        // meta: { title: '服务产品客户统计', privilege: 'statistics_ServiceForCustomer'},
        meta: { title: '服务产品客户统计', privilege: 'admin'},
        hidden:true
      },
    ]
  },
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

export default router
